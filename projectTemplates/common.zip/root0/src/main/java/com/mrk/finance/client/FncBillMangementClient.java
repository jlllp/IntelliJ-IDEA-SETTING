package com.mrk.finance.client;

import com.mrk.common.utils.page.JsonResult;
import com.mrk.finance.client.dto.FncBillManagementDto;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import java.util.List;


/**
 * @date 2021-09-23
 * @author Bob
 * @description
 */
@FeignClient(name = "mrk-finance-api", url = "#[[\$]]#{feign.finance.url}")
public interface FncBillMangementClient {

    /**
     * 通过合同id查找所有账单
     */
    @RequestMapping("/finance/client/fnccontractmanagement/select_fnc_bill_management_by_contractid")
    JsonResult<List<FncBillManagementDto>> selectFncBillManagementByContractId(@RequestParam("fncContractManagementId") Long fncContractManagementId);

    /**
     * 通过合同集合修改账单数据
     */
    @RequestMapping("/finance/client/fnccontractmanagement/update_list_fnc_bill_mangemen")
    JsonResult<List<FncBillManagementDto>> updateListFncBillMangemen(@RequestParam("fncBillManagementStr") String fncBillManagementStr);

    /**
     * 通过账单id查找账单
     */
    @RequestMapping("/finance/client/fnccontractmanagement/select_fnc_bill_management_by_billid")
    JsonResult<FncBillManagementDto> selectFncBillManagementByBillId(@RequestParam("billId") Long billId);

    /**
     * 通过账单修改账单
     */
    @RequestMapping("/finance/client/fnccontractmanagement/update_fnc_bill_management_by_bill")
    JsonResult<FncBillManagementDto> updateFncBillManagementByBill(@RequestParam("billStr") String billStr);


    /**
     * 收车工单找到租金账单是截止日期前一天的账单
     */
    @RequestMapping("/finance/client/fnccontractmanagement/select_fnc_rent_bill_management")
    JsonResult<Object> selectFncBillManagementRent();

    /**
     * 新增一条账单数据
     * @param fncBillManagementDto 账单接收实体
     * @return
     */
    @PostMapping("/finance/client/fnccontractmanagement/addFncBillManagementRent")
    JsonResult<FncBillManagementDto> addFncBillManagement(@RequestBody FncBillManagementDto fncBillManagementDto);

}
