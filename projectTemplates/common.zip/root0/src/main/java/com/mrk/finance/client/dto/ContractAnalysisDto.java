package com.mrk.finance.client.dto;

import com.fasterxml.jackson.annotation.JsonFormat;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import org.springframework.format.annotation.DateTimeFormat;

import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import java.math.BigDecimal;

/**
 * @project mrk-finance
 * @author Frank.Tang
 * @date 2022-03-30 11:14
 * @desc 天眼1.1 -- 合同统计临时表
 **/
@Data
public class ContractAnalysisDto {

    /**合同统计表主键 */
    @ApiModelProperty(value = "合同统计表主键")
    private Long dcaId;

    /**甲方类型1, "个人") 2, "组织" */
    @ApiModelProperty(value = "甲方类型")
    private Integer dcaPartyaType;

    /**甲方ID */
    @ApiModelProperty(value = "甲方ID")
    private Long dcaPartyaId;

    /**乙方类型 1, "个人")2, "组织" */
    @ApiModelProperty(value = "乙方类型")
    private Integer dcaPartybType;

    /**乙方ID */
    @ApiModelProperty(value = "乙方ID")
    private Long dcaPartybId;

    /**统计日期 */
    @DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss", timezone = "GMT+8")
    @ApiModelProperty(value = "统计日期")
    private java.util.Date dcaTime;

    /**合同id */
    @ApiModelProperty(value = "合同id")
    private Long dcaContractId;

    /**合同金额 */
    @ApiModelProperty(value = "合同金额")
    private Double dcaContractAmount;

    /**合同车辆数 */
    @ApiModelProperty(value = "合同车辆数")
    private Long dcaContractNum;

    /**合同交付车辆数 */
    @ApiModelProperty(value = "合同交付车辆数")
    private Long dcaContractDelivery;

}
