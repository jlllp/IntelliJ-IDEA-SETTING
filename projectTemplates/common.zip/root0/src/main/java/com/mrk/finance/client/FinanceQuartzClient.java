package com.mrk.finance.client;

import com.mrk.common.utils.page.JsonResult;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

/**
 * @author Bob
 * @date 2021-11-12
 * @description
 */
@FeignClient(name = "mrk-finance-api", url = "#[[\$]]#{feign.finance.url}")
public interface FinanceQuartzClient {

    /**
     * @author Bob
     * @date 2021/11/12
     * @description 清理24小时前的临时数据
     * @param paramStr 请求参数
     * @return 执行结果
     */
    @RequestMapping(value = "/finance/client/quartz/cleartemp")
    JsonResult<Object> clearTemp(@RequestParam(value = "paramStr", required = false) String paramStr);

    /**
     * @author Bob
     * @date 2021/11/12
     * @description 计算合同状态
     * @param paramStr 请求参数
     * @return 执行结果
     */
    @RequestMapping(value = "/finance/client/quartz/calculatecontractstate")
    JsonResult<Object> calculateContractState(@RequestParam(value = "paramStr", required = false) String paramStr);

    /**
     * @author Bob
     * @date 2021/11/12
     * @description 计算结算状态
     * @param paramStr 请求参数
     * @return 执行结果
     */
    @RequestMapping(value = "/finance/client/quartz/calculatesettlementstate")
    JsonResult<Object> calculateSettlementState(@RequestParam(value = "paramStr", required = false) String paramStr);

    /**
     * @author Bob
     * @date 2021/11/15
     * @description 购车尾款生成
     * @param paramStr 请求参数
     * @return 执行结果
     */
    @RequestMapping(value = "/finance/client/quartz/carpurchasebalancegeneration")
    JsonResult<Object> carPurchaseBalanceGeneration(@RequestParam(value = "paramStr", required = false) String paramStr);

    /**
     * @author Bob
     * @date 2021/11/15
     * @description 保证金退还生成
     * @param paramStr 请求参数
     * @return 执行结果
     */
    @RequestMapping(value = "/finance/client/quartz/depositrefundgeneration")
    JsonResult<Object> depositRefundGeneration(@RequestParam(value = "paramStr", required = false) String paramStr);

    /**
     * @author Bob
     * @date 2021/11/18
     * @description 检查账单是否逾期
     * @param paramStr 请求参数
     * @return 执行结果
     */
    @RequestMapping(value = "/finance/client/quartz/overduebillcheck")
    JsonResult<Object> overdueBillCheck(@RequestParam(value = "paramStr", required = false) String paramStr);

    /**
     * @author Bob
     * @date 2021/11/22
     * @description 租金账单生成定时任务
     * @param paramStr 请求参数
     * @return 执行结果
     */
    @RequestMapping(value = "/finance/client/quartz/rentbillgeneration")
    JsonResult<Object> rentBillGeneration(@RequestParam(value = "paramStr", required = false) String paramStr);

    /**
     * @author Bob
     * @date 2021/11/24
     * @description 确认收入计算定时任务
     * @param paramStr 请求参数
     * @return 执行结果
     */
    @RequestMapping(value = "/finance/client/quartz/incomecalculation")
    JsonResult<Object> incomeCalculation(@RequestParam(value = "paramStr", required = false) String paramStr);

    /**
     * @author Bob
     * @date 2021/12/24
     * @description 检查合同中止
     * @param paramStr 请求参数
     * @return 执行结果
     */
    @RequestMapping(value = "/finance/client/quartz/checkstop")
    JsonResult<Object> checkStop(@RequestParam(value = "paramStr", required = false) String paramStr);

}
