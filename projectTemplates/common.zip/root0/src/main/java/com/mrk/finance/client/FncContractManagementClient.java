package com.mrk.finance.client;

import com.mrk.common.utils.page.JsonResult;
import com.mrk.finance.client.dto.*;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import java.util.Date;
import java.util.List;
import java.util.Map;


/**
 * @date 2021-09-23
 * @author Bob
 * @description
 */
@FeignClient(name = "mrk-finance-api", url = "#[[\$]]#{feign.finance.url}")
public interface FncContractManagementClient {

    /**
     * 通过合同id查找合同
     */
    @RequestMapping("/finance/client/fnccontractmanagement/select_fnccontractmanagement_id")
    JsonResult<FncContractManagementDto> getByFncContractManagementId(@RequestParam("fncContractManagementId") Long fncContractManagementId);

    /**
     * 通过合同id查找该合同下所有的车型和数量
     */
    @RequestMapping("/finance/client/fnccontractmanagement/get_fnc_contract_car")
    JsonResult<List<FncContractCarDto>> getByFncContractCar(@RequestParam("fncContractManagementId") Long fncContractManagementId);

    /**
     * 通过合同编号查找合同
     */
    @RequestMapping("/finance/client/fnccontractmanagement/get_fnc_contract_no")
    JsonResult<List<FncContractManagementDto>> getByFncContractNo(@RequestParam("fncContractNo") String fncContractNo);



    /**
     * 通过合同id和起始日期查询租赁结束日期和总金额
     */
    @RequestMapping("/finance/client/fnccontractmanagement/get_end_date")
    JsonResult<String> getContractEndDate(@RequestParam("fncContractManagementId") Long fncContractManagementId,
                                          @RequestParam("stateDate") Date stateDate);


    /**
     * 修改合同
     */
    @RequestMapping("/finance/client/fnccontractmanagement/update_fnccontractmanagement_id")
    JsonResult<FncContractManagementDto> updateByFncContractManagementId(@RequestParam("fncContractManagementStr") String fncContractManagementStr);


    /**
     * 通过合同id集合查找合同，天眼1.1预测数据使用
     */
    @RequestMapping("/finance/client/fnccontractmanagement/select_fnccontractmanagement_by_trafficanalysis")
    JsonResult<List<FncContractManagementDto>> getByFncContractManagementByTrafficAnalysis(@RequestParam("fncContractManagementIdStr") String fncContractManagementIdStr);


    /**
     * 通过合同idList查找合同
     */
    @RequestMapping("/finance/client/fnccontractmanagement/select_fnccontractmanagement_idlist")
    JsonResult<List<FncContractManagementDto>> getByFncContractManagementIdList(@RequestParam("fncContractManagementIdListStr") String fncContractManagementIdListStr);

    /**
     * 获取租赁结束日期超过三天且没有处理过收车工单的合同
     */
    @RequestMapping("/finance/client/fnccontractmanagement/select_fnccontractmanagement_rent_overtime")
    JsonResult<List<FncContractManagementDto>> getByRentOverTime(@RequestParam("day")Integer day);


    /**
     * 获取租赁中的所有合同
     */
    @RequestMapping("/finance/client/fnccontractmanagement/get_all")
    JsonResult<List<FncContractManagementDto>> getAll();

    /**
     * 获取租赁中的且为自营网约车性质的所有合同
     */
    @RequestMapping("/finance/client/fnccontractmanagement/get_all_bytype")
    JsonResult<List<FncContractManagementDto>> getAllByType();


    /**
     * 根据逾期天数获取账单
     */
    @RequestMapping("/finance/client/fnccontractmanagement/getOverdue")
    JsonResult<List<FncBillManagementRiskDto>> getOverdue(@RequestParam(value = "day", required = false) Integer day);


    /**
     * 得到合同统计临时表的数据(das_contract_analysis)
     * @author Frank.Tang
     * @return 统计结果
     */
    @RequestMapping("/finance/client/fnccontractmanagement/init_contract_analysis_data")
    JsonResult<List<ContractAnalysisDto>> getContractAnalysisData();

    /**
     * 得到合同统计临时表的数据(das_contract_analysis) (测试用)
     * @author Frank.Tang
     * @return 统计结果
     */
    @RequestMapping("/finance/client/fnccontractmanagement/init_contract_analysis_data_test")
    JsonResult<List<ContractAnalysisDto>> getContractAnalysisDataTest(@RequestParam("start") int start,
                                                                      @RequestParam("size") int size);

    /**
     * 初始化合同临时表(das_contract_carmodel_analysis)数据
     * @author Frank.Tang
     * @return 统计结果
     */
    @RequestMapping("/finance/client/fnccontractmanagement/init_contract_carmodel_analysis_data")
    JsonResult<List<ContractAnalysisDto>> getContractCarModelAnalysisData();

    /**
     * 初始化合同临时表(das_contract_carmodel_analysis)数据 (测试用)
     * @author Frank.Tang
     * @return 统计结果
     */
    @RequestMapping("/finance/client/fnccontractmanagement/init_contract_carmodel_analysis_data_test")
    JsonResult<List<ContractAnalysisDto>> getContractCarModelAnalysisDataTest(@RequestParam("start") int start,
                                                                              @RequestParam("size") int size);

    /**
     * 通过合同类型, 查所有的合同id ("租赁待开始"除外)
     * @author Frank.Tang
     * @return 统计结果
     */
    @RequestMapping("/finance/client/fnccontractmanagement/get_contract_id_by_type")
    JsonResult<List<Long>> getContractIdByType(@RequestParam("type") Integer type);

    /**
     * 通过合同类型, 查所有的合同id ("租赁待开始"除外)
     * @author Frank.Tang
     * @return 统计结果
     */
    @RequestMapping("/finance/client/fnccontractmanagement/get_contract_id_by_carmodel")
    JsonResult<List<Long>> getContractIdByCarModel(@RequestParam("carModel") Long carModel);

    /**
     * 根据合同ids, 查车型关联表 (天眼1.1合同统计)
     * @author Frank.Tang
     * @return 封装后的数据
     */
    @RequestMapping("/finance/client/fnccontractmanagement/get_contract_car_model_by_contract_ids")
    JsonResult<List<ContractCarModelAnalysisDto>> getContractCarModelByContractIds(@RequestParam("ids") String ids);


    /**
     * 根据合同ids, 查对应的车辆签订数 (天眼1.1合同统计)
     * @author Frank.Tang
     * @return <合同id, 签订车辆数>
     */
    @RequestMapping("/finance/client/fnccontractmanagement/get_sign_count_by_contract_ids")
    JsonResult<Map<Long, Integer>> getSignCountByContractIds(@RequestParam("ids") String ids);

}
