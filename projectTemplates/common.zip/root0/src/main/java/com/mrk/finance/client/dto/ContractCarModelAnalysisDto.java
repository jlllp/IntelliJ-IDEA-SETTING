package com.mrk.finance.client.dto;

import com.fasterxml.jackson.annotation.JsonFormat;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import org.springframework.format.annotation.DateTimeFormat;

/**
 * @project mrk-finance
 * @author Frank.Tang
 * @date 2022-04-02 14:12
 * @desc
 **/
@Data
public class ContractCarModelAnalysisDto {

    /**主键 */
    @ApiModelProperty(value = "主键")
    private Long dccaId;

    /**统计日期 */
    @DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss", timezone = "GMT+8")
    @ApiModelProperty(value = "统计日期")
    private java.util.Date dccaTime;

    /**合同id */
    @ApiModelProperty(value = "合同id")
    private Long dccaContractId;

    /**车型id */
    @ApiModelProperty(value = "车型id")
    private Long dccaCarmodelId;

    /**车型的车辆数 */
    @ApiModelProperty(value = "车型的车辆数")
    private Long dccaCarNum = 0L;

    /**车型的交付车辆数 */
    @ApiModelProperty(value = "车型的交付车辆数")
    private Long dccaCarDeliveryNum = 0L;

}
