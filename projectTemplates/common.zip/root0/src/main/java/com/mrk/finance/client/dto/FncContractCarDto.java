package com.mrk.finance.client.dto;

import com.mrk.common.base.BaseEntity;
import io.swagger.annotations.ApiModelProperty;
import lombok.Getter;
import lombok.Setter;

import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import java.io.Serializable;

@Setter
@Getter
public class FncContractCarDto extends BaseEntity implements Serializable {
private static final long serialVersionUID=1L;


    /**主键 */
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @ApiModelProperty(value = "主键")
    private Long fccId;

    /**合同id */
    @ApiModelProperty(value = "合同id")
    private Long fccContractId;

    /**车型id */
    @ApiModelProperty(value = "车型id")
    private Long fccContractCarmodelId;

    /**数量 */
    @ApiModelProperty(value = "数量")
    private Integer fccCarnum;
    }
