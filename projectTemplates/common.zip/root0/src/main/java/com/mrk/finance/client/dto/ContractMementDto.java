package com.mrk.finance.client.dto;

import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.io.Serializable;

@Data
public class ContractMementDto implements Serializable {

  @ApiModelProperty(value = "合同id")
  private Long contractId;

  /**车辆状态 */
  @ApiModelProperty(value = "车辆状态")
  private Integer wpwcCarState;

  /**车架号 */
  @ApiModelProperty(value = "车架号")
  private String rcVin;

  /**车牌号 */
  @ApiModelProperty(value = "车牌号")
  private String rcPlateNum;

  /**条数 */
  @ApiModelProperty(value = "条数")
  private Integer rows;


  /**页数 */
  @ApiModelProperty(value = "页数")
  private Integer page;

}
