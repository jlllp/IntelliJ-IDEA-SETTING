package com.mrk.finance.client.dto;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.mrk.common.base.BaseEntity;
import io.swagger.annotations.ApiModelProperty;
import lombok.Getter;
import lombok.Setter;
import org.springframework.format.annotation.DateTimeFormat;

import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import java.io.Serializable;

@Setter
@Getter
public class FncBillManagementDto extends BaseEntity implements Serializable {
    private static final long serialVersionUID = 1L;


    /**
     * 主键
     */
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @ApiModelProperty(value = "主键")
    private Long fbmId;

    /**
     * 城市
     */
    @ApiModelProperty(value = "城市")
    private Long fbmCityId;

    /**
     * 科目（类型）
     */
    @ApiModelProperty(value = "科目（类型）")
    private Integer fbmSubjects;

    /**
     * 账单金额
     */
    @ApiModelProperty(value = "账单金额")
    private Double fbmBillAmount;

    /**
     * 期数
     */
    @ApiModelProperty(value = "期数")
    private String fbmNper;

    /**
     * 账单生成时间
     */
    @DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss", timezone = "GMT+8")
    @ApiModelProperty(value = "账单生成时间")
    private java.util.Date fbmBillGenerateTime;

    /**
     * 账单生成方式
     */
    @ApiModelProperty(value = "账单生成方式")
    private Integer fbmBillGenerateWay;

    /**
     * 账单截止时间
     */
    @DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss", timezone = "GMT+8")
    @ApiModelProperty(value = "账单截止时间")
    private java.util.Date fbmBillCatoffTime;

    /**
     * 关联车辆ID
     */
    @ApiModelProperty(value = "关联车辆ID")
    private Long fbmAssociateCarId;

    /**
     * 关联合同ID
     */
    @ApiModelProperty(value = "关联合同ID")
    private Long fbmAssociateContractId;

    /**
     * 账单状态
     */
    @ApiModelProperty(value = "账单状态")
    private Integer fbmBillState;

    /**
     * 匹配方式
     */
    @ApiModelProperty(value = "匹配方式")
    private Integer fbmMatchWay;

    /**
     * 匹配人ID
     */
    @ApiModelProperty(value = "匹配人ID")
    private Long fbmMatchUserId;

    /**
     * 匹配时间
     */
    @DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss", timezone = "GMT+8")
    @ApiModelProperty(value = "匹配时间")
    private java.util.Date fbmMatchTime;

    /**
     * 匹配流水号
     */
    @ApiModelProperty(value = "匹配流水号")
    private String fbmMatchSerialNumber;

    /**
     * 支付时间
     */
    @DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss", timezone = "GMT+8")
    @ApiModelProperty(value = "支付时间")
    private java.util.Date fbmPayTime;

    /**
     * 已匹配金额
     */
    @ApiModelProperty(value = "已匹配金额")
    private Double fbmMatchedAmount;

    /**
     * 未匹配金额
     */
    @ApiModelProperty(value = "未匹配金额")
    private Double fbmNotMatchAmount;

    /**
     * 账单生成原因
     */
    @ApiModelProperty(value = "账单生成原因")
    private String fbmBillGenerateReason;

    /**
     * 账单凭证
     */
    @ApiModelProperty(value = "账单凭证")
    private String fbmBillVoucher;


    /**
     * 车牌号
     */
    @ApiModelProperty(value = "车牌号")
    private String fbmPlateNum;


    /**
     * 科目（类型）文本
     */
    @ApiModelProperty(value = "科目（类型）文本")
    private String fbmSubjectsText;


    /**
     * 计租日期
     */
    @DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss", timezone = "GMT+8")
    @ApiModelProperty(value = "计租日期")
    private java.util.Date fbmLeasePeriod;

}
