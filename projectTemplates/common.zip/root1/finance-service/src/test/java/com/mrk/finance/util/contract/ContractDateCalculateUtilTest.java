package com.mrk.finance.util.contract;

import com.mrk.finance.dto.date.TimeRightDto;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Map;
import java.util.SortedMap;

import static org.junit.jupiter.api.Assertions.assertEquals;

public class ContractDateCalculateUtilTest {
    private static final Logger log = LoggerFactory.getLogger(ContractDateCalculateUtilTest.class);

    @Test
    @DisplayName("")
    public void calculateThePaymentPeriodByRelative() {
        String dateStr = "2021-11-16";
        SimpleDateFormat simpleDateFormat = new SimpleDateFormat("yyyy-MM-dd");
        Date date;
        try {
            date = simpleDateFormat.parse(dateStr);
        } catch (ParseException e) {
            log.error("解析时间错误", e);
            throw new RuntimeException(e.getMessage());
        }

        // 相对周期测试
        log.info("相对周期-测试场景1：租赁日期=\"2021-11-16\" 租期=5 周期类型=相对周期 间隔=3");
        SortedMap<Integer, TimeRightDto> integerTimeRightDtoSortedMap = ContractDateCalculateUtil.calculateThePaymentPeriod(date, 5, 1, 3);
        outputMap(integerTimeRightDtoSortedMap);
        TimeRightDto timeRightDto = integerTimeRightDtoSortedMap.get(1);
        assertEquals("2021-11-16", simpleDateFormat.format(timeRightDto.getStart()));
        assertEquals("2022-02-15", simpleDateFormat.format(timeRightDto.getEnd()));
        timeRightDto = integerTimeRightDtoSortedMap.get(2);
        assertEquals("2022-02-16", simpleDateFormat.format(timeRightDto.getStart()));
        assertEquals("2022-04-15", simpleDateFormat.format(timeRightDto.getEnd()));

        log.info("相对周期-测试场景2：租赁日期=\"2021-11-16\" 租期=5 周期类型=相对周期 间隔=12");
        integerTimeRightDtoSortedMap = ContractDateCalculateUtil.calculateThePaymentPeriod(date, 5, 1, 12);
        outputMap(integerTimeRightDtoSortedMap);
        timeRightDto = integerTimeRightDtoSortedMap.get(1);
        assertEquals("2021-11-16", simpleDateFormat.format(timeRightDto.getStart()));
        assertEquals("2022-04-15", simpleDateFormat.format(timeRightDto.getEnd()));

        log.info("相对周期-测试场景3：租赁日期=\"2021-11-16\" 租期=15 周期类型=相对周期 间隔=6");
        integerTimeRightDtoSortedMap = ContractDateCalculateUtil.calculateThePaymentPeriod(date, 15, 1, 6);
        outputMap(integerTimeRightDtoSortedMap);
        timeRightDto = integerTimeRightDtoSortedMap.get(1);
        assertEquals("2021-11-16", simpleDateFormat.format(timeRightDto.getStart()));
        assertEquals("2022-05-15", simpleDateFormat.format(timeRightDto.getEnd()));
        timeRightDto = integerTimeRightDtoSortedMap.get(2);
        assertEquals("2022-05-16", simpleDateFormat.format(timeRightDto.getStart()));
        assertEquals("2022-11-15", simpleDateFormat.format(timeRightDto.getEnd()));
        timeRightDto = integerTimeRightDtoSortedMap.get(3);
        assertEquals("2022-11-16", simpleDateFormat.format(timeRightDto.getStart()));
        assertEquals("2023-02-15", simpleDateFormat.format(timeRightDto.getEnd()));

        log.info("相对周期-测试场景4：租赁日期=\"2021-11-16\" 租期=3 周期类型=相对周期 间隔=1");
        integerTimeRightDtoSortedMap = ContractDateCalculateUtil.calculateThePaymentPeriod(date, 3, 1, 1);
        outputMap(integerTimeRightDtoSortedMap);
        timeRightDto = integerTimeRightDtoSortedMap.get(1);
        assertEquals("2021-11-16", simpleDateFormat.format(timeRightDto.getStart()));
        assertEquals("2021-12-15", simpleDateFormat.format(timeRightDto.getEnd()));
        timeRightDto = integerTimeRightDtoSortedMap.get(2);
        assertEquals("2021-12-16", simpleDateFormat.format(timeRightDto.getStart()));
        assertEquals("2022-01-15", simpleDateFormat.format(timeRightDto.getEnd()));
        timeRightDto = integerTimeRightDtoSortedMap.get(3);
        assertEquals("2022-01-16", simpleDateFormat.format(timeRightDto.getStart()));
        assertEquals("2022-02-15", simpleDateFormat.format(timeRightDto.getEnd()));

        log.info("相对周期-测试场景5：租赁日期=\"2021-11-16\" 租期=36 周期类型=相对周期 间隔=12");
        integerTimeRightDtoSortedMap = ContractDateCalculateUtil.calculateThePaymentPeriod(date, 36, 1, 12);
        outputMap(integerTimeRightDtoSortedMap);
        timeRightDto = integerTimeRightDtoSortedMap.get(1);
        assertEquals("2021-11-16", simpleDateFormat.format(timeRightDto.getStart()));
        assertEquals("2022-11-15", simpleDateFormat.format(timeRightDto.getEnd()));
        timeRightDto = integerTimeRightDtoSortedMap.get(2);
        assertEquals("2022-11-16", simpleDateFormat.format(timeRightDto.getStart()));
        assertEquals("2023-11-15", simpleDateFormat.format(timeRightDto.getEnd()));
        timeRightDto = integerTimeRightDtoSortedMap.get(3);
        assertEquals("2023-11-16", simpleDateFormat.format(timeRightDto.getStart()));
        assertEquals("2024-11-15", simpleDateFormat.format(timeRightDto.getEnd()));


    }

    @Test
    public void calculateThePaymentPeriodByNatural() {
        String dateStr = "2021-11-16";
        SimpleDateFormat simpleDateFormat = new SimpleDateFormat("yyyy-MM-dd");
        Date date;
        try {
            date = simpleDateFormat.parse(dateStr);
        } catch (ParseException e) {
            log.error("解析时间错误", e);
            throw new RuntimeException(e.getMessage());
        }

        // 自然周期测试
        log.info("自然周期-测试场景1：租赁日期=\"2021-11-16\" 租期=5 周期类型=相对周期 间隔=3");
        SortedMap<Integer, TimeRightDto> integerTimeRightDtoSortedMap = ContractDateCalculateUtil.calculateThePaymentPeriod(date, 5, 0, 3);
        outputMap(integerTimeRightDtoSortedMap);
        TimeRightDto timeRightDto = integerTimeRightDtoSortedMap.get(1);
        assertEquals("2021-11-16", simpleDateFormat.format(timeRightDto.getStart()));
        assertEquals("2022-01-31", simpleDateFormat.format(timeRightDto.getEnd()));
        timeRightDto = integerTimeRightDtoSortedMap.get(2);
        assertEquals("2022-02-01", simpleDateFormat.format(timeRightDto.getStart()));
        assertEquals("2022-03-31", simpleDateFormat.format(timeRightDto.getEnd()));

        log.info("自然周期-测试场景2：租赁日期=\"2021-11-16\" 租期=5 周期类型=相对周期 间隔=12");
        integerTimeRightDtoSortedMap = ContractDateCalculateUtil.calculateThePaymentPeriod(date, 5, 0, 12);
        outputMap(integerTimeRightDtoSortedMap);
        timeRightDto = integerTimeRightDtoSortedMap.get(1);
        assertEquals("2021-11-16", simpleDateFormat.format(timeRightDto.getStart()));
        assertEquals("2022-03-31", simpleDateFormat.format(timeRightDto.getEnd()));

        log.info("自然周期-测试场景3：租赁日期=\"2021-11-16\" 租期=15 周期类型=相对周期 间隔=6");
        integerTimeRightDtoSortedMap = ContractDateCalculateUtil.calculateThePaymentPeriod(date, 15, 0, 6);
        outputMap(integerTimeRightDtoSortedMap);
        timeRightDto = integerTimeRightDtoSortedMap.get(1);
        assertEquals("2021-11-16", simpleDateFormat.format(timeRightDto.getStart()));
        assertEquals("2022-04-30", simpleDateFormat.format(timeRightDto.getEnd()));
        timeRightDto = integerTimeRightDtoSortedMap.get(2);
        assertEquals("2022-05-01", simpleDateFormat.format(timeRightDto.getStart()));
        assertEquals("2022-10-31", simpleDateFormat.format(timeRightDto.getEnd()));
        timeRightDto = integerTimeRightDtoSortedMap.get(3);
        assertEquals("2022-11-01", simpleDateFormat.format(timeRightDto.getStart()));
        assertEquals("2023-01-31", simpleDateFormat.format(timeRightDto.getEnd()));

        log.info("自然周期-测试场景4：租赁日期=\"2021-11-16\" 租期=3 周期类型=相对周期 间隔=1");
        integerTimeRightDtoSortedMap = ContractDateCalculateUtil.calculateThePaymentPeriod(date, 3, 0, 1);
        outputMap(integerTimeRightDtoSortedMap);
        timeRightDto = integerTimeRightDtoSortedMap.get(1);
        assertEquals("2021-11-16", simpleDateFormat.format(timeRightDto.getStart()));
        assertEquals("2021-11-30", simpleDateFormat.format(timeRightDto.getEnd()));
        timeRightDto = integerTimeRightDtoSortedMap.get(2);
        assertEquals("2021-12-01", simpleDateFormat.format(timeRightDto.getStart()));
        assertEquals("2021-12-31", simpleDateFormat.format(timeRightDto.getEnd()));
        timeRightDto = integerTimeRightDtoSortedMap.get(3);
        assertEquals("2022-01-01", simpleDateFormat.format(timeRightDto.getStart()));
        assertEquals("2022-01-31", simpleDateFormat.format(timeRightDto.getEnd()));

        log.info("自然周期-测试场景5：租赁日期=\"2021-11-16\" 租期=36 周期类型=相对周期 间隔=12");
        integerTimeRightDtoSortedMap = ContractDateCalculateUtil.calculateThePaymentPeriod(date, 36, 0, 12);
        outputMap(integerTimeRightDtoSortedMap);
        timeRightDto = integerTimeRightDtoSortedMap.get(1);
        assertEquals("2021-11-16", simpleDateFormat.format(timeRightDto.getStart()));
        assertEquals("2022-10-31", simpleDateFormat.format(timeRightDto.getEnd()));
        timeRightDto = integerTimeRightDtoSortedMap.get(2);
        assertEquals("2022-11-01", simpleDateFormat.format(timeRightDto.getStart()));
        assertEquals("2023-10-31", simpleDateFormat.format(timeRightDto.getEnd()));
        timeRightDto = integerTimeRightDtoSortedMap.get(3);
        assertEquals("2023-11-01", simpleDateFormat.format(timeRightDto.getStart()));
        assertEquals("2024-10-31", simpleDateFormat.format(timeRightDto.getEnd()));
    }

    /**
     * @author Bob
     * @date 2021/11/16
     * @description 格式化输出map中的内容
     * @param integerTimeRightDtoSortedMap 待输出内容map
     */
    private static void outputMap(SortedMap<Integer, TimeRightDto> integerTimeRightDtoSortedMap){
        for (Map.Entry<Integer, TimeRightDto> entry : integerTimeRightDtoSortedMap.entrySet()) {
            log.info("期数：【{}】 周期时间：【{}】", entry.getKey(), entry.getValue());
        }
    }

    @Test
    public void getDayByMonth() throws ParseException {
        String day = "2021-11-5";
        SimpleDateFormat simpleDateFormat = new SimpleDateFormat("yyyy-MM-dd");
        Date theDay = simpleDateFormat.parse(day);
        int dayByMonth = ContractDateCalculateUtil.getDayByMonth(theDay);
        assertEquals(5, dayByMonth);
    }

    @Test
    public void getActualMaximum() throws ParseException {
        String day = "2021-11-5";
        SimpleDateFormat simpleDateFormat = new SimpleDateFormat("yyyy-MM-dd");
        Date theDay = simpleDateFormat.parse(day);
        int dayByMonth = ContractDateCalculateUtil.getActualMaximum(theDay);
        assertEquals(30 , dayByMonth);
    }

    @Test
    public void daysBetween() throws ParseException {
        SimpleDateFormat simpleDateFormat = new SimpleDateFormat("yyyy-MM-dd");
        Date start = simpleDateFormat.parse("2021-11-5");
        Date end = simpleDateFormat.parse("2021-11-30");
        int interval = ContractDateCalculateUtil.daysBetween(start, end);
        assertEquals(25, interval);
    }

    @Test
    public void getYearMonth() throws ParseException {
        SimpleDateFormat simpleDateFormat = new SimpleDateFormat("yyyy-MM-dd");
        Date date1 = simpleDateFormat.parse("2021-11-5");
        Date yearMonth = ContractDateCalculateUtil.getYearMonth(date1);
        simpleDateFormat = new SimpleDateFormat("yyyy-MM");
        Date date2 = simpleDateFormat.parse("2021-11");
        assertEquals(date2, yearMonth);
    }
}