package com.mrk.finance.facade.quartz;


import com.mrk.auth.client.AuthDeptClient;
import com.mrk.auth.model.AuthDept;
import com.mrk.common.constant.HttpConstants;
import com.mrk.common.utils.page.JsonResult;
import com.mrk.finance.enums.*;
import com.mrk.finance.model.FncConfirmIncome;
import com.mrk.finance.model.FncContractManagement;
import com.mrk.finance.provider.FinanceQuartzProvider;
import com.mrk.finance.service.FncConfirmIncomeService;
import com.mrk.finance.service.FncContractManagementService;
import com.mrk.finance.util.contract.ContractDateCalculateUtil;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.boot.test.mock.mockito.SpyBean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.test.context.junit.jupiter.SpringExtension;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.mockito.Mockito.doReturn;

@ExtendWith(SpringExtension.class)
@SpringBootTest(webEnvironment = SpringBootTest.WebEnvironment.MOCK)
@ComponentScan(value = {"com.mrk.finance"})
public class ConfirmedIncomeFacadeTest {

    @InjectMocks
    @Autowired
    private FinanceQuartzProvider financeQuartzProvider;

    @MockBean
    private AuthDeptClient authDeptClient;

    @SpyBean
    private FncContractManagementService fncContractManagementService;

    @Autowired
    private FncConfirmIncomeService fncConfirmIncomeService;

    /**
     * @author Bob
     * @date 2021/12/4
     * @description 计算确认收入定时任务
     */
    @Test
    @Transactional
    @DisplayName("计算确认收入定时任务")
    public void incomeCalculation() {
        dataPreparation();
        // 准备合同
        prepareContract();
        JsonResult<Object> jsonResult = financeQuartzProvider.incomeCalculation(null);
        assertEquals(HttpConstants.CODE_SUCCESS, jsonResult.getCode());
        List<FncConfirmIncome> fncConfirmIncomes = fncConfirmIncomeService.getByDept(-1L);
        FncConfirmIncome fncConfirmIncome = fncConfirmIncomes.get(0);
        assertEquals(0, BigDecimal.valueOf(9588D).compareTo(BigDecimal.valueOf(fncConfirmIncome.getFciTotalIncome())));
        assertNotNull(fncConfirmIncome.getFciCarPurchaseIncome());
        assertNotNull(fncConfirmIncome.getFciIncomeMonth());
        assertNotNull(fncConfirmIncome.getFciRentIncome());
        assertNotNull(fncConfirmIncome.getFciPenaltyIncome());
        assertNotNull(fncConfirmIncome.getFciDeptId());
    }

    /**
     * @author Bob
     * @date 2021/12/7
     * @description 准备合同
     *              这里的时间会受影响
     *              使用的组织ID为1 确保有这个组织
     */
    private void prepareContract() {
        List<FncContractManagement> contractManagementList = new ArrayList<>();
        FncContractManagement contractManagement = new FncContractManagement();
        contractManagement.setFcmLeaseCount(108);
        Date date = ContractDateCalculateUtil.formatDay("2021-03-19");
        contractManagement.setFcmLeaseStartDate(date);
        date = ContractDateCalculateUtil.formatDay("2030-03-18");
        contractManagement.setFcmLeaseEndDate(date);
        contractManagement.setFcmId(-1L);
        contractManagement.setFcmLeaseType(ContractLeaseTypeEnum.FIXED.getValue());
        contractManagement.setFcmLeaseAmount(888D);
        contractManagement.setFcmRentPayType(ContractRentPayTypeEnum.RELATIVE.getValue());
        contractManagement.setFcmRentPayCycle(ContractRentPaymentCycleEnum.EACH_QUARTER.getValue());
        contractManagement.setFcmBillGenerateType(BillDateTypeEnum.BEFORE.getValue());
        contractManagement.setFcmBillGenerateInterval(2);
        contractManagement.setFcmBillCatoffType(BillDateTypeEnum.FINISHED.getValue());
        contractManagement.setFcmBillCatoffInterval(2);
        contractManagement.setFcmCarnumTotal(5);
        contractManagement.setFcmContractState(ContractStateEnum.LEASED.getState());
        contractManagement.setFcmSettlementState(SettlementStateEnum.OUTSTANDING.getState());
        contractManagementList.add(contractManagement);

        contractManagement = new FncContractManagement();
        contractManagement.setFcmLeaseCount(108);
        date = ContractDateCalculateUtil.formatDay("2021-03-19");
        contractManagement.setFcmLeaseStartDate(date);
        date = ContractDateCalculateUtil.formatDay("2030-03-18");
        contractManagement.setFcmLeaseEndDate(date);
        contractManagement.setFcmId(-1L);
        contractManagement.setFcmLeaseType(ContractLeaseTypeEnum.FIXED.getValue());
        contractManagement.setFcmLeaseAmount(1000D);
        contractManagement.setFcmRentPayType(ContractRentPayTypeEnum.NATURAL.getValue());
        contractManagement.setFcmRentPayCycle(ContractRentPaymentCycleEnum.EACH_QUARTER.getValue());
        contractManagement.setFcmBillGenerateType(BillDateTypeEnum.BEFORE.getValue());
        contractManagement.setFcmBillGenerateInterval(2);
        contractManagement.setFcmBillCatoffType(BillDateTypeEnum.FINISHED.getValue());
        contractManagement.setFcmBillCatoffInterval(2);
        contractManagement.setFcmCarnumTotal(5);
        contractManagement.setFcmContractState(ContractStateEnum.LEASED.getState());
        contractManagement.setFcmSettlementState(SettlementStateEnum.OUTSTANDING.getState());
        contractManagementList.add(contractManagement);

//        when(fncContractManagementService.getByPartyA(-1L)).thenReturn(contractManagementList);
        doReturn(contractManagementList).when(fncContractManagementService).getByPartyA(-1L);
    }

    /**
     * @author Bob
     * @date 2021/12/7
     * @description 准备部门
     */
    private void dataPreparation() {
        List<AuthDept> authDepts = new ArrayList<>();
        AuthDept authDept = new AuthDept();
        authDept.setId(-1L);
        authDept.setDeptName("测试");
        authDepts.add(authDept);
        JsonResult<List<AuthDept>> success = JsonResult.success(authDepts);
//        when(authDeptClient.getAuthDeptByDeptType("auth_type_owner")).thenReturn(success);
        doReturn(success).when(authDeptClient).getAuthDeptByDeptType("auth_type_owner");
    }

}