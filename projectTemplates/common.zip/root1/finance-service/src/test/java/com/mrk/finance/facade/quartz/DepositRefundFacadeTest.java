package com.mrk.finance.facade.quartz;

import com.mrk.common.constant.HttpConstants;
import com.mrk.common.utils.page.JsonResult;
import com.mrk.finance.enums.*;
import com.mrk.finance.model.FncBillManagement;
import com.mrk.finance.model.FncContractManagement;
import com.mrk.finance.provider.FinanceQuartzProvider;
import com.mrk.finance.service.FncBillManagementService;
import com.mrk.finance.service.FncContractManagementService;
import com.mrk.finance.util.contract.ContractDateCalculateUtil;
import com.mrk.universal.enums.contract.ContractTypeEnum;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.test.context.junit.jupiter.SpringExtension;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigDecimal;
import java.util.Date;
import java.util.List;
import java.util.stream.Collectors;

import static org.junit.jupiter.api.Assertions.assertEquals;


@ExtendWith(SpringExtension.class)
@SpringBootTest(webEnvironment = SpringBootTest.WebEnvironment.MOCK)
@ComponentScan(value = {"com.mrk.finance"})
public class DepositRefundFacadeTest {

    @Autowired
    private FinanceQuartzProvider financeQuartzProvider;

    @Autowired
    private FncContractManagementService fncContractManagementService;

    @Autowired
    private FncBillManagementService fncBillManagementService;


    /**
     * @author Bob
     * @date 2021/11/29
     * @description 保证金退还生成
     */
    @Test
    @Transactional(rollbackFor = Exception.class)
    @DisplayName("保证金退还生成")
    public void depositRefundGeneration() {
        // 获取能生成保证金退还的合同
        Long contract = getContract();

        // 获取已经生成了的合同
        Long generateContract = getGenerateContract();

        // 执行定时任务
        JsonResult<Object> jsonResult = financeQuartzProvider.depositRefundGeneration(null);
        assertEquals(HttpConstants.CODE_SUCCESS, jsonResult.getCode());

        // 获取保证金退还账单
        List<FncBillManagement> billManagements = fncBillManagementService.getByContractId(contract);
        List<FncBillManagement> fncBillManagements = billManagements.stream()
                .filter(temp -> BillSubjectsEnum.BOND.getValue().equals(temp.getFbmSubjects())
                        && BigDecimal.valueOf(0).compareTo(BigDecimal.valueOf(temp.getFbmBillAmount())) > 0)
                .collect(Collectors.toList());
        assertEquals(1, fncBillManagements.size());
        FncBillManagement billManagement = fncBillManagements.get(0);
        assertEquals(BigDecimal.valueOf(-10000D), BigDecimal.valueOf(billManagement.getFbmBillAmount()));

        // 检查是否重复生成
        billManagements = fncBillManagementService.getByContractId(generateContract);
        fncBillManagements = billManagements.stream()
                .filter(temp -> BillSubjectsEnum.BOND.getValue().equals(temp.getFbmSubjects())
                        && BigDecimal.valueOf(0).compareTo(BigDecimal.valueOf(temp.getFbmBillAmount())) > 0)
                .collect(Collectors.toList());
        assertEquals(1, fncBillManagements.size());
    }

    /**
     * @author Bob
     * @date 2021/11/29
     * @description 获取生成了保证金退还的账单
     * @return 合同ID
     */
    private Long getGenerateContract() {
        FncContractManagement contractManagement = new FncContractManagement();
        contractManagement.setFcmLeaseCount(8);
        contractManagement.setFcmRentPayType(ContractRentPayTypeEnum.RELATIVE.getValue());
        contractManagement.setFcmContractType(ContractTypeEnum.RENT_FOR_SALE.getType());
        Date date = ContractDateCalculateUtil.formatDay("2021-01-29");
        contractManagement.setFcmLeaseStartDate(date);
        date = ContractDateCalculateUtil.formatDay("2021-09-28");
        contractManagement.setFcmLeaseEndDate(date);
        contractManagement.setFcmRentPayCycle(ContractRentPaymentCycleEnum.EACH_QUARTER.getValue());
        contractManagement.setFcmCarPurchase(50000D);
        contractManagement.setFcmMarginTotal(10000D);
        contractManagement.setFcmContractState(ContractStateEnum.LEASE_TO_END.getState());
        contractManagement.setFcmSettlementState(SettlementStateEnum.OUTSTANDING.getState());
        fncContractManagementService.add(contractManagement);
        Long fcmId = contractManagement.getFcmId();

        // 生成保证金账单
        FncBillManagement fncBillManagement = new FncBillManagement();
        fncBillManagement.setFbmAssociateContractId(fcmId);
        fncBillManagement.setFbmSubjects(BillSubjectsEnum.BOND.getValue());
        fncBillManagement.setFbmBillAmount(10000D);
        fncBillManagementService.add(fncBillManagement);

        // 保证金退还账单
        fncBillManagement = new FncBillManagement();
        fncBillManagement.setFbmAssociateContractId(fcmId);
        fncBillManagement.setFbmSubjects(BillSubjectsEnum.BOND.getValue());
        fncBillManagement.setFbmBillAmount(-10000D);
        fncBillManagementService.add(fncBillManagement);
        return fcmId;
    }

    /**
     * @author Bob
     * @date 2021/11/29
     * @description 获取合同
     * @return 合同id
     */
    private Long getContract() {
        FncContractManagement contractManagement = new FncContractManagement();
        contractManagement.setFcmLeaseCount(8);
        contractManagement.setFcmRentPayType(ContractRentPayTypeEnum.RELATIVE.getValue());
        contractManagement.setFcmContractType(ContractTypeEnum.RENT_FOR_SALE.getType());
        Date date = ContractDateCalculateUtil.formatDay("2021-01-29");
        contractManagement.setFcmLeaseStartDate(date);
        date = ContractDateCalculateUtil.formatDay("2021-09-28");
        contractManagement.setFcmLeaseEndDate(date);
        contractManagement.setFcmRentPayCycle(ContractRentPaymentCycleEnum.EACH_QUARTER.getValue());
        contractManagement.setFcmCarPurchase(50000D);
        contractManagement.setFcmMarginTotal(10000D);
        contractManagement.setFcmContractState(ContractStateEnum.LEASE_TO_END.getState());
        contractManagement.setFcmSettlementState(SettlementStateEnum.OUTSTANDING.getState());
        fncContractManagementService.add(contractManagement);

        // 生成保证金账单
        Long fcmId = contractManagement.getFcmId();
        FncBillManagement fncBillManagement = new FncBillManagement();
        fncBillManagement.setFbmAssociateContractId(fcmId);
        fncBillManagement.setFbmSubjects(BillSubjectsEnum.BOND.getValue());
        fncBillManagement.setFbmBillAmount(10000D);
        fncBillManagementService.add(fncBillManagement);
        return fcmId;
    }
}