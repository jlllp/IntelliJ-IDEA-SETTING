package com.mrk.finance.facade.quartz;

import com.mrk.common.constant.HttpConstants;
import com.mrk.common.utils.page.JsonResult;
import com.mrk.finance.enums.*;
import com.mrk.finance.model.FncBillManagement;
import com.mrk.finance.model.FncContractManagement;
import com.mrk.finance.model.FncContractRent;
import com.mrk.finance.provider.FinanceQuartzProvider;
import com.mrk.finance.service.FncBillManagementService;
import com.mrk.finance.service.FncContractManagementService;
import com.mrk.finance.service.FncContractRentService;
import com.mrk.finance.util.StreamUtil;
import com.mrk.finance.util.contract.ContractDateCalculateUtil;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.test.context.junit.jupiter.SpringExtension;

import java.math.BigDecimal;
import java.util.Date;
import java.util.List;
import java.util.Map;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;


@ExtendWith(SpringExtension.class)
@SpringBootTest(webEnvironment = SpringBootTest.WebEnvironment.MOCK)
@ComponentScan(value = {"com.mrk.finance"})
public class RentBillFacadeTest {

    @Autowired
    private FinanceQuartzProvider financeQuartzProvider;

    @Autowired
    private FncContractManagementService fncContractManagementService;

    @Autowired
    private FncBillManagementService fncBillManagementService;

    @Autowired
    private FncContractRentService fncContractRentService;

    /**
     * @author Bob
     * @date 2021/11/30
     * @description 租金账单生成 定时任务
     */
    @Test
    @DisplayName("租金账单生成 定时任务")
    public void rentBillGeneration() {
        // 相对周期固定租金先赠送
        relativePeriodicFixedRent();
        // 相对周期不固定租金
        relativePeriodicRents();
        // 自然周期固定租金
        naturalCycleFixedRent();
        // 自然周期不固定租金后赠送
        naturalCycleVariableRent();
    }

    /**
     * @author Bob
     * @date 2021/12/2
     * @description 自然周期不固定租金后赠送
     */
    private void naturalCycleVariableRent() {
        // 准备数据
        Long contractId = naturalCycleVariableContract();

        // 执行任务
        JsonResult<Object> jsonResult = financeQuartzProvider.rentBillGeneration(null);
        assertEquals(HttpConstants.CODE_SUCCESS, jsonResult.getCode());

        // 结果检查
        List<FncBillManagement> billManagements = fncBillManagementService.getByContractId(contractId);
        // 17 / 3 = 5 余2
        // 共6个账单  有一个金额为0 不生成
        assertEquals(5, billManagements.size());
        // 验证账单金额
        Map<String, FncBillManagement> billManagementMap = StreamUtil.toMap(billManagements, FncBillManagement::getFbmNper);
        FncBillManagement fncBillManagement = billManagementMap.get("1");
        assertEquals(0, BigDecimal.valueOf(7741.94D).compareTo(BigDecimal.valueOf(fncBillManagement.getFbmBillAmount())));
        fncBillManagement = billManagementMap.get("2");
        assertEquals(0, BigDecimal.valueOf(9600D).compareTo(BigDecimal.valueOf(fncBillManagement.getFbmBillAmount())));
        fncBillManagement = billManagementMap.get("3");
        assertEquals(0, BigDecimal.valueOf(8800D).compareTo(BigDecimal.valueOf(fncBillManagement.getFbmBillAmount())));
        fncBillManagement = billManagementMap.get("4");
        assertEquals(0, BigDecimal.valueOf(8400D).compareTo(BigDecimal.valueOf(fncBillManagement.getFbmBillAmount())));
        fncBillManagement = billManagementMap.get("5");
        assertEquals(0, BigDecimal.valueOf(2800D).compareTo(BigDecimal.valueOf(fncBillManagement.getFbmBillAmount())));

        // 字段校验
        fieldCheck(billManagements);

        // 清理数据
        billManagements.forEach(temp -> fncBillManagementService.delete(temp.getFbmId()));
        List<FncContractRent> fncContractRents = fncContractRentService.getByContractId(contractId);
        fncContractRents.forEach(temp -> fncContractRentService.delete(temp.getFccId()));
        fncContractManagementService.delete(contractId);
    }

    /**
     * @author Bob
     * @date 2021/12/2
     * @description 获取自然周期不固定租金后赠送合同
     * @return 合同ID
     */
    private Long naturalCycleVariableContract() {
        // 租期11个月
        // 租金
        //      1 - 7 : 1600
        //      8 - 13 : 1400
        // 赠送3个月  后赠送
        FncContractManagement contractManagement = new FncContractManagement();
        contractManagement.setFcmLeaseCount(13);
        Date date = ContractDateCalculateUtil.formatDay("2018-03-19");
        contractManagement.setFcmLeaseStartDate(date);
        date = ContractDateCalculateUtil.formatDay("2020-08-18");
        contractManagement.setFcmLeaseEndDate(date);
        contractManagement.setFcmLeaseType(ContractLeaseTypeEnum.NOT_FIXED.getValue());
        contractManagement.setFcmRentPayType(ContractRentPayTypeEnum.NATURAL.getValue());
        contractManagement.setFcmRentPayCycle(ContractRentPaymentCycleEnum.EACH_QUARTER.getValue());
        contractManagement.setFcmBillGenerateType(BillDateTypeEnum.BEFORE.getValue());
        contractManagement.setFcmBillGenerateInterval(2);
        contractManagement.setFcmBillCatoffType(BillDateTypeEnum.FINISHED.getValue());
        contractManagement.setFcmBillCatoffInterval(2);
        contractManagement.setFcmCarnumTotal(2);
        contractManagement.setFcmContractState(ContractStateEnum.LEASED.getState());
        contractManagement.setFcmSettlementState(SettlementStateEnum.OUTSTANDING.getState());
        contractManagement.setFcmGiveLease(3);
        contractManagement.setFcmGiveSequence(ContractGiveSequenceEnum.AFTER.getValue());
        fncContractManagementService.add(contractManagement);
        // 合同id
        Long fcmId = contractManagement.getFcmId();
        // 新增不固定租金
        FncContractRent fncContractRent = new FncContractRent();
        fncContractRent.setFccContractId(fcmId);
        fncContractRent.setFccStartMonth(1);
        fncContractRent.setFccEndMonth(7);
        fncContractRent.setFccRentAmount(1600D);
        fncContractRentService.add(fncContractRent);

        fncContractRent = new FncContractRent();
        fncContractRent.setFccContractId(fcmId);
        fncContractRent.setFccStartMonth(8);
        fncContractRent.setFccEndMonth(13);
        fncContractRent.setFccRentAmount(1400D);
        fncContractRentService.add(fncContractRent);
        return fcmId;
    }

    /**
     * @author Bob
     * @date 2021/12/2
     * @description 自然周期固定租金
     */
    private void naturalCycleFixedRent() {
        // 准备数据
        Long contractId = naturalCycleFixedContract();

        // 执行任务
        JsonResult<Object> jsonResult = financeQuartzProvider.rentBillGeneration(null);
        assertEquals(HttpConstants.CODE_SUCCESS, jsonResult.getCode());

        // 结果检查
        List<FncBillManagement> billManagements = fncBillManagementService.getByContractId(contractId);
        // 17 / 3 = 5 余2
        // 共6个账单  有一个金额为0 不生成
        assertEquals(4, billManagements.size());
        // 验证账单金额
        Map<String, FncBillManagement> billManagementMap = StreamUtil.toMap(billManagements, FncBillManagement::getFbmNper);
        FncBillManagement fncBillManagement = billManagementMap.get("1");
        assertEquals(0, BigDecimal.valueOf(6290.32D).compareTo(BigDecimal.valueOf(fncBillManagement.getFbmBillAmount())));
        fncBillManagement = billManagementMap.get("2");
        assertEquals(0, BigDecimal.valueOf(7800D).compareTo(BigDecimal.valueOf(fncBillManagement.getFbmBillAmount())));
        fncBillManagement = billManagementMap.get("3");
        assertEquals(0, BigDecimal.valueOf(7800D).compareTo(BigDecimal.valueOf(fncBillManagement.getFbmBillAmount())));
        fncBillManagement = billManagementMap.get("4");
        assertEquals(0, BigDecimal.valueOf(5200D).compareTo(BigDecimal.valueOf(fncBillManagement.getFbmBillAmount())));

        // 字段校验
        fieldCheck(billManagements);

        // 清理数据
        billManagements.forEach(temp -> fncBillManagementService.delete(temp.getFbmId()));
        fncContractManagementService.delete(contractId);
    }

    /**
     * @author Bob
     * @date 2021/12/2
     * @description 获取自然周期固定租金合同
     * @return 合同id
     */
    private Long naturalCycleFixedContract() {
        // 租期 11个月
        // 租金1300
        FncContractManagement contractManagement = new FncContractManagement();
        contractManagement.setFcmLeaseCount(11);
        Date date = ContractDateCalculateUtil.formatDay("2018-03-19");
        contractManagement.setFcmLeaseStartDate(date);
        date = ContractDateCalculateUtil.formatDay("2020-08-18");
        contractManagement.setFcmLeaseEndDate(date);
        contractManagement.setFcmLeaseType(ContractLeaseTypeEnum.FIXED.getValue());
        contractManagement.setFcmLeaseAmount(1300D);
        contractManagement.setFcmRentPayType(ContractRentPayTypeEnum.NATURAL.getValue());
        contractManagement.setFcmRentPayCycle(ContractRentPaymentCycleEnum.EACH_QUARTER.getValue());
        contractManagement.setFcmBillGenerateType(BillDateTypeEnum.BEFORE.getValue());
        contractManagement.setFcmBillGenerateInterval(2);
        contractManagement.setFcmBillCatoffType(BillDateTypeEnum.FINISHED.getValue());
        contractManagement.setFcmBillCatoffInterval(2);
        contractManagement.setFcmCarnumTotal(2);
        contractManagement.setFcmContractState(ContractStateEnum.LEASED.getState());
        contractManagement.setFcmSettlementState(SettlementStateEnum.OUTSTANDING.getState());
        fncContractManagementService.add(contractManagement);
        return contractManagement.getFcmId();
    }

    /**
     * @author Bob
     * @date 2021/12/2
     * @description 相对周期不固定租金
     */
    private void relativePeriodicRents() {
        // 准备数据
        Long contractId = relativePeriodicContract();

        // 执行任务
        JsonResult<Object> jsonResult = financeQuartzProvider.rentBillGeneration(null);
        assertEquals(HttpConstants.CODE_SUCCESS, jsonResult.getCode());

        // 结果检查
        List<FncBillManagement> billManagements = fncBillManagementService.getByContractId(contractId);
        // 17 / 3 = 5 余2
        // 共6个账单  有一个金额为0 不生成
        assertEquals(4, billManagements.size());
        // 验证账单金额
        Map<String, FncBillManagement> billManagementMap = StreamUtil.toMap(billManagements, FncBillManagement::getFbmNper);
        FncBillManagement fncBillManagement = billManagementMap.get("1");
        assertEquals(0, BigDecimal.valueOf(9000D).compareTo(BigDecimal.valueOf(fncBillManagement.getFbmBillAmount())));
        fncBillManagement = billManagementMap.get("2");
        assertEquals(0, BigDecimal.valueOf(9000D).compareTo(BigDecimal.valueOf(fncBillManagement.getFbmBillAmount())));
        fncBillManagement = billManagementMap.get("3");
        assertEquals(0, BigDecimal.valueOf(8200D).compareTo(BigDecimal.valueOf(fncBillManagement.getFbmBillAmount())));
        fncBillManagement = billManagementMap.get("4");
        assertEquals(0, BigDecimal.valueOf(5200D).compareTo(BigDecimal.valueOf(fncBillManagement.getFbmBillAmount())));

        // 字段校验
        fieldCheck(billManagements);

        // 清理数据
        billManagements.forEach(temp -> fncBillManagementService.delete(temp.getFbmId()));
        List<FncContractRent> fncContractRents = fncContractRentService.getByContractId(contractId);
        fncContractRents.forEach(temp -> fncContractRentService.delete(temp.getFccId()));
        fncContractManagementService.delete(contractId);
    }

    /**
     * @author Bob
     * @date 2021/12/2
     * @description 获取相对周期不固定租金
     * @return 合同Id
     */
    private Long relativePeriodicContract() {
        // 租期11个月
        // 租金
        //      1 - 7 : 1500
        //      8 - 11 : 1300
        FncContractManagement contractManagement = new FncContractManagement();
        contractManagement.setFcmLeaseCount(11);
        Date date = ContractDateCalculateUtil.formatDay("2018-03-19");
        contractManagement.setFcmLeaseStartDate(date);
        date = ContractDateCalculateUtil.formatDay("2020-08-18");
        contractManagement.setFcmLeaseEndDate(date);
        contractManagement.setFcmLeaseType(ContractLeaseTypeEnum.NOT_FIXED.getValue());
        contractManagement.setFcmRentPayType(ContractRentPayTypeEnum.RELATIVE.getValue());
        contractManagement.setFcmRentPayCycle(ContractRentPaymentCycleEnum.EACH_QUARTER.getValue());
        contractManagement.setFcmBillGenerateType(BillDateTypeEnum.BEFORE.getValue());
        contractManagement.setFcmBillGenerateInterval(2);
        contractManagement.setFcmBillCatoffType(BillDateTypeEnum.FINISHED.getValue());
        contractManagement.setFcmBillCatoffInterval(2);
        contractManagement.setFcmCarnumTotal(2);
        contractManagement.setFcmContractState(ContractStateEnum.LEASED.getState());
        contractManagement.setFcmSettlementState(SettlementStateEnum.OUTSTANDING.getState());
        fncContractManagementService.add(contractManagement);
        // 合同id
        Long fcmId = contractManagement.getFcmId();
        // 新增不固定租金
        FncContractRent fncContractRent = new FncContractRent();
        fncContractRent.setFccContractId(fcmId);
        fncContractRent.setFccStartMonth(1);
        fncContractRent.setFccEndMonth(7);
        fncContractRent.setFccRentAmount(1500D);
        fncContractRentService.add(fncContractRent);

        fncContractRent = new FncContractRent();
        fncContractRent.setFccContractId(fcmId);
        fncContractRent.setFccStartMonth(8);
        fncContractRent.setFccEndMonth(11);
        fncContractRent.setFccRentAmount(1300D);
        fncContractRentService.add(fncContractRent);
        return fcmId;
    }

    /**
     * @author Bob
     * @date 2021/11/30
     * @description 相对周期固定租金先赠送
     */
    private void relativePeriodicFixedRent() {
        // 准备数据
        Long contractId = relativePeriodicFixedContract();

        // 执行任务
        JsonResult<Object> jsonResult = financeQuartzProvider.rentBillGeneration(null);
        assertEquals(HttpConstants.CODE_SUCCESS, jsonResult.getCode());

        // 结果检查
        List<FncBillManagement> billManagements = fncBillManagementService.getByContractId(contractId);
        // 17 / 3 = 5 余2
        // 共6个账单  有一个金额为0 不生成
        assertEquals(5, billManagements.size());
        // 验证账单金额
        Map<String, FncBillManagement> billManagementMap = StreamUtil.toMap(billManagements, FncBillManagement::getFbmNper);
        FncBillManagement fncBillManagement = billManagementMap.get("2");
        assertEquals(0, BigDecimal.valueOf(1776D).compareTo(BigDecimal.valueOf(fncBillManagement.getFbmBillAmount())));
        fncBillManagement = billManagementMap.get("3");
        assertEquals(0, BigDecimal.valueOf(5328D).compareTo(BigDecimal.valueOf(fncBillManagement.getFbmBillAmount())));
        fncBillManagement = billManagementMap.get("4");
        assertEquals(0, BigDecimal.valueOf(5328D).compareTo(BigDecimal.valueOf(fncBillManagement.getFbmBillAmount())));
        fncBillManagement = billManagementMap.get("5");
        assertEquals(0, BigDecimal.valueOf(5328D).compareTo(BigDecimal.valueOf(fncBillManagement.getFbmBillAmount())));
        fncBillManagement = billManagementMap.get("6");
        assertEquals(0, BigDecimal.valueOf(3552D).compareTo(BigDecimal.valueOf(fncBillManagement.getFbmBillAmount())));

        // 字段校验
        fieldCheck(billManagements);
        // 清理数据
        billManagements.forEach(temp -> fncBillManagementService.delete(temp.getFbmId()));
        fncContractManagementService.delete(contractId);
    }

    /**
     * @author Bob
     * @date 2021/12/2
     * @description 检查合同生成的账单字段是否都有属性
     * @param billManagements 账单
     */
    private void fieldCheck(List<FncBillManagement> billManagements) {
        for (FncBillManagement billManagement : billManagements) {
            assertNotNull(billManagement.getFbmBillAmount());
            assertNotNull(billManagement.getFbmMatchedAmount());
            assertNotNull(billManagement.getFbmNotMatchAmount());
            assertNotNull(billManagement.getFbmBillState());
            assertNotNull(billManagement.getFbmSubjects());
            assertNotNull(billManagement.getFbmNper());
            assertNotNull(billManagement.getFbmBillGenerateTime());
            assertNotNull(billManagement.getFbmBillGenerateWay());
            assertNotNull(billManagement.getFbmBillCatoffTime());
            assertNotNull(billManagement.getFbmAssociateContractId()
            );
        }
    }

    /**
     * @author Bob
     * @date 2021/11/30
     * @description 相对周期固定租金
     * @return 合同ID
     */
    private Long relativePeriodicFixedContract() {
        // 赠送5个月
        // 先赠送
        // 租金888
        FncContractManagement contractManagement = new FncContractManagement();
        contractManagement.setFcmLeaseCount(12);
        Date date = ContractDateCalculateUtil.formatDay("2018-03-19");
        contractManagement.setFcmLeaseStartDate(date);
        date = ContractDateCalculateUtil.formatDay("2020-08-18");
        contractManagement.setFcmLeaseEndDate(date);
        contractManagement.setFcmLeaseType(ContractLeaseTypeEnum.FIXED.getValue());
        contractManagement.setFcmLeaseAmount(888D);
        contractManagement.setFcmRentPayType(ContractRentPayTypeEnum.RELATIVE.getValue());
        contractManagement.setFcmRentPayCycle(ContractRentPaymentCycleEnum.EACH_QUARTER.getValue());
        contractManagement.setFcmGiveLease(5);
        contractManagement.setFcmGiveSequence(ContractGiveSequenceEnum.BEFORE.getValue());
        contractManagement.setFcmBillGenerateType(BillDateTypeEnum.BEFORE.getValue());
        contractManagement.setFcmBillGenerateInterval(2);
        contractManagement.setFcmBillCatoffType(BillDateTypeEnum.FINISHED.getValue());
        contractManagement.setFcmBillCatoffInterval(2);
        contractManagement.setFcmCarnumTotal(2);
        contractManagement.setFcmContractState(ContractStateEnum.LEASED.getState());
        contractManagement.setFcmSettlementState(SettlementStateEnum.OUTSTANDING.getState());
        fncContractManagementService.add(contractManagement);
        return contractManagement.getFcmId();
    }
}