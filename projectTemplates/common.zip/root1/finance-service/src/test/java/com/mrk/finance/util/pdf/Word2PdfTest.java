package com.mrk.finance.util.pdf;

import cn.afterturn.easypoi.word.WordExportUtil;
import com.mrk.finance.util.PdfUtils;
import org.apache.poi.xwpf.usermodel.XWPFDocument;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.test.context.junit.jupiter.SpringExtension;

import java.io.FileOutputStream;
import java.util.HashMap;
import java.util.Map;

/**
 * @author jlllp
 * @date 2022/6/9
 * @description
 */
@ExtendWith(SpringExtension.class)
@SpringBootTest(webEnvironment = SpringBootTest.WebEnvironment.DEFINED_PORT)
@ComponentScan(value = {"com.mrk.workflow"})
class Word2PdfTest {


    @Test
    @DisplayName("word转pdf")
    void word2PdfTest() throws Exception {
        Map<String, Object> map = new HashMap<>();
        map.put("contractNumber", "Easypoi1□ ■ √");
        map.put("aTaxpayerNumber", "Easypoi1□ ■ √");
        map.put("aRepresentative", "Easypoi1□ ■ √");
        map.put("aContact", "Easypoi1□ ■ √");
        map.put("aEmail", "Easypoi1□ ■ √");
        XWPFDocument doc = WordExportUtil.exportWord07("docx/车联科技车辆租赁合同模板（20220401）.docx", map);
        FileOutputStream fileOutputStream = new FileOutputStream("C:\\Users\\jlllp\\Downloads\\模拟合同.pdf");
        PdfUtils.docx2Pdf(doc, fileOutputStream);
        Assertions.assertNotNull(map, "不能为空");
    }
}
