package com.mrk.finance.controller.common;

import com.github.pagehelper.PageInfo;
import com.mrk.finance.dto.common.DeptOrMemberInfoDto;
import com.mrk.finance.facade.common.DeptOrMemberFacade;
import org.apache.commons.collections4.CollectionUtils;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit.jupiter.SpringExtension;

import java.util.List;

import static org.junit.jupiter.api.Assertions.assertNotEquals;

@ExtendWith(SpringExtension.class)
@SpringBootTest
class DeptOrMemberControllerTest {

    private static final Logger log = LoggerFactory.getLogger(DeptOrMemberControllerTest.class);

    @Autowired
    private DeptOrMemberFacade deptOrMemberFacade;

    @Test
    @DisplayName("通过类型和名称查询组织或会员")
    void getInfoByTypeAndName() {
        // 个人查询
        log.info("执行个人查询");
        executeQuery(1);

        // 组织查询
        log.info("执行组织查询");
        executeQuery(2);
    }

    /**
     * @param i 0个人 1组织
     * @author Bob
     * @date 2021/11/18
     * @description 测试查询结果是否预期
     */
    private void executeQuery(int i) {
        // 查询
        PageInfo<DeptOrMemberInfoDto> deptOrMemberInfoDtoPageInfo = deptOrMemberFacade.getInfoByTypeAndName(i, null,null);
        log.info("不使用名称查询获取到内容 --> total：【{}】", deptOrMemberInfoDtoPageInfo.getTotal());
        List<DeptOrMemberInfoDto> list = deptOrMemberInfoDtoPageInfo.getList();
        // 随机获取2个字符作为名称查询
        if (CollectionUtils.isNotEmpty(list)) {
            log.info("不使用名称查询获取到内容 --> listSize：【{}】", list.size());
            String nameLike = null;
            for (DeptOrMemberInfoDto deptOrMemberInfoDto : list) {
                String name = deptOrMemberInfoDto.getName();
                if (null != name && name.length() > 2) {
                    nameLike = name.substring(name.length() - 2);
                    break;
                }
            }

            // 名称模糊查询
            if (null != nameLike) {
                log.info("获取到模糊查询数据内容 --> nameLike：【{}】", nameLike);
                deptOrMemberInfoDtoPageInfo = deptOrMemberFacade.getInfoByTypeAndName(i, nameLike,null);
                log.info("名称查询获取到内容 --> total：【{}】", deptOrMemberInfoDtoPageInfo.getTotal());
                assertNotEquals(0L, deptOrMemberInfoDtoPageInfo.getTotal(), "名称模糊查询数量不可能为");

                // 集合中的内容判断
                list = deptOrMemberInfoDtoPageInfo.getList();
                log.info("名称查询获取到内容 --> listSize：【{}】", list.size());
                assertNotEquals(null, list, "集合不能为空");

                // 内容判断
                for (DeptOrMemberInfoDto deptOrMemberInfoDto : list) {
                    String name = deptOrMemberInfoDto.getName();
                    log.info("名称查询获取到内容 检查名称 --> name：【{}】", name);
                    assertNotEquals(null, name, "名称不可能为空");
                    i = name.indexOf(nameLike);
                    assertNotEquals(-1, i, "名称未模糊匹配成功");
                }
            }

        }
    }
}
