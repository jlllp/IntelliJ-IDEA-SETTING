package com.mrk.finance.facade.quartz;

import com.mrk.common.constant.HttpConstants;
import com.mrk.common.utils.page.JsonResult;
import com.mrk.finance.enums.*;
import com.mrk.finance.model.FncBillManagement;
import com.mrk.finance.model.FncContractManagement;
import com.mrk.finance.provider.FinanceQuartzProvider;
import com.mrk.finance.service.FncBillManagementService;
import com.mrk.finance.service.FncContractManagementService;
import com.mrk.finance.util.contract.ContractDateCalculateUtil;
import com.mrk.universal.enums.contract.ContractTypeEnum;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.test.context.junit.jupiter.SpringExtension;

import java.math.BigDecimal;
import java.util.Date;
import java.util.List;
import java.util.stream.Collectors;

import static org.junit.jupiter.api.Assertions.assertEquals;


@ExtendWith(SpringExtension.class)
@SpringBootTest(webEnvironment = SpringBootTest.WebEnvironment.MOCK)
@ComponentScan(value = {"com.mrk.finance"})
public class CarPurchaseBalanceFacadeTest {

    @Autowired
    private FinanceQuartzProvider financeQuartzProvider;

    @Autowired
    private FncContractManagementService fncContractManagementService;

    @Autowired
    private FncBillManagementService fncBillManagementService;

    /**
     * @author Bob
     * @date 2021/11/29
     * @description 购车尾款生成定时任务
     */
    @Test
    @DisplayName("购车尾款生成定时任务")
    public void carPurchaseBalanceGeneration() {
        // 自然周期
        Long naturalContract = naturalContract();
        // 相对周期
        Long relativelyContract = relativelyContract();
        // 不生成
        Long doesNotGenerate = doesNotGenerate();
        // 方法执行完成
        JsonResult<Object> jsonResult = financeQuartzProvider.carPurchaseBalanceGeneration(null);
        assertEquals(HttpConstants.CODE_SUCCESS, jsonResult.getCode());

        // 自然周期
        List<FncBillManagement> fncBillManagementList = fncBillManagementService.getByContractId(naturalContract);
        // 清理账单
        fncBillManagementList.forEach(temp -> fncBillManagementService.delete(temp.getFbmId()));
        List<FncBillManagement> fncBillManagements = fncBillManagementList.stream().filter(temp -> BillSubjectsEnum.BALANCE.getValue().equals(temp.getFbmSubjects())).collect(Collectors.toList());
        assertEquals(1, fncBillManagements.size());
        FncBillManagement billManagement = fncBillManagements.get(0);
        // 开始 结束 时间
        Date start = ContractDateCalculateUtil.formatDay("2021-07-01");
        Date end = ContractDateCalculateUtil.formatDay("2021-08-31");
        assertEquals(start, billManagement.getFbmBillGenerateTime());
        assertEquals(end, billManagement.getFbmBillCatoffTime());
        // 金额
        assertEquals(BigDecimal.valueOf(50000D), BigDecimal.valueOf(billManagement.getFbmBillAmount()));

        // 相对周期
        fncBillManagementList = fncBillManagementService.getByContractId(relativelyContract);
        // 清理账单
        fncBillManagementList.forEach(temp -> fncBillManagementService.delete(temp.getFbmId()));
        fncBillManagements = fncBillManagementList.stream().filter(temp -> BillSubjectsEnum.BALANCE.getValue().equals(temp.getFbmSubjects())).collect(Collectors.toList());
        assertEquals(1, fncBillManagements.size());
        billManagement = fncBillManagements.get(0);
        // 开始 结束 时间
        start = ContractDateCalculateUtil.formatDay("2021-07-29");
        end = ContractDateCalculateUtil.formatDay("2021-09-28");
        assertEquals(start, billManagement.getFbmBillGenerateTime());
        assertEquals(end, billManagement.getFbmBillCatoffTime());
        // 金额
        assertEquals(BigDecimal.valueOf(60000D), BigDecimal.valueOf(billManagement.getFbmBillAmount()));

        // 不生成
        fncBillManagementList = fncBillManagementService.getByContractId(doesNotGenerate);
        fncBillManagements = fncBillManagementList.stream().filter(temp -> BillSubjectsEnum.BALANCE.getValue().equals(temp.getFbmSubjects())).collect(Collectors.toList());
        assertEquals(0, fncBillManagements.size());

        // 清理合同
        fncContractManagementService.delete(naturalContract);
        fncContractManagementService.delete(relativelyContract);
        fncContractManagementService.delete(doesNotGenerate);
    }

    /**
     * @author Bob
     * @date 2021/11/29
     * @description 不生成购车尾款的账单
     * @return 合同ID
     */
    private Long doesNotGenerate() {
        FncContractManagement contractManagement = new FncContractManagement();
        contractManagement.setFcmLeaseCount(8);
        contractManagement.setFcmRentPayType(ContractRentPayTypeEnum.RELATIVE.getValue());
        contractManagement.setFcmContractType(ContractTypeEnum.RENT_FOR_SALE.getType());
        Date date = ContractDateCalculateUtil.formatDay("2051-01-29");
        contractManagement.setFcmLeaseStartDate(date);
        date = ContractDateCalculateUtil.formatDay("2051-09-28");
        contractManagement.setFcmLeaseEndDate(date);
        contractManagement.setFcmRentPayCycle(ContractRentPaymentCycleEnum.EACH_QUARTER.getValue());
        contractManagement.setFcmCarPurchase(50000D);
        contractManagement.setFcmContractState(ContractStateEnum.LEASED.getState());
        contractManagement.setFcmSettlementState(SettlementStateEnum.OUTSTANDING.getState());
        fncContractManagementService.add(contractManagement);
        return contractManagement.getFcmId();
    }

    /**
     * @author Bob
     * @date 2021/11/29
     * @description 创建相对周期合同
     * @return 合同ID
     */
    private Long relativelyContract() {
        FncContractManagement contractManagement = new FncContractManagement();
        contractManagement.setFcmLeaseCount(8);
        contractManagement.setFcmRentPayType(ContractRentPayTypeEnum.RELATIVE.getValue());
        contractManagement.setFcmContractType(ContractTypeEnum.RENT_FOR_SALE.getType());
        Date date = ContractDateCalculateUtil.formatDay("2021-01-29");
        contractManagement.setFcmLeaseStartDate(date);
        date = ContractDateCalculateUtil.formatDay("2021-09-28");
        contractManagement.setFcmLeaseEndDate(date);
        contractManagement.setFcmRentPayCycle(ContractRentPaymentCycleEnum.EACH_QUARTER.getValue());
        contractManagement.setFcmCarPurchase(60000D);
        contractManagement.setFcmContractState(ContractStateEnum.LEASED.getState());
        contractManagement.setFcmSettlementState(SettlementStateEnum.OUTSTANDING.getState());
        fncContractManagementService.add(contractManagement);
        return contractManagement.getFcmId();
    }

    /**
     * @author Bob
     * @date 2021/11/29
     * @description 创建自然周期合同
     * @return 合同ID
     */
    private Long naturalContract() {
        FncContractManagement contractManagement = new FncContractManagement();
        contractManagement.setFcmLeaseCount(8);
        contractManagement.setFcmRentPayType(ContractRentPayTypeEnum.NATURAL.getValue());
        contractManagement.setFcmContractType(ContractTypeEnum.RENT_FOR_SALE.getType());
        Date date = ContractDateCalculateUtil.formatDay("2021-01-29");
        contractManagement.setFcmLeaseStartDate(date);
        date = ContractDateCalculateUtil.formatDay("2021-08-31");
        contractManagement.setFcmLeaseEndDate(date);
        contractManagement.setFcmRentPayCycle(ContractRentPaymentCycleEnum.EACH_QUARTER.getValue());
        contractManagement.setFcmCarPurchase(50000D);
        contractManagement.setFcmContractState(ContractStateEnum.LEASED.getState());
        contractManagement.setFcmSettlementState(SettlementStateEnum.OUTSTANDING.getState());
        fncContractManagementService.add(contractManagement);
        return contractManagement.getFcmId();
    }

}