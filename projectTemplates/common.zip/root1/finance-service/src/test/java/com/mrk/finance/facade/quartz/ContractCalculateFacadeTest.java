package com.mrk.finance.facade.quartz;

import com.mrk.common.constant.HttpConstants;
import com.mrk.common.utils.page.JsonResult;
import com.mrk.finance.enums.BillStateEnum;
import com.mrk.finance.enums.ContractStateEnum;
import com.mrk.finance.enums.SettlementStateEnum;
import com.mrk.finance.model.FncBillManagement;
import com.mrk.finance.model.FncContractManagement;
import com.mrk.finance.provider.FinanceQuartzProvider;
import com.mrk.finance.service.FncBillManagementService;
import com.mrk.finance.service.FncContractManagementService;
import com.mrk.finance.util.contract.ContractDateCalculateUtil;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.SpyBean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.test.annotation.DirtiesContext;
import org.springframework.test.context.junit.jupiter.SpringExtension;
import org.springframework.transaction.annotation.Transactional;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.List;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.doReturn;

/**
 * @author Bob
 * @date 2021-11-12
 * @description
 */
@ExtendWith(SpringExtension.class)
@SpringBootTest(webEnvironment = SpringBootTest.WebEnvironment.MOCK)
@ComponentScan(value = {"com.mrk.finance"})
public class ContractCalculateFacadeTest {

    @Autowired
    @InjectMocks
    private FinanceQuartzProvider financeQuartzProvider;

    @SpyBean
    private FncContractManagementService fncContractManagementService;

    @Autowired
    private FncBillManagementService fncBillManagementService;

    /**
     * @author Bob
     * @date 2021/11/29
     * @description 测试 多线程
     */
    @Test
    @DisplayName("测试 多线程")
    public void calculateSettlementStateTest() {
        List<FncContractManagement> mockFncContractManagements = getFncContractManagements();
        Date nowDay = ContractDateCalculateUtil.ignoreHoursMinutesAndSeconds(new Date());
        Date twoDaysAgo = ContractDateCalculateUtil.increaseDay(nowDay, -2);
        doReturn(mockFncContractManagements).when(fncContractManagementService).getStateInAndSettlementAndEndLTOE(Arrays.asList(ContractStateEnum.LEASE_TO_END.getState(),
                ContractStateEnum.LEASE_SUSPENSION.getState()), SettlementStateEnum.OUTSTANDING.getState(), twoDaysAgo);
        JsonResult<Object> jsonResult = financeQuartzProvider.calculateSettlementState(null);
        assertEquals(HttpConstants.CODE_SUCCESS, jsonResult.getCode());
    }

    /**
     * @author Bob
     * @date 2021/11/29
     * @description 测试 计算合同状态
     */
    @Test
    @Transactional()
    @DisplayName("计算合同状态")
    public void calculateContractState() {
        // 获取新增的租赁开始合同id
        Long leaseStartId = addLeaseStartContract();
        // 获取新增的租赁结束合同id
        Long endContractId = addLeaseEndContract();
        JsonResult<Object> jsonResult = financeQuartzProvider.calculateContractState(null);
        assertEquals(HttpConstants.CODE_SUCCESS, jsonResult.getCode());
        FncContractManagement contractManagement = fncContractManagementService.getById(leaseStartId);
        assertEquals(ContractStateEnum.LEASED.getState(), contractManagement.getFcmContractState());
        contractManagement = fncContractManagementService.getById(endContractId);
        assertEquals(ContractStateEnum.LEASE_TO_END.getState(), contractManagement.getFcmContractState());
    }

    /**
     * @author Bob
     * @date 2021/11/29
     * @description 测试 计算结算状态
     *              使用了多线程导致无法自动回滚
     */
    @Test
    @DirtiesContext
    @DisplayName("计算结算状态")
    public void calculateSettlementState() {
        // 获取已经请状态的合同
        Long settledContract = getSettledContract();
        // 获取未结清状态的合同
        Long noSettledContract = getNoSettledContract();
        JsonResult<Object> jsonResult = financeQuartzProvider.calculateSettlementState(null);
        assertEquals(HttpConstants.CODE_SUCCESS, jsonResult.getCode());

        // 检查已经请
        FncContractManagement contractManagement = fncContractManagementService.getById(settledContract);
        assertEquals(SettlementStateEnum.CLEARED.getState(), contractManagement.getFcmSettlementState());

        // 检查未结清
        contractManagement = fncContractManagementService.getById(noSettledContract);
        assertEquals(SettlementStateEnum.OUTSTANDING.getState(), contractManagement.getFcmSettlementState());

        // 清理数据

        // 账单数据
        List<FncBillManagement> fncBillManagementList = fncBillManagementService.getByContractId(settledContract);
        fncBillManagementList.forEach(temp -> fncBillManagementService.delete(temp.getFbmId()));
        fncBillManagementList = fncBillManagementService.getByContractId(noSettledContract);
        fncBillManagementList.forEach(temp -> fncBillManagementService.delete(temp.getFbmId()));

        // 合同数据
        fncContractManagementService.delete(settledContract);
        fncContractManagementService.delete(noSettledContract);
    }

    /**
     * @author Bob
     * @date 2021/11/29
     * @description 获取用于计算的合同
     * @return 合同
     */
    private List<FncContractManagement> getFncContractManagements() {
        List<FncContractManagement> contractManagementList = new ArrayList<>();
        for (int i = 0; i < 100; i++) {
            FncContractManagement fncContractManagement = new FncContractManagement();
            fncContractManagement.setFcmId(i + 1L);
            contractManagementList.add(fncContractManagement);
        }
        return contractManagementList;
    }

    /**
     * @author Bob
     * @date 2021/11/29
     * @description 获取新增的租赁开始合同id
     * @return 合同id
     */
    private Long addLeaseStartContract() {
        FncContractManagement fncContractManagement = new FncContractManagement();
        // 设置租赁状态
        fncContractManagement.setFcmContractState(ContractStateEnum.LEASE_TO_START.getState());
        // 设置合同开始时间为今天
        Date date = ContractDateCalculateUtil.ignoreHoursMinutesAndSeconds(new Date());
        fncContractManagement.setFcmLeaseStartDate(date);
        fncContractManagementService.add(fncContractManagement);
        return fncContractManagement.getFcmId();
    }

    /**
     * @author Bob
     * @date 2021/11/29
     * @description 获取新增的租赁结束合同id
     * @return 合同id
     */
    private Long addLeaseEndContract() {
        FncContractManagement fncContractManagement = new FncContractManagement();
        // 设置租赁状态
        fncContractManagement.setFcmContractState(ContractStateEnum.LEASED.getState());
        // 设置合同开始时间为今天
        Date date = ContractDateCalculateUtil.ignoreHoursMinutesAndSeconds(new Date());
        Date increaseDay = ContractDateCalculateUtil.increaseDay(date, -1);
        fncContractManagement.setFcmLeaseEndDate(increaseDay);
        fncContractManagementService.add(fncContractManagement);
        return fncContractManagement.getFcmId();
    }

    /**
     * @author Bob
     * @date 2021/11/29
     * @description 获取未结清状态的合同
     * @return 合同id
     */
    private Long getNoSettledContract() {
        // 创建合同
        FncContractManagement fncContractManagement = new FncContractManagement();
        // 设置租赁状态
        fncContractManagement.setFcmContractState(ContractStateEnum.LEASE_TO_END.getState());
        // 设置结算状态
        fncContractManagement.setFcmSettlementState(SettlementStateEnum.OUTSTANDING.getState());
        // 设置合同开始时间为两天前
        Date nowDay = ContractDateCalculateUtil.ignoreHoursMinutesAndSeconds(new Date());
        Date twoDaysAgo = ContractDateCalculateUtil.increaseDay(nowDay, -2);
        Date date = ContractDateCalculateUtil.ignoreHoursMinutesAndSeconds(twoDaysAgo);
        fncContractManagement.setFcmLeaseEndDate(date);
        fncContractManagementService.add(fncContractManagement);
        Long fcmId = fncContractManagement.getFcmId();

        // 创建账单 已支付状态
        FncBillManagement fncBillManagement = new FncBillManagement();
        fncBillManagement.setFbmAssociateContractId(fcmId);
        fncBillManagement.setFbmBillState(BillStateEnum.UNPAID.getValue());
        fncBillManagementService.add(fncBillManagement);

        fncBillManagement = new FncBillManagement();
        fncBillManagement.setFbmAssociateContractId(fcmId);
        fncBillManagement.setFbmBillState(BillStateEnum.PAID_PART.getValue());
        fncBillManagementService.add(fncBillManagement);

        return fcmId;
    }

    /**
     * @author Bob
     * @date 2021/11/29
     * @description 获取已结清状态的合同
     * @return 合同id
     */
    private Long getSettledContract() {
        // 创建合同
        FncContractManagement fncContractManagement = new FncContractManagement();
        // 设置租赁状态
        fncContractManagement.setFcmContractState(ContractStateEnum.LEASE_TO_END.getState());
        // 设置结算状态
        fncContractManagement.setFcmSettlementState(SettlementStateEnum.OUTSTANDING.getState());
        // 设置合同开始时间为两天前
        Date nowDay = ContractDateCalculateUtil.ignoreHoursMinutesAndSeconds(new Date());
        Date twoDaysAgo = ContractDateCalculateUtil.increaseDay(nowDay, -2);
        Date date = ContractDateCalculateUtil.ignoreHoursMinutesAndSeconds(twoDaysAgo);
        fncContractManagement.setFcmLeaseEndDate(date);
        fncContractManagementService.add(fncContractManagement);
        Long fcmId = fncContractManagement.getFcmId();

        // 创建账单 已支付状态
        FncBillManagement fncBillManagement = new FncBillManagement();
        fncBillManagement.setFbmAssociateContractId(fcmId);
        fncBillManagement.setFbmBillState(BillStateEnum.PAID_ALL.getValue());
        fncBillManagementService.add(fncBillManagement);

        fncBillManagement = new FncBillManagement();
        fncBillManagement.setFbmAssociateContractId(fcmId);
        fncBillManagement.setFbmBillState(BillStateEnum.INVOICING.getValue());
        fncBillManagementService.add(fncBillManagement);

        fncBillManagement = new FncBillManagement();
        fncBillManagement.setFbmAssociateContractId(fcmId);
        fncBillManagement.setFbmBillState(BillStateEnum.INVOICED.getValue());
        fncBillManagementService.add(fncBillManagement);
        return fcmId;
    }
}
