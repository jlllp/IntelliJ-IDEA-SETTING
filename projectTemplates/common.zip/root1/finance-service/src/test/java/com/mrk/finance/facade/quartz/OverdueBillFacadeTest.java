package com.mrk.finance.facade.quartz;

import com.mrk.common.constant.HttpConstants;
import com.mrk.common.utils.page.JsonResult;
import com.mrk.finance.enums.BillStateEnum;
import com.mrk.finance.model.FncBillManagement;
import com.mrk.finance.provider.FinanceQuartzProvider;
import com.mrk.finance.service.FncBillManagementService;
import com.mrk.finance.util.contract.ContractDateCalculateUtil;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.test.context.junit.jupiter.SpringExtension;
import org.springframework.transaction.annotation.Transactional;

import java.util.Date;

import static org.junit.jupiter.api.Assertions.assertEquals;


@ExtendWith(SpringExtension.class)
@SpringBootTest(webEnvironment = SpringBootTest.WebEnvironment.MOCK)
@ComponentScan(value = {"com.mrk.finance"})
public class OverdueBillFacadeTest {


    @Autowired
    private FinanceQuartzProvider financeQuartzProvider;

    @Autowired
    private FncBillManagementService fncBillManagementService;

    /**
     * @author Bob
     * @date 2021/11/30
     * @description 账单过期处理 定时任务
     */
    @Test
    @Transactional
    @DisplayName("账单过期处理 定时任务")
    public void overdueBillCheck() {
        // 获取逾期账单
        Long overdueBill = getOverdueBill();
        // 获取未逾期账单
        Long noOverdueBill = getNoOverdueBill();
        // 获取已支付账单
        Long paidBills = getPaidBills();
        // 获取逾期部分支付账单
        Long partialPayment = getPartialPayment();

        // 执行任务
        JsonResult<Object> jsonResult = financeQuartzProvider.overdueBillCheck(null);
        assertEquals(HttpConstants.CODE_SUCCESS, jsonResult.getCode());

        // 校验数据
        FncBillManagement billManagement = fncBillManagementService.getById(overdueBill);
        assertEquals(BillStateEnum.OVERDUE.getValue(), billManagement.getFbmBillState());

        billManagement = fncBillManagementService.getById(noOverdueBill);
        assertEquals(BillStateEnum.UNPAID.getValue(), billManagement.getFbmBillState());

        billManagement = fncBillManagementService.getById(paidBills);
        assertEquals(BillStateEnum.PAID_ALL.getValue(), billManagement.getFbmBillState());

        billManagement = fncBillManagementService.getById(partialPayment);
        assertEquals(BillStateEnum.OVERDUE.getValue(), billManagement.getFbmBillState());
    }

    private Long getPartialPayment() {
        FncBillManagement fncBillManagement = new FncBillManagement();
        Date date = ContractDateCalculateUtil.formatDay("2021-06-20");
        fncBillManagement.setFbmBillGenerateTime(date);
        date = ContractDateCalculateUtil.formatDay("2021-07-20");
        fncBillManagement.setFbmBillCatoffTime(date);
        fncBillManagement.setFbmBillState(BillStateEnum.PAID_PART.getValue());
        fncBillManagementService.add(fncBillManagement);
        return fncBillManagement.getFbmId();
    }

    /**
     * @author Bob
     * @date 2021/11/30
     * @description 获取已支付账单
     * @return 账单id
     */
    private Long getPaidBills() {
        FncBillManagement fncBillManagement = new FncBillManagement();
        Date date = ContractDateCalculateUtil.formatDay("2021-06-20");
        fncBillManagement.setFbmBillGenerateTime(date);
        date = ContractDateCalculateUtil.formatDay("2021-07-20");
        fncBillManagement.setFbmBillCatoffTime(date);
        fncBillManagement.setFbmBillState(BillStateEnum.PAID_ALL.getValue());
        fncBillManagementService.add(fncBillManagement);
        return fncBillManagement.getFbmId();
    }

    /**
     * @author Bob
     * @date 2021/11/30
     * @description 获取未支付不逾期账单
     * @return 账单ID
     */
    private Long getNoOverdueBill() {
        FncBillManagement fncBillManagement = new FncBillManagement();
        Date date = ContractDateCalculateUtil.formatDay("2021-06-20");
        fncBillManagement.setFbmBillGenerateTime(date);
        date = ContractDateCalculateUtil.formatDay("2031-07-20");
        fncBillManagement.setFbmBillCatoffTime(date);
        fncBillManagement.setFbmBillState(BillStateEnum.UNPAID.getValue());
        fncBillManagementService.add(fncBillManagement);
        return fncBillManagement.getFbmId();
    }

    /**
     * @author Bob
     * @date 2021/11/30
     * @description 获取过期的账单ID
     * @return 账单ID
     */
    private Long getOverdueBill() {
        FncBillManagement fncBillManagement = new FncBillManagement();
        Date date = ContractDateCalculateUtil.formatDay("2021-06-20");
        fncBillManagement.setFbmBillGenerateTime(date);
        date = ContractDateCalculateUtil.formatDay("2021-07-20");
        fncBillManagement.setFbmBillCatoffTime(date);
        fncBillManagement.setFbmBillState(BillStateEnum.UNPAID.getValue());
        fncBillManagementService.add(fncBillManagement);
        return fncBillManagement.getFbmId();
    }
}