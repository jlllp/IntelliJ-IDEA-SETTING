package com.mrk.finance.facade.contract;

import com.mrk.finance.dto.contract.RentCalculationDto;
import com.mrk.finance.dto.contract.RentTimeRightDto;
import com.mrk.finance.enums.ContractLeaseTypeEnum;
import com.mrk.finance.enums.ContractRentPayTypeEnum;
import com.mrk.finance.enums.ContractRentPaymentCycleEnum;
import com.mrk.finance.util.contract.ContractDateCalculateUtil;
import org.apache.commons.collections4.MapUtils;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.test.context.junit.jupiter.SpringExtension;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.SortedMap;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertTrue;


@ExtendWith(SpringExtension.class)
@SpringBootTest(webEnvironment = SpringBootTest.WebEnvironment.MOCK)
@ComponentScan(value = {"com.mrk.finance"})
public class ContractFacadeTest {

    @Autowired
    private ContractFacade contractFacade;

    /**
     * @author Bob
     * @date 2021/11/30
     * @description 测试租金计算
     */
    @Test
    @DisplayName("测试租金计算")
    public void getRent() {
        // 固定相对合同计算
        fixedRelativeContract();

        // 不固定相对合同计算
        unfixedRelativeContract();

        // 固定自然合同计算
        fixedNaturalContract();

        // 不固定自然合同计算
        unfixedNaturalContract();
    }

    /**
     * @author Bob
     * @date 2021/11/30
     * @description 不固定自然合同计算
     */
    private void unfixedNaturalContract() {
        // 获取不固定自然合同
        RentCalculationDto rentCalculationDto = getUnfixedNatural();
        SortedMap<Integer, RentTimeRightDto> rent = contractFacade.getRent(rentCalculationDto);
        // 集合不能为空
        assertTrue(MapUtils.isNotEmpty(rent));
        // 获取总金额
        BigDecimal total = rent.values().stream().map(RentTimeRightDto::getAmount).map(BigDecimal::valueOf).reduce(BigDecimal::add).orElse(BigDecimal.ZERO);
        assertEquals(0, BigDecimal.valueOf(12932.48D).compareTo(total));
    }

    /**
     * @author Bob
     * @date 2021/11/30
     * @description 获取不固定自然合同
     * @return 合同
     */
    private RentCalculationDto getUnfixedNatural() {
        RentCalculationDto rentCalculationDto = new RentCalculationDto();
        rentCalculationDto.setFcmLeaseCount(13);
        Date date = ContractDateCalculateUtil.formatDay("2021-12-03");
        rentCalculationDto.setFcmLeaseStartDate(date);
        rentCalculationDto.setFcmLeaseType(ContractLeaseTypeEnum.NOT_FIXED.getValue());
        rentCalculationDto.setFcmRentPayCycle(ContractRentPaymentCycleEnum.EACH_QUARTER.getValue());
        rentCalculationDto.setFcmRentPayType(ContractRentPayTypeEnum.NATURAL.getValue());
        List<RentCalculationDto.VariableRentDto> variableRentDtoList = new ArrayList<>();
        RentCalculationDto.VariableRentDto variableRentDto = new RentCalculationDto.VariableRentDto();
        variableRentDto.setFccStartMonth(1);
        variableRentDto.setFccEndMonth(10);
        variableRentDto.setFccRentAmount(1000D);
        variableRentDtoList.add(variableRentDto);
        rentCalculationDto.setVariableRentDtoList(variableRentDtoList);

        variableRentDto = new RentCalculationDto.VariableRentDto();
        variableRentDto.setFccStartMonth(11);
        variableRentDto.setFccEndMonth(13);
        variableRentDto.setFccRentAmount(999D);
        variableRentDtoList.add(variableRentDto);
        return rentCalculationDto;
    }

    /**
     * @author Bob
     * @date 2021/11/30
     * @description 固定自然合同计算
     */
    private void fixedNaturalContract() {
        // 获取不固定相对合同
        RentCalculationDto rentCalculationDto = getFixedNatural();
        SortedMap<Integer, RentTimeRightDto> rent = contractFacade.getRent(rentCalculationDto);
        // 集合不能为空
        assertTrue(MapUtils.isNotEmpty(rent));
        // 获取总金额
        BigDecimal total = rent.values().stream().map(RentTimeRightDto::getAmount).map(BigDecimal::valueOf).reduce(BigDecimal::add).orElse(BigDecimal.ZERO);
        assertEquals(0, BigDecimal.valueOf(12948.42D).compareTo(total));
    }

    /**
     * @author Bob
     * @date 2021/11/30
     * @description 获取固定自然合同
     * @return 合同
     */
    private RentCalculationDto getFixedNatural() {
        RentCalculationDto rentCalculationDto = new RentCalculationDto();
        rentCalculationDto.setFcmLeaseCount(13);
        Date date = ContractDateCalculateUtil.formatDay("2021-12-03");
        rentCalculationDto.setFcmLeaseStartDate(date);
        rentCalculationDto.setFcmLeaseType(ContractLeaseTypeEnum.FIXED.getValue());
        rentCalculationDto.setFcmRentPayCycle(ContractRentPaymentCycleEnum.EACH_QUARTER.getValue());
        rentCalculationDto.setFcmRentPayType(ContractRentPayTypeEnum.NATURAL.getValue());
        rentCalculationDto.setFcmLeaseAmount(1001D);
        return rentCalculationDto;
    }

    /**
     * @author Bob
     * @date 2021/11/30
     * @description 固定相对合同计算
     */
    private void fixedRelativeContract() {
        // 获取不固定相对合同
        RentCalculationDto rentCalculationDto = getFixedRelatively();
        SortedMap<Integer, RentTimeRightDto> rent = contractFacade.getRent(rentCalculationDto);
        // 集合不能为空
        assertTrue(MapUtils.isNotEmpty(rent));
        // 获取总金额
        BigDecimal total = rent.values().stream().map(RentTimeRightDto::getAmount).map(BigDecimal::valueOf).reduce(BigDecimal::add).orElse(BigDecimal.ZERO);
        assertEquals(0, BigDecimal.valueOf(13013).compareTo(total));
    }

    /**
     * @author Bob
     * @date 2021/11/30
     * @description 构建合同数据
     * @return 合同
     */
    private RentCalculationDto getFixedRelatively() {
        RentCalculationDto rentCalculationDto = new RentCalculationDto();
        rentCalculationDto.setFcmLeaseCount(13);
        Date date = ContractDateCalculateUtil.formatDay("2021-12-03");
        rentCalculationDto.setFcmLeaseStartDate(date);
        rentCalculationDto.setFcmLeaseType(ContractLeaseTypeEnum.FIXED.getValue());
        rentCalculationDto.setFcmRentPayCycle(ContractRentPaymentCycleEnum.EACH_QUARTER.getValue());
        rentCalculationDto.setFcmRentPayType(ContractRentPayTypeEnum.RELATIVE.getValue());
        rentCalculationDto.setFcmLeaseAmount(1001D);
        return rentCalculationDto;
    }

    /**
     * @author Bob
     * @date 2021/11/30
     * @description 不固定相对合同计算
     */
    private void unfixedRelativeContract() {
        // 获取不固定相对合同
        RentCalculationDto rentCalculationDto = getNotFixedRelatively();
        SortedMap<Integer, RentTimeRightDto> rent = contractFacade.getRent(rentCalculationDto);
        // 集合不能为空
        assertTrue(MapUtils.isNotEmpty(rent));
        // 获取总金额
        BigDecimal total = rent.values().stream().map(RentTimeRightDto::getAmount).map(BigDecimal::valueOf).reduce(BigDecimal::add).orElse(BigDecimal.ZERO);
        assertEquals(0, BigDecimal.valueOf(12997).compareTo(total));
    }

    /**
     * @author Bob
     * @date 2021/11/30
     * @description 构建合同数据
     * @return 合同
     */
    private RentCalculationDto getNotFixedRelatively() {
        RentCalculationDto rentCalculationDto = new RentCalculationDto();
        rentCalculationDto.setFcmLeaseCount(13);
        Date date = ContractDateCalculateUtil.formatDay("2021-12-03");
        rentCalculationDto.setFcmLeaseStartDate(date);
        rentCalculationDto.setFcmLeaseType(ContractLeaseTypeEnum.NOT_FIXED.getValue());
        rentCalculationDto.setFcmRentPayCycle(ContractRentPaymentCycleEnum.EACH_QUARTER.getValue());
        rentCalculationDto.setFcmRentPayType(ContractRentPayTypeEnum.RELATIVE.getValue());
        List<RentCalculationDto.VariableRentDto> variableRentDtoList = new ArrayList<>();
        RentCalculationDto.VariableRentDto variableRentDto = new RentCalculationDto.VariableRentDto();
        variableRentDto.setFccStartMonth(1);
        variableRentDto.setFccEndMonth(10);
        variableRentDto.setFccRentAmount(1000D);
        variableRentDtoList.add(variableRentDto);
        rentCalculationDto.setVariableRentDtoList(variableRentDtoList);

        variableRentDto = new RentCalculationDto.VariableRentDto();
        variableRentDto.setFccStartMonth(11);
        variableRentDto.setFccEndMonth(13);
        variableRentDto.setFccRentAmount(999D);
        variableRentDtoList.add(variableRentDto);
        return rentCalculationDto;
    }
}