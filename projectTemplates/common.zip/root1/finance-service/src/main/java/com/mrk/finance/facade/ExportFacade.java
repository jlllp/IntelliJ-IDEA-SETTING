package com.mrk.finance.facade;

import cn.afterturn.easypoi.excel.ExcelExportUtil;
import cn.afterturn.easypoi.excel.entity.ExportParams;
import com.mrk.common.exception.GlobalException;
import org.apache.poi.ss.usermodel.Workbook;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

import javax.servlet.ServletOutputStream;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.util.Collection;

/**
 * @author Bob
 * @date 2021/4/8 15:58
 * @description
 */
@Component
public class ExportFacade {

    private static final Logger log = LoggerFactory.getLogger(ExportFacade.class);

    private static final String ERROR_STR = "导出文件失败";

    /**
     * @author Bob
     * @date 2021/3/30 17:55
     * @description 导出文件
     */
    public void exportByExcel(HttpServletResponse response, String fileName, Class<?> pojoClass, Collection<?> data) {
        Workbook workbook = ExcelExportUtil.exportExcel(new ExportParams(), pojoClass, data);
        try(ServletOutputStream outputStream = response.getOutputStream()) {
            setProperties(response, fileName, workbook, outputStream);
        } catch (IOException e) {
            log.error(ERROR_STR, e);
            throw new GlobalException("导出文件失败,请重试");
        }
    }

    /**
     * @author Bob
     * @date 2021/4/27 14:13
     * @description 设置返回对象属性
     * @param response 响应对象
     * @param fileName 文件名
     * @param workbook excel封装的对象
     * @param outputStream 输出流
     * @throws IOException 抛出io异常
     */
    public static void setProperties(HttpServletResponse response, String fileName, Workbook workbook, ServletOutputStream outputStream) throws IOException {
        fileName = new String(fileName.getBytes(StandardCharsets.UTF_8),StandardCharsets.ISO_8859_1);
        response.setHeader("Content-Disposition", "attachment;filename=" + fileName);
        response.setContentType("application/x-download");
        response.setCharacterEncoding("UTF-8");
        response.addHeader("Pargam", "no-cache");
        response.addHeader("Cache-Control", "no-cache");
        response.flushBuffer();
        workbook.write(outputStream);
        outputStream.flush();
    }

    /**
     * @author Bob
     * @date 2021/4/13 18:24
     * @description 导出文件
     */
    public void exportByExcel(HttpServletResponse response, String fileName, Workbook workbook) {
        try(ServletOutputStream outputStream = response.getOutputStream()) {
            setProperties(response, fileName, workbook, outputStream);
        } catch (IOException e) {
            log.error(ERROR_STR, e);
            throw new GlobalException("导出文件失败,请重试");
        }
    }
}
