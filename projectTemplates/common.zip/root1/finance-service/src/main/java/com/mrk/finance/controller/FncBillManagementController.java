package com.mrk.finance.controller;

import com.github.pagehelper.PageInfo;
import com.mrk.common.utils.page.JsonResult;
import com.mrk.finance.dto.AutoMatchResOfBillDto;
import com.mrk.finance.dto.FncBillManagementDto;
import com.mrk.finance.facade.bill.FncBillAutoMatchFacade;
import com.mrk.finance.facade.bill.FncBillManagementFacade;
import com.mrk.finance.facade.bill.FncBillManagementImportFacade;
import com.mrk.finance.queryvo.FncBillManagementQueryVo;
import com.mrk.finance.service.FncBillManagementService;
import com.mrk.finance.vo.BillAddOrUpdateVo;
import com.mrk.finance.vo.BillMatchWaterVo;
import com.mrk.log.annotation.Log;
import com.mrk.log.enums.BusinessType;
import com.mrk.log.enums.OperatorType;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiImplicitParam;
import io.swagger.annotations.ApiImplicitParams;
import io.swagger.annotations.ApiOperation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import javax.servlet.http.HttpServletResponse;
import java.util.List;


/**
 * FncBillManagementController

 */
@RestController
@RequestMapping("/financeservice/fncbillmanagement")
@Api(tags = "/账单管理")
public class FncBillManagementController {
    @Autowired
    private FncBillManagementService fncBillManagementService;
    @Autowired
    private FncBillManagementFacade fncBillManagementFacade;
    @Autowired
    private FncBillManagementImportFacade fncBillManagementImportFacade;
    @Autowired
    private FncBillAutoMatchFacade fncBillAutoMatchFacade;


    @GetMapping(value = "/page")
    @ApiOperation("账单管理-分页查询")
    @ApiImplicitParams({
            @ApiImplicitParam(paramType = "header", name = "Authorization", value = "系统下发的token", required = true)
    })
    public JsonResult<PageInfo<FncBillManagementDto>> page(FncBillManagementQueryVo queryVo) {
        return JsonResult.success(fncBillManagementFacade.page(queryVo));
    }

    @GetMapping(value = "/export")
    @ApiOperation("账单管理-按条件导出")
    @ApiImplicitParams({
            @ApiImplicitParam(paramType = "header", name = "Authorization", value = "系统下发的token", required = true)
    })
    @Log(title = "账单管理", value = "按条件导出", businessType = BusinessType.DELETE, operatorType = OperatorType.MANAGE)
    public void export(FncBillManagementQueryVo queryVo, HttpServletResponse response) {
        fncBillManagementImportFacade.export(queryVo, response);
    }

    @PostMapping(value = "/add")
    @ApiOperation("账单管理-新增")
    @ApiImplicitParams({
            @ApiImplicitParam(paramType = "header", name = "Authorization", value = "系统下发的token", required = true)
    })
    @Log(title = "账单管理", value = "新增", businessType = BusinessType.DELETE, operatorType = OperatorType.MANAGE)
    public JsonResult<Integer> add(BillAddOrUpdateVo entity) {
        return JsonResult.success(fncBillManagementFacade.add(entity)).setMsg("新增成功");
    }

    @PostMapping(value = "/del/{id}")
    @ApiOperation("账单管理-删除")
    @ApiImplicitParams({
            @ApiImplicitParam(paramType = "header", name = "Authorization", value = "系统下发的token", required = true)
    })
    @Log(title = "账单管理", value = "删除", businessType = BusinessType.DELETE, operatorType = OperatorType.MANAGE)
    public JsonResult<Integer> del(@PathVariable Long id) {
        return JsonResult.success(fncBillManagementFacade.del(id, false)).setMsg("删除成功");
    }

    @PostMapping(value = "/approve")
    @ApiOperation("账单管理-审批")
    @ApiImplicitParams({
            @ApiImplicitParam(paramType = "header", name = "Authorization", value = "系统下发的token", required = true)
    })
    @Log(title = "账单管理", value = "审批", businessType = BusinessType.OTHER, operatorType = OperatorType.MANAGE)
    public JsonResult<Integer> approve(@RequestParam Long id, @RequestParam Integer approveStatus) {
        return JsonResult.success(fncBillManagementFacade.approve(id, approveStatus)).setMsg("审批操作成功");
    }

    @PostMapping(value = "/relaunch_approve")
    @ApiOperation("账单管理-重新发起审批")
    @ApiImplicitParams({
            @ApiImplicitParam(paramType = "header", name = "Authorization", value = "系统下发的token", required = true)
    })
    @Log(title = "账单管理", value = "重新发起审批", businessType = BusinessType.OTHER, operatorType = OperatorType.MANAGE)
    public JsonResult<Integer> relaunchApprove(@RequestBody BillAddOrUpdateVo bill) {
        return JsonResult.success(fncBillManagementFacade.relaunchApprove(bill)).setMsg("重新发起审批成功");
    }

    @PostMapping(value = "/apply_invoice")
    @ApiOperation("账单管理-申请开票")
    @ApiImplicitParams({
            @ApiImplicitParam(paramType = "header", name = "Authorization", value = "系统下发的token", required = true)
    })
    @Log(title = "账单管理", value = "申请开票", businessType = BusinessType.OTHER, operatorType = OperatorType.MANAGE)
    public JsonResult<Integer> applyInvoice(@RequestParam Long id) {
        return JsonResult.success(fncBillManagementFacade.applyInvoice(id)).setMsg("申请开票成功");
    }

    @PostMapping(value = "/apply_invoice_batch")
    @ApiOperation("账单管理-申请开票(批量)")
    @ApiImplicitParams({
            @ApiImplicitParam(paramType = "header", name = "Authorization", value = "系统下发的token", required = true)
    })
    @Log(title = "账单管理", value = "申请开票(批量)", businessType = BusinessType.OTHER, operatorType = OperatorType.MANAGE)
    public JsonResult<Integer> applyInvoiceBatch(@RequestBody List<Long> ids) {
        return JsonResult.success(fncBillManagementFacade.applyInvoiceBatch(ids)).setMsg("申请开票成功");
    }

    @PostMapping(value = "/confirm_invoice")
    @ApiOperation("账单管理-确认开票")
    @ApiImplicitParams({
            @ApiImplicitParam(paramType = "header", name = "Authorization", value = "系统下发的token", required = true)
    })
    @Log(title = "账单管理", value = "确认开票", businessType = BusinessType.OTHER, operatorType = OperatorType.MANAGE)
    public JsonResult<Integer> confirmInvoice(@RequestParam Long id) {
        return JsonResult.success(fncBillManagementFacade.confirmInvoice(id)).setMsg("确认开票成功");
    }

    @PostMapping(value = "/confirm_invoice_batch")
    @ApiOperation("账单管理-确认开票(批量)")
    @ApiImplicitParams({
            @ApiImplicitParam(paramType = "header", name = "Authorization", value = "系统下发的token", required = true)
    })
    @Log(title = "账单管理", value = "确认开票(批量)", businessType = BusinessType.OTHER, operatorType = OperatorType.MANAGE)
    public JsonResult<Integer> confirmInvoiceBatch(@RequestBody List<Long> ids) {
        return JsonResult.success(fncBillManagementFacade.confirmInvoiceBatch(ids)).setMsg("确认开票成功");
    }

    @PostMapping(value = "/match_water_manually")
    @ApiOperation("账单管理-手动匹配流水")
    @ApiImplicitParams({
            @ApiImplicitParam(paramType = "header", name = "Authorization", value = "系统下发的token", required = true)
    })
    @Log(title = "账单管理", value = "手动匹配流水", businessType = BusinessType.OTHER, operatorType = OperatorType.MANAGE)
    public JsonResult<Integer> matchWaterManually(@RequestBody BillMatchWaterVo vo) {
        return JsonResult.success(fncBillManagementFacade.manuallyMatch(vo)).setMsg("手动匹配成功");
    }

    @PostMapping(value = "/match_water_automatically")
    @ApiOperation("账单管理-自动匹配流水")
    @ApiImplicitParams({
            @ApiImplicitParam(paramType = "header", name = "Authorization", value = "系统下发的token", required = true)
    })
    @Log(title = "账单管理", value = "自动匹配流水", businessType = BusinessType.OTHER, operatorType = OperatorType.MANAGE)
    public JsonResult<List<AutoMatchResOfBillDto>> matchWaterAutomatically(@RequestBody List<Long> fbmIds) {
        return JsonResult.success(fncBillAutoMatchFacade.autoMatch(fbmIds)).setMsg("自动匹配成功, 请查看匹配结果");
    }

}
