package com.mrk.finance.constants;

/**
 * @project: mrk-finance
 * @author: Frank.Tang
 * @date: 2021-11-10 18:24
 * @desc:
 **/
public class ExMsgConstants {

    private ExMsgConstants() {

    }

    public static final String RECEIVE_NULL_ENTITY = "数据异常, 接收到的实体类为空";

    public static final String RECEIVE_NULL_PARA = "数据异常, 接收到的参数为空";

    public static final String RECEIVE_NULL_ID = "数据异常, 接收到的id为空";

}
