package com.mrk.finance.facade.newcontract;

import com.github.pagehelper.PageInfo;
import com.mrk.auth.client.AuthCityClient;
import com.mrk.auth.client.AuthDeptClient;
import com.mrk.auth.client.AuthUserClient;
import com.mrk.auth.model.AuthCity;
import com.mrk.auth.model.AuthDept;
import com.mrk.auth.model.AuthUser;
import com.mrk.common.constant.BaseConstants;
import com.mrk.common.exception.GlobalException;
import com.mrk.common.utils.container.ListUtil;
import com.mrk.common.utils.jwt.JWTUtil;
import com.mrk.common.utils.text.CheckUtil;
import com.mrk.common.utils.time.DateUtils;
import com.mrk.finance.constants.ExMsgConstants;
import com.mrk.finance.constants.LenConstants;
import com.mrk.finance.dto.*;
import com.mrk.finance.dto.contract.RentCalculationDto;
import com.mrk.finance.dto.contract.RentTimeRightDto;
import com.mrk.finance.dto.date.TimeRightDto;
import com.mrk.finance.enums.*;
import com.mrk.finance.enums.newcontract.*;
import com.mrk.finance.example.FncContractRentalFeesExample;
import com.mrk.finance.facade.bill.FncBillManagementFacade;
import com.mrk.finance.model.*;
import com.mrk.finance.queryvo.FncBillManagementQueryVo;
import com.mrk.finance.queryvo.FncContractManagementQueryVo;
import com.mrk.finance.queryvo.FncContractRentalFeesQueryVo;
import com.mrk.finance.queryvo.FncRentalFeesQueryVo;
import com.mrk.finance.service.*;
import com.mrk.finance.util.ExceptionUtil;
import com.mrk.finance.util.ObjectUtil;
import com.mrk.finance.util.StreamUtil;
import com.mrk.finance.util.contract.ContractDateCalculateUtil;
import com.mrk.finance.vo.ContractAddOrUpdateVo;
import com.mrk.lease.client.LeaseOrderClient;
import com.mrk.lease.client.dto.LaeOrderManagementDto;
import com.mrk.member.client.MemberClient;
import com.mrk.member.model.MrkMember;
import com.mrk.sys.client.SysCarTypeClient;
import com.mrk.sys.client.SysDictDataClient;
import com.mrk.sys.model.SysCarType;
import com.mrk.sys.model.SysDictData;
import com.mrk.universal.enums.contract.ContractLeaseStartTypeEnum;
import com.mrk.universal.enums.contract.ContractMarginPayRequireEnum;
import com.mrk.universal.enums.contract.ContractPartyTypeEnum;
import com.mrk.universal.enums.turner.TurnerSingleOverTimeEnum;
import com.mrk.workflow.client.WorkflowClient;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.CollectionUtils;

import java.math.BigDecimal;
import java.text.SimpleDateFormat;
import java.util.*;
import java.util.stream.Collectors;

/**
 * @project: mrk-finance
 **/
@Slf4j
@Component
public class NewFncContractManagementFacade {

    private static final int ADD = 0;
    private static final int UPDATE = 1;
    @Autowired
    private FncBillManagementFacade fncBillManagementFacade;
    @Autowired
    private FncContractManagementService fncContractManagementService;
    @Autowired
    private FncContractAttachService fncContractAttachService;
    @Autowired
    private FncBillManagementService fncBillManagementService;
    @Autowired
    private FncRentalFeesService fncRentalFeesService;
    @Autowired
    private FncContractRentalFeesService fncContractRentalFeesService;
    @Autowired
    private SysCarTypeClient sysCarTypeClient;
    @Autowired
    private LeaseOrderClient leaseOrderClient;
    @Autowired
    private AuthCityClient authCityClient;
    @Autowired
    private AuthDeptClient authDeptClient;
    @Autowired
    private AuthUserClient authUserClient;
    @Autowired
    private MemberClient memberClient;
    @Autowired
    private WorkflowClient workflowClient;
    @Autowired
    private SysDictDataClient sysDictDataClient;
    @Autowired
    private NewContractFacade contractFacade;

    /**
     * 分页查询
     *
     * @return *
     * @author
     */
    public PageInfo<FncContractManagementDto> page(FncContractManagementQueryVo queryVo) {
        FncContractManagementQueryVo fncContractManagementQueryVo = new FncContractManagementQueryVo();
        fncContractManagementQueryVo.setDrEqualTo(BaseConstants.DR_NO);
        List<FncContractManagement> fncContractManagements = fncContractManagementService.list(fncContractManagementQueryVo);
        if (CollectionUtils.isEmpty(fncContractManagements)) {
            return new PageInfo<>();
        }
        //合同id
        List<Long> contractList = fncContractManagements.stream().map(FncContractManagement::getFcmId).collect(Collectors.toList());
        //未上传集合
        List<Long> contractListNo = new ArrayList<>();
        //上传集合
        List<Long> contractListYes = new ArrayList<>();
        //附件状态
        //附件
        List<FncContractAttach> contractAttaches = fncContractAttachService.selectByContractIds(contractList);
        if (CheckUtil.isNotEmpty(queryVo.getTypeState())) {
            //未上传
            if (NewTypeStateEnum.LEASE_TO_START.getState().equals(queryVo.getTypeState())) {
                if (!CollectionUtils.isEmpty(contractAttaches)) {
                    for (Long id : contractList) {
                        if (CollectionUtils.isEmpty(contractAttaches.stream().filter(x -> x.getFcaContractId().equals(id)).collect(Collectors.toList()))) {
                            contractListNo.add(id);
                        }
                    }
                    queryVo.setFcmIdIn(contractListNo);
                }
            } else {
                if (!CollectionUtils.isEmpty(contractAttaches)) {
                    for (Long id : contractList) {
                        if (!CollectionUtils.isEmpty(contractAttaches.stream().filter(x -> x.getFcaContractId().equals(id)).collect(Collectors.toList()))) {
                            contractListYes.add(id);
                        }
                    }
                    queryVo.setFcmIdIn(contractListYes);
                } else {
                    return new PageInfo<>();
                }
            }
        }

        PageInfo<FncContractManagement> page = fncContractManagementService.getPage(queryVo);
        List<FncContractManagement> list = page.getList();
        if (list == null || list.isEmpty()) {
            return new PageInfo<>();
        }

        List<FncContractManagementDto> res = ListUtil.copyBeanList(list, FncContractManagementDto.class);

        //所有会员id
        List<Long> memberIds = new ArrayList<>();
        //所有部门id
        List<Long> deptIds = new ArrayList<>();
        //所有城市id
        List<Long> cityIds = new ArrayList<>();
        //所有车型id字符串
        StringBuilder carTypetIdStr = new StringBuilder();
        //所有合同id
        List<Long> contractIds = new ArrayList<>();
        //不固定类型的合同id
        for (FncContractManagementDto re : res) {
            cityIds.add(re.getFcmReturnCity());
            cityIds.add(re.getFcmDeliverCity());
            cityIds.add(re.getFcmSignedAddr());
            if (CheckUtil.isNotEmpty(re.getFcmCarTypeId())) {
                carTypetIdStr.append(re.getFcmCarTypeId()).append(",");
            }
            contractIds.add(re.getFcmId());
            if (ContractPartyTypeEnum.PERSONAL.getValue().equals(re.getFcmPartyaType())) {
                memberIds.add(re.getFcmPartyaId());
            } else {
                deptIds.add(re.getFcmPartyaId());
            }
            if (ContractPartyTypeEnum.PERSONAL.getValue().equals(re.getFcmPartybType())) {
                memberIds.add(re.getFcmPartybId());
            } else {
                deptIds.add(re.getFcmPartybId());
            }
        }

        contractIds = StreamUtil.toList(res, FncContractManagement::getFcmId);
        Map<Long, SysCarType> longSysCarTypeMap = new HashMap<>();
        //所有车型
        if (CheckUtil.isNotEmpty(carTypetIdStr)) {
            List<SysCarType> carType = sysCarTypeClient.getByIds(String.valueOf(carTypetIdStr)).getDataWithEx();
            //车型map
            longSysCarTypeMap = StreamUtil.toMap(carType, SysCarType::getCarTypeId);
        }


        //租金包含费用
        FncContractRentalFeesQueryVo queryVo1 = new FncContractRentalFeesQueryVo();
        Map<Long, List<FncContractRentalFeesDto>> rentalFeesMap;
        if (contractIds.isEmpty()) {
            rentalFeesMap = new HashMap<>();
        } else {
            queryVo1.setFcrfContractIdIn(contractIds);
            List<FncContractRentalFees> contractRentalFees = fncContractRentalFeesService.list(queryVo1);
            List<FncContractRentalFeesDto> rentalFeesDtos = ListUtil.copyBeanList(contractRentalFees, FncContractRentalFeesDto.class);

            //渲染每个的name
            List<Long> rentFeeIds = StreamUtil.toList(rentalFeesDtos, FncContractRentalFees::getFcrfRentFeesId);
            FncRentalFeesQueryVo queryVo2 = new FncRentalFeesQueryVo();
            List<FncRentalFees> rentalFees;
            if (rentFeeIds != null && !rentFeeIds.isEmpty()) {
                queryVo2.setFrfIdIn(rentFeeIds);
                rentalFees = fncRentalFeesService.list(queryVo2);
            } else {
                rentalFees = new ArrayList<>();
            }

            Map<Long, String> idAndNameMap = StreamUtil.toMap(rentalFees, FncRentalFees::getFrfId, FncRentalFees::getFrfName);
            Map<Long, String> idAndMarkMap = StreamUtil.toMap(rentalFees, FncRentalFees::getFrfId, FncRentalFees::getFrfMark);

            for (FncContractRentalFeesDto dto : rentalFeesDtos) {
                dto.setFcrfName(idAndNameMap.get(dto.getFcrfRentFeesId()));
                dto.setFcrfMark(idAndMarkMap.get(dto.getFcrfRentFeesId()));
            }
            rentalFeesMap = rentalFeesDtos.stream().collect(Collectors.groupingBy(FncContractRentalFees::getFcrfContractId));
        }

        //会员+组织
        List<MrkMember> members = memberClient.findByids(ObjectUtil.collectionToStr(memberIds)).getDataWithEx();
        List<AuthDept> depts = authDeptClient.getAuthDeptByIds(ObjectUtil.collectionToStr(deptIds)).getDataWithEx();
        Map<Long, MrkMember> memberMap = StreamUtil.toMap(members, MrkMember::getMmId);
        Map<Long, AuthDept> deptMap = StreamUtil.toMap(depts, AuthDept::getId);

        //城市
        List<AuthCity> cities = authCityClient.getCityByIds(ObjectUtil.collectionToStr(cityIds)).getDataWithEx();
        Map<Long, AuthCity> cityMap = StreamUtil.toMap(cities, AuthCity::getId);
        List<FncContractAttach> fncContractAttaches = fncContractAttachService.selectByContractIds(contractIds);
        for (FncContractManagementDto dto : res) {
            List<FncContractRentalFeesDto> rentalFee = rentalFeesMap.get(dto.getFcmId());
            Long partyaId = dto.getFcmPartyaId();
            Long partybId = dto.getFcmPartybId();

            //甲
            if (ContractPartyTypeEnum.PERSONAL.getValue().equals(dto.getFcmPartyaType())) {
                MrkMember member = memberMap.get(partyaId);
                dto.setFcmPartyaName(member == null ? "" : member.getMmName());
            } else {
                AuthDept dept = deptMap.get(partyaId);
                dto.setFcmPartyAText(dept == null ? "" : dept.getDeptName());
            }
            //乙
            if (ContractPartyTypeEnum.PERSONAL.getValue().equals(dto.getFcmPartybType())) {
                MrkMember member = memberMap.get(partybId);
                dto.setFcmPartybName(member == null ? "" : member.getMmName());
            } else {
                AuthDept dept = deptMap.get(partybId);
                dto.setFcmPartyBTypeText(dept == null ? "" : dept.getDeptName());
            }
            if (CheckUtil.isNotEmpty(dto.getFcmCarNature())) {
                SysDictData sysDictData = sysDictDataClient.getByValue(dto.getFcmCarNature()).getDataWithEx();
                dto.setFcmCarNatureText(sysDictData == null ? "" : sysDictData.getDictLabel());
            }
            //所有订单
            List<LaeOrderManagementDto> laeOrderManagementDtos = leaseOrderClient.findByLomAssociatedContractId(String.valueOf(dto.getFcmId())).getDataWithEx();

            if (!CollectionUtils.isEmpty(laeOrderManagementDtos)) {
                Integer data = workflowClient.selectByOrderId(StringUtils.join(laeOrderManagementDtos.stream().map(LaeOrderManagementDto::getLomId).collect(Collectors.toList()), ",")).getDataWithEx();
                if (data == 1) {
                    dto.setCarStateText(NewContractCarStateEnum.LEASED.getText());
                } else {
                    dto.setCarStateText(NewContractCarStateEnum.LEASE_SUSPENSION.getText());
                }
            }
            if (CollectionUtils.isEmpty(contractAttaches)) {
                dto.setContractAttachText(NewTypeStateEnum.LEASE_TO_START.getText());
            } else {
                if (!CollectionUtils.isEmpty(contractAttaches.stream().filter(x -> x.getFcaContractId().equals(dto.getFcmId())).collect(Collectors.toList()))) {
                    dto.setContractAttachText(NewTypeStateEnum.LEASED.getText());
                } else {
                    dto.setContractAttachText(NewTypeStateEnum.LEASE_TO_START.getText());
                }
            }

            dto.setFcmContractTypeName(NewContractTypeEnum.getText(dto.getFcmContractType()));
            dto.setFcmContractStateName(NewContractStateEnum.getText(dto.getFcmContractState()));
            dto.setFcmSettlementStateName(SettlementStateEnum.getText(dto.getFcmSettlementState()));

            AuthCity authCity = cityMap.get(dto.getFcmDeliverCity());
            dto.setFcmDeliverCityText(authCity == null ? "" : authCity.getCityName());

            dto.setFcmMarginPayTypeText(ContractMarginPayRequireEnum.getName(dto.getFcmMarginPayRequire()));
            dto.setFcmDeliverTypeText(ContractMarginPayRequireEnum.getName(dto.getFcmDeliverType()));
            AuthCity city = cityMap.get(dto.getFcmReturnCity());
            dto.setFcmReturnCityText(city == null ? "" : city.getCityName());
            dto.setFcmMarginTypeText(NewPerformanceSecurityEnum.getText(dto.getFcmMarginType()));
            if (!CollectionUtils.isEmpty(fncContractAttaches)) {
                dto.setFncContractAttaches(fncContractAttaches.stream().filter(x -> x.getFcaContractId().equals(dto.getFcmId())).collect(Collectors.toList()));
            }
            AuthCity authCity1 = cityMap.get(dto.getFcmSignedAddr());
            dto.setFcmSignedAddrText(authCity1 == null ? "" : authCity1.getCityName());

            if (CheckUtil.isNotEmpty(longSysCarTypeMap.get(dto.getFcmCarTypeId()))) {
                dto.setFcmCarTypeIdText(longSysCarTypeMap.get(dto.getFcmCarTypeId()).getCarTypeName());
            }
            dto.setContractRentalFees(rentalFee);
        }
        return new PageInfo<>(res);
    }

    /**
     * 查询所含的账单
     *
     * @return *
     * @author
     */
    public PageInfo<FncBillManagementDto> pageBillOfContract(FncBillManagementQueryVo queryVo) {
        CheckUtil.isEmptyWithEx(queryVo, ExMsgConstants.RECEIVE_NULL_PARA);
        CheckUtil.isEmptyWithEx(queryVo.getFbmAssociateContractIdEqualTo(), ExMsgConstants.RECEIVE_NULL_PARA + "-关联合同id");

        return fncBillManagementFacade.page(queryVo);
    }

    /**
     * 新增合同
     *
     * @return *
     * @author
     */
    @Transactional(rollbackFor = Exception.class)
    public Integer add(ContractAddOrUpdateVo entity) {
        //校验
        checkAdd(entity);
        //清除字段
        /*clearFiled(entity, ADD);*/
        //这里判断当前时间, 确定合同的初始状态
        entity.setFcmSettlementState(SettlementStateEnum.OUTSTANDING.getState());
        //新增, 拿到id
        entity.setFncTurnerSingleDeal(TurnerSingleOverTimeEnum.NO.getState());

        if (CheckUtil.isEmpty(JWTUtil.getUserId())) {
            throw new GlobalException("当前登陆人失效");
        }
        AuthUser authUser = authUserClient.getAuthUserById(JWTUtil.getUserId()).getDataWithEx();
        if (CheckUtil.isEmpty(authUser)) {
            throw new GlobalException("当前登陆人失效");
        }
        //写入合同创建人
        entity.setFcmCreatePhone(authUser.getUserPhone());
        fncContractManagementService.add(entity);
        //合同主键
        Long fcmId = entity.getFcmId();
        //合同附件
        List<FncContractAttach> fncContractAttaches = entity.getFncContractAttaches();
        for (FncContractAttach fncContractAttach : fncContractAttaches) {
            fncContractAttach.setFcaContractId(fcmId);
            fncContractAttach.setDr(BaseConstants.DR_NO);
        }
        fncContractAttachService.insertList(fncContractAttaches);
        //设置关联id, 并新增
        List<FncRentalFeesDto> rentalFees = entity.getRentalFees();

        List<FncContractRentalFees> contractRentalFeesList = new ArrayList<>();
        for (FncRentalFeesDto rentalFee : rentalFees) {
            FncContractRentalFees contractRentalFees = new FncContractRentalFees();
            contractRentalFees.setFcrfContractId(fcmId);
            contractRentalFees.setFcrfRentFeesId(rentalFee.getFrfId());
            contractRentalFees.setFcrfWrite(rentalFee.getFrfWrite());
            contractRentalFees.setFcrfValue(rentalFee.getFrfValue());
            contractRentalFeesList.add(contractRentalFees);
        }
        //生成保证金账单  当合同编号不为空，相当于审批通过
        // 下拉选择，单选，必选。分为“交车前一次性支付”、“分批支付”两种方式：
        //
        //1、选择“交车前一次性支付”的，则在合同审批通过以后，生成一个保证金总额的保证金账单。
        //
        //2、选择“分批支付”的，则在合同审批通过后，当前模版默认先生成一个保证金总额*20%的保证金账单。剩余的保证金账单通过手动生成。
        if (CheckUtil.isNotEmpty(entity.getFcmContractNo())) {
            genMarginBill(entity);
        }
        //新增关联数据
        fncContractRentalFeesService.addList(contractRentalFeesList);

        log.info("用户【{}】, 新增合同(id【{}】)", JWTUtil.getNikeName(), fcmId);

        return BaseConstants.DR_YES;
    }

    /**
     * 删除合同 (删除关联账单, 不删除关联车型/包含费用等数据)
     *
     * @return *
     * @author
     */
    @Transactional(rollbackFor = Exception.class)
    public Integer del(Long fcmId) {
        //check
        FncContractManagement contract = checkDel(fcmId);

        contract.setDr(BaseConstants.DR_YES);

        //删除关联的账单
        List<FncBillManagement> bills = fncBillManagementService.selectByContractId(fcmId);
        for (FncBillManagement bill : bills) {
            fncBillManagementFacade.del(bill.getFbmId(), true);
        }

        log.info("用户【{}】, 删除合同(id【{}】)", JWTUtil.getNikeName(), fcmId);

        return fncContractManagementService.update(contract);
    }

    /**
     * 批量删除合同
     *
     * @return *
     * @author
     */
    @Transactional(rollbackFor = Exception.class)
    public Integer delBatch(List<Long> ids) {
        if (ids == null || ids.isEmpty()) {
            throw new GlobalException("数据异常, 请选择需要删除的合同");
        }
        for (Long id : ids) {
            del(id);
        }
        return ids.size();
    }

    /**
     * 更新合同
     *
     * @return *
     * @author
     */
    @Transactional(rollbackFor = Exception.class)
    public Integer update(ContractAddOrUpdateVo entity) {
        //check 拿到相关数据
        ContractUpdateDto dto = checkUpdate(entity);
        List<FncRentalFeesDto> rentalFees = dto.getRentalFees();
        //清除字段
        clearFiled(entity, UPDATE);
        //租金包含费用
        if (rentalFees != null) {
            //删除以前的
            FncContractRentalFeesExample example = new FncContractRentalFeesExample();
            example.createCriteria()
                    .andDrEqualTo(BaseConstants.DR_NO)
                    .andFcrfContractIdEqualTo(entity.getFcmId());
            FncContractRentalFees updateEntity = new FncContractRentalFees();
            updateEntity.setDr(BaseConstants.DR_YES);
            fncContractRentalFeesService.updateByExampleSelective(updateEntity, example);

            //重新新增
            List<FncContractRentalFees> res = new ArrayList<>();
            for (FncRentalFeesDto rentalFee : rentalFees) {
                FncContractRentalFees contractRentalFees = new FncContractRentalFees();
                contractRentalFees.setFcrfContractId(entity.getFcmId());
                contractRentalFees.setFcrfRentFeesId(rentalFee.getFrfId());
                contractRentalFees.setFcrfWrite(rentalFee.getFrfWrite());
                contractRentalFees.setFcrfValue(rentalFee.getFrfValue());
                res.add(contractRentalFees);
            }
            fncContractRentalFeesService.addList(res);
        }
        //合同附件
        //删除之前的合同附件
        fncContractAttachService.updateByContarctId(entity.getFcmId());
        List<FncContractAttach> fncContractAttaches = entity.getFncContractAttaches();
        if (!CollectionUtils.isEmpty(fncContractAttaches)) {
            for (FncContractAttach fncContractAttach : fncContractAttaches) {
                fncContractAttach.setFcaContractId(entity.getFcmId());
                fncContractAttach.setDr(BaseConstants.DR_NO);
            }
            fncContractAttachService.insertList(fncContractAttaches);
        }
        //判断状态未审批中更新时，合同编号不为空的话，，合同状态为执行中，没有为审批中
        if (NewContractStateEnum.LEASE_TO_START.getState().equals(entity.getFcmContractState())) {
            if (CheckUtil.isNotEmpty(entity.getFcmContractNo())) {
                entity.setFcmContractState(NewContractStateEnum.LEASED.getState());
            }
        }
        //保存并重新发起
        if (CheckUtil.isNotEmpty(entity.getSum()) && entity.getSum() == 2 && NewContractStateEnum.LEASE_SUSPENSION.getState().equals(entity.getFcmContractState())) {
            entity.setFcmContractState(NewContractStateEnum.LEASE_TO_START.getState());
        }
        //出租方
        Long partyaId = entity.getFcmPartyaId();
        //承租方
        Integer partybId = entity.getFcmPartybType();
        //承租方 类型
        Integer partybType = entity.getFcmPartybType();
        if (ContractPartyTypeEnum.ORGANIZATION.getValue().equals(partybType)) {
            if (partyaId == partybId.longValue()) {
                throw new GlobalException("承租方为组织时不能与出租方相同！");
            }
        }
        log.info("用户【{}】, 更新合同(id【{}】)", JWTUtil.getNikeName(), entity.getFcmId());

        return fncContractManagementService.updateSelective(entity);
    }

    /**
     * 根据周期+开始日期等条件, 计算结束日期
     *
     * @return *
     * @author
     */
    public String calEndDate(FncContractManagement contract) {
        Date startDate = contract.getFcmLeaseStartDate();
        Integer leaseCount = contract.getFcmLeaseCount();
        Integer rentPayType = contract.getFcmRentPayType();
        Integer rentPayCycle = contract.getFcmRentPayCycle();

        CheckUtil.isEmptyWithEx(startDate, ExMsgConstants.RECEIVE_NULL_PARA + "(起始日期)");
        CheckUtil.isEmptyWithEx(leaseCount, ExMsgConstants.RECEIVE_NULL_PARA + "(租期)");
        CheckUtil.isEmptyWithEx(rentPayType, ExMsgConstants.RECEIVE_NULL_PARA + "(租赁类型)");
        CheckUtil.isEmptyWithEx(rentPayCycle, ExMsgConstants.RECEIVE_NULL_PARA + "(支付周期)");

        SortedMap<Integer, TimeRightDto> map = ContractDateCalculateUtil
                .calculateThePaymentPeriod(
                        startDate, leaseCount, rentPayType,
                        ContractRentPaymentCycleEnum.toIntervalValue(rentPayCycle)
                );

        Integer lastKey = map.lastKey();
        TimeRightDto rightDto = map.get(lastKey);

        SimpleDateFormat dateFormat = new SimpleDateFormat(DateUtils.YYYY_MM_DD);

        return dateFormat.format(rightDto.getEnd());
    }

    /**
     * 计算 固定/不固定 总金额
     *
     * @return *
     * @author
     */
    @Transactional(rollbackFor = Exception.class)
    public BigDecimal calRentTotal(RentCalculationDto dto) {
        //校验
        checkCalRentTotal(dto);

        //没传, 表示交车日期, 直接返回0
        if (dto.getFcmLeaseStartDate() == null) {
            return BigDecimal.ZERO;
        }

        //执行计算逻辑
        SortedMap<Integer, RentTimeRightDto> rent = contractFacade.getRent(dto);

        //为空报错
        if (rent.isEmpty()) {
            throw new GlobalException("计算异常, 请重试");
        }

        ArrayList<RentTimeRightDto> rightDtoList = new ArrayList<>(rent.values());

        //求和并返回
        return rightDtoList.stream()
                .map(RentTimeRightDto::getAmount)
                .map(BigDecimal::valueOf)
                .reduce(BigDecimal::add)
                .orElse(BigDecimal.ZERO);
    }


    /**
     * 生成保证金账单
     *
     * @author
     */
    private void genMarginBill(ContractAddOrUpdateVo entity) {
        FncBillManagement bill = new FncBillManagementDto();

        Double marginTotal = entity.getFcmMarginTotal();
        if (ContractMarginPayRequireEnum.FULL_PAY_BEFORE_PICK_UP.getValue().equals(entity.getFcmMarginPayRequire())) {
            bill.setFbmBillAmount(marginTotal);
        } else {
            //为分批交付时保证金总额为20%
            BigDecimal a = new BigDecimal(marginTotal);
            BigDecimal b = new BigDecimal("0.2");
            bill.setFbmBillAmount(a.multiply(b).doubleValue());
        }

        bill.setFbmMatchedAmount(0.0);
        bill.setFbmNotMatchAmount(marginTotal);
        bill.setFbmAssociateContractId(entity.getFcmId());
        bill.setFbmSubjects(BillSubjectsEnum.BOND.getValue());
        bill.setFbmCityId(entity.getFcmDeliverCity());
        bill.setFbmBillState(BillStateEnum.UNPAID.getValue());
        bill.setFbmBillGenerateWay(BillGenerateWayEnum.AUTO.getValue());
        bill.setFbmTurnerDeal(TurnerSingleOverTimeEnum.NO.getState());
        //保证金账单, 只有开始日期, 不设置截止日期
        bill.setFbmBillGenerateTime(entity.getFcmSignedDate());
        bill.setFbmBillGenerateReason(String.format("新增合同(id-%s), 自动生成保证金账单", entity.getFcmId()));

        //只有一辆车才设置车id
        /*Long carId = contractOnlyCarFacade.getCarIdByContract(entity);
        bill.setFbmAssociateCarId(carId);*/

        fncBillManagementService.add(bill);
    }

    /**
     * 根据类型, 清除字段, 防止前端不同类型传错值
     * (比如"续租"有平台, "以租代售"没有平台. 当类型为"以租代售"时, 需要清除该字段)
     *
     * @param type=0 --> 新增
     *               1 --> 更新
     * @author
     */
    private void clearFiled(ContractAddOrUpdateVo entity, int type) {
        //新增时, 是交车日期, 清空租金总额
        if (type == ADD && ContractLeaseStartTypeEnum.DELIVERY_DATE.getValue().equals(entity.getFcmLeaseStartType())) {
            entity.setFcmLeaseAmountTotal(null);
        }
    }


    /*********************************************************************************************
     *                                          Checks
     *********************************************************************************************
     **
     * 新增校验
     * @author
     */
    private void checkAdd(ContractAddOrUpdateVo entity) {
        CheckUtil.isEmptyWithEx(entity, ExMsgConstants.RECEIVE_NULL_ENTITY);

        //车辆及费用信息
        List<FncRentalFeesDto> rentalFees = entity.getRentalFees();
        //取消租金包含费用必填

        //合同的主体信息
        //车辆交车地址
        Long cityId = entity.getFcmDeliverCity();

        //车辆归还地点
        Long returnCity = entity.getFcmReturnCity();

        //合同签订地点
        Long fcmSignedAddr = entity.getFcmSignedAddr();

        //车辆性质
        String carNature = entity.getFcmCarNature();

        //合同类型
        //车型
        Long carType = entity.getFcmCarTypeId();

        //是否可转租
        Integer fcmSublet = entity.getFcmSublet();

        //用途
        String fcmUse = entity.getFcmUse();

        //车辆交付方式
        Integer fcmDeliverType = entity.getFcmDeliverType();
        //租赁期数
        Integer fcmLeaseCount = entity.getFcmLeaseCount();
        //合同类型
        Integer contractType = entity.getFcmContractType();
        //合同号   有则代表审批通过，无则代表审批中
        String contractNo = entity.getFcmContractNo();
        //出租方
        Long partyaId = entity.getFcmPartyaId();
        //承租方
        Integer partybId = 1;
        //承租方 类型
        Integer partybType = entity.getFcmPartybType();
        Date signedDate = entity.getFcmSignedDate();
        //车辆总数
        Integer carnumTotal = entity.getFcmCarnumTotal();
        //租赁起始类型(固定/不固定)
        Integer leaseStartType = entity.getFcmLeaseStartType();
        //租赁起始日期
        Date leaseStartDate = entity.getFcmLeaseStartDate();
        //租赁到期日期
        Date leaseEndDate = entity.getFcmLeaseEndDate();
        //租赁类型
        Integer leaseType = entity.getFcmLeaseType();
        //租金（元/月/辆）
        Double leaseAmount = entity.getFcmLeaseAmount();
        //租金支付周期
        Integer rentPayType = entity.getFcmRentPayType();
        //租金支付周期(每月支付等)
        Integer rentPayCycle = entity.getFcmRentPayCycle();
        //账单生成类型
        Integer billGenerateType = entity.getFcmBillGenerateType();
        //账单截止类型
        Integer billCatOffType = entity.getFcmBillCatoffType();

        //履约保证金类型 0无 1总额 2单车
        Integer fcmMarginType = entity.getFcmMarginType();
        //履约保证金总额    (单车或者总额)
        Double fcmMarginMoney = entity.getFcmMarginMoney();
        //保证金支付方式 0无 1交车前一次性支付 2分批支付
        Integer fcmMarginPayRequire = entity.getFcmMarginPayRequire();


        //公共字段非空校验
        CheckUtil.isEmptyWithEx(fcmMarginPayRequire, ExMsgConstants.RECEIVE_NULL_PARA + "-保证金支付方式");
        CheckUtil.isEmptyWithEx(fcmMarginMoney, ExMsgConstants.RECEIVE_NULL_PARA + "-履约保证金");
        CheckUtil.isEmptyWithEx(fcmMarginType, ExMsgConstants.RECEIVE_NULL_PARA + "-履约保证金类型");
        CheckUtil.isEmptyWithEx(cityId, ExMsgConstants.RECEIVE_NULL_PARA + "-车辆交付地点");
        CheckUtil.isEmptyWithEx(fcmLeaseCount, ExMsgConstants.RECEIVE_NULL_PARA + "-租赁期数");
        CheckUtil.isEmptyWithEx(fcmDeliverType, ExMsgConstants.RECEIVE_NULL_PARA + "-车辆交付方式");
        CheckUtil.isEmptyWithEx(fcmSignedAddr, ExMsgConstants.RECEIVE_NULL_PARA + "-合同签订地点");
        CheckUtil.isEmptyWithEx(fcmUse, ExMsgConstants.RECEIVE_NULL_PARA + "-用途");
        CheckUtil.isEmptyWithEx(fcmSublet, ExMsgConstants.RECEIVE_NULL_PARA + "-是否转租");
        CheckUtil.isEmptyWithEx(returnCity, ExMsgConstants.RECEIVE_NULL_PARA + "-车辆归还地点");
        CheckUtil.isEmptyWithEx(carType, ExMsgConstants.RECEIVE_NULL_PARA + "-车型");
        CheckUtil.isEmptyWithEx(contractType, ExMsgConstants.RECEIVE_NULL_PARA + "-合同类型");
        CheckUtil.isEmptyWithEx(partyaId, ExMsgConstants.RECEIVE_NULL_PARA + "-出租方id");
        CheckUtil.isEmptyWithEx(partybId, ExMsgConstants.RECEIVE_NULL_PARA + "-承租方id");
        CheckUtil.isEmptyWithEx(partybType, ExMsgConstants.RECEIVE_NULL_PARA + "-承租方类型");
        CheckUtil.isEmptyWithEx(signedDate, ExMsgConstants.RECEIVE_NULL_PARA + "-签订日期");
        CheckUtil.isEmptyWithEx(carnumTotal, ExMsgConstants.RECEIVE_NULL_PARA + "-车辆总数");
        CheckUtil.isEmptyWithEx(fcmLeaseCount, ExMsgConstants.RECEIVE_NULL_PARA + "-租期");
        CheckUtil.isEmptyWithEx(leaseStartType, ExMsgConstants.RECEIVE_NULL_PARA + "-开始类型");
        CheckUtil.isEmptyWithEx(leaseType, ExMsgConstants.RECEIVE_NULL_PARA + "-租赁类型");
        CheckUtil.isEmptyWithEx(rentPayType, ExMsgConstants.RECEIVE_NULL_PARA + "-租金支付类型");
        CheckUtil.isEmptyWithEx(rentPayCycle, ExMsgConstants.RECEIVE_NULL_PARA + "-租金支付周期");
        CheckUtil.isEmptyWithEx(billGenerateType, ExMsgConstants.RECEIVE_NULL_PARA + "-账单生成类型");
        CheckUtil.isEmptyWithEx(billCatOffType, ExMsgConstants.RECEIVE_NULL_PARA + "-账单截止日期");
        CheckUtil.isEmptyWithEx(leaseAmount, ExMsgConstants.RECEIVE_NULL_PARA + "-租金（元/月/辆）");
        CheckUtil.isEmptyWithEx(carNature, ExMsgConstants.RECEIVE_NULL_PARA + "-车辆性质");


        checkInterval(entity);
        entity.setFcmContractState(NewContractStateEnum.LEASE_TO_START.getState());
        //长度校验
        if (CheckUtil.isNotEmpty(contractNo)) {
            if (contractNo.length() > LenConstants.LEN_255) {
                throw ExceptionUtil.outLen("合同号");
            }
        }
        //城市id
        List<AuthCity> cityList = authCityClient.getCityByIds(cityId + "," + returnCity + "," + fcmSignedAddr + "").getDataWithEx();
        if (cityList == null || cityList.isEmpty()) {
            throw ExceptionUtil.notExist("地点id", cityId);
        }
        if (CollectionUtils.isEmpty(cityList.stream().filter(x -> x.getId().equals(cityId)).collect(Collectors.toList()))) {
            throw ExceptionUtil.notExist("车辆交车地点", cityId);
        }
        if (CollectionUtils.isEmpty(cityList.stream().filter(x -> x.getId().equals(returnCity)).collect(Collectors.toList()))) {
            throw ExceptionUtil.notExist("车辆归还地点", cityId);
        }
        if (CollectionUtils.isEmpty(cityList.stream().filter(x -> x.getId().equals(fcmSignedAddr)).collect(Collectors.toList()))) {
            throw ExceptionUtil.notExist("合同签订地点", cityId);
        }

        //合同类型枚举
        String contractTypeName = NewContractTypeEnum.getText(contractType);
        if (contractTypeName == null) {
            throw ExceptionUtil.enumNotExist("合同类型");
        }
        //合同号重复
        if (CheckUtil.isNotEmpty(contractNo)) {
            List<FncContractManagement> contractFromDb = fncContractManagementService.getByCode(contractNo);
            if (contractFromDb != null && !contractFromDb.isEmpty()) {
                throw ExceptionUtil.duplicate("合同号", contractNo);
            }
            //当合同号不为空时，合同状态为执行中
            entity.setFcmSettlementState(NewContractStateEnum.LEASED.getState());
        }
        //甲乙方合同类型
        String partybTypeName = ContractPartyTypeEnum.getName(partybType);
        if ("".equals(partybTypeName)) {
            throw ExceptionUtil.enumNotExist("承租方的类型");
        }
        //甲/乙方id
        AuthDept dept = authDeptClient.getAuthDeptById(partyaId).getDataWithEx();
        if (dept == null) {
            throw ExceptionUtil.notExist("出租方id", partyaId);
        }

        if (ContractPartyTypeEnum.PERSONAL.getValue().equals(partybType)) {
            MrkMember member = memberClient.findByid(Long.valueOf(partybId)).getDataWithEx();
            if (member == null) {
                throw ExceptionUtil.notExist("承租方id", partybId);
            }
        } else {
            AuthDept authDept = authDeptClient.getAuthDeptById(Long.valueOf(partybId)).getDataWithEx();
            if (authDept == null) {
                throw ExceptionUtil.notExist("承租方id", partybId);
            }
        }
        //车辆数
        if (carnumTotal <= 0) {
            throw new GlobalException("数据异常, 车辆总数不能小于等于0");
        }
        //租期/租金相关
        if (fcmLeaseCount <= 0) {
            throw new GlobalException("数据异常, 租期不能小于等于0");
        }
        //起始/结束日期
        if (ContractLeaseStartTypeEnum.DELIVERY_DATE.getValue().equals(leaseStartType)) {
            //起始类型为"交车日期", 账单生成日期不能为"交车开始前"
            if (NewBillDateTypeEnum.BEFORE.getValue().equals(billGenerateType)) {
                throw new GlobalException("操作失败, 起始类型为[交车日期], 账单生成日期不能为[交车开始前]");
            }
        } else if (ContractLeaseStartTypeEnum.IDENTIFIED_DATE.getValue().equals(leaseStartType)) {
            CheckUtil.isEmptyWithEx(leaseStartDate, ExMsgConstants.RECEIVE_NULL_PARA + "起始日期");
            CheckUtil.isEmptyWithEx(leaseEndDate, ExMsgConstants.RECEIVE_NULL_PARA + "结束日期");
        } else {
            throw ExceptionUtil.enumNotExist("租赁起始类型");
        }
        //租金支付周期类型
        if ("".equals(ContractRentPayTypeEnum.getName(rentPayType))) {
            throw ExceptionUtil.enumNotExist("租金支付周期类型");
        }
        //租金支付周期
        if (null == ContractRentPaymentCycleEnum.getText(rentPayCycle)) {
            throw ExceptionUtil.enumNotExist("租金支付周期");
        }


        //保证金支付要求类型
        if ("".equals(ContractMarginPayRequireEnum.getName(fcmMarginPayRequire))) {
            throw ExceptionUtil.enumNotExist("保证金支付要求");
        }
        //车型
        SysCarType sysCarType = sysCarTypeClient.getById(entity.getFcmCarTypeId()).getDataWithEx();
        if (CheckUtil.isEmpty(sysCarType)) {
            throw ExceptionUtil.enumNotExist("车型");
        }
        //租金包含费用
        if (rentalFees != null && !rentalFees.isEmpty()) {
            for (FncRentalFeesDto rentalFee : rentalFees) {
                CheckUtil.isEmptyWithEx(rentalFee.getFrfId(), ExMsgConstants.RECEIVE_NULL_PARA + "(包含费用-id)");
                CheckUtil.isEmptyWithEx(rentalFee.getFrfWrite(), ExMsgConstants.RECEIVE_NULL_PARA + "(包含费用-是否可填)");
                CheckUtil.isEmptyWithEx(rentalFee.getFrfName(), ExMsgConstants.RECEIVE_NULL_PARA + "(包含费用-名称)");
                if (BaseConstants.STATUS_ENABLE.equals(rentalFee.getFrfWrite())) {
                    CheckUtil.isEmptyWithEx(rentalFee.getFrfValue(), ExMsgConstants.RECEIVE_NULL_PARA + "(包含费用-值)");
                    if (new BigDecimal(rentalFee.getFrfValue()).compareTo(BigDecimal.ZERO) <= 0.0) {
                        throw new GlobalException("数据异常, 租金包含费用不能小于等于0");
                    }
                }
            }
        }
        //开始结束范围合法
        if (leaseStartDate != null && leaseEndDate != null && leaseStartDate.after(leaseEndDate)) {
            throw new GlobalException("数据异常, 合同的租赁[起始日期]必须小于[结束日期]");
        }
        //账单生成日类型
        if ("".equals(NewBillDateTypeEnum.getName(billGenerateType))) {
            throw ExceptionUtil.enumNotExist("账单生成日类型");
        }
        //账单截止日类型
        if ("".equals(NewBillDateTypeEnum.getName(billCatOffType))) {
            throw ExceptionUtil.enumNotExist("账单截止日类型");
        }
        //甲乙方不能相同
        if (partyaId.equals(partybId.longValue())) {
            throw new GlobalException("操作失败, 甲乙方不能选择同一个对象");
        }
    }

    /**
     * 账单生成/截止字段判断
     *
     * @author
     */
    private void checkInterval(ContractAddOrUpdateVo entity) {
        String err = "操作失败, 账单生成日不能晚于账单截止日";
        Integer generateInterval = entity.getFcmBillGenerateInterval();
        Integer generateType = entity.getFcmBillGenerateType();
        Integer catoffInterval = entity.getFcmBillCatoffInterval();
        Integer catoffType = entity.getFcmBillCatoffType();
        CheckUtil.isEmptyWithEx(generateType, "数据异常, 账单生成日类型不能为空");
        CheckUtil.isEmptyWithEx(catoffType, "数据异常, 账单截止日类型不能为空");

        //同为开始当天, 跳过
        if (NewBillDateTypeEnum.NOW.getValue().equals(generateType) && NewBillDateTypeEnum.NOW.getValue().equals(catoffType)) {
            return;
        }

        //越级
        if (generateType > catoffType) {
            throw new GlobalException(err);
        }
        //同级
        else if (generateType.equals(catoffType)) {
            if (NewBillDateTypeEnum.BEFORE.getValue().equals(generateType)) {
                if (generateInterval < catoffInterval) {
                    throw new GlobalException(err);
                }
            } else {
                if (generateInterval > catoffInterval) {
                    throw new GlobalException(err);
                }
            }
        }
    }

    /**
     * 更新合同校验:
     * (1)判断关联数据需要更新还是新增(删除暂不支持)
     * (2)数据正确性
     *
     * @return 待处理的dto, 包含需要更新或新增的数据
     * @author
     */
    private ContractUpdateDto checkUpdate(ContractAddOrUpdateVo entity) {
        CheckUtil.isEmptyWithEx(entity, ExMsgConstants.RECEIVE_NULL_PARA);
        Long fcmId = entity.getFcmId();
        CheckUtil.isEmptyWithEx(fcmId, ExMsgConstants.RECEIVE_NULL_PARA + "(合同id)");
        checkUpdateLease(entity);
        //开始/截止字段校验
        checkInterval(entity);

        //数据库中的实体类
        FncContractManagement contractFromDb = fncContractManagementService.getById(fcmId);
        List<Integer> integerList = Arrays.asList(NewContractStateEnum.LEASE_TO_START.getState(), NewContractStateEnum.LEASE_SUSPENSION.getState());
        if (!integerList.contains(contractFromDb.getFcmContractState())) {
            throw new GlobalException("操作失败, 当前合同状态不可编辑");
        }
        //包含租金费用
        List<FncRentalFeesDto> rentalFees = entity.getRentalFees();
        //这里统计需要更新/新增的数据
        //(2)
        //2.1 合同号
        String contractNo = entity.getFcmContractNo();
        if (contractNo != null && !contractNo.equals(contractFromDb.getFcmContractNo())) {
            List<FncContractManagement> contractsFromDb = fncContractManagementService.getByCode(contractNo);
            if (!contractsFromDb.isEmpty()) {
                throw new GlobalException("操作失败, 该合同号已存在");
            }
        }
        //长度
        if (contractNo != null && contractNo.length() > LenConstants.LEN_255) {
            throw ExceptionUtil.outLen("合同号");
        }

        //初始化更新集合
        ContractUpdateDto dto = new ContractUpdateDto();
        dto.setRentalFees(rentalFees);
        return dto;
    }

    /**
     * 删除校验:
     * (1)数据存在  (2)状态满足
     * (3)租赁中合同删除, 所有账单需要未支付
     *
     * @author
     */
    private FncContractManagement checkDel(Long fcmId) {
        CheckUtil.isEmptyWithEx(fcmId, ExMsgConstants.RECEIVE_NULL_ID);

        //(1)
        FncContractManagement contract = fncContractManagementService.getById(fcmId);
        if (contract == null || BaseConstants.DR_YES.equals(contract.getDr())) {
            throw ExceptionUtil.idNotExist(fcmId);
        }

        //(2)
        Integer contractState = contract.getFcmContractState();
        if (!NewContractStateEnum.LEASE_SUSPENSION.getState().equals(contractState)
        ) {
            throw new GlobalException("操作失败, 只有【已撤销】的合同才能删除");
        }

        return contract;
    }

    /**
     * 计算 [固定/不固定] 租金, 校验方法
     *
     * @author
     */
    private void checkCalRentTotal(RentCalculationDto dto) {
        CheckUtil.isEmptyWithEx(dto, ExMsgConstants.RECEIVE_NULL_ENTITY);
        CheckUtil.isEmptyWithEx(dto.getFcmLeaseCount(), ExMsgConstants.RECEIVE_NULL_ENTITY + "-租期");

        //不固定, 才校验VariableRentDto
        if (dto.getFcmLeaseAmount() == null) {
            List<RentCalculationDto.VariableRentDto> rentDtoList = dto.getVariableRentDtoList();
            if (rentDtoList == null || rentDtoList.isEmpty()) {
                throw new GlobalException(ExMsgConstants.RECEIVE_NULL_PARA);
            }

            //空校验, 范围校验
            for (RentCalculationDto.VariableRentDto rentDto : rentDtoList) {
                Integer startMonth = rentDto.getFccStartMonth();
                Integer endMonth = rentDto.getFccEndMonth();
                Double rentAmount = rentDto.getFccRentAmount();
                CheckUtil.isEmptyWithEx(startMonth, ExMsgConstants.RECEIVE_NULL_PARA + "(开始月)");
                CheckUtil.isEmptyWithEx(endMonth, ExMsgConstants.RECEIVE_NULL_PARA + "(结束月)");
                CheckUtil.isEmptyWithEx(rentAmount, ExMsgConstants.RECEIVE_NULL_PARA + "(租金)");
                if (startMonth <= 0) {
                    throw new GlobalException("数据异常, 不固定租金开始月不能小于等于0");
                }
                if (endMonth <= 0) {
                    throw new GlobalException("数据异常, 不固定租金结束月不能小于等于0");
                }
                if (rentAmount <= 0.0) {
                    throw new GlobalException("单个不固定租金不能小于等于0");
                }
            }

            //起始月排序, 默认按照这种顺序校验
            rentDtoList = rentDtoList.stream()
                    .sorted(Comparator.comparing(RentCalculationDto.VariableRentDto::getFccStartMonth))
                    .collect(Collectors.toList());
            //格式校验
            int min = 1;
            int max = dto.getFcmLeaseCount();
            String err = "操作失败, 不固定租金格式错误";
            for (int i = 0; i < rentDtoList.size(); i++) {
                //当前
                RentCalculationDto.VariableRentDto rentDtoNow = rentDtoList.get(i);
                //下一个
                RentCalculationDto.VariableRentDto rentDtoNxt =
                        (i == rentDtoList.size() - 1) ? (null) : (rentDtoList.get(i + 1));

                Integer startMonthNow = rentDtoNow.getFccStartMonth();
                Integer endMonthNow = rentDtoNow.getFccEndMonth();

                //第一个数据, 起始月必须为1
                if (i == 0 && startMonthNow != min) {
                    throw new GlobalException(err);
                }
                //最后一个数据, 结束月必须为"租期"
                if (i == rentDtoList.size() - 1 && endMonthNow != max) {
                    throw new GlobalException(err);
                }
                //首尾对应校验
                if (rentDtoNxt != null && !endMonthNow.equals(rentDtoNxt.getFccStartMonth() - 1)) {
                    throw new GlobalException(err);
                }
                //结算不能小于开始
                if (startMonthNow > endMonthNow) {
                    throw new GlobalException(err);
                }
            }
        }
    }


    /**
     * 根据逾期天数获取账单
     */
    public List<FncManagementRiskDto> getOverdue(Integer day) {
        List<ManagementRiskDto> overdue = fncContractManagementService.getOverdue(day);
        return ListUtil.copyBeanList(overdue, FncManagementRiskDto.class);
    }

    /**
     * 撤销
     *
     * @param workflowId
     * @param resone
     */
    public Object back(Long workflowId, String resone) {
        CheckUtil.isEmptyWithEx(workflowId, "合同主键不能为空");
        CheckUtil.isEmptyWithEx(resone, "撤销原因不能为空");
        FncContractManagement contractManagement = fncContractManagementService.getById(workflowId);
        CheckUtil.isEmptyWithEx(contractManagement, "合同数据异常");
        if (!NewContractStateEnum.LEASE_TO_START.getState().equals(contractManagement.getFcmContractState())) {
            throw new GlobalException("该状态下的合同不能撤销！");
        }
        contractManagement.setFcmContractState(NewContractStateEnum.LEASE_SUSPENSION.getState());
        contractManagement.setRemark(resone);
        fncContractManagementService.update(contractManagement);
        return null;
    }

    /**
     * 结束合同
     *
     * @param workflowId
     * @return
     */
    public Object finish(Long workflowId) {
        CheckUtil.isEmptyWithEx(workflowId, "合同主键不能为空");
        FncContractManagement contractManagement = fncContractManagementService.getById(workflowId);
        CheckUtil.isEmptyWithEx(contractManagement, "合同数据异常");
        if (!NewContractStateEnum.LEASED.getState().equals(contractManagement.getFcmContractState())) {
            throw new GlobalException("该状态下的合同不能结束！");
        }
        if (!SettlementStateEnum.CLEARED.getState().equals(contractManagement.getFcmSettlementState())) {
            throw new GlobalException("只有已结清下的合同能结束！");
        }
        //所有订单
        List<LaeOrderManagementDto> laeOrderManagementDtos = leaseOrderClient.findByLomAssociatedContractId(String.valueOf(contractManagement.getFcmId())).getDataWithEx();

        if (!CollectionUtils.isEmpty(laeOrderManagementDtos)) {
            Integer data = workflowClient.selectByOrderId(StringUtils.join(laeOrderManagementDtos.stream().map(LaeOrderManagementDto::getLomId).collect(Collectors.toList()), ",")).getDataWithEx();
            if (data != 1) {
                throw new GlobalException("车辆状态为全部已退回时，才可以结束合同！");
            }
        }
        contractManagement.setFcmContractState(NewContractStateEnum.LEASE_TO_END.getState());
        fncContractManagementService.update(contractManagement);
        return null;
    }


    /**
     * 修改校验
     *
     * @param entity
     */
    private void checkUpdateLease(ContractAddOrUpdateVo entity) {
        CheckUtil.isEmptyWithEx(entity, ExMsgConstants.RECEIVE_NULL_ENTITY);

        //车辆及费用信息
        List<FncRentalFeesDto> rentalFees = entity.getRentalFees();
        //取消租金包含费用必填

        //合同的主体信息
        //车辆交车地址
        Long cityId = entity.getFcmDeliverCity();

        //车辆归还地点
        Long returnCity = entity.getFcmReturnCity();

        //合同签订地点
        Long fcmSignedAddr = entity.getFcmSignedAddr();

        //车辆性质
        String carNature = entity.getFcmCarNature();

        //合同类型
        //车型
        Long carType = entity.getFcmCarTypeId();

        //是否可转租
        Integer fcmSublet = entity.getFcmSublet();

        //用途
        String fcmUse = entity.getFcmUse();

        //车辆交付方式
        Integer fcmDeliverType = entity.getFcmDeliverType();
        //租赁期数
        Integer fcmLeaseCount = entity.getFcmLeaseCount();
        //合同类型
        Integer contractType = entity.getFcmContractType();
        //合同号   有则代表审批通过，无则代表审批中
        String contractNo = entity.getFcmContractNo();
        //出租方
        Long partyaId = entity.getFcmPartyaId();
        //承租方
        Integer partybId = entity.getFcmPartybType();
        //承租方 类型
        Integer partybType = entity.getFcmPartybType();
        Date signedDate = entity.getFcmSignedDate();
        //车辆总数
        Integer carnumTotal = entity.getFcmCarnumTotal();
        //租赁起始类型(固定/不固定)
        Integer leaseStartType = entity.getFcmLeaseStartType();
        //租赁起始日期
        Date leaseStartDate = entity.getFcmLeaseStartDate();
        //租赁到期日期
        Date leaseEndDate = entity.getFcmLeaseEndDate();
        //租赁类型
        Integer leaseType = entity.getFcmLeaseType();
        //租金（元/月/辆）
        Double leaseAmount = entity.getFcmLeaseAmount();
        //租金支付周期
        Integer rentPayType = entity.getFcmRentPayType();
        //租金支付周期(每月支付等)
        Integer rentPayCycle = entity.getFcmRentPayCycle();
        //账单生成类型
        Integer billGenerateType = entity.getFcmBillGenerateType();
        //账单截止类型
        Integer billCatOffType = entity.getFcmBillCatoffType();

        //履约保证金类型 0无 1总额 2单车
        Integer fcmMarginType = entity.getFcmMarginType();
        //履约保证金总额    (单车或者总额)
        Double fcmMarginMoney = entity.getFcmMarginMoney();
        //保证金支付方式 0无 1交车前一次性支付 2分批支付
        Integer fcmMarginPayRequire = entity.getFcmMarginPayRequire();


        //公共字段非空校验
        CheckUtil.isEmptyWithEx(fcmMarginPayRequire, ExMsgConstants.RECEIVE_NULL_PARA + "-保证金支付方式");
        CheckUtil.isEmptyWithEx(fcmMarginMoney, ExMsgConstants.RECEIVE_NULL_PARA + "-履约保证金");
        CheckUtil.isEmptyWithEx(fcmMarginType, ExMsgConstants.RECEIVE_NULL_PARA + "-履约保证金类型");
        CheckUtil.isEmptyWithEx(cityId, ExMsgConstants.RECEIVE_NULL_PARA + "-车辆交付地点");
        CheckUtil.isEmptyWithEx(fcmLeaseCount, ExMsgConstants.RECEIVE_NULL_PARA + "-租赁期数");
        CheckUtil.isEmptyWithEx(fcmDeliverType, ExMsgConstants.RECEIVE_NULL_PARA + "-车辆交付方式");
        CheckUtil.isEmptyWithEx(fcmSignedAddr, ExMsgConstants.RECEIVE_NULL_PARA + "-合同签订地点");
        CheckUtil.isEmptyWithEx(fcmUse, ExMsgConstants.RECEIVE_NULL_PARA + "-用途");
        CheckUtil.isEmptyWithEx(fcmSublet, ExMsgConstants.RECEIVE_NULL_PARA + "-是否转租");
        CheckUtil.isEmptyWithEx(returnCity, ExMsgConstants.RECEIVE_NULL_PARA + "-车辆归还地点");
        CheckUtil.isEmptyWithEx(carType, ExMsgConstants.RECEIVE_NULL_PARA + "-车型");
        CheckUtil.isEmptyWithEx(contractType, ExMsgConstants.RECEIVE_NULL_PARA + "-合同类型");
        CheckUtil.isEmptyWithEx(partyaId, ExMsgConstants.RECEIVE_NULL_PARA + "-出租方id");
        CheckUtil.isEmptyWithEx(partybId, ExMsgConstants.RECEIVE_NULL_PARA + "-承租方id");
        CheckUtil.isEmptyWithEx(partybType, ExMsgConstants.RECEIVE_NULL_PARA + "-承租方类型");
        CheckUtil.isEmptyWithEx(signedDate, ExMsgConstants.RECEIVE_NULL_PARA + "-签订日期");
        CheckUtil.isEmptyWithEx(carnumTotal, ExMsgConstants.RECEIVE_NULL_PARA + "-车辆总数");
        CheckUtil.isEmptyWithEx(fcmLeaseCount, ExMsgConstants.RECEIVE_NULL_PARA + "-租期");
        CheckUtil.isEmptyWithEx(leaseStartType, ExMsgConstants.RECEIVE_NULL_PARA + "-开始类型");
        CheckUtil.isEmptyWithEx(leaseType, ExMsgConstants.RECEIVE_NULL_PARA + "-租赁类型");
        CheckUtil.isEmptyWithEx(rentPayType, ExMsgConstants.RECEIVE_NULL_PARA + "-租金支付类型");
        CheckUtil.isEmptyWithEx(rentPayCycle, ExMsgConstants.RECEIVE_NULL_PARA + "-租金支付周期");
        CheckUtil.isEmptyWithEx(billGenerateType, ExMsgConstants.RECEIVE_NULL_PARA + "-账单生成类型");
        CheckUtil.isEmptyWithEx(billCatOffType, ExMsgConstants.RECEIVE_NULL_PARA + "-账单截止日期");
        CheckUtil.isEmptyWithEx(leaseAmount, ExMsgConstants.RECEIVE_NULL_PARA + "-租金（元/月/辆）");
        CheckUtil.isEmptyWithEx(carNature, ExMsgConstants.RECEIVE_NULL_PARA + "-车辆性质");

        //城市id
        List<AuthCity> cityList = authCityClient.getCityByIds(cityId + "," + returnCity + "," + fcmSignedAddr + "").getDataWithEx();
        if (cityList == null || cityList.isEmpty()) {
            throw ExceptionUtil.notExist("地点id", cityId);
        }
        if (CollectionUtils.isEmpty(cityList.stream().filter(x -> x.getId().equals(cityId)).collect(Collectors.toList()))) {
            throw ExceptionUtil.notExist("车辆交车地点", cityId);
        }
        if (CollectionUtils.isEmpty(cityList.stream().filter(x -> x.getId().equals(returnCity)).collect(Collectors.toList()))) {
            throw ExceptionUtil.notExist("车辆归还地点", cityId);
        }
        if (CollectionUtils.isEmpty(cityList.stream().filter(x -> x.getId().equals(fcmSignedAddr)).collect(Collectors.toList()))) {
            throw ExceptionUtil.notExist("合同签订地点", cityId);
        }

        //合同类型枚举
        String contractTypeName = NewContractTypeEnum.getText(contractType);
        if (contractTypeName == null) {
            throw ExceptionUtil.enumNotExist("合同类型");
        }
        //甲乙方合同类型
        String partybTypeName = ContractPartyTypeEnum.getName(partybType);
        if ("".equals(partybTypeName)) {
            throw ExceptionUtil.enumNotExist("承租方的类型");
        }
        //甲/乙方id
        AuthDept dept = authDeptClient.getAuthDeptById(partyaId).getDataWithEx();
        if (dept == null) {
            throw ExceptionUtil.notExist("出租方id", partyaId);
        }

        if (ContractPartyTypeEnum.PERSONAL.getValue().equals(partybType)) {
            MrkMember member = memberClient.findByid(Long.valueOf(partybId)).getDataWithEx();
            if (member == null) {
                throw ExceptionUtil.notExist("承租方id", partybId);
            }
        } else {
            AuthDept authDept = authDeptClient.getAuthDeptById(Long.valueOf(partybId)).getDataWithEx();
            if (authDept == null) {
                throw ExceptionUtil.notExist("承租方id", partybId);
            }
        }
        //车辆数
        if (carnumTotal <= 0) {
            throw new GlobalException("数据异常, 车辆总数不能小于等于0");
        }
        //租期/租金相关
        if (fcmLeaseCount <= 0) {
            throw new GlobalException("数据异常, 租期不能小于等于0");
        }
        //起始/结束日期
        if (ContractLeaseStartTypeEnum.DELIVERY_DATE.getValue().equals(leaseStartType)) {
            //起始类型为"交车日期", 账单生成日期不能为"交车开始前"
            if (NewBillDateTypeEnum.BEFORE.getValue().equals(billGenerateType)) {
                throw new GlobalException("操作失败, 起始类型为[交车日期], 账单生成日期不能为[交车开始前]");
            }
        } else if (ContractLeaseStartTypeEnum.IDENTIFIED_DATE.getValue().equals(leaseStartType)) {
            CheckUtil.isEmptyWithEx(leaseStartDate, ExMsgConstants.RECEIVE_NULL_PARA + "起始日期");
            CheckUtil.isEmptyWithEx(leaseEndDate, ExMsgConstants.RECEIVE_NULL_PARA + "结束日期");
        } else {
            throw ExceptionUtil.enumNotExist("租赁起始类型");
        }
        //租金支付周期类型
        if ("".equals(ContractRentPayTypeEnum.getName(rentPayType))) {
            throw ExceptionUtil.enumNotExist("租金支付周期类型");
        }
        //租金支付周期
        if (null == ContractRentPaymentCycleEnum.getText(rentPayCycle)) {
            throw ExceptionUtil.enumNotExist("租金支付周期");
        }


        //保证金支付要求类型
        if ("".equals(ContractMarginPayRequireEnum.getName(fcmMarginPayRequire))) {
            throw ExceptionUtil.enumNotExist("保证金支付要求");
        }
        //车型
        SysCarType sysCarType = sysCarTypeClient.getById(entity.getFcmCarTypeId()).getDataWithEx();
        if (CheckUtil.isEmpty(sysCarType)) {
            throw ExceptionUtil.enumNotExist("车型");
        }
        //租金包含费用
        if (rentalFees != null && !rentalFees.isEmpty()) {
            for (FncRentalFeesDto rentalFee : rentalFees) {
                CheckUtil.isEmptyWithEx(rentalFee.getFrfId(), ExMsgConstants.RECEIVE_NULL_PARA + "(包含费用-id)");
                CheckUtil.isEmptyWithEx(rentalFee.getFrfWrite(), ExMsgConstants.RECEIVE_NULL_PARA + "(包含费用-是否可填)");
                CheckUtil.isEmptyWithEx(rentalFee.getFrfName(), ExMsgConstants.RECEIVE_NULL_PARA + "(包含费用-名称)");
                if (BaseConstants.STATUS_ENABLE.equals(rentalFee.getFrfWrite())) {
                    CheckUtil.isEmptyWithEx(rentalFee.getFrfValue(), ExMsgConstants.RECEIVE_NULL_PARA + "(包含费用-值)");
                    if (new BigDecimal(rentalFee.getFrfValue()).compareTo(BigDecimal.ZERO) <= 0.0) {
                        throw new GlobalException("数据异常, 租金包含费用不能小于等于0");
                    }
                }
            }
        }
        //开始结束范围合法
        if (leaseStartDate != null && leaseEndDate != null && leaseStartDate.after(leaseEndDate)) {
            throw new GlobalException("数据异常, 合同的租赁[起始日期]必须小于[结束日期]");
        }
        //账单生成日类型
        if ("".equals(NewBillDateTypeEnum.getName(billGenerateType))) {
            throw ExceptionUtil.enumNotExist("账单生成日类型");
        }
        //账单截止日类型
        if ("".equals(NewBillDateTypeEnum.getName(billCatOffType))) {
            throw ExceptionUtil.enumNotExist("账单截止日类型");
        }
    }
}
