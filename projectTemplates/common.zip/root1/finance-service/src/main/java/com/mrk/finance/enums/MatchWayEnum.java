package com.mrk.finance.enums;

import lombok.Getter;

/**
 * @project: mrk-finance
 * @author: Frank.Tang
 * @date: 2021-11-11 09:54
 * @desc: 账单/流水匹配方式
 **/
@Getter
public enum MatchWayEnum {

    /***/
    MANUAL(0, "手动匹配"),
    AUTO(1, "自动匹配");

    private Integer value;
    private String name;

    MatchWayEnum(Integer value, String name) {
        this.value = value;
        this.name = name;
    }

    public static String getName(Integer state) {
        if (state == null) {
            return "";
        }
        for (MatchWayEnum statusEnum : values()) {
            if (statusEnum.getValue().equals(state)) {
                return statusEnum.getName();
            }
        }
        return "";
    }

}
