package com.mrk.finance.facade;

import com.mrk.common.constant.BaseConstants;
import com.mrk.common.exception.GlobalException;
import com.mrk.common.utils.container.ListUtil;
import com.mrk.common.utils.text.CheckUtil;
import com.mrk.finance.constants.ExMsgConstants;
import com.mrk.finance.constants.LenConstants;
import com.mrk.finance.model.FncContractRentalFees;
import com.mrk.finance.model.FncRentalFees;
import com.mrk.finance.queryvo.FncContractRentalFeesQueryVo;
import com.mrk.finance.service.FncContractManagementService;
import com.mrk.finance.service.FncContractRentalFeesService;
import com.mrk.finance.service.FncRentalFeesService;
import com.mrk.finance.util.ExceptionUtil;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

/**
 * @project: mrk-finance
 * @author: Frank.Tang
 * @date: 2021-11-10 17:43
 * @desc: 租金包含费用
 *
 * 租金包含费用, 相关方法汇总:
 *     (1)新增--{@link FncRentalFeesFacade\#add}
 *     (2)修改--{@link FncRentalFeesFacade\#update}
 *     (3)删除--{@link FncRentalFeesFacade\#deleteLogically}
 *
 **/
@Slf4j
@Component
public class FncRentalFeesFacade {

    @Autowired
    private FncRentalFeesService fncRentalFeesService;
    @Autowired
    private FncContractRentalFeesService fncContractRentalFeesService;
    @Autowired
    private FncContractManagementService fncContractManagementService;


    /**
     * 租金包含费用: 新增
     * @author Frank.Tang
     * @param entity 前端传的实体类
     * @return *
     */
    @Transactional(rollbackFor = Exception.class)
    public int add(FncRentalFees entity) {
        //check
        checkAdd(entity);
        return fncRentalFeesService.add(entity);
    }

    /**
     * 租金包含费用: 修改
     * @author Frank.Tang
     * @param entity 前端传的实体类
     * @return *
     */
    @Transactional(rollbackFor = Exception.class)
    public int update(FncRentalFees entity) {
        //check
        checkUpdate(entity);
        return fncRentalFeesService.updateSelective(entity);
    }


    /**
     * 租金包含费用: 删除(逻辑删)
     * @author Frank.Tang
     * @param id 对象的id
     * @return *
     */
    @Transactional(rollbackFor = Exception.class)
    public int deleteLogically(Long id) {
        //check
        checkDelete(id);
        return fncRentalFeesService.deleteLogically(id);
    }


    /********************************************************************************************
     *                                            checks
     ********************************************************************************************
     **
     * 校验: 新增数据
     *   (1)检查是否接到数据  (2)检查关键元素是否为空
     *   (3)检查名称重复性    (4)检查是否可填(仅限0/1)  (5)长度
     * @author Frank.Tang
     */
    private void checkAdd(FncRentalFees entity) {
        //(1)
        CheckUtil.isEmptyWithEx(entity, ExMsgConstants.RECEIVE_NULL_ENTITY);

        String mark = entity.getFrfMark();
        String name = entity.getFrfName();
        Integer write = entity.getFrfWrite();

        //(2)
        CheckUtil.isEmptyWithEx(mark, ExceptionUtil.nullMsg("标识"));
        CheckUtil.isEmptyWithEx(name, ExceptionUtil.nullMsg("名称"));
        CheckUtil.isEmptyWithEx(write, ExceptionUtil.nullMsg("是否可填"));

        //(3)
        List<FncRentalFees> fees = fncRentalFeesService.selectByName(name);
        if (!fees.isEmpty()) {
            throw new GlobalException("操作失败, 名称【" + name + "】已存在, 不能重复添加");
        }

        //(4)
        if (!BaseConstants.STATUS_ENABLE.equals(write) && !BaseConstants.STATUS_DISABLE.equals(write)) {
            throw new GlobalException("数据异常, 是否可填只能为: 0或1");
        }

        //(5)
        if (mark.length() > LenConstants.LEN_50) {
            throw ExceptionUtil.outLen("标识");
        }
        if (name.length() > LenConstants.LEN_50) {
            throw ExceptionUtil.outLen("名称");
        }
    }

    /**
     * 校验: 更新
     *   (1)检查是否接到数据        (2)是否传了id
     *   (3)数据库是否有对应的数据  (4)超长
     *   (5)数据正确性             (6)名称不重复
     *   (7)存在使用
     * @author Frank.Tang
     */
    private void checkUpdate(FncRentalFees entity) {
        //(1)
        CheckUtil.isEmptyWithEx(entity, ExMsgConstants.RECEIVE_NULL_ENTITY);
        //(2)
        CheckUtil.isEmptyWithEx(entity.getFrfId(), ExMsgConstants.RECEIVE_NULL_ID);
        //(3)
        FncRentalFees rentalFees = fncRentalFeesService.getById(entity.getFrfId());
        if (rentalFees == null || BaseConstants.DR_YES.equals(rentalFees.getDr())) {
            throw new GlobalException(ExceptionUtil.idNotExistMsg(entity.getFrfId()));
        }
        //(4)
        String mark = entity.getFrfMark();
        String name = entity.getFrfName();
        String remark = entity.getRemark();
        Integer write = entity.getFrfWrite();
        if (mark != null && mark.length() > LenConstants.LEN_50) {
            throw ExceptionUtil.outLen("标识");
        }
        if (name != null && name.length() > LenConstants.LEN_50) {
            throw ExceptionUtil.outLen("名称");
        }
        if (remark != null && remark.length() > LenConstants.LEN_255) {
            throw ExceptionUtil.outLen("备注");
        }
        //(5)
        if (!BaseConstants.STATUS_ENABLE.equals(write) && !BaseConstants.STATUS_DISABLE.equals(write)) {
            throw new GlobalException("数据异常, 是否可填只能为: 0或1");
        }
        //(6)
        if (name != null) {
            List<FncRentalFees> fees = fncRentalFeesService.selectByName(name);
            ListUtil.updateOnlyCheckWithEx(fees, entity.getFrfId(), "操作失败, 名称【" + name + "】已存在");
        }
        //(7)
        FncContractRentalFeesQueryVo queryVo = new FncContractRentalFeesQueryVo();
        queryVo.setFcrfRentFeesIdEqualTo(entity.getFrfId());
        List<FncContractRentalFees> feesList = fncContractRentalFeesService.list(queryVo);
        if (!feesList.isEmpty()) {
            throw new GlobalException("操作失败, 该数据存在关联合同");
        }
    }

    /**
     * 校验: 删除
     *   (1)是否传了id  (2)数据库是否有对应的数据  (3)存在使用
     * @author Frank.Tang
     */
    private void checkDelete(Long id) {
        //(1)
        CheckUtil.isEmptyWithEx(id, ExMsgConstants.RECEIVE_NULL_ID);
        //(2)
        FncRentalFees rentalFees = fncRentalFeesService.getById(id);
        if (rentalFees == null || BaseConstants.DR_YES.equals(rentalFees.getDr())) {
            throw ExceptionUtil.idNotExist(id);
        }
        //(3)
        FncContractRentalFeesQueryVo queryVo = new FncContractRentalFeesQueryVo();
        queryVo.setFcrfRentFeesIdEqualTo(id);
        List<FncContractRentalFees> feesList = fncContractRentalFeesService.list(queryVo);
        if (!feesList.isEmpty()) {
            throw new GlobalException("操作失败, 该数据存在关联合同");
        }
    }

}
