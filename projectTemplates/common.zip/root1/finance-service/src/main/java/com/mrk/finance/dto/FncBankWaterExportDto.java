package com.mrk.finance.dto;

import cn.afterturn.easypoi.excel.annotation.Excel;
import lombok.Data;

import java.util.Date;

/**
 * @project: mrk-finance
 * @author: Frank.Tang
 * @date: 2021-11-16 15:16
 * @desc:
 **/
@Data
public class FncBankWaterExportDto {
    @Excel(name = "凭证号")
    private String fncVoucherNo;

    @Excel(name = "本方账号")
    private String fncOwnAccount;

    @Excel(name = "对方账号")
    private String fncOtherAccount;

    @Excel(name = "对方单位名称")
    private String fncOtherUnitName;

    @Excel(name = "交易时间", exportFormat = "yyyy-MM-dd HH:mm:ss" )
    private Date fncDealTime;

    @Excel(name = "借/贷")
    private String fncLoanType;

    @Excel(name = "借方发生额")
    private Double fncBorrowAmount;

    @Excel(name = "贷方发生额")
    private Double fncCreditAmount;

    @Excel(name = "用途")
    private String fncUse;

    @Excel(name = "摘要")
    private String fncDigest;

    /**错误信息 */
    @Excel(name = "错误信息")
    private String fncErrorMsg;

}
