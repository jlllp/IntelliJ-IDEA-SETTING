package com.mrk.finance.facade.quartz;

import com.mrk.auth.client.AuthDeptClient;
import com.mrk.auth.model.AuthDept;
import com.mrk.common.exception.GlobalException;
import com.mrk.finance.dto.contract.RentCalculationDto;
import com.mrk.finance.dto.date.TimeRightDto;
import com.mrk.finance.enums.BillSubjectsEnum;
import com.mrk.finance.enums.ContractRentPayTypeEnum;
import com.mrk.finance.enums.ContractStateEnum;
import com.mrk.finance.facade.contract.ContractFacade;
import com.mrk.finance.model.FncBillManagement;
import com.mrk.finance.model.FncConfirmIncome;
import com.mrk.finance.model.FncContractManagement;
import com.mrk.finance.service.FncBillManagementService;
import com.mrk.finance.service.FncConfirmIncomeService;
import com.mrk.finance.service.FncContractManagementService;
import com.mrk.finance.util.StreamUtil;
import com.mrk.finance.util.ThreadUtil;
import com.mrk.finance.util.contract.ContractDateCalculateUtil;
import org.apache.commons.collections4.CollectionUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Component;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.*;
import java.util.concurrent.Executor;
import java.util.stream.Collectors;

/**
 * @author Bob
 * @date 2021-11-24
 * @description
 */
@Component
public class ConfirmedIncomeFacade {

    private static final Logger log = LoggerFactory.getLogger(ConfirmedIncomeFacade.class);

    @Autowired
    private AuthDeptClient authDeptClient;

    @Autowired
    private FncBillManagementService fncBillManagementService;

    @Autowired
    private FncContractManagementService fncContractManagementService;

    @Autowired
    private FncConfirmIncomeService fncConfirmIncomeService;

    @Autowired
    private ContractFacade contractFacade;

    @Autowired
    @Qualifier("quartzServiceExecutor")
    private Executor executor;

    /**
     * @param paramStr 请求参数
     * @author Bob
     * @date 2021/11/24
     * @description 计算确认收入
     */
    public void incomeCalculation(String paramStr) {
        log.info("计算确认收入 --> 开始");
        long start = System.currentTimeMillis();
        // 获取所有的资产所有者
        List<AuthDept> ownerDeptList = authDeptClient.getAuthDeptByDeptType("auth_type_owner").getDataWithEx();
        log.info("计算确认收入 获取到资产所有者--> size：【{}】", ownerDeptList.size());
        if (CollectionUtils.isEmpty(ownerDeptList)) {
            return;
        }
        for (AuthDept authDept : ownerDeptList) {
            // 计算每个资产所有者的收入
            try {
                organizationCalculation(authDept);
            } catch (Exception e) {
                log.error("计算资产所有者的确认收入失败 --> deptName：【{}】", authDept.getDeptName(), e);
            }
        }
        log.info("计算确认收入 --> 开始 耗时：【{}】", System.currentTimeMillis() - start);
    }

    /**
     * @param authDept 待计算收入的资产所有者
     * @author Bob
     * @date 2021/11/24
     * @description 根据资产所有者进行计算
     */
    private void organizationCalculation(AuthDept authDept) {

        // 获取该组织下的合同
        List<FncContractManagement> contractManagementList = fncContractManagementService.getByPartyA(authDept.getId());
        if (CollectionUtils.isEmpty(contractManagementList)) {
            log.warn("计算确认收入 资产所有者没有对应的合同， 跳过--> deptName：【{}】", authDept.getDeptName());
            return;
        }
        List<Long> contractIdList = StreamUtil.toList(contractManagementList, FncContractManagement::getFcmId);

        // 获取当前月的违约金收入
        // 违约金 指非租金、保证金、购车尾款外的其他科目的收入
        // 账单截止日为本月

        Date today = ContractDateCalculateUtil.ignoreHoursMinutesAndSeconds(new Date());
        Date aMonthAgo = ContractDateCalculateUtil.increaseMonth(today, -1);
        // 上月第一天
        Date firstDayOfMonth = ContractDateCalculateUtil.getFirstDayOfMonth(aMonthAgo);
        // 上月最后一天
        Date lastDayOfMonth = ContractDateCalculateUtil.getLastDayOfMonth(aMonthAgo);
        // 本月第一天
        Date firstDayOfNextMonth = ContractDateCalculateUtil.increaseDay(lastDayOfMonth, 1);
        List<Integer> doesNotContain = Arrays.asList(BillSubjectsEnum.RENT.getValue(),
                BillSubjectsEnum.BALANCE.getValue(), BillSubjectsEnum.BOND.getValue());
        List<FncBillManagement> fncBillManagements = fncBillManagementService.getByContractIdAndNoSubjectAndCatoff(contractIdList, doesNotContain, firstDayOfMonth, firstDayOfNextMonth);
        log.info("计算确认收入 获取到违约金账单 --> deptName：【{}】 size：【{}】", authDept.getDeptName(), fncBillManagements.size());

        // 计算违约金
        BigDecimal liquidatedDamages = totalBillAmount(fncBillManagements);
        log.info("计算确认收入 计算出本月违约金收入 --> deptName：【{}】 liquidatedDamages：【{}】", authDept.getDeptName(), liquidatedDamages.doubleValue());

        // 购车尾款收入
        fncBillManagements = fncBillManagementService.getByContractIdAndSubjectAndCatoff(contractIdList, BillSubjectsEnum.BALANCE.getValue(), firstDayOfMonth, firstDayOfNextMonth);
        log.info("计算确认收入 获取到购车尾款账单 --> deptName：【{}】 size：【{}】", authDept.getDeptName(), fncBillManagements.size());
        BigDecimal endOfTheCarPurchase = totalBillAmount(fncBillManagements);
        log.info("计算确认收入 计算出本月购车尾款收入 --> deptName：【{}】 liquidatedDamages：【{}】", authDept.getDeptName(), endOfTheCarPurchase.doubleValue());

        // 获取需要计算的租金合同
        List<FncContractManagement> calculateRentContract = getRentalContract(contractManagementList, firstDayOfMonth, lastDayOfMonth);
        log.info("计算确认收入 获取到计算租金的合同 --> deptName：【{}】 calculateRentContract：【{}】", authDept.getDeptName(), calculateRentContract.size());
        List<BigDecimal> rentalIncomeList = ThreadUtil.executeAndGetResults(calculateRentContract, this::getRentThisMonth, executor);
        BigDecimal rentalIncomeThisMonth = rentalIncomeList.stream()
                .reduce(BigDecimal::add)
                .orElse(new BigDecimal("0.0"));
        log.info("计算确认收入 计算出本月租金收入 --> deptName：【{}】 liquidatedDamages：【{}】", authDept.getDeptName(), rentalIncomeThisMonth.doubleValue());

        FncConfirmIncome fncConfirmIncome = new FncConfirmIncome();
        fncConfirmIncome.setFciDeptId(authDept.getId());
        fncConfirmIncome.setFciIncomeMonth(ContractDateCalculateUtil.getYearMonth(aMonthAgo));
        fncConfirmIncome.setFciRentIncome(rentalIncomeThisMonth.doubleValue());
        fncConfirmIncome.setFciPenaltyIncome(liquidatedDamages.doubleValue());
        fncConfirmIncome.setFciCarPurchaseIncome(endOfTheCarPurchase.doubleValue());
        // 总收入
        BigDecimal total = liquidatedDamages.add(endOfTheCarPurchase).add(rentalIncomeThisMonth);
        log.info("计算确认收入 计算出本月总收入 --> deptName：【{}】 liquidatedDamages：【{}】", authDept.getDeptName(), total.doubleValue());
        fncConfirmIncome.setFciTotalIncome(total.doubleValue());
        // 总金额为0 不创建
        if (0 > BigDecimal.ZERO.compareTo(BigDecimal.valueOf(fncConfirmIncome.getFciTotalIncome()))) {
            fncConfirmIncomeService.add(fncConfirmIncome);
        }
    }

    /**
     * @param fncContractManagement 合同
     * @return 计算本月租金收入
     * @author Bob
     * @date 2021/11/24
     * @description 计算本月租金收入
     */
    private BigDecimal getRentThisMonth(FncContractManagement fncContractManagement) {
        Integer fcmCarnumTotal = fncContractManagement.getFcmCarnumTotal();
        if (Objects.isNull(fcmCarnumTotal)) {
            log.error("计算确认收入 合同车辆总数为空，计算收入错误 --> contractId：【{}】", fncContractManagement.getFcmId());
            throw new GlobalException("合同车辆总数为空，计算收入错误 合同id：" + fncContractManagement.getFcmId());
        }
        BigDecimal carnum = BigDecimal.valueOf(fcmCarnumTotal);
        // 获取每月租期时间对
        Integer leaseCount = contractFacade.getLeaseCount(fncContractManagement);
        // 获取每个月的租赁开始结束时间
        SortedMap<Integer, TimeRightDto> leaseTermMap = ContractDateCalculateUtil.calculateThePaymentPeriod
                (fncContractManagement.getFcmLeaseStartDate(), leaseCount, fncContractManagement.getFcmRentPayType(), 1);
        // 获取每月金额
        RentCalculationDto rentCalculationDto = contractFacade.transformRentCalculationDto(fncContractManagement);
        SortedMap<Integer, Double> rentCorrespondenceMap = contractFacade.getTheCorrespondingRent(rentCalculationDto);

        // 获取该月的第一天和最后一天
        Date date = ContractDateCalculateUtil.ignoreHoursMinutesAndSeconds(new Date());
        Date aMonthAgo = ContractDateCalculateUtil.increaseMonth(date, -1);
        Date firstDayOfMonth = ContractDateCalculateUtil.getFirstDayOfMonth(aMonthAgo);
        Date lastDayOfMonth = ContractDateCalculateUtil.getLastDayOfMonth(aMonthAgo);
        // 获取自然天数  算实际覆盖天数金额的时候使用

        // 自然周期
        if (ContractRentPayTypeEnum.NATURAL.getValue().equals(fncContractManagement.getFcmRentPayType())) {
            BigDecimal naturalRent = getNaturalRent(leaseTermMap, rentCorrespondenceMap, firstDayOfMonth, lastDayOfMonth);
            return naturalRent.multiply(carnum);
        }
        // 相对周期
        else if (ContractRentPayTypeEnum.RELATIVE.getValue().equals(fncContractManagement.getFcmRentPayType())) {
            BigDecimal relativeRent = getRelativeRent(leaseTermMap, rentCorrespondenceMap, firstDayOfMonth, lastDayOfMonth);
            return relativeRent.multiply(carnum);
        }
        return new BigDecimal("0.0");
    }

    /**
     * @param leaseTermMap          周期map
     * @param rentCorrespondenceMap 周期租金map
     * @param firstDayOfMonth       指定月第一天
     * @param lastDayOfMonth        指定月最后一天
     * @return 自然周期下合同的本月租金
     * @author Bob
     * @date 2021/11/25
     * @description 自然周期获取本月租金
     */
    private BigDecimal getRelativeRent(SortedMap<Integer, TimeRightDto> leaseTermMap, SortedMap<Integer, Double> rentCorrespondenceMap, Date firstDayOfMonth, Date lastDayOfMonth) {
        BigDecimal accumulate = new BigDecimal("0.00");
        // 当前月自然天数大于28天取30  反之28
        int totalDay = ContractDateCalculateUtil.getActualMaximum(firstDayOfMonth) > 28 ? 30 : 28;
        for (Map.Entry<Integer, TimeRightDto> entry : leaseTermMap.entrySet()) {
            TimeRightDto timeRightDto = entry.getValue();
            // 判断结束时间是否在本月内
            if (!firstDayOfMonth.after(timeRightDto.getEnd()) && !timeRightDto.getEnd().after(lastDayOfMonth)) {
                Double amount = rentCorrespondenceMap.get(entry.getKey());
                // 本月开始时间 = 周期开始时间
                // 这种情况 属于满月
                if (firstDayOfMonth.compareTo(timeRightDto.getStart()) == 0) {
                    return BigDecimal.valueOf(amount);
                }
                // 获取实际使用天数
                // 本月第一天和周期结束时间计算出实际使用天数
                // +1 当天也要计算
                int useDays = ContractDateCalculateUtil.daysBetween(firstDayOfMonth, timeRightDto.getEnd()) + 1;
                // 费用 = 本月租金费用 / 当月总天数 * 实际使用天数
                BigDecimal cost = BigDecimal.valueOf(amount).multiply(BigDecimal.valueOf(useDays))
                        .divide(BigDecimal.valueOf(totalDay), 2, RoundingMode.HALF_UP);
                accumulate = accumulate.add(cost);
            }

            // 判断开始时间是否在本月内 跟上面很类似
            if (!firstDayOfMonth.after(timeRightDto.getStart()) && !timeRightDto.getStart().after(lastDayOfMonth)) {
                Double amount = rentCorrespondenceMap.get(entry.getKey());
                // 获取实际使用天数
                // 周期的开始时间到本月的最后一天计算出实际使用天数
                // +1 当天也要计算
                int useDays = ContractDateCalculateUtil.daysBetween(timeRightDto.getStart(), lastDayOfMonth) + 1;
                // 费用 = 本月租金费用 / 当月总天数 * 实际使用天数
                BigDecimal cost = BigDecimal.valueOf(amount).multiply(BigDecimal.valueOf(useDays))
                        .divide(BigDecimal.valueOf(totalDay), 2, RoundingMode.HALF_UP);
                accumulate = accumulate.add(cost);
                return accumulate;
            }
        }
        return accumulate;
    }

    /**
     * @param leaseTermMap          周期map
     * @param rentCorrespondenceMap 周期租金map
     * @param firstDayOfMonth       指定月第一天
     * @param lastDayOfMonth        指定月最后一天
     * @return 自然周期下合同的本月租金
     * @author Bob
     * @date 2021/11/25
     * @description 自然周期获取本月租金
     */
    private BigDecimal getNaturalRent(SortedMap<Integer, TimeRightDto> leaseTermMap, SortedMap<Integer, Double> rentCorrespondenceMap, Date firstDayOfMonth, Date lastDayOfMonth) {
        for (Map.Entry<Integer, TimeRightDto> entry : leaseTermMap.entrySet()) {
            TimeRightDto timeRightDto = entry.getValue();
            // 本月第一天 小于等于 周期开始时间            周期开始时间 小于等于 本月最后一天
            // 满足这个情况即周期对上了
            if (!firstDayOfMonth.after(timeRightDto.getStart()) && !timeRightDto.getStart().after(lastDayOfMonth)) {
                // 自然后期只看周期开始时间是不是第一天
                // 是第一天直接取整月租金
                // 不是 则计算实际覆盖天数对应的金额
                Double amount = rentCorrespondenceMap.get(entry.getKey());
                return contractFacade.firstMonthRent(timeRightDto, new BigDecimal("0.00"), amount);

            }
        }
        // 没有找到 返回0
        return new BigDecimal("0.0");
    }

    /**
     * @param contractManagementList 合同
     * @param firstDayOfMonth        上月第一天
     * @param lastDayOfMonth         上月最后一天
     * @return 要计算当月租金的合同
     * @author Bob
     * @date 2021/11/24
     * @description 获取要计算当月租金的合同
     */
    private List<FncContractManagement> getRentalContract(List<FncContractManagement> contractManagementList, Date firstDayOfMonth, Date lastDayOfMonth) {
        // 本月租金计算
        // 过滤合同数据
        // 保留 符合条件的合同
        //
        List<Integer> complianceStatus = Arrays.asList(ContractStateEnum.LEASED.getState(), ContractStateEnum.LEASE_TO_END.getState());
        return contractManagementList.stream().filter(item -> {
            boolean contains = complianceStatus.contains(item.getFcmContractState());
            // 合同开始时间小于等于第一天 最后一天 小于等于合同结束时间
            boolean startEndMatch = !item.getFcmLeaseStartDate().after(firstDayOfMonth) && !lastDayOfMonth.after(item.getFcmLeaseEndDate());
            // 合同开始时间 在当前月份范围内
            boolean startTime = !firstDayOfMonth.after(item.getFcmLeaseStartDate()) && !item.getFcmLeaseStartDate().after(lastDayOfMonth);
            // 合同结束时间 在当前月份范围内
            boolean endTime = !firstDayOfMonth.after(item.getFcmLeaseEndDate()) && !item.getFcmLeaseEndDate().after(lastDayOfMonth);
            // 以上条件满足任意一个即可
            boolean timeMatch = startEndMatch || startTime || endTime;
            return contains && timeMatch;
        }).collect(Collectors.toList());
    }

    /**
     * @param fncBillManagements 待计算的账单
     * @return 违约金收入
     * @author Bob
     * @date 2021/11/24
     * @description 计算违约金
     */
    private BigDecimal totalBillAmount(List<FncBillManagement> fncBillManagements) {
        BigDecimal bigDecimal = new BigDecimal("0.0");
        // 计算公式
        // 计算本月违约金收入
        if (CollectionUtils.isNotEmpty(fncBillManagements)) {
            for (FncBillManagement billManagement : fncBillManagements) {
                // 租金相加
                bigDecimal = bigDecimal.add(BigDecimal.valueOf(billManagement.getFbmBillAmount()));
            }
        }
        return bigDecimal;
    }
}
