package com.mrk.finance.facade.quartz;

import com.mrk.finance.enums.BillStateEnum;
import com.mrk.finance.enums.ContractStateEnum;
import com.mrk.finance.enums.SettlementStateEnum;
import com.mrk.finance.model.FncBillManagement;
import com.mrk.finance.model.FncContractManagement;
import com.mrk.finance.service.FncBillManagementService;
import com.mrk.finance.service.FncContractManagementService;
import com.mrk.finance.util.StreamUtil;
import com.mrk.finance.util.ThreadUtil;
import com.mrk.finance.util.contract.ContractDateCalculateUtil;
import org.apache.commons.collections4.CollectionUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Component;

import java.util.Arrays;
import java.util.Date;
import java.util.List;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.Executor;

/**
 * @author Bob
 * @date 2021-11-12
 * @description
 */
@Component
public class ContractCalculateFacade {

    private static final Logger log = LoggerFactory.getLogger(ContractCalculateFacade.class);

    @Autowired
    private FncContractManagementService fncContractManagementService;

    @Autowired
    private FncBillManagementService fncBillManagementService;

    @Autowired
    @Qualifier("quartzServiceExecutor")
    private Executor executor;

    /**
     * @author Bob
     * @date 2021/11/12
     * @description 计算合同状态
     * @param paramStr 请求参数 json格式字符串
     */
    public void calculateContractState(String paramStr) {
        log.info("计算合同状态定时任务 --> 开始");
        long startTime = System.currentTimeMillis();
        // 处理租赁待开始状态的合同变更到租赁中

        // 获取租赁是今天开始的合同
        Date nowDate = ContractDateCalculateUtil.ignoreHoursMinutesAndSeconds(new Date());
        // 获取到今天开始的合同
        List<FncContractManagement> contractManagementList = fncContractManagementService.getStateAndStartDate(ContractStateEnum.LEASE_TO_START.getState(), nowDate);
        log.info("计算合同状态定时任务 获取到租赁待开始状态下并且租赁起始时间为今天的合同数量 --> size：【{}】", contractManagementList.size());

        if (CollectionUtils.isNotEmpty(contractManagementList)) {
            // 获取所有的id
            List<Long> contractIdList = StreamUtil.toList(contractManagementList, FncContractManagement::getFcmId);
            // 批量更新合同的状态
            fncContractManagementService.updateStateByIdList(ContractStateEnum.LEASED.getState(), contractIdList);
        }

        // 处理租赁中的合同状态变更为租赁结束
        Date yesterday = ContractDateCalculateUtil.increaseDay(nowDate, -1);
        contractManagementList = fncContractManagementService.getStateAndEndDate(ContractStateEnum.LEASED.getState(), yesterday);
        log.info("计算合同状态定时任务 获取到租赁待中状态下并且租赁结束时间为昨天的合同 --> size：【{}】", contractManagementList.size());
        if (CollectionUtils.isNotEmpty(contractManagementList)) {
            // 获取所有的id
            List<Long> contractIdList = StreamUtil.toList(contractManagementList, FncContractManagement::getFcmId);
            // 批量更新合同的状态
            fncContractManagementService.updateStateByIdList(ContractStateEnum.LEASE_TO_END.getState(), contractIdList);
        }
        log.info("计算合同状态定时任务 --> 结束  耗时：【{}】", System.currentTimeMillis() - startTime);
    }

    /**
     * @author Bob
     * @date 2021/11/12
     * @description 计算结算状态
     * @param paramStr 请求参数 json格式字符串
     */
    public void calculateSettlementState(String paramStr) {
        log.info("计算结算状态定时任务 --> 开始");
        long startTime = System.currentTimeMillis();
        // 获取租赁结束结算状态为未结清状态下的合同
        // 获取两天前的日期 因为保证金退还账单是租赁结束后第二天才生成
        Date nowDay = ContractDateCalculateUtil.ignoreHoursMinutesAndSeconds(new Date());
        Date twoDaysAgo = ContractDateCalculateUtil.increaseDay(nowDay, -2);
        List<FncContractManagement> contractManagementList = fncContractManagementService.getStateInAndSettlementAndEndLTOE(Arrays.asList(ContractStateEnum.LEASE_TO_END.getState(),
                ContractStateEnum.LEASE_SUSPENSION.getState()), SettlementStateEnum.OUTSTANDING.getState(), twoDaysAgo);
        if (CollectionUtils.isEmpty(contractManagementList)) {
            log.info("计算结算状态定时任务 没有获取到需要检查账单的合同 --> 结束");
            return;
        }
        log.info("计算结算状态定时任务 获取到未结清状态下的合同 --> size：【{}】", contractManagementList.size());
        // 多线程处理
        ThreadUtil.execution(contractManagementList, this::processSettlementStatus,  executor);
        log.info("计算结算状态定时任务 --> 结束 耗时：【{}】", System.currentTimeMillis() - startTime);
    }

    /**
     * @author Bob
     * @date 2021/11/17
     * @description 计算状态计算定时任务
     * @param countDownLatch 同步工具
     * @param fncContractManagement 待检查结算状态的合同
     */
    private void processSettlementStatus(CountDownLatch countDownLatch, FncContractManagement fncContractManagement){
        Long contractId = fncContractManagement.getFcmId();
        log.info("计算结算状态定时任务 检查合同结算开始 --> ID：【{}】", contractId);
        try {
            // 获取所有的账单
            List<FncBillManagement> fncBillManagements = fncBillManagementService.getByContractId(contractId);
            // 如果没有账单跳过， 不可能没有账单
            if (CollectionUtils.isEmpty(fncBillManagements)) {
                log.info("计算结算状态定时任务 未找到账单，跳过 --> ID：【{}】", contractId);
                return;
            }
            // 将能看作 '已支付状态' 的结算状态装入一个集合中
            List<Integer> complianceStatusList = Arrays.asList(BillStateEnum.PAID_ALL.getValue(), BillStateEnum.INVOICING.getValue(),
                    BillStateEnum.INVOICED.getValue(), BillStateEnum.REJECTED.getValue());
            // 判断当前合同的所有账单状态是否和 '已支付状态' 集合匹配
            boolean matchResult = fncBillManagements.stream().allMatch(fncBillManagement -> complianceStatusList.contains(fncBillManagement.getFbmBillState()));
            log.info("计算结算状态定时任务 获取到结算状态结果 --> ID：【{}】 matchResult：【{}】", contractId, matchResult);
            // 所有账单都已 结清
            if (matchResult) {
                // 更新合同
                fncContractManagement.setFcmSettlementState(SettlementStateEnum.CLEARED.getState());
                fncContractManagementService.update(fncContractManagement);
                log.info("计算结算状态定时任务 更新合同的结算状态为已完成 --> ID：【{}】", contractId);
            }
            log.info("计算结算状态定时任务 检查合同结算结束 --> ID：【{}】", contractId);
        } finally {
            countDownLatch.countDown();
        }
    }
}
