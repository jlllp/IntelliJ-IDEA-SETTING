package com.mrk.finance.enums;

import lombok.Getter;

/**
 * @project: mrk-finance
 * @author: Frank.Tang
 * @date: 2021-11-15 10:27
 * @desc: 账单[生成日/截止日]类型
 **/
@Getter
public enum BillDateTypeEnum {

    /***/
    BEFORE(0, "租赁周期开始前"),
    NOW(1, "租赁周期开始当天"),
    AFTER(2, "租赁周期开始后"),
    FINISHED(3, "租赁周期结束后");

    private Integer value;
    private String name;

    BillDateTypeEnum(Integer value, String name) {
        this.value = value;
        this.name = name;
    }

    public static String getName(Integer state) {
        if (state == null) {
            return "";
        }
        for (BillDateTypeEnum statusEnum : values()) {
            if (statusEnum.getValue().equals(state)) {
                return statusEnum.getName();
            }
        }
        return "";
    }

}
