package com.mrk.finance.facade.ttwithhold;

import cn.afterturn.easypoi.excel.ExcelExportUtil;
import cn.afterturn.easypoi.excel.ExcelImportUtil;
import cn.afterturn.easypoi.excel.entity.ExportParams;
import cn.afterturn.easypoi.excel.entity.ImportParams;
import cn.afterturn.easypoi.excel.entity.result.ExcelImportResult;
import com.github.pagehelper.PageInfo;
import com.mrk.auth.client.AuthDeptClient;
import com.mrk.auth.model.AuthCity;
import com.mrk.common.constant.BaseConstants;
import com.mrk.common.exception.GlobalException;
import com.mrk.common.utils.bean.BeanUtils;
import com.mrk.common.utils.container.ListUtil;
import com.mrk.common.utils.jwt.JWTUtil;
import com.mrk.common.utils.redis.RedisUtil;
import com.mrk.common.utils.text.CheckUtil;
import com.mrk.finance.dto.fncttexport.FncTtWithholdDto;
import com.mrk.finance.dto.fncttexport.FncTtWithholdExportByQueryDto;
import com.mrk.finance.dto.fncttexport.FncTtWithholdExportDto;
import com.mrk.finance.enums.MatchWayEnum;
import com.mrk.finance.enums.WaterMatchStateEnum;
import com.mrk.finance.facade.CarExportFacade;
import com.mrk.finance.facade.ExportFacade;
import com.mrk.finance.facade.FncWaterAutoMatchFacade;
import com.mrk.finance.model.FncDdWithhold;
import com.mrk.finance.model.FncTemp;
import com.mrk.finance.model.FncTtWithhold;
import com.mrk.finance.queryvo.FncTtWithholdQueryVo;
import com.mrk.finance.service.FncTempService;
import com.mrk.finance.service.FncTtWithholdService;
import com.mrk.finance.util.StreamUtil;
import com.mrk.finance.vo.ttwithhold.FncTtWithholdImportVo;
import com.mrk.resource.client.ResCarQueryClient;
import com.mrk.resource.model.ResCar;
import org.apache.poi.hssf.usermodel.HSSFCellStyle;
import org.apache.poi.hssf.util.HSSFColor;
import org.apache.poi.ss.usermodel.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.CollectionUtils;
import org.springframework.web.multipart.MultipartFile;

import javax.servlet.http.HttpServletResponse;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.concurrent.TimeUnit;
import java.util.regex.Pattern;
import java.util.stream.Collectors;

/**
 * @ClassName ResCarScrapImportFacade
 * @Author Vllos
 * @Date 2021-04-19 14:56
 * @Version 1.0
 */
@Component
public class FncWithholdImportFacade {

    private static final Logger log = LoggerFactory.getLogger(FncWithholdImportFacade.class);
    @Autowired
    private FncTempService fncTempService;
    @Autowired
    private RedisUtil redisUtil;

    @Autowired
    private CarExportFacade exportByExcel;

    @Autowired
    private FncWaterAutoMatchFacade fncWaterAutoMatchFacade;
    @Autowired
    private ExportFacade exportFacade;

    @Autowired
    private AuthDeptClient authDeptClient;

    @Autowired
    private ResCarQueryClient resCarQueryClient;

    @Autowired
    private FncTtWithholdFacade fncTtWithholdFacade;
    @Autowired
    private FncTtWithholdService fncTtWithholdService;
    /**
     * @description 导入文件
     */
    @Transactional(rollbackFor = Exception.class)
    public void importFile(MultipartFile file, String operateCode) {
        String userName = JWTUtil.getNikeName();
        log.info("开始导入设备数据，操作人 --> userName：【{}】", userName);
        // 删除操作标识中的数据
        fncTempService.deleteByOperateCode(operateCode);
        // 读取excel中的文件
        List<FncTtWithholdImportVo> fncTtWithholdImportVos = this.resCarScrapImportVoList(file);
        if(CollectionUtils.isEmpty(fncTtWithholdImportVos)){
            throw new GlobalException("导入数据错误");
        }
        // 处理数据
        this.dispose(fncTtWithholdImportVos, operateCode);
    }

    /**
     * @description 获取excel文件中的数据
     */
    private List<FncTtWithholdImportVo> resCarScrapImportVoList(MultipartFile file) {
        try {
            ExcelImportResult<FncTtWithholdImportVo> result = ExcelImportUtil.importExcelMore
                    (file.getInputStream(), FncTtWithholdImportVo.class, new ImportParams());
            return result.getList();
        } catch (Exception e) {
            log.error("获取excel文件中的数据", e);
            throw new GlobalException("解析文件失败，请检查数据");
        }
    }

    /**
     * @date 2021/3/29 17:21
     * @description 处理Excel中的数据
     */
    private void dispose(List<FncTtWithholdImportVo> fncTtWithholdImportVos, String operateCode) {
        int total = fncTtWithholdImportVos.size();
        for (int i = 0; i < fncTtWithholdImportVos.size(); i++) {
            FncTtWithholdImportVo fncTtWithholdImportVo = fncTtWithholdImportVos.get(i);
            // 检查数据是否是空 空的就跳过
            if (!this.checkIsNull(fncTtWithholdImportVo)) {
                // 保存数据
                this.doSave(fncTtWithholdImportVo, operateCode);
            }
            // 修改进度 百分比
            int schedule = (i + 1) * 100 / total;
            final String key = scheduleKey(operateCode);
            // 设置有效时间
            redisUtil.set(key, String.valueOf(schedule));
            redisUtil.expire(key, 30, TimeUnit.SECONDS);
        }
    }

    /**
     * @description 检查重要的数据是否为空
     */
    private boolean checkIsNull(FncTtWithholdImportVo fncTtWithholdImportVo) {
        // 检查重要数据是否都为空 为空则认为空数据
        return CheckUtil.isEmpty(fncTtWithholdImportVo.getFncMonthWithhold())
                && CheckUtil.isEmpty(fncTtWithholdImportVo.getFncAgreementNumber())
                && CheckUtil.isEmpty(fncTtWithholdImportVo.getFncCarVin())
              && CheckUtil.isEmpty(fncTtWithholdImportVo.getFncCity())
              && CheckUtil.isEmpty(fncTtWithholdImportVo.getFncIdnumber())
              && CheckUtil.isEmpty(fncTtWithholdImportVo.getFncName())
              && CheckUtil.isEmpty(fncTtWithholdImportVo.getFncMonthRentBalance())
              && CheckUtil.isEmpty(fncTtWithholdImportVo.getFncRentDate())
              && CheckUtil.isEmpty(fncTtWithholdImportVo.getFncLeaseCount())
              && CheckUtil.isEmpty(fncTtWithholdImportVo.getFncMonthRent());
    }

    /**
     * @description 保存数据
     */
    private void doSave(FncTtWithholdImportVo fncTtWithholdImportVo, String operateCode) {


        if(CheckUtil.isNotEmpty(fncTtWithholdImportVo.getFncMonthWithholdStr())){
            fncTtWithholdImportVo.setFncMonthWithhold(Double.valueOf(fncTtWithholdImportVo.getFncMonthWithholdStr().replace(",","")));
        }
        if(CheckUtil.isNotEmpty(fncTtWithholdImportVo.getFncMonthRentStr())){
            fncTtWithholdImportVo.setFncMonthRent(Double.valueOf(fncTtWithholdImportVo.getFncMonthRentStr().replace(",","")));
        }
        if(CheckUtil.isNotEmpty(fncTtWithholdImportVo.getFncMonthRentBalanceStr())){
            fncTtWithholdImportVo.setFncMonthRentBalance(Double.valueOf(fncTtWithholdImportVo.getFncMonthRentBalanceStr().replace(",","")));
        }
        FncTemp fncTemp = BeanUtils.copyBean(fncTtWithholdImportVo, FncTemp.class);
        StringBuilder sb = new StringBuilder();
        fncTemp.setFncOperateCode(operateCode);
        //身份证号
        String regex = "\\d{15}(\\d{2}[0-9xX])?";
        //车架号
        String pattern = "^[A-HJ-NPR-Z\\d]{17}#[[\$]]#";
        if(CheckUtil.isEmpty(fncTtWithholdImportVo.getFncCarVin())){
            sb.append("车架号为空，");
        }
        if (CheckUtil.isNotEmpty(fncTtWithholdImportVo.getFncCarVin()) && !Pattern.matches(pattern, fncTtWithholdImportVo.getFncCarVin().toUpperCase())) {
            sb.append("输入的车架号不规范，");
        }
        if(CheckUtil.isEmpty(fncTtWithholdImportVo.getFncIdnumber())){
            sb.append("身份证号码为空，");
        }
        if(CheckUtil.isNotEmpty(fncTtWithholdImportVo.getFncIdnumber()) && !fncTtWithholdImportVo.getFncIdnumber().matches(regex)){
            sb.append("身份证号码格式错误，");
        }
        if(CheckUtil.isEmpty(fncTtWithholdImportVo.getFncCity())){
            sb.append("城市为空，");
        }
        if(CheckUtil.isNotEmpty(fncTtWithholdImportVo.getFncCity())){
            List<AuthCity> authCities = authDeptClient.getAuthCityByCityName(fncTtWithholdImportVo.getFncCity()).getDataWithEx();
            if(CollectionUtils.isEmpty(authCities)){
                sb.append("城市不存在，");
            }
            if(!authCities.stream().map(AuthCity :: getCityName).collect(Collectors.toList()).toString().contains(fncTtWithholdImportVo.getFncCity())){
                sb.append("城市不存在，");
            }
        }
        if (CheckUtil.isEmpty(fncTtWithholdImportVo.getFncMonthWithholdStr())) {
            sb.append("月扣款总额为空，");
        }
        if (CheckUtil.isEmpty(fncTtWithholdImportVo.getFncMonthRentStr())) {
            sb.append("月租金为空，");
        }
        if (CheckUtil.isEmpty(fncTtWithholdImportVo.getFncRentDate())) {
            sb.append("起租日期为空，");
        }
        if (CheckUtil.isEmpty(fncTtWithholdImportVo.getFncLeaseCount())) {
            sb.append("租期为空，");
        }
        if (CheckUtil.isEmpty(fncTtWithholdImportVo.getFncName())) {
            sb.append("姓名为空，");
        }
        if (CheckUtil.isEmpty(fncTtWithholdImportVo.getFncMonthRentBalanceStr())) {
            sb.append("月租金余量为空，");
        }
        //检验车架号是否存在
        List<ResCar> resCarList = resCarQueryClient.findCarByEngineNumPlateNum(fncTtWithholdImportVo.getFncCarVin(), null).getDataWithEx();
        if(CollectionUtils.isEmpty(resCarList)){
            sb.append("车架号不存在，");
        }
        if (CheckUtil.isNotEmpty(sb.toString())) {
            fncTemp.setFncError(1);
            fncTemp.setFncErrorMsg(sb.substring(0, sb.length() - 1));
        } else {
            fncTemp.setFncError(0);
        }
        fncTempService.add(fncTemp);
    }

    /**
     * @description 获取进度的redisKey
     */
    private String scheduleKey(String operateCode) {
        return String.format("schedule:{%s}", operateCode);
    }

    /**
     * @description 根据文件标识符获取处理进度
     */
    public Integer schedule(String operateCode) {
        CheckUtil.isEmptyWithEx(operateCode, "操作标识不能为空");
        String value = redisUtil.get(scheduleKey(operateCode));
        try {
            return Integer.parseInt(value);
        } catch (NumberFormatException e) {
            return 0;
        }
    }

    /**
     * @description 根据标识符获取上传结果
     * 0 正常 1有错误
     */
    public Integer importResult(String operateCode) {
        List<FncTemp> fncTemps = fncTempService.selectErrorByOperateCode(operateCode);
        return fncTemps.isEmpty() ? 0 : 1;
    }

    /**
     * @description 根据标识符下载文件，错误的数据标红
     */
    public void downFile(String operateCode, HttpServletResponse response) {
        // 根据标识符获取设备数据
        List<FncTemp> fncTemps = fncTempService.selectByOperateCode(operateCode);
        List<FncTtWithholdExportDto> boxDownVos = new ArrayList<>();
        for (FncTemp fncTemp : fncTemps) {
            FncTtWithholdExportDto fncTtWithholdExportDto = BeanUtils.copyBean(fncTemp, FncTtWithholdExportDto.class);
            boxDownVos.add(fncTtWithholdExportDto);
        }
        Workbook workbook = ExcelExportUtil.exportExcel(new ExportParams(), FncTtWithholdExportDto.class, boxDownVos);
        // 设置单元格样式
        setExcelStyle(workbook);
        String fileName = "T3明细数据" + System.currentTimeMillis() + ".xls";
        exportByExcel.exportByExcel(response, fileName, workbook);
    }

    /**
     * @description 设置单元格样式
     */
    public void setExcelStyle(Workbook workbook) {
        Sheet sheet = workbook.getSheetAt(0);
        // 创建红色的字体颜色样式
        Font font = workbook.createFont();
        // 字体颜色
        font.setColor(HSSFColor.HSSFColorPredefined.RED.getIndex());
        HSSFCellStyle cellStyle = (HSSFCellStyle) workbook.createCellStyle();
        // 前景色填充
        cellStyle.setFillPattern(FillPatternType.SOLID_FOREGROUND);
        // 前景填充色
        cellStyle.setFillForegroundColor(HSSFColor.HSSFColorPredefined.LEMON_CHIFFON.getIndex());
        // 字体居中
        cellStyle.setAlignment(HorizontalAlignment.CENTER);
        cellStyle.setFont(font);
        for (int i = 1; i <= sheet.getLastRowNum(); i++) {
            Row row = sheet.getRow(i);
            // 获取小标为3的列数据 对应错误数据
            Cell cell;
            String value = row.getCell(10).toString().trim();
            // 说明此列数据错误
            if (CheckUtil.isNotEmpty(value)) {
                final int physicalNumberOfCells = row.getPhysicalNumberOfCells();
                for (int j = 0; j < physicalNumberOfCells; j++) {
                    cell = row.getCell(j);
                    // 设置单元格格式
                    cell.setCellStyle(cellStyle);
                }
            }
        }
    }

    /**
     * @author Bob
     * @date 2021/4/25 15:50
     * @description t3导入明细模板
     * @param httpServletResponse 响应对象
     */
    public void peepareTemplate(HttpServletResponse httpServletResponse) {
        exportFacade.exportByExcel(httpServletResponse, "t3导入明细模板.xls",
          FncTtWithholdImportVo.class, new ArrayList<>());
    }

    /**
     * @author roger
     * @date 2021/3/30 17:15
     * @description 根据查询条件导出excel文件
     */
    public void export(FncTtWithholdQueryVo queryVo, HttpServletResponse response) {
        PageInfo<FncTtWithholdDto> fncTtWithholdDtoPageInfo = fncTtWithholdFacade.page(queryVo);
        int maxSize = 50000;
        if (fncTtWithholdDtoPageInfo.getTotal() > maxSize) {
            throw new GlobalException("导出的数量超过5万条，请缩小范围");
        }
        // 导出文件
        List<FncTtWithholdExportByQueryDto> boxUpVoList = ListUtil.copyBeanList(fncTtWithholdDtoPageInfo.getList(), FncTtWithholdExportByQueryDto.class);
        Workbook workbook = ExcelExportUtil.exportExcel(new ExportParams(), FncTtWithholdExportByQueryDto.class, boxUpVoList);
        String fileName = "Tt明细" + System.currentTimeMillis() + ".xls";
        exportByExcel.exportByExcel(response, fileName, workbook);
    }

    /**
     * @description 根据操作标识确定导入
     */
    @Transactional(rollbackFor = Exception.class)
    public void confirmImport(String operateCode) {
        List<FncTemp> fncTempList = fncTempService.selectErrorByOperateCode(operateCode);
        if (!fncTempList.isEmpty()) {
            throw new GlobalException("当前文件存在错误数据，不能导入");
        }
        fncTempList = fncTempService.selectByOperateCode(operateCode);
        //导入数据
        List<FncTtWithhold> fncTtWithholdList = new ArrayList<>();
        FncTtWithhold fncTtWithhold;
        for (FncTemp fncTemp : fncTempList) {
            fncTtWithhold = new FncTtWithhold();
            //车架号
            fncTtWithhold.setFtwCarVin(fncTemp.getFncCarVin());
            //城市id
            if(CheckUtil.isNotEmpty(fncTemp.getFncCity())){
                List<AuthCity> authCities = authDeptClient.getAuthCityByCityName(fncTemp.getFncCity()).getDataWithEx();
                if(!CollectionUtils.isEmpty(authCities)){
                    List<AuthCity> cityList = authCities.stream().filter(x -> fncTemp.getFncCity().equals(x.getCityName())).collect(Collectors.toList());
                    if(!CollectionUtils.isEmpty(cityList)){
                        fncTtWithhold.setFtwCityId(cityList.get(0).getId());
                    }
                }
            }
            fncTtWithhold.setFtwName(fncTemp.getFncName());
            fncTtWithhold.setFtwIdnumber(fncTemp.getFncIdnumber());
            fncTtWithhold.setFtwAgreementNumber(fncTemp.getFncAgreementNumber());
            fncTtWithhold.setFtwRentDate(fncTemp.getFncRentDate());
            fncTtWithhold.setFtwLeaseCount(fncTemp.getFncLeaseCount());
            fncTtWithhold.setFtwMonthRent(fncTemp.getFncMonthRent());
            fncTtWithhold.setFtwMonthWithhold(fncTemp.getFncMonthWithhold());
            fncTtWithhold.setFtwMonthRentBalance(fncTemp.getFncMonthRentBalance());

            //检验车架号是否存在
            List<ResCar> resCarList = resCarQueryClient.findCarByEngineNumPlateNum(fncTemp.getFncCarVin(), null).getDataWithEx();
            if(!CollectionUtils.isEmpty(resCarList)){
                fncTtWithhold.setFtwCarModel(resCarList.get(0).getRcCarTypeId());
            }
            //匹配账单   TODO
            fncTtWithhold.setFtwMatchBill(null);
            fncTtWithhold.setFtwMatchedAmount(0.0D);
            fncTtWithhold.setFtwMatchWay(null);
            fncTtWithhold.setFtwMatchState(WaterMatchStateEnum.NOT_MATCH.getValue());
            fncTtWithhold.setFtwNotMatchAmount(fncTemp.getFncMonthWithhold());
            //订单号
            fncTtWithhold.setDr(BaseConstants.DR_NO);
            Date date = new Date();
            fncTtWithhold.setCreatetime(date);
            fncTtWithhold.setUpdatetime(date);
            String userName = JWTUtil.getNikeName();
            fncTtWithhold.setCreateuser(userName);
            fncTtWithhold.setUpdateuser(userName);
            fncTtWithholdList.add(fncTtWithhold);
        }
        if(CollectionUtils.isEmpty(fncTtWithholdList)){
            throw new GlobalException("导入数据为空，请重试");
        }
        int insert = fncTtWithholdService.insertList(fncTtWithholdList);
        if (insert != fncTtWithholdList.size()) {
            throw new GlobalException("导入失败，请重试");
        }

        //自动执行一次匹配
        /*fncWaterAutoMatchFacade.ttAutoMatch(StreamUtil.toList(fncTtWithholdList, FncTtWithhold::getFtwId));*/

        // 删除操作批次下的数据
        fncTempService.deleteByOperateCode(operateCode);
    }
}
