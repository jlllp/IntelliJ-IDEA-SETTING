package com.mrk.finance.facade.bill;

import cn.afterturn.easypoi.excel.ExcelExportUtil;
import cn.afterturn.easypoi.excel.entity.ExportParams;
import com.github.pagehelper.PageInfo;
import com.mrk.common.exception.GlobalException;
import com.mrk.common.utils.container.ListUtil;
import com.mrk.common.utils.jwt.JWTUtil;
import com.mrk.finance.dto.FncBillManagementDto;
import com.mrk.finance.dto.FncBillManagementExportByQueryDto;
import com.mrk.finance.facade.CarExportFacade;
import com.mrk.finance.queryvo.FncBillManagementQueryVo;
import lombok.extern.slf4j.Slf4j;
import org.apache.poi.ss.usermodel.Workbook;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import javax.servlet.http.HttpServletResponse;
import java.util.List;

/**
 * @project: mrk-finance
 * @author: Frank.Tang
 * @date: 2021-11-19 13:53
 * @desc:
 **/
@Slf4j
@Component
public class FncBillManagementImportFacade {

    @Autowired
    private FncBillManagementFacade fncBillManagementFacade;
    @Autowired
    private CarExportFacade exportByExcel;


    /**
     * 导出账单
     * @author Frank.Tang
     */
    public void export(FncBillManagementQueryVo queryVo, HttpServletResponse response) {
        long sTime = System.currentTimeMillis();

        PageInfo<FncBillManagementDto> pageInfo = fncBillManagementFacade.page(queryVo);
        int maxSize = 50000;
        if (pageInfo.getTotal() > maxSize) {
            throw new GlobalException("导出的数量超过5万条，请缩小范围");
        }
        // 导出文件
        List<FncBillManagementExportByQueryDto> boxUpVoList = ListUtil.copyBeanList(pageInfo.getList(), FncBillManagementExportByQueryDto.class);
        Workbook workbook = ExcelExportUtil.exportExcel(new ExportParams(), FncBillManagementExportByQueryDto.class, boxUpVoList);
        String fileName = "账单" + System.currentTimeMillis() + ".xls";
        exportByExcel.exportByExcel(response, fileName, workbook);

        long eTime = System.currentTimeMillis();

        log.info("用户【{}】, 导出账单. 数据量【{}条】, 耗时【{}ms】", JWTUtil.getNikeName(), boxUpVoList.size(), (eTime - sTime));
    }

}
