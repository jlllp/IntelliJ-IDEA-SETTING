package com.mrk.finance.enums.newcontract;

import java.util.Objects;

/**
 * @author
 * @date
 * @description
 */
public enum NewVehicleDeliveryMethodEnum {

    ALL_PARTIAL_DELIVERY(0, "一次性集中交付"),
    PARTIAL_DELIVERY(1, "分批交付");

    private final Integer type;
    private final String text;

    NewVehicleDeliveryMethodEnum(Integer type, String text) {
        this.type = type;
        this.text = text;
    }

    public Integer getType() {
        return type;
    }

    public String getText() {
        return text;
    }

    public static String getText(Integer type) {
        if (Objects.isNull(type)) return null;

        for (NewVehicleDeliveryMethodEnum value : values()) {
            if (value.getType().equals(type)) {
                return value.getText();
            }
        }

        return null;
    }
}
