package com.mrk.finance.constants;

/**
 * @project: mrk-finance
 * @author: Frank.Tang
 * @date: 2021-11-24 16:56
 * @desc:
 **/
public class AutoMatchResConstants {

    private AutoMatchResConstants(){
        throw new IllegalStateException("Utility class");
    }

    /** 匹配结果的描述 **/
    public static final String MATCH_SUCCESS = "成功";

    public static final String MATCH_FAILED = "失败";

    public static final String MATCH_PART_SUCCESS = "部分成功";

}
