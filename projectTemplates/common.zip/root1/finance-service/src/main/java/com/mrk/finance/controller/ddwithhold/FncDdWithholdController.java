package com.mrk.finance.controller.ddwithhold;

import com.github.pagehelper.PageInfo;
import com.mrk.common.utils.page.JsonResult;
import com.mrk.finance.dto.AutoMatchResOfWaterDto;
import com.mrk.finance.dto.fncddexport.FncDdWithholdDto;
import com.mrk.finance.facade.FncWaterAutoMatchFacade;
import com.mrk.finance.facade.ddwithhold.FncDdWithholdFacade;
import com.mrk.finance.model.FncDdWithhold;
import com.mrk.finance.queryvo.FncDdWithholdQueryVo;
import com.mrk.finance.service.FncDdWithholdService;
import com.mrk.finance.vo.BillMatchWaterVo;
import com.mrk.log.annotation.Log;
import com.mrk.log.enums.BusinessType;
import com.mrk.log.enums.OperatorType;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiImplicitParam;
import io.swagger.annotations.ApiImplicitParams;
import io.swagger.annotations.ApiOperation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;


/**
 * FncDdWithholdController

 */
@RestController
@RequestMapping("/financeservice/fncddwithhold")
@Api(tags = "滴滴代扣")
public class FncDdWithholdController {
    @Autowired
    private FncDdWithholdService fncDdWithholdService;
    @Autowired
    private FncWaterAutoMatchFacade fncWaterAutoMatchFacade;
    @Autowired
    private FncDdWithholdFacade fncDdWithholdFacade;

    @PostMapping(value = "/add")
    @ApiOperation("滴滴代扣-新增")
    @ApiImplicitParams({
            @ApiImplicitParam(paramType = "header", name = "Authorization", value = "系统下发的token", required = true)
    })
    @Log(title = "滴滴代扣", value = "合同管理-导出", businessType = BusinessType.INSERT, operatorType = OperatorType.MANAGE)
    public JsonResult<Object>  add(FncDdWithhold entity) {
        return JsonResult.success(fncDdWithholdService.add(entity));
    }

    @PostMapping(value = "/del/{idStr}")
    @ApiOperation("滴滴代扣-删除/批量删除")
    @ApiImplicitParams({
            @ApiImplicitParam(paramType = "header", name = "Authorization", value = "系统下发的token", required = true)
    })
    @Log(title = "滴滴代扣", value = "滴滴代扣-删除/批量删除", businessType = BusinessType.EXPORT, operatorType = OperatorType.MANAGE)
    public JsonResult<Object>  del(@PathVariable("idStr") String idStr) {
        fncDdWithholdFacade.delete(idStr);
        return JsonResult.success();
    }

    @PostMapping(value = "/update")
    @ApiOperation("滴滴代扣-更新")
    @ApiImplicitParams({
            @ApiImplicitParam(paramType = "header", name = "Authorization", value = "系统下发的token", required = true)
    })
    @Log(title = "滴滴代扣", value = "更新", businessType = BusinessType.UPDATE, operatorType = OperatorType.MANAGE)
    public JsonResult<Object>  update(FncDdWithhold entity) {
        return JsonResult.success(fncDdWithholdService.update(entity));
    }


    @GetMapping(value = "/page")
    @ApiOperation("滴滴代扣-分页查询")
    @ApiImplicitParams({
            @ApiImplicitParam(paramType = "header", name = "Authorization", value = "系统下发的token", required = true)
    })
    public JsonResult<PageInfo<FncDdWithholdDto>> page(FncDdWithholdQueryVo queryVo) {
        return JsonResult.success(fncDdWithholdFacade.page(queryVo));
    }

    @GetMapping(value = "/list")
    @ApiOperation("滴滴代扣-列表查询")
    @ApiImplicitParams({
            @ApiImplicitParam(paramType = "header", name = "Authorization", value = "系统下发的token", required = true)
    })
    public JsonResult<List<FncDdWithhold>> list(FncDdWithholdQueryVo queryVo) {
        return JsonResult.success(fncDdWithholdService.list(queryVo));
    }

    @GetMapping(value = "/details")
    @ApiOperation("滴滴代扣-详情")
    @ApiImplicitParams({
      @ApiImplicitParam(paramType = "header", name = "Authorization", value = "系统下发的token", required = true)
    })
    public JsonResult<FncDdWithholdDto> details(Long id) {

        return JsonResult.success(fncDdWithholdFacade.details(id));
    }

    @PostMapping(value = "/price")
    @ApiOperation("dd-手动匹配")
    @ApiImplicitParams({
      @ApiImplicitParam(paramType = "header", name = "Authorization", value = "系统下发的token", required = true)
    })
    @Log(title = "滴滴代扣", value = "手动匹配", businessType = BusinessType.OTHER, operatorType = OperatorType.MANAGE)
    public JsonResult<Object> price(@RequestBody BillMatchWaterVo billMatchWaterVo) {
        fncDdWithholdFacade.price(billMatchWaterVo);
        return JsonResult.success();
    }

    @PostMapping(value = "/match_bill_automatically")
    @ApiOperation("dd-自动匹配")
    @ApiImplicitParams({
            @ApiImplicitParam(paramType = "header", name = "Authorization", value = "系统下发的token", required = true)
    })
    @Log(title = "滴滴代扣", value = "自动匹配", businessType = BusinessType.OTHER, operatorType = OperatorType.MANAGE)
    public JsonResult<List<AutoMatchResOfWaterDto>> autoMatch(@RequestBody List<Long> fdwIds) {
        return JsonResult.success(fncWaterAutoMatchFacade.ddAutoMatch(fdwIds)).setMsg("自动匹配成功, 请查看匹配结果");
    }

}
