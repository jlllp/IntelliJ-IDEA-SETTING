package com.mrk.finance.facade.contract;

import com.mrk.finance.client.dto.ContractAnalysisDto;
import com.mrk.finance.client.dto.ContractMementDto;
import com.mrk.finance.facade.common.CommonFacade;
import com.mrk.finance.model.FncContractCarmodel;
import com.mrk.finance.queryvo.FncContractCarmodelQueryVo;
import com.mrk.finance.service.FncContractCarmodelService;
import com.mrk.finance.service.FncContractManagementService;
import com.mrk.resource.client.ResCarQueryClient;
import com.mrk.workflow.client.Dto.CarPageDto;
import com.mrk.workflow.enums.prepare.PrepareCarStateEnum;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.List;

/**
 * @project mrk-finance
 * @author Frank.Tang
 * @date 2022-03-30 10:59
 * @desc 天眼1.1 -- 合同统计
 **/
@Slf4j
@Component
public class FncContractAnalysisFacade {

    @Autowired
    private ResCarQueryClient resCarQueryClient;
    @Autowired
    private CommonFacade commonFacade;
    @Autowired
    private FncContractCarmodelService fncContractCarmodelService;
    @Autowired
    private FncContractManagementService fncContractManagementService;


    /**
     * 初始化合同临时表(das_contract_analysis)数据, 拿到所有合同+租金金额相关数据
     * @author Frank.Tang
     * @return 统计结果
     */
    public List<ContractAnalysisDto> getContractAnalysisData() {
        //查合同相关字段+租金金额
        List<ContractAnalysisDto> dtos = fncContractManagementService.selectAllStartedContractWithRentAmount();

        return dtos;
    }

    /**
     * 初始化合同车型临时表(das_contract_carmodel_analysis)数据, 拿到所有合同+车辆数相关数据
     * @author Frank.Tang
     * @return 统计结果
     */
    public List<ContractAnalysisDto> getContractCarmodelAnalysisData() {
        //查合同
        List<ContractAnalysisDto> dtos = fncContractManagementService.selectAllStartedContractWithRentAmount();

        return dtos;
    }


    /******************************************************************************************************
     *                                           测试用方法
     ******************************************************************************************************
     **
     * 测试用
     * @author Frank.Tang
     * @return *
     */
    public List<ContractAnalysisDto> getContractAnalysisDataTest(int start, int size) {
        List<ContractAnalysisDto> dtos = fncContractManagementService.selectAllContractWithRentAmountTest(start, size);

        for (ContractAnalysisDto dto : dtos) {
            ContractMementDto queryDto = new ContractMementDto();
            queryDto.setContractId(dto.getDcaContractId());

            FncContractCarmodelQueryVo queryVo = new FncContractCarmodelQueryVo();
            queryVo.setFccContractIdEqualTo(dto.getDcaContractId());
            List<FncContractCarmodel> carmodels = fncContractCarmodelService.list(queryVo);
            long signCount = (carmodels == null || carmodels.isEmpty()) ?
                    0L : carmodels.stream()
                    .map(FncContractCarmodel::getFccCarnum)
                    .reduce(Integer::sum)
                    .map(Long::valueOf)
                    .get();

            List<CarPageDto> carPageDtos = commonFacade.dataSelectByContractStr(queryDto);
            long deliveryCount = (carPageDtos == null || carPageDtos.isEmpty()) ?
                    0L : carPageDtos.stream()
                    .filter(o -> PrepareCarStateEnum.ALREADY_DELIVERED.getState().equals(o.getWpwcCarState()))
                    .count();

            dto.setDcaContractNum(signCount);
            dto.setDcaContractDelivery(deliveryCount);
        }

        return dtos;
    }

    /**
     * 初始化合同临时表(das_contract_carmodel_analysis)数据
     * @author Frank.Tang
     * @return 统计结果
     */
    public List<ContractAnalysisDto> getContractCarmodelAnalysisDataTest(int start, int size) {
        //查合同
        List<ContractAnalysisDto> dtos = fncContractManagementService.selectAllContractWithRentAmountTest(start, size);

        return dtos;
    }

}

