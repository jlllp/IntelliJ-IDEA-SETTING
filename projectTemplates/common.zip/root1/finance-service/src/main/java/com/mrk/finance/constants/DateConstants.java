package com.mrk.finance.constants;

/**
 * @project: mrk-finance
 * @author: Frank.Tang
 * @date: 2021-11-17 14:05
 * @desc:
 **/
public class DateConstants {
    private DateConstants() {
        throw new IllegalStateException("Utility class");
    }

    public static final int MIN_MONTH = 1;

    public static final int MAX_MONTH = 12;

}
