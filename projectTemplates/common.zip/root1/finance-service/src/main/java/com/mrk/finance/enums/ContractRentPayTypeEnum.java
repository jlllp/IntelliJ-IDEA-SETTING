package com.mrk.finance.enums;

import lombok.Getter;

/**
 * @project: mrk-finance
 * @author: Frank.Tang
 * @date: 2021-11-15 10:04
 * @desc: 租金支付类型
 **/
@Getter
public enum ContractRentPayTypeEnum {

    /***/
    NATURAL(0, "自然周期"),
    RELATIVE(1, "相对周期");

    private Integer value;
    private String name;

    ContractRentPayTypeEnum(Integer value, String name) {
        this.value = value;
        this.name = name;
    }

    public static String getName(Integer state) {
        if (state == null) {
            return "";
        }
        for (ContractRentPayTypeEnum statusEnum : values()) {
            if (statusEnum.getValue().equals(state)) {
                return statusEnum.getName();
            }
        }
        return "";
    }

}
