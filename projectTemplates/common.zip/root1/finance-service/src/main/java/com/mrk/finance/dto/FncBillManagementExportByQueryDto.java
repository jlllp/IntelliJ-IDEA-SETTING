package com.mrk.finance.dto;

import cn.afterturn.easypoi.excel.annotation.Excel;
import lombok.Data;

/**
 * @project: mrk-finance
 * @author: Frank.Tang
 * @date: 2021-11-19 11:56
 * @desc:
 **/
@Data
public class FncBillManagementExportByQueryDto {

    @Excel(name = "主键")
    private Long fbmId;

    @Excel(name = "城市")
    private String fbmCityName;

    @Excel(name = "科目")
    private String fbmSubjectsName;

    @Excel(name = "账单金额")
    private Double fbmBillAmount;

    @Excel(name = "期数")
    private String fbmNper;

    @Excel(name = "生成方式")
    private String fbmBillGenerateWayName;

    @Excel(name = "账单生成时间", exportFormat = "yyyy-MM-dd HH:mm:ss")
    private java.util.Date fbmBillGenerateTime;

    @Excel(name = "账单截止时间", exportFormat = "yyyy-MM-dd HH:mm:ss")
    private java.util.Date fbmBillCatoffTime;

    @Excel(name = "关联车牌号")
    private String fbmAssociateCarPlateNum;

    @Excel(name = "关联合同号")
    private String fbmAssociateContractNo;

    @Excel(name = "账单状态")
    private String fbmBillStateName;

    @Excel(name = "匹配方式")
    private String fbmMatchWayName;

    @Excel(name = "匹配人姓名")
    private String fbmMatchUserName;

    @Excel(name = "匹配时间", exportFormat = "yyyy-MM-dd HH:mm:ss")
    private java.util.Date fbmMatchTime;

    @Excel(name = "匹配流水号")
    private String fbmMatchSerialNumber;

    @Excel(name = "支付时间", exportFormat = "yyyy-MM-dd HH:mm:ss")
    private java.util.Date fbmPayTime;

    @Excel(name = "已匹配金额")
    private Double fbmMatchedAmount;

    @Excel(name = "未匹配金额")
    private Double fbmNotMatchAmount;

    @Excel(name = "账单生成原因")
    private String fbmBillGenerateReason;

}
