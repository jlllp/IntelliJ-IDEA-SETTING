package com.mrk.finance.vo;

import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import java.math.BigDecimal;

/**
 * @project: mrk-finance
 * @author: Frank.Tang
 * @date: 2021-11-18 17:16
 * @desc: 流水匹配账单
 **/
@Data
public class WaterMatchBillVo {

    @ApiModelProperty("账单id")
    private Long fbmId;

    @ApiModelProperty("银行流水id")
    private Long fbwId;

    @ApiModelProperty("匹配金额")
    private BigDecimal matchMoney;

}
