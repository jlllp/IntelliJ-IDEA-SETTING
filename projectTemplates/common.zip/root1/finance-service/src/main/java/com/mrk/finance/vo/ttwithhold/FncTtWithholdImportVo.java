package com.mrk.finance.vo.ttwithhold;

import cn.afterturn.easypoi.excel.annotation.Excel;
import lombok.Data;

import java.io.Serializable;

@Data
public class FncTtWithholdImportVo implements Serializable {

  /**城市 */
  @Excel(name = "城市")
  private String fncCity;

  /**姓名 */
  @Excel(name = "姓名")
  private String fncName;

  /**身份证号 */
  @Excel(name = "身份证号")
  private String fncIdnumber;

  /**协议编号 */
  @Excel(name = "协议编号")
  private String fncAgreementNumber;

  /**起租日期 */
  @Excel(name = "起租日期",importFormat = "yyyy-MM-dd HH:mm:ss")
  private java.util.Date fncRentDate;

  /**租期 */
  @Excel(name = "租期")
  private Integer fncLeaseCount;


  /**车架号 */
  @Excel(name = "车架号")
  private String fncCarVin;

  /**月租金 */
  @Excel(name = "月租金")
  private String fncMonthRentStr;

  private Double fncMonthRent;

  /**月扣款总额 */
  @Excel(name = "月扣款总额")
  private String fncMonthWithholdStr;

  private Double fncMonthWithhold;

  /**月租金余量 */
  @Excel(name = "月租金余量")
  private String fncMonthRentBalanceStr;

  private Double fncMonthRentBalance;
}
