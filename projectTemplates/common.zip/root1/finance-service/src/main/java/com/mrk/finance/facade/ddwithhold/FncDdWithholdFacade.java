package com.mrk.finance.facade.ddwithhold;

import com.github.pagehelper.PageInfo;
import com.mrk.auth.client.AuthUserClient;
import com.mrk.auth.model.AuthUser;
import com.mrk.common.constant.BaseConstants;
import com.mrk.common.exception.GlobalException;
import com.mrk.common.utils.bean.BeanUtils;
import com.mrk.common.utils.container.ListUtil;
import com.mrk.common.utils.jwt.JWTUtil;
import com.mrk.common.utils.text.CheckUtil;
import com.mrk.common.utils.text.StringUtils;
import com.mrk.finance.dto.fncddexport.FncDdWithholdDto;
import com.mrk.finance.enums.BillStateEnum;
import com.mrk.finance.enums.MatchWayEnum;
import com.mrk.finance.enums.WaterMatchStateEnum;
import com.mrk.finance.enums.WaterMatchTypeEnum;
import com.mrk.finance.facade.common.FinanceUserNameFacade;
import com.mrk.finance.model.FncBillManagement;
import com.mrk.finance.model.FncDdWithhold;
import com.mrk.finance.model.FncRevenueWaterRecord;
import com.mrk.finance.queryvo.FncDdWithholdQueryVo;
import com.mrk.finance.resolver.EnumResolver;
import com.mrk.finance.service.FncBillManagementService;
import com.mrk.finance.service.FncDdWithholdService;
import com.mrk.finance.service.FncRevenueWaterRecordService;
import com.mrk.finance.util.MatchUtil;
import com.mrk.finance.vo.BillMatchWaterVo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigDecimal;
import java.util.Arrays;
import java.util.Date;
import java.util.List;
import java.util.stream.Collectors;

@Component
public class FncDdWithholdFacade {

  @Autowired
  private AuthUserClient authUserClient;
  @Autowired
  private FncDdWithholdService fncDdWithholdService;
  @Autowired
  private FncBillManagementService fncBillManagementService;

  @Autowired
  private FncRevenueWaterRecordService fncRevenueWaterRecordService;

  @Autowired
  private FinanceUserNameFacade financeUserNameFacade;


  /**
   * 分页查询
   * @param queryVo
   * @return
   */
  public PageInfo<FncDdWithholdDto> page(FncDdWithholdQueryVo queryVo) {
    String filterText = StringUtils.camelToUnderlineAndFilterText(queryVo.getSidx());
    queryVo.setSidx(filterText);
    PageInfo<FncDdWithhold> fncDdWithholdPageInfo = fncDdWithholdService.page(queryVo);
    //复制属性
    List<FncDdWithholdDto> fncDdWithholdDtos = ListUtil.copyBeanList(fncDdWithholdPageInfo.getList(), FncDdWithholdDto.class);
    for(FncDdWithholdDto fncDdWithholdDto : fncDdWithholdDtos){
      //匹配状态
      fncDdWithholdDto.setFdwMatchStateText(EnumResolver.匹配状态.get(fncDdWithholdDto.getFdwMatchState()));
      //匹配方式
      fncDdWithholdDto.setFdwMatchWayText(EnumResolver.匹配方式.get(fncDdWithholdDto.getFdwMatchWay()));
    }
    return new PageInfo<>(fncDdWithholdDtos);
  }

  /**
   * 根据主键查询详情
   * @param id
   * @return
   */
  public FncDdWithholdDto details(Long id) {
    CheckUtil.isEmptyWithEx(id, "主键不能为空");
    FncDdWithhold ddWithhold = fncDdWithholdService.getById(id);
    FncDdWithholdDto fncDdWithholdDto = BeanUtils.copyBean(ddWithhold, FncDdWithholdDto.class);
    //匹配状态
    fncDdWithholdDto.setFdwMatchStateText(EnumResolver.匹配状态.get(fncDdWithholdDto.getFdwMatchStateText()));
    //匹配方式
    fncDdWithholdDto.setFdwMatchWayText(EnumResolver.匹配方式.get(fncDdWithholdDto.getFdwMatchWay()));
    return fncDdWithholdDto;
  }

  /**
   * 手动匹配
   * @param billMatchWaterVo
   * @return
   */
  @Transactional(rollbackFor = Exception.class)
  public void price(BillMatchWaterVo billMatchWaterVo) {
    //检验数据
    CheckUtil.isEmptyWithEx(billMatchWaterVo.getWaterId(), "dd主键不能为空");
    CheckUtil.isEmptyWithEx(billMatchWaterVo.getFbmId(), "账单主键不能为空");
    CheckUtil.isEmptyWithEx(billMatchWaterVo.getMatchMoney(), "匹配金额不能为空");
    if(billMatchWaterVo.getMatchMoney().compareTo(BigDecimal.ZERO) < 1){
      throw new GlobalException("匹配金额必须大于0");
    }
    //dd
    FncDdWithhold fncDdWithhold = fncDdWithholdService.getById(billMatchWaterVo.getWaterId());
    CheckUtil.isEmptyWithEx(fncDdWithhold, "滴滴流水不存在");
    //判断状态
    if(WaterMatchStateEnum.ALL_MATCH.getValue().equals(fncDdWithhold.getFdwMatchState())){
      throw new GlobalException("已匹配的dd不能再匹配");
    }
    if(CheckUtil.isEmpty(fncDdWithhold.getFdwMatchedAmount())){
      fncDdWithhold.setFdwMatchedAmount(0.0D);
    }
    //dd未匹配金额
    BigDecimal priceTt = BigDecimal.valueOf(fncDdWithhold.getFdwNotMatchAmount());
    //dd已匹配金额
    BigDecimal priceNotTt = BigDecimal.valueOf(fncDdWithhold.getFdwMatchedAmount());
    if(priceTt.subtract(billMatchWaterVo.getMatchMoney()).compareTo(BigDecimal.ZERO) < 0){
      throw new GlobalException("匹配金额不能大于dd未匹配金额");
    }
    //账单
    FncBillManagement billManagement = fncBillManagementService.getById(billMatchWaterVo.getFbmId());

    CheckUtil.isEmptyWithEx(billManagement, "账单不存在");
    //判断状态
    if(WaterMatchStateEnum.ALL_MATCH.getValue().equals(billManagement.getFbmBillState())){
      throw new GlobalException("选择的账单状态不符合");
    }
    if(CheckUtil.isEmpty(billManagement.getFbmMatchedAmount())){
      billManagement.setFbmMatchedAmount(0.0D);
    }
    //账单未匹配金额
    BigDecimal priceBill = BigDecimal.valueOf(billManagement.getFbmNotMatchAmount());

    //账单金额
    BigDecimal billMoney = BigDecimal.valueOf(billManagement.getFbmBillAmount());
    if(billMoney.compareTo(BigDecimal.ZERO) <= 0){
      throw new GlobalException("不能匹配‘借(负数)’的账单！");
    }
    //账单已匹配金额
    BigDecimal priceNotBill = BigDecimal.valueOf(billManagement.getFbmMatchedAmount());
    if(priceBill.subtract(billMatchWaterVo.getMatchMoney()).compareTo(BigDecimal.ZERO) < 0){
      throw new GlobalException("匹配金额不能大于账单未匹配金额");
    }
    //dd减去匹配金额后的未匹配金额
    fncDdWithhold.setFdwNotMatchAmount(priceTt.subtract(billMatchWaterVo.getMatchMoney()).doubleValue());
    //dd加上匹配金额后的已匹配金额
    fncDdWithhold.setFdwMatchedAmount(priceNotTt.add(billMatchWaterVo.getMatchMoney()).doubleValue());
    //dd匹配状态
    if(priceTt.subtract(billMatchWaterVo.getMatchMoney()).compareTo(BigDecimal.ZERO) == 0){
      fncDdWithhold.setFdwMatchState(WaterMatchStateEnum.ALL_MATCH.getValue());
    }else {
      fncDdWithhold.setFdwMatchState(WaterMatchStateEnum.PART_MATCH.getValue());
    }
    //账单加上匹配金额后的已匹配金额
    billManagement.setFbmMatchedAmount(priceNotBill.add(billMatchWaterVo.getMatchMoney()).doubleValue());
    //账单减去匹配金额后的未匹配金额
    billManagement.setFbmNotMatchAmount(priceBill.subtract(billMatchWaterVo.getMatchMoney()).doubleValue());
    //账单匹配状态
    if(priceBill.subtract(billMatchWaterVo.getMatchMoney()).compareTo(BigDecimal.ZERO) == 0){
      billManagement.setFbmBillState(BillStateEnum.PAID_ALL.getValue());
    }else {
      billManagement.setFbmBillState(BillStateEnum.PAID_PART.getValue());
    }
    String bmMatchSerialNumberStr = MatchUtil.splicing(billManagement.getFbmMatchSerialNumber(),WaterMatchTypeEnum.DD.getName()+fncDdWithhold.getFdwId());
    billManagement.setFbmMatchSerialNumber(
      bmMatchSerialNumberStr
    );
    String ddMatchBillStr = MatchUtil.splicing(fncDdWithhold.getFdwMatchBill(), billManagement.getFbmId());
    fncDdWithhold.setFdwMatchBill(ddMatchBillStr);
    //修改dd
    fncDdWithholdService.update(fncDdWithhold);
    //修改账单
    fncBillManagementService.update(billManagement);
    //更新记录
    saveRecord(billManagement, fncDdWithhold, billMatchWaterVo.getMatchMoney());
  }

  /**
   * 更新流水记录
   * @param billManagement
   * @param fncDdWithhold
   * @param bigDecimal
   */
  public void saveRecord(FncBillManagement billManagement, FncDdWithhold fncDdWithhold, BigDecimal bigDecimal){
    FncRevenueWaterRecord waterRecord = new FncRevenueWaterRecord();
    //记录的描述信息
    waterRecord.setFrwrBillId(billManagement.getFbmId());
    Long userId = JWTUtil.getUserId();
    AuthUser user = authUserClient.getAuthUserById(userId).getDataWithEx();
    String userNamePhone = financeUserNameFacade.getUserNamePhone(user);
    String desc = userNamePhone +
      "发起手动匹配，匹配成功。匹配账单号" +
      billManagement.getFbmId() + "，" +
      "匹配金额" + bigDecimal + "元，" +
      "流水剩余金额" +
      fncDdWithhold.getFdwNotMatchAmount() +
      "元";
    waterRecord.setFrwrDescribe(desc);
    waterRecord.setCreatetime(new Date());
    waterRecord.setFrwrRevenueId(fncDdWithhold.getFdwId());
    waterRecord.setFrwrMatchState(MatchWayEnum.MANUAL.getValue());
    waterRecord.setFrwrRevenueType(WaterMatchTypeEnum.DD.getValue());
    //保存
    fncRevenueWaterRecordService.add(waterRecord);
  }

  /**
   * 批量删除
   * @param idStr
   */
  @Transactional(rollbackFor = Exception.class)
  public void delete(String idStr) {
    CheckUtil.isEmptyWithEx(idStr, "主键不能为空");
    //滴滴id
    List<Long> idList = Arrays.stream(idStr.split(","))
      .map(s -> Long.parseLong(s.trim())).collect(Collectors.toList());
    for(Long id : idList){
      FncDdWithhold fncDdWithhold = fncDdWithholdService.getById(id);
      CheckUtil.isEmptyWithEx(fncDdWithhold, "滴滴代扣不存在");
      if(!WaterMatchStateEnum.NOT_MATCH.getValue().equals(fncDdWithhold.getFdwMatchState())){
          throw new GlobalException("当前状态不可删除");
      }
      fncDdWithhold.setDr(BaseConstants.DR_YES);
      fncDdWithholdService.update(fncDdWithhold);
    }
  }
}
