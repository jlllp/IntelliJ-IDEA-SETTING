package com.mrk.finance.config;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONException;
import com.alibaba.fastjson.JSONObject;
import com.mrk.common.exception.GlobalException;
import feign.Response;
import feign.Util;
import feign.codec.ErrorDecoder;
import lombok.extern.slf4j.Slf4j;
import org.springframework.context.annotation.Configuration;

import java.io.IOException;

/**
 * @program: pp-partent
 * @Description:
 * @Author: Shen.Sun  suntion@yeah.net
 * @create: 2021-02-26 17:33
 **/
@Configuration
@Slf4j
public class FeignErrorDecoder implements ErrorDecoder {

    @Override
    public Exception decode(String methodKey, Response response) {

        // 这里直接拿到我们抛出的异常信息
        String message = "";
        try {
            message = Util.toString(response.body().asReader());
            JSONObject jsonObject = JSON.parseObject(message);
            return new GlobalException(jsonObject.getString("message"));
        } catch (JSONException e) {
            throw new GlobalException(message);
        } catch (IOException e) {
            // io异常不做处理
        }

        return decode(methodKey, response);
    }
}
