package com.mrk.finance.enums;

import lombok.Getter;

/**
 * @project: mrk-finance
 * @author: Frank.Tang
 * @date: 2021-11-18 10:34
 * @desc: 合同: 运营平台 (经营性租赁/自营网约车_新租/自营网约车_续租, 3种情况有这个字段)
 **/
@Getter
public enum ContractOperatePlatformEnum {

    TT(0, "T3"),
    DD(1, "滴滴"),
    GD(2, "高德"),
    OTHER(3, "其它平台");

    private final Integer type;
    private final String name;

    ContractOperatePlatformEnum(Integer type, String name) {
        this.type = type;
        this.name = name;
    }

    public static String getName(Integer type) {
        if (type == null) {
            return "";
        }
        for (ContractOperatePlatformEnum value : values()) {
            if (value.getType().equals(type)) {
                return value.getName();
            }
        }
        return "";
    }

}
