package com.mrk.finance.provider;

// 对方提供client接口 实现类位置