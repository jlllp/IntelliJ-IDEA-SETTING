package com.mrk.finance.facade;

import com.mrk.auth.client.AuthDeptClient;
import com.mrk.auth.client.AuthUserClient;
import com.mrk.auth.model.AuthUser;
import com.mrk.common.base.BaseEntity;
import com.mrk.common.exception.GlobalException;
import com.mrk.common.utils.jwt.JWTUtil;
import com.mrk.common.utils.text.CheckUtil;
import com.mrk.finance.constants.AutoMatchResConstants;
import com.mrk.finance.constants.ExMsgConstants;
import com.mrk.finance.dto.AutoMatchResOfWaterDto;
import com.mrk.finance.enums.*;
import com.mrk.finance.facade.bankwater.FncBankWaterFacade;
import com.mrk.finance.facade.bill.FncBillManagementFacade;
import com.mrk.finance.facade.common.FinanceUserNameFacade;
import com.mrk.finance.facade.ddwithhold.FncDdWithholdFacade;
import com.mrk.finance.facade.dto.WaterIntegrationDto;
import com.mrk.finance.facade.ttwithhold.FncTtWithholdFacade;
import com.mrk.finance.model.*;
import com.mrk.finance.queryvo.FncBillManagementQueryVo;
import com.mrk.finance.service.*;
import com.mrk.finance.util.MatchUtil;
import com.mrk.finance.util.StreamUtil;
import com.mrk.member.client.MemberClient;
import com.mrk.resource.client.ResCarQueryClient;
import com.mrk.resource.model.ResCar;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigDecimal;
import java.util.*;
import java.util.concurrent.CopyOnWriteArrayList;
import java.util.stream.Collectors;

/**
 * @project: mrk-finance
 * @author: Frank.Tang
 * @date: 2021-11-24 15:47
 * @desc: 流水自动匹配账单
 *
 * 一、银行自动匹配{@link FncWaterAutoMatchFacade\#bwAutoMatch}
 *   (1)精确------{@link FncWaterAutoMatchFacade\#bwAutoMatchAccurate}
 *   (2)模糊------{@link FncWaterAutoMatchFacade\#bwAutoMatchFuzzy}
 *
 * 二、滴滴自动匹配{@link FncWaterAutoMatchFacade\#ddAutoMatch}
 *   (1)精确------{@link FncWaterAutoMatchFacade\#ddAutoMatchAccurate}
 *   (2)模糊------{@link FncWaterAutoMatchFacade\#ddAutoMatchFuzzy}
 *
 * 三、T3自动匹配 {@link FncWaterAutoMatchFacade\#ttAutoMatch}
 *   (1)精确------{@link FncWaterAutoMatchFacade\#ttAutoMatchAccurate}
 *   (2)模糊------{@link FncWaterAutoMatchFacade\#ttAutoMatchFuzzy}
 *
 * 四、6种匹配方式, 查找账单方法
 *   (1)精确匹配
 *       1.银行--{@link FncWaterAutoMatchFacade\#selectBillOfBwAccurate}
 *       2.滴滴--{@link FncWaterAutoMatchFacade\#selectBillOfDwAccurate}
 *       3.T3----{@link FncWaterAutoMatchFacade\#selectBillOfTwAccurate}
 *   (2)模糊匹配
 *       1.银行--{@link FncWaterAutoMatchFacade\#selectBillOfBwFuzzy}
 *       2.滴滴--{@link FncWaterAutoMatchFacade\#selectBillOfDwFuzzy}
 *       3.T3----{@link FncWaterAutoMatchFacade\#selectBillOfTwFuzzy}
 *
 **/
@Slf4j
@Component
@SuppressWarnings("unused")
public class FncWaterAutoMatchFacade {

    @Autowired
    private FncBankWaterService fncBankWaterService;
    @Autowired
    private FncDdWithholdService fncDdWithholdService;
    @Autowired
    private FncTtWithholdService fncTtWithholdService;
    @Autowired
    private FncBillManagementService fncBillManagementService;
    @Autowired
    private FncContractManagementService fncContractManagementService;
    @Autowired
    private FncRevenueWaterRecordService fncRevenueWaterRecordService;
    @Autowired
    private AuthDeptClient authDeptClient;
    @Autowired
    private ResCarQueryClient resCarQueryClient;
    @Autowired
    private MemberClient memberClient;
    @Autowired
    private AuthUserClient authUserClient;
    @Autowired
    private FncBillManagementFacade fncBillManagementFacade;
    @Autowired
    private FncBankWaterFacade fncBankWaterFacade;
    @Autowired
    private FncDdWithholdFacade fncDdWithholdFacade;
    @Autowired
    private FncTtWithholdFacade fncTtWithholdFacade;

    @Autowired
    private FinanceUserNameFacade financeUserNameFacade;


    /**
     * 银行流水自动匹配账单
     * @author Frank.Tang
     * @param fbwIds 银行流水ids
     * @return 匹配结果
     */
    @Transactional(rollbackFor = Exception.class)
    public List<AutoMatchResOfWaterDto> bwAutoMatch(List<Long> fbwIds) {
        log.info("用户【{}】, 对银行流水(id【{}】), 发起自动匹配", JWTUtil.getNikeName(), fbwIds);

        //校验 + 数据准备
        List<FncBankWater> bankWaters = checkWaterIds(fbwIds);
        Map<Long, AutoMatchResOfWaterDto> matchResMap = initBankWaterMatchRes(bankWaters);

        bwAutoMatchAccurate(bankWaters, matchResMap);

        bwAutoMatchFuzzy(bankWaters, matchResMap);

        return new ArrayList<>(matchResMap.values());
    }

    /**
     * 滴滴代扣自动匹配账单
     * @author Frank.Tang
     * @param fdwIds 滴滴ids
     * @return 匹配结果
     */
    @Transactional(rollbackFor = Exception.class)
    public List<AutoMatchResOfWaterDto> ddAutoMatch(List<Long> fdwIds) {
        log.info("用户【{}】, 对滴滴代扣(id【{}】), 发起自动匹配", JWTUtil.getNikeName(), fdwIds);

        //校验 + 数据准备
        List<FncDdWithhold> withholds = checkDdIds(fdwIds);
        Map<Long, AutoMatchResOfWaterDto> matchResMap = initDdMatchRes(withholds);

        ddAutoMatchAccurate(withholds, matchResMap);

        ddAutoMatchFuzzy(withholds, matchResMap);

        return new ArrayList<>(matchResMap.values());
    }

    /**
     * T3代扣自动匹配账单
     * @author Frank.Tang
     * @param ftwIds T3 ids
     * @return 匹配结果
     */
    @Transactional(rollbackFor = Exception.class)
    public List<AutoMatchResOfWaterDto> ttAutoMatch(List<Long> ftwIds) {
        log.info("用户【{}】, 对T3代扣(id【{}】), 发起自动匹配", JWTUtil.getNikeName(), ftwIds);

        //校验 + 数据准备
        List<FncTtWithhold> withholds = checkTtIds(ftwIds);
        Map<Long, AutoMatchResOfWaterDto> matchResMap = initTtMatchRes(withholds);

        ttAutoMatchAccurate(withholds, matchResMap);

        ttAutoMatchFuzzy(withholds, matchResMap);

        return new ArrayList<>(matchResMap.values());
    }


    /***********************************************************************************************
     *                                       精确/模糊匹配相关方法
     ***********************************************************************************************
     **
     * 银行流水精确匹配
     * @author Frank.Tang
     */
    private void bwAutoMatchAccurate(List<FncBankWater> bankWaters,
                                     Map<Long, AutoMatchResOfWaterDto> matchResMap) {
        for (FncBankWater water : bankWaters) {
            //精确匹配只走未匹配的. 部分匹配的直接跳过, 走模糊匹配流程
            if (!WaterMatchStateEnum.NOT_MATCH.getValue().equals(water.getFbwMatchState())) {
                continue;
            }

            //查找符合条件的账单
            List<FncBillManagement> bills = selectBillOfBwAccurate(water);

            AutoMatchResOfWaterDto matchRes = matchResMap.get(water.getFbwId());

            WaterIntegrationDto dto = new WaterIntegrationDto(water);

            //找到则匹配成功
            if (!bills.isEmpty()) {
                //因为是精确匹配, 所以只取第一个就行
                FncBillManagement bill = bills.get(0);

                matchRes.setMatchRes(AutoMatchResConstants.MATCH_SUCCESS);
                matchRes.setMatchBillId(bill.getFbmId() + "");
                matchRes.setMatchedAmount(BigDecimal.valueOf(Math.abs(bill.getFbmBillAmount())));
                matchRes.setNotMatchAmount(0.0);

                //更新数据+生成匹配记录
                updateAndGenRecordAccurate(dto, bill);

                //移除已精确匹配的
                bankWaters.remove(water);
            }
        }
    }

    /**
     * 银行流水模糊匹配
     * @author Frank.Tang
     */
    private void bwAutoMatchFuzzy(List<FncBankWater> bankWaters,
                                  Map<Long, AutoMatchResOfWaterDto> matchResMap) {
        for (FncBankWater water : bankWaters) {
            //查找符合条件的账单
            List<FncBillManagement> bills = selectBillOfBwFuzzy(water);

            AutoMatchResOfWaterDto matchRes = matchResMap.get(water.getFbwId());

            WaterIntegrationDto dto = new WaterIntegrationDto(water);

            //找到则说明可进行匹配
            if (!bills.isEmpty()) {
                for (FncBillManagement bill : bills) {
                    //根据借/贷关系, 这两种情况, 直接跳过
                    if (MatchUtil.checkLoanRelation(water, bill)) {
                        continue;
                    }

                    BigDecimal billAmount = BigDecimal.valueOf(bill.getFbmBillAmount()).abs();
                    BigDecimal billMatched = BigDecimal.valueOf(bill.getFbmMatchedAmount());
                    BigDecimal billNotMatch = BigDecimal.valueOf(bill.getFbmNotMatchAmount());
                    BigDecimal waterAmount = BigDecimal.valueOf(
                            WaterLoanTypeEnum.BORROW.getValue().equals(water.getFbwLoanType()) ?
                                    water.getFbwBorrowAmount() : water.getFbwCreditAmount()
                    );
                    BigDecimal waterMatched = BigDecimal.valueOf(water.getFbwMatchedAmount());
                    BigDecimal waterNotMatch = BigDecimal.valueOf(water.getFbwNotMatchAmount());

                    //流水未匹配>账单未匹配. 当前账单直接用完, 继续匹配下一个账单
                    if (waterNotMatch.compareTo(billNotMatch) > 0) {
                        BigDecimal waterMatchNow = waterMatched.add(billNotMatch);
                        bill.setFbmMatchedAmount(billAmount.doubleValue());
                        bill.setFbmNotMatchAmount(0.0);
                        water.setFbwMatchedAmount(waterMatchNow.doubleValue());
                        water.setFbwNotMatchAmount(waterAmount.subtract(waterMatchNow).doubleValue());

                        //匹配结果设置
                        matchRes.setMatchRes(AutoMatchResConstants.MATCH_PART_SUCCESS);
                        matchRes.setMatchBillId(MatchUtil.splicing(matchRes.getMatchBillId(), bill.getFbmId()));
                        matchRes.setMatchedAmount(matchRes.getMatchedAmount().add(billNotMatch));
                        matchRes.setNotMatchAmount(water.getFbwNotMatchAmount());

                        //更新数据+生成匹配记录
                        fncBillManagementFacade.updateAndGenRecordAfterMatch(bill, dto, billNotMatch, true);
                    }
                    //流水未匹配<=账单未匹配. 当前流水匹配完毕, 本次匹配结束
                    else {
                        BigDecimal billMatchNow = billMatched.add(waterNotMatch);
                        bill.setFbmMatchedAmount(billMatchNow.doubleValue());
                        bill.setFbmNotMatchAmount(billAmount.subtract(billMatchNow).doubleValue());
                        water.setFbwMatchedAmount(waterAmount.doubleValue());
                        water.setFbwNotMatchAmount(0.0);

                        //匹配结果设置
                        matchRes.setMatchRes(AutoMatchResConstants.MATCH_SUCCESS);
                        matchRes.setMatchBillId(MatchUtil.splicing(matchRes.getMatchBillId(), bill.getFbmId()));
                        matchRes.setMatchedAmount(waterAmount.subtract(matchRes.getMatchedAmountInit()));
                        matchRes.setNotMatchAmount(water.getFbwNotMatchAmount());


                        //更新数据+生成匹配记录
                        fncBillManagementFacade.updateAndGenRecordAfterMatch(bill, dto, waterNotMatch, true);

                        //移除当前流水, 结束本次循环
                        bankWaters.remove(water);
                        break;
                    }
                }
            }
        }
    }

    /**
     * 滴滴代扣精确匹配
     * @author Frank.Tang
     */
    private void ddAutoMatchAccurate(List<FncDdWithhold> withholds,
                                     Map<Long, AutoMatchResOfWaterDto> matchResMap) {
        for (FncDdWithhold withhold : withholds) {
            //精确匹配只走未匹配的. 部分匹配的直接跳过, 走模糊匹配流程
            if (!WaterMatchStateEnum.NOT_MATCH.getValue().equals(withhold.getFdwMatchState())) {
                continue;
            }

            //查找符合条件的账单
            List<FncBillManagement> bills = selectBillOfDwAccurate(withhold);

            AutoMatchResOfWaterDto matchRes = matchResMap.get(withhold.getFdwId());

            WaterIntegrationDto dto = new WaterIntegrationDto(withhold);

            //找到则匹配成功
            if (!bills.isEmpty()) {
                //因为是精确匹配, 所以只取第一个就行
                FncBillManagement bill = bills.get(0);

                matchRes.setMatchRes(AutoMatchResConstants.MATCH_SUCCESS);
                matchRes.setMatchBillId(bill.getFbmId() + "");
                matchRes.setMatchedAmount(BigDecimal.valueOf(Math.abs(bill.getFbmBillAmount())));
                matchRes.setNotMatchAmount(0.0);

                //更新数据+生成匹配记录
                updateAndGenRecordAccurate(dto, bill);

                //移除已精确匹配的
                withholds.remove(withhold);
            }
        }
    }

    /**
     * 滴滴代扣模糊匹配
     * @author Frank.Tang
     */
    private void ddAutoMatchFuzzy(List<FncDdWithhold> withholds,
                                  Map<Long, AutoMatchResOfWaterDto> matchResMap) {
        for (FncDdWithhold withhold : withholds) {
            //查找符合条件的账单
            List<FncBillManagement> bills = selectBillOfDwFuzzy(withhold);

            AutoMatchResOfWaterDto matchRes = matchResMap.get(withhold.getFdwId());

            WaterIntegrationDto dto = new WaterIntegrationDto(withhold);

            //找到则说明可进行匹配
            if (!bills.isEmpty()) {
                for (FncBillManagement bill : bills) {
                    //保证金账单, 只走银行流水
                    if (BillSubjectsEnum.BOND.getValue().equals(bill.getFbmSubjects())) {
                        continue;
                    }

                    BigDecimal billAmount = BigDecimal.valueOf(bill.getFbmBillAmount()).abs();
                    BigDecimal billMatched = BigDecimal.valueOf(bill.getFbmMatchedAmount());
                    BigDecimal billNotMatch = BigDecimal.valueOf(bill.getFbmNotMatchAmount());
                    BigDecimal waterAmount = BigDecimal.valueOf(withhold.getFdwTradeAmount());
                    BigDecimal waterMatched = BigDecimal.valueOf(withhold.getFdwMatchedAmount());
                    BigDecimal waterNotMatch = BigDecimal.valueOf(withhold.getFdwNotMatchAmount());

                    //流水未匹配>账单未匹配. 当前账单直接用完, 继续匹配下一个账单
                    if (waterNotMatch.compareTo(billNotMatch) > 0) {
                        BigDecimal waterMatchNow = waterMatched.add(billNotMatch);
                        bill.setFbmMatchedAmount(billAmount.doubleValue());
                        bill.setFbmNotMatchAmount(0.0);
                        withhold.setFdwMatchedAmount(waterMatchNow.doubleValue());
                        withhold.setFdwNotMatchAmount(waterAmount.subtract(waterMatchNow).doubleValue());

                        //匹配结果设置
                        matchRes.setMatchRes(AutoMatchResConstants.MATCH_PART_SUCCESS);
                        matchRes.setMatchBillId(MatchUtil.splicing(matchRes.getMatchBillId(), bill.getFbmId()));
                        matchRes.setMatchedAmount(matchRes.getMatchedAmount().add(billNotMatch));
                        matchRes.setNotMatchAmount(withhold.getFdwNotMatchAmount());

                        //更新数据+生成匹配记录
                        fncBillManagementFacade.updateAndGenRecordAfterMatch(bill, dto, billNotMatch, true);
                    }
                    //流水未匹配<=账单未匹配. 当前流水匹配完毕, 本次匹配结束
                    else {
                        BigDecimal billMatchNow = billMatched.add(waterNotMatch);
                        bill.setFbmMatchedAmount(billMatchNow.doubleValue());
                        bill.setFbmNotMatchAmount(billAmount.subtract(billMatchNow).doubleValue());
                        withhold.setFdwMatchedAmount(waterAmount.doubleValue());
                        withhold.setFdwNotMatchAmount(0.0);

                        //匹配结果设置
                        matchRes.setMatchRes(AutoMatchResConstants.MATCH_SUCCESS);
                        matchRes.setMatchBillId(MatchUtil.splicing(matchRes.getMatchBillId(), bill.getFbmId()));
                        matchRes.setMatchedAmount(waterAmount.subtract(matchRes.getMatchedAmountInit()));
                        matchRes.setNotMatchAmount(withhold.getFdwNotMatchAmount());

                        //更新数据+生成匹配记录
                        fncBillManagementFacade.updateAndGenRecordAfterMatch(bill, dto, waterNotMatch, true);

                        //移除当前流水, 结束本次循环
                        withholds.remove(withhold);
                        break;
                    }
                }
            }
        }
    }

    /**
     * T3代扣精确匹配
     * @author Frank.Tang
     */
    private void ttAutoMatchAccurate(List<FncTtWithhold> withholds,
                                     Map<Long, AutoMatchResOfWaterDto> matchResMap) {
        for (FncTtWithhold withhold : withholds) {
            //精确匹配只走未匹配的. 部分匹配的直接跳过, 走模糊匹配流程
            if (!WaterMatchStateEnum.NOT_MATCH.getValue().equals(withhold.getFtwMatchState())) {
                continue;
            }

            //查找符合条件的账单
            List<FncBillManagement> bills = selectBillOfTwAccurate(withhold);

            AutoMatchResOfWaterDto matchRes = matchResMap.get(withhold.getFtwId());

            WaterIntegrationDto dto = new WaterIntegrationDto(withhold);

            //找到则匹配成功
            if (!bills.isEmpty()) {
                //因为是精确匹配, 所以只取第一个就行
                FncBillManagement bill = bills.get(0);

                matchRes.setMatchRes(AutoMatchResConstants.MATCH_SUCCESS);
                matchRes.setMatchBillId(bill.getFbmId() + "");
                matchRes.setMatchedAmount(BigDecimal.valueOf(Math.abs(bill.getFbmBillAmount())));
                matchRes.setNotMatchAmount(0.0);

                //更新数据+生成匹配记录
                updateAndGenRecordAccurate(dto, bill);

                //移除已精确匹配的
                withholds.remove(withhold);
            }
        }
    }

    /**
     * T3代扣模糊匹配
     * @author Frank.Tang
     */
    private void ttAutoMatchFuzzy(List<FncTtWithhold> withholds,
                                  Map<Long, AutoMatchResOfWaterDto> matchResMap) {
        for (FncTtWithhold withhold : withholds) {
            //查找符合条件的账单
            List<FncBillManagement> bills = selectBillOfTwFuzzy(withhold);

            AutoMatchResOfWaterDto matchRes = matchResMap.get(withhold.getFtwId());

            WaterIntegrationDto dto = new WaterIntegrationDto(withhold);

            //找到则说明可进行匹配
            if (!bills.isEmpty()) {
                for (FncBillManagement bill : bills) {
                    //保证金账单, 只走银行流水
                    if (BillSubjectsEnum.BOND.getValue().equals(bill.getFbmSubjects())) {
                        continue;
                    }

                    BigDecimal billAmount = BigDecimal.valueOf(bill.getFbmBillAmount()).abs();
                    BigDecimal billMatched = BigDecimal.valueOf(bill.getFbmMatchedAmount());
                    BigDecimal billNotMatch = BigDecimal.valueOf(bill.getFbmNotMatchAmount());
                    BigDecimal waterAmount = BigDecimal.valueOf(withhold.getFtwMonthWithhold());
                    BigDecimal waterMatched = BigDecimal.valueOf(withhold.getFtwMatchedAmount());
                    BigDecimal waterNotMatch = BigDecimal.valueOf(withhold.getFtwNotMatchAmount());

                    //流水未匹配>账单未匹配. 当前账单直接用完, 继续匹配下一个账单
                    if (waterNotMatch.compareTo(billNotMatch) > 0) {
                        BigDecimal waterMatchNow = waterMatched.add(billNotMatch);
                        bill.setFbmMatchedAmount(billAmount.doubleValue());
                        bill.setFbmNotMatchAmount(0.0);
                        withhold.setFtwMatchedAmount(waterMatchNow.doubleValue());
                        withhold.setFtwNotMatchAmount(waterAmount.subtract(waterMatchNow).doubleValue());

                        //匹配结果设置
                        matchRes.setMatchRes(AutoMatchResConstants.MATCH_PART_SUCCESS);
                        matchRes.setMatchBillId(MatchUtil.splicing(matchRes.getMatchBillId(), bill.getFbmId()));
                        matchRes.setMatchedAmount(matchRes.getMatchedAmount().add(billNotMatch));
                        matchRes.setNotMatchAmount(withhold.getFtwNotMatchAmount());

                        //更新数据+生成匹配记录
                        fncBillManagementFacade.updateAndGenRecordAfterMatch(bill, dto, billNotMatch, true);
                    }
                    //流水未匹配<=账单未匹配. 当前流水匹配完毕, 本次匹配结束
                    else {
                        BigDecimal billMatchNow = billMatched.add(waterNotMatch);
                        bill.setFbmMatchedAmount(billMatchNow.doubleValue());
                        bill.setFbmNotMatchAmount(billAmount.subtract(billMatchNow).doubleValue());
                        withhold.setFtwMatchedAmount(waterAmount.doubleValue());
                        withhold.setFtwNotMatchAmount(0.0);

                        //匹配结果设置
                        matchRes.setMatchRes(AutoMatchResConstants.MATCH_SUCCESS);
                        matchRes.setMatchBillId(MatchUtil.splicing(matchRes.getMatchBillId(), bill.getFbmId()));
                        matchRes.setMatchedAmount(waterAmount.subtract(matchRes.getMatchedAmountInit()));
                        matchRes.setNotMatchAmount(withhold.getFtwNotMatchAmount());

                        //更新数据+生成匹配记录
                        fncBillManagementFacade.updateAndGenRecordAfterMatch(bill, dto, waterNotMatch, true);

                        //移除当前流水, 结束本次循环
                        withholds.remove(withhold);
                        break;
                    }
                }
            }
        }
    }

    /**
     * 针对单个流水和账单(精确匹配), 更新和新增相关数据
     * @param dto 流水 or 代扣集合对象
     * @param bill 账单
     * @author Frank.Tang
     */
    private void updateAndGenRecordAccurate(WaterIntegrationDto dto, FncBillManagement bill) {
        FncRevenueWaterRecord waterRecord = new FncRevenueWaterRecord();
        AuthUser user = authUserClient.getAuthUserById(JWTUtil.getUserId()).getDataWithEx();
        Long fbmId = bill.getFbmId();

        //银行
        if (WaterMatchTypeEnum.YH.getValue().equals(dto.getType())) {
            FncBankWater bankWater = dto.getBankWater();

            //根据借/贷, 设置已匹配金额
            if (WaterLoanTypeEnum.BORROW.getValue().equals(bankWater.getFbwLoanType())) {
                bankWater.setFbwMatchedAmount(bankWater.getFbwBorrowAmount());
            } else {
                bankWater.setFbwMatchedAmount(bankWater.getFbwCreditAmount());
            }

            bankWater.setFbwNotMatchAmount(0.0);
            bankWater.setFbwMatchBill(MatchUtil.splicing(bankWater.getFbwMatchBill(), fbmId));
            bankWater.setFbwMatchState(WaterMatchStateEnum.ALL_MATCH.getValue());
            bankWater.setFbwMatchType(MatchWayEnum.AUTO.getValue());
            waterRecord.setFrwrRevenueId(bankWater.getFbwId());
            waterRecord.setFrwrRevenueType(WaterMatchTypeEnum.YH.getValue());

            //更新流水
            fncBankWaterService.update(bankWater);
            //拼接账单的流水匹配id
            bill.setFbmMatchSerialNumber(MatchUtil.splicing(
                    bill.getFbmMatchSerialNumber(),
                    WaterMatchTypeEnum.YH.getName() + bankWater.getFbwId())
            );
        }
        //滴滴
        else if (WaterMatchTypeEnum.DD.getValue().equals(dto.getType())) {
            FncDdWithhold ddWater = dto.getDdWithhold();

            ddWater.setFdwMatchedAmount(ddWater.getFdwTradeAmount());
            ddWater.setFdwNotMatchAmount(0.0);
            ddWater.setFdwMatchBill(MatchUtil.splicing(ddWater.getFdwMatchBill(), fbmId));
            ddWater.setFdwMatchState(WaterMatchStateEnum.ALL_MATCH.getValue());
            ddWater.setFdwMatchWay(MatchWayEnum.AUTO.getValue());
            waterRecord.setFrwrRevenueId(ddWater.getFdwId());
            waterRecord.setFrwrRevenueType(WaterMatchTypeEnum.DD.getValue());

            fncDdWithholdService.update(ddWater);

            bill.setFbmMatchSerialNumber(MatchUtil.splicing(
                    bill.getFbmMatchSerialNumber(),
                    WaterMatchTypeEnum.DD.getName() + ddWater.getFdwId())
            );
        }
        //T3
        else if (WaterMatchTypeEnum.TT.getValue().equals(dto.getType())) {
            FncTtWithhold ttWater = dto.getTtWithhold();

            ttWater.setFtwMatchedAmount(ttWater.getFtwMonthWithhold());
            ttWater.setFtwNotMatchAmount(0.0);
            ttWater.setFtwMatchBill(MatchUtil.splicing(ttWater.getFtwMatchBill(), fbmId));
            ttWater.setFtwMatchState(WaterMatchStateEnum.ALL_MATCH.getValue());
            ttWater.setFtwMatchWay(MatchWayEnum.AUTO.getValue());
            waterRecord.setFrwrRevenueId(ttWater.getFtwId());
            waterRecord.setFrwrRevenueType(WaterMatchTypeEnum.TT.getValue());

            fncTtWithholdService.update(ttWater);

            bill.setFbmMatchSerialNumber(MatchUtil.splicing(
                    bill.getFbmMatchSerialNumber(),
                    WaterMatchTypeEnum.TT.getName() + ttWater.getFtwId())
            );
        }

        //更新账单
        bill.setFbmMatchUserId(JWTUtil.getUserId());
        bill.setFbmMatchTime(new Date());
        bill.setFbmMatchWay(MatchWayEnum.AUTO.getValue());
        bill.setFbmMatchedAmount(Math.abs(bill.getFbmBillAmount()));
        bill.setFbmNotMatchAmount(0.0);
        bill.setFbmBillState(BillStateEnum.PAID_ALL.getValue());
        fncBillManagementService.update(bill);
        String userNamePhone = financeUserNameFacade.getUserNamePhone(user);
        String desc = userNamePhone +
                "发起自动匹配，匹配成功。匹配账单号" + fbmId + "，" +
                "匹配金额" + bill.getFbmMatchedAmount() + "元，" +
                "流水剩余金额0.0元。";
        waterRecord.setFrwrBillId(fbmId);
        waterRecord.setFrwrDescribe(desc);
        waterRecord.setFrwrMatchState(MatchWayEnum.AUTO.getValue());

        //新增匹配记录
        fncRevenueWaterRecordService.add(waterRecord);
    }


    /***********************************************************************************************
     *                                            其它方法
     ***********************************************************************************************
     **
     * 初始化[银行流水]匹配结果
     * @author Frank.Tang
     * @return <流水id, 匹配结果实体>
     */
    private Map<Long, AutoMatchResOfWaterDto> initBankWaterMatchRes(List<FncBankWater> list) {
        Map<Long, AutoMatchResOfWaterDto> res = new HashMap<>();
        for (FncBankWater bankWater : list) {
            AutoMatchResOfWaterDto dto = new AutoMatchResOfWaterDto();
            dto.setWaterAmount(
                    bankWater.getFbwLoanType().equals(WaterLoanTypeEnum.BORROW.getValue()) ?
                            bankWater.getFbwBorrowAmount() :
                            bankWater.getFbwCreditAmount()
            );
            dto.setWaterId(bankWater.getFbwId());
            dto.setMatchBillId("");
            dto.setWaterType("银行流水");
            dto.setMatchedAmount(BigDecimal.ZERO);
            dto.setNotMatchAmount(bankWater.getFbwNotMatchAmount());
            dto.setMatchedAmountInit(BigDecimal.valueOf(bankWater.getFbwMatchedAmount()));
            dto.setMatchRes(AutoMatchResConstants.MATCH_FAILED);
            res.put(bankWater.getFbwId(), dto);
        }
        return res;
    }

    /**
     * 初始化[滴滴代扣]匹配结果
     * @author Frank.Tang
     * @return <流水id, 匹配结果实体>
     */
    private Map<Long, AutoMatchResOfWaterDto> initDdMatchRes(List<FncDdWithhold> list) {
        Map<Long, AutoMatchResOfWaterDto> res = new HashMap<>();
        for (FncDdWithhold withhold : list) {
            AutoMatchResOfWaterDto dto = new AutoMatchResOfWaterDto();

            dto.setWaterAmount(withhold.getFdwTradeAmount());
            dto.setWaterId(withhold.getFdwId());
            dto.setWaterType("滴滴代扣");
            dto.setMatchBillId("");
            dto.setMatchedAmount(BigDecimal.ZERO);
            dto.setNotMatchAmount(withhold.getFdwNotMatchAmount());
            dto.setMatchedAmountInit(BigDecimal.valueOf(withhold.getFdwMatchedAmount()));
            dto.setMatchRes(AutoMatchResConstants.MATCH_FAILED);

            res.put(withhold.getFdwId(), dto);
        }
        return res;
    }

    /**
     * 初始化[滴滴代扣]匹配结果
     * @author Frank.Tang
     * @return <流水id, 匹配结果实体>
     */
    private Map<Long, AutoMatchResOfWaterDto> initTtMatchRes(List<FncTtWithhold> list) {
        Map<Long, AutoMatchResOfWaterDto> res = new HashMap<>();
        for (FncTtWithhold withhold : list) {
            AutoMatchResOfWaterDto dto = new AutoMatchResOfWaterDto();
            dto.setWaterAmount(withhold.getFtwMonthWithhold());
            dto.setWaterId(withhold.getFtwId());
            dto.setWaterType("T3代扣");
            dto.setMatchBillId("");
            dto.setMatchedAmount(BigDecimal.ZERO);
            dto.setNotMatchAmount(withhold.getFtwNotMatchAmount());
            dto.setMatchedAmountInit(BigDecimal.valueOf(withhold.getFtwMatchedAmount()));
            dto.setMatchRes(AutoMatchResConstants.MATCH_FAILED);
            res.put(withhold.getFtwId(), dto);
        }
        return res;
    }

    /**
     * 根据银行账号, 找个人或组织的id
     * @author Frank.Tang
     * @return 个人会员 或 部门id
     */
    private Long getIdByAccount(String account) {
        Long deptId = authDeptClient.getDeptIdByBankAccount(account).getDataWithEx();
        Long memberId = memberClient.getMemberIdByBankAccount(account).getDataWithEx();

        if (deptId != null && memberId != null) {
            throw new GlobalException("数据异常, 银行账号【" + account + "】同时关联了个人会员和部门");
        }

        return deptId == null ? memberId : deptId;
    }

    /**
     * 银行流水[精确匹配]账单, 查询满足条件的账单
     * 查询条件:
     *   (1)甲乙方银行账号 = 流水中的我方、对方银行账号
     *   (2)流水金额 = 账单金额
     * @author Frank.Tang
     * @return 按生成时间升序
     */
    private List<FncBillManagement> selectBillOfBwAccurate(FncBankWater water) {
        String ownAccount = water.getFbwOwnAccount();
        String otherAccount = water.getFbwOtherAccount();
        Double amount = WaterLoanTypeEnum.BORROW.getValue().equals(water.getFbwLoanType()) ?
                water.getFbwBorrowAmount() : water.getFbwCreditAmount();

        Long partyaId = getIdByAccount(ownAccount);
        Long partybId = getIdByAccount(otherAccount);

        return fncBillManagementService
                .selectBillOfBwAccurate(water.getFbwLoanType(), amount, partyaId, partybId)
                .stream()
                .sorted(Comparator.comparing(FncBillManagement::getFbmBillGenerateTime))
                .collect(Collectors.toList());
    }

    /**
     * 银行流水[模糊匹配]账单, 查询满足条件的账单
     * 查询条件:
     *   (1)借-->账单<0 / 贷-->账单>0
     *   (2)对方账号对应的id = 关联合同乙方id
     * @author Frank.Tang
     * @return 按生成时间升序
     */
    private List<FncBillManagement> selectBillOfBwFuzzy(FncBankWater water) {
        String otherAccount = water.getFbwOtherAccount();
        Integer loanType = water.getFbwLoanType();

        Long partybId = getIdByAccount(otherAccount);

        return fncBillManagementService.selectBillOfBwFuzzy(loanType, partybId)
                .stream()
                .sorted(Comparator.comparing(FncBillManagement::getFbmBillGenerateTime))
                .collect(Collectors.toList());
    }

    /**
     * 滴滴代扣[精确匹配]账单, 查询满足条件的账单
     * 查询条件:
     *   (1)vin对应的车id = 账单上的车id
     *   (2)状态 = 未支付(未匹配)
     *   (3)代扣金额 = 账单金额
     * @author Frank.Tang
     * @return 按生成时间升序
     */
    private List<FncBillManagement> selectBillOfDwAccurate(FncDdWithhold withhold) {
        Double amount = withhold.getFdwTradeAmount();
        String vin = withhold.getFdwCarVin();

        ResCar car = resCarQueryClient.findVin(vin).getDataWithEx();

        //查询条件
        FncBillManagementQueryVo queryVo = new FncBillManagementQueryVo();
        queryVo.setFbmAssociateCarIdEqualTo(car.getRcId());
        queryVo.setFbmBillStateEqualTo(BillStateEnum.UNPAID.getValue());
        queryVo.setFbmBillAmountEqualTo(amount);

        return fncBillManagementService.list(queryVo)
                .stream()
                .sorted(Comparator.comparing(FncBillManagement::getFbmBillGenerateTime))
                .collect(Collectors.toList());
    }

    /**
     * 滴滴代扣[模糊匹配]账单, 查询满足条件的账单
     * 查询条件:
     *   (1)代扣vin对应车id = 账单关联车id
     *   (2)账单[未支付/部分支付]
     * @author Frank.Tang
     * @return 按生成时间升序
     */
    private List<FncBillManagement> selectBillOfDwFuzzy(FncDdWithhold withhold) {
        String vin = withhold.getFdwCarVin();

        ResCar car = resCarQueryClient.findVin(vin).getDataWithEx();

        //查询条件
        FncBillManagementQueryVo queryVo = new FncBillManagementQueryVo();
        queryVo.setFbmAssociateCarIdEqualTo(car.getRcId());
        queryVo.setFbmBillStateIn(Arrays.asList(
                BillStateEnum.UNPAID.getValue(),
                BillStateEnum.OVERDUE.getValue(),
                BillStateEnum.PAID_PART.getValue()
        ));

        return fncBillManagementService.list(queryVo)
                .stream()
                .sorted(Comparator.comparing(FncBillManagement::getFbmBillGenerateTime))
                .collect(Collectors.toList());
    }

    /**
     * T3代扣[精确匹配]账单, 查询满足条件的账单
     * @author Frank.Tang
     * @return 按生成时间升序
     */
    private List<FncBillManagement> selectBillOfTwAccurate(FncTtWithhold withhold) {
        String idNumber = withhold.getFtwIdnumber();
        String agreementNumber = withhold.getFtwAgreementNumber();
        String vin = withhold.getFtwCarVin();
        Double amount = withhold.getFtwMonthWithhold();

        //找车
        ResCar car = resCarQueryClient.findVin(vin).getDataWithEx();

        //找会员id
        Long partybId = memberClient.getMemberIdByIdNumber(idNumber).getDataWithEx();

        return fncBillManagementService
                .selectBillOfTwAccurate(partybId, agreementNumber, amount, car.getRcId())
                .stream()
                .sorted(Comparator.comparing(FncBillManagement::getFbmBillGenerateTime))
                .collect(Collectors.toList());
    }

    /**
     * T3代扣[模糊匹配]账单, 查询满足条件的账单
     * @author Frank.Tang
     * @return 按生成时间升序
     */
    private List<FncBillManagement> selectBillOfTwFuzzy(FncTtWithhold withhold) {
        String idNumber = withhold.getFtwIdnumber();
        String agreementNumber = withhold.getFtwAgreementNumber();

        //找会员id
        Long partybId = memberClient.getMemberIdByIdNumber(idNumber).getDataWithEx();

        return fncBillManagementService
                .selectBillOfTwFuzzy(partybId, agreementNumber)
                .stream()
                .sorted(Comparator.comparing(FncBillManagement::getFbmBillGenerateTime))
                .collect(Collectors.toList());
    }


    /***********************************************************************************************
     *                                            Checks
     ***********************************************************************************************
     **
     * 银行流水校验:
     *   (1)数据存在性  (2)状态
     * @author Frank.Tang
     * @return ids对应的实体类 {@link CopyOnWriteArrayList}
     */
    private List<FncBankWater> checkWaterIds(List<Long> ids) {
        CheckUtil.isEmptyWithEx(ids, ExMsgConstants.RECEIVE_NULL_ID);

        //(1)
        List<FncBankWater> bankWaters = fncBankWaterService.getByIds(ids);
        if (bankWaters.isEmpty()) {
            throw new GlobalException("数据异常, 未查询到对应的流水数据");
        }
        bankWaters = StreamUtil.filterDr(bankWaters);
        if (bankWaters.size() != ids.size()) {
            throw new GlobalException("数据异常, 部分id对应流水不存在或被删除, 请联系管理员");
        }

        //(2)
        for (FncBankWater bankWater : bankWaters) {
            if (bankWater.getFbwMatchState().equals(WaterMatchStateEnum.ALL_MATCH.getValue())) {
                throw new GlobalException("操作失败, 银行流水" + bankWater.getFbwId() + "已匹配, 不能在匹配");
            }
        }
        return bankWaters.stream()
                .sorted(Comparator.comparing(BaseEntity::getCreatetime))
                .collect(Collectors.toCollection(CopyOnWriteArrayList::new));
    }

    /**
     * 滴滴校验:
     *   (1)数据存在性  (2)状态
     * @author Frank.Tang
     * @return ids对应的实体类 {@link CopyOnWriteArrayList}
     */
    private List<FncDdWithhold> checkDdIds(List<Long> ids) {
        CheckUtil.isEmptyWithEx(ids, ExMsgConstants.RECEIVE_NULL_ID);

        //(1)
        List<FncDdWithhold> withholds = fncDdWithholdService.getByIds(ids);
        if (withholds.isEmpty()) {
            throw new GlobalException("数据异常, 未查询到对应的滴滴代扣数据");
        }
        withholds = StreamUtil.filterDr(withholds);
        if (withholds.size() != ids.size()) {
            throw new GlobalException("数据异常, 部分id对应滴滴代扣不存在或被删除, 请联系管理员");
        }

        //(2)
        for (FncDdWithhold withhold : withholds) {
            if (withhold.getFdwMatchState().equals(WaterMatchStateEnum.ALL_MATCH.getValue())) {
                throw new GlobalException("操作失败, 滴滴代扣" + withhold.getFdwId() + "已匹配");
            }
        }
        return withholds.stream()
                .sorted(Comparator.comparing(BaseEntity::getCreatetime))
                .collect(Collectors.toCollection(CopyOnWriteArrayList::new));
    }

    /**
     * T3校验:
     *   (1)数据存在性  (2)状态
     * @author Frank.Tang
     * @return ids对应的实体类, 并按创建时间升序升序 {@link CopyOnWriteArrayList}
     */
    private List<FncTtWithhold> checkTtIds(List<Long> ids) {
        CheckUtil.isEmptyWithEx(ids, ExMsgConstants.RECEIVE_NULL_ID);

        //(1)
        List<FncTtWithhold> withholds = fncTtWithholdService.getByIds(ids);
        if (withholds.isEmpty()) {
            throw new GlobalException("数据异常, 未查询到对应的T3代扣数据");
        }
        withholds = StreamUtil.filterDr(withholds);
        if (withholds.size() != ids.size()) {
            throw new GlobalException("数据异常, 部分id对应T3代不存在或被删除, 请联系管理员");
        }

        //(2)
        for (FncTtWithhold withhold : withholds) {
            if (withhold.getFtwMatchState().equals(WaterMatchStateEnum.ALL_MATCH.getValue())) {
                throw new GlobalException("操作失败, T3代扣" + withhold.getFtwId() + "已匹配");
            }
        }
        return withholds.stream()
                .sorted(Comparator.comparing(BaseEntity::getCreatetime))
                .collect(Collectors.toCollection(CopyOnWriteArrayList::new));
    }

}
