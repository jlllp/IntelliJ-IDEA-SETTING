package com.mrk.finance.facade.common;

import com.github.pagehelper.PageInfo;
import com.mrk.auth.client.AuthDeptClient;
import com.mrk.auth.model.AuthDept;
import com.mrk.common.page.PageDomain;
import com.mrk.common.page.TableSupport;
import com.mrk.common.utils.bean.BeanUtils;
import com.mrk.common.utils.text.CheckUtil;
import com.mrk.finance.dto.common.DeptOrMemberInfoDto;
import com.mrk.member.client.MemberClient;
import com.mrk.member.model.MrkMember;
import com.mrk.universal.enums.contract.ContractPartyTypeEnum;
import org.apache.commons.collections4.CollectionUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.ArrayList;
import java.util.List;

/**
 * @author Bob
 * @date 2021-11-18
 * @description
 */
@Component
public class DeptOrMemberFacade {

    @Autowired
    private AuthDeptClient authDeptClient;

    @Autowired
    private MemberClient memberClient;


    @Autowired
    private FinanceUserNameFacade financeUserNameFacade;


    /**
     * @param partyType 类型
     * @param nameLike  名称 模糊查询
     * @return 符合的条件
     * @author Bob
     * @date 2021/11/18
     * @description 获取信息通过类型和
     */
    public PageInfo<DeptOrMemberInfoDto> getInfoByTypeAndName(Integer partyType, String nameLike, Long cityIdEqualTo) {
        PageDomain pageDomain = TableSupport.buildPageRequest();
        // 获取分页参数
        // 获取失败的时候使用默认数据
        // 页码1 每页显示数量25
        if (CheckUtil.isEmpty(pageDomain.getPageNum())) {
            pageDomain.setPageNum(1);
        }
        if (CheckUtil.isEmpty(pageDomain.getPageSize())) {
            pageDomain.setPageSize(25);
        }
        // 会员查询
        if (ContractPartyTypeEnum.PERSONAL.getValue().equals(partyType)) {
            PageInfo<MrkMember> mrkMemberPageInfo = memberClient.getPageByDeptNameLike(nameLike, pageDomain.getPageNum(), pageDomain.getPageSize()).getDataWithEx();
            return transformByMember(mrkMemberPageInfo);
        }
        // 组织查询
        else if (ContractPartyTypeEnum.ORGANIZATION.getValue().equals(partyType)) {
            PageInfo<AuthDept> deptPageInfo = authDeptClient.getPageByDeptNameLike(nameLike, cityIdEqualTo, pageDomain.getPageNum(), pageDomain.getPageSize()).getDataWithEx();
            return transformByAuthDept(deptPageInfo);
        }
        return new PageInfo<>(new ArrayList<>());
    }

    /**
     * @param mrkMemberPageInfo 会员分页对象
     * @return 部门会员分页对象
     * @author Bob
     * @date 2021/11/18
     * @description 转换为指定的dto对象
     */
    private PageInfo<DeptOrMemberInfoDto> transformByMember(PageInfo<MrkMember> mrkMemberPageInfo) {
        // 构建一个dto分页对象
        // 将查询到的分页对象里的属性复制到dto分页对象里面
        PageInfo<DeptOrMemberInfoDto> deptOrMemberInfoDtoPageInfo = new PageInfo<>();
        BeanUtils.copyBeanProp(mrkMemberPageInfo, deptOrMemberInfoDtoPageInfo);

        // 创建一个集合用于存储自定义的dto对象
        List<DeptOrMemberInfoDto> deptOrMemberInfoDtos = new ArrayList<>();

        // 获取分页里面的集合
        // 如果不为空遍历集合
        // 将里面的属性赋值到自定义的dto对象中
        List<MrkMember> memberList = mrkMemberPageInfo.getList();
        if (CollectionUtils.isNotEmpty(memberList)) {
            for (MrkMember mrkMember : memberList) {
                DeptOrMemberInfoDto dto = new DeptOrMemberInfoDto();
                dto.setId(mrkMember.getMmId());
                dto.setPartyType(ContractPartyTypeEnum.ORGANIZATION.getValue());
                dto.setName(financeUserNameFacade.getUserName(mrkMember));
                deptOrMemberInfoDtos.add(dto);
            }
        }
        // 将自定义的dto对象集合设置到分页对象中
        deptOrMemberInfoDtoPageInfo.setList(deptOrMemberInfoDtos);
        return deptOrMemberInfoDtoPageInfo;
    }

    /**
     * @param deptPageInfo 部门分页对象
     * @return 部门会员分页对象
     * @author Bob
     * @date 2021/11/18
     * @description 转换为指定的dto对象
     */
    private PageInfo<DeptOrMemberInfoDto> transformByAuthDept(PageInfo<AuthDept> deptPageInfo) {
        // 构建一个dto分页对象
        // 将查询到的分页对象里的属性复制到dto分页对象里面
        PageInfo<DeptOrMemberInfoDto> deptOrMemberInfoDtoPageInfo = new PageInfo<>();
        BeanUtils.copyBeanProp(deptPageInfo, deptOrMemberInfoDtoPageInfo);

        // 创建一个集合用于存储自定义的dto对象
        List<DeptOrMemberInfoDto> deptOrMemberInfoDtos = new ArrayList<>();

        // 获取分页里面的集合
        // 如果不为空遍历集合
        // 将里面的属性赋值到自定义的dto对象中
        List<AuthDept> authDepts = deptPageInfo.getList();
        if (CollectionUtils.isNotEmpty(authDepts)) {
            for (AuthDept authDept : authDepts) {
                DeptOrMemberInfoDto dto = new DeptOrMemberInfoDto();
                dto.setId(authDept.getId());
                dto.setPartyType(ContractPartyTypeEnum.ORGANIZATION.getValue());
                dto.setName(authDept.getDeptName());
                deptOrMemberInfoDtos.add(dto);
            }
        }
        // 将自定义的dto对象集合设置到分页对象中
        deptOrMemberInfoDtoPageInfo.setList(deptOrMemberInfoDtos);
        return deptOrMemberInfoDtoPageInfo;
    }
}
