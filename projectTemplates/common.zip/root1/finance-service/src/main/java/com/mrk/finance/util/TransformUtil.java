package com.mrk.finance.util;

import java.lang.reflect.Field;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * @author Bob
 * @date 2022/6/8
 * @description
 */
public class TransformUtil {

    private TransformUtil() {}

    /**
     * 对象集合转map集合
     *
     * @param list 待转换的集合
     * @return map集合
     */
    public static List<Map<String, Object>> listToMap(List<?> list) {
        List<Map<String, Object>> result = new ArrayList<>();
        for (Object next : list) {
            Map<String, Object> stringObjectMap = entityToMap(next);
            result.add(stringObjectMap);
        }
        return result;
    }

    /**
     * 对象转map
     *
     * @param object 要转换为map的对象
     * @return map对象
     */
    @SuppressWarnings("all")
    public static Map<String, Object> entityToMap(Object object) {
        Map<String, Object> map = new HashMap<>();
        for (Field field : object.getClass().getDeclaredFields()) {
            try {
                boolean flag = field.isAccessible();
                field.setAccessible(true);
                Object o = field.get(object);
                map.put(field.getName(), o);
                field.setAccessible(flag);
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
        return map;
    }
}
