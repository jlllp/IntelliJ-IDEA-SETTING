package com.mrk.finance.enums;

import lombok.Getter;

/**
 * @project: mrk-finance
 * @author: Frank.Tang
 * @date: 2021-11-11 09:47
 * @desc: 账单科目(类型)
 **/
@Getter
public enum BillSubjectsEnum {

    /** */
    RENT(0, "租金"),
    BREACH(1, "滞纳金"),
    DELAY(2, "违约金"),
    BALANCE(3, "购车尾款"),
    BOND(4, "保证金"),
    INFORMATION(5, "信息服务费"),
    OTHER(6, "其它")
    ;

    private Integer value;
    private String name;

    BillSubjectsEnum(Integer value, String name) {
        this.value = value;
        this.name = name;
    }

    public static String getName(Integer state) {
        if (state == null) {
            return "";
        }
        for (BillSubjectsEnum statusEnum : values()) {
            if (statusEnum.getValue().equals(state)) {
                return statusEnum.getName();
            }
        }
        return "";
    }
}
