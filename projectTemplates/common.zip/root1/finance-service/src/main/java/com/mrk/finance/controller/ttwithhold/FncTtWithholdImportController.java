package com.mrk.finance.controller.ttwithhold;

import com.github.pagehelper.PageInfo;
import com.mrk.common.utils.page.JsonResult;
import com.mrk.finance.facade.ttwithhold.FncWithholdImportFacade;
import com.mrk.finance.model.FncTemp;
import com.mrk.finance.queryvo.FncTempQueryVo;
import com.mrk.finance.queryvo.FncTtWithholdQueryVo;
import com.mrk.finance.service.FncTempService;
import com.mrk.log.annotation.Log;
import com.mrk.log.enums.BusinessType;
import com.mrk.log.enums.OperatorType;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiImplicitParam;
import io.swagger.annotations.ApiImplicitParams;
import io.swagger.annotations.ApiOperation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import javax.servlet.http.HttpServletResponse;


/**
 * FncTtWithholdController

 */
@RestController
@RequestMapping("/financeservice/fncttwithhold/import")
@Api(tags = "T3代扣明细导入明细")
public class FncTtWithholdImportController {
    @Autowired
    private FncTempService fncTempService;

    @Autowired
    private FncWithholdImportFacade fncWithholdImportFacade;


    @PostMapping(value = "/import_file")
    @ApiOperation("T3代扣明细导入数据-导入文件")
    @ApiImplicitParams({
      @ApiImplicitParam(paramType = "header", name = "Authorization", value = "系统下发的token", required = true),
      @ApiImplicitParam(paramType = "body", name = "operateCode", value = "操作标识", required = true)
    })
    public JsonResult<Object> importFile(MultipartFile file, String operateCode) {
        fncWithholdImportFacade.importFile(file, operateCode);
        return JsonResult.success();
    }

    @GetMapping(value = "/schedule")
    @ApiOperation("T3代扣明细导入数据-获取处理进度")
    @ApiImplicitParams({
      @ApiImplicitParam(paramType = "header", name = "Authorization", value = "系统下发的token", required = true),
      @ApiImplicitParam(paramType = "query", name = "operateCode", value = "操作标识", required = true)
    })
    public JsonResult<Object> schedule(@RequestParam("operateCode") String operateCode) {
        Integer schedule = fncWithholdImportFacade.schedule(operateCode);
        return JsonResult.success(schedule);
    }

    @GetMapping(value = "/import_result")
    @ApiOperation("T3代扣明细导入数据-获取上传结果")
    @ApiImplicitParams({
      @ApiImplicitParam(paramType = "header", name = "Authorization", value = "系统下发的token", required = true),
      @ApiImplicitParam(paramType = "query", name = "operateCode", value = "操作标识", required = true)
    })
    public JsonResult<Object> importResult(@RequestParam("operateCode")String operateCode) {
        Integer result = fncWithholdImportFacade.importResult(operateCode);
        return JsonResult.success(result);
    }

    @GetMapping(value = "/down_file")
    @ApiOperation("T3代扣明细导入数据-下载文件")
    @ApiImplicitParams({
      @ApiImplicitParam(paramType = "header", name = "Authorization", value = "系统下发的token", required = true),
      @ApiImplicitParam(paramType = "query", name = "operateCode", value = "操作标识", required = true)
    })
    public void downFile(String operateCode, HttpServletResponse response) {
        fncWithholdImportFacade.downFile(operateCode, response);
    }

    @GetMapping(value = "/preview/page")
    @ApiOperation("T3导入数据-预览功能")
    @ApiImplicitParams({
      @ApiImplicitParam(paramType = "header", name = "Authorization", value = "系统下发的token", required = true),
      @ApiImplicitParam(paramType = "query", name = "operateCode", value = "操作标识", required = true)
    })
    public JsonResult<PageInfo<FncTemp>> previewData(FncTempQueryVo fncTempQueryVo) {
        return JsonResult.success(fncTempService.page(fncTempQueryVo));
    }

    @GetMapping(value = "/tt_template")
    @ApiOperation("T3导入数据-下载导入模板")
    @ApiImplicitParams({
      @ApiImplicitParam(paramType = "header", name = "Authorization", value = "系统下发的token", required = true)
    })
    public void ttTemplate(HttpServletResponse httpServletResponse) {
        fncWithholdImportFacade.peepareTemplate(httpServletResponse);
    }

    @PostMapping(value = "/confirm_import")
    @ApiOperation("T3导入数据-确认导入")
    @ApiImplicitParams({
      @ApiImplicitParam(paramType = "header", name = "Authorization", value = "系统下发的token", required = true),
      @ApiImplicitParam(paramType = "query", name = "operateCode", value = "操作标识", required = true)
    })
    @Log(title = "T3导入数据", businessType = BusinessType.IMPORT, isSaveRequestData = true, value = "T3导入数据-确认导入")
    public JsonResult<Object> confirmImport(String operateCode) {
        fncWithholdImportFacade.confirmImport(operateCode);
        return JsonResult.success();
    }

    @GetMapping(value = "/export")
    @ApiOperation("T3导入数据-导出")
    @ApiImplicitParams({
      @ApiImplicitParam(paramType = "header", name = "Authorization", value = "系统下发的token", required = true)
    })
    @Log(title = "T3导入数据", businessType = BusinessType.EXPORT, operatorType = OperatorType.MANAGE, isSaveRequestData = true, value = "用车申请-导出")
    public void export(FncTtWithholdQueryVo queryVo, HttpServletResponse response) {
        fncWithholdImportFacade.export(queryVo, response);
    }
}
