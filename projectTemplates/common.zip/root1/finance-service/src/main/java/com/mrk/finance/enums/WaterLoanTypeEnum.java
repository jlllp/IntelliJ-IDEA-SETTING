package com.mrk.finance.enums;

import lombok.Getter;

/**
 * @project: mrk-finance
 * @author: Frank.Tang
 * @date: 2021-11-12 16:44
 * @desc:
 **/
@Getter
public enum WaterLoanTypeEnum {

    /***/
    BORROW(0, "借"),
    LOAN(1, "贷");

    private Integer value;
    private String name;

    WaterLoanTypeEnum(Integer value, String name) {
        this.value = value;
        this.name = name;
    }

    public static String getName(Integer state) {
        if (state == null) {
            return "";
        }
        for (WaterLoanTypeEnum statusEnum : values()) {
            if (statusEnum.getValue().equals(state)) {
                return statusEnum.getName();
            }
        }
        return "";
    }

    public static Integer getValue(String name) {
        if (name == null) {
            return -1;
        }
        for (WaterLoanTypeEnum statusEnum : values()) {
            if (statusEnum.getName().equals(name)) {
                return statusEnum.getValue();
            }
        }
        return -1;
    }

}
