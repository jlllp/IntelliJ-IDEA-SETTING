package com.mrk.finance.resolver;

import com.mrk.common.resolver.IResolver;
import com.mrk.finance.enums.MatchWayEnum;
import com.mrk.finance.enums.WaterMatchStateEnum;
import com.mrk.universal.enums.contract.ContractMarginPayRequireEnum;
import com.mrk.universal.enums.contract.ContractSubletEnum;

/**
 * @author Bob
 * @description
 */
@SuppressWarnings("all")
public class EnumResolver {

    public static final IResolver 匹配状态 = new IResolver() {
        /**
         * 解析器接口方法 可以用任意数据类型作为返回值类型
         * @param data 待处理的数据
         * @return 解析后的任意数据
         */
        @Override
        public <T> T get(Object data) {
            try {
                return (T) WaterMatchStateEnum.getName((Integer) data);
            } catch (Exception e) {
                return null;
            }
        }
    };

    public static final IResolver 匹配方式 = new IResolver() {
        /**
         * 解析器接口方法 可以用任意数据类型作为返回值类型
         * @param data 待处理的数据
         * @return 解析后的任意数据
         */
        @Override
        public <T> T get(Object data) {
            try {
                return (T) MatchWayEnum.getName((Integer) data);
            } catch (Exception e) {
                return null;
            }
        }
    };

    /**
     * 保证金支付要求枚举解析
     */
    public static final IResolver 保证金支付要求 = new IResolver() {
        /**
         * 解析器接口方法 可以用任意数据类型作为返回值类型
         * @param data 待处理的数据
         * @return 解析后的任意数据
         */
        @Override
        public <T> T get(Object data) {
            try {
                return (T) ContractMarginPayRequireEnum.getName((Integer) data);
            } catch (Exception e) {
                return null;
            }
        }
    };


    /**
     * 保证金支付要求枚举解析
     */
    public static final IResolver 合同是否转租 = new IResolver() {
        /**
         * 解析器接口方法 可以用任意数据类型作为返回值类型
         * @param data 待处理的数据
         * @return 解析后的任意数据
         */
        @Override
        public <T> T get(Object data) {
            try {
                return (T) ContractSubletEnum.getByState((Integer) data);
            } catch (Exception e) {
                return null;
            }
        }
    };
}
