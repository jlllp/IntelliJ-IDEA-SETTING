package com.mrk.finance.controller;

import com.github.pagehelper.PageInfo;
import com.mrk.common.utils.page.JsonResult;
import com.mrk.finance.dto.FncBillManagementDto;
import com.mrk.finance.dto.FncContractManagementDto;
import com.mrk.finance.dto.contract.RentCalculationDto;
import com.mrk.finance.facade.contract.ContractPdfFacade;
import com.mrk.finance.facade.contract.FncContractManagementFacade;
import com.mrk.finance.model.FncContractManagement;
import com.mrk.finance.queryvo.FncBillManagementQueryVo;
import com.mrk.finance.queryvo.FncContractManagementQueryVo;
import com.mrk.finance.service.FncContractManagementService;
import com.mrk.finance.vo.ContractAddOrUpdateVo;
import com.mrk.log.annotation.Log;
import com.mrk.log.enums.BusinessType;
import com.mrk.log.enums.OperatorType;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiImplicitParam;
import io.swagger.annotations.ApiImplicitParams;
import io.swagger.annotations.ApiOperation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import javax.servlet.http.HttpServletResponse;
import java.math.BigDecimal;
import java.util.List;


/**
 * FncContractManagementController

 */
@RestController
@RequestMapping("/financeservice/fnccontractmanagement")
@Api(tags = "2022年6月02日-合同管理")
public class FncContractManagementController {

    @Autowired
    private FncContractManagementFacade fncContractManagementFacade;

    @Autowired
    private FncContractManagementService fncContractManagementService;

    @Autowired
    private ContractPdfFacade contractPdfFacade;

    @GetMapping(value = "/page")
    @ApiOperation("合同管理-分页查询")
    @ApiImplicitParams({
            @ApiImplicitParam(paramType = "header", name = "Authorization", value = "系统下发的token", required = true)
    })
    public JsonResult<PageInfo<FncContractManagementDto>> page(FncContractManagementQueryVo queryVo) {
        return JsonResult.success(fncContractManagementFacade.page(queryVo));
    }

    @GetMapping(value = "/list")
    @ApiOperation("合同管理-列表查询")
    @ApiImplicitParams({
      @ApiImplicitParam(paramType = "header", name = "Authorization", value = "系统下发的token", required = true)
    })
    public JsonResult<List<FncContractManagement>> list(FncContractManagementQueryVo queryVo) {
        return JsonResult.success(fncContractManagementService.list(queryVo));
    }

    @GetMapping(value = "/page_bill_of_contract")
    @ApiOperation("合同管理-分页查询所含的账单")
    @ApiImplicitParams({
            @ApiImplicitParam(paramType = "header", name = "Authorization", value = "系统下发的token", required = true)
    })
    public JsonResult<PageInfo<FncBillManagementDto>> pageBillOfContract(FncBillManagementQueryVo queryVo) {
        return JsonResult.success(fncContractManagementFacade.pageBillOfContract(queryVo));
    }

    @PostMapping(value = "/add")
    @ApiOperation("合同管理-新增")
    @ApiImplicitParams({
            @ApiImplicitParam(paramType = "header", name = "Authorization", value = "系统下发的token", required = true)
    })
    @Log(title = "合同管理", value = "新增", businessType = BusinessType.INSERT, operatorType = OperatorType.MANAGE)
    public JsonResult<Integer> add(@RequestBody ContractAddOrUpdateVo entity) {
        return JsonResult.success(fncContractManagementFacade.add(entity)).setMsg("新增成功");
    }

    @PostMapping(value = "/update")
    @ApiOperation("合同管理-更新")
    @ApiImplicitParams({
            @ApiImplicitParam(paramType = "header", name = "Authorization", value = "系统下发的token", required = true)
    })
    @Log(title = "合同管理", value = "更新", businessType = BusinessType.UPDATE, operatorType = OperatorType.MANAGE)
    public JsonResult<Integer> update(@RequestBody ContractAddOrUpdateVo entity) {
        return JsonResult.success(fncContractManagementFacade.update(entity)).setMsg("更新成功");
    }

    @PostMapping(value = "/del/{id}")
    @ApiOperation("合同管理-删除")
    @ApiImplicitParams({
            @ApiImplicitParam(paramType = "header", name = "Authorization", value = "系统下发的token", required = true)
    })
    @Log(title = "合同管理", value = "删除", businessType = BusinessType.DELETE, operatorType = OperatorType.MANAGE)
    public JsonResult<Integer> del(@PathVariable("id") Long id) {
        return JsonResult.success(fncContractManagementFacade.del(id)).setMsg("删除成功");
    }

    @PostMapping(value = "/del_batch")
    @ApiOperation("合同管理-批量删除")
    @ApiImplicitParams({
            @ApiImplicitParam(paramType = "header", name = "Authorization", value = "系统下发的token", required = true)
    })
    @Log(title = "合同管理", value = "批量删除", businessType = BusinessType.DELETE, operatorType = OperatorType.MANAGE)
    public JsonResult<Integer> del(@RequestBody List<Long> ids) {
        return JsonResult.success(fncContractManagementFacade.delBatch(ids)).setMsg("删除成功");
    }

    @GetMapping(value = "/cal_end_date")
    @ApiOperation("合同管理-计算结束日期")
    @ApiImplicitParams({
            @ApiImplicitParam(paramType = "header", name = "Authorization", value = "系统下发的token", required = true)
    })
    public JsonResult<String> calEndDate(FncContractManagement contract) {
        return JsonResult.success(fncContractManagementFacade.calEndDate(contract)).setMsg("计算成功");
    }

    @PostMapping(value = "/cal_rent_total")
    @ApiOperation("合同管理-计算总租金(固定/不固定)")
    @ApiImplicitParams({
            @ApiImplicitParam(paramType = "header", name = "Authorization", value = "系统下发的token", required = true)
    })
    public JsonResult<BigDecimal> calRentTotal(@RequestBody RentCalculationDto dto) {
        return JsonResult.success(fncContractManagementFacade.calRentTotal(dto)).setMsg("计算成功");
    }

    @GetMapping(value = "/export")
    @ApiOperation("合同管理-按条件导出")
    @ApiImplicitParams({
            @ApiImplicitParam(paramType = "header", name = "Authorization", value = "系统下发的token", required = true)
    })
    @Log(title = "合同管理", businessType = BusinessType.EXPORT, operatorType = OperatorType.MANAGE, value = "合同管理-导出")
    public void export(FncContractManagementQueryVo queryVo, HttpServletResponse response) {
        fncContractManagementFacade.export(queryVo, response);
    }

    @GetMapping(value = "/down_pdf")
    @ApiOperation("2022年6月02日-合同管理-PDF方式下载合同")
    @ApiImplicitParams({
            @ApiImplicitParam(paramType = "header", name = "Authorization", value = "系统下发的token", required = true)
    })
    public void downPdf(HttpServletResponse response, Long contractId) {
        contractPdfFacade.downPdf(response, contractId);
    }
}
