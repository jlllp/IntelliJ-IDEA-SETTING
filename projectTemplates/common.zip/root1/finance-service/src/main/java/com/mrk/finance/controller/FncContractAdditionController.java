package com.mrk.finance.controller;

import com.github.pagehelper.PageInfo;
import com.mrk.common.utils.page.JsonResult;
import com.mrk.finance.facade.contract.FncContractAdditionFacade;
import com.mrk.finance.model.FncContractAddition;
import com.mrk.finance.queryvo.FncContractAdditionQueryVo;
import com.mrk.finance.service.FncContractAdditionService;
import com.mrk.log.annotation.Log;
import com.mrk.log.enums.BusinessType;
import com.mrk.log.enums.OperatorType;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiImplicitParam;
import io.swagger.annotations.ApiImplicitParams;
import io.swagger.annotations.ApiOperation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;


/**
 * FncContractAdditionController

 */
@RestController
@RequestMapping("/financeservice/fnccontractaddition")
@Api(tags = "合同补充协议")
public class FncContractAdditionController {
    @Autowired
    private FncContractAdditionService fncContractAdditionService;
    @Autowired
    private FncContractAdditionFacade fncContractAdditionFacade;

    @PostMapping(value = "/add")
    @ApiOperation("合同补充协议-新增")
    @ApiImplicitParams({
            @ApiImplicitParam(paramType = "header", name = "Authorization", value = "系统下发的token", required = true)
    })
    @Log(title = "合同补充协议", value = "新增", businessType = BusinessType.INSERT, operatorType = OperatorType.MANAGE)
    public JsonResult<Integer> add(@RequestBody FncContractAddition entity) {
        return JsonResult.success(fncContractAdditionFacade.add(entity));
    }

    @PostMapping(value = "/add_batch")
    @ApiOperation("合同补充协议-批量新增")
    @ApiImplicitParams({
            @ApiImplicitParam(paramType = "header", name = "Authorization", value = "系统下发的token", required = true)
    })
    @Log(title = "合同补充协议", value = "批量新增", businessType = BusinessType.INSERT, operatorType = OperatorType.MANAGE)
    public JsonResult<Integer> addBatch(@RequestBody List<FncContractAddition> entities) {
        return JsonResult.success(fncContractAdditionFacade.addBatch(entities));
    }

    @PostMapping(value = "/del/{id}")
    @ApiOperation("合同补充协议-删除")
    @ApiImplicitParams({
            @ApiImplicitParam(paramType = "header", name = "Authorization", value = "系统下发的token", required = true)
    })
    @Log(title = "合同补充协议", value = "删除", businessType = BusinessType.DELETE, operatorType = OperatorType.MANAGE)
    public JsonResult<Integer> del(@PathVariable("id") Long id) {
        return JsonResult.success(fncContractAdditionService.delete(id));
    }

    @PostMapping(value = "/update")
    @ApiOperation("合同补充协议-更新")
    @ApiImplicitParams({
            @ApiImplicitParam(paramType = "header", name = "Authorization", value = "系统下发的token", required = true)
    })
    @Log(title = "合同补充协议", value = "更新", businessType = BusinessType.UPDATE, operatorType = OperatorType.MANAGE)
    public JsonResult<Integer> update(FncContractAddition entity) {
        return JsonResult.success(fncContractAdditionService.update(entity));
    }


    @GetMapping(value = "/page")
    @ApiOperation("合同补充协议-分页查询")
    @ApiImplicitParams({
            @ApiImplicitParam(paramType = "header", name = "Authorization", value = "系统下发的token", required = true)
    })
    public JsonResult<PageInfo<FncContractAddition>> page(FncContractAdditionQueryVo queryVo) {
        return JsonResult.success(fncContractAdditionService.page(queryVo));
    }

    @GetMapping(value = "/list")
    @ApiOperation("合同补充协议-列表查询")
    @ApiImplicitParams({
            @ApiImplicitParam(paramType = "header", name = "Authorization", value = "系统下发的token", required = true)
    })
    public JsonResult<List<FncContractAddition>> list(FncContractAdditionQueryVo queryVo) {
        return JsonResult.success(fncContractAdditionService.list(queryVo));
    }


}
