package com.mrk.finance.util;

import com.mrk.common.exception.GlobalException;

/**
 * @project: mrk-finance
 * @author: Frank.Tang
 * @date: 2021-11-10 18:12
 * @desc:
 **/
public class ExceptionUtil {

    private ExceptionUtil() {

    }


    /*********************************************************************************
     * 拼接异常信息 (不存在时)
     * @author Frank.Tang
     * @param name 数据的名称 (id 或 name)
     * @param target 数据值 (id=10 或 name="xxx")
     * @return 拼接后的异常信息
     */
    public static String notExistMsg(String name, Object target) {
        return String.format("数据异常, %s[%s]未查询到对应的数据, 或已被删除", name, target);
    }

    /**
     * 抛出异常 (不存在时)
     * @author Frank.Tang
     * @param name 数据的名称 (id 或 name)
     * @param target 数据值 (id=10 或 name="xxx")
     */
    public static GlobalException notExist(String name, Object target) {
        return new GlobalException(String.format("数据异常, %s[%s]未查询到对应的数据, 或已被删除", name, target));
    }

    /*********************************************************************************
     * 拼接异常信息 (不存在时) (默认id)
     * @author Frank.Tang
     * @return 拼接后的异常信息
     */
    public static String idNotExistMsg(Object target) {
        return notExistMsg("id", target);
    }

    /**
     * 抛出异常 (不存在时) (默认id)
     * @author Frank.Tang
     * @param target 数据值 (id=10 或 name="xxx")
     */
    public static GlobalException idNotExist(Object target) {
        return new GlobalException(notExistMsg("id", target));
    }

    /*********************************************************************************
     * 拼接异常信息 (枚举不存在时)
     * @author Frank.Tang
     * @return 拼接后的异常信息
     */
    public static String enumNotExistMsg(String name) {
        return String.format("数据异常, [%s]不存在对应的枚举值", name);
    }

    /**
     * 抛出异常 (枚举不存在时)
     * @author Frank.Tang
     */
    public static GlobalException enumNotExist(String name) {
        return new GlobalException(enumNotExistMsg(name));
    }


    /*********************************************************************************
     * 拼接异常信息 (超长时)
     * @author Frank.Tang
     * @param name 字段名
     * @return 拼接后的异常信息
     */
    public static String outLenMsg(String name) {
        return String.format("数据异常, [%s]超长", name);
    }

    /**
     * 抛出异常信息 (超长时)
     * @author Frank.Tang
     * @param name 字段名
     */
    public static GlobalException outLen(String name) {
        return new GlobalException(String.format("数据异常, [%s]超长", name));
    }


    /*********************************************************************************
     * 拼接异常信息 (为空时)
     * @author Frank.Tang
     * @param name 字段名
     * @return 拼接后的异常信息
     */
    public static String nullMsg(String name) {
        return String.format("数据异常, [%s]不能为空", name);
    }

    /**
     * 抛出异常 (重复时)
     * @author Frank.Tang
     * @param name 字段名
     */
    public static GlobalException duplicate(String name, Object target) {
        return new GlobalException(String.format("数据异常, %s[%s]在数据库中重复", name, target));
    }

}
