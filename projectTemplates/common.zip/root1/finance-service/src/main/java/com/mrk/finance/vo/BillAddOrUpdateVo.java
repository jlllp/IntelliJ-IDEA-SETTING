package com.mrk.finance.vo;

import com.mrk.finance.model.FncBillManagement;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

/**
 * @project: mrk-finance
 * @author: Frank.Tang
 * @date: 2021-11-11 11:14
 * @desc:
 **/
@Data
public class BillAddOrUpdateVo extends FncBillManagement {

    @ApiModelProperty("车牌号")
    private String plateNum;

    @ApiModelProperty("合同号")
    private String associateContractNo;

}
