package com.mrk.finance.facade.ddwithhold;

import cn.afterturn.easypoi.excel.ExcelExportUtil;
import cn.afterturn.easypoi.excel.ExcelImportUtil;
import cn.afterturn.easypoi.excel.entity.ExportParams;
import cn.afterturn.easypoi.excel.entity.ImportParams;
import cn.afterturn.easypoi.excel.entity.result.ExcelImportResult;
import com.github.pagehelper.PageInfo;
import com.mrk.common.constant.BaseConstants;
import com.mrk.common.exception.GlobalException;
import com.mrk.common.utils.bean.BeanUtils;
import com.mrk.common.utils.container.ListUtil;
import com.mrk.common.utils.jwt.JWTUtil;
import com.mrk.common.utils.redis.RedisUtil;
import com.mrk.common.utils.text.CheckUtil;
import com.mrk.finance.dto.fncddexport.FncDdWithholdDto;
import com.mrk.finance.dto.fncddexport.FncDdWithholdExportByQueryDto;
import com.mrk.finance.dto.fncddexport.FncDdWithholdExportDto;
import com.mrk.finance.enums.MatchWayEnum;
import com.mrk.finance.enums.WaterMatchStateEnum;
import com.mrk.finance.facade.CarExportFacade;
import com.mrk.finance.facade.ExportFacade;
import com.mrk.finance.facade.FncWaterAutoMatchFacade;
import com.mrk.finance.model.FncDdWithhold;
import com.mrk.finance.model.FncTemp;
import com.mrk.finance.queryvo.FncDdWithholdQueryVo;
import com.mrk.finance.service.FncDdWithholdService;
import com.mrk.finance.service.FncTempService;
import com.mrk.finance.util.StreamUtil;
import com.mrk.finance.vo.ddwithhold.FncDdWithholdImportVo;
import com.mrk.resource.client.ResCarQueryClient;
import com.mrk.resource.model.ResCar;
import org.apache.poi.hssf.usermodel.HSSFCellStyle;
import org.apache.poi.hssf.util.HSSFColor;
import org.apache.poi.ss.usermodel.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.CollectionUtils;
import org.springframework.web.multipart.MultipartFile;

import javax.servlet.http.HttpServletResponse;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.concurrent.TimeUnit;
import java.util.regex.Pattern;

/**
 * @ClassName ResCarScrapImportFacade
 * @Author Vllos
 * @Date 2021-04-19 14:56
 * @Version 1.0
 */
@Component
public class FncDdWithholdImportFacade {

    private static final Logger log = LoggerFactory.getLogger(FncDdWithholdImportFacade.class);
    @Autowired
    private FncTempService fncTempService;
    @Autowired
    private RedisUtil redisUtil;

    @Autowired
    private CarExportFacade exportByExcel;

    @Autowired
    private FncDdWithholdFacade fncDdWithholdFacade;
    @Autowired
    private FncWaterAutoMatchFacade fncWaterAutoMatchFacade;

    @Autowired
    private FncDdWithholdService fncDdWithholdService;

    @Autowired
    private ExportFacade exportFacade;


    @Autowired
    private ResCarQueryClient resCarQueryClient;
    /**
     * @description 导入文件
     */
    @Transactional(rollbackFor = Exception.class)
    public void importFile(MultipartFile file, String operateCode) {
        String userName = JWTUtil.getNikeName();
        log.info("开始导入设备数据，操作人 --> userName：【{}】", userName);
        // 删除操作标识中的数据
        fncTempService.deleteByOperateCode(operateCode);
        // 读取excel中的文件
        List<FncDdWithholdImportVo> fncDdWithholdImportVos = this.resCarScrapImportVoList(file);
        if(CollectionUtils.isEmpty(fncDdWithholdImportVos)){
            throw new GlobalException("导入数据错误");
        }
        // 处理数据
        this.dispose(fncDdWithholdImportVos, operateCode);
    }

    /**
     * @description 获取excel文件中的数据
     */
    private List<FncDdWithholdImportVo> resCarScrapImportVoList(MultipartFile file) {
        try {
            ExcelImportResult<FncDdWithholdImportVo> result = ExcelImportUtil.importExcelMore
                    (file.getInputStream(), FncDdWithholdImportVo.class, new ImportParams());
            return result.getList();
        } catch (Exception e) {
            log.error("获取excel文件中的数据", e);
            throw new GlobalException("解析文件失败，请检查数据");
        }
    }

    /**
     * @date 2021/3/29 17:21
     * @description 处理Excel中的数据
     */
    private void dispose(List<FncDdWithholdImportVo> fncDdWithholdImportVos, String operateCode) {
        int total = fncDdWithholdImportVos.size();
        for (int i = 0; i < fncDdWithholdImportVos.size(); i++) {
            FncDdWithholdImportVo fncDdWithholdImportVo = fncDdWithholdImportVos.get(i);
            // 检查数据是否是空 空的就跳过
            if (!this.checkIsNull(fncDdWithholdImportVo)) {
                // 保存数据
                this.doSave(fncDdWithholdImportVo, operateCode);
            }
            // 修改进度 百分比
            int schedule = (i + 1) * 100 / total;
            final String key = scheduleKey(operateCode);
            // 设置有效时间
            redisUtil.set(key, String.valueOf(schedule));
            redisUtil.expire(key, 30, TimeUnit.SECONDS);
        }
    }

    /**
     * @description 检查重要的数据是否为空
     */
    private boolean checkIsNull(FncDdWithholdImportVo fncDdWithholdImportVo) {
        // 检查重要数据是否都为空 为空则认为空数据
        return CheckUtil.isEmpty(fncDdWithholdImportVo.getFncAccountNo())
                && CheckUtil.isEmpty(fncDdWithholdImportVo.getFncOrderNo())
                && CheckUtil.isEmpty(fncDdWithholdImportVo.getFncCarVin())
                && CheckUtil.isEmpty(fncDdWithholdImportVo.getFncAccountDealFlow())
                && CheckUtil.isEmpty(fncDdWithholdImportVo.getFncTradeAmount())
                && CheckUtil.isEmpty(fncDdWithholdImportVo.getFncTradeNames())
                && CheckUtil.isEmpty(fncDdWithholdImportVo.getFncTradeParty())
                && CheckUtil.isEmpty(fncDdWithholdImportVo.getFncTradeTime());
    }

    /**
     * @description 保存数据
     */
    private void doSave(FncDdWithholdImportVo fncDdWithholdImportVo, String operateCode) {

        if(CheckUtil.isNotEmpty(fncDdWithholdImportVo.getFncTradeAmountStr())){
            fncDdWithholdImportVo.setFncTradeAmount(Double.valueOf(fncDdWithholdImportVo.getFncTradeAmountStr().replace(",","")));
        }
        FncTemp fncTemp = BeanUtils.copyBean(fncDdWithholdImportVo, FncTemp.class);

        StringBuilder sb = new StringBuilder();
        fncTemp.setFncOperateCode(operateCode);
        //车架号
        String pattern = "^[A-HJ-NPR-Z\\d]{17}#[[\$]]#";
        if(CheckUtil.isEmpty(fncDdWithholdImportVo.getFncCarVin())){
            sb.append("车架号为空，");
        }
        if (CheckUtil.isNotEmpty(fncDdWithholdImportVo.getFncCarVin()) && !Pattern.matches(pattern, fncDdWithholdImportVo.getFncCarVin().toUpperCase())) {
            sb.append("输入的车架号不规范，");
        }
        if(CheckUtil.isEmpty(fncDdWithholdImportVo.getFncOrderNo())){
            sb.append("订单号为空，");
        }
        if(CheckUtil.isEmpty(fncDdWithholdImportVo.getFncAccountNo())){
            sb.append("账单号为空，");
        }
        if (CheckUtil.isEmpty(fncDdWithholdImportVo.getFncTradeTime())) {
            sb.append("交易时间为空，");
        }
        if (CheckUtil.isEmpty(fncDdWithholdImportVo.getFncTradeNames())) {
            sb.append("交易账目为空，");
        }
        if (CheckUtil.isEmpty(fncDdWithholdImportVo.getFncTradeParty())) {
            sb.append("交易方为空，");
        }
        if (CheckUtil.isEmpty(fncDdWithholdImportVo.getFncAccountDealFlow())) {
            sb.append("交易流水号为空，");
        }
        if (CheckUtil.isEmpty(fncDdWithholdImportVo.getFncTradeAmountStr())) {
            sb.append("交易金额为空，");
        }
        //检验车架号是否存在
        List<ResCar> resCarList = resCarQueryClient.findCarByEngineNumPlateNum(fncDdWithholdImportVo.getFncCarVin(), null).getDataWithEx();
        if(CollectionUtils.isEmpty(resCarList)){
            sb.append("车架号不存在，");
        }
        if (CheckUtil.isNotEmpty(sb.toString())) {
            fncTemp.setFncError(1);
            fncTemp.setFncErrorMsg(sb.substring(0, sb.length() - 1));
        } else {
            fncTemp.setFncError(0);
        }
        fncTempService.add(fncTemp);
    }

    /**
     * @description 获取进度的redisKey
     */
    private String scheduleKey(String operateCode) {
        return String.format("schedule:{%s}", operateCode);
    }

    /**
     * @description 根据文件标识符获取处理进度
     */
    public Integer schedule(String operateCode) {
        CheckUtil.isEmptyWithEx(operateCode, "操作标识不能为空");
        String value = redisUtil.get(scheduleKey(operateCode));
        try {
            return Integer.parseInt(value);
        } catch (NumberFormatException e) {
            return 0;
        }
    }

    /**
     * @description 根据标识符获取上传结果
     * 0 正常 1有错误
     */
    public Integer importResult(String operateCode) {
        List<FncTemp> fncTemps = fncTempService.selectErrorByOperateCode(operateCode);
        return fncTemps.isEmpty() ? 0 : 1;
    }

    /**
     * @description 根据标识符下载文件，错误的数据标红
     */
    public void downFile(String operateCode, HttpServletResponse response) {
        // 根据标识符获取设备数据
        List<FncTemp> fncTemps = fncTempService.selectByOperateCode(operateCode);
        List<FncDdWithholdExportDto> boxDownVos = new ArrayList<>();
        for (FncTemp fncTemp : fncTemps) {
            FncDdWithholdExportDto fncDdWithholdExportDto = BeanUtils.copyBean(fncTemp, FncDdWithholdExportDto.class);
            boxDownVos.add(fncDdWithholdExportDto);
        }
        Workbook workbook = ExcelExportUtil.exportExcel(new ExportParams(), FncDdWithholdExportDto.class, boxDownVos);
        // 设置单元格样式
        setExcelStyle(workbook);
        String fileName = "滴滴数据" + System.currentTimeMillis() + ".xls";
        exportByExcel.exportByExcel(response, fileName, workbook);
    }

    /**
     * @description 设置单元格样式
     */
    public void setExcelStyle(Workbook workbook) {
        Sheet sheet = workbook.getSheetAt(0);
        // 创建红色的字体颜色样式
        Font font = workbook.createFont();
        // 字体颜色
        font.setColor(HSSFColor.HSSFColorPredefined.RED.getIndex());
        HSSFCellStyle cellStyle = (HSSFCellStyle) workbook.createCellStyle();
        // 前景色填充
        cellStyle.setFillPattern(FillPatternType.SOLID_FOREGROUND);
        // 前景填充色
        cellStyle.setFillForegroundColor(HSSFColor.HSSFColorPredefined.LEMON_CHIFFON.getIndex());
        // 字体居中
        cellStyle.setAlignment(HorizontalAlignment.CENTER);
        cellStyle.setFont(font);
        for (int i = 1; i <= sheet.getLastRowNum(); i++) {
            Row row = sheet.getRow(i);
            // 获取小标为3的列数据 对应错误数据
            Cell cell;
            String value = row.getCell(8).toString().trim();
            // 说明此列数据错误
            if (CheckUtil.isNotEmpty(value)) {
                final int physicalNumberOfCells = row.getPhysicalNumberOfCells();
                for (int j = 0; j < physicalNumberOfCells; j++) {
                    cell = row.getCell(j);
                    // 设置单元格格式
                    cell.setCellStyle(cellStyle);
                }
            }
        }
    }

    /**
     * @author Bob
     * @date 2021/4/25 15:50
     * @description dd导入明细模板
     * @param httpServletResponse 响应对象
     */
    public void peepareTemplate(HttpServletResponse httpServletResponse) {
        exportFacade.exportByExcel(httpServletResponse, "Dd导入明细模板.xls",
                FncDdWithholdImportVo.class, new ArrayList<>());
    }

    /**
     * @author Bob
     * @date 2021/3/30 17:15
     * @description 根据查询条件导出excel文件
     */
    public void export(FncDdWithholdQueryVo queryVo, HttpServletResponse response) {
        PageInfo<FncDdWithholdDto> ddWithholdDtoPageInfo = fncDdWithholdFacade.page(queryVo);
        int maxSize = 50000;
        if (ddWithholdDtoPageInfo.getTotal() > maxSize) {
            throw new GlobalException("导出的数量超过5万条，请缩小范围");
        }
        // 导出文件
        List<FncDdWithholdExportByQueryDto> boxUpVoList = ListUtil.copyBeanList(ddWithholdDtoPageInfo.getList(), FncDdWithholdExportByQueryDto.class);
        Workbook workbook = ExcelExportUtil.exportExcel(new ExportParams(), FncDdWithholdExportByQueryDto.class, boxUpVoList);
        String fileName = "Dd明细" + System.currentTimeMillis() + ".xls";
        exportByExcel.exportByExcel(response, fileName, workbook);
    }

    /**
     * @description 根据操作标识确定导入
     */
    @Transactional(rollbackFor = Exception.class)
    public void confirmImport(String operateCode) {
        List<FncTemp> fncTempList = fncTempService.selectErrorByOperateCode(operateCode);
        if (!fncTempList.isEmpty()) {
            throw new GlobalException("当前文件存在错误数据，不能导入");
        }
        fncTempList = fncTempService.selectByOperateCode(operateCode);
        //导入数据
        List<FncDdWithhold> fncDdWithholdList = new ArrayList<>();
        FncDdWithhold fncDdWithhold;
        for (FncTemp fncTemp : fncTempList) {
            fncDdWithhold = new FncDdWithhold();
            //账单号
            fncDdWithhold.setFdwAccountNo(fncTemp.getFncAccountNo());
            fncDdWithhold.setFdwAccountDealFlow(fncTemp.getFncAccountDealFlow());
            fncDdWithhold.setFdwCarVin(fncTemp.getFncCarVin());
            //匹配账单   TODO
            fncDdWithhold.setFdwMatchBill(null);
            fncDdWithhold.setFdwMatchState(WaterMatchStateEnum.NOT_MATCH.getValue());
            fncDdWithhold.setFdwMatchedAmount(0.0D);
            fncDdWithhold.setFdwMatchWay(null);
            fncDdWithhold.setFdwNotMatchAmount(fncTemp.getFncTradeAmount());
            //订单号
            fncDdWithhold.setFdwOrderNo(fncTemp.getFncOrderNo());
            fncDdWithhold.setFdwTradeAmount(fncTemp.getFncTradeAmount());
            fncDdWithhold.setFdwTradeNames(fncTemp.getFncTradeNames());
            fncDdWithhold.setFdwTradeParty(fncTemp.getFncTradeParty());
            fncDdWithhold.setFdwTradeTime(fncTemp.getFncTradeTime());
            //设置数据
            fncDdWithhold.setDr(BaseConstants.DR_NO);
            Date date = new Date();
            fncDdWithhold.setCreatetime(date);
            fncDdWithhold.setUpdatetime(date);
            String userName = JWTUtil.getNikeName();
            fncDdWithhold.setCreateuser(userName);
            fncDdWithhold.setUpdateuser(userName);
            fncDdWithholdList.add(fncDdWithhold);
        }
        if(CollectionUtils.isEmpty(fncDdWithholdList)){
            throw new GlobalException("导入数据为空，请重试");
        }
        int insert = fncDdWithholdService.insertList(fncDdWithholdList);
        if (insert != fncDdWithholdList.size()) {
            throw new GlobalException("导入失败，请重试");
        }

        //自动执行一次匹配
        /*fncWaterAutoMatchFacade.ddAutoMatch(StreamUtil.toList(fncDdWithholdList, FncDdWithhold::getFdwId));*/

        // 删除操作批次下的数据
        fncTempService.deleteByOperateCode(operateCode);
    }
}

