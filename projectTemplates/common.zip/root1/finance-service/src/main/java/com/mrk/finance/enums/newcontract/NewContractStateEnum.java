package com.mrk.finance.enums.newcontract;

/**
 * @author
 * @date
 * @description
 */
public enum NewContractStateEnum {

    LEASE_TO_START(0, "审批中"),
    LEASED(1, "执行中"),
    LEASE_SUSPENSION(2, "已撤销"),
    LEASE_BACK(3, "已中止"),
    LEASE_TO_END(4, "已结束");

    private final Integer state;

    private final String text;

    public Integer getState() {
        return state;
    }

    public String getText() {
        return text;
    }

    NewContractStateEnum(Integer state, String text) {
        this.state = state;
        this.text = text;
    }

    public static String getText(Integer state) {
        if (state == null) {
            return null;
        }
        for (NewContractStateEnum value : values()) {
            if (value.state.equals(state)) {
                return value.getText();
            }
        }
        return null;
    }
}
