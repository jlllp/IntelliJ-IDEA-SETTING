package com.mrk.finance.dto.contract;

import com.mrk.finance.model.FncContractManagement;
import lombok.Data;
import lombok.EqualsAndHashCode;

import java.util.List;

/**
 * @author Bob
 * @date 2021-11-23
 * @description
 */
@EqualsAndHashCode(callSuper = true)
@Data
public class RentCalculationDto extends FncContractManagement{

    /**
     * 不固定租金存放集合
     */
    List<VariableRentDto> variableRentDtoList;

    /**
     * 不固定租金dto类
     */
    @Data
    public static class VariableRentDto {
        /**
         * 开始月份
         */
        private Integer fccStartMonth;

        /**
         * 结束月份
         */
        private Integer fccEndMonth;

        /**
         * 租金金额
         */
        private Double fccRentAmount;
    }
}
