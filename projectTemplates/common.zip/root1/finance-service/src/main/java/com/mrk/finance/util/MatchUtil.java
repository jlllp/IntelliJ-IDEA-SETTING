package com.mrk.finance.util;

import com.mrk.common.exception.GlobalException;
import com.mrk.common.utils.text.CheckUtil;
import com.mrk.finance.constants.LenConstants;
import com.mrk.finance.enums.WaterLoanTypeEnum;
import com.mrk.finance.model.FncBankWater;
import com.mrk.finance.model.FncBillManagement;

import java.util.Arrays;
import java.util.Set;
import java.util.stream.Collectors;

/**
 * @project: mrk-finance
 * @author: Frank.Tang
 * @date: 2021-11-26 10:31
 * @desc: 手动/自动匹配公共方法
 **/
public class MatchUtil {

    private MatchUtil() {}


    /** 默认拼接符 */
    public static final String SEPARATOR = ",";

    /**
     * 处理拼接字符串, 将拼接后的结果返回
     * @author Frank.Tang
     * @param ids 已经有的
     * @param id 需要拼接的
     * @return 拼接后的结果
     */
    public static String splicing(String ids, Long id) {
        return splicing(ids, id.toString());
    }

    /**
     * 处理拼接字符串, 将拼接后的结果返回
     * @author Frank.Tang
     * @param origin 已经有的 (源字符串)
     * @param target 需要拼接的 (目标字符串)
     * @return (1)目标字符串为空 ----> 源字符串
     *         (2)源字符串为空 ------> 目标字符串
     *         (3)已包含目标字符串 --> 源字符串
     *         (4)未包含目标字符串 --> 源字符串 + 分隔符 + 目标字符串
     */
    public static String splicing(String origin, String target) {
        boolean originIsEmpty = CheckUtil.isEmpty(origin);
        boolean targetIsEmpty = CheckUtil.isEmpty(target);

        //如果目标字符串为空
        if (targetIsEmpty) {
            return originIsEmpty ? "" : origin.trim();
        }
        //如果源字符串为空
        if (originIsEmpty) {
            return target.trim();
        }

        origin = origin.trim();
        target = target.trim();

        //拆分, 用于判重
        Set<String> strSet = Arrays.stream(origin.split(SEPARATOR)).collect(Collectors.toSet());

        //重复了, 不拼接. 直接返回
        if (strSet.contains(target)) {
            return origin;
        }

        //拼接在源字符串的后面
        else {
            String res = origin + SEPARATOR + target;
            if (res.length() > LenConstants.LEN_2550) {
                throw new GlobalException("数据异常, 拼接的长度已达上限");
            }
            return res;
        }
    }

    /**
     * 借贷关系和账单金额正负的关系 (借找负数账单, 贷找正数账单)
     * @author Frank.Tang
     * @return true--->不符合,不匹配
     *         false-->符合,可匹配
     */
    public static boolean checkLoanRelation(FncBankWater water, FncBillManagement bill) {
        return (water.getFbwLoanType().equals(WaterLoanTypeEnum.LOAN.getValue()) && bill.getFbmBillAmount() < 0.0)
                || (water.getFbwLoanType().equals(WaterLoanTypeEnum.BORROW.getValue()) && bill.getFbmBillAmount() > 0.0);
    }

}
