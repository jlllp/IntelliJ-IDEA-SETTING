package com.mrk.finance.dto.date;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.text.SimpleDateFormat;
import java.util.Date;

/**
 * @author Bob
 * @date 2021-11-15
 * @description 时间对
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
public class TimeRightDto {

    /**
     * 开始日期
     */
    private Date start;

    /**
     * 结束日期
     */
    private Date end;

    @Override
    public String toString() {
        return "TimeRightDto{" +
                "start=" + format(start) +
                ", end=" + format(end) +
                '}';
    }

    public String format(Date date) {
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
        return sdf.format(date);
    }
}
