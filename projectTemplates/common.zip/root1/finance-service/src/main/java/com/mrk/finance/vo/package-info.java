package com.mrk.finance.vo;

// 前端请求入参对象类