package com.mrk.finance.controller.ttwithhold;

import com.github.pagehelper.PageInfo;
import com.mrk.common.utils.page.JsonResult;
import com.mrk.finance.dto.AutoMatchResOfWaterDto;
import com.mrk.finance.dto.fncttexport.FncTtWithholdDto;
import com.mrk.finance.facade.FncWaterAutoMatchFacade;
import com.mrk.finance.facade.ttwithhold.FncTtWithholdFacade;
import com.mrk.finance.model.FncTtWithhold;
import com.mrk.finance.queryvo.FncTtWithholdQueryVo;
import com.mrk.finance.service.FncTtWithholdService;
import com.mrk.finance.vo.BillMatchWaterVo;
import com.mrk.log.annotation.Log;
import com.mrk.log.enums.BusinessType;
import com.mrk.log.enums.OperatorType;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiImplicitParam;
import io.swagger.annotations.ApiImplicitParams;
import io.swagger.annotations.ApiOperation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;


/**
 * FncTtWithholdController

 */
@RestController
@RequestMapping("/financeservice/fncttwithhold")
@Api(tags = "/T3代扣明细")
public class FncTtWithholdController {
    @Autowired
    private FncTtWithholdService fncTtWithholdService;
    @Autowired
    private FncWaterAutoMatchFacade fncWaterAutoMatchFacade;
    @Autowired
    private FncTtWithholdFacade fncTtWithholdFacade;

    @PostMapping(value = "/add")
    @ApiOperation("T3代扣明细-新增")
    @ApiImplicitParams({
            @ApiImplicitParam(paramType = "header", name = "Authorization", value = "系统下发的token", required = true)
    })
    @Log(title = "T3代扣明细", value = "新增", businessType = BusinessType.INSERT, operatorType = OperatorType.MANAGE)
    public JsonResult<Object>  add(FncTtWithhold entity) {
        return JsonResult.success(fncTtWithholdService.add(entity));
    }

    @PostMapping(value = "/del/{idStr}")
    @ApiOperation("T3代扣明细-删除")
    @ApiImplicitParams({
            @ApiImplicitParam(paramType = "header", name = "Authorization", value = "系统下发的token", required = true)
    })
    @Log(title = "T3代扣明细", value = "删除", businessType = BusinessType.DELETE, operatorType = OperatorType.MANAGE)
    public JsonResult<Object>  del(@PathVariable("idStr") String idStr) {
        fncTtWithholdFacade.delete(idStr);
        return JsonResult.success();
    }

    @PostMapping(value = "/update")
    @ApiOperation("T3代扣明细-更新")
    @ApiImplicitParams({
            @ApiImplicitParam(paramType = "header", name = "Authorization", value = "系统下发的token", required = true)
    })
    @Log(title = "T3代扣明细", value = "更新", businessType = BusinessType.UPDATE, operatorType = OperatorType.MANAGE)
    public JsonResult<Object>  update(FncTtWithhold entity) {
        return JsonResult.success(fncTtWithholdService.update(entity));
    }


    @GetMapping(value = "/page")
    @ApiOperation("T3代扣明细-分页查询")
    @ApiImplicitParams({
            @ApiImplicitParam(paramType = "header", name = "Authorization", value = "系统下发的token", required = true)
    })
    public JsonResult<PageInfo<FncTtWithholdDto>> page(FncTtWithholdQueryVo queryVo) {

        return JsonResult.success(fncTtWithholdFacade.page(queryVo));
    }

    @GetMapping(value = "/list")
    @ApiOperation("T3代扣明细-列表查询")
    @ApiImplicitParams({
            @ApiImplicitParam(paramType = "header", name = "Authorization", value = "系统下发的token", required = true)
    })
    public JsonResult<List<FncTtWithhold>> list(FncTtWithholdQueryVo queryVo) {
        return JsonResult.success(fncTtWithholdService.list(queryVo));
    }

    @GetMapping(value = "/details")
    @ApiOperation("T3代扣明细-详情")
    @ApiImplicitParams({
      @ApiImplicitParam(paramType = "header", name = "Authorization", value = "系统下发的token", required = true)
    })
    public JsonResult<FncTtWithholdDto> details(Long id) {

        return JsonResult.success(fncTtWithholdFacade.details(id));
    }


    @PostMapping(value = "/price")
    @ApiOperation("T3代扣明细-手动匹配")
    @ApiImplicitParams({
      @ApiImplicitParam(paramType = "header", name = "Authorization", value = "系统下发的token", required = true)
    })
    @Log(title = "T3代扣明细", value = "手动匹配", businessType = BusinessType.OTHER, operatorType = OperatorType.MANAGE)
    public JsonResult<Object> price(@RequestBody BillMatchWaterVo billMatchWaterVo) {
        fncTtWithholdFacade.price(billMatchWaterVo);
        return JsonResult.success();
    }

    @PostMapping(value = "/match_bill_automatically")
    @ApiOperation("T3代扣明细-自动匹配")
    @ApiImplicitParams({
            @ApiImplicitParam(paramType = "header", name = "Authorization", value = "系统下发的token", required = true)
    })
    @Log(title = "T3代扣明细", value = "自动匹配", businessType = BusinessType.OTHER, operatorType = OperatorType.MANAGE)
    public JsonResult<List<AutoMatchResOfWaterDto>> autoMatch(@RequestBody List<Long> ftwIds) {
        return JsonResult.success(fncWaterAutoMatchFacade.ttAutoMatch(ftwIds)).setMsg("自动匹配成功, 请查看匹配结果");
    }

}
