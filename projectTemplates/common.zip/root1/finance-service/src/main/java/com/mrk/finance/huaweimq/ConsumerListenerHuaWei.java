package com.mrk.finance.huaweimq;

import com.mrk.finance.facade.bill.FncBillManagementFacade;
import lombok.extern.slf4j.Slf4j;
import org.apache.rocketmq.client.consumer.listener.ConsumeConcurrentlyContext;
import org.apache.rocketmq.client.consumer.listener.ConsumeConcurrentlyStatus;
import org.apache.rocketmq.client.consumer.listener.MessageListenerConcurrently;
import org.apache.rocketmq.common.message.MessageExt;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.List;


/**
 * @Author Sandy
 * @create 2021/5/8  下午 01:48
 * @description 消费消息
 */
@Component
@Slf4j
public class ConsumerListenerHuaWei implements MessageListenerConcurrently {

    @Autowired
    private FncBillManagementFacade fncBillManagementFacade;


    @Override
    public ConsumeConcurrentlyStatus consumeMessage(List<MessageExt> msgs, ConsumeConcurrentlyContext context) {
        for (MessageExt msg : msgs) {
            String tag = msg.getTags();
            try {
                ConsumerTag consumerTag = ConsumerTag.getConsumerTag(tag);
                if (consumerTag == null) {
                    log.info("接收到支付回调消息 --> tag：【{}】", tag);
                    return ConsumeConcurrentlyStatus.RECONSUME_LATER;
                } else if (ConsumerTag.CONTRACT_BILL.equals(consumerTag)) {
                    String requestJson = new String(msg.getBody());
                    fncBillManagementFacade.payNotify(requestJson);
                    return ConsumeConcurrentlyStatus.CONSUME_SUCCESS;
                }
                return ConsumeConcurrentlyStatus.CONSUME_SUCCESS;
            } catch (Exception e) {
                //消费失败
                log.error("华为云消息消费失败", e);
                return ConsumeConcurrentlyStatus.RECONSUME_LATER;
            }
        }
        return ConsumeConcurrentlyStatus.RECONSUME_LATER;
    }
}
