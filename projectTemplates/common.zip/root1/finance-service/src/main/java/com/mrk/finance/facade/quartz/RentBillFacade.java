package com.mrk.finance.facade.quartz;

import com.mrk.common.utils.bean.BeanUtils;
import com.mrk.common.utils.text.CheckUtil;
import com.mrk.finance.dto.contract.RentBillTimeRightDto;
import com.mrk.finance.dto.contract.RentCalculationDto;
import com.mrk.finance.dto.contract.RentTimeRightDto;
import com.mrk.finance.enums.*;
import com.mrk.finance.facade.bill.BillManagementGenerateFacade;
import com.mrk.finance.facade.contract.ContractFacade;
import com.mrk.finance.facade.contract.ContractOnlyCarFacade;
import com.mrk.finance.model.FncBillManagement;
import com.mrk.finance.model.FncContractManagement;
import com.mrk.finance.service.FncContractManagementService;
import com.mrk.finance.util.ThreadUtil;
import com.mrk.finance.util.contract.ContractDateCalculateUtil;
import org.apache.commons.collections4.MapUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Component;

import java.math.BigDecimal;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.*;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.Executor;

/**
 * @author Bob
 * @date 2021-11-22
 * @description
 */
@Component
public class RentBillFacade {

    private static final Logger log = LoggerFactory.getLogger(RentBillFacade.class);

    @Autowired
    private FncContractManagementService fncContractManagementService;

    @Autowired
    private ContractOnlyCarFacade contractOnlyCarFacade;

    @Autowired
    private BillManagementGenerateFacade billManagementGenerateFacade;

    @Autowired
    private ContractFacade contractFacade;

    @Qualifier("quartzServiceExecutor")
    @Autowired
    private Executor executor;

    /**
     * @param paramStr 请求参数
     * @author Bob
     * @date 2021/11/22
     * @description 租金账单生成
     */
    public void rentBillGeneration(String paramStr) {
        log.info("租金账单生成 --> 开始");
        long start = System.currentTimeMillis();
        // 获取租赁中的合同
        List<FncContractManagement> fncContractManagements = fncContractManagementService.getByState(ContractStateEnum.LEASED.getState());
        log.info("租金账单生成 获取到租赁中状态的合同 --> size：【{}】", fncContractManagements.size());
        List<FncContractManagement> contractManagementList = new ArrayList<>(fncContractManagements);

        // 获取 合同租赁结束且租赁结束日期不超过30天的合同
        // 获取今天的格式化日期 不要时分秒
        try {
            SimpleDateFormat simpleDateFormat = new SimpleDateFormat("yyyy-MM-dd");
            String format = simpleDateFormat.format(new Date());
            Date now = simpleDateFormat.parse(format);
            Date minimumDate = ContractDateCalculateUtil.increaseDay(now, -30);
            fncContractManagements = fncContractManagementService.getByStateAndEndDateGTOE(ContractStateEnum.LEASE_TO_END.getState(), minimumDate);
            log.info("租金账单生成 获取到合同租赁结束且租赁结束日期不超过30天的合同 --> size：【{}】", fncContractManagements.size());
            contractManagementList.addAll(fncContractManagements);
        } catch (ParseException e) {
            log.warn("租金账单生成 合同租赁结束且租赁结束日期不超过30天的合同失败，本次跳过计算", e);
        }

        ThreadUtil.execution(contractManagementList, this::rentBillGenerator, executor);
        log.info("租金账单生成 --> 结束 耗时：【{}】", System.currentTimeMillis() - start);
    }

    /**
     * @param countDownLatch        同步辅助
     * @param fncContractManagement 待计算租金账单的合同
     * @author Bob
     * @date 2021/11/22
     * @description 计算每个合同的租金账单 是否生成
     */
    private void rentBillGenerator(CountDownLatch countDownLatch, FncContractManagement fncContractManagement) {
        try {
            // 转换为租金计算Map
            RentCalculationDto rentCalculationDto = contractFacade.transformRentCalculationDto(fncContractManagement);
            // 构建租金周期费用
            SortedMap<Integer, RentTimeRightDto> rentMap = contractFacade.getRent(rentCalculationDto);
            // 根据周期金额创建账单
            if (MapUtils.isEmpty(rentMap)) {
                log.warn("租金账单生成 计算周期租金失败 --> 跳过 contractID：【{}】", fncContractManagement.getFcmId());
                return;
            }
            log.info("租金账单生成 获取到计算周期租金结果 --> rentMap：【{}】", rentMap);

            // 获取可以生成的账单
            SortedMap<Integer, RentBillTimeRightDto> billMap = billGeneration(rentMap, fncContractManagement);

            if (MapUtils.isEmpty(billMap)) {
                log.warn("租金账单生成 没有要生成的账单 --> 跳过 contractID：【{}】", fncContractManagement.getFcmId());
                return;
            }
            log.info("租金账单生成 待处理的账单 --> contractID：【{}】 billMap：【{}】", fncContractManagement.getFcmId(), billMap);

            // 账单生成及消息推送
            // 准备要新增的数据
            createBill(fncContractManagement, billMap);
        } finally {
            countDownLatch.countDown();
        }
    }

    /**
     * @param fncContractManagement 合同
     * @param billMap               需要创建账单的租金
     * @author Bob
     * @date 2021/11/23
     * @description 创建账单
     */
    private void createBill(FncContractManagement fncContractManagement, SortedMap<Integer, RentBillTimeRightDto> billMap) {
        for (Map.Entry<Integer, RentBillTimeRightDto> entry : billMap.entrySet()) {
            RentBillTimeRightDto rentBillTimeRightDto = entry.getValue();
            FncBillManagement fncBillManagement = new FncBillManagement();
            fncBillManagement.setFbmCityId(fncContractManagement.getFcmCityId());
            fncBillManagement.setFbmSubjects(BillSubjectsEnum.RENT.getValue());
            Double amount = rentBillTimeRightDto.getAmount();
            Integer fcmCarnumTotal = fncContractManagement.getFcmCarnumTotal();
            if (Objects.isNull(fcmCarnumTotal)) {
                log.error("租金账单生成 生成账单 获取合同车辆总数为空 --> contractId：【{}】", fncContractManagement.getFcmId());
                continue;
            }
            double totalAmount = BigDecimal.valueOf(amount).multiply(BigDecimal.valueOf(fcmCarnumTotal)).doubleValue();
            fncBillManagement.setFbmBillAmount(totalAmount);
            fncBillManagement.setFbmNper(String.valueOf(entry.getKey()));
            fncBillManagement.setFbmBillGenerateTime(rentBillTimeRightDto.getBillStart());
            fncBillManagement.setFbmBillGenerateWay(BillGenerateWayEnum.AUTO.getValue());
            fncBillManagement.setFbmBillCatoffTime(rentBillTimeRightDto.getBillEnd());
            // 获取关联车辆id
            Long carId = contractOnlyCarFacade.getCarIdByContract(fncContractManagement);
            fncBillManagement.setFbmAssociateCarId(carId);
            fncBillManagement.setFbmAssociateContractId(fncContractManagement.getFcmId());
            fncBillManagement.setFbmBillState(BillStateEnum.UNPAID.getValue());
            fncBillManagement.setFbmMatchedAmount(0D);
            fncBillManagement.setFbmNotMatchAmount(totalAmount);
            // 对比查看是否生成订单
            billManagementGenerateFacade.generateAndSend(fncBillManagement, fncContractManagement.getFcmPartybId(), fncContractManagement.getFcmPartybType());
            log.info("租金账单生成 生成账单 --> fncBillManagement：【{}】", fncBillManagement);
        }
    }

    /**
     * @param rentMap               租金map
     * @param fncContractManagement 合同
     * @return 小于当前日期应该生成的Map
     * @author Bob
     * @date 2021/11/23
     * @description 处理账单的生成日期和截止日期
     */
    private SortedMap<Integer, RentBillTimeRightDto> billGeneration(SortedMap<Integer, RentTimeRightDto> rentMap, FncContractManagement fncContractManagement) {
        SortedMap<Integer, RentBillTimeRightDto> billMap = new TreeMap<>(Integer::compare);
        // 账单检查
        if (billGenerationCheck(fncContractManagement)) {
            return billMap;
        }

        // 获取今天日期
        Date today = new Date();
        SimpleDateFormat simpleDateFormat = new SimpleDateFormat("yyyy-MM-dd");
        String formatDay = simpleDateFormat.format(today);
        Date formatToday = null;
        try {
            formatToday = simpleDateFormat.parse(formatDay);
        } catch (ParseException e) {
            log.warn("租金账单生成 格式化今天日期失败");
        }

        // 循环检查待创建的订单
        for (Map.Entry<Integer, RentTimeRightDto> entry : rentMap.entrySet()) {
            RentTimeRightDto timeRightDto = entry.getValue();
            RentBillTimeRightDto rentBillTimeRightDto = BeanUtils.copyBean(timeRightDto, RentBillTimeRightDto.class);
            // 如果账单金额为0 直接跳过
            // 有赠送日期的情况下会存在账单金额为空
            if (BigDecimal.valueOf(timeRightDto.getAmount()).compareTo(new BigDecimal("0.00")) == 0) {
                continue;
            }

            // 获取账单的生成日截止日
            Date billStart = calculatingTime(rentBillTimeRightDto.getStart(), rentBillTimeRightDto.getEnd(),
                    fncContractManagement.getFcmBillGenerateType(), fncContractManagement.getFcmBillGenerateInterval());
            Date billEnd = calculatingTime(rentBillTimeRightDto.getStart(), rentBillTimeRightDto.getEnd(),
                    fncContractManagement.getFcmBillCatoffType(), fncContractManagement.getFcmBillCatoffInterval());
            // 今天早于账单生成日
            // 那么这个账单包括后面的账单就不用生成
            if (CheckUtil.isNotEmpty(formatToday) && formatToday.before(billStart)) {
                return billMap;
            }
            rentBillTimeRightDto.setBillStart(billStart);
            rentBillTimeRightDto.setBillEnd(billEnd);
            billMap.put(entry.getKey(), rentBillTimeRightDto);
        }
        return billMap;
    }

    /**
     * @param startDate 开始时间
     * @param endDate   结束时间
     * @param type      类型
     * @param interval  间隔
     * @return 结果时间
     * @author Bob
     * @date 2021/11/23
     * @description 将时间根据指定的类型和间隔计算出结果时间
     */
    private Date calculatingTime(Date startDate, Date endDate, Integer type, Integer interval) {
        // 租赁周期开始前 x 天
        if (BillDateTypeEnum.BEFORE.getValue().equals(type)) {
            return ContractDateCalculateUtil.increaseDay(startDate, -interval);
        }
        // 租赁周期开始当天
        else if (BillDateTypeEnum.NOW.getValue().equals(type)) {
            return startDate;
        }
        // 租赁周期开始后 x 天
        else if (BillDateTypeEnum.AFTER.getValue().equals(type)) {
            return ContractDateCalculateUtil.increaseDay(startDate, interval);
        }
        // 租赁周期结束后 x天
        else if (BillDateTypeEnum.FINISHED.getValue().equals(type)) {
            return ContractDateCalculateUtil.increaseDay(endDate, interval);
        }
        return startDate;
    }

    /**
     * @param fncContractManagement 合同
     * @return ture 检查不通过 false 检查通过
     * @author Bob
     * @date 2021/11/23
     * @description 账单生成关键字段检查
     */
    private boolean billGenerationCheck(FncContractManagement fncContractManagement) {
        // 检查站但生成日和账单截止日字段是否符合预期
        Integer billGenerateType = fncContractManagement.getFcmBillGenerateType();
        Integer billGenerateInterval = fncContractManagement.getFcmBillGenerateInterval();
        Integer billCatoffType = fncContractManagement.getFcmBillCatoffType();
        Integer billCatoffInterval = fncContractManagement.getFcmBillCatoffInterval();
        // 生成日不能为空
        if (CheckUtil.isEmpty(billGenerateType)) {
            log.warn("租金账单生成 账单生成日为空 --> 跳过 contractID：【{}】", fncContractManagement.getFcmId());
            return true;
        }
        // 截止日不能为空
        if (CheckUtil.isEmpty(billCatoffType)) {
            log.warn("租金账单生成 账单截止日为空 --> 跳过 contractID：【{}】 ", fncContractManagement.getFcmId());
            return true;
        }
        // 账单生成截止检查
        if (billGenerateType > billCatoffType) {
            log.warn("租金账单生成 账单生成日和账单截止日冲突 --> 跳过 contractID：【{}】 billGenerateType：【{}】 billCatoffType：【{}】",
                    fncContractManagement.getFcmId(), billGenerateType, billCatoffType);
            return true;
        }
        if (!BillDateTypeEnum.NOW.getValue().equals(billGenerateType) && CheckUtil.isEmpty(billGenerateInterval)) {
            log.warn("租金账单生成 账单生成间隔为空 --> 跳过 contractID：【{}】", fncContractManagement.getFcmId());
            return true;
        }
        if (!BillDateTypeEnum.NOW.getValue().equals(billCatoffType) && CheckUtil.isEmpty(billCatoffInterval)) {
            log.warn("租金账单生成 账单截止间隔为空 --> 跳过 contractID：【{}】", fncContractManagement.getFcmId());
            return true;
        }
        return false;
    }

}
