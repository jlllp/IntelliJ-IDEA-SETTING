package com.mrk.finance.controller;

import com.github.pagehelper.PageInfo;
import com.mrk.common.utils.page.JsonResult;
import com.mrk.finance.dto.AutoMatchResOfWaterDto;
import com.mrk.finance.dto.FncBankWaterDto;
import com.mrk.finance.facade.FncWaterAutoMatchFacade;
import com.mrk.finance.facade.bankwater.FncBankWaterFacade;
import com.mrk.finance.model.FncBankWater;
import com.mrk.finance.model.FncRevenueWaterRecord;
import com.mrk.finance.queryvo.FncBankWaterQueryVo;
import com.mrk.finance.service.FncBankWaterService;
import com.mrk.finance.vo.WaterMatchBillVo;
import com.mrk.log.annotation.Log;
import com.mrk.log.enums.BusinessType;
import com.mrk.log.enums.OperatorType;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiImplicitParam;
import io.swagger.annotations.ApiImplicitParams;
import io.swagger.annotations.ApiOperation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;


/**
 * FncBankWaterController

 */
@RestController
@RequestMapping("/financeservice/fncbankwater")
@Api(tags = "/银行流水")
public class FncBankWaterController {
    @Autowired
    private FncWaterAutoMatchFacade fncWaterAutoMatchFacade;
    @Autowired
    private FncBankWaterFacade fncBankWaterFacade;
    @Autowired
    private FncBankWaterService fncBankWaterService;


    @GetMapping(value = "/page")
    @ApiOperation("银行流水-分页查询")
    @ApiImplicitParams({
            @ApiImplicitParam(paramType = "header", name = "Authorization", value = "系统下发的token", required = true)
    })
    public JsonResult<PageInfo<FncBankWaterDto>> page(FncBankWaterQueryVo queryVo) {
        return JsonResult.success(fncBankWaterFacade.page(queryVo));
    }

    @GetMapping(value = "/page_record")
    @ApiOperation("银行流水-分页查询收支记录")
    @ApiImplicitParams({
            @ApiImplicitParam(paramType = "header", name = "Authorization", value = "系统下发的token", required = true)
    })
    public JsonResult<PageInfo<FncRevenueWaterRecord>> pageRecord(Long fbwId) {
        return JsonResult.success(fncBankWaterFacade.pageRecord(fbwId));
    }

    @PostMapping(value = "/update")
    @ApiOperation("银行流水-更新")
    @ApiImplicitParams({
            @ApiImplicitParam(paramType = "header", name = "Authorization", value = "系统下发的token", required = true)
    })
    @Log(title = "银行流水", value = "更新", businessType = BusinessType.UPDATE, operatorType = OperatorType.MANAGE)
    public JsonResult<Integer> update(@RequestBody FncBankWater entity) {
        return JsonResult.success(fncBankWaterService.update(entity));
    }

    @PostMapping(value = "/del/{id}")
    @ApiOperation("银行流水-删除")
    @ApiImplicitParams({
            @ApiImplicitParam(paramType = "header", name = "Authorization", value = "系统下发的token", required = true)
    })
    @Log(title = "银行流水", value = "删除", businessType = BusinessType.DELETE, operatorType = OperatorType.MANAGE)
    public JsonResult<Integer> del(@PathVariable Long id) {
        return JsonResult.success(fncBankWaterFacade.del(id));
    }

    @GetMapping(value = "/list")
    @ApiOperation("银行流水-列表查询")
    @ApiImplicitParams({
            @ApiImplicitParam(paramType = "header", name = "Authorization", value = "系统下发的token", required = true)
    })
    public JsonResult<List<FncBankWater>> list(FncBankWaterQueryVo queryVo) {
        return JsonResult.success(fncBankWaterService.list(queryVo));
    }

    @PostMapping(value = "/match_bill_manually")
    @ApiOperation("银行流水-手动匹配账单")
    @ApiImplicitParams({
            @ApiImplicitParam(paramType = "header", name = "Authorization", value = "系统下发的token", required = true)
    })
    @Log(title = "银行流水", value = "手动匹配账单", businessType = BusinessType.OTHER, operatorType = OperatorType.MANAGE)
    public JsonResult<Integer> matchBillManually(@RequestBody WaterMatchBillVo vo) {
        return JsonResult.success(fncBankWaterFacade.manuallyMatch(vo)).setMsg("手动匹配成功");
    }

    @PostMapping(value = "/match_bill_automatically")
    @ApiOperation("银行流水-自动匹配账单")
    @ApiImplicitParams({
            @ApiImplicitParam(paramType = "header", name = "Authorization", value = "系统下发的token", required = true)
    })
    @Log(title = "银行流水", value = "自动匹配账单", businessType = BusinessType.OTHER, operatorType = OperatorType.MANAGE)
    public JsonResult<List<AutoMatchResOfWaterDto>> bwAutoMatch(@RequestBody List<Long> fbwIds) {
        return JsonResult.success(fncWaterAutoMatchFacade.bwAutoMatch(fbwIds)).setMsg("自动匹配成功, 请查看匹配结果");
    }
}
