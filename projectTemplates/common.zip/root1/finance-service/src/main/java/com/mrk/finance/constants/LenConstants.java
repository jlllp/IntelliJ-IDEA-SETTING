package com.mrk.finance.constants;

/**
 * @project: mrk-finance
 * @author: Frank.Tang
 * @date: 2021-11-11 10:52
 * @desc: 字符串长度
 **/
public class LenConstants {
    private LenConstants() {

    }

    public static final int LEN_50 = 50;

    public static final int LEN_100 = 100;

    public static final int LEN_255 = 255;

    public static final int LEN_2550 = 2550;

}
