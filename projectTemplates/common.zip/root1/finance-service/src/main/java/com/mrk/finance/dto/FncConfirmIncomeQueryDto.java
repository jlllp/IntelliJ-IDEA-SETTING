package com.mrk.finance.dto;

import cn.afterturn.easypoi.excel.annotation.Excel;
import lombok.Data;

import java.io.Serializable;
@Data
public class FncConfirmIncomeQueryDto implements Serializable {
  /**资产所有者文本 */
  @Excel(name = "资产所有者")
  private String fciDeptIdText;

  /**收入时间 */
  @Excel(name = "收入时间",exportFormat = "yyyy-MM-dd HH:mm:ss")
  private java.util.Date fciIncomeMonth;

  /**租金收入 */
  @Excel(name  = "租金收入")
  private Double fciRentIncome;

  /**违约金收入 */
  @Excel(name = "违约金收入")
  private Double fciPenaltyIncome;

  /**购车尾款收入 */
  @Excel(name = "购车尾款收入")
  private Double fciCarPurchaseIncome;

  /**合计收入 */
  @Excel(name = "合计收入")
  private Double fciTotalIncome;

}
