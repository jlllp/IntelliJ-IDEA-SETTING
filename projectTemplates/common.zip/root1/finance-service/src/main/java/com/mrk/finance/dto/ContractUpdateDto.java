package com.mrk.finance.dto;

import com.mrk.finance.model.FncContractCarmodel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.util.List;

/**
 * @project: mrk-finance
 * @author: Frank.Tang
 * @date: 2021-11-29 15:37
 * @desc:
 **/
@Data
public class ContractUpdateDto {

    @ApiModelProperty("新增车型")
    List<FncContractCarmodel> tobeAddCarmodels;

    @ApiModelProperty("更新车型")
    List<FncContractCarmodel> tobeUpdateCarmodels;

    @Deprecated
    @ApiModelProperty("新增租金包含费用")
    List<FncRentalFeesDto> tobeAddRentalFees;

    @Deprecated
    @ApiModelProperty("更新租金包含费用")
    List<FncRentalFeesDto> tobeUpdateRentalFees;

    /** 废弃掉原来的, 改为全删型 */
    List<FncRentalFeesDto> rentalFees;
}
