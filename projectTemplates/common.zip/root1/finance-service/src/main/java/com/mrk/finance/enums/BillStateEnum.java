package com.mrk.finance.enums;

import lombok.Getter;

/**
 * @project: mrk-finance
 * @author: Frank.Tang
 * @date: 2021-11-11 09:53
 * @desc: 账单状态
 **/
@Getter
public enum BillStateEnum {

    /***/
    APPROVING(0, "审批中"),
    UNPAID(1, "未支付"),
    REJECTED(2, "已驳回"),
    OVERDUE(3, "已逾期"),
    PAID_PART(4, "部分支付"),
    PAID_ALL(5, "已支付"),
    INVOICING(6, "开票中"),
    INVOICED(7, "已开票");


    private Integer value;
    private String name;

    BillStateEnum(Integer value, String name) {
        this.value = value;
        this.name = name;
    }

    public static String getName(Integer state) {
        if (state == null) {
            return "";
        }
        for (BillStateEnum statusEnum : values()) {
            if (statusEnum.getValue().equals(state)) {
                return statusEnum.getName();
            }
        }
        return "";
    }

}
