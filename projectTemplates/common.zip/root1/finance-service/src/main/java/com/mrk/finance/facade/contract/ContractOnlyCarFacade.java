package com.mrk.finance.facade.contract;

import com.alibaba.fastjson.JSON;
import com.github.pagehelper.PageInfo;
import com.mrk.finance.client.dto.ContractMementDto;
import com.mrk.finance.model.FncContractManagement;
import com.mrk.workflow.client.Dto.CarPageDto;
import com.mrk.workflow.client.UseCarWorkflowClient;
import org.apache.commons.collections4.CollectionUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.List;
import java.util.Objects;

/**
 * @author Bob
 * @date 2021-11-16
 * @description 合同只有一辆车处理
 */
@Component
public class ContractOnlyCarFacade {

    @Autowired
    private UseCarWorkflowClient useCarWorkflowClient;

    /**
     * @author Bob
     * @date 2021/11/16
     * @description 获取合同下唯一的车辆
     * @param fncContractManagement 合同
     * @return 唯一车辆Id 不唯一的情况下返回null 车辆为选择的情况下返回null
     */
    public Long getCarIdByContract(FncContractManagement fncContractManagement) {
        // 合同存在多辆车直接返回
        if (!Objects.equals(1, fncContractManagement.getFcmCarnumTotal())) {
            return null;
        }
        // 获取合同关联的车辆
        ContractMementDto entity = new ContractMementDto();
        entity.setContractId(fncContractManagement.getFcmId());
        entity.setRows(10);
        entity.setPage(1);
        PageInfo<CarPageDto> carPageDtoPageInfo = useCarWorkflowClient.selectByContractStr(JSON.toJSONString(entity)).getDataWithEx();
        // 如果车辆已经存在，则获取车辆id
        List<CarPageDto> list = carPageDtoPageInfo.getList();
        if (CollectionUtils.isNotEmpty(list)) {
            return list.get(0).getWpwcCar();
        }
        return null;
    }
}
