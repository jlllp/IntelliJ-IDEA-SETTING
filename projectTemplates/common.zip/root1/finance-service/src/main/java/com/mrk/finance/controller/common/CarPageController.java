package com.mrk.finance.controller.common;

import com.github.pagehelper.PageInfo;
import com.mrk.common.utils.page.JsonResult;
import com.mrk.finance.client.dto.ContractMementDto;
import com.mrk.finance.facade.common.CommonFacade;
import com.mrk.workflow.client.Dto.CarPageDto;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiImplicitParam;
import io.swagger.annotations.ApiImplicitParams;
import io.swagger.annotations.ApiOperation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;


/**
 * FncRentalFeesController

 */
@RestController
@RequestMapping("/financeservice/common")
@Api(tags = "/公共方法")
public class CarPageController {
    @Autowired
    private CommonFacade commonFacade;

    @GetMapping(value = "/car_page")
    @ApiOperation("车辆列表-分页")
    @ApiImplicitParams({
            @ApiImplicitParam(paramType = "header", name = "Authorization", value = "系统下发的token", required = true)
    })
    public JsonResult<PageInfo<CarPageDto>> add(ContractMementDto entity) {
        return JsonResult.success(commonFacade.page(entity));
    }

}
