package com.mrk.finance.dto;

import com.mrk.finance.model.FncBankWater;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

/**
 * @project: mrk-finance
 * @author: Frank.Tang
 * @date: 2021-11-15 17:46
 * @desc:
 **/
@Data
public class FncBankWaterDto extends FncBankWater {


    @ApiModelProperty("借/贷")
    private String fbwLoanTypeName;

    @ApiModelProperty("匹配状态")
    private String fbwMatchStateName;

    @ApiModelProperty("匹配方式")
    private String fbwMatchTypeName;

}
