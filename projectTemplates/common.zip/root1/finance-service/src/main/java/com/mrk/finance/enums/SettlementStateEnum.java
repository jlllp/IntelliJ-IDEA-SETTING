package com.mrk.finance.enums;

/**
 * @author Bob
 * @date 2021-11-12
 * @description 结算状态枚举类
 */
public enum SettlementStateEnum {

    OUTSTANDING(0, "未结清"),
    CLEARED(1, "已结清");

    private final Integer state;
    private final String text;

    SettlementStateEnum(Integer state, String text) {
        this.state = state;
        this.text = text;
    }

    public Integer getState() {
        return state;
    }

    public String getText() {
        return text;
    }

    public static String getText(Integer state) {
        if (state == null) {
            return null;
        }
        for (SettlementStateEnum value : values()) {
            if (value.getState().equals(state)) {
                return value.getText();
            }
        }
        return null;
    }
}
