package com.mrk.finance.dto.contract;

import com.mrk.finance.dto.date.TimeRightDto;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;

/**
 * @author Bob
 * @date 2021-11-22
 * @description 租期费用Dto
 */
@EqualsAndHashCode(callSuper = true)
@Data
@NoArgsConstructor
public class RentTimeRightDto extends TimeRightDto {

    @ApiModelProperty(value = "金额")
    private Double amount;
}
