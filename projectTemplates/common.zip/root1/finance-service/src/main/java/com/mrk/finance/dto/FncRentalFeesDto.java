package com.mrk.finance.dto;

import com.mrk.finance.model.FncRentalFees;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

/**
 * @project: mrk-finance
 * @author: Frank.Tang
 * @date: 2021-11-18 15:43
 * @desc:
 **/
@Data
public class FncRentalFeesDto extends FncRentalFees {

    @ApiModelProperty("金额")
    private String frfValue;

    @ApiModelProperty("关联表id")
    private Long fcrfId;


}
