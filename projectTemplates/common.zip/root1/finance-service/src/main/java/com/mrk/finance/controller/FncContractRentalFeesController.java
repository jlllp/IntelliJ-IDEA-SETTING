package com.mrk.finance.controller;

import com.github.pagehelper.PageInfo;
import com.mrk.common.utils.page.JsonResult;
import com.mrk.finance.model.FncContractRentalFees;
import com.mrk.finance.queryvo.FncContractRentalFeesQueryVo;
import com.mrk.finance.service.FncContractRentalFeesService;
import com.mrk.log.annotation.Log;
import com.mrk.log.enums.BusinessType;
import com.mrk.log.enums.OperatorType;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiImplicitParam;
import io.swagger.annotations.ApiImplicitParams;
import io.swagger.annotations.ApiOperation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;


/**
 * FncContractRentalFeesController

 */
@RestController
@RequestMapping("/financeservice/fnccontractrentalfees")
@Api(tags = "/合同租金包含费用")
public class FncContractRentalFeesController {
    @Autowired
    private FncContractRentalFeesService fncContractRentalFeesService;

    @PostMapping(value = "/add")
    @ApiOperation("合同租金包含费用-新增")
    @ApiImplicitParams({
            @ApiImplicitParam(paramType = "header", name = "Authorization", value = "系统下发的token", required = true)
    })
    @Log(title = "合同租金包含费用", value = "新增", businessType = BusinessType.INSERT, operatorType = OperatorType.MANAGE)
    public JsonResult<Object>  add(FncContractRentalFees entity) {
        return JsonResult.success(fncContractRentalFeesService.add(entity));
    }

    @PostMapping(value = "/del/{id}")
    @ApiOperation("合同租金包含费用-删除")
    @ApiImplicitParams({
            @ApiImplicitParam(paramType = "header", name = "Authorization", value = "系统下发的token", required = true)
    })
    @Log(title = "合同租金包含费用", value = "删除", businessType = BusinessType.DELETE, operatorType = OperatorType.MANAGE)
    public JsonResult<Object>  del(@PathVariable("id") Long id) {
        return JsonResult.success(fncContractRentalFeesService.delete(id));
    }

    @PostMapping(value = "/update")
    @ApiOperation("合同租金包含费用-更新")
    @ApiImplicitParams({
            @ApiImplicitParam(paramType = "header", name = "Authorization", value = "系统下发的token", required = true)
    })
    @Log(title = "合同租金包含费用", value = "更新", businessType = BusinessType.UPDATE, operatorType = OperatorType.MANAGE)
    public JsonResult<Object>  update(FncContractRentalFees entity) {
        return JsonResult.success(fncContractRentalFeesService.update(entity));
    }


    @GetMapping(value = "/page")
    @ApiOperation("合同租金包含费用-分页查询")
    @ApiImplicitParams({
            @ApiImplicitParam(paramType = "header", name = "Authorization", value = "系统下发的token", required = true)
    })
    public JsonResult<PageInfo<FncContractRentalFees>> page(FncContractRentalFeesQueryVo queryVo) {
        return JsonResult.success(fncContractRentalFeesService.page(queryVo));
    }

    @GetMapping(value = "/list")
    @ApiOperation("合同租金包含费用-列表查询")
    @ApiImplicitParams({
            @ApiImplicitParam(paramType = "header", name = "Authorization", value = "系统下发的token", required = true)
    })
    public JsonResult<List<FncContractRentalFees>> list(FncContractRentalFeesQueryVo queryVo) {
        return JsonResult.success(fncContractRentalFeesService.list(queryVo));
    }


}
