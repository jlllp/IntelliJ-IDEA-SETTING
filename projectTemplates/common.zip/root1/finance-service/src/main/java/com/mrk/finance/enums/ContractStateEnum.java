package com.mrk.finance.enums;

/**
 * @author Bob
 * @date 2021-11-12
 * @description
 */
public enum ContractStateEnum {

    LEASE_TO_START(0, "审批中"),
    LEASED(1, "执行中"),
    LEASE_SUSPENSION(2, "中止"),
    LEASE_TO_END(3, "已结束");

    private final Integer state;

    private final String text;

    public Integer getState() {
        return state;
    }

    public String getText() {
        return text;
    }

    ContractStateEnum(Integer state, String text) {
        this.state = state;
        this.text = text;
    }

    public static String getText(Integer state) {
        if (state == null) {
            return null;
        }
        for (ContractStateEnum value : values()) {
            if (value.state.equals(state)) {
                return value.getText();
            }
        }
        return null;
    }
}
