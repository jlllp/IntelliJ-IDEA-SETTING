package com.mrk.finance.dto;

import com.mrk.finance.model.FncContractRentalFees;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

/**
 * @project: mrk-finance
 * @author: Frank.Tang
 * @date: 2021-11-30 14:06
 * @desc:
 **/
@Data
public class FncContractRentalFeesDto extends FncContractRentalFees {

    @ApiModelProperty("名称")
    private String fcrfName;

    @ApiModelProperty("标识")
    private String fcrfMark;

}
