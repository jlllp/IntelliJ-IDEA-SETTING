package com.mrk.finance.enums.newcontract;

/**
 * @author
 * @date
 * @description
 */
public enum NewTypeStateEnum {

    LEASE_TO_START(0, "未上传"),
    LEASED(1, "已上传");

    private final Integer state;

    private final String text;

    public Integer getState() {
        return state;
    }

    public String getText() {
        return text;
    }

    NewTypeStateEnum(Integer state, String text) {
        this.state = state;
        this.text = text;
    }

    public static String getText(Integer state) {
        if (state == null) {
            return null;
        }
        for (NewTypeStateEnum value : values()) {
            if (value.state.equals(state)) {
                return value.getText();
            }
        }
        return null;
    }
}
