package com.mrk.finance.dto.fncddexport;

import cn.afterturn.easypoi.excel.annotation.Excel;
import lombok.Data;

import java.io.Serializable;

@Data
public class FncDdWithholdExportByQueryDto implements Serializable {

  /**交易账目 */
  @Excel(name = "交易账目")
  private String fdwTradeNames;

  /**交易流水号 */
  @Excel(name = "交易流水号")
  private String fdwAccountDealFlow;

  /**交易时间 */
  @Excel(name = "交易时间", exportFormat = "yyyy-MM-dd HH:mm:ss" )
  private java.util.Date fdwTradeTime;

  /**交易方 */
  @Excel(name = "交易方")
  private String fdwTradeParty;

  /**交易金额 */
  @Excel(name = "交易金额")
  private Double fdwTradeAmount;

  /**订单号 */
  @Excel(name = "订单号")
  private String fdwOrderNo;

  /**车架号 */
  @Excel(name = "车架号")
  private String fdwCarVin;

  /**账单号（滴滴） */
  @Excel(name = "账单号（滴滴）")
  private String fdwAccountNo;



  /**匹配状态文本 */
  @Excel(name = "匹配状态")
  private String fdwMatchStateText;

  /**匹配方式文本 */
  @Excel(name = "匹配方式")
  private String fdwMatchWayText;

  /**匹配账单 */
  @Excel(name = "匹配账单")
  private String fdwMatchBill;

  /**已匹配金额 */
  @Excel(name = "已匹配金额")
  private Double fdwMatchedAmount;

  /**未匹配金额 */
  @Excel(name = "未匹配金额")
  private Double fdwNotMatchAmount;
}
