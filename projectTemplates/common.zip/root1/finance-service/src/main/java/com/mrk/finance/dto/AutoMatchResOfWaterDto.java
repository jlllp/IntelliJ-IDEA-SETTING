package com.mrk.finance.dto;

import lombok.Data;

import java.math.BigDecimal;

/**
 * @project: mrk-finance
 * @author: Frank.Tang
 * @date: 2021-11-24 16:31
 * @desc: 流水自动匹配结果dto
 **/
@Data
public class AutoMatchResOfWaterDto {

    private Long waterId;

    private String waterType;

    private Double waterAmount;

    private String matchBillId;

    private String matchRes;

    private BigDecimal matchedAmount;

    private Double notMatchAmount;

    /** 初始的已匹配金额, 固定值, 累计单次匹配额时, 做为辅助参数 */
    private BigDecimal matchedAmountInit;

}
