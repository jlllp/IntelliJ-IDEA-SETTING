package com.mrk.finance.enums;

import lombok.Getter;

/**
 * @project: mrk-finance
 * @author: Frank.Tang
 * @date: 2021-11-12 11:34
 * @desc: 合同补充协议(解除租赁合同)-支付方式
 **/
@Getter
public enum ContractAdditionPayTypeEnum {

    /***/
    MARGIN_DEDUCTION(0, "保证金抵扣"),
    RENT_DEDUCTION(1, "租金抵扣"),
    NEW_BILL_PAY(2, "新账单支付");

    private Integer value;
    private String name;

    ContractAdditionPayTypeEnum(Integer value, String name) {
        this.value = value;
        this.name = name;
    }

    public static String getName(Integer state) {
        if (state == null) {
            return "";
        }
        for (ContractAdditionPayTypeEnum statusEnum : values()) {
            if (statusEnum.getValue().equals(state)) {
                return statusEnum.getName();
            }
        }
        return "";
    }


}
