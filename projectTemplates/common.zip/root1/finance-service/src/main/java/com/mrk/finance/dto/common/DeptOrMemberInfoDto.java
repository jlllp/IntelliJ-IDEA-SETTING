package com.mrk.finance.dto.common;

import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

/**
 * @author Bob
 * @date 2021-11-18
 * @description
 */
@Data
public class DeptOrMemberInfoDto {

    @ApiModelProperty(value = "对应的主键")
    private Long id;

    @ApiModelProperty(value = "类型")
    private Integer partyType;

    @ApiModelProperty(value = "名称")
    private String name;
}
