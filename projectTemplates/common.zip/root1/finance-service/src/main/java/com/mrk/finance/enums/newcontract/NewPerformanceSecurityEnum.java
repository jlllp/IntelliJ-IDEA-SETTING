package com.mrk.finance.enums.newcontract;

import java.util.Objects;

/**
 * @author
 * @date
 * @description
 */
public enum NewPerformanceSecurityEnum {

    RENT_FOR_SALE(0, "总额"),
    OPERATING_LEASE(1, "单车");

    private final Integer type;
    private final String text;

    NewPerformanceSecurityEnum(Integer type, String text) {
        this.type = type;
        this.text = text;
    }

    public Integer getType() {
        return type;
    }

    public String getText() {
        return text;
    }

    public static String getText(Integer type) {
        if (Objects.isNull(type)) return null;

        for (NewPerformanceSecurityEnum value : values()) {
            if (value.getType().equals(type)) {
                return value.getText();
            }
        }

        return null;
    }
}
