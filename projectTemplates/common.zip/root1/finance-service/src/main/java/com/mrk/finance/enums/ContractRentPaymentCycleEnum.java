package com.mrk.finance.enums;

import java.util.Objects;

/**
 * @author Bob
 * @date 2021-11-15
 * @description
 */
public enum ContractRentPaymentCycleEnum {

    PER_MONTH(0, "每月支付"),
    EACH_QUARTER(1, "每季度支付"),
    EVERY_HALF_YEAR(2, "每半年支付"),
    EACH_YEAR(3, "每年支付"),
    EVERY_TWO_YEARS(4, "每两年支付"),
    EVERY_THREE_YEARS(5, "每三年支付");

    private final Integer value;

    private final String text;

    public Integer getValue() {
        return value;
    }

    public String getText() {
        return text;
    }

    ContractRentPaymentCycleEnum(Integer value, String text) {
        this.value = value;
        this.text = text;
    }

    public static String getText(Integer value) {
        if (Objects.isNull(value)) {
            return null;
        }
        for (ContractRentPaymentCycleEnum contractRentPaymentCycleEnum : values()) {
            if (contractRentPaymentCycleEnum.getValue().equals(value)) {
                return contractRentPaymentCycleEnum.getText();
            }
        }
        return null;
    }

    /**
     * 枚举值转实际间隔值 (1[月], 3[季度], 6[半年]......)
     * @author Frank.Tang
     * @param value 枚举的value
     * @return *
     */
    public static Integer toIntervalValue(Integer value) {
        if (Objects.isNull(value)) {
            return 0;
        }
        if (value.equals(PER_MONTH.value)) {
            return 1;
        } else if (value.equals(EACH_QUARTER.value)) {
            return 3;
        } else if (value.equals(EVERY_HALF_YEAR.value)) {
            return 6;
        } else if (value.equals(EACH_YEAR.value)) {
            return 12;
        } else if (value.equals(EVERY_TWO_YEARS.value)) {
            return 24;
        } else if (value.equals(EVERY_THREE_YEARS.value)) {
            return 36;
        } else {
            return 0;
        }
    }
}
