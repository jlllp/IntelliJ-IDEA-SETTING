package com.mrk.finance.controller;

import com.github.pagehelper.PageInfo;
import com.mrk.common.utils.page.JsonResult;
import com.mrk.finance.model.FncTemp;
import com.mrk.finance.queryvo.FncTempQueryVo;
import com.mrk.finance.service.FncTempService;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiImplicitParam;
import io.swagger.annotations.ApiImplicitParams;
import io.swagger.annotations.ApiOperation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;


/**
 * FncTempController

 */
@RestController
@RequestMapping("/FncTemp")
@Api(tags = "/xx")
public class FncTempController {
    @Autowired
    private FncTempService fncTempService;

    @PostMapping(value = "/add")
    @ApiOperation("fncTemp-新增")
    @ApiImplicitParams({
            @ApiImplicitParam(paramType = "header", name = "Authorization", value = "系统下发的token", required = true)
    })
    public JsonResult<Object>  add(FncTemp entity) {
        return JsonResult.success(fncTempService.add(entity));
    }

    @PostMapping(value = "/del/{id}")
    @ApiOperation("fncTemp-删除")
    @ApiImplicitParams({
            @ApiImplicitParam(paramType = "header", name = "Authorization", value = "系统下发的token", required = true)
    })
    public JsonResult<Object>  del(@PathVariable("id") Long id) {
        return JsonResult.success(fncTempService.delete(id));
    }

    @PostMapping(value = "/update")
    @ApiOperation("fncTemp-更新")
    @ApiImplicitParams({
            @ApiImplicitParam(paramType = "header", name = "Authorization", value = "系统下发的token", required = true)
    })
    public JsonResult<Object>  update(FncTemp entity) {
        return JsonResult.success(fncTempService.update(entity));
    }


    @GetMapping(value = "/page")
    @ApiOperation("fncTemp-分页查询")
    @ApiImplicitParams({
            @ApiImplicitParam(paramType = "header", name = "Authorization", value = "系统下发的token", required = true)
    })
    public JsonResult<PageInfo<FncTemp>> page(FncTempQueryVo queryVo) {
        return JsonResult.success(fncTempService.page(queryVo));
    }

    @GetMapping(value = "/list")
    @ApiOperation("fncTemp-列表查询")
    @ApiImplicitParams({
            @ApiImplicitParam(paramType = "header", name = "Authorization", value = "系统下发的token", required = true)
    })
    public JsonResult<List<FncTemp>> list(FncTempQueryVo queryVo) {
        return JsonResult.success(fncTempService.list(queryVo));
    }


}
