package com.mrk.finance.dto;

import lombok.Data;

import java.math.BigDecimal;

/**
 * @project: mrk-finance
 * @author: Frank.Tang
 * @date: 2021-11-22 16:01
 * @desc: 账单自动匹配结果dto
 **/
@Data
public class AutoMatchResOfBillDto {

    private Long billId;

    private String billSubject;

    private Double billAmount;

    private String period;

    private String carVin;

    private String carPlateNum;

    private String contractNo;

    private String matchRes;

    private String matchWaterId;

    private BigDecimal matchedAmount;

    private Double notMatchAmount;

    /** 初始的已匹配金额, 固定值, 累计单次匹配额时, 做为辅助参数 */
    private BigDecimal matchedAmountInit;

}
