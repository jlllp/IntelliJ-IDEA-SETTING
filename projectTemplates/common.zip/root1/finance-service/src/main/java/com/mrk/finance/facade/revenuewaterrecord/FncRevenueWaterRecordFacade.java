package com.mrk.finance.facade.revenuewaterrecord;

import com.github.pagehelper.PageInfo;
import com.mrk.finance.model.FncRevenueWaterRecord;
import com.mrk.finance.queryvo.FncRevenueWaterRecordQueryVo;
import com.mrk.finance.service.FncRevenueWaterRecordService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

@Component
public class FncRevenueWaterRecordFacade {

  @Autowired
  private FncRevenueWaterRecordService fncRevenueWaterRecordService;


  public PageInfo<FncRevenueWaterRecord> page(FncRevenueWaterRecordQueryVo queryVo) {

    return fncRevenueWaterRecordService.page(queryVo);
  }
}
