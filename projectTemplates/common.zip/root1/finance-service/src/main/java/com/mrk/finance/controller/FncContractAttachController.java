package com.mrk.finance.controller;

import com.github.pagehelper.PageInfo;
import com.mrk.common.utils.page.JsonResult;
import com.mrk.finance.model.FncContractAttach;
import com.mrk.finance.queryvo.FncContractAttachQueryVo;
import com.mrk.finance.service.FncContractAttachService;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiImplicitParam;
import io.swagger.annotations.ApiImplicitParams;
import io.swagger.annotations.ApiOperation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;


/**
 * FncContractAttachController

 */
@RestController
@RequestMapping("/FncContractAttach")
@Api(tags = "/xx")
public class FncContractAttachController {
    @Autowired
    private FncContractAttachService fncContractAttachService;

    @PostMapping(value = "/add")
    @ApiOperation("fncContractAttach-新增")
    @ApiImplicitParams({
            @ApiImplicitParam(paramType = "header", name = "Authorization", value = "系统下发的token", required = true)
    })
    public JsonResult<Object>  add(FncContractAttach entity) {
        return JsonResult.success(fncContractAttachService.add(entity));
    }

    @PostMapping(value = "/del/{id}")
    @ApiOperation("fncContractAttach-删除")
    @ApiImplicitParams({
            @ApiImplicitParam(paramType = "header", name = "Authorization", value = "系统下发的token", required = true)
    })
    public JsonResult<Object>  del(@PathVariable("id") Long id) {
        return JsonResult.success(fncContractAttachService.delete(id));
    }

    @PostMapping(value = "/update")
    @ApiOperation("fncContractAttach-更新")
    @ApiImplicitParams({
            @ApiImplicitParam(paramType = "header", name = "Authorization", value = "系统下发的token", required = true)
    })
    public JsonResult<Object>  update(FncContractAttach entity) {
        return JsonResult.success(fncContractAttachService.update(entity));
    }


    @GetMapping(value = "/page")
    @ApiOperation("fncContractAttach-分页查询")
    @ApiImplicitParams({
            @ApiImplicitParam(paramType = "header", name = "Authorization", value = "系统下发的token", required = true)
    })
    public JsonResult<PageInfo<FncContractAttach>> page(FncContractAttachQueryVo queryVo) {
        return JsonResult.success(fncContractAttachService.page(queryVo));
    }

    @GetMapping(value = "/list")
    @ApiOperation("fncContractAttach-列表查询")
    @ApiImplicitParams({
            @ApiImplicitParam(paramType = "header", name = "Authorization", value = "系统下发的token", required = true)
    })
    public JsonResult<List<FncContractAttach>> list(FncContractAttachQueryVo queryVo) {
        return JsonResult.success(fncContractAttachService.list(queryVo));
    }


}
