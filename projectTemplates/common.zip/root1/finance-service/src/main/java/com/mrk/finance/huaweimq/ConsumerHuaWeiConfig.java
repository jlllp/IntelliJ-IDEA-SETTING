package com.mrk.finance.huaweimq;

import org.apache.rocketmq.acl.common.AclClientRPCHook;
import org.apache.rocketmq.acl.common.SessionCredentials;
import org.apache.rocketmq.client.consumer.DefaultMQPushConsumer;
import org.apache.rocketmq.client.exception.MQClientException;
import org.apache.rocketmq.remoting.RPCHook;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

/**
 * @Author Sandy
 * @create 2021/5/8  下午 01:48
 */
@Configuration
public class ConsumerHuaWeiConfig {

    private static final Logger log = LoggerFactory.getLogger(ConsumerHuaWeiConfig.class);

    @Autowired
    private ConsumerListenerHuaWei consumerListenerHuaWei;

    @Bean
    public DefaultMQPushConsumer buildConsumerHuaWei(HuaWeiMqProperties properties) {
        RPCHook rpcHook = new AclClientRPCHook(new SessionCredentials(properties.getAccessKey(), properties.getSecretKey()));
        DefaultMQPushConsumer consumer = new DefaultMQPushConsumer(null,properties.getGroup(),rpcHook);
        consumer.setNamesrvAddr(properties.getNameServer());
        consumer.registerMessageListener(consumerListenerHuaWei);
        try {
            //指定订阅topic下的tag
            consumer.subscribe(properties.getTopic(), properties.getTag());
            consumer.start();
        } catch (MQClientException e) {
            e.printStackTrace();
        }
        log.info("华为云消费者mq启动,tag:{},topic:{}",properties.getTag(),properties.getTopic());
        return consumer;
    }
}
