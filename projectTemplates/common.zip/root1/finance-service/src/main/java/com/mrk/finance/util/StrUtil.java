package com.mrk.finance.util;

import java.util.Objects;

/**
 * @author jlllp
 * @date 2022/6/16
 * @description
 */
public class StrUtil {
    private StrUtil() {

    }

    /**
     * 对象转字符串
     * 如果对象为null返回的是""字符串
     *
     * @param obj 任意对象
     * @return 字符串
     */
    public static String objectToString(Object obj) {
        if (Objects.isNull(obj)) {
            return "";
        }
        return String.valueOf(obj);
    }
}
