package com.mrk.finance.util;

import com.mrk.common.exception.GlobalException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import java.util.concurrent.*;
import java.util.function.BiConsumer;
import java.util.function.Function;
import java.util.stream.Collectors;

/**
 * @author Bob
 * @date 2021-11-17
 * @description
 */
public class ThreadUtil {
    private static final Logger log = LoggerFactory.getLogger(ThreadUtil.class);
    private ThreadUtil(){

    }

    /**
     * @author Bob
     * @date 2021/11/17
     * @description 将集合中的元素用多线程按照指定的方法执行执行其中一个
     *              线程会阻塞到所有线程执行完成
     * @param coll 待执行的集合
     * @param action 要执行的方法
     * @param executor 线程池
     */
    public static<E> void execution(Collection<E> coll, BiConsumer<CountDownLatch, E> action, Executor executor){
        if (coll == null || coll.isEmpty()) {
            log.info("多线程处理，传入的集合为空 --> 跳过");
            return;
        }
        CountDownLatch countDownLatch = new CountDownLatch(coll.size());
        for (E e : coll) {
            executor.execute(() -> action.accept(countDownLatch, e));
        }
        try {
            countDownLatch.await();
        } catch (InterruptedException e) {
            log.error("等待线程执行完成错误", e);
            Thread.currentThread().interrupt();
        }
    }

    /**
     * @author Bob
     * @date 2021/11/24
     * @description 异步执行并获取结果
     * @param coll 待处理的集合
     * @param function 待执行的方法
     * @param executor 线程池
     * @return 所有任务执行完成后的结果
     */
    public static<E,T> List<T> executeAndGetResults(Collection<E> coll, Function<E, T> function, Executor executor){
        if (coll == null || coll.isEmpty()) {
            log.info("多线程处理，传入的集合为空 --> 跳过");
            return new ArrayList<>();
        }
        List<CompletableFuture<T>> futureList = coll.stream()
                .map(c -> CompletableFuture.supplyAsync(() -> function.apply(c), executor))
                .collect(Collectors.toList());
        CompletableFuture<Void> allOf = CompletableFuture.allOf(futureList.toArray(new CompletableFuture[0]));
        allOf.join();
        return futureList.stream().map(CompletableFuture::join).collect(Collectors.toList());
    }

    /**
     * @author Bob
     * @date 2021/12/22
     * @description 将集合中的元素用多线程按照指定的方法执行执行其中一个
     *              线程会阻塞到所有线程执行完成 或者抛出异常信息
     *              类似于在for处理数据 有异常就会抛出  只不过这里会使用多线程处理数据
     * @param coll 待执行的集合
     * @param function 要执行的方法
     * @param executor 线程池
     * @return 所有任务执行完成后的结果
     */
    public static<E,T> List<T> executeAndGetResultsOrThrow(Collection<E> coll, Function<E, T> function, Executor executor) {
        if (coll == null || coll.isEmpty()) {
            log.info("多线程处理，传入的集合为空 --> 跳过");
            return new ArrayList<>();
        }
        List<CompletableFuture<T>> futureList = coll.stream()
                .map(c -> CompletableFuture.supplyAsync(() -> function.apply(c), executor).exceptionally(e -> {
                    Throwable cause = e.getCause();
                    if (cause instanceof GlobalException) {
                        throw new GlobalException(cause.getMessage());
                    } else {
                        log.error("多线程执行错误", cause);
                        throw new GlobalException("运行错误，请重试！");
                    }
                }))
                .collect(Collectors.toList());
        CompletableFuture<Void> allOf = CompletableFuture.allOf(futureList.toArray(new CompletableFuture[0]));
        allOf.join();
        return futureList.stream().map(CompletableFuture::join).collect(Collectors.toList());
    }
}
