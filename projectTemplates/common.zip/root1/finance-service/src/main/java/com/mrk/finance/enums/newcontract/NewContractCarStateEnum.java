package com.mrk.finance.enums.newcontract;

/**
 * @author
 * @date
 * @description
 */
public enum NewContractCarStateEnum {


    LEASED(1, "全部已退回"),
    LEASE_SUSPENSION(2, "未全部退回");

    private final Integer state;

    private final String text;

    public Integer getState() {
        return state;
    }

    public String getText() {
        return text;
    }

    NewContractCarStateEnum(Integer state, String text) {
        this.state = state;
        this.text = text;
    }

    public static String getText(Integer state) {
        if (state == null) {
            return null;
        }
        for (NewContractCarStateEnum value : values()) {
            if (value.state.equals(state)) {
                return value.getText();
            }
        }
        return null;
    }
}
