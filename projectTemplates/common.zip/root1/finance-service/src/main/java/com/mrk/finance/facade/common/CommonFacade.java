package com.mrk.finance.facade.common;

import com.alibaba.fastjson.JSON;
import com.github.pagehelper.PageInfo;
import com.mrk.finance.client.dto.ContractMementDto;
import com.mrk.workflow.client.Dto.CarPageDto;
import com.mrk.workflow.client.UseCarWorkflowClient;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.List;

@Component
public class CommonFacade {
    @Autowired
    private UseCarWorkflowClient useCarWorkflowClient;

    /**
     * 车辆列表分页查询
     * @param entity
     * @return
     */
    public PageInfo<CarPageDto> page(ContractMementDto entity) {
        return useCarWorkflowClient.selectByContractStr(JSON.toJSONString(entity)).getDataWithEx();
    }

    /**
     * 车辆列表分页查询(简化版) (天眼1.1 合同统计)
     * @param entity 查询条件
     * @author Roger
     * @return *
     */
    public List<CarPageDto> dataSelectByContractStr(ContractMementDto entity) {
        return useCarWorkflowClient.dataSelectByContractStr(JSON.toJSONString(entity)).getDataWithEx();
    }
}
