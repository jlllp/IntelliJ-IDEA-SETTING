package com.mrk.finance.facade.dto;

import com.mrk.finance.enums.WaterMatchTypeEnum;
import com.mrk.finance.model.FncBankWater;
import com.mrk.finance.model.FncDdWithhold;
import com.mrk.finance.model.FncTtWithhold;
import lombok.Getter;

/**
 * @project: mrk-finance
 * @author: Frank.Tang
 * @date: 2021-11-30 11:13
 * @desc: 流水及代扣对象集合
 **/
@Getter
public class WaterIntegrationDto {

    /** 类型: {@link WaterMatchTypeEnum} */
    private Integer type;

    private FncBankWater bankWater;

    private FncDdWithhold ddWithhold;

    private FncTtWithhold ttWithhold;


    public WaterIntegrationDto(FncBankWater bankWater) {
       this.bankWater = bankWater;
       this.type = WaterMatchTypeEnum.YH.getValue();
    }

    public WaterIntegrationDto(FncDdWithhold ddWithhold) {
        this.ddWithhold = ddWithhold;
        this.type = WaterMatchTypeEnum.DD.getValue();
    }

    public WaterIntegrationDto(FncTtWithhold ttWithhold) {
        this.ttWithhold = ttWithhold;
        this.type = WaterMatchTypeEnum.TT.getValue();
    }

}
