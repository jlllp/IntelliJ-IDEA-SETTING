package com.mrk.finance.vo;

import com.mrk.finance.dto.FncRentalFeesDto;
import com.mrk.finance.model.*;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.util.List;

/**
 * @project: mrk-finance
 * @author: Frank.Tang
 * @date: 2021-11-17 09:31
 * @desc:
 **/
@Data
public class ContractAddOrUpdateVo extends FncContractManagement {

    @ApiModelProperty("车型")
    private List<FncContractCarmodel> carmodels;

    @ApiModelProperty("租金费用")
    private List<FncContractRent> rents;

    @ApiModelProperty("附件")
    private List<FncContractAttach> fncContractAttaches;

    @ApiModelProperty("租金包含费用")
    private List<FncRentalFeesDto> rentalFees;

    @ApiModelProperty("保存并重新发起")
    private Integer  sum;

}
