package com.mrk.finance.facade.contract;

import cn.afterturn.easypoi.excel.ExcelExportUtil;
import cn.afterturn.easypoi.excel.entity.ExportParams;
import com.github.pagehelper.PageInfo;
import com.mrk.auth.client.AuthCityClient;
import com.mrk.auth.client.AuthDeptClient;
import com.mrk.auth.model.AuthCity;
import com.mrk.auth.model.AuthDept;
import com.mrk.common.constant.BaseConstants;
import com.mrk.common.exception.GlobalException;
import com.mrk.common.utils.container.ListUtil;
import com.mrk.common.utils.jwt.JWTUtil;
import com.mrk.common.utils.page.PageUtils;
import com.mrk.common.utils.text.CheckUtil;
import com.mrk.common.utils.time.DateUtils;
import com.mrk.finance.constants.DateConstants;
import com.mrk.finance.constants.ExMsgConstants;
import com.mrk.finance.constants.LenConstants;
import com.mrk.finance.dto.*;
import com.mrk.finance.dto.contract.RentCalculationDto;
import com.mrk.finance.dto.contract.RentTimeRightDto;
import com.mrk.finance.dto.date.TimeRightDto;
import com.mrk.finance.enums.*;
import com.mrk.finance.example.FncContractRentExample;
import com.mrk.finance.example.FncContractRentalFeesExample;
import com.mrk.finance.facade.CarExportFacade;
import com.mrk.finance.facade.bill.FncBillManagementFacade;
import com.mrk.finance.facade.common.CommonFacade;
import com.mrk.finance.model.*;
import com.mrk.finance.queryvo.*;
import com.mrk.finance.service.*;
import com.mrk.finance.util.ExceptionUtil;
import com.mrk.finance.util.ObjectUtil;
import com.mrk.finance.util.StreamUtil;
import com.mrk.finance.util.contract.ContractDateCalculateUtil;
import com.mrk.finance.vo.ContractAddOrUpdateVo;
import com.mrk.member.client.MemberClient;
import com.mrk.member.model.MrkMember;
import com.mrk.sys.client.SysCarTypeClient;
import com.mrk.sys.model.SysCarType;
import com.mrk.universal.enums.contract.ContractLeaseStartTypeEnum;
import com.mrk.universal.enums.contract.ContractMarginPayRequireEnum;
import com.mrk.universal.enums.contract.ContractPartyTypeEnum;
import com.mrk.universal.enums.contract.ContractTypeEnum;
import com.mrk.universal.enums.turner.TurnerSingleOverTimeEnum;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.apache.poi.ss.usermodel.Workbook;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

import javax.servlet.http.HttpServletResponse;
import java.math.BigDecimal;
import java.text.SimpleDateFormat;
import java.util.*;
import java.util.stream.Collectors;

/**
 * @project: mrk-finance
 * @author: Frank.Tang
 * @date: 2021-11-15 09:44
 * @desc: 合同管理, 相关方法汇总:
 * (1)分页查询----------{@link FncContractManagementFacade\#page}
 * (2)查询所含合同------{@link FncContractManagementFacade\#pageBillOfContract}
 * (3)查询所含车辆------{@link CommonFacade\#page}
 * (4)新增--------------{@link FncContractManagementFacade\#add}
 * (5)删除--------------{@link FncContractManagementFacade\#del}
 * (6)更新--------------{@link FncContractManagementFacade\#update}
 * (7)计算结束日期------{@link FncContractManagementFacade\#calEndDate}
 * (8)计算租金总额------{@link FncContractManagementFacade\#calRentTotal}
 * (9)导出--------------{@link FncContractManagementFacade\#export}
 **/
@Slf4j
@Component
public class FncContractManagementFacade {

    @Autowired
    private FncBillManagementFacade fncBillManagementFacade;
    @Autowired
    private FncContractManagementService fncContractManagementService;
    @Autowired
    private FncBillManagementService fncBillManagementService;
    @Autowired
    private FncContractCarmodelService fncContractCarmodelService;
    @Autowired
    private FncRentalFeesService fncRentalFeesService;
    @Autowired
    private FncContractRentalFeesService fncContractRentalFeesService;
    @Autowired
    private FncContractRentService fncContractRentService;
    @Autowired
    private FncContractAdditionService fncContractAdditionService;
    @Autowired
    private SysCarTypeClient sysCarTypeClient;
    @Autowired
    private AuthCityClient authCityClient;
    @Autowired
    private AuthDeptClient authDeptClient;
    @Autowired
    private MemberClient memberClient;
    @Autowired
    private ContractOnlyCarFacade contractOnlyCarFacade;
    @Autowired
    private ContractFacade contractFacade;
    @Autowired
    private CarExportFacade exportByExcel;

    /**
     * 这里的常量和前端约定, 用于判断更新时, 新增or更新
     */
    private static final String CAR_MODEL_UPDATE = "c01_car_model_update";
    private static final String CAR_MODEL_ADD = "c02_car_model_add";

    private static final int ADD = 0;
    private static final int UPDATE = 1;

    /**
     * 分页查询
     *
     * @return *
     * @author Frank.Tang
     */
    public PageInfo<FncContractManagementDto> page(FncContractManagementQueryVo queryVo) {
        PageInfo<FncContractManagement> page = fncContractManagementService.pageWithTableJoin(queryVo);
        List<FncContractManagement> list = page.getList();
        if (list == null || list.isEmpty()) {
            return new PageInfo<>();
        }

        List<FncContractManagementDto> res = ListUtil.copyBeanList(list, FncContractManagementDto.class);

        //所有会员id
        List<Long> memberIds = new ArrayList<>();
        //所有部门id
        List<Long> deptIds = new ArrayList<>();
        //所有合同id
        List<Long> contractIds = new ArrayList<>();
        //不固定类型的合同id
        List<Long> contractIdsNotFixed = new ArrayList<>();
        for (FncContractManagementDto re : res) {
            contractIds.add(re.getFcmId());
            if (ContractLeaseTypeEnum.NOT_FIXED.getValue().equals(re.getFcmLeaseType())) {
                contractIdsNotFixed.add(re.getFcmId());
            }
            if (ContractPartyTypeEnum.PERSONAL.getValue().equals(re.getFcmPartyaType())) {
                memberIds.add(re.getFcmPartyaId());
            } else {
                deptIds.add(re.getFcmPartyaId());
            }
            if (ContractPartyTypeEnum.PERSONAL.getValue().equals(re.getFcmPartybType())) {
                memberIds.add(re.getFcmPartybId());
            } else {
                deptIds.add(re.getFcmPartybId());
            }
        }

        contractIds = StreamUtil.toList(res, FncContractManagement::getFcmId);
        contractIdsNotFixed = res.stream()
                .filter(o -> ContractLeaseTypeEnum.NOT_FIXED.getValue().equals(o.getFcmLeaseType()))
                .map(FncContractManagement::getFcmId)
                .collect(Collectors.toList());

        //关联的车型
        List<FncContractCarmodel> carModels = fncContractCarmodelService.batchSelectByContractIds(contractIds);
        List<FncContractCarmodelDto> carModelDtos = ListUtil.copyBeanList(carModels, FncContractCarmodelDto.class);
        Map<Long, List<FncContractCarmodelDto>> carModelMap = carModelDtos.stream()
                .filter(o -> o != null && o.getFccContractId() != null)
                .collect(Collectors.groupingBy(FncContractCarmodel::getFccContractId));

        for (FncContractCarmodelDto carModelDto : carModelDtos) {
            SysCarType carType = sysCarTypeClient.getById(carModelDto.getFccContractCarmodelId()).getDataWithEx();
            carModelDto.setFccContractCarmodelName(carType.getCarTypeName());
        }

        //关联的补充协议
        List<FncContractAddition> additions = fncContractAdditionService.selectByContractIds(contractIds);
        List<FncContractAdditionDto> additionsDtoList = ListUtil.copyBeanList(additions, FncContractAdditionDto.class);
        for (FncContractAdditionDto dto : additionsDtoList) {
            dto.setFcaPayTypeName(ContractAdditionPayTypeEnum.getName(dto.getFcaPayType()));
            dto.setFcaTypeName(ContractAdditionTypeEnum.getName(dto.getFcaType()));
        }
        Map<Long, List<FncContractAdditionDto>> additionMap = additionsDtoList.stream()
                .collect(Collectors.groupingBy(FncContractAdditionDto::getFcaContractId));

        //租金包含费用
        FncContractRentalFeesQueryVo queryVo1 = new FncContractRentalFeesQueryVo();
        Map<Long, List<FncContractRentalFeesDto>> rentalFeesMap;
        if (contractIds.isEmpty()) {
            rentalFeesMap = new HashMap<>();
        } else {
            queryVo1.setFcrfContractIdIn(contractIds);
            List<FncContractRentalFees> contractRentalFees = fncContractRentalFeesService.list(queryVo1);
            List<FncContractRentalFeesDto> rentalFeesDtos = ListUtil.copyBeanList(contractRentalFees, FncContractRentalFeesDto.class);

            //渲染每个的name
            List<Long> rentFeeIds = StreamUtil.toList(rentalFeesDtos, FncContractRentalFees::getFcrfRentFeesId);
            FncRentalFeesQueryVo queryVo2 = new FncRentalFeesQueryVo();
            List<FncRentalFees> rentalFees;
            if (rentFeeIds != null && !rentFeeIds.isEmpty()) {
                queryVo2.setFrfIdIn(rentFeeIds);
                rentalFees = fncRentalFeesService.list(queryVo2);
            } else {
                rentalFees = new ArrayList<>();
            }

            Map<Long, String> idAndNameMap = StreamUtil.toMap(rentalFees, FncRentalFees::getFrfId, FncRentalFees::getFrfName);
            Map<Long, String> idAndMarkMap = StreamUtil.toMap(rentalFees, FncRentalFees::getFrfId, FncRentalFees::getFrfMark);

            for (FncContractRentalFeesDto dto : rentalFeesDtos) {
                dto.setFcrfName(idAndNameMap.get(dto.getFcrfRentFeesId()));
                dto.setFcrfMark(idAndMarkMap.get(dto.getFcrfRentFeesId()));
            }
            rentalFeesMap = rentalFeesDtos.stream().collect(Collectors.groupingBy(FncContractRentalFees::getFcrfContractId));
        }

        //不固定租金
        Map<Long, List<FncContractRent>> rentsMap;
        FncContractRentQueryVo queryVo2 = new FncContractRentQueryVo();
        if (contractIdsNotFixed.isEmpty()) {
            rentsMap = new HashMap<>();
        } else {
            queryVo2.setFccContractIdIn(contractIdsNotFixed);
            List<FncContractRent> rents = fncContractRentService.list(queryVo2);
            rentsMap = rents.stream().collect(Collectors.groupingBy(FncContractRent::getFccContractId));
        }

        //会员+组织
        List<MrkMember> members = memberClient.findByids(ObjectUtil.collectionToStr(memberIds)).getDataWithEx();
        List<AuthDept> depts = authDeptClient.getAuthDeptByIds(ObjectUtil.collectionToStr(deptIds)).getDataWithEx();
        Map<Long, MrkMember> memberMap = StreamUtil.toMap(members, MrkMember::getMmId);
        Map<Long, AuthDept> deptMap = StreamUtil.toMap(depts, AuthDept::getId);

        //城市
        List<Long> cityIds = StreamUtil.toList(res, FncContractManagement::getFcmCityId);
        List<AuthCity> cities = authCityClient.getCityByIds(ObjectUtil.collectionToStr(cityIds)).getDataWithEx();
        Map<Long, AuthCity> cityMap = StreamUtil.toMap(cities, AuthCity::getId);

        for (FncContractManagementDto dto : res) {
            List<FncContractCarmodelDto> contractCarmodelDtos = carModelMap.get(dto.getFcmId());
            List<FncContractRentalFeesDto> rentalFee = rentalFeesMap.get(dto.getFcmId());
            List<FncContractRent> rent = rentsMap.get(dto.getFcmId());
            List<FncContractAdditionDto> additionList = additionMap.get(dto.getFcmId());
            AuthCity authCity = cityMap.get(dto.getFcmCityId());
            Long partyaId = dto.getFcmPartyaId();
            Long partybId = dto.getFcmPartybId();

            //甲
            if (ContractPartyTypeEnum.PERSONAL.getValue().equals(dto.getFcmPartyaType())) {
                MrkMember member = memberMap.get(partyaId);
                dto.setFcmPartyaName(member == null ? "" : member.getMmName());
            } else {
                AuthDept dept = deptMap.get(partyaId);
                dto.setFcmPartyaName(dept == null ? "" : dept.getDeptName());
            }
            //乙
            if (ContractPartyTypeEnum.PERSONAL.getValue().equals(dto.getFcmPartybType())) {
                MrkMember member = memberMap.get(partybId);
                dto.setFcmPartybName(member == null ? "" : member.getMmName());
            } else {
                AuthDept dept = deptMap.get(partybId);
                dto.setFcmPartybName(dept == null ? "" : dept.getDeptName());
            }

            if (contractCarmodelDtos != null) {
                contractCarmodelDtos.stream()
                        .filter(Objects::nonNull)
                        .map(FncContractCarmodel::getFccCarnum)
                        .reduce(Integer::sum)
                        .ifPresent(dto::setCarModelTotal);
            }
            dto.setFcmContractTypeName(ContractTypeEnum.getText(dto.getFcmContractType()));
            dto.setFcmContractStateName(ContractStateEnum.getText(dto.getFcmContractState()));
            dto.setFcmSettlementStateName(SettlementStateEnum.getText(dto.getFcmSettlementState()));
            dto.setFcmCityName(authCity == null ? "" : authCity.getCityName());
            dto.setRents(rent);
            dto.setContractRentalFees(rentalFee);
            dto.setCarModelDtos(contractCarmodelDtos);
            dto.setAdditions(additionList);
        }
        return new PageInfo<>(res);
    }

    /**
     * 查询所含的账单
     *
     * @return *
     * @author Frank.Tang
     */
    public PageInfo<FncBillManagementDto> pageBillOfContract(FncBillManagementQueryVo queryVo) {
        CheckUtil.isEmptyWithEx(queryVo, ExMsgConstants.RECEIVE_NULL_PARA);
        CheckUtil.isEmptyWithEx(queryVo.getFbmAssociateContractIdEqualTo(), ExMsgConstants.RECEIVE_NULL_PARA + "-关联合同id");

        return fncBillManagementFacade.page(queryVo);
    }

    /**
     * 新增合同
     *
     * @return *
     * @author Frank.Tang
     */
    @Transactional(rollbackFor = Exception.class)
    public Integer add(ContractAddOrUpdateVo entity) {
        //校验
        checkAdd(entity);

        //清除字段
        clearFiled(entity, ADD);

        //这里判断当前时间, 确定合同的初始状态
        Date now = new Date();
        Date startDate = entity.getFcmLeaseStartDate();
        entity.setFcmSettlementState(SettlementStateEnum.OUTSTANDING.getState());
        if (startDate != null) {
            entity.setFcmContractState(now.after(startDate) ?
                    ContractStateEnum.LEASED.getState() :
                    ContractStateEnum.LEASE_TO_START.getState());
        } else {
            entity.setFcmContractState(ContractStateEnum.LEASE_TO_START.getState());
        }

        //新增, 拿到id
        entity.setFncTurnerSingleDeal(TurnerSingleOverTimeEnum.NO.getState());
        fncContractManagementService.add(entity);
        Long fcmId = entity.getFcmId();

        //设置关联id, 并新增
        List<FncContractRent> rents = entity.getRents();
        List<FncContractCarmodel> carmodels = entity.getCarmodels();
        List<FncRentalFeesDto> rentalFees = entity.getRentalFees();

        List<FncContractRentalFees> contractRentalFeesList = new ArrayList<>();
        for (FncRentalFeesDto rentalFee : rentalFees) {
            FncContractRentalFees contractRentalFees = new FncContractRentalFees();
            contractRentalFees.setFcrfContractId(fcmId);
            contractRentalFees.setFcrfRentFeesId(rentalFee.getFrfId());
            contractRentalFees.setFcrfWrite(rentalFee.getFrfWrite());
            contractRentalFees.setFcrfValue(rentalFee.getFrfValue());
            contractRentalFeesList.add(contractRentalFees);
        }

        for (FncContractCarmodel carmodel : carmodels) {
            carmodel.setFccContractId(fcmId);
        }

        if (rents != null && ContractLeaseTypeEnum.NOT_FIXED.getValue().equals(entity.getFcmLeaseType())) {
            for (FncContractRent rent : rents) {
                rent.setFccContractId(fcmId);
            }
            fncContractRentService.addList(rents);
        }

        //生成保证金账单
        genMarginBill(entity);
        //新增关联数据
        fncContractCarmodelService.addList(carmodels);
        fncContractRentalFeesService.addList(contractRentalFeesList);

        log.info("用户【{}】, 新增合同(id【{}】)", JWTUtil.getNikeName(), fcmId);

        return BaseConstants.DR_YES;
    }

    /**
     * 删除合同 (删除关联账单, 不删除关联车型/包含费用等数据)
     *
     * @return *
     * @author Frank.Tang
     */
    @Transactional(rollbackFor = Exception.class)
    public Integer del(Long fcmId) {
        //check
        FncContractManagement contract = checkDel(fcmId);

        contract.setDr(BaseConstants.DR_YES);

        //删除关联的账单
        List<FncBillManagement> bills = fncBillManagementService.selectByContractId(fcmId);
        for (FncBillManagement bill : bills) {
            fncBillManagementFacade.del(bill.getFbmId(), true);
        }

        log.info("用户【{}】, 删除合同(id【{}】)", JWTUtil.getNikeName(), fcmId);

        return fncContractManagementService.update(contract);
    }

    /**
     * 批量删除合同
     *
     * @return *
     * @author Frank.Tang
     */
    @Transactional(rollbackFor = Exception.class)
    public Integer delBatch(List<Long> ids) {
        if (ids == null || ids.isEmpty()) {
            throw new GlobalException("数据异常, 请选择需要删除的合同");
        }
        for (Long id : ids) {
            del(id);
        }
        return ids.size();
    }

    /**
     * 更新合同
     *
     * @return *
     * @author Frank.Tang
     */
    @Transactional(rollbackFor = Exception.class)
    public Integer update(ContractAddOrUpdateVo entity) {
        //check 拿到相关数据
        ContractUpdateDto dto = checkUpdate(entity);
        List<FncContractRent> rents = entity.getRents();
        List<FncContractCarmodel> tobeAddCarmodels = dto.getTobeAddCarmodels();
        List<FncContractCarmodel> tobeUpdateCarmodels = dto.getTobeUpdateCarmodels();
        List<FncRentalFeesDto> rentalFees = dto.getRentalFees();

        //清除字段
        clearFiled(entity, UPDATE);

        //待新增的车型
        if (tobeAddCarmodels != null && !tobeAddCarmodels.isEmpty()) {
            tobeAddCarmodels.stream()
                    .map(FncContractCarmodel::getFccCarnum)
                    .reduce(Integer::sum)
                    .ifPresent(o -> entity.setFcmCarnumTotal(entity.getFcmCarnumTotal() + o));
            fncContractCarmodelService.addList(tobeAddCarmodels);
        }
        //待更新的车型
        if (tobeUpdateCarmodels != null && !tobeUpdateCarmodels.isEmpty()) {
            for (FncContractCarmodel carmodel : tobeUpdateCarmodels) {
                fncContractCarmodelService.updateSelective(carmodel);
            }
        }

        //租金包含费用
        if (rentalFees != null) {
            //删除以前的
            FncContractRentalFeesExample example = new FncContractRentalFeesExample();
            example.createCriteria()
                    .andDrEqualTo(BaseConstants.DR_NO)
                    .andFcrfContractIdEqualTo(entity.getFcmId());
            FncContractRentalFees updateEntity = new FncContractRentalFees();
            updateEntity.setDr(BaseConstants.DR_YES);
            fncContractRentalFeesService.updateByExampleSelective(updateEntity, example);

            //重新新增
            List<FncContractRentalFees> res = new ArrayList<>();
            for (FncRentalFeesDto rentalFee : rentalFees) {
                FncContractRentalFees contractRentalFees = new FncContractRentalFees();
                contractRentalFees.setFcrfContractId(entity.getFcmId());
                contractRentalFees.setFcrfRentFeesId(rentalFee.getFrfId());
                contractRentalFees.setFcrfWrite(rentalFee.getFrfWrite());
                contractRentalFees.setFcrfValue(rentalFee.getFrfValue());
                res.add(contractRentalFees);
            }
            fncContractRentalFeesService.addList(res);
        }

        //租金
        if (rents != null && !rents.isEmpty()) {
            FncContractRent updateEntity = new FncContractRent();
            updateEntity.setDr(BaseConstants.DR_YES);

            FncContractRentExample example = new FncContractRentExample();
            example.createCriteria()
                    .andFccContractIdEqualTo(entity.getFcmId())
                    .andDrEqualTo(BaseConstants.DR_NO);

            //删除以前的
            fncContractRentService.updateByExampleSelective(updateEntity, example);

            for (FncContractRent rent : rents) {
                rent.setFccContractId(entity.getFcmId());
            }
            //重新新增
            fncContractRentService.addList(rents);
        }

        //判断更新日期后, 更新合同状态
        Integer contractState = entity.getFcmContractState();
        Date startDate = entity.getFcmLeaseStartDate();
        if (startDate != null &&
                (ContractStateEnum.LEASE_TO_START.getState().equals(contractState) ||
                        ContractStateEnum.LEASED.getState().equals(contractState))) {
            Date nowDate = new Date();
            if (nowDate.after(startDate)) {
                entity.setFcmContractState(ContractStateEnum.LEASED.getState());
            } else {
                entity.setFcmContractState(ContractStateEnum.LEASE_TO_START.getState());
            }
        }

        log.info("用户【{}】, 更新合同(id【{}】)", JWTUtil.getNikeName(), entity.getFcmId());

        return fncContractManagementService.updateSelective(entity);
    }

    /**
     * 根据周期+开始日期等条件, 计算结束日期
     *
     * @return *
     * @author Frank.Tang
     */
    public String calEndDate(FncContractManagement contract) {
        Date startDate = contract.getFcmLeaseStartDate();
        Integer leaseCount = contract.getFcmLeaseCount();
        Integer rentPayType = contract.getFcmRentPayType();
        Integer rentPayCycle = contract.getFcmRentPayCycle();

        CheckUtil.isEmptyWithEx(startDate, ExMsgConstants.RECEIVE_NULL_PARA + "(起始日期)");
        CheckUtil.isEmptyWithEx(leaseCount, ExMsgConstants.RECEIVE_NULL_PARA + "(租期)");
        CheckUtil.isEmptyWithEx(rentPayType, ExMsgConstants.RECEIVE_NULL_PARA + "(租赁类型)");
        CheckUtil.isEmptyWithEx(rentPayCycle, ExMsgConstants.RECEIVE_NULL_PARA + "(支付周期)");

        SortedMap<Integer, TimeRightDto> map = ContractDateCalculateUtil
                .calculateThePaymentPeriod(
                        startDate, contractFacade.getLeaseCount(contract), rentPayType,
                        ContractRentPaymentCycleEnum.toIntervalValue(rentPayCycle)
                );

        Integer lastKey = map.lastKey();
        TimeRightDto rightDto = map.get(lastKey);

        SimpleDateFormat dateFormat = new SimpleDateFormat(DateUtils.YYYY_MM_DD);

        return dateFormat.format(rightDto.getEnd());
    }

    /**
     * 计算 固定/不固定 总金额
     *
     * @return *
     * @author Frank.Tang
     */
    @Transactional(rollbackFor = Exception.class)
    public BigDecimal calRentTotal(RentCalculationDto dto) {
        //校验
        checkCalRentTotal(dto);

        //没传, 表示交车日期, 直接返回0
        if (dto.getFcmLeaseStartDate() == null) {
            return BigDecimal.ZERO;
        }

        //执行计算逻辑
        SortedMap<Integer, RentTimeRightDto> rent = contractFacade.getRent(dto);

        //为空报错
        if (rent.isEmpty()) {
            throw new GlobalException("计算异常, 请重试");
        }

        ArrayList<RentTimeRightDto> rightDtoList = new ArrayList<>(rent.values());

        //求和并返回
        return rightDtoList.stream()
                .map(RentTimeRightDto::getAmount)
                .map(BigDecimal::valueOf)
                .reduce(BigDecimal::add)
                .orElse(BigDecimal.ZERO);
    }

    /**
     * 导出
     *
     * @author Frank.Tang
     */
    public void export(FncContractManagementQueryVo queryVo, HttpServletResponse response) {
        long sTime = System.currentTimeMillis();

        PageInfo<FncContractManagementDto> pageInfo = page(queryVo);
        int maxSize = 50000;
        if (pageInfo.getTotal() > maxSize) {
            throw new GlobalException("导出的数量超过5万条，请缩小范围");
        }
        // 导出文件
        List<FncContractManagementExportByQueryDto> dtos =
                ListUtil.copyBeanList(pageInfo.getList(), FncContractManagementExportByQueryDto.class);

        for (FncContractManagementExportByQueryDto dto : dtos) {
            List<FncContractCarmodelDto> carModelDtos = dto.getCarModelDtos();
            List<FncContractAddition> additions = dto.getAdditions();

            Set<String> carModelNames = StreamUtil.toSet(carModelDtos, FncContractCarmodelDto::getFccContractCarmodelName);
            String joinedNames = StringUtils.join(carModelNames, "，");

            String carModelTypesCount;
            if (carModelNames == null || carModelNames.isEmpty()) {
                carModelTypesCount = "";
            } else if (carModelNames.size() == 1) {
                carModelTypesCount = "单一车型";
            } else {
                carModelTypesCount = "多种车型";
            }

            if (additions != null && !additions.isEmpty()) {
                List<String> additionNames = additions.stream()
                        .filter(Objects::nonNull)
                        .map(o -> ContractAdditionTypeEnum.getName(o.getFcaType()) + "(" + o.getFcaContractNo() + ")")
                        .collect(Collectors.toList());
                String rentalFeeNames = StringUtils.join(additionNames, ",");
                dto.setRentalFeeNames(rentalFeeNames);
            }

            dto.setCarModelTypes(joinedNames);
            dto.setCarModelTypesCount(carModelTypesCount);
        }

        Workbook workbook = ExcelExportUtil.exportExcel(new ExportParams(), FncContractManagementExportByQueryDto.class, dtos);

        String fileName = "合同管理" + System.currentTimeMillis() + ".xls";
        exportByExcel.exportByExcel(response, fileName, workbook);

        long eTime = System.currentTimeMillis();

        log.info("用户【{}】, 导出合同. 数据量【{}条】, 耗时【{}ms】", JWTUtil.getNikeName(), dtos.size(), (eTime - sTime));
    }

    /**
     * 生成保证金账单
     *
     * @author Frank.Tang
     */
    private void genMarginBill(ContractAddOrUpdateVo entity) {
        FncBillManagement bill = new FncBillManagementDto();

        Double marginTotal = entity.getFcmMarginTotal();
        bill.setFbmBillAmount(marginTotal);
        bill.setFbmMatchedAmount(0.0);
        bill.setFbmNotMatchAmount(marginTotal);
        bill.setFbmAssociateContractId(entity.getFcmId());
        bill.setFbmSubjects(BillSubjectsEnum.BOND.getValue());
        bill.setFbmCityId(entity.getFcmCityId());
        bill.setFbmBillState(BillStateEnum.UNPAID.getValue());
        bill.setFbmBillGenerateWay(BillGenerateWayEnum.AUTO.getValue());
        bill.setFbmTurnerDeal(TurnerSingleOverTimeEnum.NO.getState());
        //保证金账单, 只有开始日期, 不设置截止日期
        bill.setFbmBillGenerateTime(entity.getFcmSignedDate());
        bill.setFbmBillGenerateReason(String.format("新增合同(id-%s), 自动生成保证金账单", entity.getFcmId()));

        //只有一辆车才设置车id
        Long carId = contractOnlyCarFacade.getCarIdByContract(entity);
        bill.setFbmAssociateCarId(carId);

        fncBillManagementService.add(bill);
    }

    /**
     * 根据类型, 清除字段, 防止前端不同类型传错值
     * (比如"续租"有平台, "以租代售"没有平台. 当类型为"以租代售"时, 需要清除该字段)
     *
     * @param type=0 --> 新增
     *               1 --> 更新
     * @author Frank.Tang
     */
    private void clearFiled(ContractAddOrUpdateVo entity, int type) {
        Integer contractType = entity.getFcmContractType();
        //以租代售
        if (ContractTypeEnum.RENT_FOR_SALE.getType().equals(contractType)) {
            entity.setFcmOperatPlatform(null);
            entity.setFcmAssociateContractId(null);
            entity.setFcmAssociateContractNo(null);
        }
        //经营性租赁 或 自营网约车_新租
        else if (ContractTypeEnum.OPERATING_LEASE.getType().equals(contractType)
                || ContractTypeEnum.NEW_LEASE.getType().equals(contractType)) {
            entity.setFcmBoldRent(null);
            entity.setFcmCarPurchase(null);
            entity.setFcmCarPurchaseAdvance(null);
            entity.setFcmAssociateContractId(null);
            entity.setFcmAssociateContractNo(null);
        }
        //自营网约车_续租
        else if (ContractTypeEnum.LEASE_RENEWAL.getType().equals(contractType)) {
            entity.setFcmBoldRent(null);
            entity.setFcmCarPurchase(null);
            entity.setFcmCarPurchaseAdvance(null);
        }

        //新增时, 是交车日期, 清空租金总额
        if (type == ADD && ContractLeaseStartTypeEnum.DELIVERY_DATE.getValue().equals(entity.getFcmLeaseStartType())) {
            entity.setFcmLeaseAmountTotal(null);
        }
    }


    /*********************************************************************************************
     *                                          Checks
     *********************************************************************************************
     **
     * 新增校验
     * @author Frank.Tang
     */
    private void checkAdd(ContractAddOrUpdateVo entity) {
        CheckUtil.isEmptyWithEx(entity, ExMsgConstants.RECEIVE_NULL_ENTITY);

        //车辆及费用信息
        List<FncContractCarmodel> carmodels = entity.getCarmodels();
        List<FncContractRent> rents = entity.getRents();
        List<FncRentalFeesDto> rentalFees = entity.getRentalFees();
        if (carmodels == null || carmodels.isEmpty()) {
            throw new GlobalException(ExMsgConstants.RECEIVE_NULL_PARA + " (车型)");
        }
        //取消租金包含费用必填

        //合同的主体信息
        Long cityId = entity.getFcmCityId();
        Integer contractType = entity.getFcmContractType();
        String contractNo = entity.getFcmContractNo();
        Long partyaId = entity.getFcmPartyaId();
        Long partybId = entity.getFcmPartybId();
        Integer partyaType = entity.getFcmPartyaType();
        Integer partybType = entity.getFcmPartybType();
        Date signedDate = entity.getFcmSignedDate();
        Integer carnumTotal = entity.getFcmCarnumTotal();
        Integer leaseCount = entity.getFcmLeaseCount();
        Integer leaseStartType = entity.getFcmLeaseStartType();
        Date leaseStartDate = entity.getFcmLeaseStartDate();
        Date leaseEndDate = entity.getFcmLeaseEndDate();
        Integer leaseType = entity.getFcmLeaseType();
        Double leaseAmount = entity.getFcmLeaseAmount();
        Integer rentPayType = entity.getFcmRentPayType();
        Integer rentPayCycle = entity.getFcmRentPayCycle();
        Integer billGenerateType = entity.getFcmBillGenerateType();
        Integer billCatOffType = entity.getFcmBillCatoffType();
        Double leaseAmountTotal = entity.getFcmLeaseAmountTotal();
        Double singleMargin = entity.getFcmSingleMargin();
        Double marginTotal = entity.getFcmMarginTotal();
        Integer marginPayRequire = entity.getFcmMarginPayRequire();
        Double fcmCarPurchase = entity.getFcmCarPurchase();
        Double boldRent = entity.getFcmBoldRent();
        String carPurchaseAdvance = entity.getFcmCarPurchaseAdvance();
        //公共字段非空校验
        CheckUtil.isEmptyWithEx(cityId, ExMsgConstants.RECEIVE_NULL_PARA + "-城市");
        CheckUtil.isEmptyWithEx(contractType, ExMsgConstants.RECEIVE_NULL_PARA + "-合同类型");
        CheckUtil.isEmptyWithEx(contractNo, ExMsgConstants.RECEIVE_NULL_PARA + "-合同号");
        CheckUtil.isEmptyWithEx(partyaId, ExMsgConstants.RECEIVE_NULL_PARA + "-甲方id");
        CheckUtil.isEmptyWithEx(partybId, ExMsgConstants.RECEIVE_NULL_PARA + "-乙方id");
        CheckUtil.isEmptyWithEx(partyaType, ExMsgConstants.RECEIVE_NULL_PARA + "-甲方类型");
        CheckUtil.isEmptyWithEx(partybType, ExMsgConstants.RECEIVE_NULL_PARA + "-乙方类型");
        CheckUtil.isEmptyWithEx(signedDate, ExMsgConstants.RECEIVE_NULL_PARA + "-签订日期");
        CheckUtil.isEmptyWithEx(carnumTotal, ExMsgConstants.RECEIVE_NULL_PARA + "-车辆总数");
        CheckUtil.isEmptyWithEx(leaseCount, ExMsgConstants.RECEIVE_NULL_PARA + "-租期");
        CheckUtil.isEmptyWithEx(leaseStartType, ExMsgConstants.RECEIVE_NULL_PARA + "-开始类型");
        CheckUtil.isEmptyWithEx(leaseType, ExMsgConstants.RECEIVE_NULL_PARA + "-租赁类型");
        CheckUtil.isEmptyWithEx(rentPayType, ExMsgConstants.RECEIVE_NULL_PARA + "-租金支付类型");
        CheckUtil.isEmptyWithEx(rentPayCycle, ExMsgConstants.RECEIVE_NULL_PARA + "-租金支付周期");
        CheckUtil.isEmptyWithEx(billGenerateType, ExMsgConstants.RECEIVE_NULL_PARA + "-账单生成类型");
        CheckUtil.isEmptyWithEx(billCatOffType, ExMsgConstants.RECEIVE_NULL_PARA + "-账单截止日期");
        CheckUtil.isEmptyWithEx(singleMargin, ExMsgConstants.RECEIVE_NULL_PARA + "-单车保证金");
        CheckUtil.isEmptyWithEx(marginTotal, ExMsgConstants.RECEIVE_NULL_PARA + "-保证金总额");
        CheckUtil.isEmptyWithEx(marginPayRequire, ExMsgConstants.RECEIVE_NULL_PARA + "-保证金支付要求");

        checkInterval(entity);

        //长度校验
        if (contractNo.length() > LenConstants.LEN_255) {
            throw ExceptionUtil.outLen("合同号");
        }

        //以租代售, 特殊字段
        if (contractType.equals(ContractTypeEnum.RENT_FOR_SALE.getType())) {
            CheckUtil.isEmptyWithEx(fcmCarPurchase, ExMsgConstants.RECEIVE_NULL_PARA);
            CheckUtil.isEmptyWithEx(carPurchaseAdvance, ExMsgConstants.RECEIVE_NULL_PARA);
            CheckUtil.isEmptyWithEx(boldRent, ExMsgConstants.RECEIVE_NULL_PARA);
            if (carPurchaseAdvance.length() > LenConstants.LEN_2550) {
                throw ExceptionUtil.outLen("提前购车价计算方式");
            }
        }

        //非以租代售, 特殊字段
        if (!ContractTypeEnum.RENT_FOR_SALE.getType().equals(contractType)) {
            Integer platform = entity.getFcmOperatPlatform();
            //这两种才校验运营平台
            if (ContractTypeEnum.LEASE_RENEWAL.getType().equals(contractType)
                    || ContractTypeEnum.NEW_LEASE.getType().equals(contractType)) {
                CheckUtil.isEmptyWithEx(platform, ExMsgConstants.RECEIVE_NULL_PARA + "(运营平台)");
                if ("".equals(ContractOperatePlatformEnum.getName(platform))) {
                    throw ExceptionUtil.enumNotExist("运营平台");
                }
            }
            Integer sequence = entity.getFcmGiveSequence();
            CheckUtil.isEmptyWithEx(sequence, ExMsgConstants.RECEIVE_NULL_PARA + "(赠送顺序)");
            if ("".equals(ContractGiveSequenceEnum.getName(sequence))) {
                throw ExceptionUtil.enumNotExist("赠送顺序");
            }
        }

        //续租, 特殊字段
        if (ContractTypeEnum.LEASE_RENEWAL.getType().equals(contractType)) {
            Long associateContractId = entity.getFcmAssociateContractId();
            String associateContractNo = entity.getFcmAssociateContractNo();
            CheckUtil.isEmptyWithEx(associateContractId, ExMsgConstants.RECEIVE_NULL_PARA + "(关联合同id)");
            CheckUtil.isEmptyWithEx(associateContractNo, ExMsgConstants.RECEIVE_NULL_PARA + "(关联合同号)");

            FncContractManagement contract = fncContractManagementService.getById(associateContractId);
            if (contract == null || BaseConstants.DR_YES.equals(contract.getDr())) {
                throw ExceptionUtil.idNotExist(associateContractId);
            }
            if (!contract.getFcmContractNo().equals(associateContractNo)) {
                throw new GlobalException("数据异常, 关联合同id和关联合同号未对应上");
            }
        }

        //城市id
        List<AuthCity> cityList = authCityClient.getCityByIds(cityId + "").getDataWithEx();
        if (cityList == null || cityList.isEmpty()) {
            throw ExceptionUtil.notExist("城市id", cityId);
        }
        //合同类型枚举
        String contractTypeName = ContractTypeEnum.getText(contractType);
        if (contractTypeName == null) {
            throw ExceptionUtil.enumNotExist("合同类型");
        }
        //合同号重复
        List<FncContractManagement> contractFromDb = fncContractManagementService.getByCode(contractNo);
        if (contractFromDb != null && !contractFromDb.isEmpty()) {
            throw ExceptionUtil.duplicate("合同号", contractNo);
        }
        //甲乙方合同类型
        String partyaTypeName = ContractPartyTypeEnum.getName(partyaType);
        String partybTypeName = ContractPartyTypeEnum.getName(partybType);
        if ("".equals(partyaTypeName) || "".equals(partybTypeName)) {
            throw ExceptionUtil.enumNotExist("甲方或乙方的类型");
        }
        //甲/乙方id
        if (ContractPartyTypeEnum.PERSONAL.getValue().equals(partyaType)) {
            MrkMember member = memberClient.findByid(partyaId).getDataWithEx();
            if (member == null) {
                throw ExceptionUtil.notExist("甲方id", partyaId);
            }
        } else {
            AuthDept dept = authDeptClient.getAuthDeptById(partyaId).getDataWithEx();
            if (dept == null) {
                throw ExceptionUtil.notExist("甲方id", partyaId);
            }
        }
        if (ContractPartyTypeEnum.PERSONAL.getValue().equals(partybType)) {
            MrkMember member = memberClient.findByid(partybId).getDataWithEx();
            if (member == null) {
                throw ExceptionUtil.notExist("乙方id", partybId);
            }
        } else {
            AuthDept dept = authDeptClient.getAuthDeptById(partybId).getDataWithEx();
            if (dept == null) {
                throw ExceptionUtil.notExist("乙方id", partybId);
            }
        }
        //车辆数
        if (carnumTotal <= 0) {
            throw new GlobalException("数据异常, 车辆总数不能小于等于0");
        }
        //租期/租金相关
        if (leaseCount <= 0) {
            throw new GlobalException("数据异常, 租期不能小于等于0");
        }
        //起始/结束日期
        if (ContractLeaseStartTypeEnum.DELIVERY_DATE.getValue().equals(leaseStartType)) {
            //起始类型为"交车日期", 账单生成日期不能为"租赁开始前"
            if (BillDateTypeEnum.BEFORE.getValue().equals(billGenerateType)) {
                throw new GlobalException("操作失败, 起始类型为[交车日期], 账单生成日期不能为[租赁开始前]");
            }
        } else if (ContractLeaseStartTypeEnum.IDENTIFIED_DATE.getValue().equals(leaseStartType)) {
            CheckUtil.isEmptyWithEx(leaseStartDate, ExMsgConstants.RECEIVE_NULL_PARA + "起始日期");
            CheckUtil.isEmptyWithEx(leaseEndDate, ExMsgConstants.RECEIVE_NULL_PARA + "结束日期");
        } else {
            throw ExceptionUtil.enumNotExist("租赁起始类型");
        }
        //租金支付周期类型
        if ("".equals(ContractRentPayTypeEnum.getName(rentPayType))) {
            throw ExceptionUtil.enumNotExist("租金支付周期类型");
        }
        //租金支付周期
        if (null == ContractRentPaymentCycleEnum.getText(rentPayCycle)) {
            throw ExceptionUtil.enumNotExist("租金支付周期");
        }
        //租金总额
        if (leaseAmountTotal != null && leaseAmountTotal <= 0) {
            throw new GlobalException("数据异常, 租金总额不能小于等于0");
        }
        //单车保证金
        if (singleMargin <= 0) {
            throw new GlobalException("数据异常, 单车保证金不能小于等于0");
        }
        //保证金总额
        if (marginTotal <= 0) {
            throw new GlobalException("数据异常, 保证金总额不能小于等于0");
        }
        //保证金支付要求类型
        if ("".equals(ContractMarginPayRequireEnum.getName(marginPayRequire))) {
            throw ExceptionUtil.enumNotExist("保证金支付要求");
        }
        //购车尾款
        if (fcmCarPurchase != null && fcmCarPurchase <= 0) {
            throw new GlobalException("数据异常, 车辆购买尾款不能小于等于0");
        }
        //保底租金
        if (boldRent != null && boldRent <= 0) {
            throw new GlobalException("数据异常, 保底租金不能小于等于0");
        }
        //提前购车计价方式
        if (carPurchaseAdvance != null && "".equals(carPurchaseAdvance.trim())) {
            throw new GlobalException("数据异常, 提前购车计价方式不能为空");
        }
        //固定/不固定租金
        if (ContractLeaseTypeEnum.FIXED.getValue().equals(leaseType)) {
            CheckUtil.isEmptyWithEx(leaseAmount, "数据异常, [固定]情况下金额不能为空");
            if (leaseAmount <= 0) {
                throw new GlobalException("数据异常, 金额不能小于等于0");
            }
        } else if (ContractLeaseTypeEnum.NOT_FIXED.getValue().equals(leaseType)) {
            if (rents == null || rents.isEmpty()) {
                throw new GlobalException(ExMsgConstants.RECEIVE_NULL_PARA + "(不固定情况下, 需添加合同租金)");
            }
            for (FncContractRent rent : rents) {
                Integer startMonth = rent.getFccStartMonth();
                Integer endMonth = rent.getFccEndMonth();
                CheckUtil.isEmptyWithEx(startMonth, ExMsgConstants.RECEIVE_NULL_PARA + "(租金起始月)");
                CheckUtil.isEmptyWithEx(endMonth, ExMsgConstants.RECEIVE_NULL_PARA + "(租金结束月)");
                if (startMonth < DateConstants.MIN_MONTH/* || startMonth > DateConstants.MAX_MONTH*/) {
                    throw new GlobalException("数据异常, 租金的起始月不能小于等于0");
                }
                if (endMonth < DateConstants.MIN_MONTH/* || endMonth > DateConstants.MAX_MONTH*/) {
                    throw new GlobalException("数据异常, 租金的结束月不能小于等于0");
                }
            }
        } else {
            throw ExceptionUtil.enumNotExist("租金类型");
        }
        //车型
        Set<Long> carmodelSet = new HashSet<>();
        for (FncContractCarmodel carmodel : carmodels) {
            Integer carNum = carmodel.getFccCarnum();
            Long carmodelId = carmodel.getFccContractCarmodelId();
            CheckUtil.isEmptyWithEx(carNum, ExMsgConstants.RECEIVE_NULL_PARA + "(车型的数量)");
            CheckUtil.isEmptyWithEx(carmodelId, ExMsgConstants.RECEIVE_NULL_PARA + "(车型id)");
            if (carNum <= 0) {
                throw new GlobalException("数据异常, 车型的数量不能小于等于0");
            }
            SysCarType carType = sysCarTypeClient.getById(carmodelId).getDataWithEx();
            if (carType == null) {
                throw new GlobalException("数据异常, 车型id不存在");
            }
            carmodelSet.add(carmodel.getFccContractCarmodelId());
        }
        //限制同一车型不重复
        if (carmodelSet.size() < carmodels.size()) {
            throw new GlobalException("操作失败, 车型不能重复添加");
        }
        //租金包含费用
        if (rentalFees != null && !rentalFees.isEmpty()) {
            for (FncRentalFeesDto rentalFee : rentalFees) {
                CheckUtil.isEmptyWithEx(rentalFee.getFrfId(), ExMsgConstants.RECEIVE_NULL_PARA + "(包含费用-id)");
                CheckUtil.isEmptyWithEx(rentalFee.getFrfWrite(), ExMsgConstants.RECEIVE_NULL_PARA + "(包含费用-是否可填)");
                CheckUtil.isEmptyWithEx(rentalFee.getFrfName(), ExMsgConstants.RECEIVE_NULL_PARA + "(包含费用-名称)");
                if (BaseConstants.STATUS_ENABLE.equals(rentalFee.getFrfWrite())) {
                    CheckUtil.isEmptyWithEx(rentalFee.getFrfValue(), ExMsgConstants.RECEIVE_NULL_PARA + "(包含费用-值)");
                    if (new BigDecimal(rentalFee.getFrfValue()).compareTo(BigDecimal.ZERO) <= 0.0) {
                        throw new GlobalException("数据异常, 租金包含费用不能小于等于0");
                    }
                }
            }
        }
        //开始结束范围合法
        if (leaseStartDate != null && leaseEndDate != null && leaseStartDate.after(leaseEndDate)) {
            throw new GlobalException("数据异常, 合同的租赁[起始日期]必须小于[结束日期]");
        }
        //账单生成日类型
        if ("".equals(BillDateTypeEnum.getName(billGenerateType))) {
            throw ExceptionUtil.enumNotExist("账单生成日类型");
        }
        //账单截止日类型
        if ("".equals(BillDateTypeEnum.getName(billCatOffType))) {
            throw ExceptionUtil.enumNotExist("账单截止日类型");
        }
        //甲乙方不能相同
        if (ContractPartyTypeEnum.ORGANIZATION.getValue().equals(partyaType)
                && ContractPartyTypeEnum.ORGANIZATION.getValue().equals(partybType)
                && partyaId.equals(partybId)) {
            throw new GlobalException("操作失败, 甲乙方不能选择同一个对象");
        }
        if (ContractPartyTypeEnum.PERSONAL.getValue().equals(partyaType)
                && ContractPartyTypeEnum.PERSONAL.getValue().equals(partybType)
                && partyaId.equals(partybId)) {
            throw new GlobalException("操作失败, 甲乙方不能选择同一个对象");
        }
    }

    /**
     * 账单生成/截止字段判断
     *
     * @author Frank.Tang
     */
    private void checkInterval(ContractAddOrUpdateVo entity) {
        String err = "操作失败, 账单生成日不能晚于账单截止日";
        Integer generateInterval = entity.getFcmBillGenerateInterval();
        Integer generateType = entity.getFcmBillGenerateType();
        Integer catoffInterval = entity.getFcmBillCatoffInterval();
        Integer catoffType = entity.getFcmBillCatoffType();
        CheckUtil.isEmptyWithEx(generateType, "数据异常, 账单生成日类型不能为空");
        CheckUtil.isEmptyWithEx(catoffType, "数据异常, 账单截止日类型不能为空");

        //同为开始当天, 跳过
        if (BillDateTypeEnum.NOW.getValue().equals(generateType) && BillDateTypeEnum.NOW.getValue().equals(catoffType)) {
            return;
        }

        //越级
        if (generateType > catoffType) {
            throw new GlobalException(err);
        }
        //同级
        else if (generateType.equals(catoffType)) {
            if (BillDateTypeEnum.BEFORE.getValue().equals(generateType)) {
                if (generateInterval < catoffInterval) {
                    throw new GlobalException(err);
                }
            } else {
                if (generateInterval > catoffInterval) {
                    throw new GlobalException(err);
                }
            }
        }
    }

    /**
     * 更新合同校验:
     * (1)判断关联数据需要更新还是新增(删除暂不支持)
     * (2)数据正确性
     *
     * @return 待处理的dto, 包含需要更新或新增的数据
     * @author Frank.Tang
     */
    private ContractUpdateDto checkUpdate(ContractAddOrUpdateVo entity) {
        CheckUtil.isEmptyWithEx(entity, ExMsgConstants.RECEIVE_NULL_PARA);

        Long fcmId = entity.getFcmId();
        CheckUtil.isEmptyWithEx(fcmId, ExMsgConstants.RECEIVE_NULL_PARA + "(合同id)");

        //开始/截止字段校验
        checkInterval(entity);

        //数据库中的实体类
        FncContractManagement contractFromDb = fncContractManagementService.getById(fcmId);

        List<FncContractCarmodel> carmodels = entity.getCarmodels();
        List<FncRentalFeesDto> rentalFees = entity.getRentalFees();

        //这里统计需要更新/新增的数据
        List<FncContractCarmodel> tobeAddCarmodels = new ArrayList<>();
        List<FncContractCarmodel> tobeUpdateCarmodels = new ArrayList<>();

        //(1)
        //1.1 接收到车型数据, 判断需要新增还是修改
        if (carmodels != null && !carmodels.isEmpty()) {
            for (FncContractCarmodel carmodel : carmodels) {
                //关联合同id不做更新
                carmodel.setFccContractId(null);

                //更新
                if (CAR_MODEL_UPDATE.equals(carmodel.getRemark())) {
                    CheckUtil.isEmptyWithEx(carmodel.getFccId(), ExMsgConstants.RECEIVE_NULL_PARA + "-车型id");
                    carmodel.setRemark(null);
                    tobeUpdateCarmodels.add(carmodel);
                }
                //新增
                else if (CAR_MODEL_ADD.equals(carmodel.getRemark())) {
                    CheckUtil.isEmptyWithEx(carmodel.getFccCarnum(), ExMsgConstants.RECEIVE_NULL_PARA + "-车型数量");
                    CheckUtil.isEmptyWithEx(carmodel.getFccContractCarmodelId(), ExMsgConstants.RECEIVE_NULL_PARA);
                    carmodel.setRemark(null);
                    carmodel.setFccContractId(fcmId);
                    tobeAddCarmodels.add(carmodel);
                }
                //未接收到标识
                else {
                    throw new GlobalException("未接收到正确的车型标识");
                }
            }
        }

        //(2)
        //2.1 合同号
        String contractNo = entity.getFcmContractNo();
        if (contractNo != null && !contractNo.equals(contractFromDb.getFcmContractNo())) {
            List<FncContractManagement> contractsFromDb = fncContractManagementService.getByCode(contractNo);
            if (!contractsFromDb.isEmpty()) {
                throw new GlobalException("操作失败, 该合同号已存在");
            }
        }

        //长度
        String carPurchaseAdvance = entity.getFcmCarPurchaseAdvance();
        if (contractNo != null && contractNo.length() > LenConstants.LEN_255) {
            throw ExceptionUtil.outLen("合同号");
        }
        if (carPurchaseAdvance != null && carPurchaseAdvance.length() > LenConstants.LEN_2550) {
            throw ExceptionUtil.outLen("提前购车价计算方式");
        }

        //固定,不固定金额
        Double leaseAmount = entity.getFcmLeaseAmount();
        Integer leaseType = entity.getFcmLeaseType();
        if (leaseType == null) {
            throw new GlobalException("数据异常, 租赁类型(固定/不固定)不能为空");
        }
        if (leaseAmount == null && ContractLeaseTypeEnum.FIXED.getValue().equals(leaseType)) {
            throw new GlobalException("数据异常, 租金总额不能为空");
        }
        if (leaseAmount != null && leaseAmount < 0.0) {
            throw new GlobalException("数据异常, 租金总额不能小于等于0");
        }

        //初始化更新集合
        ContractUpdateDto dto = new ContractUpdateDto();
        dto.setTobeAddCarmodels(tobeAddCarmodels);
        dto.setTobeUpdateCarmodels(tobeUpdateCarmodels);
        dto.setRentalFees(rentalFees);
        entity.setFcmContractState(contractFromDb.getFcmContractState());
        return dto;
    }

    /**
     * 删除校验:
     * (1)数据存在  (2)状态满足
     * (3)租赁中合同删除, 所有账单需要未支付
     *
     * @author Frank.Tang
     */
    private FncContractManagement checkDel(Long fcmId) {
        CheckUtil.isEmptyWithEx(fcmId, ExMsgConstants.RECEIVE_NULL_ID);

        //(1)
        FncContractManagement contract = fncContractManagementService.getById(fcmId);
        if (contract == null || BaseConstants.DR_YES.equals(contract.getDr())) {
            throw ExceptionUtil.idNotExist(fcmId);
        }

        //(2)
        Integer contractState = contract.getFcmContractState();
        if (!ContractStateEnum.LEASE_TO_START.getState().equals(contractState)
                && !ContractStateEnum.LEASED.getState().equals(contractState)) {
            throw new GlobalException("操作失败, 只有【租赁待开始】或【租赁中】的合同才能删除");
        }

        //(3)
        if (ContractStateEnum.LEASED.getState().equals(contractState)) {
            FncBillManagementQueryVo queryVo = new FncBillManagementQueryVo();
            queryVo.setFbmAssociateContractIdEqualTo(fcmId);
            List<FncBillManagement> bills = fncBillManagementService.list(queryVo);
            for (FncBillManagement bill : bills) {
                if (bill.getFbmMatchedAmount() > 0.0) {
                    throw new GlobalException(String.format(
                            "操作失败, 该合同关联的账单存在支付记录（不满足的账单id[%s]）",
                            bill.getFbmId()));
                }
            }
        }

        return contract;
    }

    /**
     * 计算 [固定/不固定] 租金, 校验方法
     *
     * @author Frank.Tang
     */
    private void checkCalRentTotal(RentCalculationDto dto) {
        CheckUtil.isEmptyWithEx(dto, ExMsgConstants.RECEIVE_NULL_ENTITY);
        CheckUtil.isEmptyWithEx(dto.getFcmLeaseCount(), ExMsgConstants.RECEIVE_NULL_ENTITY + "-租期");

        //不固定, 才校验VariableRentDto
        if (dto.getFcmLeaseAmount() == null) {
            List<RentCalculationDto.VariableRentDto> rentDtoList = dto.getVariableRentDtoList();
            if (rentDtoList == null || rentDtoList.isEmpty()) {
                throw new GlobalException(ExMsgConstants.RECEIVE_NULL_PARA);
            }

            //空校验, 范围校验
            for (RentCalculationDto.VariableRentDto rentDto : rentDtoList) {
                Integer startMonth = rentDto.getFccStartMonth();
                Integer endMonth = rentDto.getFccEndMonth();
                Double rentAmount = rentDto.getFccRentAmount();
                CheckUtil.isEmptyWithEx(startMonth, ExMsgConstants.RECEIVE_NULL_PARA + "(开始月)");
                CheckUtil.isEmptyWithEx(endMonth, ExMsgConstants.RECEIVE_NULL_PARA + "(结束月)");
                CheckUtil.isEmptyWithEx(rentAmount, ExMsgConstants.RECEIVE_NULL_PARA + "(租金)");
                if (startMonth <= 0) {
                    throw new GlobalException("数据异常, 不固定租金开始月不能小于等于0");
                }
                if (endMonth <= 0) {
                    throw new GlobalException("数据异常, 不固定租金结束月不能小于等于0");
                }
                if (rentAmount <= 0.0) {
                    throw new GlobalException("单个不固定租金不能小于等于0");
                }
            }

            //起始月排序, 默认按照这种顺序校验
            rentDtoList = rentDtoList.stream()
                    .sorted(Comparator.comparing(RentCalculationDto.VariableRentDto::getFccStartMonth))
                    .collect(Collectors.toList());
            //格式校验
            int min = 1;
            int max = dto.getFcmLeaseCount();
            String err = "操作失败, 不固定租金格式错误";
            for (int i = 0; i < rentDtoList.size(); i++) {
                //当前
                RentCalculationDto.VariableRentDto rentDtoNow = rentDtoList.get(i);
                //下一个
                RentCalculationDto.VariableRentDto rentDtoNxt =
                        (i == rentDtoList.size() - 1) ? (null) : (rentDtoList.get(i + 1));

                Integer startMonthNow = rentDtoNow.getFccStartMonth();
                Integer endMonthNow = rentDtoNow.getFccEndMonth();

                //第一个数据, 起始月必须为1
                if (i == 0 && startMonthNow != min) {
                    throw new GlobalException(err);
                }
                //最后一个数据, 结束月必须为"租期"
                if (i == rentDtoList.size() - 1 && endMonthNow != max) {
                    throw new GlobalException(err);
                }
                //首尾对应校验
                if (rentDtoNxt != null && !endMonthNow.equals(rentDtoNxt.getFccStartMonth() - 1)) {
                    throw new GlobalException(err);
                }
                //结算不能小于开始
                if (startMonthNow > endMonthNow) {
                    throw new GlobalException(err);
                }
            }
        }
    }


    /**
     * 根据逾期天数获取账单
     */
    public List<FncManagementRiskDto> getOverdue(Integer day) {
        List<ManagementRiskDto> overdue = fncContractManagementService.getOverdue(day);
        return ListUtil.copyBeanList(overdue,FncManagementRiskDto.class);
    }

    /**
     * 查询审批中或者执行中的合同
     * @param queryVo
     * @return
     */
    public PageInfo<FncContractManagement> leasePage(FncContractManagementQueryVo queryVo) {
        // 合同状态 且状态为“审批中”或“执行中”的合同
        List<Integer> contractList = new ArrayList<>();
        contractList.add(ContractStateEnum.LEASE_TO_START.getState());
        contractList.add(ContractStateEnum.LEASED.getState());
        queryVo.setFcmContractTypeList(contractList);
        PageUtils.startPage();
        List<FncContractManagement> fncContractManagements= fncContractManagementService.leasePage(queryVo);
        return new PageInfo<>(fncContractManagements);
    }
}

