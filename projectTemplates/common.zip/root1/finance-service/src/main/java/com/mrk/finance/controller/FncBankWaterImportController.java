package com.mrk.finance.controller;

import com.github.pagehelper.PageInfo;
import com.mrk.common.utils.page.JsonResult;
import com.mrk.finance.facade.bankwater.FncBankWaterImportFacade;
import com.mrk.finance.model.FncTemp;
import com.mrk.finance.queryvo.FncBankWaterQueryVo;
import com.mrk.finance.queryvo.FncTempQueryVo;
import com.mrk.finance.service.FncTempService;
import com.mrk.log.annotation.Log;
import com.mrk.log.enums.BusinessType;
import com.mrk.log.enums.OperatorType;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiImplicitParam;
import io.swagger.annotations.ApiImplicitParams;
import io.swagger.annotations.ApiOperation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import javax.servlet.http.HttpServletResponse;

/**
 * @project: mrk-finance
 * @author: Frank.Tang
 * @date: 2021-11-16 15:03
 * @desc:
 **/
@RestController
@RequestMapping("/financeservice/fncbankwater/import")
@Api(tags = "银行流水导入")
public class FncBankWaterImportController {
    @Autowired
    private FncTempService fncTempService;
    @Autowired
    private FncBankWaterImportFacade fncBankWaterImportFacade;


    @PostMapping(value = "/import_file")
    @ApiOperation("银行流水导入-导入文件")
    @ApiImplicitParams({
            @ApiImplicitParam(paramType = "header", name = "Authorization", value = "系统下发的token", required = true),
            @ApiImplicitParam(paramType = "body", name = "operateCode", value = "操作标识", required = true)
    })
    public JsonResult<Object> importFile(MultipartFile file, String operateCode) {
        fncBankWaterImportFacade.importFile(file, operateCode);
        return JsonResult.success();
    }

    @PostMapping(value = "/confirm_import")
    @ApiOperation("银行流水导入-确认导入")
    @ApiImplicitParams({
            @ApiImplicitParam(paramType = "header", name = "Authorization", value = "系统下发的token", required = true),
            @ApiImplicitParam(paramType = "query", name = "operateCode", value = "操作标识", required = true)
    })
    @Log(title = "银行流水导入", businessType = BusinessType.IMPORT, value = "银行流水导入-确认导入")
    public JsonResult<Object> confirmImport(String operateCode) {
        fncBankWaterImportFacade.confirmImport(operateCode);
        return JsonResult.success();
    }

    @GetMapping(value = "/schedule")
    @ApiOperation("银行流水导入-获取处理进度")
    @ApiImplicitParams({
            @ApiImplicitParam(paramType = "header", name = "Authorization", value = "系统下发的token", required = true),
            @ApiImplicitParam(paramType = "query", name = "operateCode", value = "操作标识", required = true)
    })
    public JsonResult<Object> schedule(@RequestParam("operateCode") String operateCode) {
        Integer schedule = fncBankWaterImportFacade.schedule(operateCode);
        return JsonResult.success(schedule);
    }

    @GetMapping(value = "/import_result")
    @ApiOperation("银行流水导入-获取上传结果")
    @ApiImplicitParams({
            @ApiImplicitParam(paramType = "header", name = "Authorization", value = "系统下发的token", required = true),
            @ApiImplicitParam(paramType = "query", name = "operateCode", value = "操作标识", required = true)
    })
    public JsonResult<Object> importResult(@RequestParam("operateCode") String operateCode) {
        Integer result = fncBankWaterImportFacade.importResult(operateCode);
        return JsonResult.success(result);
    }

    @GetMapping(value = "/down_file")
    @ApiOperation("银行流水导入-下载文件")
    @ApiImplicitParams({
            @ApiImplicitParam(paramType = "header", name = "Authorization", value = "系统下发的token", required = true),
            @ApiImplicitParam(paramType = "query", name = "operateCode", value = "操作标识", required = true)
    })
    public void downFile(String operateCode, HttpServletResponse response) {
        fncBankWaterImportFacade.downFile(operateCode, response);
    }

    @GetMapping(value = "/preview/page")
    @ApiOperation("银行流水导入-预览功能")
    @ApiImplicitParams({
            @ApiImplicitParam(paramType = "header", name = "Authorization", value = "系统下发的token", required = true),
            @ApiImplicitParam(paramType = "query", name = "operateCode", value = "操作标识", required = true)
    })
    public JsonResult<PageInfo<FncTemp>> previewData(FncTempQueryVo fncTempQueryVo) {
        return JsonResult.success(fncTempService.page(fncTempQueryVo));
    }

    @GetMapping(value = "/tt_template")
    @ApiOperation("银行流水导入-下载导入模板")
    @ApiImplicitParams({
            @ApiImplicitParam(paramType = "header", name = "Authorization", value = "系统下发的token", required = true)
    })
    public void ttTemplate(HttpServletResponse httpServletResponse) {
        fncBankWaterImportFacade.peepareTemplate(httpServletResponse);
    }


    @GetMapping(value = "/export")
    @ApiOperation("银行流水导入-按条件导出")
    @ApiImplicitParams({
            @ApiImplicitParam(paramType = "header", name = "Authorization", value = "系统下发的token", required = true)
    })
    @Log(title = "用车申请", businessType = BusinessType.EXPORT, operatorType = OperatorType.MANAGE, isSaveRequestData = true, value = "用车申请-导出")
    public void export(FncBankWaterQueryVo queryVo, HttpServletResponse response) {
        fncBankWaterImportFacade.export(queryVo, response);
    }
}
