package com.mrk.finance.facade.bill;

import com.alibaba.fastjson.JSON;
import com.mrk.applet.client.MaintainPushClient;
import com.mrk.applet.enums.PayObjectTypeEnum;
import com.mrk.common.exception.GlobalException;
import com.mrk.common.utils.text.CheckUtil;
import com.mrk.finance.model.FncBillManagement;
import com.mrk.finance.service.FncBillManagementService;
import com.mrk.member.client.MemberClient;
import com.mrk.member.model.MrkMember;
import com.mrk.resource.client.ResCarQueryClient;
import com.mrk.resource.model.ResCar;
import com.mrk.thirdparty.client.SmsClient;
import com.mrk.thirdparty.client.SmsRecordClient;
import com.mrk.thirdparty.enums.sms.SmsBizTypeEnum;
import com.mrk.thirdparty.enums.sms.SmsTypeEnum;
import com.mrk.thirdparty.model.MrkSmsRecord;
import com.mrk.universal.enums.contract.ContractPartyTypeEnum;
import com.mrk.universal.enums.turner.TurnerSingleOverTimeEnum;
import org.apache.commons.collections4.CollectionUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * @author Bob
 * @date 2021-11-23
 * @description
 */
@Component
public class BillManagementGenerateFacade {

    private static final Logger log = LoggerFactory.getLogger(BillManagementGenerateFacade.class);

    @Autowired
    private FncBillManagementService fncBillManagementService;

    @Autowired
    private SmsClient smsClient;

    @Autowired
    private MaintainPushClient maintainPushClient;

    @Autowired
    protected MemberClient memberClient;

    @Autowired
    protected SmsRecordClient smsRecordClient;

    @Autowired
    private ResCarQueryClient resCarQueryClient;

    /**
     * @author Bob
     * @date 2021/11/23
     * @description 查看账单是否已经存在
     *              不存在则新建并推送消息
     * @param fncBillManagement 账单
     * @param memberId 会员id
     */
    public void generateAndSend(FncBillManagement fncBillManagement, Long memberId, Integer type) {
        List<FncBillManagement> fncBillManagementList = fncBillManagementService.getByContractIdAndSubjectAndNper
                (fncBillManagement.getFbmAssociateContractId(), fncBillManagement.getFbmSubjects(), fncBillManagement.getFbmNper());
        // 新增 并 发送消息
        if (CollectionUtils.isEmpty(fncBillManagementList)) {
            //  新增
            fncBillManagement.setFbmTurnerDeal(TurnerSingleOverTimeEnum.NO.getState());
            fncBillManagementService.add(fncBillManagement);
            // 发送消息
            try {
                if (ContractPartyTypeEnum.PERSONAL.getValue().equals(type)) {
                    sendMsg(fncBillManagement, memberId);
                }
            } catch (Exception e) {
                log.info("创建账单 推送消息发生错误", e);
            }
        }
    }

    private void sendMsg(FncBillManagement fncBillManagement, Long memberId) {
        // 发送消息
        if(CheckUtil.isNotEmpty(fncBillManagement.getFbmAssociateCarId())){
            ResCar resCar = resCarQueryClient.findCarById(fncBillManagement.getFbmAssociateCarId()).getDataWithEx();
            if(CheckUtil.isEmpty(resCar)){
                throw new GlobalException("车辆数据异常");
            }
            MrkMember mrkMember = memberClient.findByid(memberId).getDataWithEx();
            if(CheckUtil.isNotEmpty(mrkMember)){

                Map<String,Object> paramMap=new HashMap<>();
                paramMap.put("mrkMemberName", mrkMember.getMmName());
                String param= JSON.toJSONString(paramMap);
                // 发送短信
                smsClient.templateSendType(mrkMember.getMmMobile(),"bill_have",
                  param,
                  4,null).getDataWithEx();
                MrkSmsRecord  mrkSmsRecord = new MrkSmsRecord();
                mrkSmsRecord.setMsrTitle("您有新的账单待支付");
                mrkSmsRecord.setMsrMobile(mrkMember.getMmMobile());
                mrkSmsRecord.setMsrStatus(2);
                mrkSmsRecord.setMsrType(Integer.parseInt(SmsTypeEnum.WECHART.getState().toString()));
                mrkSmsRecord.setMsrBizType(Integer.parseInt(SmsBizTypeEnum.MINIPROGROM.getState().toString()));
                //设置业务类型为    账单
                mrkSmsRecord.setMsrObjectType(PayObjectTypeEnum.CONTRACT_BILL.getValue());
                mrkSmsRecord.setMsrContent("您的车辆已产生账单，点击链接查看详细账单并完成支付！");
                mrkSmsRecord.setMsrObjectId(fncBillManagement.getFbmId());
                smsRecordClient.addSmsRecord(mrkSmsRecord).getDataWithEx();
                // 推送消息
                maintainPushClient.billPayPush(memberId, fncBillManagement.getFbmId(), resCar.getRcPlateNum(), fncBillManagement.getFbmBillAmount()).getDataWithEx();
            }
        }
    }
}
