package com.mrk.finance.controller;

import com.github.pagehelper.PageInfo;
import com.mrk.common.utils.page.JsonResult;
import com.mrk.finance.model.FncContractCarmodel;
import com.mrk.finance.queryvo.FncContractCarmodelQueryVo;
import com.mrk.finance.service.FncContractCarmodelService;
import com.mrk.log.annotation.Log;
import com.mrk.log.enums.BusinessType;
import com.mrk.log.enums.OperatorType;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiImplicitParam;
import io.swagger.annotations.ApiImplicitParams;
import io.swagger.annotations.ApiOperation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;


/**
 * FncContractCarmodelController

 */
@RestController
@RequestMapping("/financeservice/fnccontractcarmodel")
@Api(tags = "/合同车型")
public class FncContractCarmodelController {
    @Autowired
    private FncContractCarmodelService fncContractCarmodelService;

    @PostMapping(value = "/add")
    @ApiOperation("合同车型-新增")
    @ApiImplicitParams({
            @ApiImplicitParam(paramType = "header", name = "Authorization", value = "系统下发的token", required = true)
    })
    @Log(title = "合同车型", value = "新增", businessType = BusinessType.INSERT, operatorType = OperatorType.MANAGE)
    public JsonResult<Object>  add(FncContractCarmodel entity) {
        return JsonResult.success(fncContractCarmodelService.add(entity));
    }

    @PostMapping(value = "/del/{id}")
    @ApiOperation("合同车型-删除")
    @ApiImplicitParams({
            @ApiImplicitParam(paramType = "header", name = "Authorization", value = "系统下发的token", required = true)
    })
    @Log(title = "合同车型", value = "删除", businessType = BusinessType.DELETE, operatorType = OperatorType.MANAGE)
    public JsonResult<Object>  del(@PathVariable("id") Long id) {
        return JsonResult.success(fncContractCarmodelService.delete(id));
    }

    @PostMapping(value = "/update")
    @ApiOperation("合同车型-更新")
    @ApiImplicitParams({
            @ApiImplicitParam(paramType = "header", name = "Authorization", value = "系统下发的token", required = true)
    })
    @Log(title = "合同车型", value = "更新", businessType = BusinessType.UPDATE, operatorType = OperatorType.MANAGE)
    public JsonResult<Object>  update(FncContractCarmodel entity) {
        return JsonResult.success(fncContractCarmodelService.update(entity));
    }


    @GetMapping(value = "/page")
    @ApiOperation("合同车型-分页查询")
    @ApiImplicitParams({
            @ApiImplicitParam(paramType = "header", name = "Authorization", value = "系统下发的token", required = true)
    })
    public JsonResult<PageInfo<FncContractCarmodel>> page(FncContractCarmodelQueryVo queryVo) {
        return JsonResult.success(fncContractCarmodelService.page(queryVo));
    }

    @GetMapping(value = "/list")
    @ApiOperation("合同车型-列表查询")
    @ApiImplicitParams({
            @ApiImplicitParam(paramType = "header", name = "Authorization", value = "系统下发的token", required = true)
    })
    public JsonResult<List<FncContractCarmodel>> list(FncContractCarmodelQueryVo queryVo) {
        return JsonResult.success(fncContractCarmodelService.list(queryVo));
    }


}
