package com.mrk.finance.enums.newcontract;

import java.util.Objects;

/**
 * @author
 * @date
 * @description
 */
public enum NewContractTypeEnum {

    RENT_FOR_SALE(0, "租赁合同"),
    OPERATING_LEASE(1, "租售合同");

    private final Integer type;
    private final String text;

    NewContractTypeEnum(Integer type, String text) {
        this.type = type;
        this.text = text;
    }

    public Integer getType() {
        return type;
    }

    public String getText() {
        return text;
    }

    public static String getText(Integer type) {
        if (Objects.isNull(type)) return null;

        for (NewContractTypeEnum value : values()) {
            if (value.getType().equals(type)) {
                return value.getText();
            }
        }

        return null;
    }
}
