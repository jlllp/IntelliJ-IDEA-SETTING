package com.mrk.finance.remote;

import com.mrk.auth.client.AuthDeptClient;
import com.mrk.auth.model.AuthDept;
import com.mrk.common.utils.text.CheckUtil;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

/**
 * @author jlllp
 * @date 2022/6/16
 * @description
 */
@Component
public class AuthDeptRPC {

    @Autowired
    private AuthDeptClient authDeptClient;

    /**
     * 通过ID获取组织信息
     *
     * @param id 主键
     * @return 组织信息
     */
    public AuthDept getAuthDeptById(Long id) {
        CheckUtil.isEmptyWithEx(id, "主键不能为空");
        return authDeptClient.getAuthDeptById(id).getDataWithEx();
    }
}
