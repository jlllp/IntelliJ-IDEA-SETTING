package com.mrk.finance.dto;

import com.fasterxml.jackson.annotation.JsonFormat;
import io.swagger.annotations.ApiModelProperty;
import lombok.Getter;
import lombok.Setter;
import org.springframework.format.annotation.DateTimeFormat;

/**
 * mrk-finance
 *
 * @author : Sandy
 * @Description:
 * @Date 2022/3/29 17:37
 **/
@Setter
@Getter
public class FncManagementRiskDto {

    @ApiModelProperty(value = "组织")
    private Long fcmPartybId;

    @ApiModelProperty(value = "账单id")
    private Long fbmId;


    @DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss", timezone = "GMT+8")
    @ApiModelProperty(value = "账单截止时间")
    private java.util.Date fbmBillCatoffTime;

}
