package com.mrk.finance.util.contract;

import com.mrk.common.utils.text.CheckUtil;
import com.mrk.finance.dto.date.TimeRightDto;
import com.mrk.finance.enums.ContractRentPayTypeEnum;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.*;

/**
 * @author Bob
 * @date 2021-11-15
 * @description 合同日期计算
 */
public class ContractDateCalculateUtil {

    private static final Logger log = LoggerFactory.getLogger(ContractDateCalculateUtil.class);

    private ContractDateCalculateUtil() {

    }

    /**
     * @param startDate  开始时间
     * @param month      周期
     * @param periodType 周期类型 0自然周期 1相对周期
     * @param interval   间隔
     * @return 返回一个根据周期作为key，周期对应的开始时间和结算时间作为value的map
     * 注意 返回Map数量为0的时候说明计算错误
     * @author Bob
     * @date 2021/11/15
     * @description 计算合同周期类型
     */
    public static SortedMap<Integer, TimeRightDto> calculateThePaymentPeriod(Date startDate, Integer month, Integer periodType, Integer interval) {
        // 数据检查
        // 检查数据不能为空
        CheckUtil.isEmptyWithEx(startDate, "开始时间不能为空");
        CheckUtil.isEmptyWithEx(month, "月份总数不能为空");
        CheckUtil.isEmptyWithEx(periodType, "周期类型不能为空");
        CheckUtil.isEmptyWithEx(interval, "间隔不能为空");

        SortedMap<Integer, TimeRightDto> dtoTreeMap = new TreeMap<>(Integer::compare);
        Date formatStartDate = ignoreHoursMinutesAndSeconds(startDate);
        if (Objects.isNull(formatStartDate)) {
            return dtoTreeMap;
        }

        // 获取周期次数
        int count = getCycleCount(month, interval);

        // 自然周期处理
        if (ContractRentPayTypeEnum.NATURAL.getValue().equals(periodType)) {
            naturalCycleCalculation(month, interval, dtoTreeMap, formatStartDate, count);
        }
        // 相对周期处理
        else if (ContractRentPayTypeEnum.RELATIVE.getValue().equals(periodType)) {
            relativePeriodCalculation(month, interval, dtoTreeMap, formatStartDate, count);
        }
        // 参数不合法 不参与计算
        else {
            log.info("合同日期计算 周期类型错误 --> periodType：【{}】", periodType);
        }

        return dtoTreeMap;
    }

    /**
     * @param date 待转换的日期
     * @return 抹掉时分秒的日期
     * @author Bob
     * @date 2021/11/15
     * @description 转换日期 抹掉时分秒
     */
    public static Date ignoreHoursMinutesAndSeconds(Date date) {
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
        // 把带时分秒的 date 转为 yyyy-MM-dd 格式的字符串
        String dateStr = sdf.format(date);
        try {
            // 把字符串解析为日期类型
            return sdf.parse(dateStr);
        } catch (ParseException e) {
            log.warn("解析日期失败 --> dateStr：【{}】", dateStr);
        }
        return date;
    }

    /**
     * @param date 待转换的日期
     * @return 抹掉日时分秒的日期
     * @author Bob
     * @date 2021/11/15
     * @description 转换日期 抹掉日时分秒
     */
    public static Date getYearMonth(Date date) {
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM");
        // 把带时分秒的 date 转为 yyyy-MM 格式的字符串
        String dateStr = sdf.format(date);
        try {
            // 把字符串解析为日期类型
            return sdf.parse(dateStr);
        } catch (ParseException e) {
            log.warn("解析日期失败 --> dateStr：【{}】", dateStr);
        }
        return date;
    }

    /**
     * @param date 指定日期
     * @return 当前日期对应月份的最后一天
     * @author Bob
     * @date 2021/11/15
     * @description 获取指定日期的月份最后一天
     */
    public static Date getLastDayOfMonth(Date date) {
        Calendar instance = Calendar.getInstance();
        instance.setTime(date);
        int lastDay = instance.getActualMaximum(Calendar.DAY_OF_MONTH);
        instance.set(Calendar.DAY_OF_MONTH, lastDay);
        return instance.getTime();
    }

    /**
     * @param date 指定日期
     * @return 当前日期对应月份的第一天
     * @author Bob
     * @date 2021/11/15
     * @description 获取指定日期的月份第一天
     */
    public static Date getFirstDayOfMonth(Date date) {
        Calendar instance = Calendar.getInstance();
        instance.setTime(date);
        int lastDay = instance.getActualMinimum(Calendar.DAY_OF_MONTH);
        instance.set(Calendar.DAY_OF_MONTH, lastDay);
        return instance.getTime();
    }

    /**
     * @param date   指定日期
     * @param amount 月份数量
     * @return 增减完月份的日期
     * @author Bob
     * @date 2021/11/15
     * @description 根据指定日期增加月份 正数为增加  负数为减去
     */
    public static Date increaseMonth(Date date, Integer amount) {
        // 如果数量为空 为了不报空指针返回请求的日期
        if (Objects.isNull(amount)) {
            return date;
        }
        Calendar instance = Calendar.getInstance();
        instance.setTime(date);
        instance.add(Calendar.MONTH, amount);
        return instance.getTime();
    }

    /**
     * @param date   指定日期
     * @param amount 正数增加天数 负数减少天数
     * @return 增减完天数的日期
     * @author Bob
     * @date 2021/11/15
     * @description 在指定日期上增减天数
     */
    public static Date increaseDay(Date date, Integer amount) {
        // 如果数量为空 为了不报空指针返回请求的日期
        if (Objects.isNull(amount)) {
            return date;
        }
        Calendar instance = Calendar.getInstance();
        instance.setTime(date);
        instance.add(Calendar.DAY_OF_MONTH, amount);
        return instance.getTime();
    }

    /**
     * @author Bob
     * @date 2021/11/22
     * @description 获取指定日期最后一天对应的数字
     *              等效于 这个月的总天数
     * @param date 日期
     * @return 指定日期最后一天对应的数字
     */
    public static int getActualMaximum(Date date){
        Calendar instance = Calendar.getInstance();
        instance.setTime(date);
        return instance.getActualMaximum(Calendar.DAY_OF_MONTH);
    }

    /**
     * @author Bob
     * @date 2021/11/22
     * @description 获取今天是这个月的第几天
     * @param date 日期
     * @return 今天是这个月的第几天
     */
    public static int getDayByMonth(Date date) {
        Calendar instance = Calendar.getInstance();
        instance.setTime(date);
        return instance.get(Calendar.DATE);
    }

    /**
     * 计算两个日期之间相差的天数
     * 注意 不包含 较小的时间 当天
     * 需要包含自行处理
     * @param startDate 较小的时间
     * @param endDate  较大的时间
     * @return 相差天数
     */
    public static int daysBetween(Date startDate, Date endDate) {
        try {
            SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
            startDate = sdf.parse(sdf.format(startDate));
            endDate = sdf.parse(sdf.format(endDate));
            Calendar cal = Calendar.getInstance();
            cal.setTime(startDate);
            long time1 = cal.getTimeInMillis();
            cal.setTime(endDate);
            long time2 = cal.getTimeInMillis();
            long betweenDays = (time2 - time1) / (1000 * 3600 * 24);
            return (int) betweenDays;
        } catch (ParseException e) {
            log.warn("计算两个日期之间相差的天数错误 返回0", e);
            return 0;
        }
    }

    /**
     * @author Bob
     * @date 2021/11/29
     * @description 格式化日期
     * @param dateStr 日期字符串
     * @return 日期
     */
    public static Date formatDay(String dateStr) {
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
        // 把带时分秒的 date 转为 yyyy-MM-dd 格式的字符串
        try {
            // 把字符串解析为日期类型
            return sdf.parse(dateStr);
        } catch (ParseException e) {
            log.warn("解析日期失败 --> dateStr：【{}】", dateStr);
        }
        return null;
    }

    /**
     * @author Bob
     * @date 2021/11/16
     * @description 相对周期计算周期
     * @param month 月份
     * @param interval 间隔
     * @param dtoTreeMap 周期存储map
     * @param formatStartDate 格式化的起点日期
     * @param count 总期数
     */
    private static void relativePeriodCalculation(Integer month, Integer interval, SortedMap<Integer, TimeRightDto> dtoTreeMap, Date formatStartDate, int count) {
        // 起始日期
        //      第一期：
        //          租赁起始时间就是起始日期
        //     非第一期：
        //          租赁起始日期 + 期数 * 间隔
        // 结束日期
        //      统一：
        //          起始日期 + 间隔
        //          特俗情况：剩余的周期不足一个间隔，使用月份模间隔即可获取到最后一个走起的月份

        for (int i = 1; i <= count; i++) {

            // 第一期特殊处理
            if (i == 1) {
                // 获取结束月
                Date endMonth = getRelativeEndMonth(i, interval, month, formatStartDate);
                // 结束月份 - 1天即为结束日期
                Date endDate = increaseDay(endMonth, -1);
                dtoTreeMap.put(i, new TimeRightDto(formatStartDate, endDate));
            }
            // 非第一期
            else {
                // 获取起始月
                Date startMonth = increaseMonth(formatStartDate, (i - 1) * interval);
                // 获取结束月
                Date endMonth = getRelativeEndMonth(i, interval, month, startMonth);
                // 结束日期 = 结束月份 - 1天
                Date endDate = increaseDay(endMonth, -1);
                // 相对周期只需要增加月份即可，不需要对日期进行计算
                // 即 起始月 = 起始日期
                dtoTreeMap.put(i, new TimeRightDto(startMonth, endDate));
            }
        }
    }

    /**
     * @author Bob
     * @date 2021/11/16
     * @description 自然周期计算周期
     * @param month 月份
     * @param interval 间隔
     * @param dtoTreeMap 周期存储map
     * @param formatStartDate 格式化的起点日期
     * @param count 总期数
     */
    private static void naturalCycleCalculation(Integer month, Integer interval, SortedMap<Integer, TimeRightDto> dtoTreeMap, Date formatStartDate, int count) {
        // 自然周期月份计算规则
        // 起始月 = 当前月 + 周期
        // 结束月 = 起始月 + 周期 - 1
        //          PS = 第一个月的其实月就是起始日期的月份  直接使用即可
        // 周期开始日期 = 拿到起始月后除开始日期外获取当月的第一天 开始日期取开始日期当天即可
        // 周期结束日期 = 拿到结束月后获取当前月份的最后一天即可
        // 注意 周期结束月在最后一个周期的时候 要考虑剩余周期不满足间隔的问题

        // 根据周期计算时间间隔
        for (int i = 1; i <= count; i++) {
            // 第一个周期
            if (i == 1) {
                // 获取周期结束时间
                // 当前日期加上周期 -1
                // -1 因为自然周期结束时间为指定月最后一天。
                // 当开始日期 + 周期间隔 = 结束日期  这里的结束日期自然会到下一个月
                // 举例：
                //      ①开始日期:1/1 + 周期间隔:3 = 4/1
                //      ②开始日期:2/5 + 周期间隔:6 = 8/1
                //      实际想要的值 ①3/31 ②7月31号
                // 故：可以使用周期间隔 -1的方式获取到上个月月份
                //     在获取上月月份的最后一天
                //  这样就获取到自然周期结束日期了

                // 获取结束月
                Date endMonth = getNaturalEndMonth(month, interval, formatStartDate, i);
                // 获取此月份最后一天
                Date endDate = getLastDayOfMonth(endMonth);
                // 添加到Map中
                dtoTreeMap.put(i, new TimeRightDto(formatStartDate, endDate));
            }
            // 其他周期
            else {
                // 获取起始月
                Date startMonth = increaseMonth(formatStartDate, (i - 1) * interval);
                // 获取结束月
                Date endMonth = getNaturalEndMonth(month, interval, startMonth, i);
                // 获取起始日期
                Date firstDayOfMonth = getFirstDayOfMonth(startMonth);
                // 获取结束日期
                Date lastDayOfMonth = getLastDayOfMonth(endMonth);
                // 添加到Map中
                dtoTreeMap.put(i, new TimeRightDto(firstDayOfMonth, lastDayOfMonth));
            }
        }
    }

    /**
     * @param month    月份
     * @param interval 间隔
     * @return 执行周期
     * @author Bob
     * @date 2021/11/15
     * @description 根据月份和间隔获取执行周期
     */
    private static int getCycleCount(Integer month, Integer interval) {
        int count;
        if (month % interval == 0) {
            count = month / interval;
        } else {
            count = month / interval + 1;
        }
        return count;
    }

    /**
     * @author Bob
     * @date 2021/11/16
     * @description 相对周期获取结束月份
     * @param i 第几期
     * @param interval 间隔
     * @param month 总月份
     * @param startMonth 开始月份
     * @return 结束月份
     */
    private static Date getRelativeEndMonth(int i, Integer interval, Integer month, Date startMonth) {
        // 获取结束月
        Date endMonth;
        // 剩余周期不满足间隔
        // 期数 * 间隔 > 总月份
        // 此情况需要去除多余的月份
        // 获取到实际的月份
        // 通过取模即可获取到剩余实际的月份数
        if (i * interval > month) {
            endMonth = increaseMonth(startMonth, month % interval);
        } else {
            endMonth = increaseMonth(startMonth, interval);
        }
        return endMonth;
    }

    /**
     * @author Bob
     * @date 2021/11/16
     * @description 自然周期获取结束月份
     * @param month 总月份
     * @param interval 间隔
     * @param startMonth 开始月份
     * @param i 第几期
     * @return 结束月份
     */
    private static Date getNaturalEndMonth(Integer month, Integer interval, Date startMonth, int i) {
        Date endMonth;
        // 剩余周期不满足间隔
        // 期数 * 间隔 > 总月份
        // 此情况需要去除多余的月份
        // 获取到实际的月份
        // 通过取模即可获取到剩余实际的月份数
        if (i * interval > month) {
            endMonth = increaseMonth(startMonth, month % interval - 1);
        } else {
            endMonth = increaseMonth(startMonth, interval - 1);
        }
        return endMonth;
    }

    /**
     * 日期往后推n个月
     * @author Frank.Tang
     * @param date 待处理的日期
     * @param n 往后推几个月
     * @return *
     */
    public static Date getFewMonthLaterDate(Date date, int n) {
        Calendar calendar = Calendar.getInstance();
        calendar.setTime(date);
        calendar.add(Calendar.MONTH, n);
        return calendar.getTime();
    }
}
