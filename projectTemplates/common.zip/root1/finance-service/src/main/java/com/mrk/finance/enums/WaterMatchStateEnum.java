package com.mrk.finance.enums;

import lombok.Getter;

/**
 * @project: mrk-finance
 * @author: Frank.Tang
 * @date: 2021-11-12 16:26
 * @desc:
 **/
@Getter
public enum WaterMatchStateEnum {

    /***/
    NOT_MATCH(0, "未匹配"),
    PART_MATCH(1, "部分匹配"),
    ALL_MATCH(2, "已匹配");

    private Integer value;
    private String name;

    WaterMatchStateEnum(Integer value, String name) {
        this.value = value;
        this.name = name;
    }

    public static String getName(Integer state) {
        if (state == null) {
            return "";
        }
        for (WaterMatchStateEnum statusEnum : values()) {
            if (statusEnum.getValue().equals(state)) {
                return statusEnum.getName();
            }
        }
        return "";
    }

}
