package com.mrk.finance.remote;

import com.mrk.common.utils.text.CheckUtil;
import com.mrk.sys.client.SysCarTypeClient;
import com.mrk.sys.model.SysCarType;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

/**
 * @author jlllp
 * @date 2022/6/16
 * @description
 */
@Component
public class SysCarTypeRPC {

    @Autowired
    private SysCarTypeClient sysCarTypeClient;

    /**
     * 通过主键获取车型
     *
     * @param id 主键
     * @return 车型
     */
    public SysCarType getById(Long id) {
        CheckUtil.isEmptyWithEx(id, "主键不能为空");
        return sysCarTypeClient.getById(id).getDataWithEx();
    }
}
