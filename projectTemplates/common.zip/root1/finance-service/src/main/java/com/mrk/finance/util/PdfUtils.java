package com.mrk.finance.util;

import com.mrk.common.exception.GlobalException;
import fr.opensagres.poi.xwpf.converter.pdf.PdfConverter;
import fr.opensagres.poi.xwpf.converter.pdf.PdfOptions;
import org.apache.poi.xwpf.usermodel.XWPFDocument;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.IOException;
import java.io.OutputStream;

/**
 * @author Bob
 * @date 2022/6/8
 * @description
 */
public class PdfUtils {

    private static final Logger log = LoggerFactory.getLogger(PdfUtils.class);

    private PdfUtils() {

    }

    /**
     * docx转pdf
     *
     * @param docx         文档对象
     * @param outputStream 输出流 把文件输出到哪里
     */
    public static void docx2Pdf(XWPFDocument docx, OutputStream outputStream) {
        PdfOptions pdfOptions = PdfOptions.create();
        try {
            PdfConverter.getInstance().convert(docx, outputStream, pdfOptions);
        } catch (IOException e) {
            throw new GlobalException("docx转pdf发生异常", e);
        }
    }
}
