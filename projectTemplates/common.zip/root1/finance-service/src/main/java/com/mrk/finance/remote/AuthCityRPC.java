package com.mrk.finance.remote;

import com.mrk.auth.client.AuthCityClient;
import com.mrk.auth.model.AuthCity;
import com.mrk.common.utils.text.CheckUtil;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

/**
 * @author jlllp
 * @date 2022/6/16
 * @description
 */
@Component
public class AuthCityRPC {

    @Autowired
    private AuthCityClient authCityClient;

    /**
     * 根据主键查询组织城市
     *
     * @param id 主键
     * @return 组织城市
     */
    public AuthCity getCityById(Long id) {
        CheckUtil.isEmptyWithEx(id, "主键不能为空");
        return authCityClient.getCityById(id).getDataWithEx();
    }
}
