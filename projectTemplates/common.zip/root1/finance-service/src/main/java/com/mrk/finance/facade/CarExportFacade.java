package com.mrk.finance.facade;

import org.apache.poi.ss.usermodel.Workbook;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

import javax.servlet.ServletOutputStream;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;

/**
 * @author Bob
 * @date 2021/3/30 17:51
 * @description 导出文件类
 */
@Component
public class CarExportFacade {

  private static final Logger log = LoggerFactory.getLogger(CarExportFacade.class);

  /**
   * @author Bob
   * @date 2021/3/30 17:55
   * @description 导出文件
   */
  public void exportByExcel(HttpServletResponse response, String fileName, Workbook workbook) {
    try(ServletOutputStream outputStream = response.getOutputStream()) {
        ExportFacade.setProperties(response, fileName, workbook, outputStream);
    } catch (IOException e) {
      log.error("导出文件失败", e);
    }
  }
}

