package com.mrk.finance.dto.fncddexport;

import com.mrk.finance.model.FncDdWithhold;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

@Data
public class FncDdWithholdDto extends FncDdWithhold {

  /**匹配状态文本 */
  @ApiModelProperty(value = "匹配状态文本")
  private String fdwMatchStateText;

  /**匹配方式文本 */
  @ApiModelProperty(value = "匹配方式文本")
  private String fdwMatchWayText;
}
