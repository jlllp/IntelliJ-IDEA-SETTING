package com.mrk.finance.dto;

import cn.afterturn.easypoi.excel.annotation.Excel;
import com.mrk.finance.model.FncBankWater;
import lombok.Data;

/**
 * @project: mrk-finance
 * @author: Frank.Tang
 * @date: 2021-11-16 15:27
 * @desc:
 **/
@Data
public class FncBankWaterExportByQueryDto extends FncBankWater {

    @Excel(name = "主键")
    private Long fbwId;

    /**凭证号 */
    @Excel(name = "凭证号")
    private String fbwVoucherNo;

    /**本方账号 */
    @Excel(name = "本方账号")
    private String fbwOwnAccount;

    /**对方账号 */
    @Excel(name = "对方账号")
    private String fbwOtherAccount;

    /**对方单位名称 */
    @Excel(name = "对方单位名称")
    private String fbwOtherUnitName;

    /**借/贷 */
    @Excel(name = "借/贷")
    private String fbwLoanTypeName;
    private Integer fbwLoanType;

    /**交易时间 */
    @Excel(name = "交易时间", exportFormat = "yyyy-MM-dd HH:mm:ss")
    private java.util.Date fbwDealTime;

    /**借方发生额 */
    @Excel(name = "借方发生额")
    private Double fbwBorrowAmount;

    /**贷方发生额 */
    @Excel(name = "贷方发生额")
    private Double fbwCreditAmount;

    /**用途 */
    @Excel(name = "用途")
    private String fbwUse;

    /**摘要 */
    @Excel(name = "摘要")
    private String fbwDigest;

    /**个性化信息 */
    @Excel(name = "个性化信息")
    private String fbwPersonalizedInformation;

    /**匹配状态 */
    @Excel(name = "匹配状态")
    private String fbwMatchStateName;
    private Integer fbwMatchState;

    /**匹配账单 */
    @Excel(name = "匹配账单")
    private String fbwMatchBill;

    /**匹配方式 */
    @Excel(name = "匹配方式")
    private String fbwMatchTypeName;
    private Integer fbwMatchType;

    /**已匹配金额 */
    @Excel(name = "已匹配金额")
    private Double fbwMatchedAmount;

    /**未匹配金额 */
    @Excel(name = "未匹配金额")
    private Double fbwNotMatchAmount;

}
