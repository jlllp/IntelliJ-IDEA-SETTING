package com.mrk.finance.huaweimq;

/**
 * @Author Sandy
 * @create 2021/5/8  下午 01:57
 */
public enum ConsumerTag {
    CONTRACT_BILL;
    /**
     * @date 2021/5/8  下午 01:57
     * @description 根据名称获取对象 找不到时返回 "null"
     * @param name 名称
     */
    public static ConsumerTag getConsumerTag(String name) {
        for (ConsumerTag value : values()) {
            if (value.name().equals(name)) {
                return value;
            }
        }
        return null;
    }
}
