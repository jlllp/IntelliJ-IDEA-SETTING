package com.mrk.finance.dto;

import cn.afterturn.easypoi.excel.annotation.Excel;
import com.mrk.finance.model.FncContractAddition;
import com.mrk.finance.model.FncContractRent;
import lombok.Data;

import java.util.List;

/**
 * @project: mrk-finance
 * @author: Frank.Tang
 * @date: 2021-12-03 09:25
 * @desc:
 **/
@Data
public class FncContractManagementExportByQueryDto {

    @Excel(name = "序号")
    private Long fcmId;

    @Excel(name = "合同编号")
    private String fcmContractNo;

    @Excel(name = "甲方")
    private String fcmPartyaName;

    @Excel(name = "乙方")
    private String fcmPartybName;

    @Excel(name = "合同类型")
    private String fcmContractTypeName;

    @Excel(name = "车辆总数")
    private Integer carModelTotal;

    @Excel(name = "车型种类")
    private String carModelTypesCount;

    @Excel(name = "车型")
    private String carModelTypes;

    @Excel(name = "补充协议")
    private String rentalFeeNames;

    @Excel(name = "租赁起始日期", exportFormat = "yyyy-MM-dd HH:mm:ss")
    private java.util.Date fcmLeaseStartDate;

    @Excel(name = "租赁结束日期", exportFormat = "yyyy-MM-dd HH:mm:ss")
    private java.util.Date fcmLeaseEndDate;

    @Excel(name = "合同状态")
    private String fcmContractStateName;

    @Excel(name = "结算状态")
    private String fcmSettlementStateName;

    @Excel(name = "签订日期", exportFormat = "yyyy-MM-dd HH:mm:ss")
    private java.util.Date fcmSignedDate;


    /**车型*/
    List<FncContractCarmodelDto> carModelDtos;

    /**补充合同*/
    List<FncContractAddition> additions;

    /**租金包含费用*/
    List<FncContractRentalFeesDto> contractRentalFees;

    /**不固定租金*/
    List<FncContractRent> rents;

}
