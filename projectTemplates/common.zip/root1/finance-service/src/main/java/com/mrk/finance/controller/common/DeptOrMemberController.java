package com.mrk.finance.controller.common;

import com.github.pagehelper.PageInfo;
import com.mrk.common.utils.page.JsonResult;
import com.mrk.finance.dto.common.DeptOrMemberInfoDto;
import com.mrk.finance.facade.common.DeptOrMemberFacade;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiImplicitParam;
import io.swagger.annotations.ApiImplicitParams;
import io.swagger.annotations.ApiOperation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

/**
 * @author Bob
 * @date 2021-11-18
 * @description
 */
@RestController
@RequestMapping("/financeservice/deptormember")
@Api(tags = "部门和会员")
public class DeptOrMemberController {

    @Autowired
    private DeptOrMemberFacade deptOrMemberFacade;

    @ApiOperation("部门和会员-根据类型和名称模糊查询 获取分页结果")
    @ApiImplicitParams({
            @ApiImplicitParam(paramType = "header", name = "Authorization", value = "系统下发的token", required = true),
            @ApiImplicitParam(paramType = "query", name = "partyType", value = "类型 0个人 1组织", required = true),
            @ApiImplicitParam(paramType = "query", name = "nameLike", value = "名称模糊查询 非必传"),
            @ApiImplicitParam(paramType = "query", name = "cityIdEqualTo", value = "名称模糊查询 非必传"),
            @ApiImplicitParam(paramType = "query", name = "page", value = "页码 不传入默认为1", required = true),
            @ApiImplicitParam(paramType = "query", name = "rows", value = "每页显示记录 不传入默认为25", required = true),
    })
    @GetMapping("/info")
    public JsonResult<PageInfo<DeptOrMemberInfoDto>> getInfoByTypeAndName(Integer partyType, @RequestParam(required = false) String nameLike,@RequestParam(required = false) Long cityIdEqualTo) {
        PageInfo<DeptOrMemberInfoDto> deptOrMemberInfoDtoList = deptOrMemberFacade.getInfoByTypeAndName(partyType, nameLike, cityIdEqualTo);
        return JsonResult.success(deptOrMemberInfoDtoList);
    }
}
