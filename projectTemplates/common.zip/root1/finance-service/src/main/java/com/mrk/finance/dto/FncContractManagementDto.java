package com.mrk.finance.dto;

import com.mrk.finance.model.FncContractAttach;
import com.mrk.finance.model.FncContractManagement;
import com.mrk.finance.model.FncContractRent;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.util.List;

/**
 * @project: mrk-finance
 * @author: Frank.Tang
 * @date: 2021-11-15 09:47
 * @desc:
 **/
@Data
public class FncContractManagementDto extends FncContractManagement {

    @ApiModelProperty("甲方名称")
    private String fcmPartyaName;

    @ApiModelProperty("甲方类型名称")
    private String fcmPartyaTypeName;

    @ApiModelProperty("乙方名称")
    private String fcmPartybName;

    @ApiModelProperty("乙方类型名称")
    private String fcmPartybTypeName;

    @ApiModelProperty("城市")
    private String fcmCityName;

    @ApiModelProperty("租赁起始类型")
    private String fcmLeaseStartTypeName;

    @ApiModelProperty("租赁类型")
    private String fcmLeaseTypeName;

    @ApiModelProperty("租金支付类型")
    private String fcmRentPayTypeName;

    @ApiModelProperty("账单生成类型")
    private String fcmBillGenerateTypeName;

    @ApiModelProperty("保证金支付要求")
    private String fcmMarginPayRequireName;

    @ApiModelProperty("合同状态")
    private String fcmContractStateName;

    @ApiModelProperty("合同类型 ")
    private String fcmContractTypeName;

    @ApiModelProperty("结算状态")
    private String fcmSettlementStateName;



    /**出租方/租售方 */
    @ApiModelProperty(value = "出租方/租售方")
    private String fcmPartyAText;

    /**承租方/租售方 类型 */
    @ApiModelProperty(value = "承租方/租售方 类型")
    private String fcmPartyBTypeText;

    /**车型ID */
    @ApiModelProperty(value = "车型ID")
    private String fcmCarTypeIdText;

    /**车辆性质 */
    @ApiModelProperty(value = "车辆性质")
    private String fcmCarNatureText;

    /**履约保证金类型 0无 1总额 2单车 */
    @ApiModelProperty(value = "履约保证金类型 0无 1总额 2单车")
    private String fcmMarginTypeText;


    /**保证金支付方式 0无 1交车前一次性支付 2分批支付 */
    @ApiModelProperty(value = "保证金支付方式 0无 1交车前一次性支付 2分批支付")
    private String fcmMarginPayTypeText;

    /**签订地点 */
    @ApiModelProperty(value = "签订地点")
    private String fcmSignedAddrText;

    /**车辆交车地点 */
    @ApiModelProperty(value = "车辆交车地点")
    private String fcmDeliverCityText;

    /**车辆归还地点 */
    @ApiModelProperty(value = "车辆归还地点")
    private String fcmReturnCityText;

    /**车辆交付方式 0无 1交车前一次性交付 2分批交付 */
    @ApiModelProperty(value = "车辆交付方式 0无 1交车前一次性交付 2分批交付")
    private String fcmDeliverTypeText;

    /**是否科转租 0无 1是 2否 */
    @ApiModelProperty(value = "是否科转租 0无 1是 2否")
    private String fcmSubletText;




    /**车辆状态 */
    @ApiModelProperty(value = "车辆状态")
    private String carStateText;



    @ApiModelProperty("附件")
    private  String contractAttachText;




    @ApiModelProperty("附件")
    private List<FncContractAttach> fncContractAttaches;

    /**车型*/
    List<FncContractCarmodelDto> carModelDtos;

    /**补充合同*/
    List<FncContractAdditionDto> additions;

    /**租金包含费用*/
    List<FncContractRentalFeesDto> contractRentalFees;

    /**不固定租金*/
    List<FncContractRent> rents;

    int carModelTotal;
}
