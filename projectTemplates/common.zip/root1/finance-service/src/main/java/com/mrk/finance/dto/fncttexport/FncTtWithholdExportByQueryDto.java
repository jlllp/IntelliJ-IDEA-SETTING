package com.mrk.finance.dto.fncttexport;

import cn.afterturn.easypoi.excel.annotation.Excel;
import lombok.Data;

import java.io.Serializable;

@Data
public class FncTtWithholdExportByQueryDto implements Serializable {

  /**车型文本 */
  @Excel(name = "车型")
  private String ftwCarModelText;

  /**匹配状态文本 */
  @Excel(name = "匹配状态")
  private String ftwMatchStateText;


  /**匹配方式文本 */
  @Excel(name = "匹配方式")
  private String ftwMatchWayText;

  /**城市文本 */
  @Excel(name = "城市")
  private String ftwCityIdText;

  /**姓名 */
  @Excel(name = "姓名")
  private String ftwName;

  /**身份证号 */
  @Excel(name = "身份证号")
  private String ftwIdnumber;

  /**协议编号 */
  @Excel(name = "协议编号")
  private String ftwAgreementNumber;

  /**起租日期 */
  @Excel(name = "起租日期",exportFormat = "yyyy-MM-dd HH:mm:ss")
  private java.util.Date ftwRentDate;

  /**租期 */
  @Excel(name = "租期")
  private Integer ftwLeaseCount;


  /**车架号 */
  @Excel(name = "车架号")
  private String ftwCarVin;

  /**月租金 */
  @Excel(name = "月租金")
  private Double ftwMonthRent;

  /**月扣款总额 */
  @Excel(name = "月扣款总额")
  private Double ftwMonthWithhold;

  /**月租金余量 */
  @Excel(name = "月租金余量")
  private Double ftwMonthRentBalance;

  /**司机ID */
  @Excel(name = "司机ID")
  private Long ftwMemberId;

  /**匹配账单 */
  @Excel(name = "匹配账单")
  private String ftwMatchBill;

  /**已匹配金额 */
  @Excel(name = "已匹配金额")
  private Double ftwMatchedAmount;

  /**未匹配金额 */
  @Excel(name = "未匹配金额")
  private Double ftwNotMatchAmount;
}
