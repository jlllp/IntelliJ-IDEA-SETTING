package com.mrk.finance.enums;

import lombok.Getter;

/**
 * @project: mrk-finance
 * @author: Frank.Tang
 * @date: 2021-11-11 09:55
 * @desc: 账单生成方式
 **/
@Getter
public enum BillGenerateWayEnum {

    /***/
    MANUAL(0, "手动生成"),
    AUTO(1, "自动生成");

    private Integer value;
    private String name;

    BillGenerateWayEnum(Integer value, String name) {
        this.value = value;
        this.name = name;
    }

    public static String getName(Integer state) {
        if (state == null) {
            return "";
        }
        for (BillGenerateWayEnum statusEnum : values()) {
            if (statusEnum.getValue().equals(state)) {
                return statusEnum.getName();
            }
        }
        return "";
    }

}
