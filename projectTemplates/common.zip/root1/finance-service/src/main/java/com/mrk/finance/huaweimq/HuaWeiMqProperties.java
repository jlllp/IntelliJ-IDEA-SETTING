package com.mrk.finance.huaweimq;

import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Configuration;

/**
 * mrk-finance
 *
 * @author : Sandy
 * @Description:
 * @Date 2021/12/3 10:17
 **/
@Configuration
@ConfigurationProperties(prefix = "mrk.huawei.rocketmq")
public class HuaWeiMqProperties {
    /**
     * 消费的tag
     */
    private String tag;

    /**
     * 元数据地址
     */
    private String nameServer;

    /**
     * 消费的group
     */
    private String group;

    /**
     * 消费的topic
     */
    private String topic;


    /**
     * accessKey
     */
    private String accessKey;


    /**
     * secretKey
     */
    private String secretKey;

    public String getTag() {
        return tag;
    }

    public void setTag(String tag) {
        this.tag = tag;
    }

    public String getNameServer() {
        return nameServer;
    }

    public void setNameServer(String nameServer) {
        this.nameServer = nameServer;
    }

    public String getGroup() {
        return group;
    }

    public void setGroup(String group) {
        this.group = group;
    }

    public String getTopic() {
        return topic;
    }

    public void setTopic(String topic) {
        this.topic = topic;
    }

    public String getAccessKey() {
        return accessKey;
    }

    public void setAccessKey(String accessKey) {
        this.accessKey = accessKey;
    }

    public String getSecretKey() {
        return secretKey;
    }

    public void setSecretKey(String secretKey) {
        this.secretKey = secretKey;
    }
}
