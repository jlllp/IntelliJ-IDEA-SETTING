package com.mrk.finance.facade.contract;

import com.mrk.common.utils.bean.BeanUtils;
import com.mrk.common.utils.container.ListUtil;
import com.mrk.common.utils.text.CheckUtil;
import com.mrk.finance.dto.contract.RentCalculationDto;
import com.mrk.finance.dto.contract.RentTimeRightDto;
import com.mrk.finance.dto.date.TimeRightDto;
import com.mrk.finance.enums.ContractGiveSequenceEnum;
import com.mrk.finance.enums.ContractLeaseTypeEnum;
import com.mrk.finance.enums.ContractRentPayTypeEnum;
import com.mrk.finance.enums.ContractRentPaymentCycleEnum;
import com.mrk.finance.model.FncContractManagement;
import com.mrk.finance.model.FncContractRent;
import com.mrk.finance.service.FncContractRentService;
import com.mrk.finance.util.contract.ContractDateCalculateUtil;
import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.collections4.MapUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.List;
import java.util.Map;
import java.util.SortedMap;
import java.util.TreeMap;

/**
 * @author Bob
 * @date 2021-11-23
 * @description
 */
@Component
public class ContractFacade {

    private static final Logger log = LoggerFactory.getLogger(ContractFacade.class);

    @Autowired
    private FncContractRentService fncContractRentService;

    /**
     * @param rentCalculationDto 租金dot类
     * @return 租金账单Map
     * @author Bob
     * @date 2021/11/23
     * @description 获取租金
     */
    public SortedMap<Integer, RentTimeRightDto> getRent(RentCalculationDto rentCalculationDto) {
        // 检查数据是否正常
        if (dataCheck(rentCalculationDto)) return new TreeMap<>();

        // 获取合同租赁时间
        Integer leaseCount = getLeaseCount(rentCalculationDto);

        // 间隔转换
        Integer rentPayCycle = rentCalculationDto.getFcmRentPayCycle();
        Integer interval = ContractRentPaymentCycleEnum.toIntervalValue(rentPayCycle);
        if (interval == 0) {
            log.warn("计算租金 转换实际间隔失败 --> 跳过 contractID：【{}】", rentCalculationDto.getFcmId());
            return new TreeMap<>();
        }

        // 获取租期
        SortedMap<Integer, TimeRightDto> leaseTermMap = ContractDateCalculateUtil.calculateThePaymentPeriod
                (rentCalculationDto.getFcmLeaseStartDate(), leaseCount, rentCalculationDto.getFcmRentPayType(), interval);
        // 检查是否获取到租赁周期
        if (MapUtils.isEmpty(leaseTermMap)) {
            log.warn("计算租金 获取租期失败 --> 跳过 contractID：【{}】", rentCalculationDto.getFcmId());
            return new TreeMap<>();
        }
        log.info("计算租金 获取租期 --> contractID：【{}】 leaseTermMap：【{}】", rentCalculationDto.getFcmId(), leaseTermMap);

        // 获取月份和租金对应关系
        SortedMap<Integer, Double> rentCorrespondenceMap = getTheCorrespondingRent(rentCalculationDto);
        // 获取月份和租金对应
        if (MapUtils.isEmpty(rentCorrespondenceMap)) {
            log.warn("计算租金 获取月份和租金对应关系 --> 跳过 contractID：【{}】", rentCalculationDto.getFcmId());
            return new TreeMap<>();
        }
        log.info("计算租金 获取月份和租金对应关系 --> rentCorrespondenceMap：【{}】", rentCorrespondenceMap);

        // 构建租金周期费用
        SortedMap<Integer, RentTimeRightDto> integerRentTimeRightDtoSortedMap = constructRentCycle(leaseTermMap, rentCorrespondenceMap, rentCalculationDto);
        log.info("计算租金 获取到每月租金 --> integerRentTimeRightDtoSortedMap：【{}】", integerRentTimeRightDtoSortedMap);
        return integerRentTimeRightDtoSortedMap;
    }

    /**
     * @param fncContractManagement 合同
     * @return 真实租期
     * @author Bob
     * @date 2021/11/25
     * @description 获取合同真实的租期
     */
    public Integer getLeaseCount(FncContractManagement fncContractManagement) {
        // 获取合同的租赁周期
        Integer leaseCount = fncContractManagement.getFcmLeaseCount();
        // 都不为空说明存在赠送
        // 赠送租期处理
        if (CheckUtil.isNotEmpty(fncContractManagement.getFcmGiveLease()) && CheckUtil.isNotEmpty(fncContractManagement.getFcmGiveSequence())) {
            leaseCount += fncContractManagement.getFcmGiveLease();
        }
        return leaseCount;
    }

    /**
     * @param fncContractManagement 合同
     * @return true 数据检查不通过 false数据检查通过
     * @author Bob
     * @date 2021/11/22
     * @description 检查必须是否是否为空
     */
    private boolean dataCheck(FncContractManagement fncContractManagement) {
        // 必要数据检查 发现为空 跳过
        if (CheckUtil.isEmpty(fncContractManagement)) {
            log.info("计算租金 合同为空 --> 跳过");
            return true;
        }

        if (CheckUtil.isEmpty(fncContractManagement.getFcmLeaseStartDate())) {
            log.warn("计算租金 合同开始日期为空 --> 跳过 contractID：【{}】", fncContractManagement.getFcmId());
            return true;
        }

        if (CheckUtil.isEmpty(fncContractManagement.getFcmLeaseCount())) {
            log.warn("计算租金 合同租期为空 --> 跳过 contractID：【{}】", fncContractManagement.getFcmId());
            return true;
        }

        if (CheckUtil.isEmpty(fncContractManagement.getFcmRentPayType())) {
            log.warn("计算租金 租金支付类型为空 --> 跳过 contractID：【{}】", fncContractManagement.getFcmId());
            return true;
        }

        if (CheckUtil.isEmpty(fncContractManagement.getFcmRentPayCycle())) {
            log.warn("计算租金 租金支付周期为空 --> 跳过 contractID：【{}】", fncContractManagement.getFcmId());
            return true;
        }

        if (CheckUtil.isEmpty(fncContractManagement.getFcmLeaseType())) {
            log.warn("计算租金 租金类型为空 --> 跳过 contractID：【{}】", fncContractManagement.getFcmId());
            return true;
        }

        return false;
    }

    /**
     * @param rentCalculationDto 合同dto
     * @return 第几月 和 对应租金 组成的一个map
     * @author Bob
     * @date 2021/11/22
     * @description 获取月份和租金对应关系
     */
    public SortedMap<Integer, Double> getTheCorrespondingRent(RentCalculationDto rentCalculationDto) {
        // 构建一个map用于返回数据
        SortedMap<Integer, Double> dtoTreeMap = new TreeMap<>(Integer::compare);
        Integer leaseType = rentCalculationDto.getFcmLeaseType();
        // 固定
        if (ContractLeaseTypeEnum.FIXED.getValue().equals(leaseType)) {
            // 固定租金处理
            fixedRentDispose(rentCalculationDto, dtoTreeMap);
        }
        // 不固定
        else if (ContractLeaseTypeEnum.NOT_FIXED.getValue().equals(leaseType)) {
            // 不固定租金处理
            noFixedRentDispose(rentCalculationDto, dtoTreeMap);
        }
        // 没有结果旧返回
        if (MapUtils.isEmpty(dtoTreeMap)) {
            return dtoTreeMap;
        }
        // 赠送租期处理
        freeLeaseDispose(rentCalculationDto, dtoTreeMap);
        return dtoTreeMap;
    }

    /**
     * @param fncContractManagement 合同对象
     * @return 合同不固定租金dto对象
     * @author Bob
     * @date 2021/11/25
     * @description 对象转换
     */
    public RentCalculationDto transformRentCalculationDto(FncContractManagement fncContractManagement) {
        RentCalculationDto rentCalculationDto = BeanUtils.copyBean(fncContractManagement, RentCalculationDto.class);
        // 不固定租金处理
        if (ContractLeaseTypeEnum.NOT_FIXED.getValue().equals(rentCalculationDto.getFcmLeaseType())) {
            List<FncContractRent> contractRentList = fncContractRentService.getByContractId(fncContractManagement.getFcmId());
            List<RentCalculationDto.VariableRentDto> variableRentDtoList = ListUtil.copyBeanList(contractRentList, RentCalculationDto.VariableRentDto.class);
            rentCalculationDto.setVariableRentDtoList(variableRentDtoList);
        }
        return rentCalculationDto;
    }

    /**
     * @param fncContractManagement 合同
     * @param dtoTreeMap            月份 租金 map
     * @author Bob
     * @date 2021/11/22
     * @description 固定租金处理
     */
    private void fixedRentDispose(FncContractManagement fncContractManagement, SortedMap<Integer, Double> dtoTreeMap) {
        // 获取到每个月租金
        Double leaseAmount = fncContractManagement.getFcmLeaseAmount();
        if (CheckUtil.isNotEmpty(leaseAmount)) {
            // 使用租期次数来遍历
            // 处理第X个月和租金的对应关系
            for (Integer i = 1; i <= fncContractManagement.getFcmLeaseCount(); i++) {
                dtoTreeMap.put(i, leaseAmount);
            }
        }
    }

    /**
     * @param rentCalculationDto 租金计算dto
     * @param dtoTreeMap         月份 租金 map
     * @author Bob
     * @date 2021/11/22
     * @description 不固定租金处理
     */
    private void noFixedRentDispose(RentCalculationDto rentCalculationDto, SortedMap<Integer, Double> dtoTreeMap) {
        // 获取当前合同对应的不固定租期租金明细
        List<RentCalculationDto.VariableRentDto> variableRentDtoList = rentCalculationDto.getVariableRentDtoList();
        if (CollectionUtils.isNotEmpty(variableRentDtoList)) {
            // 统计循环次数
            // 用于判断是否和总租期相等
            int count = 0;
            for (RentCalculationDto.VariableRentDto variableRentDto : variableRentDtoList) {
                // 关键数据不能为空
                Integer startMonth = variableRentDto.getFccStartMonth();
                Integer endMonth = variableRentDto.getFccEndMonth();
                Double rentAmount = variableRentDto.getFccRentAmount();
                if (CheckUtil.isNotEmpty(startMonth) && CheckUtil.isNotEmpty(endMonth) && CheckUtil.isNotEmpty(rentAmount)) {
                    // 开始月份 结束月份
                    // 当作遍历的条件 用来构成key
                    for (int i = startMonth; i <= endMonth; i++) {
                        count++;
                        dtoTreeMap.put(i, rentAmount);
                    }
                }
            }
            // 不和总租期相等
            // 则说明数据出现问题
            if (count != rentCalculationDto.getFcmLeaseCount()) {
                // 清空map中的数据
                // 这里为什么不使用异常的方式结束线程运行状态
                // 当线程异常的时候，线程池会将异常线程从线程池中移除出去
                // 添加一个新的线程到线程池中
                // 如果异常线程过多，会导致每次创建新的线程
                dtoTreeMap.clear();
                log.warn("计算租金 租金总月份和不固定租金月份不匹配 --> 合同id：【{}】", rentCalculationDto.getFcmId());
            }
        }
    }

    /**
     * @param fncContractManagement 合同
     * @param dtoTreeMap            现有租金map
     * @author Bob
     * @date 2021/11/23
     * @description 赠送租期租金处理
     */
    private void freeLeaseDispose(FncContractManagement fncContractManagement, SortedMap<Integer, Double> dtoTreeMap) {
        // 赠送租期处理
        Integer giveLease = fncContractManagement.getFcmGiveLease();
        Integer giveSequence = fncContractManagement.getFcmGiveSequence();

        // 赠送租期处理
        if (CheckUtil.isNotEmpty(giveLease) && CheckUtil.isNotEmpty(giveSequence)) {
            // 先赠送
            if (ContractGiveSequenceEnum.BEFORE.getValue().equals(giveSequence)) {
                // 将集合中的数据往后放
                // 例：  原先有3给租期 赠送2个
                //      原集合中数据为 1=5D, 2=5D, 3=5D
                //      移动后变为     3=5D, 4=5D, 5=5D
                //      不送赠送租期就变为
                //                  1=0D, 2=0D, 3=5D, 4=5D, 5=5D
                // SortMap.values() 此方法保证了取出来的集合不会乱序
                int size = dtoTreeMap.values().size();
                for (int i = size; i > 0; i--) {
                    Double amount = dtoTreeMap.get(i);
                    dtoTreeMap.put(i + giveLease, amount);
                }
                // 赠送租期处理
                // 赠送租期的租金费用为0
                for (int i = 1; i <= giveLease; i++) {
                    dtoTreeMap.put(i, 0D);
                }
            }
            // 后赠送
            else if (ContractGiveSequenceEnum.AFTER.getValue().equals(giveSequence)) {
                // 只需要再原先的基础上往后面累加即可
                // 例：原先有15个租期 后赠送5个租期
                //    那么map中有15条数据
                //    从第16个开始放赠送租期即可
                int size = dtoTreeMap.size();
                for (int i = 1; i <= giveLease; i++) {
                    dtoTreeMap.put(i + size, 0D);
                }
            }
        }
    }

    /**
     * @param leaseTermMap          租赁周期map
     * @param rentCorrespondenceMap 月份租金map
     * @param fncContractManagement 合同
     * @return 租金周期费用 关系映射Map
     * @author Bob
     * @date 2021/11/22
     * @description 构建租金周期费用
     */
    private SortedMap<Integer, RentTimeRightDto> constructRentCycle(SortedMap<Integer, TimeRightDto> leaseTermMap, SortedMap<Integer, Double> rentCorrespondenceMap, FncContractManagement fncContractManagement) {
        // 自然周期处理
        if (ContractRentPayTypeEnum.NATURAL.getValue().equals(fncContractManagement.getFcmRentPayType())) {
            log.info("计算租金 自然周期处理 --> contractID：【{}】", fncContractManagement.getFcmId());
            return naturalDispose(leaseTermMap, rentCorrespondenceMap, fncContractManagement);
        }
        // 相对周期处理
        else if (ContractRentPayTypeEnum.RELATIVE.getValue().equals(fncContractManagement.getFcmRentPayType())) {
            log.info("计算租金 相对周期处理 --> contractID：【{}】", fncContractManagement.getFcmId());
            return relativeDispose(leaseTermMap, rentCorrespondenceMap, fncContractManagement);
        }
        return new TreeMap<>();
    }

    /**
     * @param leaseTermMap          租赁周期map
     * @param rentCorrespondenceMap 月份租金map
     * @param fncContractManagement 合同
     * @return 每个租期总金额
     * @author Bob
     * @date 2021/11/22
     * @description 自然周期处理
     */
    private SortedMap<Integer, RentTimeRightDto> naturalDispose(SortedMap<Integer, TimeRightDto> leaseTermMap, SortedMap<Integer, Double> rentCorrespondenceMap, FncContractManagement fncContractManagement) {
        SortedMap<Integer, RentTimeRightDto> rentMap = new TreeMap<>(Integer::compare);
        // 租金支付周期
        Integer rentPayCycle = fncContractManagement.getFcmRentPayCycle();
        Integer interval = ContractRentPaymentCycleEnum.toIntervalValue(rentPayCycle);
        // 四舍五入 保留两个小数
        for (Map.Entry<Integer, TimeRightDto> entry : leaseTermMap.entrySet()) {
            Integer cycle = entry.getKey();
            TimeRightDto timeRightDto = entry.getValue();
            BigDecimal accumulatedRent = new BigDecimal("0.00");
            // 价格计算
            int end = cycle * interval;
            int start = end - interval + 1;
            // 如果结束月 大于 总租期
            // 结束 = 总租期
            // 不能影响开始月
            Integer leaseCount = getLeaseCount(fncContractManagement);
            if (end > leaseCount) {
                end = leaseCount;
            }
            // 第一个月会出现不满一个月的情况 用实际覆盖天数进行计算
            int count = 1;
            for (int i = start; i <= end; i++) {
                // 第一次进来
                Double amount = rentCorrespondenceMap.get(i);
                if (count == 1) {
                    count++;
                    accumulatedRent = firstMonthRent(timeRightDto, accumulatedRent, amount);
                }
                // 非第一次 自然周期下绝对是满月
                else {
                    if (CheckUtil.isNotEmpty(amount)) {
                        accumulatedRent = accumulatedRent.add(BigDecimal.valueOf(amount));
                    }
                }
            }
            // 租赁周期时间
            RentTimeRightDto rentTimeRightDto = BeanUtils.copyBean(timeRightDto, RentTimeRightDto.class);
            rentTimeRightDto.setAmount(accumulatedRent.doubleValue());
            rentMap.put(cycle, rentTimeRightDto);
        }
        log.info("计算租金 自然周期处理结束 --> contractID：【{}】", fncContractManagement.getFcmId());
        return rentMap;
    }

    /**
     * @param timeRightDto    时间对dto类
     * @param accumulatedRent 租金累计
     * @param amount          单月租金
     * @return 自然周期第一月租金
     * @author Bob
     * @date 2021/11/22
     * @description
     */
    public BigDecimal firstMonthRent(TimeRightDto timeRightDto, BigDecimal accumulatedRent, Double amount) {
        // 获取当前月是否满月
        int actualMaximum = ContractDateCalculateUtil.getActualMaximum(timeRightDto.getStart());
        int dayByMonth = ContractDateCalculateUtil.getDayByMonth(timeRightDto.getStart());
        // 实际覆盖天数 = 当月总天数 - 本月的开始天数 + 1
        // 当月总天数 等于 实际覆盖天数
        // 满月
        int actualDays = actualMaximum - dayByMonth + 1;
        if (actualMaximum == actualDays) {
            if (CheckUtil.isNotEmpty(amount)) {
                accumulatedRent = accumulatedRent.add(BigDecimal.valueOf(amount));
            }
        }
        // 不满月
        else {
            // 将租金转换
            BigDecimal decimal = BigDecimal.valueOf(amount);
            // 本月租金 = 租金 / 本月自然天数 * 本月覆盖天数
            BigDecimal rentThisMonth = decimal.multiply(BigDecimal.valueOf(actualDays))
                    .divide(BigDecimal.valueOf(actualMaximum), 2, RoundingMode.HALF_UP);
            accumulatedRent = accumulatedRent.add(rentThisMonth);
        }
        return accumulatedRent;
    }

    /**
     * @param leaseTermMap          租赁周期map
     * @param rentCorrespondenceMap 月份租金map
     * @param fncContractManagement 合同
     * @return 每个租期总金额
     * @author Bob
     * @date 2021/11/22
     * @description 相对周期处理
     */
    private SortedMap<Integer, RentTimeRightDto> relativeDispose(SortedMap<Integer, TimeRightDto> leaseTermMap, SortedMap<Integer, Double> rentCorrespondenceMap, FncContractManagement fncContractManagement) {
        SortedMap<Integer, RentTimeRightDto> rentMap = new TreeMap<>(Integer::compare);
        // 租金支付周期
        Integer rentPayCycle = fncContractManagement.getFcmRentPayCycle();
        Integer interval = ContractRentPaymentCycleEnum.toIntervalValue(rentPayCycle);
        // 四舍五入 保留两个小数
        for (Map.Entry<Integer, TimeRightDto> entry : leaseTermMap.entrySet()) {
            BigDecimal bigDecimal = new BigDecimal("0.00");
            Integer cycle = entry.getKey();
            TimeRightDto timeRightDto = entry.getValue();
            // 租赁周期时间
            RentTimeRightDto rentTimeRightDto = BeanUtils.copyBean(timeRightDto, RentTimeRightDto.class);
            // 价格计算
            int end = cycle * interval;
            int start = end - interval + 1;
            // 如果结束月 大于 总租期
            // 结束 = 总租期
            // 不能影响开始月
            Integer leaseCount = getLeaseCount(fncContractManagement);
            if (end > leaseCount) {
                end = leaseCount;
            }
            for (int i = start; i <= end; i++) {
                Double amount = rentCorrespondenceMap.get(i);
                if (CheckUtil.isNotEmpty(amount)) {
                    bigDecimal = bigDecimal.add(BigDecimal.valueOf(amount));
                }
            }
            rentTimeRightDto.setAmount(bigDecimal.doubleValue());
            rentMap.put(cycle, rentTimeRightDto);
        }
        log.info("计算租金 相对周期处理结束 --> contractID：【{}】", fncContractManagement.getFcmId());
        return rentMap;
    }

}
