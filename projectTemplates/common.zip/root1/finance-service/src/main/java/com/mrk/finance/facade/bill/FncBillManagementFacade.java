package com.mrk.finance.facade.bill;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.TypeReference;
import com.github.pagehelper.PageInfo;
import com.mrk.auth.client.AuthCityClient;
import com.mrk.auth.client.AuthUserClient;
import com.mrk.auth.model.AuthCity;
import com.mrk.auth.model.AuthUser;
import com.mrk.common.constant.BaseConstants;
import com.mrk.common.exception.GlobalException;
import com.mrk.common.utils.container.ListUtil;
import com.mrk.common.utils.jwt.JWTUtil;
import com.mrk.common.utils.redis.RedisLock;
import com.mrk.common.utils.text.CheckUtil;
import com.mrk.finance.constants.ExMsgConstants;
import com.mrk.finance.constants.LenConstants;
import com.mrk.finance.dto.FncBillManagementDto;
import com.mrk.finance.enums.*;
import com.mrk.finance.facade.common.FinanceUserNameFacade;
import com.mrk.finance.facade.dto.WaterIntegrationDto;
import com.mrk.finance.model.*;
import com.mrk.finance.queryvo.FncBillManagementQueryVo;
import com.mrk.finance.service.*;
import com.mrk.finance.util.ExceptionUtil;
import com.mrk.finance.util.MatchUtil;
import com.mrk.finance.util.ObjectUtil;
import com.mrk.finance.util.StreamUtil;
import com.mrk.finance.vo.BillAddOrUpdateVo;
import com.mrk.finance.vo.BillMatchWaterVo;
import com.mrk.paycenter.client.PayCenterClient;
import com.mrk.paycenter.model.MrkPayDetail;
import com.mrk.paycenter.model.MrkPayRecord;
import com.mrk.resource.client.ResCarQueryClient;
import com.mrk.resource.model.ResCar;
import com.mrk.universal.enums.turner.TurnerSingleOverTimeEnum;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.redis.core.StringRedisTemplate;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.*;
import java.util.regex.Pattern;
import java.util.stream.Collectors;

/**
 * @project: mrk-finance
 * @author: Frank.Tang
 * @date: 2021-11-11 09:36
 * @desc:
 *
 * 账单管理, 相关方法汇总:
 *   (1)分页查询-----{@link FncBillManagementFacade\#page}
 *   (2)新增---------{@link FncBillManagementFacade\#add}
 *   (3)删除---------{@link FncBillManagementFacade\#del}
 *   (4)审批---------{@link FncBillManagementFacade\#approve}
 *   (5)重新发起审批--{@link FncBillManagementFacade\#relaunchApprove}
 *   (6)申请开票------{@link FncBillManagementFacade\#applyInvoice}
 *   (7)确认开票------{@link FncBillManagementFacade\#confirmInvoice}
 *   (8)手动匹配------{@link FncBillManagementFacade\#manuallyMatch}
 *   (9)自动匹配------{@link FncBillAutoMatchFacade\#autoMatch}
 *
 **/
@Slf4j
@Component
public class FncBillManagementFacade {

    @Autowired
    private FncBankWaterService fncBankWaterService;
    @Autowired
    private FncDdWithholdService fncDdWithholdService;
    @Autowired
    private FncTtWithholdService fncTtWithholdService;
    @Autowired
    private FncBillManagementService fncBillManagementService;
    @Autowired
    private FncContractManagementService fncContractManagementService;
    @Autowired
    private FncRevenueWaterRecordService fncRevenueWaterRecordService;
    @Autowired
    private AuthCityClient authCityClient;
    @Autowired
    private AuthUserClient authUserClient;
    @Autowired
    private ResCarQueryClient resCarQueryClient;
    @Autowired
    private PayCenterClient payCenterClient;
    @Autowired
    private StringRedisTemplate stringRedisTemplate;

    @Autowired
    private FinanceUserNameFacade financeUserNameFacade;

    /** 手动匹配的流水格式(2个字母+id) */
    private static final Pattern WATER_INFO_PATTERN = Pattern.compile("[A-Za-z]{2}\\d+");

    public static final String BILL_MANAGEMENT_KEY = "billIds:";


    /**
     * 账单分页查询
     * @return *
     * @author Frank.Tang
     */
    public PageInfo<FncBillManagementDto> page(FncBillManagementQueryVo queryVo) {
        PageInfo<FncBillManagement> pageInfo = fncBillManagementService.page(queryVo);
        List<FncBillManagement> list = pageInfo.getList();
        List<FncBillManagementDto> dtos = ListUtil.copyBeanList(list, FncBillManagementDto.class);

        Set<Long> carIds = StreamUtil.toSet(dtos, FncBillManagement::getFbmAssociateCarId);
        Set<Long> contractIds = StreamUtil.toSet(dtos, FncBillManagement::getFbmAssociateContractId);
        Set<Long> userIds = StreamUtil.toSet(dtos, FncBillManagement::getFbmMatchUserId);
        Set<Long> cityIds = StreamUtil.toSet(dtos, FncBillManagement::getFbmCityId);

        List<ResCar> cars = resCarQueryClient.findCarByIds(ObjectUtil.collectionToStr(carIds)).getDataWithEx();
        List<FncContractManagement> contracts = fncContractManagementService.getByIds(new ArrayList<>(contractIds));
        List<AuthUser> users = authUserClient.getAuthUserByIds(ObjectUtil.collectionToStr(userIds)).getDataWithEx();
        List<AuthCity> cities = authCityClient.getCityByIds(ObjectUtil.collectionToStr(cityIds)).getDataWithEx();

        Map<Long, ResCar> carMap = StreamUtil.toMap(cars, ResCar::getRcId);
        Map<Long, FncContractManagement> contractMap = StreamUtil.toMap(contracts, FncContractManagement::getFcmId);
        Map<Long, AuthUser> userMap = StreamUtil.toMap(users, AuthUser::getId);
        Map<Long, AuthCity> cityMap = StreamUtil.toMap(cities, AuthCity::getId);

        for (FncBillManagementDto dto : dtos) {
            FncContractManagement contract = contractMap.get(dto.getFbmAssociateContractId());
            AuthUser matchUser = userMap.get(dto.getFbmMatchUserId());
            AuthCity city = cityMap.get(dto.getFbmCityId());
            ResCar car = carMap.get(dto.getFbmAssociateCarId());

            dto.setFbmAssociateContractNo(contract == null ? "" : contract.getFcmContractNo());
            dto.setFbmMatchUserName(matchUser == null ? "" : matchUser.getUserName());
            dto.setFbmCityName(city == null ? "" : city.getCityName());
            dto.setFbmAssociateCarPlateNum(car == null ? "" : car.getRcPlateNum());

            dto.setFbmBillStateName(BillStateEnum.getName(dto.getFbmBillState()));
            dto.setFbmMatchWayName(MatchWayEnum.getName(dto.getFbmMatchWay()));
            dto.setFbmSubjectsName(BillSubjectsEnum.getName(dto.getFbmSubjects()));
            dto.setFbmBillGenerateWayName(BillGenerateWayEnum.getName(dto.getFbmBillGenerateWay()));
        }
        return new PageInfo<>(dtos);
    }

    /**
     * 账单管理: 新增
     * @param entity 前端传的实体类
     * @return *
     * @author Frank.Tang
     */
    @Transactional(rollbackFor = Exception.class)
    public int add(BillAddOrUpdateVo entity) {
        //校验
        checkAdd(entity);

        entity.setFbmBillGenerateTime(new Date());
        entity.setFbmBillGenerateWay(BillGenerateWayEnum.MANUAL.getValue());
        entity.setFbmBillState(BillStateEnum.APPROVING.getValue());
        entity.setFbmMatchedAmount(0.0);
        entity.setFbmNotMatchAmount(Math.abs(entity.getFbmBillAmount()));
        entity.setFbmTurnerDeal(TurnerSingleOverTimeEnum.NO.getState());
        fncBillManagementService.add(entity);

        log.info("用户【{}】, 新增账单(id【{}】)", JWTUtil.getNikeName(), entity.getFbmId());

        return BaseConstants.YES;
    }

    /**
     * 账单管理: 删除
     * @author Frank.Tang
     * @param isContractDel 合同删除时调用?
     * @return *
     */
    public int del(Long id, boolean isContractDel) {
        //check
        FncBillManagement bill = checkDel(id, isContractDel);

        bill.setDr(BaseConstants.DR_YES);

        fncBillManagementService.updateSelective(bill);

        log.info("用户【{}】, 删除账单(id【{}】)", JWTUtil.getNikeName(), id);

        return BaseConstants.YES;
    }

    /**
     * 账单管理: 审批(驳回/通过)
     * @param id            账单id
     * @param approveStatus 审批结果
     * @return *
     * @author Frank.Tang
     */
    @Transactional(rollbackFor = Exception.class)
    public int approve(Long id, Integer approveStatus) {
        //check
        FncBillManagement bill = checkApprove(id, approveStatus);

        bill.setFbmBillState(approveStatus);

        fncBillManagementService.update(bill);

        log.info("用户【{}】, 审核账单(id【{}】), 审核结果【{}】", JWTUtil.getNikeName(), id,
                BillStateEnum.UNPAID.getValue().equals(approveStatus) ? "通过" : "驳回");

        return BaseConstants.YES;
    }

    /**
     * 账单管理: 重新发起审批(驳回 --> 待审批)
     * @param bill 账单实体类
     * @return *
     * @author Frank.Tang
     */
    @Transactional(rollbackFor = Exception.class)
    public int relaunchApprove(BillAddOrUpdateVo bill) {
        //check
        checkRelaunchApprove(bill);

        bill.setFbmBillState(BillStateEnum.APPROVING.getValue());

        //更新未匹配金额
        StreamUtil.execSetter(bill.getFbmBillAmount() != null, bill::setFbmNotMatchAmount, bill.getFbmBillAmount());

        fncBillManagementService.updateSelective(bill);

        log.info("用户【{}】, 对账单(id【{}】)重新发起审批", JWTUtil.getNikeName(), bill.getFbmId());

        return BaseConstants.YES;
    }

    /**
     * 账单管理: 申请开票
     * @param id 账单id
     * @return *
     * @author Frank.Tang
     */
    @Transactional(rollbackFor = Exception.class)
    public int applyInvoice(Long id) {
        //check
        FncBillManagement bill = checkApplyInvoice(id);

        bill.setFbmBillState(BillStateEnum.INVOICING.getValue());

        fncBillManagementService.update(bill);

        log.info("用户【{}】, 对账单(id【{}】)申请开票", JWTUtil.getNikeName(), bill.getFbmId());

        return BaseConstants.YES;
    }

    /**
     * 账单管理: 申请开票(批量)
     * @param ids 账单ids
     * @return *
     * @author Frank.Tang
     */
    @Transactional(rollbackFor = Exception.class)
    public int applyInvoiceBatch(List<Long> ids) {
        CheckUtil.isEmptyWithEx(ids, ExMsgConstants.RECEIVE_NULL_ID);
        if (ids.isEmpty()) {
            throw new GlobalException("数据异常, 请选择账单进行操作");
        }
        for (Long id : ids) {
            applyInvoice(id);
        }
        return ids.size();
    }

    /**
     * 账单管理: 确认开票
     * @param id 账单id
     * @author Frank.Tang
     * @return *
     */
    @Transactional(rollbackFor = Exception.class)
    public int confirmInvoice(Long id) {
        //check
        FncBillManagement bill = checkConfirmInvoice(id);

        bill.setFbmBillState(BillStateEnum.INVOICED.getValue());

        fncBillManagementService.update(bill);

        log.info("用户【{}】, 对账单(id【{}】)确认开票", JWTUtil.getNikeName(), bill.getFbmId());

        return BaseConstants.YES;
    }

    /**
     * 账单管理: 确认开票(批量)
     * @param ids 账单ids
     * @author Frank.Tang
     * @return *
     */
    @Transactional(rollbackFor = Exception.class)
    public int confirmInvoiceBatch(List<Long> ids) {
        CheckUtil.isEmptyWithEx(ids, ExMsgConstants.RECEIVE_NULL_ID);
        if (ids.isEmpty()) {
            throw new GlobalException("数据异常, 请选择账单进行操作");
        }
        for (Long id : ids) {
            confirmInvoice(id);
        }
        return ids.size();
    }

    /**
     * 账单匹配流水(手动)
     * @param vo 前端传值
     * @return *
     * @author Frank.Tang
     */
    @Transactional(rollbackFor = Exception.class)
    public int manuallyMatch(BillMatchWaterVo vo) {
        log.info("用户【{}】, 对账单(id【{}】, 发起手动匹配", JWTUtil.getNikeName(), vo.getFbmId());

        CheckUtil.isEmptyWithEx(vo, ExMsgConstants.RECEIVE_NULL_PARA);

        Long fbmId = vo.getFbmId();
        String waterInfo = vo.getWaterInfo();
        BigDecimal matchMoney = vo.getMatchMoney();

        //限制输入金额>0
        CheckUtil.isEmptyWithEx(matchMoney, ExMsgConstants.RECEIVE_NULL_PARA + "(匹配金额)");
        if (matchMoney.compareTo(BigDecimal.ZERO) <= 0) {
            throw new GlobalException("操作失败, 输入的匹配金额不能小于等于0");
        }

        //基本数据校验+数据准备
        FncBillManagement bill = checkBill(fbmId, matchMoney);
        Object[] waterInfos = checkWaterInfo(waterInfo);

        //根据流水的类型,选择匹配策略
        MatchStrategyExecutor executor = new MatchStrategyExecutor(waterInfos, bill, matchMoney);
        executor.execute();

        return BaseConstants.YES;
    }


    /********************************************************************************************
     *                                            Checks
     ********************************************************************************************
     **
     * 新增校验,同时设置其车辆id:
     *   (1)检查是否接到数据  (2)检查关键元素是否为空
     *   (3)校验数据正确性
     * @author Frank.Tang
     */
    private void checkAdd(BillAddOrUpdateVo entity) {
        //(1)
        CheckUtil.isEmptyWithEx(entity, ExMsgConstants.RECEIVE_NULL_ENTITY);

        //(2)
        Integer subjects = entity.getFbmSubjects();
        Double amount = entity.getFbmBillAmount();
        Date generateTime = entity.getFbmBillGenerateTime();
        Date catoffTime = entity.getFbmBillCatoffTime();
        String plateNum = entity.getPlateNum();
        String genReason = entity.getFbmBillGenerateReason();
        String voucher = entity.getFbmBillVoucher();
        String associateContractNo = entity.getAssociateContractNo();
        CheckUtil.isEmptyWithEx(subjects, ExceptionUtil.nullMsg("科目"));
        CheckUtil.isEmptyWithEx(amount, ExceptionUtil.nullMsg("账单金额"));
        CheckUtil.isEmptyWithEx(catoffTime, ExceptionUtil.nullMsg("截止时间"));
        CheckUtil.isEmptyWithEx(genReason, ExceptionUtil.nullMsg("生成原因"));
        CheckUtil.isEmptyWithEx(associateContractNo, ExceptionUtil.nullMsg("关联合同号 "));

        //(3)
        //3.1枚举
        if ("".equals(BillSubjectsEnum.getName(subjects))) {
            throw ExceptionUtil.enumNotExist("科目类型");
        }
        //3.2长度
        if (genReason.length() > LenConstants.LEN_255) {
            throw ExceptionUtil.outLen("生成原因");
        }
        if (voucher != null && voucher.length() > LenConstants.LEN_2550) {
            throw ExceptionUtil.outLen("账单凭证url");
        }
        if (entity.getRemark() != null && entity.getRemark().length() > LenConstants.LEN_255) {
            throw ExceptionUtil.outLen("备注");
        }
        //3.3车牌号存在性
        if (plateNum != null) {
            ResCar car = resCarQueryClient.findPlateNum(plateNum).getDataWithEx();
            if (car == null) {
                throw ExceptionUtil.notExist("车牌号", plateNum);
            } else {
                entity.setFbmAssociateCarId(car.getRcId());
            }
        }
        //3.4关联合同
        List<FncContractManagement> contracts = fncContractManagementService.getByCode(associateContractNo);
        if (contracts.isEmpty()) {
            throw ExceptionUtil.notExist("关联合同号.", associateContractNo);
        } else if (contracts.size() > 1) {
            throw new GlobalException("数据异常, 合同号【" + associateContractNo + "】查询到重复数据, 请联系管理员");
        } else {
            //关联合同字段设置
            FncContractManagement contractManagement = contracts.get(0);
            entity.setFbmCityId(contractManagement.getFcmCityId());
            entity.setFbmAssociateContractId(contractManagement.getFcmId());
        }
        //3.5为0情况
        if (amount == 0.0) {
            throw new GlobalException("操作失败, 账单金额不能为0");
        }
        //3.6生成截止日关系
        if (generateTime != null && generateTime.after(catoffTime)) {
            throw new GlobalException("操作失败, 截止日不能晚于生成日");
        }
    }

    /**
     * 账单申请开票校验:
     *   (1)参数是否为空  (2)数据库中是否有数据 (3)状态是否满足
     * @author Frnk.Tang
     * @return id对应的实体类
     */
    private FncBillManagement checkApplyInvoice(Long id) {
        //(1)
        CheckUtil.isEmptyWithEx(id, ExceptionUtil.idNotExistMsg(id));

        //(2)
        FncBillManagement bill = fncBillManagementService.getById(id);
        if (bill == null || BaseConstants.DR_YES.equals(bill.getDr())) {
            throw ExceptionUtil.notExist("账单id", id);
        }

        //(3)
        Integer state = bill.getFbmBillState();
        if (!BillStateEnum.PAID_ALL.getValue().equals(state)) {
            throw new GlobalException("操作失败, 只有[已支付]的账单才能申请开票");
        }
        return bill;
    }

    /**
     * 删除校验:
     *   (1)参数  (2)数据存在 (3)状态满足
     * @author Frank.Tang
     */
    private FncBillManagement checkDel(Long id, boolean isContractDel) {
        //(1)
        CheckUtil.isEmptyWithEx(id, ExMsgConstants.RECEIVE_NULL_ID);
        //(2)
        FncBillManagement bill = fncBillManagementService.getById(id);
        if (bill == null || BaseConstants.DR_YES.equals(bill.getDr())) {
            throw ExceptionUtil.idNotExist(id);
        }
        //(3)
        Integer billState = bill.getFbmBillState();
        if (!isContractDel && !BillStateEnum.REJECTED.getValue().equals(billState)
                && !BillStateEnum.APPROVING.getValue().equals(billState)) {
            throw new GlobalException("操作失败, 只有[审核中]或[已驳回]的账单才能删除");
        }
        return bill;
    }

    /**
     * 账单确认开票校验:
     *   (1)参数是否为空  (2)数据库中是否有数据 (3)状态是否满足
     * @author Frnk.Tang
     * @return id对应的实体类
     */
    private FncBillManagement checkConfirmInvoice(Long id) {
        //(1)
        CheckUtil.isEmptyWithEx(id, ExceptionUtil.idNotExistMsg(id));

        //(2)
        FncBillManagement entity = fncBillManagementService.getById(id);
        if (entity == null || BaseConstants.DR_YES.equals(entity.getDr())) {
            throw ExceptionUtil.notExist("账单id", id);
        }

        //(3)
        Integer state = entity.getFbmBillState();
        if (!BillStateEnum.INVOICING.getValue().equals(state)) {
            throw new GlobalException("操作失败, 只有[开票中]的账单才能确认开票");
        }
        return entity;
    }

    /**
     * 审核账单校验:
     *   (1)参数是否为空  (2)数据库中是否有数据
     *   (3)账单状态      (4)审核状态(通过或驳回)
     * @author Frank.Tang
     * @return id对应的实体类
     */
    private FncBillManagement checkApprove(Long id, Integer approveStatus) {
        //(1)
        CheckUtil.isEmptyWithEx(id, ExceptionUtil.idNotExistMsg(id));

        //(2)
        FncBillManagement bill = fncBillManagementService.getById(id);
        if (bill == null || BaseConstants.DR_YES.equals(bill.getDr())) {
            throw ExceptionUtil.notExist("账单id", id);
        }

        //(3)
        Integer state = bill.getFbmBillState();
        if (!BillStateEnum.APPROVING.getValue().equals(state)) {
            throw new GlobalException("操作失败, 只有[审批中]的账单才能进行审批");
        }

        //(4)
        if (!BillStateEnum.UNPAID.getValue().equals(approveStatus)
                && !BillStateEnum.REJECTED.getValue().equals(approveStatus)) {
            throw new GlobalException("数据异常, 审核状态仅限: 1(同意) / 2(驳回)");
        }

        return bill;
    }

    /**
     * 审核账单校验
     *   (1)参数是否为空  (2)数据库中是否有数据
     *   (3)数据的正确性  (4)状态是否满足
     * @author Frank.Tang
     */
    private void checkRelaunchApprove(BillAddOrUpdateVo entity) {
        //(1)
        CheckUtil.isEmptyWithEx(entity, ExMsgConstants.RECEIVE_NULL_ENTITY);

        Long id = entity.getFbmId();
        CheckUtil.isEmptyWithEx(id, ExMsgConstants.RECEIVE_NULL_ID);

        //(2)
        FncBillManagement billFromDb = fncBillManagementService.getById(id);
        if (billFromDb == null || BaseConstants.DR_YES.equals(billFromDb.getDr())) {
            throw ExceptionUtil.notExist("账单id", id);
        }

        Integer subjects = entity.getFbmSubjects();
        String plateNum = entity.getPlateNum();
        String genReason = entity.getFbmBillGenerateReason();
        String voucher = entity.getFbmBillVoucher();
        String associateContractNo = entity.getAssociateContractNo();

        //(3)
        //3.1枚举
        if ("".equals(BillSubjectsEnum.getName(subjects))) {
            throw ExceptionUtil.enumNotExist("科目类型");
        }
        //3.2长度
        if (genReason != null && genReason.length() > LenConstants.LEN_255) {
            throw ExceptionUtil.outLen("生成原因");
        }
        if (voucher != null && voucher.length() > LenConstants.LEN_2550) {
            throw ExceptionUtil.outLen("账单凭证url");
        }
        if (entity.getRemark() != null && entity.getRemark().length() > LenConstants.LEN_255) {
            throw ExceptionUtil.outLen("备注");
        }
        //3.3车牌号存在性
        if (plateNum != null) {
            ResCar car = resCarQueryClient.findPlateNum(plateNum).getDataWithEx();
            if (car == null) {
                throw ExceptionUtil.notExist("车牌号", plateNum);
            } else {
                entity.setFbmAssociateCarId(car.getRcId());
            }
        }
        //3.4关联合同
        List<FncContractManagement> contracts = fncContractManagementService.getByCode(associateContractNo);
        contracts = contracts.stream().filter(o -> BaseConstants.DR_NO.equals(o.getDr())).collect(Collectors.toList());
        if (contracts.isEmpty()) {
            throw ExceptionUtil.notExist("关联合同号", associateContractNo);
        }
        if (contracts.size() > 1) {
            throw new GlobalException("数据异常, 合同号【" + associateContractNo + "】查询到重复数据, 请联系管理员");
        }
        FncContractManagement contract = contracts.get(0);
        if (BaseConstants.DR_YES.equals(contract.getDr())) {
            throw ExceptionUtil.notExist("关联合同号", associateContractNo);
        }

        //(4)
        Integer state = billFromDb.getFbmBillState();
        if (!BillStateEnum.REJECTED.getValue().equals(state)) {
            throw new GlobalException("操作失败, 只有[已驳回]的账单才能重新发起");
        }
    }

    /**
     * 手动匹配校验01:
     *   (1)账单是否存在  (2)账单状态
     * @author Frank.Tang
     * @return id对应的实体类
     */
    private FncBillManagement checkBill(Long fbmId, BigDecimal matchMoney) {
        CheckUtil.isEmptyWithEx(fbmId, ExMsgConstants.RECEIVE_NULL_PARA);

        FncBillManagement bill = fncBillManagementService.getById(fbmId);
        //(1)
        if (bill == null || BaseConstants.DR_YES.equals(bill.getDr())) {
            throw ExceptionUtil.notExist("账单id", fbmId);
        }
        //(2)
        Integer state = bill.getFbmBillState();
        if (!BillStateEnum.UNPAID.getValue().equals(state)
                && !BillStateEnum.PAID_PART.getValue().equals(state)
                && !BillStateEnum.OVERDUE.getValue().equals(state)) {
            throw new GlobalException("操作失败, 只有[未支付]或[部分支付]或[已逾期]的账单才能进行匹配");
        }

        //输入的金额,大于了账单还剩下的,抛异常
        if ((matchMoney.compareTo(BigDecimal.valueOf(bill.getFbmNotMatchAmount())) > 0)) {
            throw new GlobalException(OUT_OF_BILL_AMOUNT);
        }

        return bill;
    }

    /**
     * 手动匹配校验02, 并返回标识及id:
     *   (1)格式   (2)前缀合法性   (3)id合法性
     * @author Frank.Tang
     * @return [流水类型, 流水的id]
     */
    private Object[] checkWaterInfo(String waterInfo) {
        CheckUtil.isEmptyWithEx(waterInfo, ExMsgConstants.RECEIVE_NULL_PARA);

        waterInfo = waterInfo.trim();
        //(1)
        if (!WATER_INFO_PATTERN.matcher(waterInfo).matches()) {
            throw new GlobalException("操作失败, 流水信息的格式有误。正确格式: xx100");
        }

        //前缀(支持大小写)
        String prefix = waterInfo.substring(0, 2).toUpperCase();
        //后缀(id)
        String suffix = waterInfo.replaceAll("[A-Za-z]{2}", "");

        //(2)
        int type = -1;
        boolean prefixMatched = false;
        for (WaterMatchTypeEnum value : WaterMatchTypeEnum.values()) {
            if (value.getName().equals(prefix)) {
                prefixMatched = true;
                type = value.getValue();
                break;
            }
        }
        if (!prefixMatched) {
            throw new GlobalException("操作失败, 前缀格式错误。正确示例: YH、DD、TT");
        }

        //(3)
        BigDecimal longMaxValue = BigDecimal.valueOf(Long.MAX_VALUE);
        BigDecimal waterId = new BigDecimal(suffix);
        if (longMaxValue.compareTo(waterId) < 0 || longMaxValue.compareTo(BigDecimal.ZERO) == 0) {
            throw new GlobalException("操作失败, 后缀范围异常。合法范围(1~2^63-1)");
        }

        return new Object[]{type, waterId.longValue()};
    }


    /********************************************************************************************
     *                                  Manually Match Strategies
     ********************************************************************************************
     **
     * 手动匹配策略: 执行类
     * @author Frank.Tang
     */
    class MatchStrategyExecutor {
        private final Long waterId;
        private final Integer waterType;
        private final FncBillManagement bill;
        private final BigDecimal matchMoney;

        public MatchStrategyExecutor(Object[] waterInfos, FncBillManagement bill, BigDecimal matchMoney) {
            //拿到check时得到的id+类型
            this.waterId = (Long) waterInfos[1];
            this.waterType = (Integer) waterInfos[0];
            this.bill = bill;
            this.matchMoney = matchMoney;
        }

        /**
         * 根据类型选择匹配策略.后续有新增则需要扩充if-else和新增匹配策略
         * @author Frank.Tang
         */
        public void execute() {
            //负数账单只能匹配银行流水
            if (bill.getFbmBillAmount() < 0.0 && !WaterMatchTypeEnum.YH.getValue().equals(waterType)) {
                throw new GlobalException("操作失败, 负数账单只能匹配银行流水");
            }

            //银行流水
            MatchStrategy strategy;
            if (WaterMatchTypeEnum.YH.getValue().equals(waterType)) {
                strategy = new MatchStrategyYh(bill, waterId, matchMoney);
            }
            //滴滴代扣
            else if (WaterMatchTypeEnum.DD.getValue().equals(waterType)) {
                strategy = new MatchStrategyDd(bill, waterId, matchMoney);
            }
            //T3代扣
            else if (WaterMatchTypeEnum.TT.getValue().equals(waterType)) {
                strategy = new MatchStrategyTt(bill, waterId, matchMoney);
            }
            //其它
            else {
                throw new GlobalException("不支持的匹配方式");
            }
            strategy.doMatch();
        }
    }

    /**
     * 账单匹配流水: 抽象策略类
     * @author Frank.Tang
     */
    abstract static class MatchStrategy {
        FncBillManagement bill;
        Long waterId;
        BigDecimal matchMoney;

        protected MatchStrategy(FncBillManagement bill, Long waterId, BigDecimal matchMoney) {
            this.bill = bill;
            this.waterId = waterId;
            this.matchMoney = matchMoney;
        }

        /**
         * 匹配流水的业务逻辑
         * @author Frank.Tang
         */
        abstract void doMatch();
    }

    private static final String OUT_OF_WATER_AMOUNT = "操作失败, 请确保输入的匹配金额<=流水剩下的金额";
    private static final String OUT_OF_BILL_AMOUNT = "操作失败, 请确保输入的匹配金额<=账单剩下的金额";

    /**
     * 账单匹配流水01: 银行流水
     * @author Frank.Tang
     */
    class MatchStrategyYh extends MatchStrategy {
        protected MatchStrategyYh(FncBillManagement bill, Long waterId, BigDecimal matchMoney) {
            super(bill, waterId, matchMoney);
        }

        @Override
        void doMatch() {
            FncBankWater water = fncBankWaterService.getById(waterId);
            if (water == null || BaseConstants.DR_YES.equals(water.getDr())) {
                throw ExceptionUtil.notExist("银行流水id", waterId);
            }

            Integer state = water.getFbwMatchState();
            if (WaterMatchStateEnum.ALL_MATCH.getValue().equals(state)) {
                throw new GlobalException("操作失败, 银行流水已匹配完毕, 不能再匹配");
            }

            BigDecimal billAmount = BigDecimal.valueOf(bill.getFbmBillAmount());
            BigDecimal billMatched = BigDecimal.valueOf(bill.getFbmMatchedAmount());
            BigDecimal billNotMatch = BigDecimal.valueOf(bill.getFbmNotMatchAmount());
            BigDecimal waterAmount;
            BigDecimal waterMatched = BigDecimal.valueOf(water.getFbwMatchedAmount());
            BigDecimal waterNotMatch = BigDecimal.valueOf(water.getFbwNotMatchAmount());

            //输入的金额,大于了流水还剩下的,抛异常
            if (matchMoney.compareTo(waterNotMatch) > 0) {
                throw new GlobalException(OUT_OF_WATER_AMOUNT);
            }
            //输入的金额,大于了账单还剩下的,抛异常
            if (matchMoney.compareTo(billNotMatch) > 0) {
                throw new GlobalException(OUT_OF_BILL_AMOUNT);
            }

            //账单金额为负, 流水需要为"借"
            if (billAmount.compareTo(BigDecimal.ZERO) < 0) {
                if (!WaterLoanTypeEnum.BORROW.getValue().equals(water.getFbwLoanType())) {
                    throw new GlobalException("操作失败, 账单金额为负数, 需匹配[借]类型的银行流水");
                }
                waterAmount = BigDecimal.valueOf(water.getFbwBorrowAmount());
            }
            //账单金额为正, 流水需要为"贷"
            else {
                if (!WaterLoanTypeEnum.LOAN.getValue().equals(water.getFbwLoanType())) {
                    throw new GlobalException("操作失败, 账单金额为正数, 需匹配[贷]类型的银行流水");
                }
                waterAmount = BigDecimal.valueOf(water.getFbwCreditAmount());
            }

            //取绝对值
            billAmount = billAmount.abs();
            BigDecimal waterMatchedNow = waterMatched.add(matchMoney);
            water.setFbwMatchedAmount(waterMatchedNow.doubleValue());
            water.setFbwNotMatchAmount(waterAmount.subtract(waterMatchedNow).doubleValue());

            BigDecimal billMatchedNow = billMatched.add(matchMoney);
            bill.setFbmMatchedAmount(billMatchedNow.doubleValue());
            bill.setFbmNotMatchAmount(billAmount.subtract(billMatchedNow).doubleValue());

            //更新数据 + 生成收支记录
            WaterIntegrationDto dto = new WaterIntegrationDto(water);
            updateAndGenRecordAfterMatch(bill, dto, matchMoney, false);
        }
    }

    /**
     * 账单匹配流水02: 滴滴代扣
     * @author Frank.Tang
     */
    class MatchStrategyDd extends MatchStrategy {
        protected MatchStrategyDd(FncBillManagement bill, Long waterId, BigDecimal matchMoney) {
            super(bill, waterId, matchMoney);
        }

        @Override
        void doMatch() {
            FncDdWithhold water = fncDdWithholdService.getById(waterId);
            if (water == null || BaseConstants.DR_YES.equals(water.getDr())) {
                throw ExceptionUtil.notExist("滴滴代扣id", waterId);
            }

            Integer state = water.getFdwMatchState();
            if (WaterMatchStateEnum.ALL_MATCH.getValue().equals(state)) {
                throw new GlobalException("操作失败, 该滴滴代扣已匹配完毕, 不能再匹配");
            }

            BigDecimal billAmount = BigDecimal.valueOf(bill.getFbmBillAmount());
            BigDecimal billMatched = BigDecimal.valueOf(bill.getFbmMatchedAmount());
            BigDecimal billNotMatch = BigDecimal.valueOf(bill.getFbmNotMatchAmount());
            BigDecimal waterAmount = BigDecimal.valueOf(water.getFdwTradeAmount());
            BigDecimal waterMatched = BigDecimal.valueOf(water.getFdwMatchedAmount());
            BigDecimal waterNotMatch = BigDecimal.valueOf(water.getFdwNotMatchAmount());

            //输入的金额,大于了流水还剩下的,抛异常
            if ((matchMoney.compareTo(waterNotMatch) > 0)) {
                throw new GlobalException(OUT_OF_WATER_AMOUNT);
            }
            //输入的金额,大于了账单还剩下的,抛异常
            if (matchMoney.compareTo(billNotMatch) > 0) {
                throw new GlobalException(OUT_OF_BILL_AMOUNT);
            }

            BigDecimal waterMatchedNow = waterMatched.add(matchMoney);
            water.setFdwMatchedAmount(waterMatchedNow.doubleValue());
            water.setFdwNotMatchAmount(waterAmount.subtract(waterMatchedNow).doubleValue());

            BigDecimal billMatchedNow = billMatched.add(matchMoney);
            bill.setFbmMatchedAmount(billMatchedNow.doubleValue());
            bill.setFbmNotMatchAmount(billAmount.subtract(billMatchedNow).doubleValue());

            //更新数据 + 生成收支记录
            WaterIntegrationDto dto = new WaterIntegrationDto(water);
            updateAndGenRecordAfterMatch(bill, dto, matchMoney, false);
        }
    }

    /**
     * 账单匹配流水03: T3
     * @author Frank.Tang
     */
    class MatchStrategyTt extends MatchStrategy {
        public MatchStrategyTt(FncBillManagement bill, Long waterId, BigDecimal matchMoney) {
            super(bill, waterId, matchMoney);
        }

        @Override
        void doMatch() {
            FncTtWithhold water = fncTtWithholdService.getById(waterId);
            if (water == null || BaseConstants.DR_YES.equals(water.getDr())) {
                throw ExceptionUtil.notExist("T3代扣id", waterId);
            }

            Integer state = water.getFtwMatchState();
            if (WaterMatchStateEnum.ALL_MATCH.getValue().equals(state)) {
                throw new GlobalException("操作失败, T3代扣已匹配完毕, 不能再匹配");
            }

            BigDecimal billAmount = BigDecimal.valueOf(bill.getFbmBillAmount());
            BigDecimal billMatched = BigDecimal.valueOf(bill.getFbmMatchedAmount());
            BigDecimal billNotMatch = BigDecimal.valueOf(bill.getFbmNotMatchAmount());
            BigDecimal waterAmount = BigDecimal.valueOf(water.getFtwMonthWithhold());
            BigDecimal waterMatched = BigDecimal.valueOf(water.getFtwMatchedAmount());
            BigDecimal waterNotMatch = BigDecimal.valueOf(water.getFtwNotMatchAmount());

            if (matchMoney.compareTo(billNotMatch) > 0) {
                throw new GlobalException(OUT_OF_BILL_AMOUNT);
            }
            if (matchMoney.compareTo(waterNotMatch) > 0) {
                throw new GlobalException(OUT_OF_WATER_AMOUNT);
            }

            BigDecimal waterMatchedNow = waterMatched.add(matchMoney);
            water.setFtwMatchedAmount(waterMatchedNow.doubleValue());
            water.setFtwNotMatchAmount(waterAmount.subtract(waterMatchedNow).doubleValue());

            BigDecimal billMatchedNow = billMatched.add(matchMoney);
            bill.setFbmMatchedAmount(billMatchedNow.doubleValue());
            bill.setFbmNotMatchAmount(billAmount.subtract(billMatchedNow).doubleValue());

            //更新数据 + 生成收支记录
            WaterIntegrationDto dto = new WaterIntegrationDto(water);
            updateAndGenRecordAfterMatch(bill, dto, matchMoney, false);
        }
    }

    /**
     * 匹配后, 更新账单和流水的数据, 并生成流水的收支记录 (该方法设置非"金额"字段)
     * @param bill 账单
     * @param dto 流水封装对象
     * @param matchMoney 匹配金额
     * @param isAutoMatch 自动匹配或手动匹配
     * @author Frank.Tang
     */
    public void updateAndGenRecordAfterMatch(FncBillManagement bill, WaterIntegrationDto dto,
                                             BigDecimal matchMoney, boolean isAutoMatch) {
        Long billId = bill.getFbmId();
        Long userId = JWTUtil.getUserId();
        FncRevenueWaterRecord waterRecord = new FncRevenueWaterRecord();
        AuthUser user = authUserClient.getAuthUserById(userId).getDataWithEx();
        String userNamePhone = financeUserNameFacade.getUserNamePhone(user);
        //记录的描述信息
        StringBuilder desc = new StringBuilder();
        desc.append(userNamePhone)
                .append("发起").append(isAutoMatch ? "自动" : "手动").append("匹配，匹配成功。匹配账单号")
                .append(billId).append("，")
                .append("匹配金额").append(matchMoney).append("元，")
                .append("流水剩余金额");

        //银行
        if (WaterMatchTypeEnum.YH.getValue().equals(dto.getType())) {
            FncBankWater bankWater = dto.getBankWater();
            //设置流水状态
            BigDecimal waterNotMatchedNow = BigDecimal.valueOf(bankWater.getFbwNotMatchAmount());
            if (waterNotMatchedNow.compareTo(BigDecimal.ZERO) == 0) {
                bankWater.setFbwMatchState(WaterMatchStateEnum.ALL_MATCH.getValue());
            } else {
                bankWater.setFbwMatchState(WaterMatchStateEnum.PART_MATCH.getValue());
            }
            //拼接id
            bankWater.setFbwMatchBill(MatchUtil.splicing(bankWater.getFbwMatchBill(), billId));
            bill.setFbmMatchSerialNumber(MatchUtil.splicing(
                    bill.getFbmMatchSerialNumber(),
                    WaterMatchTypeEnum.YH.getName() + bankWater.getFbwId())
            );
            bankWater.setFbwMatchType(isAutoMatch ? MatchWayEnum.AUTO.getValue() : MatchWayEnum.MANUAL.getValue());
            //设置匹配记录
            waterRecord.setFrwrRevenueId(bankWater.getFbwId());
            waterRecord.setFrwrRevenueType(WaterMatchTypeEnum.YH.getValue());
            desc.append(bankWater.getFbwNotMatchAmount()).append("元。");
            fncBankWaterService.update(bankWater);
        }
        //滴滴
        else if (WaterMatchTypeEnum.DD.getValue().equals(dto.getType())) {
            FncDdWithhold ddWater = dto.getDdWithhold();
            //设置流水状态
            BigDecimal waterNotMatchedNow = BigDecimal.valueOf(ddWater.getFdwNotMatchAmount());
            if (waterNotMatchedNow.compareTo(BigDecimal.ZERO) == 0) {
                ddWater.setFdwMatchState(WaterMatchStateEnum.ALL_MATCH.getValue());
            } else {
                ddWater.setFdwMatchState(WaterMatchStateEnum.PART_MATCH.getValue());
            }
            //拼接id
            ddWater.setFdwMatchBill(MatchUtil.splicing(ddWater.getFdwMatchBill(), billId));
            bill.setFbmMatchSerialNumber(MatchUtil.splicing(
                    bill.getFbmMatchSerialNumber(),
                    WaterMatchTypeEnum.DD.getName() + ddWater.getFdwId())
            );
            ddWater.setFdwMatchWay(isAutoMatch ? MatchWayEnum.AUTO.getValue() : MatchWayEnum.MANUAL.getValue());
            //设置匹配记录
            waterRecord.setFrwrRevenueId(ddWater.getFdwId());
            waterRecord.setFrwrRevenueType(WaterMatchTypeEnum.DD.getValue());
            desc.append(ddWater.getFdwNotMatchAmount()).append("元。");
            fncDdWithholdService.update(ddWater);
        }
        //T3
        else if (WaterMatchTypeEnum.TT.getValue().equals(dto.getType())) {
            FncTtWithhold ttWater = dto.getTtWithhold();
            //设置流水状态
            BigDecimal waterNotMatchedNow = BigDecimal.valueOf(ttWater.getFtwNotMatchAmount());
            if (waterNotMatchedNow.compareTo(BigDecimal.ZERO) == 0) {
                ttWater.setFtwMatchState(WaterMatchStateEnum.ALL_MATCH.getValue());
            } else {
                ttWater.setFtwMatchState(WaterMatchStateEnum.PART_MATCH.getValue());
            }
            //拼接id
            ttWater.setFtwMatchBill(MatchUtil.splicing(ttWater.getFtwMatchBill(), billId));
            bill.setFbmMatchSerialNumber(MatchUtil.splicing(
                    bill.getFbmMatchSerialNumber(),
                    WaterMatchTypeEnum.TT.getName() + ttWater.getFtwId())
            );
            ttWater.setFtwMatchWay(isAutoMatch ? MatchWayEnum.AUTO.getValue() : MatchWayEnum.MANUAL.getValue());
            //设置匹配记录
            waterRecord.setFrwrRevenueId(ttWater.getFtwId());
            waterRecord.setFrwrRevenueType(WaterMatchTypeEnum.TT.getValue());
            desc.append(ttWater.getFtwNotMatchAmount()).append("元。");
            fncTtWithholdService.update(ttWater);
        }
        //不存在的情况
        else {
            throw new GlobalException("暂不支持的匹配类型");
        }

        //账单更新
        bill.setFbmMatchUserId(userId);
        bill.setFbmMatchTime(new Date());
        bill.setFbmMatchWay(isAutoMatch ? MatchWayEnum.AUTO.getValue() : MatchWayEnum.MANUAL.getValue());
        BigDecimal billNotMatchNow = BigDecimal.valueOf(bill.getFbmNotMatchAmount());
        if (billNotMatchNow.compareTo(BigDecimal.ZERO) == 0) {
            bill.setFbmBillState(BillStateEnum.PAID_ALL.getValue());
        } else {
            bill.setFbmBillState(BillStateEnum.PAID_PART.getValue());
        }
        fncBillManagementService.update(bill);

        //收支记录生成
        waterRecord.setFrwrBillId(billId);
        waterRecord.setFrwrDescribe(desc.toString());
        waterRecord.setFrwrMatchState(isAutoMatch ? MatchWayEnum.AUTO.getValue() : MatchWayEnum.MANUAL.getValue());
        fncRevenueWaterRecordService.add(waterRecord);
    }

    /**
     * mq回调
     * @param requestJson
     */
    @Transactional(rollbackFor = Exception.class)
    public void payNotify(String requestJson) {
        Map<String, String> notifyMap = JSON.parseObject(requestJson, new TypeReference<HashMap<String, String>>(HashMap.class) {
        });
        String transactionId = notifyMap.get("transaction_id");
        log.info("transactionId==>>:{}", transactionId);
        String nonceStr = notifyMap.get("nonce_str");
        String outTradeNo = notifyMap.get("out_trade_no").split("-")[0];
        log.info("回调获取到的账单号为：{}", outTradeNo);
        MrkPayRecord mrkPayRecord = payCenterClient.findPayRecordByNonceStr(nonceStr).getDataWithEx();
        FncBillManagement fncBillManagement = fncBillManagementService.getById(Long.valueOf(outTradeNo));
        if (CheckUtil.isEmpty(fncBillManagement)) {
            throw new GlobalException("不存在此账单");
        }
        //支付明细查询
        MrkPayDetail mrkPayDetail = payCenterClient.findMrkPayDetail(mrkPayRecord.getMprPayDetail()).getDataWithEx();
        //账单单id
        String businessMark = mrkPayDetail.getBusinessMark();
        String redisLockKey = BILL_MANAGEMENT_KEY + businessMark;
        RedisLock redisLock = new RedisLock(stringRedisTemplate, redisLockKey, 5000);

        // 分布式锁保证 支付处理
        if (redisLock.tryLock()) {
            try {
                //修改账单支付状态 以及拼接匹配流水号，修改已匹配和未匹配金额等
                fncBillManagement.setFbmBillState(BillStateEnum.PAID_ALL.getValue());
                BigDecimal bigDecimal = BigDecimal.valueOf(mrkPayDetail.getTotalFee());
                BigDecimal decimal = new BigDecimal("100");
                BigDecimal divide = bigDecimal.divide(decimal, 2, RoundingMode.HALF_UP);
                fncBillManagement.setFbmMatchedAmount(divide.doubleValue());
                fncBillManagement.setFbmNotMatchAmount(0.0D);
                fncBillManagement.setFbmPayTime(new Date());
                String bmMatchSerialNumberStr = MatchUtil.splicing(fncBillManagement.getFbmMatchSerialNumber(), mrkPayDetail.getTransactionId());
                fncBillManagement.setFbmMatchSerialNumber(bmMatchSerialNumberStr);
                fncBillManagementService.update(fncBillManagement);
                //收支记录
            } finally {
                // 释放锁
                redisLock.unlock();
            }
        }
    }


}
