package com.mrk.finance.dto.fncttexport;

import com.mrk.finance.model.FncTtWithhold;
import io.swagger.annotations.ApiModelProperty;
import lombok.Getter;
import lombok.Setter;

@Setter
@Getter
public class FncTtWithholdDto extends FncTtWithhold {


    /**车型文本 */
    @ApiModelProperty(value = "车型文本")
    private String ftwCarModelText;

    /**匹配状态文本 */
    @ApiModelProperty(value = "匹配状态文本")
    private String ftwMatchStateText;


    /**匹配方式文本 */
    @ApiModelProperty(value = "匹配方式文本")
    private String ftwMatchWayText;

    /**城市文本 */
    @ApiModelProperty(value = "城市文本")
    private String ftwCityIdText;

    }
