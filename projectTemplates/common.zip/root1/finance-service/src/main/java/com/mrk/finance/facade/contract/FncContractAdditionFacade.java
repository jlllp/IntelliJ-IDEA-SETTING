package com.mrk.finance.facade.contract;

import com.mrk.common.constant.BaseConstants;
import com.mrk.common.exception.GlobalException;
import com.mrk.common.utils.jwt.JWTUtil;
import com.mrk.common.utils.text.CheckUtil;
import com.mrk.finance.constants.ExMsgConstants;
import com.mrk.finance.dto.FncBillManagementDto;
import com.mrk.finance.enums.*;
import com.mrk.finance.model.FncBillManagement;
import com.mrk.finance.model.FncContractAddition;
import com.mrk.finance.model.FncContractManagement;
import com.mrk.finance.queryvo.FncBillManagementQueryVo;
import com.mrk.finance.queryvo.FncContractAdditionQueryVo;
import com.mrk.finance.service.FncBillManagementService;
import com.mrk.finance.service.FncContractAdditionService;
import com.mrk.finance.service.FncContractManagementService;
import com.mrk.finance.util.ExceptionUtil;
import com.mrk.finance.util.contract.ContractDateCalculateUtil;
import com.mrk.resource.client.ResCarQueryClient;
import com.mrk.resource.model.ResCar;
import com.mrk.universal.enums.contract.ContractLeaseStartTypeEnum;
import com.mrk.universal.enums.turner.TurnerSingleOverTimeEnum;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

import java.util.Arrays;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.stream.Collectors;

/**
 * @project: mrk-finance
 * @author: Frank.Tang
 * @date: 2021-11-12 11:12
 * @desc:
 **/
@Slf4j
@Component
public class FncContractAdditionFacade {

    @Autowired
    private ResCarQueryClient resCarQueryClient;
    @Autowired
    private FncBillManagementService fncBillManagementService;
    @Autowired
    private FncContractAdditionService fncContractAdditionService;
    @Autowired
    private FncContractManagementService fncContractManagementService;

    /**
     * Date的时分秒置为0
     *
     * @return *
     * @author Frank.Tang
     */
    public static Date clearHms(Date now) {
        Calendar cal1 = Calendar.getInstance();
        cal1.setTime(now);
        cal1.set(Calendar.HOUR_OF_DAY, 0);
        cal1.set(Calendar.MINUTE, 0);
        cal1.set(Calendar.SECOND, 0);
        cal1.set(Calendar.MILLISECOND, 0);
        return cal1.getTime();
    }

    /**
     * 补充协议: 新增
     *
     * @param entity 前端传的实体
     * @return *
     * @author Frank.Tang
     */
    @Transactional(rollbackFor = Exception.class)
    public int add(FncContractAddition entity) {
        //check
        checkAdd(entity);

        fncContractAdditionService.add(entity);

        log.info("用户【{}】, 对合同(id【{}】), 增加补充协议(id【{}】)", JWTUtil.getNikeName(), entity.getFcaContractId(), entity.getFcaId());

        return BaseConstants.YES;
    }

    /**
     * 补充协议: 批量新增
     *
     * @param entities entity数组
     * @return *
     * @author Frank.Tang
     */
    @Transactional(rollbackFor = Exception.class)
    public int addBatch(List<FncContractAddition> entities) {
        if (entities == null || entities.isEmpty()) {
            throw new GlobalException(ExMsgConstants.RECEIVE_NULL_PARA);
        }

        for (FncContractAddition entity : entities) {
            add(entity);
        }

        return entities.size();
    }

    /********************************************************************************************
     *                                            checks
     ********************************************************************************************
     **
     * 新增校验:
     *   (1)检查是否接到数据         (2)检查关键元素是否为空
     *   (3)合同校验,及一些特殊校验  (4)车牌号校验
     *   (5)重复                    (6)还车和解除租赁, 只能存在一个
     *
     * 特殊: 选择"解除租赁合同", 会终止原合同, 同时根据支付类型, 可能会生成账单 (见2.3)
     *
     * @author Frank.Tang
     */
    private void checkAdd(FncContractAddition entity) {
        //(1)
        CheckUtil.isEmptyWithEx(entity, ExMsgConstants.RECEIVE_NULL_ENTITY);

        //(2)
        Integer type = entity.getFcaType();
        Long contractId = entity.getFcaContractId();
        String associateContractNo = entity.getFcaAssociateContractNo();
        String contractNo = entity.getFcaContractNo();
        CheckUtil.isEmptyWithEx(type, ExceptionUtil.nullMsg("补充合同类型"));
        CheckUtil.isEmptyWithEx(contractId, ExceptionUtil.nullMsg("关联合同id"));
        CheckUtil.isEmptyWithEx(associateContractNo, ExceptionUtil.nullMsg("关联合同的合同号"));
        CheckUtil.isEmptyWithEx(contractNo, ExceptionUtil.nullMsg("补充合同的合同号"));

        //(6)
        FncContractAdditionQueryVo queryVo0 = new FncContractAdditionQueryVo();
        queryVo0.setFcaContractIdEqualTo(contractId);
        queryVo0.setFcaTypeIn(Arrays.asList(
                ContractAdditionTypeEnum.EARLY_RETURN.getValue(),
                ContractAdditionTypeEnum.TERMINATE.getValue()
        ));
        List<FncContractAddition> additions = fncContractAdditionService.list(queryVo0);
        if (!ContractAdditionTypeEnum.CAR_CHANGE.getValue().equals(type) && !additions.isEmpty()) {
            throw new GlobalException("操作失败, [提前还车]或[解除租赁]协议最多存在一个, 不能再添加");
        }

        //2.1提前还车
        if (ContractAdditionTypeEnum.EARLY_RETURN.getValue().equals(type)) {
            Date endDate = entity.getFcaLeaseEndDate();
            CheckUtil.isEmptyWithEx(endDate, ExceptionUtil.nullMsg("租赁结束日期"));
            entity.setFcaNewCarPlateNum(null);
            entity.setFcaNewHandoverDate(null);
            entity.setFcaOldCarReturnDate(null);
            entity.setFcaInformationFee(null);
            entity.setFcaContractTerminateDate(null);
            entity.setFcaPayType(null);

            FncContractManagement contract = fncContractManagementService.getById(contractId);
            if (contract == null || BaseConstants.DR_YES.equals(contract.getDr())) {
                throw ExceptionUtil.idNotExist(contractId);
            }

            //合同开始<日期<合同结束
            Date contractLeaseStartDate = contract.getFcmLeaseStartDate();
            Date contractLeaseEndDate = contract.getFcmLeaseEndDate();
            if (contractLeaseStartDate != null && endDate.before(contractLeaseStartDate)) {
                throw new GlobalException("操作失败, 日期不能小于合同的[开始日期]");
            }
            if (contractLeaseEndDate != null && endDate.after(contractLeaseEndDate)) {
                throw new GlobalException("操作失败, 日期不能大于合同的[结束日期]");
            }

        }
        //2.2换车
        else if (ContractAdditionTypeEnum.CAR_CHANGE.getValue().equals(type)) {
            //(4)
            String plateNum = entity.getFcaNewCarPlateNum();
            ResCar car = resCarQueryClient.findPlateNum(plateNum).getDataWithEx();
            if (car == null) {
                throw ExceptionUtil.notExist("车牌号", plateNum);
            }

            Date newHandoverDate = entity.getFcaNewHandoverDate();
            Date oldCarReturnDate = entity.getFcaOldCarReturnDate();
            CheckUtil.isEmptyWithEx(plateNum, ExceptionUtil.nullMsg("新车车牌号"));
            CheckUtil.isEmptyWithEx(newHandoverDate, ExceptionUtil.nullMsg("新车交付日期"));
            CheckUtil.isEmptyWithEx(oldCarReturnDate, ExceptionUtil.nullMsg("旧车归还日期"));

            if (oldCarReturnDate.after(newHandoverDate)) {
                throw new GlobalException("操作失败, [旧车归还日期]不能晚于[新车交付日期]");
            }
            entity.setFcaLeaseEndDate(null);
            entity.setFcaInformationFee(null);
            entity.setFcaContractTerminateDate(null);
            entity.setFcaPayType(null);

            //有[还车/解除]合同, 需要在[当前时间, 相应补充合同的时间]范围内
            if (!additions.isEmpty()) {
                FncContractAddition addition = additions.get(0);
                Date nowDate = clearHms(new Date());
                Date leaseEndDate = addition.getFcaLeaseEndDate();
                Date terminateDate = addition.getFcaContractTerminateDate();

                //提前还车
                if (ContractAdditionTypeEnum.EARLY_RETURN.getValue().equals(addition.getFcaType())) {
                    if (newHandoverDate.before(nowDate) || newHandoverDate.after(leaseEndDate)) {
                        throw new GlobalException("操作失败, 请确保[新车交付日期]在: [当前日期~提前还车协议的'租赁结束日期'] 之间");
                    }
                    if (oldCarReturnDate.before(nowDate) || oldCarReturnDate.after(leaseEndDate)) {
                        throw new GlobalException("操作失败, 请确保[旧车归还日期]在: [当前日期~提前还车协议的'租赁结束日期'] 之间");
                    }
                }
                //解除租赁
                else if (ContractAdditionTypeEnum.TERMINATE.getValue().equals(addition.getFcaType())) {
                    if (newHandoverDate.before(nowDate) || newHandoverDate.after(terminateDate)) {
                        throw new GlobalException("操作失败, 请确保[新车交付日期]在: [当前日期~解除租赁协议的'解除合同日期'] 之间");
                    }
                    if (oldCarReturnDate.before(nowDate) || oldCarReturnDate.after(terminateDate)) {
                        throw new GlobalException("操作失败, 请确保[新车交付日期]在: [当前日期~解除租赁协议的'解除合同日期'] 之间");
                    }
                }
            }
        }
        //2.3解除租赁合同
        else if (ContractAdditionTypeEnum.TERMINATE.getValue().equals(type)) {
            Integer payType = entity.getFcaPayType();
            Double informationFee = entity.getFcaInformationFee();
            Date terminateDate = entity.getFcaContractTerminateDate();
            CheckUtil.isEmptyWithEx(terminateDate, ExceptionUtil.nullMsg("解除合同日期"));
            CheckUtil.isEmptyWithEx(informationFee, ExceptionUtil.nullMsg("信息服务费"));
            CheckUtil.isEmptyWithEx(payType, ExceptionUtil.nullMsg("支付方式"));
            entity.setFcaLeaseEndDate(null);
            entity.setFcaNewCarPlateNum(null);
            entity.setFcaNewHandoverDate(null);
            entity.setFcaOldCarReturnDate(null);
            if ("".equals(ContractAdditionPayTypeEnum.getName(payType))) {
                throw ExceptionUtil.enumNotExist("支付方式");
            }

            FncContractManagement contract = fncContractManagementService.getById(contractId);
            if (contract == null || BaseConstants.DR_YES.equals(contract.getDr())) {
                throw ExceptionUtil.idNotExist(contractId);
            }

            //terminateDate不能小于租赁起始日期
            if (contract.getFcmLeaseStartDate() != null && terminateDate.before(contract.getFcmLeaseStartDate())) {
                throw new GlobalException("操作失败, [解除合同日期]不能小于[租赁起始日期]");
            }

            //以[交车日期]为租赁起始日期，且[未提车]的合同才可以新增解除租赁合同协议
            if (ContractLeaseStartTypeEnum.DELIVERY_DATE.getValue().equals(contract.getFcmLeaseStartType())
                    && contract.getFcmLeaseStartDate() != null) {
                throw new GlobalException("操作失败, 该合同的【租赁起始类型】为【交车日期】, 且【已提车】, 不能解除租赁合同");
            }

            //选择[保证金或租金抵扣]时，原合同的[保证金或租金]账单必须为已支付状态，否则无法提交成功。
            if (!ContractAdditionPayTypeEnum.NEW_BILL_PAY.getValue().equals(payType)) {
                FncBillManagementQueryVo queryVo2 = new FncBillManagementQueryVo();
                queryVo2.setFbmAssociateContractIdEqualTo(contractId);
                if (ContractAdditionPayTypeEnum.MARGIN_DEDUCTION.getValue().equals(payType)) {
                    queryVo2.setFbmSubjectsEqualTo(BillSubjectsEnum.BOND.getValue());
                } else if (ContractAdditionPayTypeEnum.RENT_DEDUCTION.getValue().equals(payType)) {
                    queryVo2.setFbmSubjectsEqualTo(BillSubjectsEnum.RENT.getValue());
                } else {
                    throw new GlobalException("暂不支持的方式");
                }
                List<FncBillManagement> bills = fncBillManagementService.list(queryVo2);
                List<FncBillManagement> unpaidBills = bills.stream()
                        .filter(o -> o.getFbmBillState() < BillStateEnum.PAID_ALL.getValue())
                        .collect(Collectors.toList());
                if (!unpaidBills.isEmpty()) {
                    //true=保证金, false=租金
                    boolean b = ContractAdditionPayTypeEnum.MARGIN_DEDUCTION.getValue().equals(payType);
                    String errorMsg = String.format(
                            "操作失败, 支付方式选择【%s】时, 关联合同的所有【%s】账单需为【已支付】状态（未完成支付的账单id%s）",
                            (b ? "保证金" : "租金"),
                            (b ? "保证金" : "租金"),
                            Arrays.toString(unpaidBills.stream().map(FncBillManagement::getFbmId).toArray())
                    );
                    throw new GlobalException(errorMsg);
                }
            }

            //选择新账单支付的，原合同自动生成一条未支付账单
            if (ContractAdditionPayTypeEnum.NEW_BILL_PAY.getValue().equals(payType)) {
                FncBillManagement newBill = new FncBillManagementDto();
                newBill.setFbmBillAmount(informationFee);
                newBill.setFbmMatchedAmount(0.0);
                newBill.setFbmNotMatchAmount(informationFee);
                newBill.setFbmAssociateContractId(contractId);
                newBill.setFbmCityId(contract.getFcmCityId());
                //默认一个月之后
                newBill.setFbmBillCatoffTime(ContractDateCalculateUtil.getFewMonthLaterDate(new Date(), 1));
                newBill.setFbmBillState(BillStateEnum.UNPAID.getValue());
                newBill.setFbmSubjects(BillSubjectsEnum.INFORMATION.getValue());
                newBill.setFbmBillGenerateWay(BillGenerateWayEnum.AUTO.getValue());
                newBill.setFbmBillGenerateTime(new Date());
                newBill.setFbmBillGenerateReason(String.format("合同(合同号【%s】), 新增解除租赁协议, 支付方式选择【新账单支付】, 自动生成账单", contract.getFcmContractNo()));
                newBill.setFbmTurnerDeal(TurnerSingleOverTimeEnum.NO.getState());
                fncBillManagementService.add(newBill);
            }
        }
        //2.4异常
        else {
            throw ExceptionUtil.enumNotExist("协议类型");
        }

        //(3)
        FncContractManagement contract = fncContractManagementService.getById(contractId);
        if (contract == null || BaseConstants.DR_YES.equals(contract.getDr())) {
            throw ExceptionUtil.idNotExist(contractId);
        }
        if (!associateContractNo.equals(contract.getFcmContractNo())) {
            throw new GlobalException("数据异常, 合同号【" + associateContractNo + "】不属于合同id" + contractId);
        }

        //(5)
        FncContractAdditionQueryVo queryVo3 = new FncContractAdditionQueryVo();
        queryVo3.setFcaContractNoEqualTo(contractNo);
        List<FncContractAddition> additionsFromDb = fncContractAdditionService.list(queryVo3);
        if (!additionsFromDb.isEmpty()) {
            throw ExceptionUtil.duplicate("补充协议编号", contractNo);
        }
    }

}
