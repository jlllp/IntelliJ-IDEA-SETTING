package com.mrk.finance.facade.quartz;

import com.mrk.finance.enums.ContractStateEnum;
import com.mrk.finance.model.FncContractAddition;
import com.mrk.finance.service.FncContractAdditionService;
import com.mrk.finance.service.FncContractManagementService;
import com.mrk.finance.util.StreamUtil;
import com.mrk.finance.util.contract.ContractDateCalculateUtil;
import io.seata.common.util.CollectionUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.Date;
import java.util.List;

/**
 * @author Bob
 * @date 2021/12/24
 * @description
 */
@Component
public class CheckStopFacade {

    @Autowired
    private FncContractAdditionService fncContractAdditionService;

    @Autowired
    private FncContractManagementService fncContractManagementService;

    private static final Logger log = LoggerFactory.getLogger(CheckStopFacade.class);

    /**
     * @author Bob
     * @date 2021/12/24
     * @description 处理合同中止
     * @param paramStr 请求参数
     */
    public void checkStop(String paramStr) {
        log.info("处理合同中止 --> 开始");
        long start = System.currentTimeMillis();
        // 获取一个月内的租赁中止补充协议和提前还车协议
        Date today = ContractDateCalculateUtil.ignoreHoursMinutesAndSeconds(new Date());
        Date aMonthAgo = ContractDateCalculateUtil.increaseMonth(today, -1);
        List<FncContractAddition> fncContractAdditions = fncContractAdditionService.getByLeaseEnd(aMonthAgo, today);
        fncContractAdditions.addAll(fncContractAdditionService.getByTerminate(aMonthAgo, today));
        // 获取到要租赁中止的合同id
        List<Long> contractIds = StreamUtil.toList(fncContractAdditions, FncContractAddition::getFcaContractId);
        // 中止合同
        if (CollectionUtils.isNotEmpty(contractIds)) {
            fncContractManagementService.updateStateByStateAndIds(ContractStateEnum.LEASE_SUSPENSION.getState(), contractIds);
        }
        log.info("处理合同中止 --> 结束，耗时：【{}】", System.currentTimeMillis() - start);
    }
}
