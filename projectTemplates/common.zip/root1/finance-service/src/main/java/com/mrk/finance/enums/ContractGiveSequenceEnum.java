package com.mrk.finance.enums;

import lombok.Getter;

/**
 * @project: mrk-finance
 * @author: Frank.Tang
 * @date: 2021-11-18 14:09
 * @desc:
 **/
@Getter
public enum ContractGiveSequenceEnum {

    /***/
    BEFORE(0, "先赠送"),
    AFTER(1, "后赠送");

    private Integer value;
    private String name;

    ContractGiveSequenceEnum(Integer value, String name) {
        this.value = value;
        this.name = name;
    }

    public static String getName(Integer state) {
        if (state == null) {
            return "";
        }
        for (ContractGiveSequenceEnum statusEnum : values()) {
            if (statusEnum.getValue().equals(state)) {
                return statusEnum.getName();
            }
        }
        return "";
    }


}
