package com.mrk.finance.controller;

import com.github.pagehelper.PageInfo;
import com.mrk.common.utils.page.JsonResult;
import com.mrk.finance.dto.FncConfirmIncomeDto;
import com.mrk.finance.facade.FncConfirmIncomeFacade;
import com.mrk.finance.queryvo.FncConfirmIncomeQueryVo;
import com.mrk.log.annotation.Log;
import com.mrk.log.enums.BusinessType;
import com.mrk.log.enums.OperatorType;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiImplicitParam;
import io.swagger.annotations.ApiImplicitParams;
import io.swagger.annotations.ApiOperation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import javax.servlet.http.HttpServletResponse;


/**
 * FncConfirmIncomeController

 */
@RestController
@RequestMapping("/financeservice/fncconfirmincome")
@Api(tags = "/确认收入")
public class FncConfirmIncomeController {


    @Autowired
    private FncConfirmIncomeFacade fncConfirmIncomeFacade;

    @GetMapping(value = "/page")
    @ApiOperation("确认收入-分页查询")
    @ApiImplicitParams({
            @ApiImplicitParam(paramType = "header", name = "Authorization", value = "系统下发的token", required = true)
    })
    public JsonResult<PageInfo<FncConfirmIncomeDto>> page(FncConfirmIncomeQueryVo queryVo) {
        //转换数据，资产所有者
        return JsonResult.success(fncConfirmIncomeFacade.page(queryVo));
    }

    @GetMapping(value = "/export")
    @ApiOperation("确认收入-导出")
    @ApiImplicitParams({
      @ApiImplicitParam(paramType = "header", name = "Authorization", value = "系统下发的token", required = true)
    })
    @Log(title = "确认收入", businessType = BusinessType.EXPORT, operatorType = OperatorType.MANAGE, isSaveRequestData = true, value = "确认收入-导出")
    public void export(FncConfirmIncomeQueryVo queryVo, HttpServletResponse response) {
        fncConfirmIncomeFacade.export(queryVo, response);
    }

}
