package com.mrk.finance.facade.contract;

import cn.afterturn.easypoi.word.WordExportUtil;
import com.mrk.auth.model.AuthCity;
import com.mrk.auth.model.AuthDept;
import com.mrk.common.exception.GlobalException;
import com.mrk.common.utils.text.CheckUtil;
import com.mrk.common.utils.time.DateUtils;
import com.mrk.finance.dto.ContractDocxExport;
import com.mrk.finance.model.FncContractManagement;
import com.mrk.finance.model.FncContractRentalFees;
import com.mrk.finance.model.FncRentalFees;
import com.mrk.finance.remote.AuthCityRPC;
import com.mrk.finance.remote.AuthDeptRPC;
import com.mrk.finance.remote.MemberRPC;
import com.mrk.finance.remote.SysCarTypeRPC;
import com.mrk.finance.resolver.EnumResolver;
import com.mrk.finance.service.FncContractManagementService;
import com.mrk.finance.service.FncContractRentalFeesService;
import com.mrk.finance.service.FncRentalFeesService;
import com.mrk.finance.util.PdfUtils;
import com.mrk.finance.util.StrUtil;
import com.mrk.finance.util.StreamUtil;
import com.mrk.finance.util.TransformUtil;
import com.mrk.member.client.dto.MrkMemberRentDto;
import com.mrk.member.model.MrkMember;
import com.mrk.sys.model.SysCarType;
import com.mrk.universal.enums.contract.ContractLeaseStartTypeEnum;
import com.mrk.universal.enums.contract.ContractPartyTypeEnum;
import com.mrk.universal.enums.contract.ContractTypeEnum;
import org.apache.poi.xwpf.usermodel.XWPFDocument;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import javax.servlet.http.HttpServletResponse;
import java.util.*;

/**
 * @author jlllp
 * @date 2022/6/16
 * @description
 */
@Component
public class ContractPdfFacade {

    private static final String RENT_AND_LEASE = "docx/车联科技车辆租赁合同模板（20220401）.docx";
    private static final String RENT_AND_SELL = "docx/车联科技车辆租售合同模板（20220401）.docx";
    @Autowired
    private FncContractManagementService fncContractManagementService;
    @Autowired
    private AuthDeptRPC authDeptRPC;
    @Autowired
    private MemberRPC memberRPC;
    @Autowired
    private SysCarTypeRPC sysCarTypeRPC;
    @Autowired
    private AuthCityRPC authCityRPC;
    @Autowired
    private FncContractRentalFeesService fncContractRentalFeesService;
    @Autowired
    private FncRentalFeesService fncRentalFeesService;

    /**
     * 将合同以PDF方式进行下载
     *
     * @param response   响应对象
     * @param contractId 合同id
     */
    public void downPdf(HttpServletResponse response, Long contractId) {
        CheckUtil.isEmptyWithEx(contractId, "合同ID不能为空");
        FncContractManagement fncContractManagement = fncContractManagementService.getById(contractId);
        CheckUtil.isEmptyWithEx(fncContractManagement, "合同不存在，请检查数据");
        // 租赁合同和租售合同的模板不一样
        ContractDocxExport contractDocxExport = new ContractDocxExport();
        contractDocxExport.setContractNumber(fncContractManagement.getFcmContractNo());
        // 转换甲方信息
        AuthDept aAuthDept = authDeptRPC.getAuthDeptById(fncContractManagement.getFcmPartyaId());
        contractDocxExport.setPartyA(StrUtil.objectToString(aAuthDept.getDeptName()));
        contractDocxExport.setATaxpayerNumber(StrUtil.objectToString(aAuthDept.getDeptTaxpayerNo()));
        contractDocxExport.setAContactAddress(StrUtil.objectToString(aAuthDept.getDeptRelationAddress()));
        contractDocxExport.setARepresentative(StrUtil.objectToString(aAuthDept.getDeptLegalRepresentative()));
        contractDocxExport.setAContact(StrUtil.objectToString(aAuthDept.getDeptContact()));
        contractDocxExport.setAContactInformation(StrUtil.objectToString(aAuthDept.getDeptContactPhone()));
        contractDocxExport.setAEmail(StrUtil.objectToString(aAuthDept.getDeptEmail()));
        contractDocxExport.setABillingAddress(StrUtil.objectToString(aAuthDept.getDeptInvoiceAddress()));
        contractDocxExport.setABillingPhone(StrUtil.objectToString(aAuthDept.getDeptInvoiceTelephone()));
        contractDocxExport.setADepositBank(StrUtil.objectToString(aAuthDept.getDeptOpenBank()));
        contractDocxExport.setABankAccount(StrUtil.objectToString(aAuthDept.getDeptBankAccount()));

        // 转换乙方信息
        // 组织
        if (ContractPartyTypeEnum.ORGANIZATION.getValue().equals(fncContractManagement.getFcmPartybType())) {
            AuthDept bAuthDept = authDeptRPC.getAuthDeptById(fncContractManagement.getFcmPartybId());
            contractDocxExport.setPartyB(StrUtil.objectToString(bAuthDept.getDeptName()));
            contractDocxExport.setBTaxpayerNumber(StrUtil.objectToString(aAuthDept.getDeptTaxpayerNo()));
            contractDocxExport.setBContactAddress(StrUtil.objectToString(aAuthDept.getDeptRelationAddress()));
            contractDocxExport.setBRepresentative(StrUtil.objectToString(aAuthDept.getDeptLegalRepresentative()));
            contractDocxExport.setBContact(StrUtil.objectToString(aAuthDept.getDeptContact()));
            contractDocxExport.setBContactInformation(StrUtil.objectToString(aAuthDept.getDeptContactPhone()));
            contractDocxExport.setBEMail(StrUtil.objectToString(aAuthDept.getDeptEmail()));
            contractDocxExport.setBSBillingAddress(StrUtil.objectToString(aAuthDept.getDeptInvoiceAddress()));
            contractDocxExport.setBBillingPhone(StrUtil.objectToString(aAuthDept.getDeptInvoiceTelephone()));
            contractDocxExport.setBSBank(StrUtil.objectToString(aAuthDept.getDeptOpenBank()));
            contractDocxExport.setBBankAccountNumber(StrUtil.objectToString(aAuthDept.getDeptBankAccount()));

        }
        // 个人
        else if (ContractPartyTypeEnum.PERSONAL.getValue().equals(fncContractManagement.getFcmPartybType())) {
            MrkMember mrkMember = memberRPC.findById(fncContractManagement.getFcmPartybId());
            MrkMemberRentDto memberRentDto = memberRPC.getRentById(fncContractManagement.getFcmPartybId());
            contractDocxExport.setPartyB(StrUtil.objectToString(mrkMember.getMmName()));
            contractDocxExport.setBContactAddress(StrUtil.objectToString(memberRentDto.getMmrLelationAddress()));
            contractDocxExport.setBContactInformation(StrUtil.objectToString(mrkMember.getMmMobile()));
            contractDocxExport.setBEMail(StrUtil.objectToString(memberRentDto.getMmrEmail()));
            contractDocxExport.setBSBank(StrUtil.objectToString(memberRentDto.getMmrOpenBank()));
            contractDocxExport.setBBankAccountNumber(StrUtil.objectToString(memberRentDto.getMmrBankAccount()));
            contractDocxExport.setBTaxpayerNumber("");
            contractDocxExport.setBRepresentative("");
            contractDocxExport.setBContact("");
            contractDocxExport.setBSBillingAddress("");
            contractDocxExport.setBBillingPhone("");


        }

        SysCarType sysCarType = sysCarTypeRPC.getById(fncContractManagement.getFcmId());
        if (Objects.nonNull(sysCarType)) {
            contractDocxExport.setVehicleType(StrUtil.objectToString(sysCarType.getCarTypeName()));
        } else {
            contractDocxExport.setVehicleType("");
        }

        AuthCity authCity = authCityRPC.getCityById(fncContractManagement.getFcmSignedAddr());
        if (Objects.nonNull(authCity)) {
            contractDocxExport.setPlaceOfContract(StrUtil.objectToString(authCity.getCityName()));
        } else {
            contractDocxExport.setPlaceOfContract("");
        }
        contractDocxExport.setNumberOfVehicles(StrUtil.objectToString(fncContractManagement.getFcmCarnumTotal()));
        contractDocxExport.setVehicleNature(StrUtil.objectToString(fncContractManagement.getFcmCarNature()));

        authCity = authCityRPC.getCityById(fncContractManagement.getFcmDeliverCity());
        if (Objects.nonNull(authCity)) {
            contractDocxExport.setVehicleDeliveryLocation(StrUtil.objectToString(authCity.getCityName()));
        } else {
            contractDocxExport.setVehicleDeliveryLocation("");
        }
        contractDocxExport.setPaymentMethod(StrUtil.objectToString(EnumResolver.保证金支付要求.get(fncContractManagement.getFcmMarginPayRequire())));
        contractDocxExport.setNumberOfLeasePeriods(StrUtil.objectToString(fncContractManagement.getFcmLeaseCount()));
        contractDocxExport.setRent(StrUtil.objectToString(fncContractManagement.getFcmLeaseAmount()));
        contractDocxExport.setSecurityDeposit(StrUtil.objectToString(fncContractManagement.getFcmMarginMoney()));

        authCity = authCityRPC.getCityById(fncContractManagement.getFcmReturnCity());
        if (Objects.nonNull(authCity)) {
            contractDocxExport.setVehicleReturnLocation(StrUtil.objectToString(authCity.getCityName()));
        } else {
            contractDocxExport.setVehicleReturnLocation("");
        }
        contractDocxExport.setSubletting(StrUtil.objectToString(EnumResolver.合同是否转租.get(fncContractManagement.getFcmSublet())));

        // 租金包含费用处理
        contractDocxExport.setChargeDetails(contractRentalFess(contractId));

        contractDocxExport.setUse(StrUtil.objectToString(fncContractManagement.getFcmUse()));

        if (ContractLeaseStartTypeEnum.IDENTIFIED_DATE.getValue().equals(fncContractManagement.getFcmLeaseStartType())) {
            Date fcmLeaseStartDate = fncContractManagement.getFcmLeaseStartDate();
            Date fcmLeaseEndDate = fncContractManagement.getFcmLeaseEndDate();
            String startDateStr = DateUtils.parseDateToStr("yyyy年MM月dd日", fcmLeaseStartDate);
            String endDateStr = DateUtils.parseDateToStr("yyyy年MM月dd日", fcmLeaseEndDate);
            contractDocxExport.setLeaseStartDate(StrUtil.objectToString(startDateStr));
            contractDocxExport.setLeaseExpiryDate(StrUtil.objectToString(endDateStr));
        } else {
            contractDocxExport.setLeaseStartDate("见实际交车日期");
            contractDocxExport.setLeaseExpiryDate("根据实际交车日期推算");
        }

        Map<String, Object> entityToMap = TransformUtil.entityToMap(fncContractManagement);

        if (ContractTypeEnum.LEASE_AND_LEASE.getType().equals(fncContractManagement.getFcmContractType())) {
            // 租赁合同模板
            try {
                XWPFDocument doc = WordExportUtil.exportWord07(RENT_AND_LEASE, entityToMap);
                PdfUtils.docx2Pdf(doc, response.getOutputStream());
            } catch (Exception e) {
                throw new GlobalException("导出PDF失败", e);
            }
        } else if (ContractTypeEnum.LEASE_AND_SALE.getType().equals(fncContractManagement.getFcmContractType())) {
            // 租售合同模板
            try {
                XWPFDocument doc = WordExportUtil.exportWord07(RENT_AND_SELL, entityToMap);
                PdfUtils.docx2Pdf(doc, response.getOutputStream());
            } catch (Exception e) {
                throw new GlobalException("导出PDF失败", e);
            }
        }
    }

    /**
     * 组装合同下的租金包含费用
     *
     * @param contractId 合同ID
     * @return 租金包含费用明细
     */
    public String contractRentalFess(Long contractId) {
        String contain = "■";
        String doesNotContain = "□";
        String specialKey = "commercial_insurance";
        String specialStr = "商业险(三者 %s 万元)";
        List<FncRentalFees> fncRentalFees = fncRentalFeesService.getAll();
        List<FncContractRentalFees> fncContractRentalFees = fncContractRentalFeesService.getByContractId(contractId);
        Map<Long, FncContractRentalFees> contractRentalFeesMap = StreamUtil.toMap(fncContractRentalFees, FncContractRentalFees::getFcrfRentFeesId);
        Set<Long> rentalFreeIds = contractRentalFeesMap.keySet();
        StringBuilder sb = new StringBuilder();

        for (FncRentalFees fncRentalFee : fncRentalFees) {

            // 包含
            if (rentalFreeIds.contains(fncRentalFee.getFrfId())) {
                String name = fncRentalFee.getFrfName();
                // 特殊标识处理填充
                if (specialKey.equals(fncRentalFee.getFrfMark())) {
                    name = String.format(specialStr, contractRentalFeesMap.get(fncRentalFee.getFrfId()).getFcrfValue());
                }
                sb.append(contain).append(name);
            }
            // 不包含
            else {
                String name = fncRentalFee.getFrfName();
                // 特殊标识处理填充
                if (specialKey.equals(fncRentalFee.getFrfMark())) {
                    name = String.format(specialStr, "  ");
                }
                sb.append(doesNotContain).append(name);
            }
        }
        return sb.toString();
    }
}
