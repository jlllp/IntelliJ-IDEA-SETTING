package com.mrk.finance.enums;

import lombok.Getter;

/**
 * @project: mrk-finance
 * @author: Frank.Tang
 * @date: 2021-11-15 10:04
 * @desc: 合同租金类型
 **/
@Getter
public enum ContractLeaseTypeEnum {

    /***/
    FIXED(0, "固定"),
    NOT_FIXED(1, "不固定");

    private Integer value;
    private String name;

    ContractLeaseTypeEnum(Integer value, String name) {
        this.value = value;
        this.name = name;
    }

    public static String getName(Integer state) {
        if (state == null) {
            return "";
        }
        for (ContractLeaseTypeEnum statusEnum : values()) {
            if (statusEnum.getValue().equals(state)) {
                return statusEnum.getName();
            }
        }
        return "";
    }

}
