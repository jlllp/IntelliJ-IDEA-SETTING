package com.mrk.finance.facade.quartz;

import com.mrk.common.constant.BaseConstants;
import com.mrk.common.exception.GlobalException;
import com.mrk.common.utils.text.CheckUtil;
import com.mrk.finance.enums.BillGenerateWayEnum;
import com.mrk.finance.enums.BillStateEnum;
import com.mrk.finance.enums.BillSubjectsEnum;
import com.mrk.finance.enums.ContractStateEnum;
import com.mrk.finance.facade.contract.ContractOnlyCarFacade;
import com.mrk.finance.model.FncBillManagement;
import com.mrk.finance.model.FncContractManagement;
import com.mrk.finance.service.FncBillManagementService;
import com.mrk.finance.service.FncContractManagementService;
import com.mrk.finance.util.StreamUtil;
import com.mrk.finance.util.contract.ContractDateCalculateUtil;
import org.apache.commons.collections4.CollectionUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

/**
 * @author Bob
 * @date 2021-11-17
 * @description
 */
@Component
public class DepositRefundFacade {

    private static final Logger log = LoggerFactory.getLogger(DepositRefundFacade.class);

    @Autowired
    private FncBillManagementService fncBillManagementService;

    @Autowired
    private FncContractManagementService fncContractManagementService;

    @Autowired
    private ContractOnlyCarFacade contractOnlyCarFacade;

    /**
     * @author Bob
     * @date 2021/11/17
     * @description 保证金退还账单生成
     * @param paramStr 请求参数 一般为空
     */
    public void depositRefundGeneration(String paramStr) {
        log.info("保证金退还账单生成 --> 开始");
        long startTime = System.currentTimeMillis();
        // 获取系统中已经存在保证金退还的账单
        List<FncBillManagement> fncBillManagementList = fncBillManagementService.getBySubjectAndAmountLT(BillSubjectsEnum.BOND.getValue(), 0D);
        // 获取存在保证金退还账单的合同ID集合
        List<Long> contractIds = StreamUtil.toList(fncBillManagementList, FncBillManagement::getFbmAssociateContractId);
        log.info("保证金退还账单生成 获取到已经生成退还账单的数量 --> size：【{}】", contractIds.size());
        // 合同有效期到期第二天生成保证金退还账单，账单截止时间为有效期往后推一个月
        // 如果当前合同存在续租合同，那么则不用生成保证金退还账单
        // 当前日期减一天和租赁结束时间相同的合同即代表合同需要生成保证金退还账单
        Date date = new Date();
        date = ContractDateCalculateUtil.increaseDay(date, -1);
        SimpleDateFormat simpleDateFormat = new SimpleDateFormat("yyyy-MM-dd");
        String formatDate = simpleDateFormat.format(date);
        Date yesterday;
        try {
            yesterday = simpleDateFormat.parse(formatDate);
        } catch (ParseException e) {
            log.error("解析失败失败", e);
            throw new GlobalException("计算失败失败，任务中止");
        }
        // 构建存放待生成保证金退还的合同
        List<FncContractManagement> contractManagementList;
        if (CollectionUtils.isEmpty(contractIds)) {
            contractManagementList = fncContractManagementService.getByStateAndEndDateLTOE(ContractStateEnum.LEASE_TO_END.getState(), yesterday);
        } else {
            contractManagementList = fncContractManagementService.getByStateAndEndDateLTOEAndIdNotIn(ContractStateEnum.LEASE_TO_END.getState(), yesterday, contractIds);
        }
        log.info("保证金退还账单生成 获取到需要生成保证金退还的账单数量--> size：【{}】", contractManagementList.size());
        if (CollectionUtils.isEmpty(contractManagementList)) {
            return;
        }

        // 构建待创建的账单
        List<FncBillManagement> fncBillManagements = new ArrayList<>();
        Date today = ContractDateCalculateUtil.increaseDay(yesterday, 1);
        Date endDay = ContractDateCalculateUtil.increaseMonth(yesterday, 1);
        for (FncContractManagement fncContractManagement : contractManagementList) {
            // 保证金为空  跳过
            if (CheckUtil.isEmpty(fncContractManagement.getFcmMarginTotal())){
                log.info("保证金退还账单生成 保证金金额为空，跳过--> contractId：【{}】", fncContractManagement.getFcmId());
                continue;
            }
            FncBillManagement fncBillManagement = new FncBillManagement();
            fncBillManagement.setFbmCityId(fncContractManagement.getFcmCityId());
            fncBillManagement.setFbmSubjects(BillSubjectsEnum.BOND.getValue());
            fncBillManagement.setFbmBillAmount(-fncContractManagement.getFcmMarginTotal());
            fncBillManagement.setFbmNper("/");
            fncBillManagement.setFbmBillGenerateTime(today);
            fncBillManagement.setFbmBillGenerateWay(BillGenerateWayEnum.AUTO.getValue());
            fncBillManagement.setFbmBillCatoffTime(endDay);
            // 合同只有一辆车的情况下才写入车辆id
            Long carId = contractOnlyCarFacade.getCarIdByContract(fncContractManagement);
            fncBillManagement.setFbmAssociateCarId(carId);
            fncBillManagement.setFbmAssociateContractId(fncContractManagement.getFcmId());
            fncBillManagement.setFbmBillState(BillStateEnum.UNPAID.getValue());
            fncBillManagement.setFbmMatchedAmount(0D);
            fncBillManagement.setFbmNotMatchAmount(fncContractManagement.getFcmMarginTotal());
            fncBillManagement.setCreatetime(new Date());
            fncBillManagement.setDr(BaseConstants.DR_NO);
            fncBillManagements.add(fncBillManagement);
        }
        fncBillManagementService.batchAdd(fncBillManagements);
        log.info("保证金退还账单生成 --> 结束 耗时：【{}】", System.currentTimeMillis() - startTime);
    }

}
