package com.mrk.finance.provider;

import com.alibaba.fastjson.JSON;
import com.github.pagehelper.PageInfo;
import com.mrk.common.exception.GlobalException;
import com.mrk.common.utils.bean.BeanUtils;
import com.mrk.common.utils.container.ListUtil;
import com.mrk.common.utils.page.JsonResult;
import com.mrk.common.utils.text.CheckUtil;
import com.mrk.common.utils.text.StringUtils;
import com.mrk.common.utils.time.DateUtils;
import com.mrk.finance.client.FncContractManagementClient;
import com.mrk.finance.client.dto.*;
import com.mrk.finance.dto.FncManagementRiskDto;
import com.mrk.finance.dto.contract.RentCalculationDto;
import com.mrk.finance.enums.ContractStateEnum;
import com.mrk.finance.facade.common.CommonFacade;
import com.mrk.finance.facade.contract.FncContractAnalysisFacade;
import com.mrk.finance.facade.contract.FncContractManagementFacade;
import com.mrk.finance.model.FncContractCarmodel;
import com.mrk.finance.model.FncContractManagement;
import com.mrk.finance.model.FncContractRent;
import com.mrk.finance.queryvo.FncContractCarmodelQueryVo;
import com.mrk.finance.queryvo.FncContractManagementQueryVo;
import com.mrk.finance.service.FncContractCarmodelService;
import com.mrk.finance.service.FncContractManagementService;
import com.mrk.finance.service.FncContractRentService;
import com.mrk.finance.util.StreamUtil;
import com.mrk.resource.client.ResCarOperateClient;
import com.mrk.resource.client.ResCarQueryClient;
import com.mrk.resource.client.ResParklotClient;
import com.mrk.resource.client.ResUseCarClient;
import com.mrk.resource.enums.parklot.ParklotTypeEnums;
import com.mrk.resource.model.ResCar;
import com.mrk.resource.model.ResParklot;
import com.mrk.resource.model.ResUsecarApply;
import com.mrk.universal.enums.contract.ContractLeaseStartTypeEnum;
import com.mrk.universal.enums.turner.TurnerAutoEnum;
import com.mrk.universal.enums.turner.TurnerSingleOverTimeEnum;
import com.mrk.workflow.client.Dto.CarPageDto;
import com.mrk.workflow.client.UseCarWorkflowClient;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.util.CollectionUtils;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import java.math.BigDecimal;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.*;
import java.util.stream.Collectors;


/**
 * @author Bob
 * @date 2021-09-23
 * @description
 */
@RestController
public class FncContractManagementProvider implements FncContractManagementClient {

    @Autowired
    private FncContractManagementService fncContractManagementService;

    @Autowired
    private FncContractCarmodelService fncContractCarmodelService;

    @Autowired
    private FncContractManagementFacade fncContractManagementFacade;

    @Autowired
    private ResUseCarClient resUseCarClient;

    @Autowired
    private UseCarWorkflowClient useCarWorkflowClient;

    @Autowired
    private CommonFacade commonFacade;

    @Autowired
    private FncContractRentService fncContractRentService;

    @Autowired
    private ResCarOperateClient resCarOperateClient;

    @Autowired
    private ResCarQueryClient resCarQueryClient;

    @Autowired
    private ResParklotClient resParklotClient;

    @Autowired
    private FncContractAnalysisFacade fncContractAnalysisFacade;


    @Override
    public JsonResult<FncContractManagementDto> getByFncContractManagementId(@RequestParam("fncContractManagementId") Long fncContractManagementId) {
        FncContractManagement fncContractManagement = fncContractManagementService.getById(fncContractManagementId);
        FncContractManagementDto fncContractManagementDto = BeanUtils.copyBean(fncContractManagement, FncContractManagementDto.class);
        CheckUtil.isEmptyWithEx(fncContractManagement, "合同不存在");
        return JsonResult.success(fncContractManagementDto);
    }

    @Override
    public JsonResult<List<FncContractCarDto>> getByFncContractCar(@RequestParam("fncContractManagementId") Long fncContractManagementId) {
        //该合同下所有的车型和数量
        List<FncContractCarmodel> fncContractCarmodels = fncContractCarmodelService.selectByFncContractManagementId(fncContractManagementId);

        List<FncContractCarDto> fncContractCarDtoList = ListUtil.copyBeanList(fncContractCarmodels, FncContractCarDto.class);
        return JsonResult.success(fncContractCarDtoList);
    }

    @Override
    public JsonResult<List<FncContractManagementDto>> getByFncContractNo(@RequestParam("fncContractNo") String fncContractNo) {
        List<FncContractManagement> fncContractManagementList = fncContractManagementService.getByCode(fncContractNo);
        List<FncContractManagementDto> fncContractManagementDtoList = ListUtil.copyBeanList(fncContractManagementList, FncContractManagementDto.class);
        if(CollectionUtils.isEmpty(fncContractManagementDtoList)){
            return JsonResult.success();
        }
        return JsonResult.success(fncContractManagementDtoList);
    }

    @Override
    public JsonResult<String> getContractEndDate(@RequestParam("fncContractManagementId") Long fncContractManagementId,
                                                 @RequestParam("stateDate") Date stateDate) {
        FncContractManagement fncContractManagement = fncContractManagementService.getById(fncContractManagementId);
        CheckUtil.isEmptyWithEx(fncContractManagement, "合同不存在");
        //根据合同id找到合同租金
        List<FncContractRent> fncContractRents = fncContractRentService.getByContractId(fncContractManagementId);

        FncContractManagement contract0 = new FncContractManagement();
        contract0.setFcmLeaseStartDate(stateDate);
        contract0.setFcmLeaseCount(fncContractManagement.getFcmLeaseCount());
        contract0.setFcmLeaseType(ContractLeaseStartTypeEnum.DELIVERY_DATE.getValue());
        contract0.setFcmRentPayCycle(fncContractManagement.getFcmRentPayCycle());
        contract0.setFcmRentPayType(fncContractManagement.getFcmRentPayType());
        contract0.setFcmGiveLease(fncContractManagement.getFcmGiveLease());
        contract0.setFcmGiveSequence(fncContractManagement.getFcmGiveSequence());
        String endDate = fncContractManagementFacade.calEndDate(contract0);
        SimpleDateFormat dateFormat = new SimpleDateFormat(DateUtils.YYYY_MM_DD);
        try {
            fncContractManagement.setFcmLeaseEndDate(dateFormat.parse(endDate));
            fncContractManagement.setFcmLeaseStartDate(stateDate);
        } catch (ParseException e) {
            throw new GlobalException("日期转换错误");
        }

        //计算参数初始化
        RentCalculationDto dto = new RentCalculationDto();
        dto.setVariableRentDtoList(new ArrayList<>());
        BeanUtils.copyBeanProp(fncContractManagement, dto);
        dto.setFcmGiveLease(fncContractManagement.getFcmGiveLease());
        for (FncContractRent rent : fncContractRents) {
            RentCalculationDto.VariableRentDto variableRentDto = new RentCalculationDto.VariableRentDto();
            variableRentDto.setFccEndMonth(rent.getFccEndMonth());
            variableRentDto.setFccStartMonth(rent.getFccStartMonth());
            variableRentDto.setFccRentAmount(rent.getFccRentAmount());
            dto.getVariableRentDtoList().add(variableRentDto);
        }

        BigDecimal rentTotal = fncContractManagementFacade.calRentTotal(dto);
        return JsonResult.success(endDate + "," + rentTotal.toString());

    }

    @Override
    public JsonResult<FncContractManagementDto> updateByFncContractManagementId(@RequestParam("fncContractManagementStr") String fncContractManagementStr) {
        FncContractManagementDto fncContractManagementDto = JSON.parseObject(fncContractManagementStr, FncContractManagementDto.class);
        FncContractManagement fncContractManagement = BeanUtils.copyBean(fncContractManagementDto, FncContractManagement.class);
        fncContractManagementService.update(fncContractManagement);
        return JsonResult.success(fncContractManagementDto);
    }

    @Override
    public JsonResult<List<FncContractManagementDto>> getByFncContractManagementByTrafficAnalysis(@RequestParam("fncContractManagementIdStr") String fncContractManagementIdStr) {
        List<Long> fncContractManagementIds = Arrays.stream(fncContractManagementIdStr.split(",")).map(s -> Long.parseLong(s.trim())).collect(Collectors.toList());
        List<FncContractManagementDto> fncContractManagementDto = ListUtil.copyBeanList(fncContractManagementService.getByIds(fncContractManagementIds), FncContractManagementDto.class);
        return JsonResult.success(fncContractManagementDto);
    }

    @Override
    public JsonResult<List<FncContractManagementDto>> getByFncContractManagementIdList(@RequestParam("fncContractManagementIdListStr") String fncContractManagementIdListStr) {
        List<Long> contractIdList = Arrays.stream(fncContractManagementIdListStr.split(",")).map(Long::parseLong).collect(Collectors.toList());
        //查询合同状态有效的合同
        List<FncContractManagement> fncContractManagement = fncContractManagementService.selectContractByContractIdList(contractIdList);
        List<FncContractManagementDto> fncContractManagementDto = ListUtil.copyBeanList(fncContractManagement, FncContractManagementDto.class);
        return JsonResult.success(fncContractManagementDto);
    }

    @Override
    public JsonResult<List<FncContractManagementDto>> getByRentOverTime(@RequestParam("day")Integer day) {
        //获取租赁结束日期超过三天且没有处理过收车工单的合同
        List<FncContractManagement> fncContractManagement = fncContractManagementService.selectRentTimeAndTurnerNo(day);
        for (FncContractManagement contractManagement : fncContractManagement) {
            //看是否有续签合同 并且有效的合同
            if (CheckUtil.isNotEmpty(contractManagement.getFcmAssociateContractId())) {
                FncContractManagement management = fncContractManagementService.getById(contractManagement.getFcmAssociateContractId());
                if (!ContractStateEnum.LEASED.getState().equals(management.getFcmContractState())) {
                    selectByUseCar(contractManagement);
                }
            } else {
                selectByUseCar(contractManagement);
            }

        }

        return JsonResult.success();
    }

    @Override
    public JsonResult<List<FncContractManagementDto>> getAll() {
        List<FncContractManagement> all = fncContractManagementService.getAll();
        List<FncContractManagementDto> fncContractManagementDtos = ListUtil.copyBeanList(all,FncContractManagementDto.class);
        return JsonResult.success(fncContractManagementDtos);
    }

    @Override
    public JsonResult<List<FncContractManagementDto>> getAllByType() {
        List<FncContractManagement> all = fncContractManagementService.getAllByType();
        List<FncContractManagementDto> fncContractManagementDtos = ListUtil.copyBeanList(all,FncContractManagementDto.class);
        return JsonResult.success(fncContractManagementDtos);
    }

    /**
     * 查询用车申请和车辆看当前车辆运营组织是否当前合同用车申请下面运营，是的话生成收车工单，不是的话跳过
     */
    public void selectByUseCar(FncContractManagement contractManagement) {
        //所有的用车申请
        List<ResUsecarApply> resUsecarApplies = resUseCarClient.selectContractById(contractManagement.getFcmId()).getDataWithEx();
        //找到该合同下所有的车
        ContractMementDto contractMementDto = new ContractMementDto();
        contractMementDto.setContractId(contractManagement.getFcmId());
        PageInfo<CarPageDto> carPageDtoPageInfo = commonFacade.page(contractMementDto);
        if (!CollectionUtils.isEmpty(carPageDtoPageInfo.getList()) && !CollectionUtils.isEmpty(resUsecarApplies)) {
            //用车申请组织id
            List<Long> deptIdList = resUsecarApplies.stream().map(ResUsecarApply::getRuaDept).collect(Collectors.toList());

            //List转换成String两种方式
            String deptIdListString = StringUtils.join(deptIdList, ",");

            //合同下车辆id
            List<Long> carIdList = carPageDtoPageInfo.getList().stream().map(CarPageDto::getWpwcCar).collect(Collectors.toList());

            //List转换成String两种方式
            String carIdListString = StringUtils.join(carIdList, ",");
            //可以生成收车工单的车
            List<Long> carIdListTurner = resCarOperateClient.getCarIdByDeptIdListAndCarIdList(deptIdListString, carIdListString).getDataWithEx();

            //可以生成收车工单的车,网点为空的车辆集合carIdParklot
            List<Long> carIdParklot = new ArrayList<>();
            //网点不为空的车辆集合
            List<ResCar> cars = new ArrayList<>();
            if(!CollectionUtils.isEmpty(carIdListTurner)) {
                List<ResCar> resCars = resCarQueryClient.findCars(carIdListTurner).getDataWithEx();
                for(ResCar resCar : resCars){
                    if(CheckUtil.isEmpty(resCar.getRcCarParklot())){
                        carIdParklot.add(resCar.getRcId());
                    }else {
                        cars.add(resCar);
                    }
                }
                if(!CollectionUtils.isEmpty(cars)) {
                    //处理网点组织和车辆资产所有者相同的车
                    carNoParklot(cars, contractManagement.getFcmId());
                }
            }
            //可以生成收车工单的车,网点为空的车辆
            if(!CollectionUtils.isEmpty(carIdParklot)) {
                //List转换成String两种方式
                String carIdParklotString = StringUtils.join(carIdParklot, ",");
                useCarWorkflowClient.addTurnerWorkflow(carIdParklotString, TurnerAutoEnum.CONTRACT.getState(), contractManagement.getFcmId()).getDataWithEx();
            }
        }
        //修改合同为已处理
        contractManagement.setFncTurnerSingleDeal(TurnerSingleOverTimeEnum.YES.getState());
        fncContractManagementService.update(contractManagement);
    }

    /**
     * 处理网点组织和车辆资产所有者相同的车
     * @param cars
     */
    public void  carNoParklot(List<ResCar> cars, Long typeId){
        //当资产所有者不相同时生成收车工单车辆id集合
        List<Long> carOwnerIds = new ArrayList<>();

        //当资产所有者相同时车辆集合
        List<ResCar> resCarOwners = new ArrayList<>();
        //所有车的网点组织与资产所有者相同时的网点
        List<ResParklot> resParklotOwners = new ArrayList<>();

        //所有车的网点
        List<ResParklot> resParklots = resParklotClient.getByIds(cars.stream().map(ResCar :: getRcCarParklot).map(String::valueOf).collect(Collectors.joining(","))).getDataWithEx();
        for(ResCar resCar : cars){
            if(!CollectionUtils.isEmpty(resParklots)){
                List<ResParklot> parklots = resParklots.stream().filter(x -> x.getRpId().equals(resCar.getRcCarParklot())).collect(Collectors.toList());
                if(!CollectionUtils.isEmpty(parklots)){
                    //当资产所有者不相同时生成收车工单
                    if(CheckUtil.isNotEmpty(parklots.get(0).getRpDeptId())){
                        if(!parklots.get(0).getRpDeptId().equals(resCar.getRcOwner())){
                            carOwnerIds.add(resCar.getRcId());
                        }else {
                            resCarOwners.add(resCar);
                            resParklotOwners.add(parklots.get(0));
                        }
                }
            }
          }
        }
        //可以生成收车工单的车,网点不为空并且资产所有者相同时生成收车工单车辆集合 判断网点类型是否为库房
        resCarOwnersTurner(resCarOwners,resParklotOwners, typeId);
        //可以生成收车工单的车,网点不为空并且资产所有者不相同时生成收车工单车辆id集合
        if(!CollectionUtils.isEmpty(carOwnerIds)) {
            String carOwnerIdsString = StringUtils.join(carOwnerIds, ",");
            useCarWorkflowClient.addTurnerWorkflow(carOwnerIdsString, TurnerAutoEnum.CONTRACT.getState(), typeId).getDataWithEx();
        }
    }

    /**
     * //可以生成收车工单的车,网点不为空并且资产所有者相同时生成收车工单车辆集合 判断网点类型是否为库房
     * @param resCarOwners
     */
    public void resCarOwnersTurner(List<ResCar> resCarOwners,List<ResParklot> resParklotOwners, Long typeId){
        //当资产所有者不相同时生成收车工单车辆id集合
        List<Long> carParklotOwnerIds = new ArrayList<>();
            for(ResCar resCar : resCarOwners){
                if(!CollectionUtils.isEmpty(resParklotOwners)){
                    List<ResParklot> parklots = resParklotOwners.stream().filter(x -> x.getRpId().equals(resCar.getRcCarParklot())).collect(Collectors.toList());
                    if(!CollectionUtils.isEmpty(parklots)){
                        //当资产所有者相同时，网点类型不为库房生成收车工单
                        if(!parklots.get(0).getRpParklotType().contains(ParklotTypeEnums.WAREHOUSE.name())){
                            carParklotOwnerIds.add(resCar.getRcId());
                        }
                    }
                }
            }
        //可以生成收车工单的车,网点不为空并且资产所有者相同时，网点类型不为库房时生成收车工单车辆id集合
        if(!CollectionUtils.isEmpty(carParklotOwnerIds)) {
            String carParklotOwnerIdsString = StringUtils.join(carParklotOwnerIds, ",");
            useCarWorkflowClient.addTurnerWorkflow(carParklotOwnerIdsString, TurnerAutoEnum.CONTRACT.getState() , typeId).getDataWithEx();
        }
    }


    @Override
    public JsonResult<List<FncBillManagementRiskDto>> getOverdue(@RequestParam(value = "day", required = false) Integer day) {
        if (CheckUtil.isEmpty(day)) {
            return JsonResult.success(new ArrayList<>());
        }
        List<FncManagementRiskDto> overdue = fncContractManagementFacade.getOverdue(day);
        List<FncBillManagementRiskDto> fncBillManagementRiskDtos = ListUtil.copyBeanList(overdue, FncBillManagementRiskDto.class);
        return JsonResult.success(fncBillManagementRiskDtos);
    }

    @Override
    public JsonResult<List<ContractAnalysisDto>> getContractAnalysisData() {
        return JsonResult.success(fncContractAnalysisFacade.getContractAnalysisData());
    }

    @Override
    public JsonResult<List<ContractAnalysisDto>> getContractAnalysisDataTest(@RequestParam("start") int start,
                                                                             @RequestParam("size") int size) {
        return JsonResult.success(fncContractAnalysisFacade.getContractAnalysisDataTest(start, size));
    }

    @Override
    public JsonResult<List<ContractAnalysisDto>> getContractCarModelAnalysisData() {
        return JsonResult.success(fncContractAnalysisFacade.getContractCarmodelAnalysisData());
    }

    @Override
    public JsonResult<List<ContractAnalysisDto>> getContractCarModelAnalysisDataTest(@RequestParam("start") int start,
                                                                                     @RequestParam("size") int size) {
        return JsonResult.success(fncContractAnalysisFacade.getContractCarmodelAnalysisDataTest(start, size));
    }

    @Override
    public JsonResult<List<Long>> getContractIdByType(@RequestParam("type") Integer type) {
        FncContractManagementQueryVo queryVo = new FncContractManagementQueryVo();
        queryVo.setFcmContractTypeEqualTo(type);
        queryVo.setFcmContractStateIn(Arrays.asList(
                ContractStateEnum.LEASED.getState(),
                ContractStateEnum.LEASE_SUSPENSION.getState(),
                ContractStateEnum.LEASE_TO_END.getState()
        ));
        List<FncContractManagement> list = fncContractManagementService.list(queryVo);
        return JsonResult.success(StreamUtil.toList(list, FncContractManagement::getFcmId));
    }

    @Override
    public JsonResult<List<Long>> getContractIdByCarModel(Long carModel) {
        FncContractCarmodelQueryVo queryVo = new FncContractCarmodelQueryVo();
        queryVo.setFccContractCarmodelIdEqualTo(carModel);
        List<FncContractCarmodel> list = fncContractCarmodelService.list(queryVo);
        return JsonResult.success(StreamUtil.toList(list, FncContractCarmodel::getFccContractId));
    }

    @Override
    public JsonResult<List<ContractCarModelAnalysisDto>> getContractCarModelByContractIds(@RequestParam("ids") String ids) {
        if (ids == null || ids.isEmpty()) {
            return JsonResult.success(new ArrayList<>());
        }
        List<Long> idsList = Arrays.stream(ids.split(","))
                .map(Long::valueOf)
                .collect(Collectors.toList());

        FncContractCarmodelQueryVo queryVo = new FncContractCarmodelQueryVo();
        queryVo.setFccContractIdIn(idsList);
        List<FncContractCarmodel> carmodels = fncContractCarmodelService.list(queryVo);

        List<ContractCarModelAnalysisDto> res = new ArrayList<>();
        for (FncContractCarmodel carmodel : carmodels) {
            ContractCarModelAnalysisDto dto = new ContractCarModelAnalysisDto();
            dto.setDccaContractId(carmodel.getFccContractId());
            dto.setDccaCarmodelId(carmodel.getFccContractCarmodelId());
            dto.setDccaCarNum((long) carmodel.getFccCarnum());
            res.add(dto);
        }

        return JsonResult.success(res);
    }

    @Override
    public JsonResult<Map<Long, Integer>> getSignCountByContractIds(String ids) {
        if (ids == null || ids.isEmpty()) {
            return JsonResult.success(new HashMap<>());
        }
        List<Long> idsList = Arrays.stream(ids.split(","))
                .map(Long::valueOf)
                .collect(Collectors.toList());

        FncContractCarmodelQueryVo queryVo = new FncContractCarmodelQueryVo();
        queryVo.setFccContractIdIn(idsList);
        List<FncContractCarmodel> carmodels = fncContractCarmodelService.list(queryVo);

        //按合同id分组
        Map<Long, List<FncContractCarmodel>> map = carmodels
                .stream()
                .collect(Collectors.groupingBy(FncContractCarmodel::getFccContractId));

        //List转成数量
        Map<Long, Integer> res = map.entrySet()
                .stream()
                .collect(Collectors.toMap(
                        //合同id
                        Map.Entry::getKey,
                        //carNum求和
                        o -> o.getValue().stream().map(FncContractCarmodel::getFccCarnum).reduce(Integer::sum).orElse(0)
                ));

        return JsonResult.success(res);
    }

}
