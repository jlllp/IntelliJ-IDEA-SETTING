package com.mrk.finance.dto;

import com.mrk.finance.model.FncBillManagement;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

/**
 * @project: mrk-finance
 * @author: Frank.Tang
 * @date: 2021-11-11 11:59
 * @desc:
 **/
@Data
public class FncBillManagementDto extends FncBillManagement {

    @ApiModelProperty("合同号")
    private String fbmAssociateContractNo;

    @ApiModelProperty("车牌号")
    private String fbmAssociateCarPlateNum;

    @ApiModelProperty("科目名称")
    private String fbmSubjectsName;

    @ApiModelProperty("生成方式名称")
    private String fbmBillGenerateWayName;

    @ApiModelProperty("账单状态名称")
    private String fbmBillStateName;

    @ApiModelProperty("匹配方式名称")
    private String fbmMatchWayName;

    @ApiModelProperty("城市名称")
    private String fbmCityName;

    @ApiModelProperty("匹配人姓名")
    private String fbmMatchUserName;

}
