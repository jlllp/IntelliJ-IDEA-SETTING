package com.mrk.finance.provider;

import com.alibaba.fastjson.JSON;
import com.mrk.common.exception.GlobalException;
import com.mrk.common.utils.bean.BeanUtils;
import com.mrk.common.utils.container.ListUtil;
import com.mrk.common.utils.page.JsonResult;
import com.mrk.common.utils.text.CheckUtil;
import com.mrk.common.utils.text.StringUtils;
import com.mrk.finance.client.FncBillMangementClient;
import com.mrk.finance.client.dto.ContractMementDto;
import com.mrk.finance.client.dto.FncBillManagementDto;
import com.mrk.finance.enums.BillSubjectsEnum;
import com.mrk.finance.model.FncBillManagement;
import com.mrk.finance.model.FncContractManagement;
import com.mrk.finance.service.FncBillManagementService;
import com.mrk.finance.service.FncContractManagementService;
import com.mrk.member.client.MemberClient;
import com.mrk.member.model.MrkMember;
import com.mrk.resource.client.ResCarQueryClient;
import com.mrk.resource.model.ResCar;
import com.mrk.thirdparty.client.SmsClient;
import com.mrk.universal.enums.contract.ContractPartyTypeEnum;
import com.mrk.universal.enums.turner.TurnerAutoEnum;
import com.mrk.universal.enums.turner.TurnerSingleOverTimeEnum;
import com.mrk.workflow.client.Dto.CarPageDto;
import com.mrk.workflow.client.UseCarWorkflowClient;
import io.seata.spring.annotation.GlobalTransactional;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.CollectionUtils;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;


/**
 * @date 2021-09-23
 * @author Bob
 * @description
 */
@Slf4j
@RestController
public class FncBillMangementProvider implements FncBillMangementClient {

    @Autowired
    private FncBillManagementService fncBillManagementService;

    @Autowired
    private FncContractManagementService fncContractManagementService;

    @Autowired
    private MemberClient memberClient;

    @Autowired
    private UseCarWorkflowClient useCarWorkflowClient;

    @Autowired
    private SmsClient smsClient;


    @Autowired
    private ResCarQueryClient resCarQueryClient;

    @Override
    public JsonResult<List<FncBillManagementDto>> selectFncBillManagementByContractId(@RequestParam("fncContractManagementId") Long fncContractManagementId) {
        List<FncBillManagement> fncBillManagements = fncBillManagementService.selectByContractIdAndSubject(fncContractManagementId, BillSubjectsEnum.BOND.getValue());
        List<FncBillManagementDto> fncBillManagementDtos = ListUtil.copyBeanList(fncBillManagements, FncBillManagementDto.class);
        return JsonResult.success(fncBillManagementDtos);
    }

    @Override
    public JsonResult<List<FncBillManagementDto>> updateListFncBillMangemen(@RequestParam("fncBillManagementStr") String fncBillManagementStr) {
        List<FncBillManagementDto> fncBillManagementDtos = JSON.parseArray(fncBillManagementStr,FncBillManagementDto.class);
        List<FncBillManagement> fncBillManagements = ListUtil.copyBeanList(fncBillManagementDtos, FncBillManagement.class);
        fncBillManagementService.updateList(fncBillManagements);
        return JsonResult.success(new ArrayList<>());
    }

    @Override
    public JsonResult<FncBillManagementDto> selectFncBillManagementByBillId(@RequestParam("billId") Long billId) {
        CheckUtil.isEmptyWithEx(billId, "账单主键不能为空");
        FncBillManagement fncBillManagement = fncBillManagementService.getById(billId);
        FncBillManagementDto fncBillManagementDto = BeanUtils.copyBean(fncBillManagement, FncBillManagementDto.class);
        if(CheckUtil.isNotEmpty(fncBillManagementDto.getFbmAssociateCarId())) {
            ResCar resCar = resCarQueryClient.findCarById(fncBillManagementDto.getFbmAssociateCarId()).getDataWithEx();
            if(CheckUtil.isEmpty(resCar)){
                throw new GlobalException("车辆数据异常");
            }
            fncBillManagementDto.setFbmPlateNum(resCar.getRcPlateNum());
        }
        fncBillManagementDto.setFbmSubjectsText(BillSubjectsEnum.getName(fncBillManagementDto.getFbmSubjects()));
        return JsonResult.success(fncBillManagementDto);
    }

    @Override
    public JsonResult<FncBillManagementDto> updateFncBillManagementByBill(@RequestParam("billStr") String billStr) {
        FncBillManagementDto fncBillManagementDto = JSON.parseObject(billStr, FncBillManagementDto.class);
        FncBillManagement fncBillManagement = BeanUtils.copyBean(fncBillManagementDto, FncBillManagement.class);
        fncBillManagementService.update(fncBillManagement);
        return JsonResult.success(fncBillManagementDto);
    }

    @Override
    public JsonResult<Object> selectFncBillManagementRent() {
        //获取截止日期前一天的租金账单
        List<FncBillManagement> fncBillManagements = fncBillManagementService.selectRentBill();
        if(!CollectionUtils.isEmpty(fncBillManagements)){
            List<Long> longList = fncBillManagements.stream().map(FncBillManagement::getFbmAssociateContractId).collect(Collectors.toList());
            List<FncContractManagement> fncContractManagements = fncContractManagementService.selectContractByContractIdList(longList);
            for(FncContractManagement fncContractManagement : fncContractManagements){
                //如果说是个人，发短信
                if(ContractPartyTypeEnum.PERSONAL.getValue().equals(fncContractManagement.getFcmPartybType())){
                    MrkMember mrkMember = memberClient.findByid(fncContractManagement.getFcmPartybId()).getDataWithEx();
                    // 发送短信
                    if(CheckUtil.isNotEmpty(mrkMember.getMmMobile())) {
                        smsClient.templateSendType(mrkMember.getMmMobile(), "turner_rent",
                            null,
                            0, null).getDataWithEx();
                    }
                }
            }
        }
        //获取租金账单截止日期早于等于三天的的账单
        getRentLess();
        return JsonResult.success();
    }

    /**
     * 新增一条账单数据
     * @param fncBillManagementDto 账单接收实体
     * @return
     */
    @Override
    @Transactional(rollbackFor = Exception.class)
    @GlobalTransactional(rollbackFor = Exception.class)
    public JsonResult<FncBillManagementDto> addFncBillManagement(@RequestBody FncBillManagementDto fncBillManagementDto) {
        // 参数校验
        checkAddParam(fncBillManagementDto);
        FncBillManagement fncBillManagement = new FncBillManagement();
        BeanUtils.copyBeanProp(fncBillManagementDto, fncBillManagement);
        fncBillManagementService.add(fncBillManagement);
        return JsonResult.success(fncBillManagementDto);
    }

    /**
     * 账单生成参数校验
     * @param fncBillManagementDto 账单实体
     */
    public void checkAddParam(FncBillManagementDto fncBillManagementDto) {
        CheckUtil.isEmptyWithEx(fncBillManagementDto.getFbmAssociateCarId(), "关联车辆不能为空");
        CheckUtil.isEmptyWithEx(fncBillManagementDto.getFbmAssociateContractId(), "关联合同不能为空");
        CheckUtil.isEmptyWithEx(fncBillManagementDto.getFbmSubjects(), "账单科目不能为空");
        CheckUtil.isEmptyWithEx(fncBillManagementDto.getFbmBillAmount(), "账单金额不能为空");
        CheckUtil.isEmptyWithEx(fncBillManagementDto.getFbmBillState(), "账单状态不能为空");
        CheckUtil.isEmptyWithEx(fncBillManagementDto.getFbmBillGenerateWay(), "账单生成方式不能为空");
    }

    /**
     * 获取租金账单截止日期早于等于三天的的账单
     */
    public void getRentLess() {
        //获取租金账单截止日期早于等于三天的的账单
        List<FncBillManagement> fncBillManagementList = fncBillManagementService.selectRentBillLess();
        if (!CollectionUtils.isEmpty(fncBillManagementList)) {
            //做了调整，直接循环账单

            for(FncBillManagement fncBillManagement : fncBillManagementList){
                FncContractManagement fncContractManagement = fncContractManagementService.getById(fncBillManagement.getFbmAssociateContractId());
                if(CheckUtil.isNotEmpty(fncContractManagement)){
                    //车辆id
                    List<Long> carIdList;
                    //如果说是个人，找到该合同下的车辆生成收车工单
                    if (ContractPartyTypeEnum.PERSONAL.getValue().equals(fncContractManagement.getFcmPartybType())) {
                        ContractMementDto entity = new ContractMementDto();
                        entity.setContractId(fncContractManagement.getFcmId());
                        List<CarPageDto> carPageDtoList = useCarWorkflowClient.selectByContractStr(JSON.toJSONString(entity)).getDataWithEx().getList();
                        log.info("当前合同id为【{}】",fncContractManagement.getFcmId());
                        //车辆id集合
                        if(!CollectionUtils.isEmpty(carPageDtoList)){
                            carIdList = carPageDtoList.stream().map(CarPageDto::getWpwcCar).collect(Collectors.toList());
                            //修改合同收车工单已处理

                        /*fncContractManagement.setFncTurnerSingleDeal(TurnerSingleOverTimeEnum.YES.getState());
                        fncContractManagementService.update(fncContractManagement);*/
                            //生成收车工单
                            log.info("生成收车工单车辆id集合为【{}】", carIdList);
                            if(!CollectionUtils.isEmpty(carIdList)) {
                                fncBillManagement.setFbmTurnerDeal(TurnerSingleOverTimeEnum.YES.getState());
                                fncBillManagementService.update(fncBillManagement);
                                String carIdParklotString = StringUtils.join(carIdList, ",");
                                useCarWorkflowClient.addTurnerWorkflow(carIdParklotString, TurnerAutoEnum.BILL_OVERDUE.getState(), fncBillManagement.getFbmId()).getDataWithEx();
                            }
                        }
                    }
                }
            }
        }
    }

}
