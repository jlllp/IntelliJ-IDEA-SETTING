package com.mrk.finance.facade.bill;

import com.github.pagehelper.PageInfo;
import com.mrk.auth.client.AuthDeptClient;
import com.mrk.auth.client.AuthUserClient;
import com.mrk.auth.model.AuthUser;
import com.mrk.common.base.BaseEntity;
import com.mrk.common.exception.GlobalException;
import com.mrk.common.utils.jwt.JWTUtil;
import com.mrk.common.utils.text.CheckUtil;
import com.mrk.finance.client.dto.ContractMementDto;
import com.mrk.finance.constants.AutoMatchResConstants;
import com.mrk.finance.dto.AutoMatchResOfBillDto;
import com.mrk.finance.enums.*;
import com.mrk.finance.facade.common.CommonFacade;
import com.mrk.finance.facade.common.FinanceUserNameFacade;
import com.mrk.finance.facade.dto.WaterIntegrationDto;
import com.mrk.finance.model.*;
import com.mrk.finance.queryvo.FncBankWaterQueryVo;
import com.mrk.finance.queryvo.FncDdWithholdQueryVo;
import com.mrk.finance.queryvo.FncTtWithholdQueryVo;
import com.mrk.finance.service.*;
import com.mrk.finance.util.ExceptionUtil;
import com.mrk.finance.util.MatchUtil;
import com.mrk.finance.util.StreamUtil;
import com.mrk.member.client.MemberClient;
import com.mrk.resource.client.ResCarQueryClient;
import com.mrk.resource.model.ResCar;
import com.mrk.resource.queryvo.ResCarQueryVo;
import com.mrk.universal.enums.contract.ContractPartyTypeEnum;
import com.mrk.workflow.client.Dto.CarPageDto;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigDecimal;
import java.util.*;
import java.util.concurrent.CopyOnWriteArrayList;
import java.util.stream.Collectors;

/**
 * @project: mrk-finance
 * @author: Frank.Tang
 * @date: 2021-11-22 10:31
 * @desc: 账单自动匹配. 3种匹配类型(银行、滴滴、T3), 2种匹配方式(精确、模糊)
 * <p>
 * 一、账单匹配流水{@link FncBillAutoMatchFacade\#autoMatch}
 * 1.精确匹配   {@link FncBillAutoMatchFacade\#autoMatchAccurate}
 * (1)银行--{@link FncBillAutoMatchFacade\#autoMatchAccurateYh}
 * (2)滴滴--{@link FncBillAutoMatchFacade\#autoMatchAccurateDd}
 * (3)T3----{@link FncBillAutoMatchFacade\#autoMatchAccurateTt}
 * <p>
 * 2.模糊匹配   {@link FncBillAutoMatchFacade\#autoMatchFuzzy}
 * (1)银行--{@link FncBillAutoMatchFacade\#autoMatchFuzzyYh}
 * (2)滴滴--{@link FncBillAutoMatchFacade\#autoMatchFuzzyDd}
 * (3)T3----{@link FncBillAutoMatchFacade\#autoMatchFuzzyTt}
 * <p>
 * 二、匹配时, 查找流水相关方法
 * 1.精确匹配
 * (1)查找银行流水--{@link FncBillAutoMatchFacade\#selectBankWaterAccurate}
 * (2)查找滴滴代扣--{@link FncBillAutoMatchFacade\#selectDdWithHoldAccurate}
 * (3)查找T3代扣----{@link FncBillAutoMatchFacade\#selectTtWithHoldAccurate}
 * <p>
 * 2.模糊匹配
 * (4)查找银行流水--{@link FncBillAutoMatchFacade\#selectBankWaterFuzzy}
 * (5)查找滴滴代扣--{@link FncBillAutoMatchFacade\#selectDdWithHoldFuzzy}
 * (6)查找T3代扣----{@link FncBillAutoMatchFacade\#selectTtWithHoldFuzzy}
 **/
@Slf4j
@Component
public class FncBillAutoMatchFacade {

    @Autowired
    private FncBankWaterService fncBankWaterService;
    @Autowired
    private FncDdWithholdService fncDdWithholdService;
    @Autowired
    private FncTtWithholdService fncTtWithholdService;
    @Autowired
    private FncBillManagementService fncBillManagementService;
    @Autowired
    private FncContractManagementService fncContractManagementService;
    @Autowired
    private FncRevenueWaterRecordService fncRevenueWaterRecordService;
    @Autowired
    private AuthDeptClient authDeptClient;
    @Autowired
    private MemberClient memberClient;
    @Autowired
    private FncBillManagementFacade fncBillManagementFacade;
    @Autowired
    private CommonFacade commonFacade;
    @Autowired
    private AuthUserClient authUserClient;
    @Autowired
    private ResCarQueryClient resCarQueryClient;

    @Autowired
    private FinanceUserNameFacade financeUserNameFacade;


    /**
     * 账单自动匹配流水
     *
     * @param fbmIds 账单ids
     * @return 匹配结果(仅用于前端展示)
     * @author Frank.Tang
     */
    @Transactional(rollbackFor = Exception.class)
    public List<AutoMatchResOfBillDto> autoMatch(List<Long> fbmIds) {
        log.info("用户【{}】, 对账单(id{}, 发起自动匹配", JWTUtil.getNikeName(), fbmIds);

        //校验 + 数据准备
        List<FncBillManagement> bills = checkBillBeforeMatch(fbmIds);
        Map<Long, AutoMatchResOfBillDto> matchResMap = initMatchRes(bills);

        //批量查关联合同, 提高效率
        List<Long> contractIds = StreamUtil.toList(bills, FncBillManagement::getFbmAssociateContractId);
        List<FncContractManagement> contracts = selectAssociateContracts(contractIds, bills);
        Map<Long, FncContractManagement> contractMap = StreamUtil.toMap(contracts, FncContractManagement::getFcmId);

        //精确匹配: 先走3种精确匹配
        autoMatchAccurate(bills, matchResMap, contractMap);

        //模糊匹配: 剩下的账单, 再先走3种模糊匹配
        autoMatchFuzzy(bills, matchResMap, contractMap);

        //设置匹配结果的车牌号
        List<AutoMatchResOfBillDto> matchResList = new ArrayList<>(matchResMap.values());
        setMatchResPlateNum(matchResList);

        return matchResList;
    }


    /**********************************************************************************************
     *                                    账单匹配流水(精确)
     **********************************************************************************************
     **
     * 账单匹配流水: 精确匹配 (先走完3种精确, 再走模糊)
     * @author Frank.Tang
     * @param bills 账单对象集
     * @param matchResMap 匹配结果(用于前端展示)
     * @param contractMap 关联合同Map<账单id, 关联合同实体>
     */
    private void autoMatchAccurate(List<FncBillManagement> bills, Map<Long, AutoMatchResOfBillDto> matchResMap,
                                   Map<Long, FncContractManagement> contractMap) {
        if (bills == null || bills.isEmpty()) {
            return;
        }
        //依次走3种精确匹配逻辑
        autoMatchAccurateYh(bills, matchResMap, contractMap);

        autoMatchAccurateDd(bills, matchResMap, contractMap);

        autoMatchAccurateTt(bills, matchResMap, contractMap);
    }

    /**
     * 精确匹配(银行) + 处理匹配结果
     *
     * @author Frank.Tang
     */
    private void autoMatchAccurateYh(List<FncBillManagement> bills, Map<Long, AutoMatchResOfBillDto> matchResMap,
                                     Map<Long, FncContractManagement> contractMap) {
        for (FncBillManagement bill : bills) {
            //如果账单匹配过, 直接跳过精确匹配, 等待后续模糊匹配
            if (BillStateEnum.PAID_PART.getValue().equals(bill.getFbmBillState())) {
                continue;
            }
            //拿到关联的合同
            FncContractManagement contract = contractMap.get(bill.getFbmAssociateContractId());

            //找满足"精确匹配"的银行流水
            List<FncBankWater> waters = selectBankWaterAccurate(bill, contract);

            //设置匹配结果
            AutoMatchResOfBillDto matchRes = matchResMap.get(bill.getFbmId());
            matchRes.setBillId(bill.getFbmId());
            matchRes.setBillSubject(BillSubjectsEnum.getName(bill.getFbmSubjects()));
            matchRes.setPeriod(bill.getFbmNper());
            matchRes.setContractNo(contract.getFcmContractNo());

            //找到则匹配成功
            if (!waters.isEmpty()) {
                //因为是精确匹配, 所以只取最早的一个就行
                FncBankWater water = waters.stream()
                        .min(Comparator.comparing(FncBankWater::getCreatetime))
                        .orElseGet(FncBankWater::new);
                //设置匹配成功的结果
                matchRes.setMatchRes(AutoMatchResConstants.MATCH_SUCCESS);
                matchRes.setMatchWaterId(WaterMatchTypeEnum.YH.getName() + water.getFbwId());
                matchRes.setMatchedAmount(BigDecimal.valueOf(Math.abs(bill.getFbmBillAmount())));
                matchRes.setNotMatchAmount(0.0);
                //执行匹配, 生成或更新相关数据
                WaterIntegrationDto dto = new WaterIntegrationDto(water);
                updateAndGenRecordAccurate(dto, bill);
                //移除已精确匹配的账单
                bills.remove(bill);
            }
        }
    }

    /**
     * 精确匹配(滴滴)
     *
     * @author Frank.Tang
     */
    private void autoMatchAccurateDd(List<FncBillManagement> bills, Map<Long, AutoMatchResOfBillDto> matchResMap,
                                     Map<Long, FncContractManagement> contractMap) {
        for (FncBillManagement bill : bills) {
            //拿到关联的合同
            FncContractManagement contract = contractMap.get(bill.getFbmAssociateContractId());

            //账单金额<0 or 账单已经匹配过 or 合同乙方非"个人类型" or 是[保证金]账单,  直接跳过
            if (bill.getFbmBillAmount() < 0.0
                    || (bill.getFbmBillState() > BillStateEnum.OVERDUE.getValue())
                    || (!ContractPartyTypeEnum.PERSONAL.getValue().equals(contract.getFcmPartybType()))
                    || (BillSubjectsEnum.BOND.getValue().equals(bill.getFbmSubjects()))) {
                continue;
            }

            //找满足"精确匹配"的滴滴代扣
            List<FncDdWithhold> dds = selectDdWithHoldAccurate(bill, contract);

            //设置匹配结果
            AutoMatchResOfBillDto matchRes = matchResMap.get(bill.getFbmId());
            matchRes.setBillId(bill.getFbmId());
            matchRes.setBillSubject(BillSubjectsEnum.getName(bill.getFbmSubjects()));
            matchRes.setPeriod(bill.getFbmNper());
            matchRes.setContractNo(contract.getFcmContractNo());

            //找到则匹配成功
            if (!dds.isEmpty()) {
                //因为是精确匹配, 所以只取最早的一个就行
                FncDdWithhold dd = dds.stream()
                        .min(Comparator.comparing(FncDdWithhold::getCreatetime))
                        .orElseGet(FncDdWithhold::new);
                //设置匹配成功的结果
                matchRes.setMatchRes(AutoMatchResConstants.MATCH_SUCCESS);
                matchRes.setMatchWaterId(WaterMatchTypeEnum.DD.getName() + dd.getFdwId());
                matchRes.setMatchedAmount(BigDecimal.valueOf(bill.getFbmBillAmount()));
                matchRes.setNotMatchAmount(0.0);
                matchRes.setCarVin(dd.getFdwCarVin());
                //执行匹配, 生成或更新相关数据
                WaterIntegrationDto dto = new WaterIntegrationDto(dd);
                updateAndGenRecordAccurate(dto, bill);
                //移除已精确匹配的账单
                bills.remove(bill);
            }
        }
    }

    /**
     * 精确匹配(T3)
     *
     * @author Frank.Tang
     */
    private void autoMatchAccurateTt(List<FncBillManagement> bills, Map<Long, AutoMatchResOfBillDto> matchResMap,
                                     Map<Long, FncContractManagement> contractMap) {
        for (FncBillManagement bill : bills) {
            //拿到关联的合同
            FncContractManagement contract = contractMap.get(bill.getFbmAssociateContractId());

            //如果账单已经匹配过 or 如果合同乙方非"个人类型" or 如果是[保证金]账单,  直接跳过
            if (bill.getFbmBillAmount() < 0
                    || (bill.getFbmBillState() > BillStateEnum.OVERDUE.getValue())
                    || (!ContractPartyTypeEnum.PERSONAL.getValue().equals(contract.getFcmPartybType()))
                    || (BillSubjectsEnum.BOND.getValue().equals(bill.getFbmSubjects()))) {
                continue;
            }

            //找满足"精确匹配"的T3代扣
            List<FncTtWithhold> tts = selectTtWithHoldAccurate(bill, contract);

            //设置匹配结果
            AutoMatchResOfBillDto matchRes = matchResMap.get(bill.getFbmId());
            matchRes.setBillId(bill.getFbmId());
            matchRes.setBillSubject(BillSubjectsEnum.getName(bill.getFbmSubjects()));
            matchRes.setPeriod(bill.getFbmNper());
            matchRes.setContractNo(contract.getFcmContractNo());

            //找到则匹配成功
            if (!tts.isEmpty()) {
                //因为是精确匹配, 所以只取最早的一个就行
                FncTtWithhold tt = tts.stream()
                        .min(Comparator.comparing(FncTtWithhold::getCreatetime))
                        .orElseGet(FncTtWithhold::new);
                //设置匹配成功的结果
                matchRes.setMatchRes(AutoMatchResConstants.MATCH_SUCCESS);
                matchRes.setMatchWaterId(WaterMatchTypeEnum.TT.getName() + tt.getFtwId());
                matchRes.setMatchedAmount(BigDecimal.valueOf(bill.getFbmBillAmount()));
                matchRes.setNotMatchAmount(0.0);
                matchRes.setCarVin(tt.getFtwCarVin());
                //执行匹配, 生成或更新相关数据
                WaterIntegrationDto dto = new WaterIntegrationDto(tt);
                updateAndGenRecordAccurate(dto, bill);
                //移除已精确匹配的账单
                bills.remove(bill);
            }
        }
    }

    /**
     * 针对单个流水和账单(精确匹配), 更新和新增相关数据
     *
     * @param dto  流水 or 代扣封装对象
     * @param bill 账单
     * @author Frank.Tang
     */
    private void updateAndGenRecordAccurate(WaterIntegrationDto dto, FncBillManagement bill) {
        FncRevenueWaterRecord waterRecord = new FncRevenueWaterRecord();
        AuthUser user = authUserClient.getAuthUserById(JWTUtil.getUserId()).getDataWithEx();
        Long fbmId = bill.getFbmId();

        //银行
        if (WaterMatchTypeEnum.YH.getValue().equals(dto.getType())) {
            FncBankWater bankWater = dto.getBankWater();

            //根据借/贷, 设置已匹配金额
            if (WaterLoanTypeEnum.BORROW.getValue().equals(bankWater.getFbwLoanType())) {
                bankWater.setFbwMatchedAmount(bankWater.getFbwBorrowAmount());
            } else {
                bankWater.setFbwMatchedAmount(bankWater.getFbwCreditAmount());
            }

            bankWater.setFbwNotMatchAmount(0.0);
            bankWater.setFbwMatchBill(MatchUtil.splicing(bankWater.getFbwMatchBill(), fbmId));
            bankWater.setFbwMatchState(WaterMatchStateEnum.ALL_MATCH.getValue());
            bankWater.setFbwMatchType(MatchWayEnum.AUTO.getValue());
            waterRecord.setFrwrRevenueId(bankWater.getFbwId());
            waterRecord.setFrwrRevenueType(WaterMatchTypeEnum.YH.getValue());

            //更新流水
            fncBankWaterService.update(bankWater);
            //拼接账单的流水匹配id
            bill.setFbmMatchSerialNumber(MatchUtil.splicing(
                    bill.getFbmMatchSerialNumber(),
                    WaterMatchTypeEnum.YH.getName() + bankWater.getFbwId())
            );
        }
        //滴滴
        else if (WaterMatchTypeEnum.DD.getValue().equals(dto.getType())) {
            FncDdWithhold ddWater = dto.getDdWithhold();

            ddWater.setFdwMatchedAmount(ddWater.getFdwTradeAmount());
            ddWater.setFdwNotMatchAmount(0.0);
            ddWater.setFdwMatchBill(MatchUtil.splicing(ddWater.getFdwMatchBill(), fbmId));
            ddWater.setFdwMatchState(WaterMatchStateEnum.ALL_MATCH.getValue());
            ddWater.setFdwMatchWay(MatchWayEnum.AUTO.getValue());
            waterRecord.setFrwrRevenueId(ddWater.getFdwId());
            waterRecord.setFrwrRevenueType(WaterMatchTypeEnum.DD.getValue());

            fncDdWithholdService.update(ddWater);

            bill.setFbmMatchSerialNumber(MatchUtil.splicing(
                    bill.getFbmMatchSerialNumber(),
                    WaterMatchTypeEnum.DD.getName() + ddWater.getFdwId())
            );
        }
        //T3
        else if (WaterMatchTypeEnum.TT.getValue().equals(dto.getType())) {
            FncTtWithhold ttWater = dto.getTtWithhold();

            ttWater.setFtwMatchedAmount(ttWater.getFtwMonthWithhold());
            ttWater.setFtwNotMatchAmount(0.0);
            ttWater.setFtwMatchBill(MatchUtil.splicing(ttWater.getFtwMatchBill(), fbmId));
            ttWater.setFtwMatchState(WaterMatchStateEnum.ALL_MATCH.getValue());
            ttWater.setFtwMatchWay(MatchWayEnum.AUTO.getValue());
            waterRecord.setFrwrRevenueId(ttWater.getFtwId());
            waterRecord.setFrwrRevenueType(WaterMatchTypeEnum.TT.getValue());

            fncTtWithholdService.update(ttWater);

            bill.setFbmMatchSerialNumber(MatchUtil.splicing(
                    bill.getFbmMatchSerialNumber(),
                    WaterMatchTypeEnum.TT.getName() + ttWater.getFtwId())
            );
        }

        //更新账单
        bill.setFbmMatchUserId(JWTUtil.getUserId());
        bill.setFbmMatchTime(new Date());
        bill.setFbmMatchWay(MatchWayEnum.AUTO.getValue());
        bill.setFbmBillState(BillStateEnum.PAID_ALL.getValue());
        bill.setFbmMatchedAmount(Math.abs(bill.getFbmBillAmount()));
        bill.setFbmNotMatchAmount(0.0);
        fncBillManagementService.update(bill);
        String userNamePhone = financeUserNameFacade.getUserNamePhone(user);
        String desc = userNamePhone +
                "发起自动匹配，匹配成功。匹配账单号" + fbmId + "，" +
                "匹配金额" + bill.getFbmMatchedAmount() + "元，" +
                "流水剩余金额0.0元。";
        waterRecord.setFrwrBillId(fbmId);
        waterRecord.setFrwrDescribe(desc);
        waterRecord.setFrwrMatchState(MatchWayEnum.AUTO.getValue());

        //新增匹配记录
        fncRevenueWaterRecordService.add(waterRecord);
    }


    /**********************************************************************************************
     *                                  账单匹配流水(模糊)
     **********************************************************************************************
     **
     * 账单匹配流水: 模糊匹配
     * @author Frank.Tang
     * @param bills 账单对象集
     * @param matchResMap 匹配结果(用于前端展示)
     * @param contractMap 关联合同map (<账单id, 关联合同实体>)
     */
    private void autoMatchFuzzy(List<FncBillManagement> bills, Map<Long, AutoMatchResOfBillDto> matchResMap,
                                Map<Long, FncContractManagement> contractMap) {
        if (bills == null || bills.isEmpty()) {
            return;
        }
        //依次走3种模糊匹配逻辑
        autoMatchFuzzyYh(bills, matchResMap, contractMap);

        autoMatchFuzzyDd(bills, matchResMap, contractMap);

        autoMatchFuzzyTt(bills, matchResMap, contractMap);
    }

    /**
     * 模糊匹配(银行)
     *
     * @author Frank.Tang
     */
    private void autoMatchFuzzyYh(List<FncBillManagement> bills, Map<Long, AutoMatchResOfBillDto> matchResMap,
                                  Map<Long, FncContractManagement> contractMap) {
        for (FncBillManagement bill : bills) {
            //拿到关联的合同
            FncContractManagement contract = contractMap.get(bill.getFbmAssociateContractId());

            //找符合条件的数据
            List<FncBankWater> waters = selectBankWaterFuzzy(contract);

            //设置匹配结果
            AutoMatchResOfBillDto matchRes = matchResMap.get(bill.getFbmId());
            matchRes.setBillId(bill.getFbmId());
            matchRes.setBillSubject(BillSubjectsEnum.getName(bill.getFbmSubjects()));
            matchRes.setPeriod(bill.getFbmNper());
            matchRes.setContractNo(contract.getFcmContractNo());

            //有符合条件的, 进行匹配. 直到账单匹成功, 或者流水用完为止
            if (!waters.isEmpty()) {
                for (FncBankWater water : waters) {
                    //根据借/贷关系, 这两种情况, 直接跳过
                    if (MatchUtil.checkLoanRelation(water, bill)) {
                        continue;
                    }

                    WaterIntegrationDto dto = new WaterIntegrationDto(water);
                    BigDecimal billAmount = BigDecimal.valueOf(bill.getFbmBillAmount()).abs();
                    BigDecimal billMatched = BigDecimal.valueOf(bill.getFbmMatchedAmount());
                    BigDecimal billNotMatch = BigDecimal.valueOf(bill.getFbmNotMatchAmount());
                    BigDecimal waterAmount = BigDecimal.valueOf(
                            WaterLoanTypeEnum.BORROW.getValue().equals(water.getFbwLoanType()) ?
                                    water.getFbwBorrowAmount() : water.getFbwCreditAmount()
                    );
                    BigDecimal waterMatched = BigDecimal.valueOf(water.getFbwMatchedAmount());
                    BigDecimal waterNotMatch = BigDecimal.valueOf(water.getFbwNotMatchAmount());

                    //账单未匹配>流水未匹配. 当前流水直接用完, 继续匹配下一个流水
                    if (billNotMatch.compareTo(waterNotMatch) > 0) {
                        BigDecimal billMatchedNow = billMatched.add(waterNotMatch);
                        bill.setFbmMatchedAmount(billMatchedNow.doubleValue());
                        bill.setFbmNotMatchAmount(billAmount.subtract(billMatchedNow).doubleValue());
                        water.setFbwMatchedAmount(waterAmount.doubleValue());
                        water.setFbwNotMatchAmount(0.0);

                        matchRes.setMatchRes(AutoMatchResConstants.MATCH_PART_SUCCESS);
                        matchRes.setMatchWaterId(MatchUtil.splicing(
                                matchRes.getMatchWaterId(),
                                WaterMatchTypeEnum.YH.getName() + water.getFbwId())
                        );

                        matchRes.setMatchedAmount(matchRes.getMatchedAmount().add(waterNotMatch));
                        matchRes.setNotMatchAmount(bill.getFbmNotMatchAmount());
                        matchRes.setCarVin("");

                        //更新数据+生成匹配记录
                        fncBillManagementFacade.updateAndGenRecordAfterMatch(bill, dto, waterNotMatch, true);
                    }
                    //账单未匹配<=流水未匹配. 当前账单匹配完毕, 本次匹配结束
                    else {
                        BigDecimal waterMatchedNow = waterMatched.add(billNotMatch);
                        bill.setFbmMatchedAmount(billAmount.doubleValue());
                        bill.setFbmNotMatchAmount(0.0);
                        water.setFbwMatchedAmount(waterMatchedNow.doubleValue());
                        water.setFbwNotMatchAmount(waterAmount.subtract(waterMatchedNow).doubleValue());

                        matchRes.setMatchRes(AutoMatchResConstants.MATCH_SUCCESS);
                        matchRes.setMatchWaterId(MatchUtil.splicing(
                                matchRes.getMatchWaterId(),
                                WaterMatchTypeEnum.YH.getName() + water.getFbwId())
                        );
                        matchRes.setMatchedAmount(billAmount.subtract(matchRes.getMatchedAmountInit()));
                        matchRes.setNotMatchAmount(bill.getFbmNotMatchAmount());
                        matchRes.setCarVin("");

                        //更新数据+生成匹配记录
                        fncBillManagementFacade.updateAndGenRecordAfterMatch(bill, dto, billNotMatch, true);
                        //移除该账单
                        bills.remove(bill);
                        //当前账单匹配结束
                        break;
                    }
                }
            }
        }
    }

    /**
     * 模糊匹配(滴滴)
     *
     * @author Frank.Tang
     */
    private void autoMatchFuzzyDd(List<FncBillManagement> bills, Map<Long, AutoMatchResOfBillDto> matchResMap,
                                  Map<Long, FncContractManagement> contractMap) {
        for (FncBillManagement bill : bills) {
            //<0直接跳过
            if (bill.getFbmBillAmount() < 0.0) {
                continue;
            }

            //拿到关联的合同
            FncContractManagement contract = contractMap.get(bill.getFbmAssociateContractId());

            //找符合条件的数据
            List<FncDdWithhold> withholds = selectDdWithHoldFuzzy(contract);

            //设置匹配结果
            AutoMatchResOfBillDto matchRes = matchResMap.get(bill.getFbmId());
            matchRes.setBillId(bill.getFbmId());
            matchRes.setBillSubject(BillSubjectsEnum.getName(bill.getFbmSubjects()));
            matchRes.setPeriod(bill.getFbmNper());
            matchRes.setContractNo(contract.getFcmContractNo());


            //有符合条件的, 进行匹配. 直到账单匹成功, 或者流水用完为止
            if (!withholds.isEmpty()) {
                for (FncDdWithhold withhold : withholds) {
                    WaterIntegrationDto dto = new WaterIntegrationDto(withhold);
                    BigDecimal billAmount = BigDecimal.valueOf(bill.getFbmBillAmount()).abs();
                    BigDecimal billMatched = BigDecimal.valueOf(bill.getFbmMatchedAmount());
                    BigDecimal billNotMatch = BigDecimal.valueOf(bill.getFbmNotMatchAmount());
                    BigDecimal waterAmount = BigDecimal.valueOf(withhold.getFdwTradeAmount());
                    BigDecimal waterMatched = BigDecimal.valueOf(withhold.getFdwMatchedAmount());
                    BigDecimal waterNotMatch = BigDecimal.valueOf(withhold.getFdwNotMatchAmount());

                    //账单未匹配>流水未匹配. 当前流水直接用完, 继续匹配下一个流水
                    if (billNotMatch.compareTo(waterNotMatch) > 0) {
                        BigDecimal billMatchNow = billMatched.add(waterNotMatch);
                        bill.setFbmMatchedAmount(billMatchNow.doubleValue());
                        bill.setFbmNotMatchAmount(billAmount.subtract(billMatchNow).doubleValue());
                        withhold.setFdwMatchedAmount(waterAmount.doubleValue());
                        withhold.setFdwNotMatchAmount(0.0);

                        matchRes.setMatchRes(AutoMatchResConstants.MATCH_PART_SUCCESS);
                        matchRes.setMatchWaterId(MatchUtil.splicing(
                                matchRes.getMatchWaterId(),
                                WaterMatchTypeEnum.DD.getName() + withhold.getFdwId())
                        );
                        matchRes.setMatchedAmount(matchRes.getMatchedAmount().add(waterNotMatch));
                        matchRes.setNotMatchAmount(bill.getFbmNotMatchAmount());
                        matchRes.setCarVin(MatchUtil.splicing(matchRes.getCarVin(), withhold.getFdwCarVin()));

                        //更新数据+生成匹配记录
                        fncBillManagementFacade.updateAndGenRecordAfterMatch(bill, dto, waterNotMatch, true);
                    }
                    //账单未匹配<=流水未匹配. 当前账单匹配完毕, 本次匹配结束
                    else {
                        BigDecimal waterMatchNow = waterMatched.add(billNotMatch);
                        bill.setFbmMatchedAmount(billAmount.doubleValue());
                        bill.setFbmNotMatchAmount(0.0);
                        withhold.setFdwMatchedAmount(waterMatchNow.doubleValue());
                        withhold.setFdwNotMatchAmount(waterAmount.subtract(waterMatchNow).doubleValue());

                        matchRes.setMatchRes(AutoMatchResConstants.MATCH_SUCCESS);
                        matchRes.setMatchWaterId(MatchUtil.splicing(
                                matchRes.getMatchWaterId(),
                                WaterMatchTypeEnum.DD.getName() + withhold.getFdwId())
                        );
                        matchRes.setMatchedAmount(billAmount.subtract(matchRes.getMatchedAmountInit()));
                        matchRes.setNotMatchAmount(bill.getFbmNotMatchAmount());
                        matchRes.setCarVin(MatchUtil.splicing(matchRes.getCarVin(), withhold.getFdwCarVin()));

                        //更新数据+生成匹配记录
                        fncBillManagementFacade.updateAndGenRecordAfterMatch(bill, dto, billNotMatch, true);
                        //移除该账单
                        bills.remove(bill);
                        //当前账单匹配结束
                        break;
                    }
                }
            }
        }
    }

    /**
     * 模糊匹配(T3)
     *
     * @author Frank.Tang
     */
    private void autoMatchFuzzyTt(List<FncBillManagement> bills, Map<Long, AutoMatchResOfBillDto> matchResMap,
                                  Map<Long, FncContractManagement> contractMap) {
        for (FncBillManagement bill : bills) {
            //<0直接跳过
            if (bill.getFbmBillAmount() < 0.0) {
                continue;
            }

            //拿到关联的合同
            FncContractManagement contract = contractMap.get(bill.getFbmAssociateContractId());

            //找符合条件的数据
            List<FncTtWithhold> withholds = selectTtWithHoldFuzzy(contract);

            //设置匹配结果
            AutoMatchResOfBillDto matchRes = matchResMap.get(bill.getFbmId());
            matchRes.setBillId(bill.getFbmId());
            matchRes.setBillSubject(BillSubjectsEnum.getName(bill.getFbmSubjects()));
            matchRes.setPeriod(bill.getFbmNper());
            matchRes.setContractNo(contract.getFcmContractNo());

            //有符合条件的, 进行匹配. 直到账单匹成功, 或者流水用完为止
            if (!withholds.isEmpty()) {
                for (FncTtWithhold withhold : withholds) {
                    WaterIntegrationDto dto = new WaterIntegrationDto(withhold);
                    BigDecimal billAmount = BigDecimal.valueOf(bill.getFbmBillAmount()).abs();
                    BigDecimal billMatched = BigDecimal.valueOf(bill.getFbmMatchedAmount());
                    BigDecimal billNotMatch = BigDecimal.valueOf(bill.getFbmNotMatchAmount());
                    BigDecimal waterAmount = BigDecimal.valueOf(withhold.getFtwMonthWithhold());
                    BigDecimal waterMatched = BigDecimal.valueOf(withhold.getFtwMatchedAmount());
                    BigDecimal waterNotMatch = BigDecimal.valueOf(withhold.getFtwNotMatchAmount());

                    //账单未匹配>流水未匹配. 当前流水直接用完, 继续匹配下一个流水
                    if (billNotMatch.compareTo(waterNotMatch) > 0) {
                        BigDecimal billMatchNow = billMatched.add(waterNotMatch);
                        bill.setFbmMatchedAmount(billMatchNow.doubleValue());
                        bill.setFbmNotMatchAmount(billAmount.subtract(billMatchNow).doubleValue());
                        withhold.setFtwMatchedAmount(waterAmount.doubleValue());
                        withhold.setFtwNotMatchAmount(0.0);

                        matchRes.setMatchRes(AutoMatchResConstants.MATCH_PART_SUCCESS);
                        matchRes.setMatchWaterId(MatchUtil.splicing(
                                matchRes.getMatchWaterId(),
                                WaterMatchTypeEnum.TT.getName() + withhold.getFtwId())
                        );
                        matchRes.setMatchedAmount(matchRes.getMatchedAmount().add(waterNotMatch));
                        matchRes.setNotMatchAmount(bill.getFbmNotMatchAmount());
                        matchRes.setCarVin(MatchUtil.splicing(matchRes.getCarVin(), withhold.getFtwCarVin()));

                        //更新数据+生成匹配记录
                        fncBillManagementFacade.updateAndGenRecordAfterMatch(bill, dto, waterNotMatch, true);
                    }
                    //账单未匹配<=流水未匹配. 当前账单匹配完毕, 本次匹配结束
                    else {
                        BigDecimal waterMatchNow = waterMatched.add(billNotMatch);
                        bill.setFbmMatchedAmount(billAmount.doubleValue());
                        bill.setFbmNotMatchAmount(0.0);
                        withhold.setFtwMatchedAmount(waterMatchNow.doubleValue());
                        withhold.setFtwNotMatchAmount(waterAmount.subtract(waterMatchNow).doubleValue());

                        matchRes.setMatchRes(AutoMatchResConstants.MATCH_SUCCESS);
                        matchRes.setMatchWaterId(MatchUtil.splicing(
                                matchRes.getMatchWaterId(),
                                WaterMatchTypeEnum.TT.getName() + withhold.getFtwId())
                        );
                        matchRes.setMatchedAmount(billAmount.subtract(matchRes.getMatchedAmountInit()));
                        matchRes.setNotMatchAmount(bill.getFbmNotMatchAmount());
                        matchRes.setCarVin(MatchUtil.splicing(matchRes.getCarVin(), withhold.getFtwCarVin()));

                        //更新数据+生成匹配记录
                        fncBillManagementFacade.updateAndGenRecordAfterMatch(bill, dto, billNotMatch, true);
                        //移除该账单
                        bills.remove(bill);
                        //当前账单匹配结束
                        break;
                    }
                }
            }
        }
    }


    /**********************************************************************************************
     *                                      查找流水相关方法
     **********************************************************************************************
     **
     * 根据银行账号+金额等信息, 查询银行流水(精确匹配)
     * 查找条件:
     *     (1)本方银行账号 = 甲方银行账号
     *     (2)对方银行账号 = 乙方银行账号
     *     (3)借方金额 = 账单金额（负数） / 贷方金额 = 账单金额（正数）
     *     (4)流水状态 = 未匹配
     * @author Frank.Tang
     * @param bill 账单
     * @param contract bill的关联合同
     * @return 关键元素有空 --> 空集合
     *         关键元素非空 --> 满足条件的银行流水
     */
    private List<FncBankWater> selectBankWaterAccurate(FncBillManagement bill, FncContractManagement contract) {
        String aBankAccount = getBankAccount(contract.getFcmPartyaId(), contract.getFcmPartyaType());
        String bBankAccount = getBankAccount(contract.getFcmPartybId(), contract.getFcmPartybType());

        if (aBankAccount == null || bBankAccount == null) {
            return new ArrayList<>();
        }

        FncBankWaterQueryVo queryVo = new FncBankWaterQueryVo();
        queryVo.setFbwOwnAccountEqualTo(aBankAccount);
        queryVo.setFbwOtherAccountEqualTo(bBankAccount);
        queryVo.setFbwNotMatchAmountEqualTo(bill.getFbmNotMatchAmount());
        queryVo.setFbwMatchStateEqualTo(WaterMatchStateEnum.NOT_MATCH.getValue());

        //根据正负, 确定借/贷
        if (bill.getFbmBillAmount() < 0.0) {
            queryVo.setFbwLoanTypeEqualTo(WaterLoanTypeEnum.BORROW.getValue());
        } else {
            queryVo.setFbwLoanTypeEqualTo(WaterLoanTypeEnum.LOAN.getValue());
        }

        return fncBankWaterService.list(queryVo);
    }

    /**
     * 查询银行流水(模糊匹配)
     * 查找条件:
     * (1)乙方银行账号 = 流水账号 (所有[未匹配/部分匹配]的都拿出来)
     * (2)流水的状态 = [未匹配/部分匹配]
     *
     * @param contract bill的关联合同
     * @return 关键元素有空 --> 空集合
     * 关键元素非空 --> 满足条件的银行流水, 且按生成时间升序
     * @author Frank.Tang
     */
    private List<FncBankWater> selectBankWaterFuzzy(FncContractManagement contract) {
        Long partybId = contract.getFcmPartybId();
        Integer partybType = contract.getFcmPartybType();

        String partybBankAccount = getBankAccount(partybId, partybType);

        if (partybBankAccount == null) {
            return new ArrayList<>();
        }

        FncBankWaterQueryVo queryVo = new FncBankWaterQueryVo();
        queryVo.setFbwOtherAccountEqualTo(partybBankAccount);
        queryVo.setFbwMatchStateIn(Arrays.asList(
                WaterMatchStateEnum.NOT_MATCH.getValue(),
                WaterMatchStateEnum.PART_MATCH.getValue()
        ));

        //按创建时间升序
        return fncBankWaterService.list(queryVo)
                .stream()
                .sorted(Comparator.comparing(BaseEntity::getCreatetime))
                .collect(Collectors.toList());
    }

    /**
     * 根据vin+金额等信息, 查询滴滴代扣(精确匹配)
     * 查找条件:
     * (1)关联合同的关联vin = 滴滴代扣的vin
     * (2)账单金额 = 滴滴代扣金额
     * (3)代扣状态 = 未匹配
     *
     * @param bill     账单
     * @param contract bill的关联合同
     * @return 关键元素有空 --> 空集合
     * 关键元素非空 --> 满足条件的滴滴代扣
     * @author Frank.Tang
     */
    private List<FncDdWithhold> selectDdWithHoldAccurate(FncBillManagement bill, FncContractManagement contract) {
        //找合同下所属的车辆
        ContractMementDto mementDto = new ContractMementDto();
        mementDto.setContractId(contract.getFcmId());
        PageInfo<CarPageDto> page = commonFacade.page(mementDto);

        //提取vin
        List<String> contractVinList = StreamUtil.toList(page.getList(), CarPageDto::getRcVin);

        if (contractVinList == null || contractVinList.isEmpty()) {
            return new ArrayList<>();
        }

        //查询条件
        FncDdWithholdQueryVo queryVo = new FncDdWithholdQueryVo();
        queryVo.setFdwCarVinIn(contractVinList);
        queryVo.setFdwTradeAmountEqualTo(bill.getFbmBillAmount());
        queryVo.setFdwMatchStateEqualTo(WaterMatchStateEnum.NOT_MATCH.getValue());

        return fncDdWithholdService.list(queryVo);
    }

    /**
     * 查询滴滴代扣(模糊匹配)
     * 查找条件:
     * (1)合同关联的vin = 代扣的vin
     * (2)代扣的状态 = [未匹配/部分匹配]
     *
     * @param contract bill的关联合同
     * @return 关键元素有空 --> 空集合
     * 关键元素非空 --> 满足条件的滴滴代扣, 且按生成时间升序
     * @author Frank.Tang
     */
    private List<FncDdWithhold> selectDdWithHoldFuzzy(FncContractManagement contract) {
        //找合同下所属的车辆
        ContractMementDto mementDto = new ContractMementDto();
        mementDto.setContractId(contract.getFcmId());
        PageInfo<CarPageDto> page = commonFacade.page(mementDto);

        //提取vin
        List<String> contractVinList = StreamUtil.toList(page.getList(), CarPageDto::getRcVin);
        if (contractVinList == null || contractVinList.isEmpty()) {
            return new ArrayList<>();
        }

        //查询条件
        FncDdWithholdQueryVo queryVo = new FncDdWithholdQueryVo();
        queryVo.setFdwCarVinIn(contractVinList);
        queryVo.setFdwMatchStateIn(Arrays.asList(
                WaterMatchStateEnum.NOT_MATCH.getValue(),
                WaterMatchStateEnum.PART_MATCH.getValue())
        );

        //按创建时间升序
        return fncDdWithholdService.list(queryVo)
                .stream()
                .sorted(Comparator.comparing(BaseEntity::getCreatetime))
                .collect(Collectors.toList());
    }

    /**
     * 根据身份证+金额等信息, 查询T3代扣(精确匹配)
     * 查找条件:
     * (1)合同号 = 协议编号
     * (2)月扣款 = 账单金额
     * (3)乙方身份证 = 代扣上的身份证
     * (4)关联合同的关联vin = T3代扣的vin
     * (5)代扣状态 = 未匹配
     *
     * @param bill     账单
     * @param contract bill的关联合同
     * @return 关键元素有空 --> 空集合
     * 关键元素非空 --> 满足条件的T3代扣
     * @author Frank.Tang
     */
    private List<FncTtWithhold> selectTtWithHoldAccurate(FncBillManagement bill, FncContractManagement contract) {
        //vin
        ContractMementDto mementDto = new ContractMementDto();
        mementDto.setContractId(contract.getFcmId());
        PageInfo<CarPageDto> page = commonFacade.page(mementDto);
        List<String> contractVinList = StreamUtil.toList(page.getList(), CarPageDto::getRcVin);

        //身份证
        String idNumber = memberClient.getMemberIdNumberById(contract.getFcmPartybId()).getDataWithEx();

        if (idNumber == null || idNumber.trim().length() == 0
                || contractVinList == null || contractVinList.isEmpty()) {
            return new ArrayList<>();
        }

        //查询条件
        FncTtWithholdQueryVo queryVo = new FncTtWithholdQueryVo();
        queryVo.setFtwAgreementNumberEqualTo(contract.getFcmContractNo());
        queryVo.setFtwMonthWithholdEqualTo(bill.getFbmBillAmount());
        queryVo.setFtwIdnumberEqualTo(idNumber);
        queryVo.setFtwCarVinIn(contractVinList);
        queryVo.setFtwMatchStateEqualTo(WaterMatchStateEnum.NOT_MATCH.getValue());

        return fncTtWithholdService.list(queryVo);
    }

    /**
     * 查询T3代扣(模糊匹配)
     * 查找条件:
     * (1)乙方身份证 = 代扣的身份证
     * (2)代扣的状态 = [未匹配/部分匹配]
     *
     * @param contract bill的关联合同
     * @return 关键元素有空 --> 空集合
     * 关键元素非空 --> 满足条件的T3代扣, 且按生成时间升序
     * @author Frank.Tang
     */
    private List<FncTtWithhold> selectTtWithHoldFuzzy(FncContractManagement contract) {
        String idNumber = memberClient.getMemberIdNumberById(contract.getFcmPartybId()).getDataWithEx();

        if (idNumber == null || idNumber.trim().length() == 0) {
            return new ArrayList<>();
        }

        //查询条件
        FncTtWithholdQueryVo queryVo = new FncTtWithholdQueryVo();
        queryVo.setFtwIdnumberEqualTo(idNumber);
        queryVo.setFtwMatchStateIn(Arrays.asList(
                WaterMatchStateEnum.NOT_MATCH.getValue(),
                WaterMatchStateEnum.PART_MATCH.getValue()
        ));

        //按创建时间升序
        return fncTtWithholdService.list(queryVo)
                .stream()
                .sorted(Comparator.comparing(BaseEntity::getCreatetime))
                .collect(Collectors.toList());
    }


    /**********************************************************************************************
     *                                        其它方法汇总
     **********************************************************************************************
     **
     * 根据类型+账号id(个人/组织), 查找银行账号
     * @author Frank.Tang
     * @param partyId 个人或组织的id
     * @param partyType 类型
     * @return *
     */
    private String getBankAccount(Long partyId, Integer partyType) {
        return ContractPartyTypeEnum.PERSONAL.getValue().equals(partyType) ?
                memberClient.getMemberBankAccountById(partyId).getDataWithEx() :
                authDeptClient.getAuthDeptById(partyId).getDataWithEx().getDeptBankAccount();
    }

    /**
     * 批量查询账单的关联合同
     *
     * @param ids   关联合同ids
     * @param bills 账单, 用于判断关联合同是否有异常
     * @return *
     * @author Frank.Tang
     */
    private List<FncContractManagement> selectAssociateContracts(List<Long> ids, List<FncBillManagement> bills) {
        //拿关联合同
        List<FncContractManagement> contract = fncContractManagementService.getByIds(ids);
        if (contract == null || contract.isEmpty()) {
            throw new GlobalException("数据异常, 账单关联合同丢失");
        }

        Set<Long> associateContractIdsOfBill = StreamUtil.toSet(bills, FncBillManagement::getFbmAssociateContractId);

        if (associateContractIdsOfBill.size() != contract.size()) {
            throw new GlobalException("数据异常, 部分账单的关联合同数据丢失, 请联系管理员");
        }

        return contract;
    }

    /**
     * 初始化匹配结果集
     *
     * @return <账单id, 匹配结果>
     * @author Frank.Tang
     */
    private Map<Long, AutoMatchResOfBillDto> initMatchRes(List<FncBillManagement> bills) {
        Map<Long, AutoMatchResOfBillDto> res = new HashMap<>();
        for (FncBillManagement bill : bills) {
            AutoMatchResOfBillDto matchRes = new AutoMatchResOfBillDto();

            matchRes.setBillId(bill.getFbmId());
            matchRes.setBillSubject(BillSubjectsEnum.getName(bill.getFbmSubjects()));
            matchRes.setBillAmount(bill.getFbmBillAmount());
            matchRes.setCarVin("");
            matchRes.setMatchRes(AutoMatchResConstants.MATCH_FAILED);
            matchRes.setMatchWaterId("");
            matchRes.setMatchedAmount(BigDecimal.ZERO);
            matchRes.setMatchedAmountInit(BigDecimal.valueOf(bill.getFbmMatchedAmount()));
            matchRes.setNotMatchAmount(bill.getFbmNotMatchAmount());

            res.put(bill.getFbmId(), matchRes);
        }
        return res;
    }

    /**
     * 自动匹配校验账单
     *
     * @return ids对应的实体类
     * @author Frank.Tang
     */
    private List<FncBillManagement> checkBillBeforeMatch(List<Long> fbmIds) {
        List<FncBillManagement> bills = fncBillManagementService.getByIds(fbmIds);
        if (bills.isEmpty()) {
            throw ExceptionUtil.idNotExist(fbmIds);
        }
        if (bills.size() != fbmIds.size()) {
            throw new GlobalException("数据异常, 选择的部分账单不存在或被删除");
        }
        for (FncBillManagement bill : bills) {
            if (bill.getFbmBillState() >= BillStateEnum.PAID_ALL.getValue()) {
                throw new GlobalException("操作失败, 账单【" + bill.getFbmId() + "】已支付, 不能再匹配");
            }
            if (bill.getFbmBillState().equals(BillStateEnum.REJECTED.getValue()) ||
                    bill.getFbmBillState().equals(BillStateEnum.APPROVING.getValue())) {
                throw new GlobalException("操作失败, 账单【" + bill.getFbmId() + "】还未审核通过, 不能匹配");
            }
        }
        //按生成时间升序
        return bills.stream()
                .sorted(Comparator.comparing(FncBillManagement::getFbmBillGenerateTime))
                .collect(Collectors.toCollection(CopyOnWriteArrayList::new));
    }

    /**
     * 设置匹配结果的车牌号
     *
     * @author Frank.Tang
     */
    private void setMatchResPlateNum(List<AutoMatchResOfBillDto> matchResList) {
        List<String> vinList = new ArrayList<>();

        //提取vin
        for (AutoMatchResOfBillDto res : matchResList) {
            String vin = res.getCarVin();
            if (!CheckUtil.isEmpty(vin)) {
                String[] split = vin.split(MatchUtil.SEPARATOR);
                vinList.addAll(Arrays.asList(split));
            }
        }

        if (vinList.isEmpty()) {
            return;
        }

        //批量查询
        ResCarQueryVo queryVo = new ResCarQueryVo();
        queryVo.setRcVinIn(vinList);
        List<ResCar> cars = resCarQueryClient.getCarListByQueryVo(queryVo).getDataWithEx();

        //设置
        Map<String, String> vinAndPlateNum = StreamUtil.toMap(cars, ResCar::getRcVin, ResCar::getRcPlateNum);
        for (AutoMatchResOfBillDto res : matchResList) {
            String plateNum = vinAndPlateNum.get(res.getCarVin());
            res.setCarPlateNum(plateNum);
        }
    }

}
