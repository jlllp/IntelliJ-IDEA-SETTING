package com.mrk.finance.facade.quartz;

import com.mrk.common.exception.GlobalException;
import com.mrk.finance.enums.BillStateEnum;
import com.mrk.finance.service.FncBillManagementService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Arrays;
import java.util.Date;

/**
 * @author Bob
 * @date 2021-11-18
 * @description
 */
@Component
public class OverdueBillFacade {

    private static final Logger log = LoggerFactory.getLogger(OverdueBillFacade.class);

    @Autowired
    private FncBillManagementService fncBillManagementService;

    /**
     * @author Bob
     * @date 2021/11/18
     * @description 账单过期处理
     * @param paramStr 请求参数
     */
    public void overdueBillCheck(String paramStr) {
        log.info("账单过期处理 --> 开始");
        long startTime = System.currentTimeMillis();
        SimpleDateFormat simpleDateFormat = new SimpleDateFormat("yyyy-MM-dd");
        String dateFormat = simpleDateFormat.format(new Date());
        Date today;
        try {
            today = simpleDateFormat.parse(dateFormat);
        } catch (ParseException e) {
            log.error("账单过期处理, 解析日期失败", e);
            throw new GlobalException("账单过期处理, 解析日期失败");
        }
        log.info("账单过期处理 获取到今天的日期 --> today：【{}】", dateFormat);
        fncBillManagementService.updateStateByCatOffTimeLTAndStateIn(BillStateEnum.OVERDUE.getValue(),
                today, Arrays.asList(BillStateEnum.UNPAID.getValue(), BillStateEnum.PAID_PART.getValue()));
        log.info("账单过期处理 --> 结束 耗时：【{}】", System.currentTimeMillis() - startTime);
    }
}
