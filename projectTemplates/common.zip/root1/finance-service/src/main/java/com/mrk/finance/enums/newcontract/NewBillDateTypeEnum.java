package com.mrk.finance.enums.newcontract;

import lombok.Getter;

/**
 * @project: mrk-finance
 * @author:
 * @date:
 * @desc: 账单[生成日/截止日]类型
 **/
@Getter
public enum NewBillDateTypeEnum {

    /***/
    BEFORE(0, "支付周期开始前"),
    NOW(1, "支付周期开始当天"),
    AFTER(2, "支付周期开始后"),
    FINISHED_AFTER(3, "支付周期结束前"),
    FINISHED_ING(4, "支付周期结束当天"),
    FINISHED(5, "支付周期结束后");

    private Integer value;
    private String name;

    NewBillDateTypeEnum(Integer value, String name) {
        this.value = value;
        this.name = name;
    }

    public static String getName(Integer state) {
        if (state == null) {
            return "";
        }
        for (NewBillDateTypeEnum statusEnum : values()) {
            if (statusEnum.getValue().equals(state)) {
                return statusEnum.getName();
            }
        }
        return "";
    }

}
