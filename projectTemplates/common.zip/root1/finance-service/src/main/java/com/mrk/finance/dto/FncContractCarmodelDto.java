package com.mrk.finance.dto;

import com.mrk.finance.model.FncContractCarmodel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

/**
 * @project: mrk-finance
 * @author: Frank.Tang
 * @date: 2021-11-15 11:56
 * @desc:
 **/
@Data
public class FncContractCarmodelDto extends FncContractCarmodel {

    @ApiModelProperty("车型名")
    private String fccContractCarmodelName;

}
