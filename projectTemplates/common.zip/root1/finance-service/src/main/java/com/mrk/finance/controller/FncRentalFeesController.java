package com.mrk.finance.controller;

import com.github.pagehelper.PageInfo;
import com.mrk.common.utils.page.JsonResult;
import com.mrk.finance.facade.FncRentalFeesFacade;
import com.mrk.finance.model.FncRentalFees;
import com.mrk.finance.queryvo.FncRentalFeesQueryVo;
import com.mrk.finance.service.FncRentalFeesService;
import com.mrk.log.annotation.Log;
import com.mrk.log.enums.BusinessType;
import com.mrk.log.enums.OperatorType;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiImplicitParam;
import io.swagger.annotations.ApiImplicitParams;
import io.swagger.annotations.ApiOperation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;


/**
 * FncRentalFeesController

 */
@RestController
@RequestMapping("/financeservice/fncrentalfees")
@Api(tags = "/租金包含费用")
public class FncRentalFeesController {
    @Autowired
    private FncRentalFeesFacade fncRentalFeesFacade;
    @Autowired
    private FncRentalFeesService fncRentalFeesService;

    @PostMapping(value = "/add")
    @ApiOperation("租金包含费用-新增")
    @ApiImplicitParams({
            @ApiImplicitParam(paramType = "header", name = "Authorization", value = "系统下发的token", required = true)
    })
    @Log(title = "租金包含费用", value = "新增", businessType = BusinessType.INSERT, operatorType = OperatorType.MANAGE)
    public JsonResult<Integer> add(FncRentalFees entity) {
        return JsonResult.success(fncRentalFeesFacade.add(entity)).setMsg("新增成功");
    }

    @PostMapping(value = "/del/{id}")
    @ApiOperation("租金包含费用-删除")
    @ApiImplicitParams({
            @ApiImplicitParam(paramType = "header", name = "Authorization", value = "系统下发的token", required = true)
    })
    @Log(title = "租金包含费用", value = "删除", businessType = BusinessType.DELETE, operatorType = OperatorType.MANAGE)
    public JsonResult<Integer> del(@PathVariable("id") Long id) {
        return JsonResult.success(fncRentalFeesFacade.deleteLogically(id)).setMsg("删除成功");
    }

    @PostMapping(value = "/update")
    @ApiOperation("租金包含费用-更新")
    @ApiImplicitParams({
            @ApiImplicitParam(paramType = "header", name = "Authorization", value = "系统下发的token", required = true)
    })
    @Log(title = "租金包含费用", value = "更新", businessType = BusinessType.UPDATE, operatorType = OperatorType.MANAGE)
    public JsonResult<Integer> update(FncRentalFees entity) {
        return JsonResult.success(fncRentalFeesFacade.update(entity)).setMsg("更新成功");
    }

    @GetMapping(value = "/page")
    @ApiOperation("租金包含费用-分页查询")
    @ApiImplicitParams({
            @ApiImplicitParam(paramType = "header", name = "Authorization", value = "系统下发的token", required = true)
    })
    public JsonResult<PageInfo<FncRentalFees>> page(FncRentalFeesQueryVo queryVo) {
        return JsonResult.success(fncRentalFeesService.page(queryVo));
    }

    @GetMapping(value = "/list")
    @ApiOperation("租金包含费用-列表查询")
    @ApiImplicitParams({
            @ApiImplicitParam(paramType = "header", name = "Authorization", value = "系统下发的token", required = true)
    })
    public JsonResult<List<FncRentalFees>> list(FncRentalFeesQueryVo queryVo) {
        return JsonResult.success(fncRentalFeesService.list(queryVo));
    }

}
