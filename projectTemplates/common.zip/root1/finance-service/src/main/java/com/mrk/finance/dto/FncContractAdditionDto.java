package com.mrk.finance.dto;

import com.mrk.finance.model.FncContractAddition;
import lombok.Data;

/**
 * @project: mrk-finance
 * @author: Frank.Tang
 * @date: 2021-12-06 16:56
 * @desc:
 **/
@Data
public class FncContractAdditionDto extends FncContractAddition {

    private String fcaTypeName;

    private String fcaPayTypeName;

}
