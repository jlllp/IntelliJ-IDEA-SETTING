package com.mrk.finance.dto;

import lombok.Data;

import java.io.Serializable;

/**
 * @author jlllp
 * @date 2022/6/15
 * @description
 */
@Data
public class ContractDocxExport implements Serializable {

    /**
     * 合同编号
     */
    private String contractNumber;

    /**
     * 甲方
     */
    private String partyA;

    /**
     * 甲纳税人识别号
     */
    private String aTaxpayerNumber;

    /**
     * 甲联系地址
     */
    private String aContactAddress;

    /**
     * 甲代表人
     */
    private String aRepresentative;

    /**
     * 甲联系人
     */
    private String aContact;

    /**
     * 甲联系方式
     */
    private String aContactInformation;

    /**
     * 甲电子邮箱
     */
    private String aEmail;

    /**
     * 甲开票地址
     */
    private String aBillingAddress;

    /**
     * 甲开票电话
     */
    private String aBillingPhone;

    /**
     * 甲开户银行
     */
    private String aDepositBank;

    /**
     * 甲银行账号
     */
    private String aBankAccount;

    /**
     * 乙方
     */
    private String partyB;

    /**
     * 乙纳税人识别号
     */
    private String bTaxpayerNumber;

    /**
     * 乙联系地址
     */
    private String bContactAddress;

    /**
     * 乙代表人
     */
    private String bRepresentative;

    /**
     * 乙联系人
     */
    private String bContact;

    /**
     * 乙联系方式
     */
    private String bContactInformation;

    /**
     * 乙电子邮箱
     */
    private String bEMail;

    /**
     * 乙开票地址
     */
    private String bSBillingAddress;

    /**
     * 乙开票电话
     */
    private String bBillingPhone;

    /**
     * 乙开户银行
     */
    private String bSBank;

    /**
     * 乙银行账号
     */
    private String bBankAccountNumber;

    /**
     * 合同签订地
     */
    private String placeOfContract;

    /**
     * 车辆类型
     */
    private String vehicleType;

    /**
     * 车辆数量
     */
    private String numberOfVehicles;

    /**
     * 车辆性质
     */
    private String vehicleNature;

    /**
     * 车辆交付地点
     */
    private String vehicleDeliveryLocation;

    /**
     * 交付方式
     */
    private String paymentMethod;

    /**
     * 租赁期数
     */
    private String numberOfLeasePeriods;

    /**
     * 租赁起始日期
     */
    private String leaseStartDate;

    /**
     * 租赁到期日期
     */
    private String leaseExpiryDate;

    /**
     * 租金
     */
    private String rent;

    /**
     * 保证金
     */
    private String securityDeposit;

    /**
     * 车辆归还地点
     */
    private String vehicleReturnLocation;

    /**
     * 转租
     */
    private String subletting;

    /**
     * 用途
     */
    private String use;

    /**
     * 费用明细
     */
    private String chargeDetails;

}
