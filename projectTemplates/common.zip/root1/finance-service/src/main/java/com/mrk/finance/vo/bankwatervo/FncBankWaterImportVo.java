package com.mrk.finance.vo.bankwatervo;

import cn.afterturn.easypoi.excel.annotation.Excel;
import lombok.Data;

import java.util.Date;

/**
 * @project: mrk-finance
 * @author: Frank.Tang
 * @date: 2021-11-15 18:32
 * @desc: 银行流水导入
 **/
@Data
public class FncBankWaterImportVo {

    @Excel(name = "凭证号")
    private String fncVoucherNo;

    @Excel(name = "本方账号")
    private String fncOwnAccount;

    @Excel(name = "对方账号")
    private String fncOtherAccount;

    @Excel(name = "对方单位名称")
    private String fncOtherUnitName;

    @Excel(name = "交易时间", importFormat = "yyyy-MM-dd HH:mm:ss" )
    private Date fncDealTime;

    @Excel(name = "借/贷")
    private String fncLoanType;

    @Excel(name = "借方发生额")
    private String fncBorrowAmountStr;
    private Double fncBorrowAmount;

    @Excel(name = "贷方发生额")
    private String fncCreditAmountStr;
    private Double fncCreditAmount;

    @Excel(name = "用途")
    private String fncUse;

    @Excel(name = "摘要")
    private String fncDigest;

}
