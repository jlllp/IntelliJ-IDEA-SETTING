package com.mrk.finance.dto.contract;

import lombok.Data;
import lombok.EqualsAndHashCode;

import java.util.Date;

/**
 * @author Bob
 * @date 2021-11-22
 * @description 租金账单Dto
 */
@EqualsAndHashCode(callSuper = true)
@Data
public class RentBillTimeRightDto extends RentTimeRightDto {

    /**
     * 账单开始时间
     */
    private Date billStart;

    /**
     * 账单结束时间
     */
    private Date billEnd;

    @Override
    public String toString() {
        return "RentBillTimeRightDto{" +
                "billStart=" + format(billStart) +
                ", billEnd=" + format(billEnd) +
                ", amount=" + getAmount() +
                '}';
    }
}
