package com.mrk.finance.facade;

import cn.afterturn.easypoi.excel.ExcelExportUtil;
import cn.afterturn.easypoi.excel.entity.ExportParams;
import com.github.pagehelper.PageInfo;
import com.mrk.auth.client.AuthDeptClient;
import com.mrk.auth.model.AuthDept;
import com.mrk.common.exception.GlobalException;
import com.mrk.common.utils.container.ListUtil;
import com.mrk.common.utils.text.CheckUtil;
import com.mrk.common.utils.text.StringUtils;
import com.mrk.finance.dto.FncConfirmIncomeDto;
import com.mrk.finance.dto.FncConfirmIncomeQueryDto;
import com.mrk.finance.model.FncConfirmIncome;
import com.mrk.finance.queryvo.FncConfirmIncomeQueryVo;
import com.mrk.finance.service.FncConfirmIncomeService;
import org.apache.poi.ss.usermodel.Workbook;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import javax.servlet.http.HttpServletResponse;
import java.util.List;

@Component
public class FncConfirmIncomeFacade {

  @Autowired
  private FncConfirmIncomeService fncConfirmIncomeService;

  @Autowired
  private AuthDeptClient authDeptClient;

  @Autowired
  private CarExportFacade exportByExcel;

  /**
   * 分页查询
   * @param queryVo
   * @return
   */
  public PageInfo<FncConfirmIncomeDto> page(FncConfirmIncomeQueryVo queryVo) {
    //复制属性
    String filterText = StringUtils.camelToUnderlineAndFilterText(queryVo.getSidx());
    queryVo.setSidx(filterText);
    PageInfo<FncConfirmIncome> page = fncConfirmIncomeService.page(queryVo);
    List<FncConfirmIncomeDto> fncConfirmIncomeDtos = ListUtil.copyBeanList(page.getList(),FncConfirmIncomeDto.class);
    for(FncConfirmIncomeDto fncConfirmIncomeDto : fncConfirmIncomeDtos){
      if(CheckUtil.isNotEmpty(fncConfirmIncomeDto.getFciDeptId())){
        AuthDept authDept = authDeptClient.getAuthDeptById(fncConfirmIncomeDto.getFciDeptId()).getDataWithEx();
        fncConfirmIncomeDto.setFciDeptIdText(authDept == null ? "" : authDept.getDeptName());
      }
    }
    return new PageInfo<>(fncConfirmIncomeDtos);
  }

  /**
   * @author Bob
   * @date 2021/3/30 17:15
   * @description 根据查询条件导出excel文件
   */
  public void export(FncConfirmIncomeQueryVo queryVo, HttpServletResponse response) {
    PageInfo<FncConfirmIncomeDto> fncConfirmIncomeDtoPageInfo = page(queryVo);
    int maxSize = 50000;
    if (fncConfirmIncomeDtoPageInfo.getTotal() > maxSize) {
      throw new GlobalException("导出的数量超过5万条，请缩小范围");
    }
    // 导出文件
    List<FncConfirmIncomeQueryDto> boxUpVoList = ListUtil.copyBeanList(fncConfirmIncomeDtoPageInfo.getList(), FncConfirmIncomeQueryDto.class);
    Workbook workbook = ExcelExportUtil.exportExcel(new ExportParams(), FncConfirmIncomeQueryDto.class, boxUpVoList);
    String fileName = "确认收入" + System.currentTimeMillis() + ".xls";
    exportByExcel.exportByExcel(response, fileName, workbook);
  }

}
