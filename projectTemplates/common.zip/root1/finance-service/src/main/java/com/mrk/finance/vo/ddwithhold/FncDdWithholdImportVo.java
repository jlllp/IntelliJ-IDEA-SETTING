package com.mrk.finance.vo.ddwithhold;

import cn.afterturn.easypoi.excel.annotation.Excel;
import lombok.Data;

import java.io.Serializable;

@Data
public class FncDdWithholdImportVo implements Serializable {

  /**交易账目 */
  @Excel(name = "交易账目")
  private String fncTradeNames;

  /**交易流水号 */
  @Excel(name = "交易流水号")
  private String fncAccountDealFlow;

  /**交易方 */
  @Excel(name = "交易方")
  private String fncTradeParty;

  /**订单号 */
  @Excel(name = "订单号")
  private String fncOrderNo;

  /**车架号 */
  @Excel(name = "车架号")
  private String fncCarVin;

  /**账单号（滴滴） */
  @Excel(name = "账单号（滴滴）")
  private String fncAccountNo;

  /**交易金额 */
  @Excel(name = "交易金额")
  private String fncTradeAmountStr;

  private Double fncTradeAmount;

  /**交易时间 */
  @Excel(name = "交易时间", importFormat = "yyyy-MM-dd HH:mm:ss" )
  private java.util.Date fncTradeTime;
}
