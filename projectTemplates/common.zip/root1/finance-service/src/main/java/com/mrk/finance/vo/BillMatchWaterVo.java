package com.mrk.finance.vo;

import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.math.BigDecimal;

/**
 * @project: mrk-finance
 * @author: Frank.Tang
 * @date: 2021-11-12 15:29
 * @desc: 账单匹配流水
 **/
@Data
public class BillMatchWaterVo {

    @ApiModelProperty("账单id")
    private Long fbmId;

    @ApiModelProperty("流水信息(前缀+id)")
    private String waterInfo;

    @ApiModelProperty("匹配金额(手动输入)")
    private BigDecimal matchMoney;

    @ApiModelProperty("tt或滴滴主键")
    private Long waterId;

}
