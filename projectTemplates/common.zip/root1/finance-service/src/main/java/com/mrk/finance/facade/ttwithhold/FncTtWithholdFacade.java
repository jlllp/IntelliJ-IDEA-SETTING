package com.mrk.finance.facade.ttwithhold;

import com.github.pagehelper.PageInfo;
import com.mrk.auth.client.AuthDeptClient;
import com.mrk.auth.client.AuthUserClient;
import com.mrk.auth.model.AuthCity;
import com.mrk.auth.model.AuthUser;
import com.mrk.common.constant.BaseConstants;
import com.mrk.common.exception.GlobalException;
import com.mrk.common.utils.bean.BeanUtils;
import com.mrk.common.utils.container.ListUtil;
import com.mrk.common.utils.jwt.JWTUtil;
import com.mrk.common.utils.text.CheckUtil;
import com.mrk.common.utils.text.StringUtils;
import com.mrk.finance.dto.fncttexport.FncTtWithholdDto;
import com.mrk.finance.enums.BillStateEnum;
import com.mrk.finance.enums.MatchWayEnum;
import com.mrk.finance.enums.WaterMatchStateEnum;
import com.mrk.finance.enums.WaterMatchTypeEnum;
import com.mrk.finance.facade.common.FinanceUserNameFacade;
import com.mrk.finance.model.FncBillManagement;
import com.mrk.finance.model.FncRevenueWaterRecord;
import com.mrk.finance.model.FncTtWithhold;
import com.mrk.finance.queryvo.FncTtWithholdQueryVo;
import com.mrk.finance.resolver.EnumResolver;
import com.mrk.finance.service.FncBillManagementService;
import com.mrk.finance.service.FncRevenueWaterRecordService;
import com.mrk.finance.service.FncTtWithholdService;
import com.mrk.finance.util.MatchUtil;
import com.mrk.finance.vo.BillMatchWaterVo;
import com.mrk.sys.client.SysCarTypeClient;
import com.mrk.sys.model.SysCarType;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigDecimal;
import java.util.Arrays;
import java.util.Date;
import java.util.List;
import java.util.stream.Collectors;

@Component
public class FncTtWithholdFacade {

  @Autowired
  private FncTtWithholdService fncTtWithholdService;

  @Autowired
  private SysCarTypeClient sysCarTypeClient;
  @Autowired
  private AuthDeptClient authDeptClient;

  @Autowired
  private AuthUserClient authUserClient;
  @Autowired
  private FncBillManagementService fncBillManagementService;

  @Autowired
  private FncRevenueWaterRecordService fncRevenueWaterRecordService;


  @Autowired
  private FinanceUserNameFacade financeUserNameFacade;

  /**
   * 分页查询
   * @param queryVo
   * @return
   */
  public PageInfo<FncTtWithholdDto> page(FncTtWithholdQueryVo queryVo){
    String filterText = StringUtils.camelToUnderlineAndFilterText(queryVo.getSidx());
    queryVo.setSidx(filterText);
    PageInfo<FncTtWithhold> ttWithholdPageInfo = fncTtWithholdService.page(queryVo);
    //解析数据
    List<FncTtWithholdDto> fncTtWithholdDtos = ListUtil.copyBeanList(ttWithholdPageInfo.getList(), FncTtWithholdDto.class);
    for(FncTtWithholdDto fncTtWithholdDto : fncTtWithholdDtos){
      //转化车型
        if(CheckUtil.isNotEmpty(fncTtWithholdDto.getFtwCarModel())){
          SysCarType sysCarType = sysCarTypeClient.getById(fncTtWithholdDto.getFtwCarModel()).getDataWithEx();
          fncTtWithholdDto.setFtwCarModelText(sysCarType == null ? "" : sysCarType.getCarTypeName());
        }
        //匹配状态
        fncTtWithholdDto.setFtwMatchStateText(EnumResolver.匹配状态.get(fncTtWithholdDto.getFtwMatchState()));
        //匹配方式
        fncTtWithholdDto.setFtwMatchWayText(EnumResolver.匹配方式.get(fncTtWithholdDto.getFtwMatchWay()));
        //城市
        if(CheckUtil.isNotEmpty(fncTtWithholdDto.getFtwCityId())) {
          AuthCity authCity = authDeptClient.getAuthCity(fncTtWithholdDto.getFtwCityId()).getDataWithEx();
          fncTtWithholdDto.setFtwCityIdText(authCity == null ? "" : authCity.getCityName());
        }
    }
    return new PageInfo<>(fncTtWithholdDtos);
  }

  /**
   * 根据id获取tt详情
   * @param id
   * @return
   */
  public FncTtWithholdDto details(Long id) {
    CheckUtil.isEmptyWithEx(id, "tt明细主键不能为空");
    FncTtWithhold fncTtWithhold = fncTtWithholdService.getById(id);
    CheckUtil.isEmptyWithEx(fncTtWithhold, "tt明细主键不存在");
    FncTtWithholdDto fncTtWithholdDto = BeanUtils.copyBean(fncTtWithhold, FncTtWithholdDto.class);
    //转化车型
    if(CheckUtil.isNotEmpty(fncTtWithholdDto.getFtwCarModel())){
      SysCarType sysCarType = sysCarTypeClient.getById(fncTtWithholdDto.getFtwCarModel()).getDataWithEx();
      fncTtWithholdDto.setFtwCarModelText(sysCarType == null ? "" : sysCarType.getCarTypeName());
    }
    //匹配状态
    fncTtWithholdDto.setFtwMatchStateText(EnumResolver.匹配状态.get(fncTtWithholdDto.getFtwMatchState()));
    //匹配方式
    fncTtWithholdDto.setFtwMatchWayText(EnumResolver.匹配方式.get(fncTtWithholdDto.getFtwMatchWay()));
    //城市
    if(CheckUtil.isNotEmpty(fncTtWithholdDto.getFtwCityId())) {
      AuthCity authCity = authDeptClient.getAuthCity(fncTtWithholdDto.getFtwCityId()).getDataWithEx();
      fncTtWithholdDto.setFtwCityIdText(authCity == null ? "" : authCity.getCityName());
    }
    return fncTtWithholdDto;
  }

  /**
   * 手动匹配
   * @param billMatchWaterVo
   * @return
   */
  @Transactional(rollbackFor = Exception.class)
  public void price(BillMatchWaterVo billMatchWaterVo) {
    //检验数据
    CheckUtil.isEmptyWithEx(billMatchWaterVo.getWaterId(), "tt主键不能为空");
    CheckUtil.isEmptyWithEx(billMatchWaterVo.getFbmId(), "账单主键不能为空");
    CheckUtil.isEmptyWithEx(billMatchWaterVo.getMatchMoney(), "匹配金额不能为空");
    if(billMatchWaterVo.getMatchMoney().compareTo(BigDecimal.ZERO) < 1){
      throw new GlobalException("匹配金额必须大于0");
    }
    //tt
    FncTtWithhold fncTtWithhold = fncTtWithholdService.getById(billMatchWaterVo.getWaterId());
    CheckUtil.isEmptyWithEx(fncTtWithhold, "tt代扣不存在");
    //判断状态
    if(WaterMatchStateEnum.ALL_MATCH.getValue().equals(fncTtWithhold.getFtwMatchState())){
      throw new GlobalException("已匹配的tt不能再匹配");
    }
    if(CheckUtil.isEmpty(fncTtWithhold.getFtwMatchedAmount())){
      fncTtWithhold.setFtwMatchedAmount(0.0);
    }
    //tt未匹配金额
    BigDecimal priceTt = BigDecimal.valueOf(fncTtWithhold.getFtwNotMatchAmount());
    //tt已匹配金额
    BigDecimal priceNotTt = BigDecimal.valueOf(fncTtWithhold.getFtwMatchedAmount());
    if(priceTt.subtract(billMatchWaterVo.getMatchMoney()).compareTo(BigDecimal.ZERO) < 0){
      throw new GlobalException("匹配金额不能大于t3未匹配金额");
    }
    //账单
    FncBillManagement billManagement = fncBillManagementService.getById(billMatchWaterVo.getFbmId());
    CheckUtil.isEmptyWithEx(billManagement, "账单不存在");
    //判断状态
    if(WaterMatchStateEnum.ALL_MATCH.getValue().equals(billManagement.getFbmBillState())){
      throw new GlobalException("选择的账单状态不符合");
    }
    if(CheckUtil.isEmpty(billManagement.getFbmMatchedAmount())){
      billManagement.setFbmMatchedAmount(0.0);
    }
    //账单未匹配金额
    BigDecimal priceBill = BigDecimal.valueOf(billManagement.getFbmNotMatchAmount());
    //账单金额
    BigDecimal billMoney = BigDecimal.valueOf(billManagement.getFbmBillAmount());
    if(billMoney.compareTo(BigDecimal.ZERO) <= 0){
      throw new GlobalException("不能匹配‘借(负数)’的账单！");
    }
    //账单已匹配金额
    BigDecimal priceNotBill = BigDecimal.valueOf(billManagement.getFbmMatchedAmount());
    if(priceBill.subtract(billMatchWaterVo.getMatchMoney()).compareTo(BigDecimal.ZERO) < 0){
      throw new GlobalException("匹配金额不能大于账单未匹配金额");
    }
    //tt减去匹配金额后的未匹配金额
    fncTtWithhold.setFtwNotMatchAmount(priceTt.subtract(billMatchWaterVo.getMatchMoney()).doubleValue());
    //tt加上匹配金额后的已匹配金额
    fncTtWithhold.setFtwMatchedAmount(priceNotTt.add(billMatchWaterVo.getMatchMoney()).doubleValue());
    //tt匹配状态
    if(priceTt.subtract(billMatchWaterVo.getMatchMoney()).compareTo(BigDecimal.ZERO) == 0){
      fncTtWithhold.setFtwMatchState(WaterMatchStateEnum.ALL_MATCH.getValue());
    }else {
      fncTtWithhold.setFtwMatchState(WaterMatchStateEnum.PART_MATCH.getValue());
    }
    //账单加上匹配金额后的已匹配金额
    billManagement.setFbmMatchedAmount(priceNotBill.add(billMatchWaterVo.getMatchMoney()).doubleValue());
    //账单减去匹配金额后的未匹配金额
    billManagement.setFbmNotMatchAmount(priceBill.subtract(billMatchWaterVo.getMatchMoney()).doubleValue());
    //账单匹配状态
    if(priceBill.subtract(billMatchWaterVo.getMatchMoney()).compareTo(BigDecimal.ZERO) == 0){
      billManagement.setFbmBillState(BillStateEnum.PAID_ALL.getValue());
    }else {
      billManagement.setFbmBillState(BillStateEnum.PAID_PART.getValue());
    }
    String bmMatchSerialNumberStr = MatchUtil.splicing(billManagement.getFbmMatchSerialNumber(),WaterMatchTypeEnum.TT.getName()+ fncTtWithhold.getFtwId());
    billManagement.setFbmMatchSerialNumber(
      bmMatchSerialNumberStr
    );
    String twMatchBillStr = MatchUtil.splicing(fncTtWithhold.getFtwMatchBill(), billManagement.getFbmId());
    fncTtWithhold.setFtwMatchBill(twMatchBillStr);
    //修改tt
    fncTtWithholdService.update(fncTtWithhold);
    //修改账单
    fncBillManagementService.update(billManagement);
    //更新记录
    saveRecord(billManagement, fncTtWithhold, billMatchWaterVo.getMatchMoney());
  }

  /**
   * 更新流水记录
   * @param billManagement
   * @param fncTtWithhold
   * @param bigDecimal
   */
  public void saveRecord(FncBillManagement billManagement, FncTtWithhold fncTtWithhold, BigDecimal bigDecimal){
    FncRevenueWaterRecord waterRecord = new FncRevenueWaterRecord();
    //记录的描述信息
    waterRecord.setFrwrBillId(billManagement.getFbmId());
    Long userId = JWTUtil.getUserId();
    AuthUser user = authUserClient.getAuthUserById(userId).getDataWithEx();
    String userNamePhone = financeUserNameFacade.getUserNamePhone(user);
    String desc = "" + userNamePhone+
      "发起手动匹配，匹配成功。匹配账单号" +
      billManagement.getFbmId() + "，" +
      "匹配金额" + bigDecimal + "元，" +
      "流水剩余金额" +
      fncTtWithhold.getFtwNotMatchAmount() +
      "元";
    waterRecord.setFrwrDescribe(desc);
    waterRecord.setCreatetime(new Date());
    waterRecord.setFrwrRevenueId(fncTtWithhold.getFtwId());
    waterRecord.setFrwrMatchState(MatchWayEnum.MANUAL.getValue());
    waterRecord.setFrwrRevenueType(WaterMatchTypeEnum.TT.getValue());
    //保存
    fncRevenueWaterRecordService.add(waterRecord);
  }

  /**
   * 批量删除
   * @param idStr
   */
  @Transactional(rollbackFor = Exception.class)
  public void delete(String idStr) {
    CheckUtil.isEmptyWithEx(idStr, "主键不能为空");
    //TT
    List<Long> idList = Arrays.stream(idStr.split(","))
      .map(s -> Long.parseLong(s.trim())).collect(Collectors.toList());
    for(Long id : idList){
      FncTtWithhold fncTtWithhold = fncTtWithholdService.getById(id);
      CheckUtil.isEmptyWithEx(fncTtWithhold, "T3代扣不存在");
      if(!WaterMatchStateEnum.NOT_MATCH.getValue().equals(fncTtWithhold.getFtwMatchState())){
        throw new GlobalException("当前状态不可删除");
      }
      fncTtWithhold.setDr(BaseConstants.DR_YES);
      fncTtWithholdService.update(fncTtWithhold);
    }
  }
}
