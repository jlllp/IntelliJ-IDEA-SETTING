package com.mrk.finance.util;


import com.mrk.common.utils.text.StringUtils;

import java.lang.reflect.Field;
import java.util.Arrays;
import java.util.Collection;
import java.util.HashSet;
import java.util.Set;
import java.util.stream.Collectors;

/**
 * @project: mrk-finance
 * @author: Frank.Tang
 * @date: 2021-11-11 17:03
 * @desc:
 **/
public class ObjectUtil {

    /** 默认拼接符 */
    public static final String SEPARATOR = ",";


    private ObjectUtil() {}

    /**
     * 判断对象所有成员变量为null
     * @author Frank.Tang
     * @return true ---> 全为空
     *         false --> 不全为空
     */
    public static boolean allFieldsIsNull(Object object) {
        if (null == object) {
            return true;
        }
        try {
            for (Field f : object.getClass().getDeclaredFields()) {
                f.setAccessible(true);
                Object field = f.get(object);
                if (field != null && StringUtils.isNotBlank(field.toString())) {
                    return false;
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return true;
    }

    /**
     * 判断对象所有成员变量为null
     * @author Frank.Tang
     * @param object 目标对象
     * @param excepts 除外字段(小驼峰)
     * @return true ---> 全为空
     *         false --> 不全为空
     */
    public static boolean allFieldsIsNull(Object object, String... excepts) {
        if (null == object) {
            return true;
        }

        Set<String> fields = excepts == null ?
                new HashSet<>() :
                Arrays.stream(excepts).collect(Collectors.toSet());
        try {
            for (Field f : object.getClass().getDeclaredFields()) {
                if (fields.contains(f.getName())) {
                    continue;
                }
                f.setAccessible(true);
                Object field = f.get(object);
                if (field != null && StringUtils.isNotBlank(field.toString())) {
                    return false;
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return true;
    }

    /**
     * 集合转 x,xx,xxx 格式字符串
     * @author Frank.Tang
     * @param collection 集合
     * @param separator 分隔符
     * @return *
     */
    public static String collectionToStr(Collection<?> collection, String separator) {
        if (collection == null || collection.isEmpty()) {
            return "";
        }
        collection.remove(null);
        return StringUtils.join(collection, separator);
    }

    /**
     * 集合转 x,xx,xxx 格式字符串 (默认英文逗号分隔)
     * @author Frank.Tang
     * @param collection 集合
     * @return *
     */
    public static String collectionToStr(Collection<?> collection) {
        return collectionToStr(collection, SEPARATOR);
    }
}
