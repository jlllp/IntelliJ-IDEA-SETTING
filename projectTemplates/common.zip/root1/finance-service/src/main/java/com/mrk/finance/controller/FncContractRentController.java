package com.mrk.finance.controller;

import com.github.pagehelper.PageInfo;
import com.mrk.common.utils.page.JsonResult;
import com.mrk.finance.model.FncContractRent;
import com.mrk.finance.queryvo.FncContractRentQueryVo;
import com.mrk.finance.service.FncContractRentService;
import com.mrk.log.annotation.Log;
import com.mrk.log.enums.BusinessType;
import com.mrk.log.enums.OperatorType;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiImplicitParam;
import io.swagger.annotations.ApiImplicitParams;
import io.swagger.annotations.ApiOperation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;


/**
 * FncContractRentController

 */
@RestController
@RequestMapping("/financeservice/fnccontractrent")
@Api(tags = "/合同租金")
public class FncContractRentController {
    @Autowired
    private FncContractRentService fncContractRentService;

    @PostMapping(value = "/add")
    @ApiOperation("合同租金-新增")
    @ApiImplicitParams({
            @ApiImplicitParam(paramType = "header", name = "Authorization", value = "系统下发的token", required = true)
    })
    @Log(title = "合同租金", value = "新增", businessType = BusinessType.INSERT, operatorType = OperatorType.MANAGE)
    public JsonResult<Object>  add(FncContractRent entity) {
        return JsonResult.success(fncContractRentService.add(entity));
    }

    @PostMapping(value = "/del/{id}")
    @ApiOperation("合同租金-删除")
    @ApiImplicitParams({
            @ApiImplicitParam(paramType = "header", name = "Authorization", value = "系统下发的token", required = true)
    })
    @Log(title = "合同租金", value = "删除", businessType = BusinessType.DELETE, operatorType = OperatorType.MANAGE)
    public JsonResult<Object>  del(@PathVariable("id") Long id) {
        return JsonResult.success(fncContractRentService.delete(id));
    }

    @PostMapping(value = "/update")
    @ApiOperation("合同租金-更新")
    @ApiImplicitParams({
            @ApiImplicitParam(paramType = "header", name = "Authorization", value = "系统下发的token", required = true)
    })
    @Log(title = "合同租金", value = "更新", businessType = BusinessType.UPDATE, operatorType = OperatorType.MANAGE)
    public JsonResult<Object>  update(FncContractRent entity) {
        return JsonResult.success(fncContractRentService.update(entity));
    }


    @GetMapping(value = "/page")
    @ApiOperation("合同租金-分页查询")
    @ApiImplicitParams({
            @ApiImplicitParam(paramType = "header", name = "Authorization", value = "系统下发的token", required = true)
    })
    public JsonResult<PageInfo<FncContractRent>> page(FncContractRentQueryVo queryVo) {
        return JsonResult.success(fncContractRentService.page(queryVo));
    }

    @GetMapping(value = "/list")
    @ApiOperation("合同租金-列表查询")
    @ApiImplicitParams({
            @ApiImplicitParam(paramType = "header", name = "Authorization", value = "系统下发的token", required = true)
    })
    public JsonResult<List<FncContractRent>> list(FncContractRentQueryVo queryVo) {
        return JsonResult.success(fncContractRentService.list(queryVo));
    }


}
