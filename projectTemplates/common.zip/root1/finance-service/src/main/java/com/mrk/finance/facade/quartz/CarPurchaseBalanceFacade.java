package com.mrk.finance.facade.quartz;

import com.mrk.finance.dto.date.TimeRightDto;
import com.mrk.finance.enums.*;
import com.mrk.finance.facade.contract.ContractOnlyCarFacade;
import com.mrk.finance.model.FncBillManagement;
import com.mrk.finance.model.FncContractManagement;
import com.mrk.finance.service.FncBillManagementService;
import com.mrk.finance.service.FncContractManagementService;
import com.mrk.finance.util.StreamUtil;
import com.mrk.finance.util.ThreadUtil;
import com.mrk.finance.util.contract.ContractDateCalculateUtil;
import com.mrk.universal.enums.contract.ContractTypeEnum;
import com.mrk.universal.enums.turner.TurnerSingleOverTimeEnum;
import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.collections4.MapUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Component;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.Objects;
import java.util.SortedMap;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.Executor;

/**
 * @author Bob
 * @date 2021-11-15
 * @description
 */
@Component
public class CarPurchaseBalanceFacade {

    private static final Logger log = LoggerFactory.getLogger(CarPurchaseBalanceFacade.class);

    @Autowired
    private FncBillManagementService fncBillManagementService;

    @Autowired
    private FncContractManagementService fncContractManagementService;

    @Autowired
    private ContractOnlyCarFacade contractOnlyCarFacade;

    @Autowired
    @Qualifier("quartzServiceExecutor")
    private Executor executor;

    /**
     * @author Bob
     * @date 2021/11/15
     * @description 购车尾款计算
     * @param paramStr 请求参数
     */
    public void carPurchaseBalanceGeneration(String paramStr) {
        log.info("购车尾款生成定时任务 --> 开始");
        long startTime = System.currentTimeMillis();
        // 获取所有科目为购车尾款的账单
        List<FncBillManagement> fncBillManagements = fncBillManagementService.getBySubject(BillSubjectsEnum.BALANCE.getValue());
        // 获取已经拥有账单的合同ID
        List<Long> contractIds = StreamUtil.toList(fncBillManagements, FncBillManagement::getFbmAssociateContractId);
        log.info("购车尾款生成定时任务 获取到已存在购车尾款的合同数量 --> size：【{}】", contractIds.size());
        // 定义对象  用于存储需要判断是否生成购车尾款的合同
        List<FncContractManagement> contractManagementList;
        // 不用排除已生成购车尾款的账单
        if (CollectionUtils.isEmpty(contractIds)) {
            // 获取所有合同状态为租赁中的合同 合同类型为以租代售的合同
            contractManagementList = fncContractManagementService.getByStateAndType(ContractStateEnum.LEASED.getState(), ContractTypeEnum.RENT_FOR_SALE.getType());
        } else {
            // 获取所有合同状态为租赁中的合同 合同类型为以租代售的合同 排除掉已经生成账单的合同
            contractManagementList = fncContractManagementService.getByStateAndTypeAndIdNotIn(ContractStateEnum.LEASED.getState(), ContractTypeEnum.RENT_FOR_SALE.getType(), contractIds);
        }
        if (CollectionUtils.isEmpty(contractManagementList)) {
            log.info("购车尾款生成定时任务 获取到待计算购车尾款生成的合同数量为0 计算结束");
            return;
        }

        log.info("购车尾款生成定时任务 获取到待计算购车尾款生成的合同数量为 --> size：【{}】", contractManagementList.size());
        // 多线程处理
        ThreadUtil.execution(contractManagementList, this::calculateTheEndOfTheCarPurchase, executor);
        log.info("购车尾款生成定时任务 --> 结束 耗时：【{}】", System.currentTimeMillis() - startTime);
    }

    /**
     * @author Bob
     * @date 2021/11/15
     * @description 计算车辆的购车尾款
     * @param countDownLatch 同步工具
     * @param fncContractManagement 待计算的合同
     */
    private void calculateTheEndOfTheCarPurchase(CountDownLatch countDownLatch, FncContractManagement fncContractManagement) {
        try {
            Long contractId = fncContractManagement.getFcmId();
            log.info("购车尾款生成定时任务 计算车辆购车尾款生成开始 --> contractId：【{}】", contractId);
            // 检查数据 计算要使用到的字段不能为空
            if (checkRequiredField(fncContractManagement)) return;
            // 计算合同的购车尾款生成
            doCalculateTheEndOfTheCarPurchase(fncContractManagement);
            log.info("购车尾款生成定时任务 计算车辆购车尾款生成结束 --> contractId：【{}】", contractId);
        } finally {
            countDownLatch.countDown();
        }
    }

    /**
     * @author Bob
     * @date 2021/11/15
     * @description 计算合同的购车尾款生成
     * @param fncContractManagement 合同
     */
    private void doCalculateTheEndOfTheCarPurchase(FncContractManagement fncContractManagement) {
        // 租赁周期
        SimpleDateFormat simpleDateFormat = new SimpleDateFormat("yyyy-MM-dd");
        String startDayStr = simpleDateFormat.format(fncContractManagement.getFcmLeaseStartDate());
        Integer rentPayCycle = fncContractManagement.getFcmRentPayCycle();
        Integer interval = ContractRentPaymentCycleEnum.toIntervalValue(rentPayCycle);
        log.info("购车尾款生成定时任务 根据合同计算租期 --> contractId：【{}】 startDate：【{}】 month：【{}】  periodType：【{}】 interval：【{}】",
                fncContractManagement.getFcmId(), startDayStr,
                fncContractManagement.getFcmLeaseCount(), fncContractManagement.getFcmRentPayType(), interval);

        SortedMap<Integer, TimeRightDto> paymentCycleMap = ContractDateCalculateUtil
                .calculateThePaymentPeriod(fncContractManagement.getFcmLeaseStartDate(), fncContractManagement.getFcmLeaseCount(),
                        fncContractManagement.getFcmRentPayType(), interval);
        if (MapUtils.isEmpty(paymentCycleMap)) {
            log.info("购车尾款生成定时任务 计算车辆租赁周期失败，跳过 --> contractId：【{}】", fncContractManagement.getFcmId());
            return;
        }

        // 获取最后一期
        Integer cycle = paymentCycleMap.lastKey();
        // 获取最后一个的开始结束日期
        TimeRightDto timeRightDto = paymentCycleMap.get(cycle);
        startDayStr = simpleDateFormat.format(timeRightDto.getStart());
        String endDayStr = simpleDateFormat.format(timeRightDto.getEnd());
        log.info("购车尾款生成定时任务 计算出租赁的最后一个周期 --> contractId：【{}】 startDay：【{}】 endDay：【{}】", fncContractManagement.getFcmId(),
                startDayStr, endDayStr);
        // 获取今天时间
        Date today = ContractDateCalculateUtil.ignoreHoursMinutesAndSeconds(new Date());
        // 最后一期的开始时间小于等于今天 不生产购车尾款账单
        if (!timeRightDto.getStart().after(today)) {
            // 创建一笔科目为购车尾款的账单
            createBill(fncContractManagement, timeRightDto);
        }
    }

    /**
     * @author Bob
     * @date 2021/11/29
     * @description 创建购车尾款账单
     * @param fncContractManagement 合同
     * @param timeRightDto 最后一期开始结束时间
     */
    private void createBill(FncContractManagement fncContractManagement, TimeRightDto timeRightDto) {
        // 构建账单
        FncBillManagement fncBillManagement = new FncBillManagement();
        fncBillManagement.setFbmCityId(fncContractManagement.getFcmCityId());
        fncBillManagement.setFbmSubjects(BillSubjectsEnum.BALANCE.getValue());
        fncBillManagement.setFbmBillAmount(fncContractManagement.getFcmCarPurchase());
        fncBillManagement.setFbmNper("/");
        fncBillManagement.setFbmBillGenerateTime(timeRightDto.getStart());
        fncBillManagement.setFbmBillGenerateWay(BillGenerateWayEnum.AUTO.getValue());
        fncBillManagement.setFbmBillCatoffTime(timeRightDto.getEnd());
        // 合同只有一辆车的情况下才写入车辆id
        Long carId = contractOnlyCarFacade.getCarIdByContract(fncContractManagement);
        fncBillManagement.setFbmAssociateCarId(carId);
        fncBillManagement.setFbmAssociateContractId(fncContractManagement.getFcmId());
        fncBillManagement.setFbmBillState(BillStateEnum.UNPAID.getValue());
        fncBillManagement.setFbmMatchedAmount(0D);
        fncBillManagement.setFbmNotMatchAmount(fncContractManagement.getFcmCarPurchase());
        fncBillManagement.setFbmTurnerDeal(TurnerSingleOverTimeEnum.NO.getState());
        // 保存账单
        fncBillManagementService.add(fncBillManagement);
    }

    /**
     * @author Bob
     * @date 2021/11/15
     * @description 购车尾款计算所需字段校验
     * @param fncContractManagement 合同
     * @return true 表示所需字段存在null的情况， false不存在
     */
    private boolean checkRequiredField(FncContractManagement fncContractManagement) {
        Long contractId = fncContractManagement.getFcmId();
        // 购车尾款字段
        if (Objects.isNull(fncContractManagement.getFcmCarPurchase())) {
            log.warn("购车尾款生成定时任务 购车尾款为空，跳过 --> contractId：【{}】", contractId);
            return true;
        }
        // 租期
        if (Objects.isNull(fncContractManagement.getFcmLeaseCount())) {
            log.warn("购车尾款生成定时任务 租期为空，跳过 --> contractId：【{}】", contractId);
            return true;
        }
        // 租赁起始日期
        if (Objects.isNull(fncContractManagement.getFcmLeaseStartDate())) {
            log.warn("购车尾款生成定时任务 租赁起始日期为空，跳过 --> contractId：【{}】", contractId);
            return true;
        }
        // 租赁结束日期
        if (Objects.isNull(fncContractManagement.getFcmLeaseEndDate())) {
            log.warn("购车尾款生成定时任务 租赁结束日期为空，跳过 --> contractId：【{}】", contractId);
            return true;
        }
        // 租赁支付类型
        if (Objects.isNull(fncContractManagement.getFcmRentPayType())) {
            log.warn("购车尾款生成定时任务 租赁支付类型为空，跳过 --> contractId：【{}】", contractId);
            return true;
        }
        // 租赁支付周期
        if (Objects.isNull(fncContractManagement.getFcmRentPayCycle())) {
            log.warn("购车尾款生成定时任务 租赁支付周期为空，跳过 --> contractId：【{}】", contractId);
            return true;
        }
        return false;
    }
}
