package com.mrk.finance.controller;

import com.github.pagehelper.PageInfo;
import com.mrk.common.utils.page.JsonResult;
import com.mrk.finance.dto.FncBillManagementDto;
import com.mrk.finance.dto.FncContractManagementDto;
import com.mrk.finance.dto.contract.RentCalculationDto;
import com.mrk.finance.facade.contract.FncContractManagementFacade;
import com.mrk.finance.model.FncContractManagement;
import com.mrk.finance.queryvo.FncBillManagementQueryVo;
import com.mrk.finance.queryvo.FncContractManagementQueryVo;
import com.mrk.finance.service.FncContractManagementService;
import com.mrk.finance.vo.ContractAddOrUpdateVo;
import com.mrk.log.annotation.Log;
import com.mrk.log.enums.BusinessType;
import com.mrk.log.enums.OperatorType;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiImplicitParam;
import io.swagger.annotations.ApiImplicitParams;
import io.swagger.annotations.ApiOperation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import javax.servlet.http.HttpServletResponse;
import java.math.BigDecimal;
import java.util.List;


/**
 * FncContractManagementController
 */
@RestController
@RequestMapping("/financeservice/lese_fnccontractmanagement")
@Api(tags = "/2022-06-02-合同管理")
public class FncContractManagementLeaseController {

    @Autowired
    private FncContractManagementFacade fncContractManagementFacade;


    @GetMapping(value = "/lease_page")
    @ApiOperation("合同管理-分页查询审批中或者执行中的合同")
    @ApiImplicitParams({
            @ApiImplicitParam(paramType = "header", name = "Authorization", value = "系统下发的token", required = true)
    })
    public JsonResult<PageInfo<FncContractManagement>> leasePage(FncContractManagementQueryVo queryVo) {
        return JsonResult.success(fncContractManagementFacade.leasePage(queryVo));
    }

}
