package com.mrk.finance.facade.bankwater;

import com.github.pagehelper.PageInfo;
import com.mrk.common.constant.BaseConstants;
import com.mrk.common.exception.GlobalException;
import com.mrk.common.utils.container.ListUtil;
import com.mrk.common.utils.jwt.JWTUtil;
import com.mrk.common.utils.text.CheckUtil;
import com.mrk.finance.constants.ExMsgConstants;
import com.mrk.finance.dto.FncBankWaterDto;
import com.mrk.finance.enums.BillStateEnum;
import com.mrk.finance.enums.MatchWayEnum;
import com.mrk.finance.enums.WaterLoanTypeEnum;
import com.mrk.finance.enums.WaterMatchStateEnum;
import com.mrk.finance.facade.FncWaterAutoMatchFacade;
import com.mrk.finance.facade.bill.FncBillManagementFacade;
import com.mrk.finance.facade.dto.WaterIntegrationDto;
import com.mrk.finance.model.FncBankWater;
import com.mrk.finance.model.FncBillManagement;
import com.mrk.finance.model.FncRevenueWaterRecord;
import com.mrk.finance.queryvo.FncBankWaterQueryVo;
import com.mrk.finance.queryvo.FncRevenueWaterRecordQueryVo;
import com.mrk.finance.service.FncBankWaterService;
import com.mrk.finance.service.FncBillManagementService;
import com.mrk.finance.service.FncRevenueWaterRecordService;
import com.mrk.finance.util.ExceptionUtil;
import com.mrk.finance.vo.WaterMatchBillVo;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.math.BigDecimal;
import java.util.List;

/**
 * @project: mrk-finance
 * @author: Frank.Tang
 * @date: 2021-11-15 17:45
 * @desc: 银行流水
 *
 * 银行流水, 相关方法汇总:
 *     (1)分页---------{@link FncBankWaterFacade\#page}
 *     (2)删除---------{@link FncBankWaterFacade\#del}
 *     (3)查询收支明细--{@link FncBankWaterFacade\#pageRecord}
 *     (4)手动匹配------{@link FncBankWaterFacade\#manuallyMatch}
 *     (5)自动匹配------{@link FncWaterAutoMatchFacade\#bwAutoMatch}
 *     (6)导入导出------{@link FncBankWaterImportFacade}
 *
 **/
@Slf4j
@Component
public class FncBankWaterFacade {

    @Autowired
    private FncBankWaterService fncBankWaterService;
    @Autowired
    private FncBillManagementService fncBillManagementService;
    @Autowired
    private FncBillManagementFacade fncBillManagementFacade;
    @Autowired
    private FncRevenueWaterRecordService fncRevenueWaterRecordService;


    /**
     * 分页查询
     * @author Frank.Tang
     * @return *
     */
    public PageInfo<FncBankWaterDto> page(FncBankWaterQueryVo queryVo) {
        PageInfo<FncBankWater> page = fncBankWaterService.page(queryVo);
        List<FncBankWater> list = page.getList();
        List<FncBankWaterDto> res = ListUtil.copyBeanList(list, FncBankWaterDto.class);

        for (FncBankWaterDto dto : res) {
            dto.setFbwLoanTypeName(WaterLoanTypeEnum.getName(dto.getFbwLoanType()));
            dto.setFbwMatchStateName(WaterMatchStateEnum.getName(dto.getFbwMatchState()));
            dto.setFbwMatchTypeName(MatchWayEnum.getName(dto.getFbwMatchType()));
        }

        return new PageInfo<>(res);
    }

    /**
     * 删除
     * @author Frank.Tang
     * @return *
     */
    public Integer del(Long id) {
        //check
        FncBankWater water = checkDel(id);

        water.setDr(BaseConstants.DR_YES);

        log.info("用户【{}】, 删除银行流水(id【{}】)", JWTUtil.getNikeName(), id);

        return fncBankWaterService.update(water);
    }

    /**
     * 查询流水对应的收支明细
     * @author Frank.Tang
     * @return *
     */
    public PageInfo<FncRevenueWaterRecord> pageRecord(Long fbwId) {
        CheckUtil.isEmptyWithEx(fbwId, ExMsgConstants.RECEIVE_NULL_ID);
        FncRevenueWaterRecordQueryVo queryVo = new FncRevenueWaterRecordQueryVo();
        queryVo.setFrwrRevenueIdEqualTo(fbwId);
        return fncRevenueWaterRecordService.page(queryVo);
    }

    /**
     * 银行流水手动匹配账单
     * @author Frank.Tang
     * @return *
     */
    public Integer manuallyMatch(WaterMatchBillVo vo) {
        log.info("用户【{}】, 对银行流水(id【{}】), 发起手动匹配", JWTUtil.getNikeName(), vo.getFbwId());

        //校验并拿到对应的实体类
        Object[] objects = checkMatch(vo);

        FncBillManagement bill = (FncBillManagement) objects[0];
        FncBankWater water = (FncBankWater) objects[1];
        BigDecimal matchMoney = vo.getMatchMoney();

        BigDecimal billAmount = BigDecimal.valueOf(bill.getFbmBillAmount());
        BigDecimal billMatched = BigDecimal.valueOf(bill.getFbmMatchedAmount());
        BigDecimal waterAmount;
        BigDecimal waterMatched = BigDecimal.valueOf(water.getFbwMatchedAmount());

        //账单金额为负, 流水需要为"借"
        if (billAmount.compareTo(BigDecimal.ZERO) < 0) {
            if (WaterLoanTypeEnum.LOAN.getValue().equals(water.getFbwLoanType())) {
                throw new GlobalException("操作失败, [贷]类型的银行流水, 只能匹配账单[金额为正数]的");
            }
            waterAmount = BigDecimal.valueOf(water.getFbwBorrowAmount());
        }
        //账单金额为正, 流水需要为"贷"
        else {
            if (WaterLoanTypeEnum.BORROW.getValue().equals(water.getFbwLoanType())) {
                throw new GlobalException("操作失败, [借]类型的银行流水, 只能匹配账单[金额为负数]的");
            }
            waterAmount = BigDecimal.valueOf(water.getFbwCreditAmount());
        }

        billAmount = billAmount.abs();
        BigDecimal waterMatchedNow = waterMatched.add(matchMoney);
        water.setFbwMatchedAmount(waterMatchedNow.doubleValue());
        water.setFbwNotMatchAmount(waterAmount.subtract(waterMatchedNow).doubleValue());

        BigDecimal billMatchedNow = billMatched.add(matchMoney);
        bill.setFbmMatchedAmount(billMatchedNow.doubleValue());
        bill.setFbmNotMatchAmount(billAmount.subtract(billMatchedNow).doubleValue());

        //更新数据 + 生成收支记录
        WaterIntegrationDto dto = new WaterIntegrationDto(water);
        fncBillManagementFacade.updateAndGenRecordAfterMatch(bill, dto, matchMoney, false);

        return BaseConstants.YES;
    }


    /********************************************************************************************
     *                                            Checks
     ********************************************************************************************
     **
     * 银行流水手动匹配账单校验:
     *   (1)数据存在性和空值  (2)匹配金额  (3)状态
     * @author Frank.Tang
     * @return [账单实体类, 银行流水实体类]
     */
    private Object[] checkMatch(WaterMatchBillVo vo) {
        //(1)
        CheckUtil.isEmptyWithEx(vo, ExMsgConstants.RECEIVE_NULL_ENTITY);

        Long fbmId = vo.getFbmId();
        Long fbwId = vo.getFbwId();
        BigDecimal matchMoney = vo.getMatchMoney();
        CheckUtil.isEmptyWithEx(fbmId, ExMsgConstants.RECEIVE_NULL_PARA + "(账单id)");
        CheckUtil.isEmptyWithEx(fbwId, ExMsgConstants.RECEIVE_NULL_PARA + "(银行流水id)");
        CheckUtil.isEmptyWithEx(matchMoney, ExMsgConstants.RECEIVE_NULL_PARA + "(匹配金额)");

        FncBillManagement bill = fncBillManagementService.getById(fbmId);
        if (bill == null || BaseConstants.DR_YES.equals(bill.getDr())) {
            throw ExceptionUtil.notExist("账单id", fbmId);
        }
        FncBankWater water = fncBankWaterService.getById(fbwId);
        if (water == null || BaseConstants.DR_YES.equals(water.getDr())) {
            throw ExceptionUtil.notExist("银行流水id", fbwId);
        }

        //(3)
        if (WaterMatchStateEnum.ALL_MATCH.getValue().equals(water.getFbwMatchState())) {
            throw new GlobalException("操作失败, 该流水已匹配完毕, 不能再匹配");
        }
        if (!BillStateEnum.PAID_PART.getValue().equals(bill.getFbmBillState())
                && !BillStateEnum.UNPAID.getValue().equals(bill.getFbmBillState())
                && !BillStateEnum.OVERDUE.getValue().equals(bill.getFbmBillState())) {
            throw new GlobalException("操作失败, 只有[未支付]或[部分支付]或[已逾期]的账单才能匹配");
        }

        //(2)
        if (matchMoney.compareTo(BigDecimal.valueOf(bill.getFbmNotMatchAmount()).abs()) > 0) {
            throw new GlobalException("操作失败, 请确保输入的匹配金额<=账单剩下的金额");
        }
        if (matchMoney.compareTo(BigDecimal.valueOf(water.getFbwNotMatchAmount())) > 0) {
            throw new GlobalException("操作失败, 请确保输入的匹配金额<=流水剩下的金额");
        }
        if (matchMoney.compareTo(BigDecimal.ZERO) <= 0) {
            throw new GlobalException("操作失败, 输入的匹配金额不能小于等于0");
        }

        return new Object[]{bill, water};
    }

    /**
     * 用户银行流水删除校验
     * @author Frank.Tang
     * @return *
     */
    private FncBankWater checkDel(Long id) {
        CheckUtil.isEmptyWithEx(id, ExMsgConstants.RECEIVE_NULL_ID);

        FncBankWater water = fncBankWaterService.getById(id);
        if (water == null || BaseConstants.DR_YES.equals(water.getDr())) {
            throw ExceptionUtil.idNotExist(id);
        }

        if (!WaterMatchStateEnum.NOT_MATCH.getValue().equals(water.getFbwMatchState())) {
            throw new GlobalException("操作失败, 只有[未匹配]的才能删除");
        }
        return water;
    }
}
