package com.mrk.finance.facade.quartz;

import com.mrk.finance.service.FncTempService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.text.SimpleDateFormat;
import java.util.Date;

/**
 * @author Bob
 * @date 2021-11-12
 * @description
 */
@Component
public class TempClearFacade {

    private static final Logger log = LoggerFactory.getLogger(TempClearFacade.class);

    @Autowired
    private FncTempService fncTempService;

    /**
     * @author Bob
     * @date 2021/11/12
     * @description 清理24小时前的临时数据
     * @param paramStr 自定义参数  json格式
     */
    public void tempClear(String paramStr) {
        // 获取当前时间的毫秒值
        // 计算出24小时前的毫秒值
        long time = System.currentTimeMillis() - 24 * 60 * 60 * 1000;
        // 转换为时间
        Date date = new Date(time);
        // 格式化日期对象 得到指定的时间字符串
        String dateStr = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").format(date);
        log.info("定时任务调用：删除小于指定时间的临时表数据 --> time:【{}】", dateStr);
        // 删除小于指定时间的临时数据
        fncTempService.deleteByLessTime(date);
    }
}
