package com.mrk.finance.dto;

import com.mrk.finance.model.FncConfirmIncome;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

@Data
public class FncConfirmIncomeDto extends FncConfirmIncome {
  /**资产所有者文本 */
  @ApiModelProperty(value = "资产所有者文本")
  private String fciDeptIdText;
}
