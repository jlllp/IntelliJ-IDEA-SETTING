package com.mrk.finance.facade.common;

import com.mrk.auth.client.AuthUserClient;
import com.mrk.auth.model.AuthUser;
import com.mrk.common.utils.text.CheckUtil;
import com.mrk.member.model.MrkMember;
import org.apache.commons.collections4.CollectionUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.List;

/**
 * mrk-workflow
 * @Description:
 * @Date 2022/5/19 15:34
 **/
@Component
public class FinanceUserNameFacade {

    @Autowired
    private AuthUserClient authUserClient;



    public String getUserNamePhone(AuthUser authUser) {
        if (CheckUtil.isEmpty(authUser)) {
            return "";
        }
        // 姓名
        String userName = authUser.getUserName();

        // 手机号
        String userPhone = authUser.getUserPhone();
        if (CheckUtil.isEmpty(userName)) {
            return "";
        }
        if (CheckUtil.isEmpty(userPhone)) {
            return userName;
        }
        String replaceAll = userPhone.replaceAll("(\\d{3})\\d{4}(\\d{4})", "#[[\$]]#1****#[[\$]]#2");
        return userName + "(" + replaceAll + ")";
    }

    /**
     * 获取用户名称
     * @param mrkMember 会员
     * @return
     */
    public String getUserName(MrkMember mrkMember) {
        if (CheckUtil.isEmpty(mrkMember)) {
            return "";
        }
        String mmMobile = mrkMember.getMmMobile();
        String userName = mrkMember.getMmName();
        List<AuthUser> authUserList = authUserClient.getAuthUserByMobile(mmMobile).getDataWithEx();
        if (CollectionUtils.isEmpty(authUserList)) {
            // 手机号
            String userPhone = mrkMember.getMmMobile();
            if (CheckUtil.isEmpty(userName)) {
                return userPhone;
            }
            if (CheckUtil.isEmpty(userPhone)) {
                return userName;
            }
            String replaceAll = userPhone.replaceAll("(\\d{3})\\d{4}(\\d{4})", "#[[\$]]#1****#[[\$]]#2");
            return userName + "(" + replaceAll + ")";
        }

        if (CollectionUtils.isNotEmpty(authUserList)) {
            // 手机号
            AuthUser authUser = authUserList.get(0);
            String userPhone = authUser.getUserPhone();
            String userUserName = authUser.getUserName();
            if (CheckUtil.isEmpty(userUserName)) {
                userUserName = userName;
            }
            if (CheckUtil.isEmpty(userPhone)) {
                return userUserName;
            }
            String replaceAll = userPhone.replaceAll("(\\d{3})\\d{4}(\\d{4})", "#[[\$]]#1****#[[\$]]#2");
            return userUserName + "(" + replaceAll + ")";
        }

        return "";
    }
}
