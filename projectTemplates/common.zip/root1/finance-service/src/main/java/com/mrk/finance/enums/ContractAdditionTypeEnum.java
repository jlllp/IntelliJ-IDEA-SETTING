package com.mrk.finance.enums;

import lombok.Getter;

/**
 * @project: mrk-finance
 * @author: Frank.Tang
 * @date: 2021-11-12 11:19
 * @desc: 补充合同类型枚举
 **/
@Getter
public enum ContractAdditionTypeEnum {

    /***/
    EARLY_RETURN(0, "提前还车"),
    CAR_CHANGE(1, "换车协议"),
    TERMINATE (2, "解除租赁合同");

    private Integer value;
    private String name;

    ContractAdditionTypeEnum(Integer value, String name) {
        this.value = value;
        this.name = name;
    }

    public static String getName(Integer state) {
        if (state == null) {
            return "";
        }
        for (ContractAdditionTypeEnum statusEnum : values()) {
            if (statusEnum.getValue().equals(state)) {
                return statusEnum.getName();
            }
        }
        return "";
    }

}
