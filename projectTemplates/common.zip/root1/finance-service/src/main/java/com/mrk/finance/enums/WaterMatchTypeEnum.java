package com.mrk.finance.enums;

import lombok.Getter;

/**
 * @project: mrk-finance
 * @author: Frank.Tang
 * @date: 2021-11-12 14:26
 * @desc: 账单匹配流水类型
 **/
@Getter
public enum WaterMatchTypeEnum {

    /** 银行 */
    YH(0, "YH"),

    /** 滴滴 */
    DD(1, "DD"),

    /** T3 */
    TT(2, "TT"),
    /** 微信支付 */
    WX(3, "WX");


    private Integer value;
    private String name;

    WaterMatchTypeEnum(Integer value, String name) {
        this.value = value;
        this.name = name;
    }

    public static String getName(Integer state) {
        if (state == null) {
            return "";
        }
        for (WaterMatchTypeEnum statusEnum : values()) {
            if (statusEnum.getValue().equals(state)) {
                return statusEnum.getName();
            }
        }
        return "";
    }

}
