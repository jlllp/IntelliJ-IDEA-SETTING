package com.mrk.finance.dto;

// 用于后端不同层传输转换类 和 返回前端对象类