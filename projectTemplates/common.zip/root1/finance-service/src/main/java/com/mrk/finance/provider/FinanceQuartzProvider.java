package com.mrk.finance.provider;

import com.mrk.common.utils.page.JsonResult;
import com.mrk.finance.client.FinanceQuartzClient;
import com.mrk.finance.facade.quartz.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

/**
 * @author Bob
 * @date 2021-11-12
 * @description
 */
@RestController
public class FinanceQuartzProvider implements FinanceQuartzClient {

    @Autowired
    private TempClearFacade tempClearFacade;

    @Autowired
    private ContractCalculateFacade contractCalculateFacade;

    @Autowired
    private CarPurchaseBalanceFacade carPurchaseBalanceFacade;

    @Autowired
    private DepositRefundFacade depositRefundFacade;

    @Autowired
    private OverdueBillFacade overdueBillFacade;

    @Autowired
    private RentBillFacade rentBillFacade;

    @Autowired
    private ConfirmedIncomeFacade confirmedIncomeFacade;

    @Autowired
    private CheckStopFacade checkStopFacade;

    /**
     * @author Bob
     * @date 2021/11/12
     * @description 清理24小时前的临时数据
     * @param paramStr 请求参数
     * @return 执行结果
     */
    @Override
    public JsonResult<Object> clearTemp(@RequestParam(value = "paramStr", required = false) String paramStr) {
        tempClearFacade.tempClear(paramStr);
        return JsonResult.success();
    }

    /**
     * @param paramStr 请求参数
     * @return 执行结果
     * @author Bob
     * @date 2021/11/12
     * @description 计算合同状态
     */
    @Override
    public JsonResult<Object> calculateContractState(@RequestParam(value = "paramStr", required = false) String paramStr) {
        contractCalculateFacade.calculateContractState(paramStr);
        return JsonResult.success();
    }

    /**
     * @param paramStr 请求参数
     * @return 执行结果
     * @author Bob
     * @date 2021/11/12
     * @description 计算结算状态
     */
    @Override
    public JsonResult<Object> calculateSettlementState(@RequestParam(value = "paramStr", required = false) String paramStr) {
        contractCalculateFacade.calculateSettlementState(paramStr);
        return JsonResult.success();
    }

    /**
     * @param paramStr 请求参数
     * @return 执行结果
     * @author Bob
     * @date 2021/11/15
     * @description 购车尾款生成
     */
    @Override
    public JsonResult<Object> carPurchaseBalanceGeneration(@RequestParam(value = "paramStr", required = false) String paramStr) {
        carPurchaseBalanceFacade.carPurchaseBalanceGeneration(paramStr);
        return JsonResult.success();
    }

    /**
     * @param paramStr 请求参数
     * @return 执行结果
     * @author Bob
     * @date 2021/11/15
     * @description 保证金退还生成
     */
    @Override
    public JsonResult<Object> depositRefundGeneration(@RequestParam(value = "paramStr", required = false) String paramStr) {
        depositRefundFacade.depositRefundGeneration(paramStr);
        return JsonResult.success();
    }

    /**
     * @param paramStr 请求参数
     * @return 执行结果
     * @author Bob
     * @date 2021/11/18
     * @description 检查账单是否逾期
     */
    @Override
    public JsonResult<Object> overdueBillCheck(@RequestParam(value = "paramStr", required = false) String paramStr) {
        overdueBillFacade.overdueBillCheck(paramStr);
        return JsonResult.success();
    }

    /**
     * @param paramStr 请求参数
     * @return 执行结果
     * @author Bob
     * @date 2021/11/22
     * @description 租金账单生成定时任务
     */
    @Override
    public JsonResult<Object> rentBillGeneration(@RequestParam(value = "paramStr", required = false) String paramStr) {
        rentBillFacade.rentBillGeneration(paramStr);
        return JsonResult.success();
    }

    /**
     * @param paramStr 请求参数
     * @return 执行结果
     * @author Bob
     * @date 2021/11/24
     * @description 确认收入计算定时任务
     */
    @Override
    public JsonResult<Object> incomeCalculation(@RequestParam(value = "paramStr", required = false) String paramStr) {
        confirmedIncomeFacade.incomeCalculation(paramStr);
        return JsonResult.success();
    }

    @Override
    public JsonResult<Object> checkStop(String paramStr) {
        checkStopFacade.checkStop(paramStr);
        return JsonResult.success();
    }
}
