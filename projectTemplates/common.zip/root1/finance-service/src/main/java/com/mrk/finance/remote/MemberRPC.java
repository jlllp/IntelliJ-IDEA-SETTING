package com.mrk.finance.remote;

import com.mrk.common.utils.text.CheckUtil;
import com.mrk.member.client.MemberClient;
import com.mrk.member.client.dto.MrkMemberRentDto;
import com.mrk.member.model.MrkMember;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

/**
 * @author jlllp
 * @date 2022/6/16
 * @description
 */
@Component
public class MemberRPC {

    @Autowired
    private MemberClient memberClient;

    /**
     * 根据主键获取会员承租信息
     *
     * @param id 主键
     * @return 承租信息
     */
    public MrkMemberRentDto getRentById(Long id) {
        CheckUtil.isEmptyWithEx(id, "主键不能为空");
        return memberClient.getRentById(id).getDataWithEx();
    }

    /**
     * 根据id 查询会员
     *
     * @param id 会员id
     * @return 会员
     */
    public MrkMember findById(Long id) {
        CheckUtil.isEmptyWithEx(id, "主键不能为空");
        return memberClient.findByid(id).getDataWithEx();
    }
}
