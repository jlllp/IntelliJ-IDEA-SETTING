package com.mrk.finance.controller;

import com.github.pagehelper.PageInfo;
import com.mrk.common.utils.page.JsonResult;
import com.mrk.finance.model.FncBillMatchRecord;
import com.mrk.finance.queryvo.FncBillMatchRecordQueryVo;
import com.mrk.finance.service.FncBillMatchRecordService;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiImplicitParam;
import io.swagger.annotations.ApiImplicitParams;
import io.swagger.annotations.ApiOperation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;


/**
 * FncBillMatchRecordController
 */
@RestController
@RequestMapping("/financeservice/fncbillmatchrecord")
@Api(tags = "/账单匹配记录")
public class FncBillMatchRecordController {
    @Autowired
    private FncBillMatchRecordService fncBillMatchRecordService;

    @PostMapping(value = "/add")
    @ApiOperation("账单匹配记录-新增")
    @ApiImplicitParams({
            @ApiImplicitParam(paramType = "header", name = "Authorization", value = "系统下发的token", required = true)
    })
    public JsonResult<Object> add(FncBillMatchRecord entity) {
        return JsonResult.success(fncBillMatchRecordService.add(entity));
    }

    @PostMapping(value = "/del/{id}")
    @ApiOperation("账单匹配记录-删除")
    @ApiImplicitParams({
            @ApiImplicitParam(paramType = "header", name = "Authorization", value = "系统下发的token", required = true)
    })
    public JsonResult<Object> del(@PathVariable("id") Long id) {
        return JsonResult.success(fncBillMatchRecordService.delete(id));
    }

    @PostMapping(value = "/update")
    @ApiOperation("账单匹配记录-更新")
    @ApiImplicitParams({
            @ApiImplicitParam(paramType = "header", name = "Authorization", value = "系统下发的token", required = true)
    })
    public JsonResult<Object> update(FncBillMatchRecord entity) {
        return JsonResult.success(fncBillMatchRecordService.update(entity));
    }


    @GetMapping(value = "/page")
    @ApiOperation("账单匹配记录-分页查询")
    @ApiImplicitParams({
            @ApiImplicitParam(paramType = "header", name = "Authorization", value = "系统下发的token", required = true)
    })
    public JsonResult<PageInfo<FncBillMatchRecord>> page(FncBillMatchRecordQueryVo queryVo) {
        return JsonResult.success(fncBillMatchRecordService.page(queryVo));
    }

    @GetMapping(value = "/list")
    @ApiOperation("账单匹配记录-列表查询")
    @ApiImplicitParams({
            @ApiImplicitParam(paramType = "header", name = "Authorization", value = "系统下发的token", required = true)
    })
    public JsonResult<List<FncBillMatchRecord>> list(FncBillMatchRecordQueryVo queryVo) {
        return JsonResult.success(fncBillMatchRecordService.list(queryVo));
    }


}
