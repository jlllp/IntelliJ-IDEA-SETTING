package com.mrk.finance.facade.bankwater;

import cn.afterturn.easypoi.excel.ExcelExportUtil;
import cn.afterturn.easypoi.excel.ExcelImportUtil;
import cn.afterturn.easypoi.excel.entity.ExportParams;
import cn.afterturn.easypoi.excel.entity.ImportParams;
import cn.afterturn.easypoi.excel.entity.result.ExcelImportResult;
import com.github.pagehelper.PageInfo;
import com.mrk.common.exception.GlobalException;
import com.mrk.common.utils.bean.BeanUtils;
import com.mrk.common.utils.container.ListUtil;
import com.mrk.common.utils.jwt.JWTUtil;
import com.mrk.common.utils.redis.RedisUtil;
import com.mrk.common.utils.text.CheckUtil;
import com.mrk.finance.dto.FncBankWaterDto;
import com.mrk.finance.dto.FncBankWaterExportByQueryDto;
import com.mrk.finance.dto.FncBankWaterExportDto;
import com.mrk.finance.enums.WaterLoanTypeEnum;
import com.mrk.finance.facade.CarExportFacade;
import com.mrk.finance.facade.ExportFacade;
import com.mrk.finance.facade.FncWaterAutoMatchFacade;
import com.mrk.finance.model.FncBankWater;
import com.mrk.finance.model.FncTemp;
import com.mrk.finance.queryvo.FncBankWaterQueryVo;
import com.mrk.finance.service.FncBankWaterService;
import com.mrk.finance.service.FncTempService;
import com.mrk.finance.util.StreamUtil;
import com.mrk.finance.vo.bankwatervo.FncBankWaterImportVo;
import com.mrk.resource.enums.MatchStateEnums;
import lombok.extern.slf4j.Slf4j;
import org.apache.poi.hssf.usermodel.HSSFCellStyle;
import org.apache.poi.hssf.util.HSSFColor;
import org.apache.poi.ss.usermodel.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.CollectionUtils;
import org.springframework.web.multipart.MultipartFile;

import javax.servlet.http.HttpServletResponse;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.TimeUnit;

/**
 * @project: mrk-finance
 * @author: Frank.Tang
 * @date: 2021-11-15 18:29
 * @desc:
 **/
@Slf4j
@Component
public class FncBankWaterImportFacade {

    @Autowired
    private FncTempService fncTempService;
    @Autowired
    private RedisUtil redisUtil;
    @Autowired
    private ExportFacade exportFacade;
    @Autowired
    private CarExportFacade exportByExcel;
    @Autowired
    private FncBankWaterService fncBankWaterService;
    @Autowired
    private FncWaterAutoMatchFacade fncWaterAutoMatchFacade;
    @Autowired
    private FncBankWaterFacade fncBankWaterFacade;


    /**
     * @description 导入文件
     */
    @Transactional(rollbackFor = Exception.class)
    public void importFile(MultipartFile file, String operateCode) {
        String userName = JWTUtil.getNikeName();
        log.info("开始导入银行流水，操作人 --> userName：【{}】", userName);
        // 删除操作标识中的数据
        fncTempService.deleteByOperateCode(operateCode);
        // 读取excel中的文件
        List<FncBankWaterImportVo> importVos = this.getData(file);
        if (CollectionUtils.isEmpty(importVos)) {
            throw new GlobalException("未读取到数据, 请检查文件");
        }
        // 处理数据
        this.dispose(importVos, operateCode);
    }

    /**
     * @description 获取excel文件中的数据
     */
    private List<FncBankWaterImportVo> getData(MultipartFile file) {
        try {
            ExcelImportResult<FncBankWaterImportVo> result = ExcelImportUtil.importExcelMore
                    (file.getInputStream(), FncBankWaterImportVo.class, new ImportParams());
            return result.getList();
        } catch (Exception e) {
            log.error("获取excel文件中的数据", e);
            throw new GlobalException("解析文件失败，请检查数据");
        }
    }

    /**
     * @description 获取进度的redisKey
     */
    private String scheduleKey(String operateCode) {
        return String.format("schedule:{%s}", operateCode);
    }

    /**
     * @description 根据文件标识符获取处理进度
     */
    public Integer schedule(String operateCode) {
        CheckUtil.isEmptyWithEx(operateCode, "操作标识不能为空");
        String value = redisUtil.get(scheduleKey(operateCode));
        try {
            return Integer.parseInt(value);
        } catch (NumberFormatException e) {
            return 0;
        }
    }

    public void export(FncBankWaterQueryVo queryVo, HttpServletResponse response) {
        long sTime = System.currentTimeMillis();

        PageInfo<FncBankWaterDto> pageInfo = fncBankWaterFacade.page(queryVo);
        int maxSize = 50000;
        if (pageInfo.getTotal() > maxSize) {
            throw new GlobalException("导出的数量超过5万条，请缩小范围");
        }
        // 导出文件
        List<FncBankWaterExportByQueryDto> boxUpVoList = ListUtil.copyBeanList(pageInfo.getList(), FncBankWaterExportByQueryDto.class);
        Workbook workbook = ExcelExportUtil.exportExcel(new ExportParams(), FncBankWaterExportByQueryDto.class, boxUpVoList);
        String fileName = "银行流水" + System.currentTimeMillis() + ".xls";
        exportByExcel.exportByExcel(response, fileName, workbook);

        long eTime = System.currentTimeMillis();

        log.info("用户【{}】, 导出银行流水. 数据量【{}条】, 耗时【{}ms】", JWTUtil.getNikeName(), boxUpVoList.size(), (eTime - sTime));
    }

    /**
     * @description 根据操作标识确定导入
     */
    @Transactional(rollbackFor = Exception.class)
    public void confirmImport(String operateCode) {
        List<FncTemp> fncTempList = fncTempService.selectErrorByOperateCode(operateCode);
        if (!fncTempList.isEmpty()) {
            throw new GlobalException("当前文件存在错误数据，不能导入");
        }
        fncTempList = fncTempService.selectByOperateCode(operateCode);
        //导入数据
        List<FncBankWater> waters = new ArrayList<>();
        for (FncTemp fncTemp : fncTempList) {
            FncBankWater water = new FncBankWater();

            water.setFbwVoucherNo(fncTemp.getFncVoucherNo());
            water.setFbwOwnAccount(fncTemp.getFncOwnAccount());
            water.setFbwOtherAccount(fncTemp.getFncOtherAccount());
            water.setFbwOtherUnitName(fncTemp.getFncOtherUnitName());
            water.setFbwDealTime(fncTemp.getFncDealTime());
            water.setFbwLoanType(WaterLoanTypeEnum.getValue(fncTemp.getFncLoanType()));
            water.setFbwBorrowAmount(fncTemp.getFncBorrowAmount());
            water.setFbwCreditAmount(fncTemp.getFncCreditAmount());
            water.setFbwUse(fncTemp.getFncUse());
            water.setFbwDigest(fncTemp.getFncDigest());

            water.setFbwMatchState(MatchStateEnums.NOT_MATCHED.getValue());
            water.setFbwNotMatchAmount(
                    WaterLoanTypeEnum.BORROW.getName().equals(fncTemp.getFncLoanType()) ?
                            water.getFbwBorrowAmount() : water.getFbwCreditAmount()
            );
            water.setFbwMatchedAmount(BigDecimal.ZERO.doubleValue());

            waters.add(water);
        }
        int insert = fncBankWaterService.insertList(waters);
        if (insert != waters.size()) {
            throw new GlobalException("导入失败，请重试");
        }

        //默认执行一次自动匹配
        /*fncWaterAutoMatchFacade.bwAutoMatch(StreamUtil.toList(waters, FncBankWater::getFbwId));*/

        // 删除操作批次下的数据
        fncTempService.deleteByOperateCode(operateCode);
    }


    /**
     * @description 设置单元格样式
     */
    public void setExcelStyle(Workbook workbook) {
        Sheet sheet = workbook.getSheetAt(0);
        // 创建红色的字体颜色样式
        Font font = workbook.createFont();
        // 字体颜色
        font.setColor(HSSFColor.HSSFColorPredefined.RED.getIndex());
        HSSFCellStyle cellStyle = (HSSFCellStyle) workbook.createCellStyle();
        // 前景色填充
        cellStyle.setFillPattern(FillPatternType.SOLID_FOREGROUND);
        // 前景填充色
        cellStyle.setFillForegroundColor(HSSFColor.HSSFColorPredefined.LEMON_CHIFFON.getIndex());
        // 字体居中
        cellStyle.setAlignment(HorizontalAlignment.CENTER);
        cellStyle.setFont(font);
        for (int i = 1; i <= sheet.getLastRowNum(); i++) {
            Row row = sheet.getRow(i);
            // 获取小标为3的列数据 对应错误数据
            Cell cell;
            String value = row.getCell(10).toString().trim();
            // 说明此列数据错误
            if (CheckUtil.isNotEmpty(value)) {
                final int physicalNumberOfCells = row.getPhysicalNumberOfCells();
                for (int j = 0; j < physicalNumberOfCells; j++) {
                    cell = row.getCell(j);
                    // 设置单元格格式
                    cell.setCellStyle(cellStyle);
                }
            }
        }
    }

    public void peepareTemplate(HttpServletResponse httpServletResponse) {
        exportFacade.exportByExcel(httpServletResponse, "银行流水模板.xls",
                FncBankWaterImportVo.class, new ArrayList<>());
    }

    /**
     * @description 根据标识符下载文件，错误的数据标红
     */
    public void downFile(String operateCode, HttpServletResponse response) {
        // 根据标识符获取设备数据
        List<FncTemp> fncTemps = fncTempService.selectByOperateCode(operateCode);
        List<FncBankWaterExportDto> boxDownVos = new ArrayList<>();
        for (FncTemp fncTemp : fncTemps) {
            FncBankWaterExportDto waterExportDto = BeanUtils.copyBean(fncTemp, FncBankWaterExportDto.class);
            boxDownVos.add(waterExportDto);
        }
        Workbook workbook = ExcelExportUtil.exportExcel(new ExportParams(), FncBankWaterExportDto.class, boxDownVos);
        // 设置单元格样式
        setExcelStyle(workbook);
        String fileName = "银行流水" + System.currentTimeMillis() + ".xls";
        exportByExcel.exportByExcel(response, fileName, workbook);
    }

    /**
     * @description 根据标识符获取上传结果
     * 0 正常 1有错误
     */
    public Integer importResult(String operateCode) {
        List<FncTemp> fncTemps = fncTempService.selectErrorByOperateCode(operateCode);
        return fncTemps.isEmpty() ? 0 : 1;
    }

    /**
     * @date 2021/3/29 17:21
     */
    private void dispose(List<FncBankWaterImportVo> importVos, String operateCode) {
        int total = importVos.size();
        for (int i = 0; i < importVos.size(); i++) {
            FncBankWaterImportVo importVo = importVos.get(i);
            // 检查数据是否是空 空的就跳过
            if (!this.checkIsNull(importVo)) {
                // 保存数据
                this.doSave(importVo, operateCode);
            }
            // 修改进度 百分比
            int schedule = (i + 1) * 100 / total;
            final String key = scheduleKey(operateCode);
            // 设置有效时间
            redisUtil.set(key, String.valueOf(schedule));
            redisUtil.expire(key, 30, TimeUnit.SECONDS);
        }
    }

    /**
     * 检查重要的数据是否为空
     */
    private boolean checkIsNull(FncBankWaterImportVo importVo) {
        // 检查重要数据是否都为空 为空则认为空数据
        return CheckUtil.isEmpty(importVo.getFncVoucherNo())
                && CheckUtil.isEmpty(importVo.getFncOwnAccount())
                && CheckUtil.isEmpty(importVo.getFncOtherAccount())
                && CheckUtil.isEmpty(importVo.getFncOtherUnitName())
                && CheckUtil.isEmpty(importVo.getFncDealTime())
                && CheckUtil.isEmpty(importVo.getFncLoanType())
                && CheckUtil.isEmpty(importVo.getFncBorrowAmount())
                && CheckUtil.isEmpty(importVo.getFncCreditAmount())
                && CheckUtil.isEmpty(importVo.getFncUse())
                && CheckUtil.isEmpty(importVo.getFncDigest());
    }

    /**
     * 保存数据
     */
    private void doSave(FncBankWaterImportVo importVo, String operateCode) {
        StringBuilder sb = new StringBuilder();

        if (CheckUtil.isEmpty(importVo.getFncVoucherNo())) {
            sb.append("凭证号为空，");
        }
        if (CheckUtil.isEmpty(importVo.getFncOwnAccount())) {
            sb.append("本方账号为空，");
        }
        if (CheckUtil.isEmpty(importVo.getFncOtherAccount())) {
            sb.append("对方账号为空，");
        }
        if (CheckUtil.isEmpty(importVo.getFncOtherUnitName())) {
            sb.append("对方单位名称为空，");
        }
        if (CheckUtil.isEmpty(importVo.getFncDealTime())) {
            sb.append("交易时间为空，");
        }
        if (CheckUtil.isEmpty(importVo.getFncLoanType())) {
            sb.append("借/贷为空，");
        } else {
            Integer loanTypeValue = WaterLoanTypeEnum.getValue(importVo.getFncLoanType());
            //只能填 借/贷
            if (loanTypeValue.equals(-1)) {
                sb.append("借/贷不存在对应的值，");
            }
            //借, 校验金额
            if (loanTypeValue.equals(WaterLoanTypeEnum.BORROW.getValue())) {
                String borrowAmountStr = importVo.getFncBorrowAmountStr();
                if (CheckUtil.isEmpty(borrowAmountStr)) {
                    sb.append("借方发生额为空，");
                } else {
                    double borrowAmount = Double.parseDouble(borrowAmountStr.replaceAll(",", ""));
                    if (borrowAmount <= 0.0) {
                        sb.append("借方发生额不能小于等于0，");
                    }
                    importVo.setFncBorrowAmount(borrowAmount);
                }
                if (!CheckUtil.isEmpty(importVo.getFncCreditAmountStr())) {
                    sb.append("借类型时，贷方发生额不填，");
                }
            }
            //贷 校验金额
            if (loanTypeValue.equals(WaterLoanTypeEnum.LOAN.getValue())) {
                String creditAmountStr = importVo.getFncCreditAmountStr();
                if (CheckUtil.isEmpty(creditAmountStr)) {
                    sb.append("贷方发生额为空，");
                } else {
                    double creditAmount = Double.parseDouble(creditAmountStr.replaceAll(",", ""));
                    if (creditAmount <= 0.0) {
                        sb.append("贷方发生额不能小于等于0，");
                    }
                    importVo.setFncCreditAmount(creditAmount);
                }
                if (!CheckUtil.isEmpty(importVo.getFncBorrowAmountStr())) {
                    sb.append("贷类型时，借方发生额不填，");
                }
            }
        }

        if (WaterLoanTypeEnum.LOAN.getName().equals(importVo.getFncLoanType())
                && CheckUtil.isEmpty(importVo.getFncCreditAmount())) {
            sb.append("贷方发生额为空，");
        }
        if (CheckUtil.isEmpty(importVo.getFncUse())) {
            sb.append("用途为空，");
        }
        if (CheckUtil.isEmpty(importVo.getFncDigest())) {
            sb.append("摘要为空，");
        }

        FncTemp fncTemp = BeanUtils.copyBean(importVo, FncTemp.class);
        fncTemp.setFncOperateCode(operateCode);

        if (CheckUtil.isNotEmpty(sb.toString())) {
            fncTemp.setFncError(1);
            fncTemp.setFncErrorMsg(sb.substring(0, sb.length() - 1));
        } else {
            fncTemp.setFncError(0);
        }
        fncTempService.add(fncTemp);
    }

}
