package com.mrk.finance.service.impl;

import com.github.pagehelper.PageInfo;
import com.mrk.common.constant.BaseConstants;
import com.mrk.common.utils.bean.BeanUtils;
import com.mrk.common.utils.jwt.JWTUtil;
import com.mrk.common.utils.page.PageUtils;
import com.mrk.common.utils.text.StringUtils;
import com.mrk.finance.dao.FncRevenueWaterRecordMapper;
import com.mrk.finance.model.FncRevenueWaterRecord;
import com.mrk.finance.query.FncRevenueWaterRecordQuery;
import com.mrk.finance.queryvo.FncRevenueWaterRecordQueryVo;
import com.mrk.finance.service.FncRevenueWaterRecordService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import javax.annotation.Resource;
import java.util.Date;
import java.util.List;


/**
 * @Description: FncRevenueWaterRecordServiceImpl
 */
@Service
@Slf4j
public class FncRevenueWaterRecordServiceImpl implements FncRevenueWaterRecordService {
    @Resource
    private FncRevenueWaterRecordMapper fncRevenueWaterRecordMapper;

    @Override
    public PageInfo<FncRevenueWaterRecord> page(FncRevenueWaterRecordQueryVo queryVo){
        PageUtils.startPage();
        List<FncRevenueWaterRecord> list = this.list(queryVo);
        return new PageInfo<>(list);
    }

    @Override
    public List<FncRevenueWaterRecord> list(FncRevenueWaterRecordQueryVo queryVo){
        FncRevenueWaterRecordQuery query = new FncRevenueWaterRecordQuery();
        BeanUtils.copyBeanProp(queryVo, query);
        query.setSidx(StringUtils.camelToUnderlineAndFilterText(query.getSidx()));
        return fncRevenueWaterRecordMapper.selectByExample(query.getCrieria());
    }

    @Override
    @Transactional(rollbackFor = Exception.class)
    public int add(FncRevenueWaterRecord entity){
        String userName = JWTUtil.getNikeName();
        entity.setCreateuser(userName);
        entity.setCreatetime(new Date());
        entity.setDr(BaseConstants.DR_NO);
        return fncRevenueWaterRecordMapper.insert(entity);
    }

    @Override
    @Transactional(rollbackFor = Exception.class)
    public int update(FncRevenueWaterRecord entity){
        entity.setUpdatetime(new Date());
        return fncRevenueWaterRecordMapper.updateByPrimaryKey(entity);
    }

    @Override
    @Transactional(rollbackFor = Exception.class)
    public int delete(Long id){
        return fncRevenueWaterRecordMapper.deleteByPrimaryKey(id);
    }

    @Override
    public FncRevenueWaterRecord getById(Long id){
        return fncRevenueWaterRecordMapper.selectByPrimaryKey(id);
    }
}
