package com.mrk.finance.model;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.mrk.common.base.BaseEntity;
import io.swagger.annotations.ApiModelProperty;
import lombok.Getter;
import lombok.Setter;
import org.springframework.format.annotation.DateTimeFormat;

import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import java.io.Serializable;

@Setter
@Getter
public class FncContractManagement extends BaseEntity implements Serializable {
private static final long serialVersionUID=1L;


    /**序号 */
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @ApiModelProperty(value = "序号")
    private Long fcmId;

    /**城市（废弃） */
    @ApiModelProperty(value = "城市（废弃）")
    private Long fcmCityId;

    /**合同类型 0以租代售 1经营性租赁 2自营网约车_新租 3 营网约车_续租 4租赁合同 5租售合同 */
    @ApiModelProperty(value = "合同类型 0以租代售 1经营性租赁 2自营网约车_新租 3 营网约车_续租 4租赁合同 5租售合同")
    private Integer fcmContractType;

    /**合同编号 */
    @ApiModelProperty(value = "合同编号")
    private String fcmContractNo;

    /**甲方类型 1个人 2组织（废弃） */
    @ApiModelProperty(value = "甲方类型 1个人 2组织（废弃）")
    private Integer fcmPartyaType;

    /**甲方ID */
    @ApiModelProperty(value = "甲方ID")
    private Long fcmPartyaId;

    /**乙方类型 1个人 2组织 */
    @ApiModelProperty(value = "乙方类型 1个人 2组织")
    private Integer fcmPartybType;

    /**乙方ID */
    @ApiModelProperty(value = "乙方ID")
    private Long fcmPartybId;

    /**车型ID */
    @ApiModelProperty(value = "车型ID")
    private Long fcmCarTypeId;

    /**运营平台（废弃） */
    @ApiModelProperty(value = "运营平台（废弃）")
    private Integer fcmOperatPlatform;

    /**签订日期 */
    @DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss", timezone = "GMT+8")
    @ApiModelProperty(value = "签订日期")
    private java.util.Date fcmSignedDate;

    /**租赁类型 0无 1自然周期 2相对周期 */
    @ApiModelProperty(value = "租赁类型 0无 1自然周期 2相对周期")
    private Integer fcmLeaseCalculateType;

    /**租期（月） */
    @ApiModelProperty(value = "租期（月）")
    private Integer fcmLeaseCount;

    /**租赁起始类型 0确定日期 1交车日期 */
    @ApiModelProperty(value = "租赁起始类型 0确定日期 1交车日期")
    private Integer fcmLeaseStartType;

    /**租赁起始日期 */
    @DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss", timezone = "GMT+8")
    @ApiModelProperty(value = "租赁起始日期")
    private java.util.Date fcmLeaseStartDate;

    /**租赁结束日期 */
    @DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss", timezone = "GMT+8")
    @ApiModelProperty(value = "租赁结束日期")
    private java.util.Date fcmLeaseEndDate;

    /**租赁类型 0固定 1不固定 */
    @ApiModelProperty(value = "租赁类型 0固定 1不固定")
    private Integer fcmLeaseType;

    /**租金金额 */
    @ApiModelProperty(value = "租金金额")
    private Double fcmLeaseAmount;

    /**租金支付类型 0自然周期 1相对周期 */
    @ApiModelProperty(value = "租金支付类型 0自然周期 1相对周期")
    private Integer fcmRentPayType;

    /**租金支付周期 */
    @ApiModelProperty(value = "租金支付周期")
    private Integer fcmRentPayCycle;

    /**赠送租期（废弃） */
    @ApiModelProperty(value = "赠送租期（废弃）")
    private Integer fcmGiveLease;

    /**赠送顺序（废弃） */
    @ApiModelProperty(value = "赠送顺序（废弃）")
    private Integer fcmGiveSequence;

    /**账单生成类型 */
    @ApiModelProperty(value = "账单生成类型")
    private Integer fcmBillGenerateType;

    /**账单生成间隔 */
    @ApiModelProperty(value = "账单生成间隔")
    private Integer fcmBillGenerateInterval;

    /**账单截止类型 */
    @ApiModelProperty(value = "账单截止类型")
    private Integer fcmBillCatoffType;

    /**账单截止间隔 */
    @ApiModelProperty(value = "账单截止间隔")
    private Integer fcmBillCatoffInterval;

    /**车辆总数 */
    @ApiModelProperty(value = "车辆总数")
    private Integer fcmCarnumTotal;

    /**单车保证金 */
    @ApiModelProperty(value = "单车保证金")
    private Double fcmSingleMargin;

    /**保证金支付要求 0提车前一次性支付 1每次提车前分批支付 2灵活支付 */
    @ApiModelProperty(value = "保证金支付要求 0提车前一次性支付 1每次提车前分批支付 2灵活支付")
    private Integer fcmMarginPayRequire;

    /**租金总额 */
    @ApiModelProperty(value = "租金总额")
    private Double fcmLeaseAmountTotal;

    /**保证金类型 0无 1总额 2单车 */
    @ApiModelProperty(value = "保证金类型 0无 1总额 2单车")
    private Integer fcmMarginType;

    /**保证金金额 */
    @ApiModelProperty(value = "保证金金额")
    private Double fcmMarginMoney;

    /**保证金总额 */
    @ApiModelProperty(value = "保证金总额")
    private Double fcmMarginTotal;

    /**车辆购车尾款（废弃） */
    @ApiModelProperty(value = "车辆购车尾款（废弃）")
    private Double fcmCarPurchase;

    /**保底租金 */
    @ApiModelProperty(value = "保底租金")
    private Double fcmBoldRent;

    /**提前购车价计算方式（废弃） */
    @ApiModelProperty(value = "提前购车价计算方式（废弃）")
    private String fcmCarPurchaseAdvance;

    /**合同状态 0租赁待开始 1租赁中 2租赁中止 3租赁结束 */
    @ApiModelProperty(value = "合同状态 0租赁待开始 1租赁中 2租赁中止 3租赁结束")
    private Integer fcmContractState;

    /**结算状态 */
    @ApiModelProperty(value = "结算状态")
    private Integer fcmSettlementState;

    /**关联合同ID（废弃） */
    @ApiModelProperty(value = "关联合同ID（废弃）")
    private Long fcmAssociateContractId;

    /**关联合同编号（废弃） */
    @ApiModelProperty(value = "关联合同编号（废弃）")
    private String fcmAssociateContractNo;

    /**收车工单是否处理标识 0未处理 1已处理 */
    @ApiModelProperty(value = "收车工单是否处理标识 0未处理 1已处理")
    private Integer fncTurnerSingleDeal;

    /**车辆性质 */
    @ApiModelProperty(value = "车辆性质")
    private String fcmCarNature;

    /**交车地点 */
    @ApiModelProperty(value = "交车地点")
    private Long fcmDeliverCity;

    /**归还地点 */
    @ApiModelProperty(value = "归还地点")
    private Long fcmReturnCity;

    /**车辆交付方式 0无 1交车前一次性交付 2分批交付 */
    @ApiModelProperty(value = "车辆交付方式 0无 1交车前一次性交付 2分批交付")
    private Integer fcmDeliverType;

    /**是否可以转租 0无 1是 2否 */
    @ApiModelProperty(value = "是否可以转租 0无 1是 2否")
    private Integer fcmSublet;

    /**签订地点 */
    @ApiModelProperty(value = "签订地点")
    private Long fcmSignedAddr;

    /**合同创建人手机号 */
    @ApiModelProperty(value = "合同创建人手机号")
    private String fcmCreatePhone;

    /**用途 */
    @ApiModelProperty(value = "用途")
    private String fcmUse;
    }
