package com.mrk.finance.example;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

public class FncBankWaterExample {
    protected String orderByClause;

    protected boolean distinct;

    protected List<Criteria> oredCriteria;

    public FncBankWaterExample() {
        oredCriteria = new ArrayList<Criteria>();
    }

    public void setOrderByClause(String orderByClause) {
        this.orderByClause = orderByClause;
    }

    public String getOrderByClause() {
        return orderByClause;
    }

    public void setDistinct(boolean distinct) {
        this.distinct = distinct;
    }

    public boolean isDistinct() {
        return distinct;
    }

    public List<Criteria> getOredCriteria() {
        return oredCriteria;
    }

    public void or(Criteria criteria) {
        oredCriteria.add(criteria);
    }

    public Criteria or() {
        Criteria criteria = createCriteriaInternal();
        oredCriteria.add(criteria);
        return criteria;
    }

    public Criteria createCriteria() {
        Criteria criteria = createCriteriaInternal();
        if (oredCriteria.size() == 0) {
            oredCriteria.add(criteria);
        }
        return criteria;
    }

    protected Criteria createCriteriaInternal() {
        Criteria criteria = new Criteria();
        return criteria;
    }

    public void clear() {
        oredCriteria.clear();
        orderByClause = null;
        distinct = false;
    }

    protected abstract static class GeneratedCriteria {
        protected List<Criterion> criteria;

        protected GeneratedCriteria() {
            super();
            criteria = new ArrayList<Criterion>();
        }

        public boolean isValid() {
            return criteria.size() > 0;
        }

        public List<Criterion> getAllCriteria() {
            return criteria;
        }

        public List<Criterion> getCriteria() {
            return criteria;
        }

        protected void addCriterion(String condition) {
            if (condition == null) {
                throw new RuntimeException("Value for condition cannot be null");
            }
            criteria.add(new Criterion(condition));
        }

        protected void addCriterion(String condition, Object value, String property) {
            if (value == null) {
                throw new RuntimeException("Value for " + property + " cannot be null");
            }
            criteria.add(new Criterion(condition, value));
        }

        protected void addCriterion(String condition, Object value1, Object value2, String property) {
            if (value1 == null || value2 == null) {
                throw new RuntimeException("Between values for " + property + " cannot be null");
            }
            criteria.add(new Criterion(condition, value1, value2));
        }

        public Criteria andFbwIdIsNull() {
            addCriterion("fbw_id is null");
            return (Criteria) this;
        }

        public Criteria andFbwIdIsNotNull() {
            addCriterion("fbw_id is not null");
            return (Criteria) this;
        }

        public Criteria andFbwIdEqualTo(Long value) {
            addCriterion("fbw_id =", value, "fbwId");
            return (Criteria) this;
        }

        public Criteria andFbwIdNotEqualTo(Long value) {
            addCriterion("fbw_id <>", value, "fbwId");
            return (Criteria) this;
        }

        public Criteria andFbwIdGreaterThan(Long value) {
            addCriterion("fbw_id >", value, "fbwId");
            return (Criteria) this;
        }

        public Criteria andFbwIdGreaterThanOrEqualTo(Long value) {
            addCriterion("fbw_id >=", value, "fbwId");
            return (Criteria) this;
        }

        public Criteria andFbwIdLessThan(Long value) {
            addCriterion("fbw_id <", value, "fbwId");
            return (Criteria) this;
        }

        public Criteria andFbwIdLessThanOrEqualTo(Long value) {
            addCriterion("fbw_id <=", value, "fbwId");
            return (Criteria) this;
        }

        public Criteria andFbwIdIn(List<Long> values) {
            addCriterion("fbw_id in", values, "fbwId");
            return (Criteria) this;
        }

        public Criteria andFbwIdNotIn(List<Long> values) {
            addCriterion("fbw_id not in", values, "fbwId");
            return (Criteria) this;
        }

        public Criteria andFbwIdBetween(Long value1, Long value2) {
            addCriterion("fbw_id between", value1, value2, "fbwId");
            return (Criteria) this;
        }

        public Criteria andFbwIdNotBetween(Long value1, Long value2) {
            addCriterion("fbw_id not between", value1, value2, "fbwId");
            return (Criteria) this;
        }

        public Criteria andFbwVoucherNoIsNull() {
            addCriterion("fbw_voucher_no is null");
            return (Criteria) this;
        }

        public Criteria andFbwVoucherNoIsNotNull() {
            addCriterion("fbw_voucher_no is not null");
            return (Criteria) this;
        }

        public Criteria andFbwVoucherNoEqualTo(String value) {
            addCriterion("fbw_voucher_no =", value, "fbwVoucherNo");
            return (Criteria) this;
        }

        public Criteria andFbwVoucherNoNotEqualTo(String value) {
            addCriterion("fbw_voucher_no <>", value, "fbwVoucherNo");
            return (Criteria) this;
        }

        public Criteria andFbwVoucherNoGreaterThan(String value) {
            addCriterion("fbw_voucher_no >", value, "fbwVoucherNo");
            return (Criteria) this;
        }

        public Criteria andFbwVoucherNoGreaterThanOrEqualTo(String value) {
            addCriterion("fbw_voucher_no >=", value, "fbwVoucherNo");
            return (Criteria) this;
        }

        public Criteria andFbwVoucherNoLessThan(String value) {
            addCriterion("fbw_voucher_no <", value, "fbwVoucherNo");
            return (Criteria) this;
        }

        public Criteria andFbwVoucherNoLessThanOrEqualTo(String value) {
            addCriterion("fbw_voucher_no <=", value, "fbwVoucherNo");
            return (Criteria) this;
        }

        public Criteria andFbwVoucherNoLike(String value) {
            addCriterion("fbw_voucher_no like", value, "fbwVoucherNo");
            return (Criteria) this;
        }

        public Criteria andFbwVoucherNoNotLike(String value) {
            addCriterion("fbw_voucher_no not like", value, "fbwVoucherNo");
            return (Criteria) this;
        }

        public Criteria andFbwVoucherNoIn(List<String> values) {
            addCriterion("fbw_voucher_no in", values, "fbwVoucherNo");
            return (Criteria) this;
        }

        public Criteria andFbwVoucherNoNotIn(List<String> values) {
            addCriterion("fbw_voucher_no not in", values, "fbwVoucherNo");
            return (Criteria) this;
        }

        public Criteria andFbwVoucherNoBetween(String value1, String value2) {
            addCriterion("fbw_voucher_no between", value1, value2, "fbwVoucherNo");
            return (Criteria) this;
        }

        public Criteria andFbwVoucherNoNotBetween(String value1, String value2) {
            addCriterion("fbw_voucher_no not between", value1, value2, "fbwVoucherNo");
            return (Criteria) this;
        }

        public Criteria andFbwOwnAccountIsNull() {
            addCriterion("fbw_own_account is null");
            return (Criteria) this;
        }

        public Criteria andFbwOwnAccountIsNotNull() {
            addCriterion("fbw_own_account is not null");
            return (Criteria) this;
        }

        public Criteria andFbwOwnAccountEqualTo(String value) {
            addCriterion("fbw_own_account =", value, "fbwOwnAccount");
            return (Criteria) this;
        }

        public Criteria andFbwOwnAccountNotEqualTo(String value) {
            addCriterion("fbw_own_account <>", value, "fbwOwnAccount");
            return (Criteria) this;
        }

        public Criteria andFbwOwnAccountGreaterThan(String value) {
            addCriterion("fbw_own_account >", value, "fbwOwnAccount");
            return (Criteria) this;
        }

        public Criteria andFbwOwnAccountGreaterThanOrEqualTo(String value) {
            addCriterion("fbw_own_account >=", value, "fbwOwnAccount");
            return (Criteria) this;
        }

        public Criteria andFbwOwnAccountLessThan(String value) {
            addCriterion("fbw_own_account <", value, "fbwOwnAccount");
            return (Criteria) this;
        }

        public Criteria andFbwOwnAccountLessThanOrEqualTo(String value) {
            addCriterion("fbw_own_account <=", value, "fbwOwnAccount");
            return (Criteria) this;
        }

        public Criteria andFbwOwnAccountLike(String value) {
            addCriterion("fbw_own_account like", value, "fbwOwnAccount");
            return (Criteria) this;
        }

        public Criteria andFbwOwnAccountNotLike(String value) {
            addCriterion("fbw_own_account not like", value, "fbwOwnAccount");
            return (Criteria) this;
        }

        public Criteria andFbwOwnAccountIn(List<String> values) {
            addCriterion("fbw_own_account in", values, "fbwOwnAccount");
            return (Criteria) this;
        }

        public Criteria andFbwOwnAccountNotIn(List<String> values) {
            addCriterion("fbw_own_account not in", values, "fbwOwnAccount");
            return (Criteria) this;
        }

        public Criteria andFbwOwnAccountBetween(String value1, String value2) {
            addCriterion("fbw_own_account between", value1, value2, "fbwOwnAccount");
            return (Criteria) this;
        }

        public Criteria andFbwOwnAccountNotBetween(String value1, String value2) {
            addCriterion("fbw_own_account not between", value1, value2, "fbwOwnAccount");
            return (Criteria) this;
        }

        public Criteria andFbwOtherAccountIsNull() {
            addCriterion("fbw_other_account is null");
            return (Criteria) this;
        }

        public Criteria andFbwOtherAccountIsNotNull() {
            addCriterion("fbw_other_account is not null");
            return (Criteria) this;
        }

        public Criteria andFbwOtherAccountEqualTo(String value) {
            addCriterion("fbw_other_account =", value, "fbwOtherAccount");
            return (Criteria) this;
        }

        public Criteria andFbwOtherAccountNotEqualTo(String value) {
            addCriterion("fbw_other_account <>", value, "fbwOtherAccount");
            return (Criteria) this;
        }

        public Criteria andFbwOtherAccountGreaterThan(String value) {
            addCriterion("fbw_other_account >", value, "fbwOtherAccount");
            return (Criteria) this;
        }

        public Criteria andFbwOtherAccountGreaterThanOrEqualTo(String value) {
            addCriterion("fbw_other_account >=", value, "fbwOtherAccount");
            return (Criteria) this;
        }

        public Criteria andFbwOtherAccountLessThan(String value) {
            addCriterion("fbw_other_account <", value, "fbwOtherAccount");
            return (Criteria) this;
        }

        public Criteria andFbwOtherAccountLessThanOrEqualTo(String value) {
            addCriterion("fbw_other_account <=", value, "fbwOtherAccount");
            return (Criteria) this;
        }

        public Criteria andFbwOtherAccountLike(String value) {
            addCriterion("fbw_other_account like", value, "fbwOtherAccount");
            return (Criteria) this;
        }

        public Criteria andFbwOtherAccountNotLike(String value) {
            addCriterion("fbw_other_account not like", value, "fbwOtherAccount");
            return (Criteria) this;
        }

        public Criteria andFbwOtherAccountIn(List<String> values) {
            addCriterion("fbw_other_account in", values, "fbwOtherAccount");
            return (Criteria) this;
        }

        public Criteria andFbwOtherAccountNotIn(List<String> values) {
            addCriterion("fbw_other_account not in", values, "fbwOtherAccount");
            return (Criteria) this;
        }

        public Criteria andFbwOtherAccountBetween(String value1, String value2) {
            addCriterion("fbw_other_account between", value1, value2, "fbwOtherAccount");
            return (Criteria) this;
        }

        public Criteria andFbwOtherAccountNotBetween(String value1, String value2) {
            addCriterion("fbw_other_account not between", value1, value2, "fbwOtherAccount");
            return (Criteria) this;
        }

        public Criteria andFbwOtherUnitNameIsNull() {
            addCriterion("fbw_other_unit_name is null");
            return (Criteria) this;
        }

        public Criteria andFbwOtherUnitNameIsNotNull() {
            addCriterion("fbw_other_unit_name is not null");
            return (Criteria) this;
        }

        public Criteria andFbwOtherUnitNameEqualTo(String value) {
            addCriterion("fbw_other_unit_name =", value, "fbwOtherUnitName");
            return (Criteria) this;
        }

        public Criteria andFbwOtherUnitNameNotEqualTo(String value) {
            addCriterion("fbw_other_unit_name <>", value, "fbwOtherUnitName");
            return (Criteria) this;
        }

        public Criteria andFbwOtherUnitNameGreaterThan(String value) {
            addCriterion("fbw_other_unit_name >", value, "fbwOtherUnitName");
            return (Criteria) this;
        }

        public Criteria andFbwOtherUnitNameGreaterThanOrEqualTo(String value) {
            addCriterion("fbw_other_unit_name >=", value, "fbwOtherUnitName");
            return (Criteria) this;
        }

        public Criteria andFbwOtherUnitNameLessThan(String value) {
            addCriterion("fbw_other_unit_name <", value, "fbwOtherUnitName");
            return (Criteria) this;
        }

        public Criteria andFbwOtherUnitNameLessThanOrEqualTo(String value) {
            addCriterion("fbw_other_unit_name <=", value, "fbwOtherUnitName");
            return (Criteria) this;
        }

        public Criteria andFbwOtherUnitNameLike(String value) {
            addCriterion("fbw_other_unit_name like", value, "fbwOtherUnitName");
            return (Criteria) this;
        }

        public Criteria andFbwOtherUnitNameNotLike(String value) {
            addCriterion("fbw_other_unit_name not like", value, "fbwOtherUnitName");
            return (Criteria) this;
        }

        public Criteria andFbwOtherUnitNameIn(List<String> values) {
            addCriterion("fbw_other_unit_name in", values, "fbwOtherUnitName");
            return (Criteria) this;
        }

        public Criteria andFbwOtherUnitNameNotIn(List<String> values) {
            addCriterion("fbw_other_unit_name not in", values, "fbwOtherUnitName");
            return (Criteria) this;
        }

        public Criteria andFbwOtherUnitNameBetween(String value1, String value2) {
            addCriterion("fbw_other_unit_name between", value1, value2, "fbwOtherUnitName");
            return (Criteria) this;
        }

        public Criteria andFbwOtherUnitNameNotBetween(String value1, String value2) {
            addCriterion("fbw_other_unit_name not between", value1, value2, "fbwOtherUnitName");
            return (Criteria) this;
        }

        public Criteria andFbwLoanTypeIsNull() {
            addCriterion("fbw_loan_type is null");
            return (Criteria) this;
        }

        public Criteria andFbwLoanTypeIsNotNull() {
            addCriterion("fbw_loan_type is not null");
            return (Criteria) this;
        }

        public Criteria andFbwLoanTypeEqualTo(Integer value) {
            addCriterion("fbw_loan_type =", value, "fbwLoanType");
            return (Criteria) this;
        }

        public Criteria andFbwLoanTypeNotEqualTo(Integer value) {
            addCriterion("fbw_loan_type <>", value, "fbwLoanType");
            return (Criteria) this;
        }

        public Criteria andFbwLoanTypeGreaterThan(Integer value) {
            addCriterion("fbw_loan_type >", value, "fbwLoanType");
            return (Criteria) this;
        }

        public Criteria andFbwLoanTypeGreaterThanOrEqualTo(Integer value) {
            addCriterion("fbw_loan_type >=", value, "fbwLoanType");
            return (Criteria) this;
        }

        public Criteria andFbwLoanTypeLessThan(Integer value) {
            addCriterion("fbw_loan_type <", value, "fbwLoanType");
            return (Criteria) this;
        }

        public Criteria andFbwLoanTypeLessThanOrEqualTo(Integer value) {
            addCriterion("fbw_loan_type <=", value, "fbwLoanType");
            return (Criteria) this;
        }

        public Criteria andFbwLoanTypeIn(List<Integer> values) {
            addCriterion("fbw_loan_type in", values, "fbwLoanType");
            return (Criteria) this;
        }

        public Criteria andFbwLoanTypeNotIn(List<Integer> values) {
            addCriterion("fbw_loan_type not in", values, "fbwLoanType");
            return (Criteria) this;
        }

        public Criteria andFbwLoanTypeBetween(Integer value1, Integer value2) {
            addCriterion("fbw_loan_type between", value1, value2, "fbwLoanType");
            return (Criteria) this;
        }

        public Criteria andFbwLoanTypeNotBetween(Integer value1, Integer value2) {
            addCriterion("fbw_loan_type not between", value1, value2, "fbwLoanType");
            return (Criteria) this;
        }

        public Criteria andFbwDealTimeIsNull() {
            addCriterion("fbw_deal_time is null");
            return (Criteria) this;
        }

        public Criteria andFbwDealTimeIsNotNull() {
            addCriterion("fbw_deal_time is not null");
            return (Criteria) this;
        }

        public Criteria andFbwDealTimeEqualTo(Date value) {
            addCriterion("fbw_deal_time =", value, "fbwDealTime");
            return (Criteria) this;
        }

        public Criteria andFbwDealTimeNotEqualTo(Date value) {
            addCriterion("fbw_deal_time <>", value, "fbwDealTime");
            return (Criteria) this;
        }

        public Criteria andFbwDealTimeGreaterThan(Date value) {
            addCriterion("fbw_deal_time >", value, "fbwDealTime");
            return (Criteria) this;
        }

        public Criteria andFbwDealTimeGreaterThanOrEqualTo(Date value) {
            addCriterion("fbw_deal_time >=", value, "fbwDealTime");
            return (Criteria) this;
        }

        public Criteria andFbwDealTimeLessThan(Date value) {
            addCriterion("fbw_deal_time <", value, "fbwDealTime");
            return (Criteria) this;
        }

        public Criteria andFbwDealTimeLessThanOrEqualTo(Date value) {
            addCriterion("fbw_deal_time <=", value, "fbwDealTime");
            return (Criteria) this;
        }

        public Criteria andFbwDealTimeIn(List<Date> values) {
            addCriterion("fbw_deal_time in", values, "fbwDealTime");
            return (Criteria) this;
        }

        public Criteria andFbwDealTimeNotIn(List<Date> values) {
            addCriterion("fbw_deal_time not in", values, "fbwDealTime");
            return (Criteria) this;
        }

        public Criteria andFbwDealTimeBetween(Date value1, Date value2) {
            addCriterion("fbw_deal_time between", value1, value2, "fbwDealTime");
            return (Criteria) this;
        }

        public Criteria andFbwDealTimeNotBetween(Date value1, Date value2) {
            addCriterion("fbw_deal_time not between", value1, value2, "fbwDealTime");
            return (Criteria) this;
        }

        public Criteria andFbwBorrowAmountIsNull() {
            addCriterion("fbw_borrow_amount is null");
            return (Criteria) this;
        }

        public Criteria andFbwBorrowAmountIsNotNull() {
            addCriterion("fbw_borrow_amount is not null");
            return (Criteria) this;
        }

        public Criteria andFbwBorrowAmountEqualTo(Double value) {
            addCriterion("fbw_borrow_amount =", value, "fbwBorrowAmount");
            return (Criteria) this;
        }

        public Criteria andFbwBorrowAmountNotEqualTo(Double value) {
            addCriterion("fbw_borrow_amount <>", value, "fbwBorrowAmount");
            return (Criteria) this;
        }

        public Criteria andFbwBorrowAmountGreaterThan(Double value) {
            addCriterion("fbw_borrow_amount >", value, "fbwBorrowAmount");
            return (Criteria) this;
        }

        public Criteria andFbwBorrowAmountGreaterThanOrEqualTo(Double value) {
            addCriterion("fbw_borrow_amount >=", value, "fbwBorrowAmount");
            return (Criteria) this;
        }

        public Criteria andFbwBorrowAmountLessThan(Double value) {
            addCriterion("fbw_borrow_amount <", value, "fbwBorrowAmount");
            return (Criteria) this;
        }

        public Criteria andFbwBorrowAmountLessThanOrEqualTo(Double value) {
            addCriterion("fbw_borrow_amount <=", value, "fbwBorrowAmount");
            return (Criteria) this;
        }

        public Criteria andFbwBorrowAmountIn(List<Double> values) {
            addCriterion("fbw_borrow_amount in", values, "fbwBorrowAmount");
            return (Criteria) this;
        }

        public Criteria andFbwBorrowAmountNotIn(List<Double> values) {
            addCriterion("fbw_borrow_amount not in", values, "fbwBorrowAmount");
            return (Criteria) this;
        }

        public Criteria andFbwBorrowAmountBetween(Double value1, Double value2) {
            addCriterion("fbw_borrow_amount between", value1, value2, "fbwBorrowAmount");
            return (Criteria) this;
        }

        public Criteria andFbwBorrowAmountNotBetween(Double value1, Double value2) {
            addCriterion("fbw_borrow_amount not between", value1, value2, "fbwBorrowAmount");
            return (Criteria) this;
        }

        public Criteria andFbwCreditAmountIsNull() {
            addCriterion("fbw_credit_amount is null");
            return (Criteria) this;
        }

        public Criteria andFbwCreditAmountIsNotNull() {
            addCriterion("fbw_credit_amount is not null");
            return (Criteria) this;
        }

        public Criteria andFbwCreditAmountEqualTo(Double value) {
            addCriterion("fbw_credit_amount =", value, "fbwCreditAmount");
            return (Criteria) this;
        }

        public Criteria andFbwCreditAmountNotEqualTo(Double value) {
            addCriterion("fbw_credit_amount <>", value, "fbwCreditAmount");
            return (Criteria) this;
        }

        public Criteria andFbwCreditAmountGreaterThan(Double value) {
            addCriterion("fbw_credit_amount >", value, "fbwCreditAmount");
            return (Criteria) this;
        }

        public Criteria andFbwCreditAmountGreaterThanOrEqualTo(Double value) {
            addCriterion("fbw_credit_amount >=", value, "fbwCreditAmount");
            return (Criteria) this;
        }

        public Criteria andFbwCreditAmountLessThan(Double value) {
            addCriterion("fbw_credit_amount <", value, "fbwCreditAmount");
            return (Criteria) this;
        }

        public Criteria andFbwCreditAmountLessThanOrEqualTo(Double value) {
            addCriterion("fbw_credit_amount <=", value, "fbwCreditAmount");
            return (Criteria) this;
        }

        public Criteria andFbwCreditAmountIn(List<Double> values) {
            addCriterion("fbw_credit_amount in", values, "fbwCreditAmount");
            return (Criteria) this;
        }

        public Criteria andFbwCreditAmountNotIn(List<Double> values) {
            addCriterion("fbw_credit_amount not in", values, "fbwCreditAmount");
            return (Criteria) this;
        }

        public Criteria andFbwCreditAmountBetween(Double value1, Double value2) {
            addCriterion("fbw_credit_amount between", value1, value2, "fbwCreditAmount");
            return (Criteria) this;
        }

        public Criteria andFbwCreditAmountNotBetween(Double value1, Double value2) {
            addCriterion("fbw_credit_amount not between", value1, value2, "fbwCreditAmount");
            return (Criteria) this;
        }

        public Criteria andFbwUseIsNull() {
            addCriterion("fbw_use is null");
            return (Criteria) this;
        }

        public Criteria andFbwUseIsNotNull() {
            addCriterion("fbw_use is not null");
            return (Criteria) this;
        }

        public Criteria andFbwUseEqualTo(String value) {
            addCriterion("fbw_use =", value, "fbwUse");
            return (Criteria) this;
        }

        public Criteria andFbwUseNotEqualTo(String value) {
            addCriterion("fbw_use <>", value, "fbwUse");
            return (Criteria) this;
        }

        public Criteria andFbwUseGreaterThan(String value) {
            addCriterion("fbw_use >", value, "fbwUse");
            return (Criteria) this;
        }

        public Criteria andFbwUseGreaterThanOrEqualTo(String value) {
            addCriterion("fbw_use >=", value, "fbwUse");
            return (Criteria) this;
        }

        public Criteria andFbwUseLessThan(String value) {
            addCriterion("fbw_use <", value, "fbwUse");
            return (Criteria) this;
        }

        public Criteria andFbwUseLessThanOrEqualTo(String value) {
            addCriterion("fbw_use <=", value, "fbwUse");
            return (Criteria) this;
        }

        public Criteria andFbwUseLike(String value) {
            addCriterion("fbw_use like", value, "fbwUse");
            return (Criteria) this;
        }

        public Criteria andFbwUseNotLike(String value) {
            addCriterion("fbw_use not like", value, "fbwUse");
            return (Criteria) this;
        }

        public Criteria andFbwUseIn(List<String> values) {
            addCriterion("fbw_use in", values, "fbwUse");
            return (Criteria) this;
        }

        public Criteria andFbwUseNotIn(List<String> values) {
            addCriterion("fbw_use not in", values, "fbwUse");
            return (Criteria) this;
        }

        public Criteria andFbwUseBetween(String value1, String value2) {
            addCriterion("fbw_use between", value1, value2, "fbwUse");
            return (Criteria) this;
        }

        public Criteria andFbwUseNotBetween(String value1, String value2) {
            addCriterion("fbw_use not between", value1, value2, "fbwUse");
            return (Criteria) this;
        }

        public Criteria andFbwDigestIsNull() {
            addCriterion("fbw_digest is null");
            return (Criteria) this;
        }

        public Criteria andFbwDigestIsNotNull() {
            addCriterion("fbw_digest is not null");
            return (Criteria) this;
        }

        public Criteria andFbwDigestEqualTo(String value) {
            addCriterion("fbw_digest =", value, "fbwDigest");
            return (Criteria) this;
        }

        public Criteria andFbwDigestNotEqualTo(String value) {
            addCriterion("fbw_digest <>", value, "fbwDigest");
            return (Criteria) this;
        }

        public Criteria andFbwDigestGreaterThan(String value) {
            addCriterion("fbw_digest >", value, "fbwDigest");
            return (Criteria) this;
        }

        public Criteria andFbwDigestGreaterThanOrEqualTo(String value) {
            addCriterion("fbw_digest >=", value, "fbwDigest");
            return (Criteria) this;
        }

        public Criteria andFbwDigestLessThan(String value) {
            addCriterion("fbw_digest <", value, "fbwDigest");
            return (Criteria) this;
        }

        public Criteria andFbwDigestLessThanOrEqualTo(String value) {
            addCriterion("fbw_digest <=", value, "fbwDigest");
            return (Criteria) this;
        }

        public Criteria andFbwDigestLike(String value) {
            addCriterion("fbw_digest like", value, "fbwDigest");
            return (Criteria) this;
        }

        public Criteria andFbwDigestNotLike(String value) {
            addCriterion("fbw_digest not like", value, "fbwDigest");
            return (Criteria) this;
        }

        public Criteria andFbwDigestIn(List<String> values) {
            addCriterion("fbw_digest in", values, "fbwDigest");
            return (Criteria) this;
        }

        public Criteria andFbwDigestNotIn(List<String> values) {
            addCriterion("fbw_digest not in", values, "fbwDigest");
            return (Criteria) this;
        }

        public Criteria andFbwDigestBetween(String value1, String value2) {
            addCriterion("fbw_digest between", value1, value2, "fbwDigest");
            return (Criteria) this;
        }

        public Criteria andFbwDigestNotBetween(String value1, String value2) {
            addCriterion("fbw_digest not between", value1, value2, "fbwDigest");
            return (Criteria) this;
        }

        public Criteria andFbwPersonalizedInformationIsNull() {
            addCriterion("fbw_personalized_information is null");
            return (Criteria) this;
        }

        public Criteria andFbwPersonalizedInformationIsNotNull() {
            addCriterion("fbw_personalized_information is not null");
            return (Criteria) this;
        }

        public Criteria andFbwPersonalizedInformationEqualTo(String value) {
            addCriterion("fbw_personalized_information =", value, "fbwPersonalizedInformation");
            return (Criteria) this;
        }

        public Criteria andFbwPersonalizedInformationNotEqualTo(String value) {
            addCriterion("fbw_personalized_information <>", value, "fbwPersonalizedInformation");
            return (Criteria) this;
        }

        public Criteria andFbwPersonalizedInformationGreaterThan(String value) {
            addCriterion("fbw_personalized_information >", value, "fbwPersonalizedInformation");
            return (Criteria) this;
        }

        public Criteria andFbwPersonalizedInformationGreaterThanOrEqualTo(String value) {
            addCriterion("fbw_personalized_information >=", value, "fbwPersonalizedInformation");
            return (Criteria) this;
        }

        public Criteria andFbwPersonalizedInformationLessThan(String value) {
            addCriterion("fbw_personalized_information <", value, "fbwPersonalizedInformation");
            return (Criteria) this;
        }

        public Criteria andFbwPersonalizedInformationLessThanOrEqualTo(String value) {
            addCriterion("fbw_personalized_information <=", value, "fbwPersonalizedInformation");
            return (Criteria) this;
        }

        public Criteria andFbwPersonalizedInformationLike(String value) {
            addCriterion("fbw_personalized_information like", value, "fbwPersonalizedInformation");
            return (Criteria) this;
        }

        public Criteria andFbwPersonalizedInformationNotLike(String value) {
            addCriterion("fbw_personalized_information not like", value, "fbwPersonalizedInformation");
            return (Criteria) this;
        }

        public Criteria andFbwPersonalizedInformationIn(List<String> values) {
            addCriterion("fbw_personalized_information in", values, "fbwPersonalizedInformation");
            return (Criteria) this;
        }

        public Criteria andFbwPersonalizedInformationNotIn(List<String> values) {
            addCriterion("fbw_personalized_information not in", values, "fbwPersonalizedInformation");
            return (Criteria) this;
        }

        public Criteria andFbwPersonalizedInformationBetween(String value1, String value2) {
            addCriterion("fbw_personalized_information between", value1, value2, "fbwPersonalizedInformation");
            return (Criteria) this;
        }

        public Criteria andFbwPersonalizedInformationNotBetween(String value1, String value2) {
            addCriterion("fbw_personalized_information not between", value1, value2, "fbwPersonalizedInformation");
            return (Criteria) this;
        }

        public Criteria andFbwMatchStateIsNull() {
            addCriterion("fbw_match_state is null");
            return (Criteria) this;
        }

        public Criteria andFbwMatchStateIsNotNull() {
            addCriterion("fbw_match_state is not null");
            return (Criteria) this;
        }

        public Criteria andFbwMatchStateEqualTo(Integer value) {
            addCriterion("fbw_match_state =", value, "fbwMatchState");
            return (Criteria) this;
        }

        public Criteria andFbwMatchStateNotEqualTo(Integer value) {
            addCriterion("fbw_match_state <>", value, "fbwMatchState");
            return (Criteria) this;
        }

        public Criteria andFbwMatchStateGreaterThan(Integer value) {
            addCriterion("fbw_match_state >", value, "fbwMatchState");
            return (Criteria) this;
        }

        public Criteria andFbwMatchStateGreaterThanOrEqualTo(Integer value) {
            addCriterion("fbw_match_state >=", value, "fbwMatchState");
            return (Criteria) this;
        }

        public Criteria andFbwMatchStateLessThan(Integer value) {
            addCriterion("fbw_match_state <", value, "fbwMatchState");
            return (Criteria) this;
        }

        public Criteria andFbwMatchStateLessThanOrEqualTo(Integer value) {
            addCriterion("fbw_match_state <=", value, "fbwMatchState");
            return (Criteria) this;
        }

        public Criteria andFbwMatchStateIn(List<Integer> values) {
            addCriterion("fbw_match_state in", values, "fbwMatchState");
            return (Criteria) this;
        }

        public Criteria andFbwMatchStateNotIn(List<Integer> values) {
            addCriterion("fbw_match_state not in", values, "fbwMatchState");
            return (Criteria) this;
        }

        public Criteria andFbwMatchStateBetween(Integer value1, Integer value2) {
            addCriterion("fbw_match_state between", value1, value2, "fbwMatchState");
            return (Criteria) this;
        }

        public Criteria andFbwMatchStateNotBetween(Integer value1, Integer value2) {
            addCriterion("fbw_match_state not between", value1, value2, "fbwMatchState");
            return (Criteria) this;
        }

        public Criteria andFbwMatchBillIsNull() {
            addCriterion("fbw_match_bill is null");
            return (Criteria) this;
        }

        public Criteria andFbwMatchBillIsNotNull() {
            addCriterion("fbw_match_bill is not null");
            return (Criteria) this;
        }

        public Criteria andFbwMatchBillEqualTo(String value) {
            addCriterion("fbw_match_bill =", value, "fbwMatchBill");
            return (Criteria) this;
        }

        public Criteria andFbwMatchBillNotEqualTo(String value) {
            addCriterion("fbw_match_bill <>", value, "fbwMatchBill");
            return (Criteria) this;
        }

        public Criteria andFbwMatchBillGreaterThan(String value) {
            addCriterion("fbw_match_bill >", value, "fbwMatchBill");
            return (Criteria) this;
        }

        public Criteria andFbwMatchBillGreaterThanOrEqualTo(String value) {
            addCriterion("fbw_match_bill >=", value, "fbwMatchBill");
            return (Criteria) this;
        }

        public Criteria andFbwMatchBillLessThan(String value) {
            addCriterion("fbw_match_bill <", value, "fbwMatchBill");
            return (Criteria) this;
        }

        public Criteria andFbwMatchBillLessThanOrEqualTo(String value) {
            addCriterion("fbw_match_bill <=", value, "fbwMatchBill");
            return (Criteria) this;
        }

        public Criteria andFbwMatchBillLike(String value) {
            addCriterion("fbw_match_bill like", value, "fbwMatchBill");
            return (Criteria) this;
        }

        public Criteria andFbwMatchBillNotLike(String value) {
            addCriterion("fbw_match_bill not like", value, "fbwMatchBill");
            return (Criteria) this;
        }

        public Criteria andFbwMatchBillIn(List<String> values) {
            addCriterion("fbw_match_bill in", values, "fbwMatchBill");
            return (Criteria) this;
        }

        public Criteria andFbwMatchBillNotIn(List<String> values) {
            addCriterion("fbw_match_bill not in", values, "fbwMatchBill");
            return (Criteria) this;
        }

        public Criteria andFbwMatchBillBetween(String value1, String value2) {
            addCriterion("fbw_match_bill between", value1, value2, "fbwMatchBill");
            return (Criteria) this;
        }

        public Criteria andFbwMatchBillNotBetween(String value1, String value2) {
            addCriterion("fbw_match_bill not between", value1, value2, "fbwMatchBill");
            return (Criteria) this;
        }

        public Criteria andFbwMatchTypeIsNull() {
            addCriterion("fbw_match_type is null");
            return (Criteria) this;
        }

        public Criteria andFbwMatchTypeIsNotNull() {
            addCriterion("fbw_match_type is not null");
            return (Criteria) this;
        }

        public Criteria andFbwMatchTypeEqualTo(Integer value) {
            addCriterion("fbw_match_type =", value, "fbwMatchType");
            return (Criteria) this;
        }

        public Criteria andFbwMatchTypeNotEqualTo(Integer value) {
            addCriterion("fbw_match_type <>", value, "fbwMatchType");
            return (Criteria) this;
        }

        public Criteria andFbwMatchTypeGreaterThan(Integer value) {
            addCriterion("fbw_match_type >", value, "fbwMatchType");
            return (Criteria) this;
        }

        public Criteria andFbwMatchTypeGreaterThanOrEqualTo(Integer value) {
            addCriterion("fbw_match_type >=", value, "fbwMatchType");
            return (Criteria) this;
        }

        public Criteria andFbwMatchTypeLessThan(Integer value) {
            addCriterion("fbw_match_type <", value, "fbwMatchType");
            return (Criteria) this;
        }

        public Criteria andFbwMatchTypeLessThanOrEqualTo(Integer value) {
            addCriterion("fbw_match_type <=", value, "fbwMatchType");
            return (Criteria) this;
        }

        public Criteria andFbwMatchTypeIn(List<Integer> values) {
            addCriterion("fbw_match_type in", values, "fbwMatchType");
            return (Criteria) this;
        }

        public Criteria andFbwMatchTypeNotIn(List<Integer> values) {
            addCriterion("fbw_match_type not in", values, "fbwMatchType");
            return (Criteria) this;
        }

        public Criteria andFbwMatchTypeBetween(Integer value1, Integer value2) {
            addCriterion("fbw_match_type between", value1, value2, "fbwMatchType");
            return (Criteria) this;
        }

        public Criteria andFbwMatchTypeNotBetween(Integer value1, Integer value2) {
            addCriterion("fbw_match_type not between", value1, value2, "fbwMatchType");
            return (Criteria) this;
        }

        public Criteria andFbwMatchedAmountIsNull() {
            addCriterion("fbw_matched_amount is null");
            return (Criteria) this;
        }

        public Criteria andFbwMatchedAmountIsNotNull() {
            addCriterion("fbw_matched_amount is not null");
            return (Criteria) this;
        }

        public Criteria andFbwMatchedAmountEqualTo(Double value) {
            addCriterion("fbw_matched_amount =", value, "fbwMatchedAmount");
            return (Criteria) this;
        }

        public Criteria andFbwMatchedAmountNotEqualTo(Double value) {
            addCriterion("fbw_matched_amount <>", value, "fbwMatchedAmount");
            return (Criteria) this;
        }

        public Criteria andFbwMatchedAmountGreaterThan(Double value) {
            addCriterion("fbw_matched_amount >", value, "fbwMatchedAmount");
            return (Criteria) this;
        }

        public Criteria andFbwMatchedAmountGreaterThanOrEqualTo(Double value) {
            addCriterion("fbw_matched_amount >=", value, "fbwMatchedAmount");
            return (Criteria) this;
        }

        public Criteria andFbwMatchedAmountLessThan(Double value) {
            addCriterion("fbw_matched_amount <", value, "fbwMatchedAmount");
            return (Criteria) this;
        }

        public Criteria andFbwMatchedAmountLessThanOrEqualTo(Double value) {
            addCriterion("fbw_matched_amount <=", value, "fbwMatchedAmount");
            return (Criteria) this;
        }

        public Criteria andFbwMatchedAmountIn(List<Double> values) {
            addCriterion("fbw_matched_amount in", values, "fbwMatchedAmount");
            return (Criteria) this;
        }

        public Criteria andFbwMatchedAmountNotIn(List<Double> values) {
            addCriterion("fbw_matched_amount not in", values, "fbwMatchedAmount");
            return (Criteria) this;
        }

        public Criteria andFbwMatchedAmountBetween(Double value1, Double value2) {
            addCriterion("fbw_matched_amount between", value1, value2, "fbwMatchedAmount");
            return (Criteria) this;
        }

        public Criteria andFbwMatchedAmountNotBetween(Double value1, Double value2) {
            addCriterion("fbw_matched_amount not between", value1, value2, "fbwMatchedAmount");
            return (Criteria) this;
        }

        public Criteria andFbwNotMatchAmountIsNull() {
            addCriterion("fbw_not_match_amount is null");
            return (Criteria) this;
        }

        public Criteria andFbwNotMatchAmountIsNotNull() {
            addCriterion("fbw_not_match_amount is not null");
            return (Criteria) this;
        }

        public Criteria andFbwNotMatchAmountEqualTo(Double value) {
            addCriterion("fbw_not_match_amount =", value, "fbwNotMatchAmount");
            return (Criteria) this;
        }

        public Criteria andFbwNotMatchAmountNotEqualTo(Double value) {
            addCriterion("fbw_not_match_amount <>", value, "fbwNotMatchAmount");
            return (Criteria) this;
        }

        public Criteria andFbwNotMatchAmountGreaterThan(Double value) {
            addCriterion("fbw_not_match_amount >", value, "fbwNotMatchAmount");
            return (Criteria) this;
        }

        public Criteria andFbwNotMatchAmountGreaterThanOrEqualTo(Double value) {
            addCriterion("fbw_not_match_amount >=", value, "fbwNotMatchAmount");
            return (Criteria) this;
        }

        public Criteria andFbwNotMatchAmountLessThan(Double value) {
            addCriterion("fbw_not_match_amount <", value, "fbwNotMatchAmount");
            return (Criteria) this;
        }

        public Criteria andFbwNotMatchAmountLessThanOrEqualTo(Double value) {
            addCriterion("fbw_not_match_amount <=", value, "fbwNotMatchAmount");
            return (Criteria) this;
        }

        public Criteria andFbwNotMatchAmountIn(List<Double> values) {
            addCriterion("fbw_not_match_amount in", values, "fbwNotMatchAmount");
            return (Criteria) this;
        }

        public Criteria andFbwNotMatchAmountNotIn(List<Double> values) {
            addCriterion("fbw_not_match_amount not in", values, "fbwNotMatchAmount");
            return (Criteria) this;
        }

        public Criteria andFbwNotMatchAmountBetween(Double value1, Double value2) {
            addCriterion("fbw_not_match_amount between", value1, value2, "fbwNotMatchAmount");
            return (Criteria) this;
        }

        public Criteria andFbwNotMatchAmountNotBetween(Double value1, Double value2) {
            addCriterion("fbw_not_match_amount not between", value1, value2, "fbwNotMatchAmount");
            return (Criteria) this;
        }

        public Criteria andRemarkIsNull() {
            addCriterion("remark is null");
            return (Criteria) this;
        }

        public Criteria andRemarkIsNotNull() {
            addCriterion("remark is not null");
            return (Criteria) this;
        }

        public Criteria andRemarkEqualTo(String value) {
            addCriterion("remark =", value, "remark");
            return (Criteria) this;
        }

        public Criteria andRemarkNotEqualTo(String value) {
            addCriterion("remark <>", value, "remark");
            return (Criteria) this;
        }

        public Criteria andRemarkGreaterThan(String value) {
            addCriterion("remark >", value, "remark");
            return (Criteria) this;
        }

        public Criteria andRemarkGreaterThanOrEqualTo(String value) {
            addCriterion("remark >=", value, "remark");
            return (Criteria) this;
        }

        public Criteria andRemarkLessThan(String value) {
            addCriterion("remark <", value, "remark");
            return (Criteria) this;
        }

        public Criteria andRemarkLessThanOrEqualTo(String value) {
            addCriterion("remark <=", value, "remark");
            return (Criteria) this;
        }

        public Criteria andRemarkLike(String value) {
            addCriterion("remark like", value, "remark");
            return (Criteria) this;
        }

        public Criteria andRemarkNotLike(String value) {
            addCriterion("remark not like", value, "remark");
            return (Criteria) this;
        }

        public Criteria andRemarkIn(List<String> values) {
            addCriterion("remark in", values, "remark");
            return (Criteria) this;
        }

        public Criteria andRemarkNotIn(List<String> values) {
            addCriterion("remark not in", values, "remark");
            return (Criteria) this;
        }

        public Criteria andRemarkBetween(String value1, String value2) {
            addCriterion("remark between", value1, value2, "remark");
            return (Criteria) this;
        }

        public Criteria andRemarkNotBetween(String value1, String value2) {
            addCriterion("remark not between", value1, value2, "remark");
            return (Criteria) this;
        }

        public Criteria andCreateuserIsNull() {
            addCriterion("createuser is null");
            return (Criteria) this;
        }

        public Criteria andCreateuserIsNotNull() {
            addCriterion("createuser is not null");
            return (Criteria) this;
        }

        public Criteria andCreateuserEqualTo(String value) {
            addCriterion("createuser =", value, "createuser");
            return (Criteria) this;
        }

        public Criteria andCreateuserNotEqualTo(String value) {
            addCriterion("createuser <>", value, "createuser");
            return (Criteria) this;
        }

        public Criteria andCreateuserGreaterThan(String value) {
            addCriterion("createuser >", value, "createuser");
            return (Criteria) this;
        }

        public Criteria andCreateuserGreaterThanOrEqualTo(String value) {
            addCriterion("createuser >=", value, "createuser");
            return (Criteria) this;
        }

        public Criteria andCreateuserLessThan(String value) {
            addCriterion("createuser <", value, "createuser");
            return (Criteria) this;
        }

        public Criteria andCreateuserLessThanOrEqualTo(String value) {
            addCriterion("createuser <=", value, "createuser");
            return (Criteria) this;
        }

        public Criteria andCreateuserLike(String value) {
            addCriterion("createuser like", value, "createuser");
            return (Criteria) this;
        }

        public Criteria andCreateuserNotLike(String value) {
            addCriterion("createuser not like", value, "createuser");
            return (Criteria) this;
        }

        public Criteria andCreateuserIn(List<String> values) {
            addCriterion("createuser in", values, "createuser");
            return (Criteria) this;
        }

        public Criteria andCreateuserNotIn(List<String> values) {
            addCriterion("createuser not in", values, "createuser");
            return (Criteria) this;
        }

        public Criteria andCreateuserBetween(String value1, String value2) {
            addCriterion("createuser between", value1, value2, "createuser");
            return (Criteria) this;
        }

        public Criteria andCreateuserNotBetween(String value1, String value2) {
            addCriterion("createuser not between", value1, value2, "createuser");
            return (Criteria) this;
        }

        public Criteria andCreatetimeIsNull() {
            addCriterion("createtime is null");
            return (Criteria) this;
        }

        public Criteria andCreatetimeIsNotNull() {
            addCriterion("createtime is not null");
            return (Criteria) this;
        }

        public Criteria andCreatetimeEqualTo(Date value) {
            addCriterion("createtime =", value, "createtime");
            return (Criteria) this;
        }

        public Criteria andCreatetimeNotEqualTo(Date value) {
            addCriterion("createtime <>", value, "createtime");
            return (Criteria) this;
        }

        public Criteria andCreatetimeGreaterThan(Date value) {
            addCriterion("createtime >", value, "createtime");
            return (Criteria) this;
        }

        public Criteria andCreatetimeGreaterThanOrEqualTo(Date value) {
            addCriterion("createtime >=", value, "createtime");
            return (Criteria) this;
        }

        public Criteria andCreatetimeLessThan(Date value) {
            addCriterion("createtime <", value, "createtime");
            return (Criteria) this;
        }

        public Criteria andCreatetimeLessThanOrEqualTo(Date value) {
            addCriterion("createtime <=", value, "createtime");
            return (Criteria) this;
        }

        public Criteria andCreatetimeIn(List<Date> values) {
            addCriterion("createtime in", values, "createtime");
            return (Criteria) this;
        }

        public Criteria andCreatetimeNotIn(List<Date> values) {
            addCriterion("createtime not in", values, "createtime");
            return (Criteria) this;
        }

        public Criteria andCreatetimeBetween(Date value1, Date value2) {
            addCriterion("createtime between", value1, value2, "createtime");
            return (Criteria) this;
        }

        public Criteria andCreatetimeNotBetween(Date value1, Date value2) {
            addCriterion("createtime not between", value1, value2, "createtime");
            return (Criteria) this;
        }

        public Criteria andUpdateuserIsNull() {
            addCriterion("updateuser is null");
            return (Criteria) this;
        }

        public Criteria andUpdateuserIsNotNull() {
            addCriterion("updateuser is not null");
            return (Criteria) this;
        }

        public Criteria andUpdateuserEqualTo(String value) {
            addCriterion("updateuser =", value, "updateuser");
            return (Criteria) this;
        }

        public Criteria andUpdateuserNotEqualTo(String value) {
            addCriterion("updateuser <>", value, "updateuser");
            return (Criteria) this;
        }

        public Criteria andUpdateuserGreaterThan(String value) {
            addCriterion("updateuser >", value, "updateuser");
            return (Criteria) this;
        }

        public Criteria andUpdateuserGreaterThanOrEqualTo(String value) {
            addCriterion("updateuser >=", value, "updateuser");
            return (Criteria) this;
        }

        public Criteria andUpdateuserLessThan(String value) {
            addCriterion("updateuser <", value, "updateuser");
            return (Criteria) this;
        }

        public Criteria andUpdateuserLessThanOrEqualTo(String value) {
            addCriterion("updateuser <=", value, "updateuser");
            return (Criteria) this;
        }

        public Criteria andUpdateuserLike(String value) {
            addCriterion("updateuser like", value, "updateuser");
            return (Criteria) this;
        }

        public Criteria andUpdateuserNotLike(String value) {
            addCriterion("updateuser not like", value, "updateuser");
            return (Criteria) this;
        }

        public Criteria andUpdateuserIn(List<String> values) {
            addCriterion("updateuser in", values, "updateuser");
            return (Criteria) this;
        }

        public Criteria andUpdateuserNotIn(List<String> values) {
            addCriterion("updateuser not in", values, "updateuser");
            return (Criteria) this;
        }

        public Criteria andUpdateuserBetween(String value1, String value2) {
            addCriterion("updateuser between", value1, value2, "updateuser");
            return (Criteria) this;
        }

        public Criteria andUpdateuserNotBetween(String value1, String value2) {
            addCriterion("updateuser not between", value1, value2, "updateuser");
            return (Criteria) this;
        }

        public Criteria andUpdatetimeIsNull() {
            addCriterion("updatetime is null");
            return (Criteria) this;
        }

        public Criteria andUpdatetimeIsNotNull() {
            addCriterion("updatetime is not null");
            return (Criteria) this;
        }

        public Criteria andUpdatetimeEqualTo(Date value) {
            addCriterion("updatetime =", value, "updatetime");
            return (Criteria) this;
        }

        public Criteria andUpdatetimeNotEqualTo(Date value) {
            addCriterion("updatetime <>", value, "updatetime");
            return (Criteria) this;
        }

        public Criteria andUpdatetimeGreaterThan(Date value) {
            addCriterion("updatetime >", value, "updatetime");
            return (Criteria) this;
        }

        public Criteria andUpdatetimeGreaterThanOrEqualTo(Date value) {
            addCriterion("updatetime >=", value, "updatetime");
            return (Criteria) this;
        }

        public Criteria andUpdatetimeLessThan(Date value) {
            addCriterion("updatetime <", value, "updatetime");
            return (Criteria) this;
        }

        public Criteria andUpdatetimeLessThanOrEqualTo(Date value) {
            addCriterion("updatetime <=", value, "updatetime");
            return (Criteria) this;
        }

        public Criteria andUpdatetimeIn(List<Date> values) {
            addCriterion("updatetime in", values, "updatetime");
            return (Criteria) this;
        }

        public Criteria andUpdatetimeNotIn(List<Date> values) {
            addCriterion("updatetime not in", values, "updatetime");
            return (Criteria) this;
        }

        public Criteria andUpdatetimeBetween(Date value1, Date value2) {
            addCriterion("updatetime between", value1, value2, "updatetime");
            return (Criteria) this;
        }

        public Criteria andUpdatetimeNotBetween(Date value1, Date value2) {
            addCriterion("updatetime not between", value1, value2, "updatetime");
            return (Criteria) this;
        }

        public Criteria andDrIsNull() {
            addCriterion("dr is null");
            return (Criteria) this;
        }

        public Criteria andDrIsNotNull() {
            addCriterion("dr is not null");
            return (Criteria) this;
        }

        public Criteria andDrEqualTo(Integer value) {
            addCriterion("dr =", value, "dr");
            return (Criteria) this;
        }

        public Criteria andDrNotEqualTo(Integer value) {
            addCriterion("dr <>", value, "dr");
            return (Criteria) this;
        }

        public Criteria andDrGreaterThan(Integer value) {
            addCriterion("dr >", value, "dr");
            return (Criteria) this;
        }

        public Criteria andDrGreaterThanOrEqualTo(Integer value) {
            addCriterion("dr >=", value, "dr");
            return (Criteria) this;
        }

        public Criteria andDrLessThan(Integer value) {
            addCriterion("dr <", value, "dr");
            return (Criteria) this;
        }

        public Criteria andDrLessThanOrEqualTo(Integer value) {
            addCriterion("dr <=", value, "dr");
            return (Criteria) this;
        }

        public Criteria andDrIn(List<Integer> values) {
            addCriterion("dr in", values, "dr");
            return (Criteria) this;
        }

        public Criteria andDrNotIn(List<Integer> values) {
            addCriterion("dr not in", values, "dr");
            return (Criteria) this;
        }

        public Criteria andDrBetween(Integer value1, Integer value2) {
            addCriterion("dr between", value1, value2, "dr");
            return (Criteria) this;
        }

        public Criteria andDrNotBetween(Integer value1, Integer value2) {
            addCriterion("dr not between", value1, value2, "dr");
            return (Criteria) this;
        }
    }

    public static class Criteria extends GeneratedCriteria {

        protected Criteria() {
            super();
        }
    }

    public static class Criterion {
        private String condition;

        private Object value;

        private Object secondValue;

        private boolean noValue;

        private boolean singleValue;

        private boolean betweenValue;

        private boolean listValue;

        private String typeHandler;

        public String getCondition() {
            return condition;
        }

        public Object getValue() {
            return value;
        }

        public Object getSecondValue() {
            return secondValue;
        }

        public boolean isNoValue() {
            return noValue;
        }

        public boolean isSingleValue() {
            return singleValue;
        }

        public boolean isBetweenValue() {
            return betweenValue;
        }

        public boolean isListValue() {
            return listValue;
        }

        public String getTypeHandler() {
            return typeHandler;
        }

        protected Criterion(String condition) {
            super();
            this.condition = condition;
            this.typeHandler = null;
            this.noValue = true;
        }

        protected Criterion(String condition, Object value, String typeHandler) {
            super();
            this.condition = condition;
            this.value = value;
            this.typeHandler = typeHandler;
            if (value instanceof List<?>) {
                this.listValue = true;
            } else {
                this.singleValue = true;
            }
        }

        protected Criterion(String condition, Object value) {
            this(condition, value, null);
        }

        protected Criterion(String condition, Object value, Object secondValue, String typeHandler) {
            super();
            this.condition = condition;
            this.value = value;
            this.secondValue = secondValue;
            this.typeHandler = typeHandler;
            this.betweenValue = true;
        }

        protected Criterion(String condition, Object value, Object secondValue) {
            this(condition, value, secondValue, null);
        }
    }
}
