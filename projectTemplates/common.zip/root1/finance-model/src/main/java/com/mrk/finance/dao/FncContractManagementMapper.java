package com.mrk.finance.dao;

import com.mrk.common.base.BaseMapper;
import com.mrk.finance.client.dto.ContractAnalysisDto;
import com.mrk.finance.client.dto.FncContractManagementDto;
import com.mrk.finance.dto.ManagementRiskDto;
import com.mrk.finance.model.FncContractManagement;
import com.mrk.finance.queryvo.FncContractManagementQueryVo;
import org.apache.ibatis.annotations.Param;

import java.util.List;

/**
 * Mapper接口
 * @author 自动工具
 */
public interface FncContractManagementMapper extends BaseMapper<FncContractManagement> {

    /**
     * 连表查询 (其它表的条件)
     * @author Frank.Tang
     * @return *
     */
    List<FncContractManagement> selectWithTableJoin(FncContractManagementQueryVo queryVo);

    /**
     * 获取租赁结束日期超过三天且没有处理过收车工单的合同
     * @param state
     * @return
     */
    List<FncContractManagement> selectRentTimeAndTurnerNo(@Param("state") Integer state,
                                                          @Param("dayOne") Integer dayOne);

    /**
     * 根据逾期天数获取账单
     */
    List<ManagementRiskDto> getOverdue(@Param("day") Integer day);

    /**
     * 天眼1.1, 查询合同对应的租金金额
     * @author Frank.Tang
     * @return <合同id, 金额>
     */
    List<ContractAnalysisDto> selectAllStartedContractWithRentAmount();

    /**测试用*/
    List<ContractAnalysisDto> selectAllStartedContractWithRentAmountTest(@Param("start") int start, @Param("size") int size);

    /**
     * 新合同分页接口
     * @param queryVo
     * @return
     */
    List<FncContractManagement> getPage(FncContractManagementQueryVo queryVo);

    /**
     * 查询审批中或者执行中的合同
     * @param queryVo
     * @return
     */
    List<FncContractManagement> leasePage(FncContractManagementQueryVo queryVo);
}
