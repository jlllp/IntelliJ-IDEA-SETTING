package com.mrk.finance.query;
import com.mrk.common.utils.text.CheckUtil;

/**
 * @author 自动生成工具
 * @date   2021/12/09 
 */
public class FncContractAdditionQuery {
	private String updateuserNotLike;
	private java.util.List updateuserNotIn;
	private String updateuserNotEqualTo;
	private String updateuserLike;
	private String updateuserLessThanOrEqualTo;
	private String updateuserLessThan;
	private Boolean updateuserIsNull;
	private Boolean updateuserIsNotNull;
	private java.util.List updateuserIn;
	private String updateuserGreaterThanOrEqualTo;
	private String updateuserGreaterThan;
	private String updateuserEqualTo;
	private java.util.List updatetimeNotIn;
	private java.util.Date updatetimeNotEqualTo;
	private java.util.Date updatetimeLessThanOrEqualTo;
	private java.util.Date updatetimeLessThan;
	private Boolean updatetimeIsNull;
	private Boolean updatetimeIsNotNull;
	private java.util.List updatetimeIn;
	private java.util.Date updatetimeGreaterThanOrEqualTo;
	private java.util.Date updatetimeGreaterThan;
	private java.util.Date updatetimeEqualTo;
	private String remarkNotLike;
	private java.util.List remarkNotIn;
	private String remarkNotEqualTo;
	private String remarkLike;
	private String remarkLessThanOrEqualTo;
	private String remarkLessThan;
	private Boolean remarkIsNull;
	private Boolean remarkIsNotNull;
	private java.util.List remarkIn;
	private String remarkGreaterThanOrEqualTo;
	private String remarkGreaterThan;
	private String remarkEqualTo;
	private java.util.List fcaTypeNotIn;
	private Integer fcaTypeNotEqualTo;
	private Integer fcaTypeLessThanOrEqualTo;
	private Integer fcaTypeLessThan;
	private Boolean fcaTypeIsNull;
	private Boolean fcaTypeIsNotNull;
	private java.util.List fcaTypeIn;
	private Integer fcaTypeGreaterThanOrEqualTo;
	private Integer fcaTypeGreaterThan;
	private Integer fcaTypeEqualTo;
	private java.util.List fcaPayTypeNotIn;
	private Integer fcaPayTypeNotEqualTo;
	private Integer fcaPayTypeLessThanOrEqualTo;
	private Integer fcaPayTypeLessThan;
	private Boolean fcaPayTypeIsNull;
	private Boolean fcaPayTypeIsNotNull;
	private java.util.List fcaPayTypeIn;
	private Integer fcaPayTypeGreaterThanOrEqualTo;
	private Integer fcaPayTypeGreaterThan;
	private Integer fcaPayTypeEqualTo;
	private java.util.List fcaOldCarReturnDateNotIn;
	private java.util.Date fcaOldCarReturnDateNotEqualTo;
	private java.util.Date fcaOldCarReturnDateLessThanOrEqualTo;
	private java.util.Date fcaOldCarReturnDateLessThan;
	private Boolean fcaOldCarReturnDateIsNull;
	private Boolean fcaOldCarReturnDateIsNotNull;
	private java.util.List fcaOldCarReturnDateIn;
	private java.util.Date fcaOldCarReturnDateGreaterThanOrEqualTo;
	private java.util.Date fcaOldCarReturnDateGreaterThan;
	private java.util.Date fcaOldCarReturnDateEqualTo;
	private java.util.List fcaNewHandoverDateNotIn;
	private java.util.Date fcaNewHandoverDateNotEqualTo;
	private java.util.Date fcaNewHandoverDateLessThanOrEqualTo;
	private java.util.Date fcaNewHandoverDateLessThan;
	private Boolean fcaNewHandoverDateIsNull;
	private Boolean fcaNewHandoverDateIsNotNull;
	private java.util.List fcaNewHandoverDateIn;
	private java.util.Date fcaNewHandoverDateGreaterThanOrEqualTo;
	private java.util.Date fcaNewHandoverDateGreaterThan;
	private java.util.Date fcaNewHandoverDateEqualTo;
	private String fcaNewCarPlateNumNotLike;
	private java.util.List fcaNewCarPlateNumNotIn;
	private String fcaNewCarPlateNumNotEqualTo;
	private String fcaNewCarPlateNumLike;
	private String fcaNewCarPlateNumLessThanOrEqualTo;
	private String fcaNewCarPlateNumLessThan;
	private Boolean fcaNewCarPlateNumIsNull;
	private Boolean fcaNewCarPlateNumIsNotNull;
	private java.util.List fcaNewCarPlateNumIn;
	private String fcaNewCarPlateNumGreaterThanOrEqualTo;
	private String fcaNewCarPlateNumGreaterThan;
	private String fcaNewCarPlateNumEqualTo;
	private java.util.List fcaLeaseEndDateNotIn;
	private java.util.Date fcaLeaseEndDateNotEqualTo;
	private java.util.Date fcaLeaseEndDateLessThanOrEqualTo;
	private java.util.Date fcaLeaseEndDateLessThan;
	private Boolean fcaLeaseEndDateIsNull;
	private Boolean fcaLeaseEndDateIsNotNull;
	private java.util.List fcaLeaseEndDateIn;
	private java.util.Date fcaLeaseEndDateGreaterThanOrEqualTo;
	private java.util.Date fcaLeaseEndDateGreaterThan;
	private java.util.Date fcaLeaseEndDateEqualTo;
	private java.util.List fcaInformationFeeNotIn;
	private Double fcaInformationFeeNotEqualTo;
	private Double fcaInformationFeeLessThanOrEqualTo;
	private Double fcaInformationFeeLessThan;
	private Boolean fcaInformationFeeIsNull;
	private Boolean fcaInformationFeeIsNotNull;
	private java.util.List fcaInformationFeeIn;
	private Double fcaInformationFeeGreaterThanOrEqualTo;
	private Double fcaInformationFeeGreaterThan;
	private Double fcaInformationFeeEqualTo;
	private java.util.List fcaIdNotIn;
	private Long fcaIdNotEqualTo;
	private Long fcaIdLessThanOrEqualTo;
	private Long fcaIdLessThan;
	private Boolean fcaIdIsNull;
	private Boolean fcaIdIsNotNull;
	private java.util.List fcaIdIn;
	private Long fcaIdGreaterThanOrEqualTo;
	private Long fcaIdGreaterThan;
	private Long fcaIdEqualTo;
	private java.util.List fcaContractTerminateDateNotIn;
	private java.util.Date fcaContractTerminateDateNotEqualTo;
	private java.util.Date fcaContractTerminateDateLessThanOrEqualTo;
	private java.util.Date fcaContractTerminateDateLessThan;
	private Boolean fcaContractTerminateDateIsNull;
	private Boolean fcaContractTerminateDateIsNotNull;
	private java.util.List fcaContractTerminateDateIn;
	private java.util.Date fcaContractTerminateDateGreaterThanOrEqualTo;
	private java.util.Date fcaContractTerminateDateGreaterThan;
	private java.util.Date fcaContractTerminateDateEqualTo;
	private String fcaContractNoNotLike;
	private java.util.List fcaContractNoNotIn;
	private String fcaContractNoNotEqualTo;
	private String fcaContractNoLike;
	private String fcaContractNoLessThanOrEqualTo;
	private String fcaContractNoLessThan;
	private Boolean fcaContractNoIsNull;
	private Boolean fcaContractNoIsNotNull;
	private java.util.List fcaContractNoIn;
	private String fcaContractNoGreaterThanOrEqualTo;
	private String fcaContractNoGreaterThan;
	private String fcaContractNoEqualTo;
	private java.util.List fcaContractIdNotIn;
	private Long fcaContractIdNotEqualTo;
	private Long fcaContractIdLessThanOrEqualTo;
	private Long fcaContractIdLessThan;
	private Boolean fcaContractIdIsNull;
	private Boolean fcaContractIdIsNotNull;
	private java.util.List fcaContractIdIn;
	private Long fcaContractIdGreaterThanOrEqualTo;
	private Long fcaContractIdGreaterThan;
	private Long fcaContractIdEqualTo;
	private String fcaAssociateContractNoNotLike;
	private java.util.List fcaAssociateContractNoNotIn;
	private String fcaAssociateContractNoNotEqualTo;
	private String fcaAssociateContractNoLike;
	private String fcaAssociateContractNoLessThanOrEqualTo;
	private String fcaAssociateContractNoLessThan;
	private Boolean fcaAssociateContractNoIsNull;
	private Boolean fcaAssociateContractNoIsNotNull;
	private java.util.List fcaAssociateContractNoIn;
	private String fcaAssociateContractNoGreaterThanOrEqualTo;
	private String fcaAssociateContractNoGreaterThan;
	private String fcaAssociateContractNoEqualTo;
	private java.util.List drNotIn;
	private Integer drNotEqualTo;
	private Integer drLessThanOrEqualTo;
	private Integer drLessThan;
	private Boolean drIsNull;
	private Boolean drIsNotNull;
	private java.util.List drIn;
	private Integer drGreaterThanOrEqualTo;
	private Integer drGreaterThan;
	private Integer drEqualTo;
	private String createuserNotLike;
	private java.util.List createuserNotIn;
	private String createuserNotEqualTo;
	private String createuserLike;
	private String createuserLessThanOrEqualTo;
	private String createuserLessThan;
	private Boolean createuserIsNull;
	private Boolean createuserIsNotNull;
	private java.util.List createuserIn;
	private String createuserGreaterThanOrEqualTo;
	private String createuserGreaterThan;
	private String createuserEqualTo;
	private java.util.List createtimeNotIn;
	private java.util.Date createtimeNotEqualTo;
	private java.util.Date createtimeLessThanOrEqualTo;
	private java.util.Date createtimeLessThan;
	private Boolean createtimeIsNull;
	private Boolean createtimeIsNotNull;
	private java.util.List createtimeIn;
	private java.util.Date createtimeGreaterThanOrEqualTo;
	private java.util.Date createtimeGreaterThan;
	private java.util.Date createtimeEqualTo;
	private String sidx;
	private String sord;
	public String getSidx(){
		if(this.sidx == null){
			return "";
		}
		else if("updateuser".equals(this.sidx)){
			return "updateuser";
		}
		else if("updatetime".equals(this.sidx)){
			return "updatetime";
		}
		else if("remark".equals(this.sidx)){
			return "remark";
		}
		else if("fcaType".equals(this.sidx)){
			return "fca_type";
		}
		else if("fcaPayType".equals(this.sidx)){
			return "fca_pay_type";
		}
		else if("fcaOldCarReturnDate".equals(this.sidx)){
			return "fca_old_car_return_date";
		}
		else if("fcaNewHoverDate".equals(this.sidx)){
			return "fca_new_hover_date";
		}
		else if("fcaNewCarPlateNum".equals(this.sidx)){
			return "fca_new_car_plate_num";
		}
		else if("fcaLeaseDate".equals(this.sidx)){
			return "fca_lease_date";
		}
		else if("fcaformationFeeIn".equals(this.sidx)){
			return "fcaformation_fee_in";
		}
		else if("fcaformationFee".equals(this.sidx)){
			return "fcaformation_fee";
		}
		else if("fcaId".equals(this.sidx)){
			return "fca_id";
		}
		else if("fcaContractTerminateDate".equals(this.sidx)){
			return "fca_contract_terminate_date";
		}
		else if("fcaContractNo".equals(this.sidx)){
			return "fca_contract_no";
		}
		else if("fcaContractId".equals(this.sidx)){
			return "fca_contract_id";
		}
		else if("fcaAssociateContractNo".equals(this.sidx)){
			return "fca_associate_contract_no";
		}
		else if("dr".equals(this.sidx)){
			return "dr";
		}
		else if("createuser".equals(this.sidx)){
			return "createuser";
		}
		else if("createtime".equals(this.sidx)){
			return "createtime";
		}
		return this.sidx;
	}

	@com.fasterxml.jackson.annotation.JsonIgnore
	public com.mrk.finance.example.FncContractAdditionExample getCrieria(){
		com.mrk.finance.example.FncContractAdditionExample q = new com.mrk.finance.example.FncContractAdditionExample();
		com.mrk.finance.example.FncContractAdditionExample.Criteria c = q.createCriteria();
		c.andDrEqualTo(0);
		if(CheckUtil.isNotEmpty(getUpdateuserNotLike())){
			c.andUpdateuserNotLike("%"+this.getUpdateuserNotLike()+"%");
		}
		if(CheckUtil.isNotEmpty(getUpdateuserNotIn())){
			c.andUpdateuserNotIn(this.getUpdateuserNotIn());
		}
		if(CheckUtil.isNotEmpty(getUpdateuserNotEqualTo())){
			c.andUpdateuserNotEqualTo(this.getUpdateuserNotEqualTo());
		}
		if(CheckUtil.isNotEmpty(getUpdateuserLike())){
			c.andUpdateuserLike("%"+this.getUpdateuserLike()+"%");
		}
		if(CheckUtil.isNotEmpty(getUpdateuserLessThanOrEqualTo())){
			c.andUpdateuserLessThanOrEqualTo(this.getUpdateuserLessThanOrEqualTo());
		}
		if(CheckUtil.isNotEmpty(getUpdateuserLessThan())){
			c.andUpdateuserLessThan(this.getUpdateuserLessThan());
		}
		if(CheckUtil.isNotEmpty(getUpdateuserIsNull()) && this.getUpdateuserIsNull()){
			c.andUpdateuserIsNull();
		}
		if(CheckUtil.isNotEmpty(getUpdateuserIsNotNull()) && this.getUpdateuserIsNotNull()){
			c.andUpdateuserIsNotNull();
		}
		if(CheckUtil.isNotEmpty(getUpdateuserIn())){
			c.andUpdateuserIn(this.getUpdateuserIn());
		}
		if(CheckUtil.isNotEmpty(getUpdateuserGreaterThanOrEqualTo())){
			c.andUpdateuserGreaterThanOrEqualTo(this.getUpdateuserGreaterThanOrEqualTo());
		}
		if(CheckUtil.isNotEmpty(getUpdateuserGreaterThan())){
			c.andUpdateuserGreaterThan(this.getUpdateuserGreaterThan());
		}
		if(CheckUtil.isNotEmpty(getUpdateuserEqualTo())){
			c.andUpdateuserEqualTo(this.getUpdateuserEqualTo());
		}
		if(CheckUtil.isNotEmpty(getUpdatetimeNotIn())){
			c.andUpdatetimeNotIn(this.getUpdatetimeNotIn());
		}
		if(CheckUtil.isNotEmpty(getUpdatetimeNotEqualTo())){
			c.andUpdatetimeNotEqualTo(this.getUpdatetimeNotEqualTo());
		}
		if(CheckUtil.isNotEmpty(getUpdatetimeLessThanOrEqualTo())){
			c.andUpdatetimeLessThanOrEqualTo(this.getUpdatetimeLessThanOrEqualTo());
		}
		if(CheckUtil.isNotEmpty(getUpdatetimeLessThan())){
			c.andUpdatetimeLessThan(this.getUpdatetimeLessThan());
		}
		if(CheckUtil.isNotEmpty(getUpdatetimeIsNull()) && this.getUpdatetimeIsNull()){
			c.andUpdatetimeIsNull();
		}
		if(CheckUtil.isNotEmpty(getUpdatetimeIsNotNull()) && this.getUpdatetimeIsNotNull()){
			c.andUpdatetimeIsNotNull();
		}
		if(CheckUtil.isNotEmpty(getUpdatetimeIn())){
			c.andUpdatetimeIn(this.getUpdatetimeIn());
		}
		if(CheckUtil.isNotEmpty(getUpdatetimeGreaterThanOrEqualTo())){
			c.andUpdatetimeGreaterThanOrEqualTo(this.getUpdatetimeGreaterThanOrEqualTo());
		}
		if(CheckUtil.isNotEmpty(getUpdatetimeGreaterThan())){
			c.andUpdatetimeGreaterThan(this.getUpdatetimeGreaterThan());
		}
		if(CheckUtil.isNotEmpty(getUpdatetimeEqualTo())){
			c.andUpdatetimeEqualTo(this.getUpdatetimeEqualTo());
		}
		if(CheckUtil.isNotEmpty(getRemarkNotLike())){
			c.andRemarkNotLike("%"+this.getRemarkNotLike()+"%");
		}
		if(CheckUtil.isNotEmpty(getRemarkNotIn())){
			c.andRemarkNotIn(this.getRemarkNotIn());
		}
		if(CheckUtil.isNotEmpty(getRemarkNotEqualTo())){
			c.andRemarkNotEqualTo(this.getRemarkNotEqualTo());
		}
		if(CheckUtil.isNotEmpty(getRemarkLike())){
			c.andRemarkLike("%"+this.getRemarkLike()+"%");
		}
		if(CheckUtil.isNotEmpty(getRemarkLessThanOrEqualTo())){
			c.andRemarkLessThanOrEqualTo(this.getRemarkLessThanOrEqualTo());
		}
		if(CheckUtil.isNotEmpty(getRemarkLessThan())){
			c.andRemarkLessThan(this.getRemarkLessThan());
		}
		if(CheckUtil.isNotEmpty(getRemarkIsNull()) && this.getRemarkIsNull()){
			c.andRemarkIsNull();
		}
		if(CheckUtil.isNotEmpty(getRemarkIsNotNull()) && this.getRemarkIsNotNull()){
			c.andRemarkIsNotNull();
		}
		if(CheckUtil.isNotEmpty(getRemarkIn())){
			c.andRemarkIn(this.getRemarkIn());
		}
		if(CheckUtil.isNotEmpty(getRemarkGreaterThanOrEqualTo())){
			c.andRemarkGreaterThanOrEqualTo(this.getRemarkGreaterThanOrEqualTo());
		}
		if(CheckUtil.isNotEmpty(getRemarkGreaterThan())){
			c.andRemarkGreaterThan(this.getRemarkGreaterThan());
		}
		if(CheckUtil.isNotEmpty(getRemarkEqualTo())){
			c.andRemarkEqualTo(this.getRemarkEqualTo());
		}
		if(CheckUtil.isNotEmpty(getFcaTypeNotIn())){
			c.andFcaTypeNotIn(this.getFcaTypeNotIn());
		}
		if(CheckUtil.isNotEmpty(getFcaTypeNotEqualTo())){
			c.andFcaTypeNotEqualTo(this.getFcaTypeNotEqualTo());
		}
		if(CheckUtil.isNotEmpty(getFcaTypeLessThanOrEqualTo())){
			c.andFcaTypeLessThanOrEqualTo(this.getFcaTypeLessThanOrEqualTo());
		}
		if(CheckUtil.isNotEmpty(getFcaTypeLessThan())){
			c.andFcaTypeLessThan(this.getFcaTypeLessThan());
		}
		if(CheckUtil.isNotEmpty(getFcaTypeIsNull()) && this.getFcaTypeIsNull()){
			c.andFcaTypeIsNull();
		}
		if(CheckUtil.isNotEmpty(getFcaTypeIsNotNull()) && this.getFcaTypeIsNotNull()){
			c.andFcaTypeIsNotNull();
		}
		if(CheckUtil.isNotEmpty(getFcaTypeIn())){
			c.andFcaTypeIn(this.getFcaTypeIn());
		}
		if(CheckUtil.isNotEmpty(getFcaTypeGreaterThanOrEqualTo())){
			c.andFcaTypeGreaterThanOrEqualTo(this.getFcaTypeGreaterThanOrEqualTo());
		}
		if(CheckUtil.isNotEmpty(getFcaTypeGreaterThan())){
			c.andFcaTypeGreaterThan(this.getFcaTypeGreaterThan());
		}
		if(CheckUtil.isNotEmpty(getFcaTypeEqualTo())){
			c.andFcaTypeEqualTo(this.getFcaTypeEqualTo());
		}
		if(CheckUtil.isNotEmpty(getFcaPayTypeNotIn())){
			c.andFcaPayTypeNotIn(this.getFcaPayTypeNotIn());
		}
		if(CheckUtil.isNotEmpty(getFcaPayTypeNotEqualTo())){
			c.andFcaPayTypeNotEqualTo(this.getFcaPayTypeNotEqualTo());
		}
		if(CheckUtil.isNotEmpty(getFcaPayTypeLessThanOrEqualTo())){
			c.andFcaPayTypeLessThanOrEqualTo(this.getFcaPayTypeLessThanOrEqualTo());
		}
		if(CheckUtil.isNotEmpty(getFcaPayTypeLessThan())){
			c.andFcaPayTypeLessThan(this.getFcaPayTypeLessThan());
		}
		if(CheckUtil.isNotEmpty(getFcaPayTypeIsNull()) && this.getFcaPayTypeIsNull()){
			c.andFcaPayTypeIsNull();
		}
		if(CheckUtil.isNotEmpty(getFcaPayTypeIsNotNull()) && this.getFcaPayTypeIsNotNull()){
			c.andFcaPayTypeIsNotNull();
		}
		if(CheckUtil.isNotEmpty(getFcaPayTypeIn())){
			c.andFcaPayTypeIn(this.getFcaPayTypeIn());
		}
		if(CheckUtil.isNotEmpty(getFcaPayTypeGreaterThanOrEqualTo())){
			c.andFcaPayTypeGreaterThanOrEqualTo(this.getFcaPayTypeGreaterThanOrEqualTo());
		}
		if(CheckUtil.isNotEmpty(getFcaPayTypeGreaterThan())){
			c.andFcaPayTypeGreaterThan(this.getFcaPayTypeGreaterThan());
		}
		if(CheckUtil.isNotEmpty(getFcaPayTypeEqualTo())){
			c.andFcaPayTypeEqualTo(this.getFcaPayTypeEqualTo());
		}
		if(CheckUtil.isNotEmpty(getFcaOldCarReturnDateNotIn())){
			c.andFcaOldCarReturnDateNotIn(this.getFcaOldCarReturnDateNotIn());
		}
		if(CheckUtil.isNotEmpty(getFcaOldCarReturnDateNotEqualTo())){
			c.andFcaOldCarReturnDateNotEqualTo(this.getFcaOldCarReturnDateNotEqualTo());
		}
		if(CheckUtil.isNotEmpty(getFcaOldCarReturnDateLessThanOrEqualTo())){
			c.andFcaOldCarReturnDateLessThanOrEqualTo(this.getFcaOldCarReturnDateLessThanOrEqualTo());
		}
		if(CheckUtil.isNotEmpty(getFcaOldCarReturnDateLessThan())){
			c.andFcaOldCarReturnDateLessThan(this.getFcaOldCarReturnDateLessThan());
		}
		if(CheckUtil.isNotEmpty(getFcaOldCarReturnDateIsNull()) && this.getFcaOldCarReturnDateIsNull()){
			c.andFcaOldCarReturnDateIsNull();
		}
		if(CheckUtil.isNotEmpty(getFcaOldCarReturnDateIsNotNull()) && this.getFcaOldCarReturnDateIsNotNull()){
			c.andFcaOldCarReturnDateIsNotNull();
		}
		if(CheckUtil.isNotEmpty(getFcaOldCarReturnDateIn())){
			c.andFcaOldCarReturnDateIn(this.getFcaOldCarReturnDateIn());
		}
		if(CheckUtil.isNotEmpty(getFcaOldCarReturnDateGreaterThanOrEqualTo())){
			c.andFcaOldCarReturnDateGreaterThanOrEqualTo(this.getFcaOldCarReturnDateGreaterThanOrEqualTo());
		}
		if(CheckUtil.isNotEmpty(getFcaOldCarReturnDateGreaterThan())){
			c.andFcaOldCarReturnDateGreaterThan(this.getFcaOldCarReturnDateGreaterThan());
		}
		if(CheckUtil.isNotEmpty(getFcaOldCarReturnDateEqualTo())){
			c.andFcaOldCarReturnDateEqualTo(this.getFcaOldCarReturnDateEqualTo());
		}
		if(CheckUtil.isNotEmpty(getFcaNewHandoverDateNotIn())){
			c.andFcaNewHandoverDateNotIn(this.getFcaNewHandoverDateNotIn());
		}
		if(CheckUtil.isNotEmpty(getFcaNewHandoverDateNotEqualTo())){
			c.andFcaNewHandoverDateNotEqualTo(this.getFcaNewHandoverDateNotEqualTo());
		}
		if(CheckUtil.isNotEmpty(getFcaNewHandoverDateLessThanOrEqualTo())){
			c.andFcaNewHandoverDateLessThanOrEqualTo(this.getFcaNewHandoverDateLessThanOrEqualTo());
		}
		if(CheckUtil.isNotEmpty(getFcaNewHandoverDateLessThan())){
			c.andFcaNewHandoverDateLessThan(this.getFcaNewHandoverDateLessThan());
		}
		if(CheckUtil.isNotEmpty(getFcaNewHandoverDateIsNull()) && this.getFcaNewHandoverDateIsNull()){
			c.andFcaNewHandoverDateIsNull();
		}
		if(CheckUtil.isNotEmpty(getFcaNewHandoverDateIsNotNull()) && this.getFcaNewHandoverDateIsNotNull()){
			c.andFcaNewHandoverDateIsNotNull();
		}
		if(CheckUtil.isNotEmpty(getFcaNewHandoverDateIn())){
			c.andFcaNewHandoverDateIn(this.getFcaNewHandoverDateIn());
		}
		if(CheckUtil.isNotEmpty(getFcaNewHandoverDateGreaterThanOrEqualTo())){
			c.andFcaNewHandoverDateGreaterThanOrEqualTo(this.getFcaNewHandoverDateGreaterThanOrEqualTo());
		}
		if(CheckUtil.isNotEmpty(getFcaNewHandoverDateGreaterThan())){
			c.andFcaNewHandoverDateGreaterThan(this.getFcaNewHandoverDateGreaterThan());
		}
		if(CheckUtil.isNotEmpty(getFcaNewHandoverDateEqualTo())){
			c.andFcaNewHandoverDateEqualTo(this.getFcaNewHandoverDateEqualTo());
		}
		if(CheckUtil.isNotEmpty(getFcaNewCarPlateNumNotLike())){
			c.andFcaNewCarPlateNumNotLike("%"+this.getFcaNewCarPlateNumNotLike()+"%");
		}
		if(CheckUtil.isNotEmpty(getFcaNewCarPlateNumNotIn())){
			c.andFcaNewCarPlateNumNotIn(this.getFcaNewCarPlateNumNotIn());
		}
		if(CheckUtil.isNotEmpty(getFcaNewCarPlateNumNotEqualTo())){
			c.andFcaNewCarPlateNumNotEqualTo(this.getFcaNewCarPlateNumNotEqualTo());
		}
		if(CheckUtil.isNotEmpty(getFcaNewCarPlateNumLike())){
			c.andFcaNewCarPlateNumLike("%"+this.getFcaNewCarPlateNumLike()+"%");
		}
		if(CheckUtil.isNotEmpty(getFcaNewCarPlateNumLessThanOrEqualTo())){
			c.andFcaNewCarPlateNumLessThanOrEqualTo(this.getFcaNewCarPlateNumLessThanOrEqualTo());
		}
		if(CheckUtil.isNotEmpty(getFcaNewCarPlateNumLessThan())){
			c.andFcaNewCarPlateNumLessThan(this.getFcaNewCarPlateNumLessThan());
		}
		if(CheckUtil.isNotEmpty(getFcaNewCarPlateNumIsNull()) && this.getFcaNewCarPlateNumIsNull()){
			c.andFcaNewCarPlateNumIsNull();
		}
		if(CheckUtil.isNotEmpty(getFcaNewCarPlateNumIsNotNull()) && this.getFcaNewCarPlateNumIsNotNull()){
			c.andFcaNewCarPlateNumIsNotNull();
		}
		if(CheckUtil.isNotEmpty(getFcaNewCarPlateNumIn())){
			c.andFcaNewCarPlateNumIn(this.getFcaNewCarPlateNumIn());
		}
		if(CheckUtil.isNotEmpty(getFcaNewCarPlateNumGreaterThanOrEqualTo())){
			c.andFcaNewCarPlateNumGreaterThanOrEqualTo(this.getFcaNewCarPlateNumGreaterThanOrEqualTo());
		}
		if(CheckUtil.isNotEmpty(getFcaNewCarPlateNumGreaterThan())){
			c.andFcaNewCarPlateNumGreaterThan(this.getFcaNewCarPlateNumGreaterThan());
		}
		if(CheckUtil.isNotEmpty(getFcaNewCarPlateNumEqualTo())){
			c.andFcaNewCarPlateNumEqualTo(this.getFcaNewCarPlateNumEqualTo());
		}
		if(CheckUtil.isNotEmpty(getFcaLeaseEndDateNotIn())){
			c.andFcaLeaseEndDateNotIn(this.getFcaLeaseEndDateNotIn());
		}
		if(CheckUtil.isNotEmpty(getFcaLeaseEndDateNotEqualTo())){
			c.andFcaLeaseEndDateNotEqualTo(this.getFcaLeaseEndDateNotEqualTo());
		}
		if(CheckUtil.isNotEmpty(getFcaLeaseEndDateLessThanOrEqualTo())){
			c.andFcaLeaseEndDateLessThanOrEqualTo(this.getFcaLeaseEndDateLessThanOrEqualTo());
		}
		if(CheckUtil.isNotEmpty(getFcaLeaseEndDateLessThan())){
			c.andFcaLeaseEndDateLessThan(this.getFcaLeaseEndDateLessThan());
		}
		if(CheckUtil.isNotEmpty(getFcaLeaseEndDateIsNull()) && this.getFcaLeaseEndDateIsNull()){
			c.andFcaLeaseEndDateIsNull();
		}
		if(CheckUtil.isNotEmpty(getFcaLeaseEndDateIsNotNull()) && this.getFcaLeaseEndDateIsNotNull()){
			c.andFcaLeaseEndDateIsNotNull();
		}
		if(CheckUtil.isNotEmpty(getFcaLeaseEndDateIn())){
			c.andFcaLeaseEndDateIn(this.getFcaLeaseEndDateIn());
		}
		if(CheckUtil.isNotEmpty(getFcaLeaseEndDateGreaterThanOrEqualTo())){
			c.andFcaLeaseEndDateGreaterThanOrEqualTo(this.getFcaLeaseEndDateGreaterThanOrEqualTo());
		}
		if(CheckUtil.isNotEmpty(getFcaLeaseEndDateGreaterThan())){
			c.andFcaLeaseEndDateGreaterThan(this.getFcaLeaseEndDateGreaterThan());
		}
		if(CheckUtil.isNotEmpty(getFcaLeaseEndDateEqualTo())){
			c.andFcaLeaseEndDateEqualTo(this.getFcaLeaseEndDateEqualTo());
		}
		if(CheckUtil.isNotEmpty(getFcaInformationFeeNotIn())){
			c.andFcaInformationFeeNotIn(this.getFcaInformationFeeNotIn());
		}
		if(CheckUtil.isNotEmpty(getFcaInformationFeeNotEqualTo())){
			c.andFcaInformationFeeNotEqualTo(this.getFcaInformationFeeNotEqualTo());
		}
		if(CheckUtil.isNotEmpty(getFcaInformationFeeLessThanOrEqualTo())){
			c.andFcaInformationFeeLessThanOrEqualTo(this.getFcaInformationFeeLessThanOrEqualTo());
		}
		if(CheckUtil.isNotEmpty(getFcaInformationFeeLessThan())){
			c.andFcaInformationFeeLessThan(this.getFcaInformationFeeLessThan());
		}
		if(CheckUtil.isNotEmpty(getFcaInformationFeeIsNull()) && this.getFcaInformationFeeIsNull()){
			c.andFcaInformationFeeIsNull();
		}
		if(CheckUtil.isNotEmpty(getFcaInformationFeeIsNotNull()) && this.getFcaInformationFeeIsNotNull()){
			c.andFcaInformationFeeIsNotNull();
		}
		if(CheckUtil.isNotEmpty(getFcaInformationFeeIn())){
			c.andFcaInformationFeeIn(this.getFcaInformationFeeIn());
		}
		if(CheckUtil.isNotEmpty(getFcaInformationFeeGreaterThanOrEqualTo())){
			c.andFcaInformationFeeGreaterThanOrEqualTo(this.getFcaInformationFeeGreaterThanOrEqualTo());
		}
		if(CheckUtil.isNotEmpty(getFcaInformationFeeGreaterThan())){
			c.andFcaInformationFeeGreaterThan(this.getFcaInformationFeeGreaterThan());
		}
		if(CheckUtil.isNotEmpty(getFcaInformationFeeEqualTo())){
			c.andFcaInformationFeeEqualTo(this.getFcaInformationFeeEqualTo());
		}
		if(CheckUtil.isNotEmpty(getFcaIdNotIn())){
			c.andFcaIdNotIn(this.getFcaIdNotIn());
		}
		if(CheckUtil.isNotEmpty(getFcaIdNotEqualTo())){
			c.andFcaIdNotEqualTo(this.getFcaIdNotEqualTo());
		}
		if(CheckUtil.isNotEmpty(getFcaIdLessThanOrEqualTo())){
			c.andFcaIdLessThanOrEqualTo(this.getFcaIdLessThanOrEqualTo());
		}
		if(CheckUtil.isNotEmpty(getFcaIdLessThan())){
			c.andFcaIdLessThan(this.getFcaIdLessThan());
		}
		if(CheckUtil.isNotEmpty(getFcaIdIsNull()) && this.getFcaIdIsNull()){
			c.andFcaIdIsNull();
		}
		if(CheckUtil.isNotEmpty(getFcaIdIsNotNull()) && this.getFcaIdIsNotNull()){
			c.andFcaIdIsNotNull();
		}
		if(CheckUtil.isNotEmpty(getFcaIdIn())){
			c.andFcaIdIn(this.getFcaIdIn());
		}
		if(CheckUtil.isNotEmpty(getFcaIdGreaterThanOrEqualTo())){
			c.andFcaIdGreaterThanOrEqualTo(this.getFcaIdGreaterThanOrEqualTo());
		}
		if(CheckUtil.isNotEmpty(getFcaIdGreaterThan())){
			c.andFcaIdGreaterThan(this.getFcaIdGreaterThan());
		}
		if(CheckUtil.isNotEmpty(getFcaIdEqualTo())){
			c.andFcaIdEqualTo(this.getFcaIdEqualTo());
		}
		if(CheckUtil.isNotEmpty(getFcaContractTerminateDateNotIn())){
			c.andFcaContractTerminateDateNotIn(this.getFcaContractTerminateDateNotIn());
		}
		if(CheckUtil.isNotEmpty(getFcaContractTerminateDateNotEqualTo())){
			c.andFcaContractTerminateDateNotEqualTo(this.getFcaContractTerminateDateNotEqualTo());
		}
		if(CheckUtil.isNotEmpty(getFcaContractTerminateDateLessThanOrEqualTo())){
			c.andFcaContractTerminateDateLessThanOrEqualTo(this.getFcaContractTerminateDateLessThanOrEqualTo());
		}
		if(CheckUtil.isNotEmpty(getFcaContractTerminateDateLessThan())){
			c.andFcaContractTerminateDateLessThan(this.getFcaContractTerminateDateLessThan());
		}
		if(CheckUtil.isNotEmpty(getFcaContractTerminateDateIsNull()) && this.getFcaContractTerminateDateIsNull()){
			c.andFcaContractTerminateDateIsNull();
		}
		if(CheckUtil.isNotEmpty(getFcaContractTerminateDateIsNotNull()) && this.getFcaContractTerminateDateIsNotNull()){
			c.andFcaContractTerminateDateIsNotNull();
		}
		if(CheckUtil.isNotEmpty(getFcaContractTerminateDateIn())){
			c.andFcaContractTerminateDateIn(this.getFcaContractTerminateDateIn());
		}
		if(CheckUtil.isNotEmpty(getFcaContractTerminateDateGreaterThanOrEqualTo())){
			c.andFcaContractTerminateDateGreaterThanOrEqualTo(this.getFcaContractTerminateDateGreaterThanOrEqualTo());
		}
		if(CheckUtil.isNotEmpty(getFcaContractTerminateDateGreaterThan())){
			c.andFcaContractTerminateDateGreaterThan(this.getFcaContractTerminateDateGreaterThan());
		}
		if(CheckUtil.isNotEmpty(getFcaContractTerminateDateEqualTo())){
			c.andFcaContractTerminateDateEqualTo(this.getFcaContractTerminateDateEqualTo());
		}
		if(CheckUtil.isNotEmpty(getFcaContractNoNotLike())){
			c.andFcaContractNoNotLike("%"+this.getFcaContractNoNotLike()+"%");
		}
		if(CheckUtil.isNotEmpty(getFcaContractNoNotIn())){
			c.andFcaContractNoNotIn(this.getFcaContractNoNotIn());
		}
		if(CheckUtil.isNotEmpty(getFcaContractNoNotEqualTo())){
			c.andFcaContractNoNotEqualTo(this.getFcaContractNoNotEqualTo());
		}
		if(CheckUtil.isNotEmpty(getFcaContractNoLike())){
			c.andFcaContractNoLike("%"+this.getFcaContractNoLike()+"%");
		}
		if(CheckUtil.isNotEmpty(getFcaContractNoLessThanOrEqualTo())){
			c.andFcaContractNoLessThanOrEqualTo(this.getFcaContractNoLessThanOrEqualTo());
		}
		if(CheckUtil.isNotEmpty(getFcaContractNoLessThan())){
			c.andFcaContractNoLessThan(this.getFcaContractNoLessThan());
		}
		if(CheckUtil.isNotEmpty(getFcaContractNoIsNull()) && this.getFcaContractNoIsNull()){
			c.andFcaContractNoIsNull();
		}
		if(CheckUtil.isNotEmpty(getFcaContractNoIsNotNull()) && this.getFcaContractNoIsNotNull()){
			c.andFcaContractNoIsNotNull();
		}
		if(CheckUtil.isNotEmpty(getFcaContractNoIn())){
			c.andFcaContractNoIn(this.getFcaContractNoIn());
		}
		if(CheckUtil.isNotEmpty(getFcaContractNoGreaterThanOrEqualTo())){
			c.andFcaContractNoGreaterThanOrEqualTo(this.getFcaContractNoGreaterThanOrEqualTo());
		}
		if(CheckUtil.isNotEmpty(getFcaContractNoGreaterThan())){
			c.andFcaContractNoGreaterThan(this.getFcaContractNoGreaterThan());
		}
		if(CheckUtil.isNotEmpty(getFcaContractNoEqualTo())){
			c.andFcaContractNoEqualTo(this.getFcaContractNoEqualTo());
		}
		if(CheckUtil.isNotEmpty(getFcaContractIdNotIn())){
			c.andFcaContractIdNotIn(this.getFcaContractIdNotIn());
		}
		if(CheckUtil.isNotEmpty(getFcaContractIdNotEqualTo())){
			c.andFcaContractIdNotEqualTo(this.getFcaContractIdNotEqualTo());
		}
		if(CheckUtil.isNotEmpty(getFcaContractIdLessThanOrEqualTo())){
			c.andFcaContractIdLessThanOrEqualTo(this.getFcaContractIdLessThanOrEqualTo());
		}
		if(CheckUtil.isNotEmpty(getFcaContractIdLessThan())){
			c.andFcaContractIdLessThan(this.getFcaContractIdLessThan());
		}
		if(CheckUtil.isNotEmpty(getFcaContractIdIsNull()) && this.getFcaContractIdIsNull()){
			c.andFcaContractIdIsNull();
		}
		if(CheckUtil.isNotEmpty(getFcaContractIdIsNotNull()) && this.getFcaContractIdIsNotNull()){
			c.andFcaContractIdIsNotNull();
		}
		if(CheckUtil.isNotEmpty(getFcaContractIdIn())){
			c.andFcaContractIdIn(this.getFcaContractIdIn());
		}
		if(CheckUtil.isNotEmpty(getFcaContractIdGreaterThanOrEqualTo())){
			c.andFcaContractIdGreaterThanOrEqualTo(this.getFcaContractIdGreaterThanOrEqualTo());
		}
		if(CheckUtil.isNotEmpty(getFcaContractIdGreaterThan())){
			c.andFcaContractIdGreaterThan(this.getFcaContractIdGreaterThan());
		}
		if(CheckUtil.isNotEmpty(getFcaContractIdEqualTo())){
			c.andFcaContractIdEqualTo(this.getFcaContractIdEqualTo());
		}
		if(CheckUtil.isNotEmpty(getFcaAssociateContractNoNotLike())){
			c.andFcaAssociateContractNoNotLike("%"+this.getFcaAssociateContractNoNotLike()+"%");
		}
		if(CheckUtil.isNotEmpty(getFcaAssociateContractNoNotIn())){
			c.andFcaAssociateContractNoNotIn(this.getFcaAssociateContractNoNotIn());
		}
		if(CheckUtil.isNotEmpty(getFcaAssociateContractNoNotEqualTo())){
			c.andFcaAssociateContractNoNotEqualTo(this.getFcaAssociateContractNoNotEqualTo());
		}
		if(CheckUtil.isNotEmpty(getFcaAssociateContractNoLike())){
			c.andFcaAssociateContractNoLike("%"+this.getFcaAssociateContractNoLike()+"%");
		}
		if(CheckUtil.isNotEmpty(getFcaAssociateContractNoLessThanOrEqualTo())){
			c.andFcaAssociateContractNoLessThanOrEqualTo(this.getFcaAssociateContractNoLessThanOrEqualTo());
		}
		if(CheckUtil.isNotEmpty(getFcaAssociateContractNoLessThan())){
			c.andFcaAssociateContractNoLessThan(this.getFcaAssociateContractNoLessThan());
		}
		if(CheckUtil.isNotEmpty(getFcaAssociateContractNoIsNull()) && this.getFcaAssociateContractNoIsNull()){
			c.andFcaAssociateContractNoIsNull();
		}
		if(CheckUtil.isNotEmpty(getFcaAssociateContractNoIsNotNull()) && this.getFcaAssociateContractNoIsNotNull()){
			c.andFcaAssociateContractNoIsNotNull();
		}
		if(CheckUtil.isNotEmpty(getFcaAssociateContractNoIn())){
			c.andFcaAssociateContractNoIn(this.getFcaAssociateContractNoIn());
		}
		if(CheckUtil.isNotEmpty(getFcaAssociateContractNoGreaterThanOrEqualTo())){
			c.andFcaAssociateContractNoGreaterThanOrEqualTo(this.getFcaAssociateContractNoGreaterThanOrEqualTo());
		}
		if(CheckUtil.isNotEmpty(getFcaAssociateContractNoGreaterThan())){
			c.andFcaAssociateContractNoGreaterThan(this.getFcaAssociateContractNoGreaterThan());
		}
		if(CheckUtil.isNotEmpty(getFcaAssociateContractNoEqualTo())){
			c.andFcaAssociateContractNoEqualTo(this.getFcaAssociateContractNoEqualTo());
		}
		if(CheckUtil.isNotEmpty(getDrNotIn())){
			c.andDrNotIn(this.getDrNotIn());
		}
		if(CheckUtil.isNotEmpty(getDrNotEqualTo())){
			c.andDrNotEqualTo(this.getDrNotEqualTo());
		}
		if(CheckUtil.isNotEmpty(getDrLessThanOrEqualTo())){
			c.andDrLessThanOrEqualTo(this.getDrLessThanOrEqualTo());
		}
		if(CheckUtil.isNotEmpty(getDrLessThan())){
			c.andDrLessThan(this.getDrLessThan());
		}
		if(CheckUtil.isNotEmpty(getDrIsNull()) && this.getDrIsNull()){
			c.andDrIsNull();
		}
		if(CheckUtil.isNotEmpty(getDrIsNotNull()) && this.getDrIsNotNull()){
			c.andDrIsNotNull();
		}
		if(CheckUtil.isNotEmpty(getDrIn())){
			c.andDrIn(this.getDrIn());
		}
		if(CheckUtil.isNotEmpty(getDrGreaterThanOrEqualTo())){
			c.andDrGreaterThanOrEqualTo(this.getDrGreaterThanOrEqualTo());
		}
		if(CheckUtil.isNotEmpty(getDrGreaterThan())){
			c.andDrGreaterThan(this.getDrGreaterThan());
		}
		if(CheckUtil.isNotEmpty(getDrEqualTo())){
			c.andDrEqualTo(this.getDrEqualTo());
		}
		if(CheckUtil.isNotEmpty(getCreateuserNotLike())){
			c.andCreateuserNotLike("%"+this.getCreateuserNotLike()+"%");
		}
		if(CheckUtil.isNotEmpty(getCreateuserNotIn())){
			c.andCreateuserNotIn(this.getCreateuserNotIn());
		}
		if(CheckUtil.isNotEmpty(getCreateuserNotEqualTo())){
			c.andCreateuserNotEqualTo(this.getCreateuserNotEqualTo());
		}
		if(CheckUtil.isNotEmpty(getCreateuserLike())){
			c.andCreateuserLike("%"+this.getCreateuserLike()+"%");
		}
		if(CheckUtil.isNotEmpty(getCreateuserLessThanOrEqualTo())){
			c.andCreateuserLessThanOrEqualTo(this.getCreateuserLessThanOrEqualTo());
		}
		if(CheckUtil.isNotEmpty(getCreateuserLessThan())){
			c.andCreateuserLessThan(this.getCreateuserLessThan());
		}
		if(CheckUtil.isNotEmpty(getCreateuserIsNull()) && this.getCreateuserIsNull()){
			c.andCreateuserIsNull();
		}
		if(CheckUtil.isNotEmpty(getCreateuserIsNotNull()) && this.getCreateuserIsNotNull()){
			c.andCreateuserIsNotNull();
		}
		if(CheckUtil.isNotEmpty(getCreateuserIn())){
			c.andCreateuserIn(this.getCreateuserIn());
		}
		if(CheckUtil.isNotEmpty(getCreateuserGreaterThanOrEqualTo())){
			c.andCreateuserGreaterThanOrEqualTo(this.getCreateuserGreaterThanOrEqualTo());
		}
		if(CheckUtil.isNotEmpty(getCreateuserGreaterThan())){
			c.andCreateuserGreaterThan(this.getCreateuserGreaterThan());
		}
		if(CheckUtil.isNotEmpty(getCreateuserEqualTo())){
			c.andCreateuserEqualTo(this.getCreateuserEqualTo());
		}
		if(CheckUtil.isNotEmpty(getCreatetimeNotIn())){
			c.andCreatetimeNotIn(this.getCreatetimeNotIn());
		}
		if(CheckUtil.isNotEmpty(getCreatetimeNotEqualTo())){
			c.andCreatetimeNotEqualTo(this.getCreatetimeNotEqualTo());
		}
		if(CheckUtil.isNotEmpty(getCreatetimeLessThanOrEqualTo())){
			c.andCreatetimeLessThanOrEqualTo(this.getCreatetimeLessThanOrEqualTo());
		}
		if(CheckUtil.isNotEmpty(getCreatetimeLessThan())){
			c.andCreatetimeLessThan(this.getCreatetimeLessThan());
		}
		if(CheckUtil.isNotEmpty(getCreatetimeIsNull()) && this.getCreatetimeIsNull()){
			c.andCreatetimeIsNull();
		}
		if(CheckUtil.isNotEmpty(getCreatetimeIsNotNull()) && this.getCreatetimeIsNotNull()){
			c.andCreatetimeIsNotNull();
		}
		if(CheckUtil.isNotEmpty(getCreatetimeIn())){
			c.andCreatetimeIn(this.getCreatetimeIn());
		}
		if(CheckUtil.isNotEmpty(getCreatetimeGreaterThanOrEqualTo())){
			c.andCreatetimeGreaterThanOrEqualTo(this.getCreatetimeGreaterThanOrEqualTo());
		}
		if(CheckUtil.isNotEmpty(getCreatetimeGreaterThan())){
			c.andCreatetimeGreaterThan(this.getCreatetimeGreaterThan());
		}
		if(CheckUtil.isNotEmpty(getCreatetimeEqualTo())){
			c.andCreatetimeEqualTo(this.getCreatetimeEqualTo());
		}
		if((this.getSidx()!=null && !this.getSidx().trim().equals("")) && this.getSord()!=null) {
			q.setOrderByClause(""+ this.getSidx()+" "+this.getSord());
		}
		return q;
	}
	public String getUpdateuserNotLike() {
		return updateuserNotLike;
	}
	public void setUpdateuserNotLike(String updateuserNotLike) {
		this.updateuserNotLike = updateuserNotLike;
	}

	public java.util.List getUpdateuserNotIn() {
		return updateuserNotIn;
	}
	public void setUpdateuserNotIn(java.util.List updateuserNotIn) {
		this.updateuserNotIn = updateuserNotIn;
	}

	public String getUpdateuserNotEqualTo() {
		return updateuserNotEqualTo;
	}
	public void setUpdateuserNotEqualTo(String updateuserNotEqualTo) {
		this.updateuserNotEqualTo = updateuserNotEqualTo;
	}

	public String getUpdateuserLike() {
		return updateuserLike;
	}
	public void setUpdateuserLike(String updateuserLike) {
		this.updateuserLike = updateuserLike;
	}

	public String getUpdateuserLessThanOrEqualTo() {
		return updateuserLessThanOrEqualTo;
	}
	public void setUpdateuserLessThanOrEqualTo(String updateuserLessThanOrEqualTo) {
		this.updateuserLessThanOrEqualTo = updateuserLessThanOrEqualTo;
	}

	public String getUpdateuserLessThan() {
		return updateuserLessThan;
	}
	public void setUpdateuserLessThan(String updateuserLessThan) {
		this.updateuserLessThan = updateuserLessThan;
	}

	public Boolean getUpdateuserIsNull() {
		return updateuserIsNull;
	}
	public void setUpdateuserIsNull(Boolean updateuserIsNull) {
		this.updateuserIsNull = updateuserIsNull;
	}

	public Boolean getUpdateuserIsNotNull() {
		return updateuserIsNotNull;
	}
	public void setUpdateuserIsNotNull(Boolean updateuserIsNotNull) {
		this.updateuserIsNotNull = updateuserIsNotNull;
	}

	public java.util.List getUpdateuserIn() {
		return updateuserIn;
	}
	public void setUpdateuserIn(java.util.List updateuserIn) {
		this.updateuserIn = updateuserIn;
	}

	public String getUpdateuserGreaterThanOrEqualTo() {
		return updateuserGreaterThanOrEqualTo;
	}
	public void setUpdateuserGreaterThanOrEqualTo(String updateuserGreaterThanOrEqualTo) {
		this.updateuserGreaterThanOrEqualTo = updateuserGreaterThanOrEqualTo;
	}

	public String getUpdateuserGreaterThan() {
		return updateuserGreaterThan;
	}
	public void setUpdateuserGreaterThan(String updateuserGreaterThan) {
		this.updateuserGreaterThan = updateuserGreaterThan;
	}

	public String getUpdateuserEqualTo() {
		return updateuserEqualTo;
	}
	public void setUpdateuserEqualTo(String updateuserEqualTo) {
		this.updateuserEqualTo = updateuserEqualTo;
	}

	public java.util.List getUpdatetimeNotIn() {
		return updatetimeNotIn;
	}
	public void setUpdatetimeNotIn(java.util.List updatetimeNotIn) {
		this.updatetimeNotIn = updatetimeNotIn;
	}

	public java.util.Date getUpdatetimeNotEqualTo() {
		return updatetimeNotEqualTo;
	}
	public void setUpdatetimeNotEqualTo(java.util.Date updatetimeNotEqualTo) {
		this.updatetimeNotEqualTo = updatetimeNotEqualTo;
	}

	public java.util.Date getUpdatetimeLessThanOrEqualTo() {
		return updatetimeLessThanOrEqualTo;
	}
	public void setUpdatetimeLessThanOrEqualTo(java.util.Date updatetimeLessThanOrEqualTo) {
		this.updatetimeLessThanOrEqualTo = updatetimeLessThanOrEqualTo;
	}

	public java.util.Date getUpdatetimeLessThan() {
		return updatetimeLessThan;
	}
	public void setUpdatetimeLessThan(java.util.Date updatetimeLessThan) {
		this.updatetimeLessThan = updatetimeLessThan;
	}

	public Boolean getUpdatetimeIsNull() {
		return updatetimeIsNull;
	}
	public void setUpdatetimeIsNull(Boolean updatetimeIsNull) {
		this.updatetimeIsNull = updatetimeIsNull;
	}

	public Boolean getUpdatetimeIsNotNull() {
		return updatetimeIsNotNull;
	}
	public void setUpdatetimeIsNotNull(Boolean updatetimeIsNotNull) {
		this.updatetimeIsNotNull = updatetimeIsNotNull;
	}

	public java.util.List getUpdatetimeIn() {
		return updatetimeIn;
	}
	public void setUpdatetimeIn(java.util.List updatetimeIn) {
		this.updatetimeIn = updatetimeIn;
	}

	public java.util.Date getUpdatetimeGreaterThanOrEqualTo() {
		return updatetimeGreaterThanOrEqualTo;
	}
	public void setUpdatetimeGreaterThanOrEqualTo(java.util.Date updatetimeGreaterThanOrEqualTo) {
		this.updatetimeGreaterThanOrEqualTo = updatetimeGreaterThanOrEqualTo;
	}

	public java.util.Date getUpdatetimeGreaterThan() {
		return updatetimeGreaterThan;
	}
	public void setUpdatetimeGreaterThan(java.util.Date updatetimeGreaterThan) {
		this.updatetimeGreaterThan = updatetimeGreaterThan;
	}

	public java.util.Date getUpdatetimeEqualTo() {
		return updatetimeEqualTo;
	}
	public void setUpdatetimeEqualTo(java.util.Date updatetimeEqualTo) {
		this.updatetimeEqualTo = updatetimeEqualTo;
	}

	public String getRemarkNotLike() {
		return remarkNotLike;
	}
	public void setRemarkNotLike(String remarkNotLike) {
		this.remarkNotLike = remarkNotLike;
	}

	public java.util.List getRemarkNotIn() {
		return remarkNotIn;
	}
	public void setRemarkNotIn(java.util.List remarkNotIn) {
		this.remarkNotIn = remarkNotIn;
	}

	public String getRemarkNotEqualTo() {
		return remarkNotEqualTo;
	}
	public void setRemarkNotEqualTo(String remarkNotEqualTo) {
		this.remarkNotEqualTo = remarkNotEqualTo;
	}

	public String getRemarkLike() {
		return remarkLike;
	}
	public void setRemarkLike(String remarkLike) {
		this.remarkLike = remarkLike;
	}

	public String getRemarkLessThanOrEqualTo() {
		return remarkLessThanOrEqualTo;
	}
	public void setRemarkLessThanOrEqualTo(String remarkLessThanOrEqualTo) {
		this.remarkLessThanOrEqualTo = remarkLessThanOrEqualTo;
	}

	public String getRemarkLessThan() {
		return remarkLessThan;
	}
	public void setRemarkLessThan(String remarkLessThan) {
		this.remarkLessThan = remarkLessThan;
	}

	public Boolean getRemarkIsNull() {
		return remarkIsNull;
	}
	public void setRemarkIsNull(Boolean remarkIsNull) {
		this.remarkIsNull = remarkIsNull;
	}

	public Boolean getRemarkIsNotNull() {
		return remarkIsNotNull;
	}
	public void setRemarkIsNotNull(Boolean remarkIsNotNull) {
		this.remarkIsNotNull = remarkIsNotNull;
	}

	public java.util.List getRemarkIn() {
		return remarkIn;
	}
	public void setRemarkIn(java.util.List remarkIn) {
		this.remarkIn = remarkIn;
	}

	public String getRemarkGreaterThanOrEqualTo() {
		return remarkGreaterThanOrEqualTo;
	}
	public void setRemarkGreaterThanOrEqualTo(String remarkGreaterThanOrEqualTo) {
		this.remarkGreaterThanOrEqualTo = remarkGreaterThanOrEqualTo;
	}

	public String getRemarkGreaterThan() {
		return remarkGreaterThan;
	}
	public void setRemarkGreaterThan(String remarkGreaterThan) {
		this.remarkGreaterThan = remarkGreaterThan;
	}

	public String getRemarkEqualTo() {
		return remarkEqualTo;
	}
	public void setRemarkEqualTo(String remarkEqualTo) {
		this.remarkEqualTo = remarkEqualTo;
	}

	public java.util.List getFcaTypeNotIn() {
		return fcaTypeNotIn;
	}
	public void setFcaTypeNotIn(java.util.List fcaTypeNotIn) {
		this.fcaTypeNotIn = fcaTypeNotIn;
	}

	public Integer getFcaTypeNotEqualTo() {
		return fcaTypeNotEqualTo;
	}
	public void setFcaTypeNotEqualTo(Integer fcaTypeNotEqualTo) {
		this.fcaTypeNotEqualTo = fcaTypeNotEqualTo;
	}

	public Integer getFcaTypeLessThanOrEqualTo() {
		return fcaTypeLessThanOrEqualTo;
	}
	public void setFcaTypeLessThanOrEqualTo(Integer fcaTypeLessThanOrEqualTo) {
		this.fcaTypeLessThanOrEqualTo = fcaTypeLessThanOrEqualTo;
	}

	public Integer getFcaTypeLessThan() {
		return fcaTypeLessThan;
	}
	public void setFcaTypeLessThan(Integer fcaTypeLessThan) {
		this.fcaTypeLessThan = fcaTypeLessThan;
	}

	public Boolean getFcaTypeIsNull() {
		return fcaTypeIsNull;
	}
	public void setFcaTypeIsNull(Boolean fcaTypeIsNull) {
		this.fcaTypeIsNull = fcaTypeIsNull;
	}

	public Boolean getFcaTypeIsNotNull() {
		return fcaTypeIsNotNull;
	}
	public void setFcaTypeIsNotNull(Boolean fcaTypeIsNotNull) {
		this.fcaTypeIsNotNull = fcaTypeIsNotNull;
	}

	public java.util.List getFcaTypeIn() {
		return fcaTypeIn;
	}
	public void setFcaTypeIn(java.util.List fcaTypeIn) {
		this.fcaTypeIn = fcaTypeIn;
	}

	public Integer getFcaTypeGreaterThanOrEqualTo() {
		return fcaTypeGreaterThanOrEqualTo;
	}
	public void setFcaTypeGreaterThanOrEqualTo(Integer fcaTypeGreaterThanOrEqualTo) {
		this.fcaTypeGreaterThanOrEqualTo = fcaTypeGreaterThanOrEqualTo;
	}

	public Integer getFcaTypeGreaterThan() {
		return fcaTypeGreaterThan;
	}
	public void setFcaTypeGreaterThan(Integer fcaTypeGreaterThan) {
		this.fcaTypeGreaterThan = fcaTypeGreaterThan;
	}

	public Integer getFcaTypeEqualTo() {
		return fcaTypeEqualTo;
	}
	public void setFcaTypeEqualTo(Integer fcaTypeEqualTo) {
		this.fcaTypeEqualTo = fcaTypeEqualTo;
	}

	public java.util.List getFcaPayTypeNotIn() {
		return fcaPayTypeNotIn;
	}
	public void setFcaPayTypeNotIn(java.util.List fcaPayTypeNotIn) {
		this.fcaPayTypeNotIn = fcaPayTypeNotIn;
	}

	public Integer getFcaPayTypeNotEqualTo() {
		return fcaPayTypeNotEqualTo;
	}
	public void setFcaPayTypeNotEqualTo(Integer fcaPayTypeNotEqualTo) {
		this.fcaPayTypeNotEqualTo = fcaPayTypeNotEqualTo;
	}

	public Integer getFcaPayTypeLessThanOrEqualTo() {
		return fcaPayTypeLessThanOrEqualTo;
	}
	public void setFcaPayTypeLessThanOrEqualTo(Integer fcaPayTypeLessThanOrEqualTo) {
		this.fcaPayTypeLessThanOrEqualTo = fcaPayTypeLessThanOrEqualTo;
	}

	public Integer getFcaPayTypeLessThan() {
		return fcaPayTypeLessThan;
	}
	public void setFcaPayTypeLessThan(Integer fcaPayTypeLessThan) {
		this.fcaPayTypeLessThan = fcaPayTypeLessThan;
	}

	public Boolean getFcaPayTypeIsNull() {
		return fcaPayTypeIsNull;
	}
	public void setFcaPayTypeIsNull(Boolean fcaPayTypeIsNull) {
		this.fcaPayTypeIsNull = fcaPayTypeIsNull;
	}

	public Boolean getFcaPayTypeIsNotNull() {
		return fcaPayTypeIsNotNull;
	}
	public void setFcaPayTypeIsNotNull(Boolean fcaPayTypeIsNotNull) {
		this.fcaPayTypeIsNotNull = fcaPayTypeIsNotNull;
	}

	public java.util.List getFcaPayTypeIn() {
		return fcaPayTypeIn;
	}
	public void setFcaPayTypeIn(java.util.List fcaPayTypeIn) {
		this.fcaPayTypeIn = fcaPayTypeIn;
	}

	public Integer getFcaPayTypeGreaterThanOrEqualTo() {
		return fcaPayTypeGreaterThanOrEqualTo;
	}
	public void setFcaPayTypeGreaterThanOrEqualTo(Integer fcaPayTypeGreaterThanOrEqualTo) {
		this.fcaPayTypeGreaterThanOrEqualTo = fcaPayTypeGreaterThanOrEqualTo;
	}

	public Integer getFcaPayTypeGreaterThan() {
		return fcaPayTypeGreaterThan;
	}
	public void setFcaPayTypeGreaterThan(Integer fcaPayTypeGreaterThan) {
		this.fcaPayTypeGreaterThan = fcaPayTypeGreaterThan;
	}

	public Integer getFcaPayTypeEqualTo() {
		return fcaPayTypeEqualTo;
	}
	public void setFcaPayTypeEqualTo(Integer fcaPayTypeEqualTo) {
		this.fcaPayTypeEqualTo = fcaPayTypeEqualTo;
	}

	public java.util.List getFcaOldCarReturnDateNotIn() {
		return fcaOldCarReturnDateNotIn;
	}
	public void setFcaOldCarReturnDateNotIn(java.util.List fcaOldCarReturnDateNotIn) {
		this.fcaOldCarReturnDateNotIn = fcaOldCarReturnDateNotIn;
	}

	public java.util.Date getFcaOldCarReturnDateNotEqualTo() {
		return fcaOldCarReturnDateNotEqualTo;
	}
	public void setFcaOldCarReturnDateNotEqualTo(java.util.Date fcaOldCarReturnDateNotEqualTo) {
		this.fcaOldCarReturnDateNotEqualTo = fcaOldCarReturnDateNotEqualTo;
	}

	public java.util.Date getFcaOldCarReturnDateLessThanOrEqualTo() {
		return fcaOldCarReturnDateLessThanOrEqualTo;
	}
	public void setFcaOldCarReturnDateLessThanOrEqualTo(java.util.Date fcaOldCarReturnDateLessThanOrEqualTo) {
		this.fcaOldCarReturnDateLessThanOrEqualTo = fcaOldCarReturnDateLessThanOrEqualTo;
	}

	public java.util.Date getFcaOldCarReturnDateLessThan() {
		return fcaOldCarReturnDateLessThan;
	}
	public void setFcaOldCarReturnDateLessThan(java.util.Date fcaOldCarReturnDateLessThan) {
		this.fcaOldCarReturnDateLessThan = fcaOldCarReturnDateLessThan;
	}

	public Boolean getFcaOldCarReturnDateIsNull() {
		return fcaOldCarReturnDateIsNull;
	}
	public void setFcaOldCarReturnDateIsNull(Boolean fcaOldCarReturnDateIsNull) {
		this.fcaOldCarReturnDateIsNull = fcaOldCarReturnDateIsNull;
	}

	public Boolean getFcaOldCarReturnDateIsNotNull() {
		return fcaOldCarReturnDateIsNotNull;
	}
	public void setFcaOldCarReturnDateIsNotNull(Boolean fcaOldCarReturnDateIsNotNull) {
		this.fcaOldCarReturnDateIsNotNull = fcaOldCarReturnDateIsNotNull;
	}

	public java.util.List getFcaOldCarReturnDateIn() {
		return fcaOldCarReturnDateIn;
	}
	public void setFcaOldCarReturnDateIn(java.util.List fcaOldCarReturnDateIn) {
		this.fcaOldCarReturnDateIn = fcaOldCarReturnDateIn;
	}

	public java.util.Date getFcaOldCarReturnDateGreaterThanOrEqualTo() {
		return fcaOldCarReturnDateGreaterThanOrEqualTo;
	}
	public void setFcaOldCarReturnDateGreaterThanOrEqualTo(java.util.Date fcaOldCarReturnDateGreaterThanOrEqualTo) {
		this.fcaOldCarReturnDateGreaterThanOrEqualTo = fcaOldCarReturnDateGreaterThanOrEqualTo;
	}

	public java.util.Date getFcaOldCarReturnDateGreaterThan() {
		return fcaOldCarReturnDateGreaterThan;
	}
	public void setFcaOldCarReturnDateGreaterThan(java.util.Date fcaOldCarReturnDateGreaterThan) {
		this.fcaOldCarReturnDateGreaterThan = fcaOldCarReturnDateGreaterThan;
	}

	public java.util.Date getFcaOldCarReturnDateEqualTo() {
		return fcaOldCarReturnDateEqualTo;
	}
	public void setFcaOldCarReturnDateEqualTo(java.util.Date fcaOldCarReturnDateEqualTo) {
		this.fcaOldCarReturnDateEqualTo = fcaOldCarReturnDateEqualTo;
	}

	public java.util.List getFcaNewHandoverDateNotIn() {
		return fcaNewHandoverDateNotIn;
	}
	public void setFcaNewHandoverDateNotIn(java.util.List fcaNewHandoverDateNotIn) {
		this.fcaNewHandoverDateNotIn = fcaNewHandoverDateNotIn;
	}

	public java.util.Date getFcaNewHandoverDateNotEqualTo() {
		return fcaNewHandoverDateNotEqualTo;
	}
	public void setFcaNewHandoverDateNotEqualTo(java.util.Date fcaNewHandoverDateNotEqualTo) {
		this.fcaNewHandoverDateNotEqualTo = fcaNewHandoverDateNotEqualTo;
	}

	public java.util.Date getFcaNewHandoverDateLessThanOrEqualTo() {
		return fcaNewHandoverDateLessThanOrEqualTo;
	}
	public void setFcaNewHandoverDateLessThanOrEqualTo(java.util.Date fcaNewHandoverDateLessThanOrEqualTo) {
		this.fcaNewHandoverDateLessThanOrEqualTo = fcaNewHandoverDateLessThanOrEqualTo;
	}

	public java.util.Date getFcaNewHandoverDateLessThan() {
		return fcaNewHandoverDateLessThan;
	}
	public void setFcaNewHandoverDateLessThan(java.util.Date fcaNewHandoverDateLessThan) {
		this.fcaNewHandoverDateLessThan = fcaNewHandoverDateLessThan;
	}

	public Boolean getFcaNewHandoverDateIsNull() {
		return fcaNewHandoverDateIsNull;
	}
	public void setFcaNewHandoverDateIsNull(Boolean fcaNewHandoverDateIsNull) {
		this.fcaNewHandoverDateIsNull = fcaNewHandoverDateIsNull;
	}

	public Boolean getFcaNewHandoverDateIsNotNull() {
		return fcaNewHandoverDateIsNotNull;
	}
	public void setFcaNewHandoverDateIsNotNull(Boolean fcaNewHandoverDateIsNotNull) {
		this.fcaNewHandoverDateIsNotNull = fcaNewHandoverDateIsNotNull;
	}

	public java.util.List getFcaNewHandoverDateIn() {
		return fcaNewHandoverDateIn;
	}
	public void setFcaNewHandoverDateIn(java.util.List fcaNewHandoverDateIn) {
		this.fcaNewHandoverDateIn = fcaNewHandoverDateIn;
	}

	public java.util.Date getFcaNewHandoverDateGreaterThanOrEqualTo() {
		return fcaNewHandoverDateGreaterThanOrEqualTo;
	}
	public void setFcaNewHandoverDateGreaterThanOrEqualTo(java.util.Date fcaNewHandoverDateGreaterThanOrEqualTo) {
		this.fcaNewHandoverDateGreaterThanOrEqualTo = fcaNewHandoverDateGreaterThanOrEqualTo;
	}

	public java.util.Date getFcaNewHandoverDateGreaterThan() {
		return fcaNewHandoverDateGreaterThan;
	}
	public void setFcaNewHandoverDateGreaterThan(java.util.Date fcaNewHandoverDateGreaterThan) {
		this.fcaNewHandoverDateGreaterThan = fcaNewHandoverDateGreaterThan;
	}

	public java.util.Date getFcaNewHandoverDateEqualTo() {
		return fcaNewHandoverDateEqualTo;
	}
	public void setFcaNewHandoverDateEqualTo(java.util.Date fcaNewHandoverDateEqualTo) {
		this.fcaNewHandoverDateEqualTo = fcaNewHandoverDateEqualTo;
	}

	public String getFcaNewCarPlateNumNotLike() {
		return fcaNewCarPlateNumNotLike;
	}
	public void setFcaNewCarPlateNumNotLike(String fcaNewCarPlateNumNotLike) {
		this.fcaNewCarPlateNumNotLike = fcaNewCarPlateNumNotLike;
	}

	public java.util.List getFcaNewCarPlateNumNotIn() {
		return fcaNewCarPlateNumNotIn;
	}
	public void setFcaNewCarPlateNumNotIn(java.util.List fcaNewCarPlateNumNotIn) {
		this.fcaNewCarPlateNumNotIn = fcaNewCarPlateNumNotIn;
	}

	public String getFcaNewCarPlateNumNotEqualTo() {
		return fcaNewCarPlateNumNotEqualTo;
	}
	public void setFcaNewCarPlateNumNotEqualTo(String fcaNewCarPlateNumNotEqualTo) {
		this.fcaNewCarPlateNumNotEqualTo = fcaNewCarPlateNumNotEqualTo;
	}

	public String getFcaNewCarPlateNumLike() {
		return fcaNewCarPlateNumLike;
	}
	public void setFcaNewCarPlateNumLike(String fcaNewCarPlateNumLike) {
		this.fcaNewCarPlateNumLike = fcaNewCarPlateNumLike;
	}

	public String getFcaNewCarPlateNumLessThanOrEqualTo() {
		return fcaNewCarPlateNumLessThanOrEqualTo;
	}
	public void setFcaNewCarPlateNumLessThanOrEqualTo(String fcaNewCarPlateNumLessThanOrEqualTo) {
		this.fcaNewCarPlateNumLessThanOrEqualTo = fcaNewCarPlateNumLessThanOrEqualTo;
	}

	public String getFcaNewCarPlateNumLessThan() {
		return fcaNewCarPlateNumLessThan;
	}
	public void setFcaNewCarPlateNumLessThan(String fcaNewCarPlateNumLessThan) {
		this.fcaNewCarPlateNumLessThan = fcaNewCarPlateNumLessThan;
	}

	public Boolean getFcaNewCarPlateNumIsNull() {
		return fcaNewCarPlateNumIsNull;
	}
	public void setFcaNewCarPlateNumIsNull(Boolean fcaNewCarPlateNumIsNull) {
		this.fcaNewCarPlateNumIsNull = fcaNewCarPlateNumIsNull;
	}

	public Boolean getFcaNewCarPlateNumIsNotNull() {
		return fcaNewCarPlateNumIsNotNull;
	}
	public void setFcaNewCarPlateNumIsNotNull(Boolean fcaNewCarPlateNumIsNotNull) {
		this.fcaNewCarPlateNumIsNotNull = fcaNewCarPlateNumIsNotNull;
	}

	public java.util.List getFcaNewCarPlateNumIn() {
		return fcaNewCarPlateNumIn;
	}
	public void setFcaNewCarPlateNumIn(java.util.List fcaNewCarPlateNumIn) {
		this.fcaNewCarPlateNumIn = fcaNewCarPlateNumIn;
	}

	public String getFcaNewCarPlateNumGreaterThanOrEqualTo() {
		return fcaNewCarPlateNumGreaterThanOrEqualTo;
	}
	public void setFcaNewCarPlateNumGreaterThanOrEqualTo(String fcaNewCarPlateNumGreaterThanOrEqualTo) {
		this.fcaNewCarPlateNumGreaterThanOrEqualTo = fcaNewCarPlateNumGreaterThanOrEqualTo;
	}

	public String getFcaNewCarPlateNumGreaterThan() {
		return fcaNewCarPlateNumGreaterThan;
	}
	public void setFcaNewCarPlateNumGreaterThan(String fcaNewCarPlateNumGreaterThan) {
		this.fcaNewCarPlateNumGreaterThan = fcaNewCarPlateNumGreaterThan;
	}

	public String getFcaNewCarPlateNumEqualTo() {
		return fcaNewCarPlateNumEqualTo;
	}
	public void setFcaNewCarPlateNumEqualTo(String fcaNewCarPlateNumEqualTo) {
		this.fcaNewCarPlateNumEqualTo = fcaNewCarPlateNumEqualTo;
	}

	public java.util.List getFcaLeaseEndDateNotIn() {
		return fcaLeaseEndDateNotIn;
	}
	public void setFcaLeaseEndDateNotIn(java.util.List fcaLeaseEndDateNotIn) {
		this.fcaLeaseEndDateNotIn = fcaLeaseEndDateNotIn;
	}

	public java.util.Date getFcaLeaseEndDateNotEqualTo() {
		return fcaLeaseEndDateNotEqualTo;
	}
	public void setFcaLeaseEndDateNotEqualTo(java.util.Date fcaLeaseEndDateNotEqualTo) {
		this.fcaLeaseEndDateNotEqualTo = fcaLeaseEndDateNotEqualTo;
	}

	public java.util.Date getFcaLeaseEndDateLessThanOrEqualTo() {
		return fcaLeaseEndDateLessThanOrEqualTo;
	}
	public void setFcaLeaseEndDateLessThanOrEqualTo(java.util.Date fcaLeaseEndDateLessThanOrEqualTo) {
		this.fcaLeaseEndDateLessThanOrEqualTo = fcaLeaseEndDateLessThanOrEqualTo;
	}

	public java.util.Date getFcaLeaseEndDateLessThan() {
		return fcaLeaseEndDateLessThan;
	}
	public void setFcaLeaseEndDateLessThan(java.util.Date fcaLeaseEndDateLessThan) {
		this.fcaLeaseEndDateLessThan = fcaLeaseEndDateLessThan;
	}

	public Boolean getFcaLeaseEndDateIsNull() {
		return fcaLeaseEndDateIsNull;
	}
	public void setFcaLeaseEndDateIsNull(Boolean fcaLeaseEndDateIsNull) {
		this.fcaLeaseEndDateIsNull = fcaLeaseEndDateIsNull;
	}

	public Boolean getFcaLeaseEndDateIsNotNull() {
		return fcaLeaseEndDateIsNotNull;
	}
	public void setFcaLeaseEndDateIsNotNull(Boolean fcaLeaseEndDateIsNotNull) {
		this.fcaLeaseEndDateIsNotNull = fcaLeaseEndDateIsNotNull;
	}

	public java.util.List getFcaLeaseEndDateIn() {
		return fcaLeaseEndDateIn;
	}
	public void setFcaLeaseEndDateIn(java.util.List fcaLeaseEndDateIn) {
		this.fcaLeaseEndDateIn = fcaLeaseEndDateIn;
	}

	public java.util.Date getFcaLeaseEndDateGreaterThanOrEqualTo() {
		return fcaLeaseEndDateGreaterThanOrEqualTo;
	}
	public void setFcaLeaseEndDateGreaterThanOrEqualTo(java.util.Date fcaLeaseEndDateGreaterThanOrEqualTo) {
		this.fcaLeaseEndDateGreaterThanOrEqualTo = fcaLeaseEndDateGreaterThanOrEqualTo;
	}

	public java.util.Date getFcaLeaseEndDateGreaterThan() {
		return fcaLeaseEndDateGreaterThan;
	}
	public void setFcaLeaseEndDateGreaterThan(java.util.Date fcaLeaseEndDateGreaterThan) {
		this.fcaLeaseEndDateGreaterThan = fcaLeaseEndDateGreaterThan;
	}

	public java.util.Date getFcaLeaseEndDateEqualTo() {
		return fcaLeaseEndDateEqualTo;
	}
	public void setFcaLeaseEndDateEqualTo(java.util.Date fcaLeaseEndDateEqualTo) {
		this.fcaLeaseEndDateEqualTo = fcaLeaseEndDateEqualTo;
	}

	public java.util.List getFcaInformationFeeNotIn() {
		return fcaInformationFeeNotIn;
	}
	public void setFcaInformationFeeNotIn(java.util.List fcaInformationFeeNotIn) {
		this.fcaInformationFeeNotIn = fcaInformationFeeNotIn;
	}

	public Double getFcaInformationFeeNotEqualTo() {
		return fcaInformationFeeNotEqualTo;
	}
	public void setFcaInformationFeeNotEqualTo(Double fcaInformationFeeNotEqualTo) {
		this.fcaInformationFeeNotEqualTo = fcaInformationFeeNotEqualTo;
	}

	public Double getFcaInformationFeeLessThanOrEqualTo() {
		return fcaInformationFeeLessThanOrEqualTo;
	}
	public void setFcaInformationFeeLessThanOrEqualTo(Double fcaInformationFeeLessThanOrEqualTo) {
		this.fcaInformationFeeLessThanOrEqualTo = fcaInformationFeeLessThanOrEqualTo;
	}

	public Double getFcaInformationFeeLessThan() {
		return fcaInformationFeeLessThan;
	}
	public void setFcaInformationFeeLessThan(Double fcaInformationFeeLessThan) {
		this.fcaInformationFeeLessThan = fcaInformationFeeLessThan;
	}

	public Boolean getFcaInformationFeeIsNull() {
		return fcaInformationFeeIsNull;
	}
	public void setFcaInformationFeeIsNull(Boolean fcaInformationFeeIsNull) {
		this.fcaInformationFeeIsNull = fcaInformationFeeIsNull;
	}

	public Boolean getFcaInformationFeeIsNotNull() {
		return fcaInformationFeeIsNotNull;
	}
	public void setFcaInformationFeeIsNotNull(Boolean fcaInformationFeeIsNotNull) {
		this.fcaInformationFeeIsNotNull = fcaInformationFeeIsNotNull;
	}

	public java.util.List getFcaInformationFeeIn() {
		return fcaInformationFeeIn;
	}
	public void setFcaInformationFeeIn(java.util.List fcaInformationFeeIn) {
		this.fcaInformationFeeIn = fcaInformationFeeIn;
	}

	public Double getFcaInformationFeeGreaterThanOrEqualTo() {
		return fcaInformationFeeGreaterThanOrEqualTo;
	}
	public void setFcaInformationFeeGreaterThanOrEqualTo(Double fcaInformationFeeGreaterThanOrEqualTo) {
		this.fcaInformationFeeGreaterThanOrEqualTo = fcaInformationFeeGreaterThanOrEqualTo;
	}

	public Double getFcaInformationFeeGreaterThan() {
		return fcaInformationFeeGreaterThan;
	}
	public void setFcaInformationFeeGreaterThan(Double fcaInformationFeeGreaterThan) {
		this.fcaInformationFeeGreaterThan = fcaInformationFeeGreaterThan;
	}

	public Double getFcaInformationFeeEqualTo() {
		return fcaInformationFeeEqualTo;
	}
	public void setFcaInformationFeeEqualTo(Double fcaInformationFeeEqualTo) {
		this.fcaInformationFeeEqualTo = fcaInformationFeeEqualTo;
	}

	public java.util.List getFcaIdNotIn() {
		return fcaIdNotIn;
	}
	public void setFcaIdNotIn(java.util.List fcaIdNotIn) {
		this.fcaIdNotIn = fcaIdNotIn;
	}

	public Long getFcaIdNotEqualTo() {
		return fcaIdNotEqualTo;
	}
	public void setFcaIdNotEqualTo(Long fcaIdNotEqualTo) {
		this.fcaIdNotEqualTo = fcaIdNotEqualTo;
	}

	public Long getFcaIdLessThanOrEqualTo() {
		return fcaIdLessThanOrEqualTo;
	}
	public void setFcaIdLessThanOrEqualTo(Long fcaIdLessThanOrEqualTo) {
		this.fcaIdLessThanOrEqualTo = fcaIdLessThanOrEqualTo;
	}

	public Long getFcaIdLessThan() {
		return fcaIdLessThan;
	}
	public void setFcaIdLessThan(Long fcaIdLessThan) {
		this.fcaIdLessThan = fcaIdLessThan;
	}

	public Boolean getFcaIdIsNull() {
		return fcaIdIsNull;
	}
	public void setFcaIdIsNull(Boolean fcaIdIsNull) {
		this.fcaIdIsNull = fcaIdIsNull;
	}

	public Boolean getFcaIdIsNotNull() {
		return fcaIdIsNotNull;
	}
	public void setFcaIdIsNotNull(Boolean fcaIdIsNotNull) {
		this.fcaIdIsNotNull = fcaIdIsNotNull;
	}

	public java.util.List getFcaIdIn() {
		return fcaIdIn;
	}
	public void setFcaIdIn(java.util.List fcaIdIn) {
		this.fcaIdIn = fcaIdIn;
	}

	public Long getFcaIdGreaterThanOrEqualTo() {
		return fcaIdGreaterThanOrEqualTo;
	}
	public void setFcaIdGreaterThanOrEqualTo(Long fcaIdGreaterThanOrEqualTo) {
		this.fcaIdGreaterThanOrEqualTo = fcaIdGreaterThanOrEqualTo;
	}

	public Long getFcaIdGreaterThan() {
		return fcaIdGreaterThan;
	}
	public void setFcaIdGreaterThan(Long fcaIdGreaterThan) {
		this.fcaIdGreaterThan = fcaIdGreaterThan;
	}

	public Long getFcaIdEqualTo() {
		return fcaIdEqualTo;
	}
	public void setFcaIdEqualTo(Long fcaIdEqualTo) {
		this.fcaIdEqualTo = fcaIdEqualTo;
	}

	public java.util.List getFcaContractTerminateDateNotIn() {
		return fcaContractTerminateDateNotIn;
	}
	public void setFcaContractTerminateDateNotIn(java.util.List fcaContractTerminateDateNotIn) {
		this.fcaContractTerminateDateNotIn = fcaContractTerminateDateNotIn;
	}

	public java.util.Date getFcaContractTerminateDateNotEqualTo() {
		return fcaContractTerminateDateNotEqualTo;
	}
	public void setFcaContractTerminateDateNotEqualTo(java.util.Date fcaContractTerminateDateNotEqualTo) {
		this.fcaContractTerminateDateNotEqualTo = fcaContractTerminateDateNotEqualTo;
	}

	public java.util.Date getFcaContractTerminateDateLessThanOrEqualTo() {
		return fcaContractTerminateDateLessThanOrEqualTo;
	}
	public void setFcaContractTerminateDateLessThanOrEqualTo(java.util.Date fcaContractTerminateDateLessThanOrEqualTo) {
		this.fcaContractTerminateDateLessThanOrEqualTo = fcaContractTerminateDateLessThanOrEqualTo;
	}

	public java.util.Date getFcaContractTerminateDateLessThan() {
		return fcaContractTerminateDateLessThan;
	}
	public void setFcaContractTerminateDateLessThan(java.util.Date fcaContractTerminateDateLessThan) {
		this.fcaContractTerminateDateLessThan = fcaContractTerminateDateLessThan;
	}

	public Boolean getFcaContractTerminateDateIsNull() {
		return fcaContractTerminateDateIsNull;
	}
	public void setFcaContractTerminateDateIsNull(Boolean fcaContractTerminateDateIsNull) {
		this.fcaContractTerminateDateIsNull = fcaContractTerminateDateIsNull;
	}

	public Boolean getFcaContractTerminateDateIsNotNull() {
		return fcaContractTerminateDateIsNotNull;
	}
	public void setFcaContractTerminateDateIsNotNull(Boolean fcaContractTerminateDateIsNotNull) {
		this.fcaContractTerminateDateIsNotNull = fcaContractTerminateDateIsNotNull;
	}

	public java.util.List getFcaContractTerminateDateIn() {
		return fcaContractTerminateDateIn;
	}
	public void setFcaContractTerminateDateIn(java.util.List fcaContractTerminateDateIn) {
		this.fcaContractTerminateDateIn = fcaContractTerminateDateIn;
	}

	public java.util.Date getFcaContractTerminateDateGreaterThanOrEqualTo() {
		return fcaContractTerminateDateGreaterThanOrEqualTo;
	}
	public void setFcaContractTerminateDateGreaterThanOrEqualTo(java.util.Date fcaContractTerminateDateGreaterThanOrEqualTo) {
		this.fcaContractTerminateDateGreaterThanOrEqualTo = fcaContractTerminateDateGreaterThanOrEqualTo;
	}

	public java.util.Date getFcaContractTerminateDateGreaterThan() {
		return fcaContractTerminateDateGreaterThan;
	}
	public void setFcaContractTerminateDateGreaterThan(java.util.Date fcaContractTerminateDateGreaterThan) {
		this.fcaContractTerminateDateGreaterThan = fcaContractTerminateDateGreaterThan;
	}

	public java.util.Date getFcaContractTerminateDateEqualTo() {
		return fcaContractTerminateDateEqualTo;
	}
	public void setFcaContractTerminateDateEqualTo(java.util.Date fcaContractTerminateDateEqualTo) {
		this.fcaContractTerminateDateEqualTo = fcaContractTerminateDateEqualTo;
	}

	public String getFcaContractNoNotLike() {
		return fcaContractNoNotLike;
	}
	public void setFcaContractNoNotLike(String fcaContractNoNotLike) {
		this.fcaContractNoNotLike = fcaContractNoNotLike;
	}

	public java.util.List getFcaContractNoNotIn() {
		return fcaContractNoNotIn;
	}
	public void setFcaContractNoNotIn(java.util.List fcaContractNoNotIn) {
		this.fcaContractNoNotIn = fcaContractNoNotIn;
	}

	public String getFcaContractNoNotEqualTo() {
		return fcaContractNoNotEqualTo;
	}
	public void setFcaContractNoNotEqualTo(String fcaContractNoNotEqualTo) {
		this.fcaContractNoNotEqualTo = fcaContractNoNotEqualTo;
	}

	public String getFcaContractNoLike() {
		return fcaContractNoLike;
	}
	public void setFcaContractNoLike(String fcaContractNoLike) {
		this.fcaContractNoLike = fcaContractNoLike;
	}

	public String getFcaContractNoLessThanOrEqualTo() {
		return fcaContractNoLessThanOrEqualTo;
	}
	public void setFcaContractNoLessThanOrEqualTo(String fcaContractNoLessThanOrEqualTo) {
		this.fcaContractNoLessThanOrEqualTo = fcaContractNoLessThanOrEqualTo;
	}

	public String getFcaContractNoLessThan() {
		return fcaContractNoLessThan;
	}
	public void setFcaContractNoLessThan(String fcaContractNoLessThan) {
		this.fcaContractNoLessThan = fcaContractNoLessThan;
	}

	public Boolean getFcaContractNoIsNull() {
		return fcaContractNoIsNull;
	}
	public void setFcaContractNoIsNull(Boolean fcaContractNoIsNull) {
		this.fcaContractNoIsNull = fcaContractNoIsNull;
	}

	public Boolean getFcaContractNoIsNotNull() {
		return fcaContractNoIsNotNull;
	}
	public void setFcaContractNoIsNotNull(Boolean fcaContractNoIsNotNull) {
		this.fcaContractNoIsNotNull = fcaContractNoIsNotNull;
	}

	public java.util.List getFcaContractNoIn() {
		return fcaContractNoIn;
	}
	public void setFcaContractNoIn(java.util.List fcaContractNoIn) {
		this.fcaContractNoIn = fcaContractNoIn;
	}

	public String getFcaContractNoGreaterThanOrEqualTo() {
		return fcaContractNoGreaterThanOrEqualTo;
	}
	public void setFcaContractNoGreaterThanOrEqualTo(String fcaContractNoGreaterThanOrEqualTo) {
		this.fcaContractNoGreaterThanOrEqualTo = fcaContractNoGreaterThanOrEqualTo;
	}

	public String getFcaContractNoGreaterThan() {
		return fcaContractNoGreaterThan;
	}
	public void setFcaContractNoGreaterThan(String fcaContractNoGreaterThan) {
		this.fcaContractNoGreaterThan = fcaContractNoGreaterThan;
	}

	public String getFcaContractNoEqualTo() {
		return fcaContractNoEqualTo;
	}
	public void setFcaContractNoEqualTo(String fcaContractNoEqualTo) {
		this.fcaContractNoEqualTo = fcaContractNoEqualTo;
	}

	public java.util.List getFcaContractIdNotIn() {
		return fcaContractIdNotIn;
	}
	public void setFcaContractIdNotIn(java.util.List fcaContractIdNotIn) {
		this.fcaContractIdNotIn = fcaContractIdNotIn;
	}

	public Long getFcaContractIdNotEqualTo() {
		return fcaContractIdNotEqualTo;
	}
	public void setFcaContractIdNotEqualTo(Long fcaContractIdNotEqualTo) {
		this.fcaContractIdNotEqualTo = fcaContractIdNotEqualTo;
	}

	public Long getFcaContractIdLessThanOrEqualTo() {
		return fcaContractIdLessThanOrEqualTo;
	}
	public void setFcaContractIdLessThanOrEqualTo(Long fcaContractIdLessThanOrEqualTo) {
		this.fcaContractIdLessThanOrEqualTo = fcaContractIdLessThanOrEqualTo;
	}

	public Long getFcaContractIdLessThan() {
		return fcaContractIdLessThan;
	}
	public void setFcaContractIdLessThan(Long fcaContractIdLessThan) {
		this.fcaContractIdLessThan = fcaContractIdLessThan;
	}

	public Boolean getFcaContractIdIsNull() {
		return fcaContractIdIsNull;
	}
	public void setFcaContractIdIsNull(Boolean fcaContractIdIsNull) {
		this.fcaContractIdIsNull = fcaContractIdIsNull;
	}

	public Boolean getFcaContractIdIsNotNull() {
		return fcaContractIdIsNotNull;
	}
	public void setFcaContractIdIsNotNull(Boolean fcaContractIdIsNotNull) {
		this.fcaContractIdIsNotNull = fcaContractIdIsNotNull;
	}

	public java.util.List getFcaContractIdIn() {
		return fcaContractIdIn;
	}
	public void setFcaContractIdIn(java.util.List fcaContractIdIn) {
		this.fcaContractIdIn = fcaContractIdIn;
	}

	public Long getFcaContractIdGreaterThanOrEqualTo() {
		return fcaContractIdGreaterThanOrEqualTo;
	}
	public void setFcaContractIdGreaterThanOrEqualTo(Long fcaContractIdGreaterThanOrEqualTo) {
		this.fcaContractIdGreaterThanOrEqualTo = fcaContractIdGreaterThanOrEqualTo;
	}

	public Long getFcaContractIdGreaterThan() {
		return fcaContractIdGreaterThan;
	}
	public void setFcaContractIdGreaterThan(Long fcaContractIdGreaterThan) {
		this.fcaContractIdGreaterThan = fcaContractIdGreaterThan;
	}

	public Long getFcaContractIdEqualTo() {
		return fcaContractIdEqualTo;
	}
	public void setFcaContractIdEqualTo(Long fcaContractIdEqualTo) {
		this.fcaContractIdEqualTo = fcaContractIdEqualTo;
	}

	public String getFcaAssociateContractNoNotLike() {
		return fcaAssociateContractNoNotLike;
	}
	public void setFcaAssociateContractNoNotLike(String fcaAssociateContractNoNotLike) {
		this.fcaAssociateContractNoNotLike = fcaAssociateContractNoNotLike;
	}

	public java.util.List getFcaAssociateContractNoNotIn() {
		return fcaAssociateContractNoNotIn;
	}
	public void setFcaAssociateContractNoNotIn(java.util.List fcaAssociateContractNoNotIn) {
		this.fcaAssociateContractNoNotIn = fcaAssociateContractNoNotIn;
	}

	public String getFcaAssociateContractNoNotEqualTo() {
		return fcaAssociateContractNoNotEqualTo;
	}
	public void setFcaAssociateContractNoNotEqualTo(String fcaAssociateContractNoNotEqualTo) {
		this.fcaAssociateContractNoNotEqualTo = fcaAssociateContractNoNotEqualTo;
	}

	public String getFcaAssociateContractNoLike() {
		return fcaAssociateContractNoLike;
	}
	public void setFcaAssociateContractNoLike(String fcaAssociateContractNoLike) {
		this.fcaAssociateContractNoLike = fcaAssociateContractNoLike;
	}

	public String getFcaAssociateContractNoLessThanOrEqualTo() {
		return fcaAssociateContractNoLessThanOrEqualTo;
	}
	public void setFcaAssociateContractNoLessThanOrEqualTo(String fcaAssociateContractNoLessThanOrEqualTo) {
		this.fcaAssociateContractNoLessThanOrEqualTo = fcaAssociateContractNoLessThanOrEqualTo;
	}

	public String getFcaAssociateContractNoLessThan() {
		return fcaAssociateContractNoLessThan;
	}
	public void setFcaAssociateContractNoLessThan(String fcaAssociateContractNoLessThan) {
		this.fcaAssociateContractNoLessThan = fcaAssociateContractNoLessThan;
	}

	public Boolean getFcaAssociateContractNoIsNull() {
		return fcaAssociateContractNoIsNull;
	}
	public void setFcaAssociateContractNoIsNull(Boolean fcaAssociateContractNoIsNull) {
		this.fcaAssociateContractNoIsNull = fcaAssociateContractNoIsNull;
	}

	public Boolean getFcaAssociateContractNoIsNotNull() {
		return fcaAssociateContractNoIsNotNull;
	}
	public void setFcaAssociateContractNoIsNotNull(Boolean fcaAssociateContractNoIsNotNull) {
		this.fcaAssociateContractNoIsNotNull = fcaAssociateContractNoIsNotNull;
	}

	public java.util.List getFcaAssociateContractNoIn() {
		return fcaAssociateContractNoIn;
	}
	public void setFcaAssociateContractNoIn(java.util.List fcaAssociateContractNoIn) {
		this.fcaAssociateContractNoIn = fcaAssociateContractNoIn;
	}

	public String getFcaAssociateContractNoGreaterThanOrEqualTo() {
		return fcaAssociateContractNoGreaterThanOrEqualTo;
	}
	public void setFcaAssociateContractNoGreaterThanOrEqualTo(String fcaAssociateContractNoGreaterThanOrEqualTo) {
		this.fcaAssociateContractNoGreaterThanOrEqualTo = fcaAssociateContractNoGreaterThanOrEqualTo;
	}

	public String getFcaAssociateContractNoGreaterThan() {
		return fcaAssociateContractNoGreaterThan;
	}
	public void setFcaAssociateContractNoGreaterThan(String fcaAssociateContractNoGreaterThan) {
		this.fcaAssociateContractNoGreaterThan = fcaAssociateContractNoGreaterThan;
	}

	public String getFcaAssociateContractNoEqualTo() {
		return fcaAssociateContractNoEqualTo;
	}
	public void setFcaAssociateContractNoEqualTo(String fcaAssociateContractNoEqualTo) {
		this.fcaAssociateContractNoEqualTo = fcaAssociateContractNoEqualTo;
	}

	public java.util.List getDrNotIn() {
		return drNotIn;
	}
	public void setDrNotIn(java.util.List drNotIn) {
		this.drNotIn = drNotIn;
	}

	public Integer getDrNotEqualTo() {
		return drNotEqualTo;
	}
	public void setDrNotEqualTo(Integer drNotEqualTo) {
		this.drNotEqualTo = drNotEqualTo;
	}

	public Integer getDrLessThanOrEqualTo() {
		return drLessThanOrEqualTo;
	}
	public void setDrLessThanOrEqualTo(Integer drLessThanOrEqualTo) {
		this.drLessThanOrEqualTo = drLessThanOrEqualTo;
	}

	public Integer getDrLessThan() {
		return drLessThan;
	}
	public void setDrLessThan(Integer drLessThan) {
		this.drLessThan = drLessThan;
	}

	public Boolean getDrIsNull() {
		return drIsNull;
	}
	public void setDrIsNull(Boolean drIsNull) {
		this.drIsNull = drIsNull;
	}

	public Boolean getDrIsNotNull() {
		return drIsNotNull;
	}
	public void setDrIsNotNull(Boolean drIsNotNull) {
		this.drIsNotNull = drIsNotNull;
	}

	public java.util.List getDrIn() {
		return drIn;
	}
	public void setDrIn(java.util.List drIn) {
		this.drIn = drIn;
	}

	public Integer getDrGreaterThanOrEqualTo() {
		return drGreaterThanOrEqualTo;
	}
	public void setDrGreaterThanOrEqualTo(Integer drGreaterThanOrEqualTo) {
		this.drGreaterThanOrEqualTo = drGreaterThanOrEqualTo;
	}

	public Integer getDrGreaterThan() {
		return drGreaterThan;
	}
	public void setDrGreaterThan(Integer drGreaterThan) {
		this.drGreaterThan = drGreaterThan;
	}

	public Integer getDrEqualTo() {
		return drEqualTo;
	}
	public void setDrEqualTo(Integer drEqualTo) {
		this.drEqualTo = drEqualTo;
	}

	public String getCreateuserNotLike() {
		return createuserNotLike;
	}
	public void setCreateuserNotLike(String createuserNotLike) {
		this.createuserNotLike = createuserNotLike;
	}

	public java.util.List getCreateuserNotIn() {
		return createuserNotIn;
	}
	public void setCreateuserNotIn(java.util.List createuserNotIn) {
		this.createuserNotIn = createuserNotIn;
	}

	public String getCreateuserNotEqualTo() {
		return createuserNotEqualTo;
	}
	public void setCreateuserNotEqualTo(String createuserNotEqualTo) {
		this.createuserNotEqualTo = createuserNotEqualTo;
	}

	public String getCreateuserLike() {
		return createuserLike;
	}
	public void setCreateuserLike(String createuserLike) {
		this.createuserLike = createuserLike;
	}

	public String getCreateuserLessThanOrEqualTo() {
		return createuserLessThanOrEqualTo;
	}
	public void setCreateuserLessThanOrEqualTo(String createuserLessThanOrEqualTo) {
		this.createuserLessThanOrEqualTo = createuserLessThanOrEqualTo;
	}

	public String getCreateuserLessThan() {
		return createuserLessThan;
	}
	public void setCreateuserLessThan(String createuserLessThan) {
		this.createuserLessThan = createuserLessThan;
	}

	public Boolean getCreateuserIsNull() {
		return createuserIsNull;
	}
	public void setCreateuserIsNull(Boolean createuserIsNull) {
		this.createuserIsNull = createuserIsNull;
	}

	public Boolean getCreateuserIsNotNull() {
		return createuserIsNotNull;
	}
	public void setCreateuserIsNotNull(Boolean createuserIsNotNull) {
		this.createuserIsNotNull = createuserIsNotNull;
	}

	public java.util.List getCreateuserIn() {
		return createuserIn;
	}
	public void setCreateuserIn(java.util.List createuserIn) {
		this.createuserIn = createuserIn;
	}

	public String getCreateuserGreaterThanOrEqualTo() {
		return createuserGreaterThanOrEqualTo;
	}
	public void setCreateuserGreaterThanOrEqualTo(String createuserGreaterThanOrEqualTo) {
		this.createuserGreaterThanOrEqualTo = createuserGreaterThanOrEqualTo;
	}

	public String getCreateuserGreaterThan() {
		return createuserGreaterThan;
	}
	public void setCreateuserGreaterThan(String createuserGreaterThan) {
		this.createuserGreaterThan = createuserGreaterThan;
	}

	public String getCreateuserEqualTo() {
		return createuserEqualTo;
	}
	public void setCreateuserEqualTo(String createuserEqualTo) {
		this.createuserEqualTo = createuserEqualTo;
	}

	public java.util.List getCreatetimeNotIn() {
		return createtimeNotIn;
	}
	public void setCreatetimeNotIn(java.util.List createtimeNotIn) {
		this.createtimeNotIn = createtimeNotIn;
	}

	public java.util.Date getCreatetimeNotEqualTo() {
		return createtimeNotEqualTo;
	}
	public void setCreatetimeNotEqualTo(java.util.Date createtimeNotEqualTo) {
		this.createtimeNotEqualTo = createtimeNotEqualTo;
	}

	public java.util.Date getCreatetimeLessThanOrEqualTo() {
		return createtimeLessThanOrEqualTo;
	}
	public void setCreatetimeLessThanOrEqualTo(java.util.Date createtimeLessThanOrEqualTo) {
		this.createtimeLessThanOrEqualTo = createtimeLessThanOrEqualTo;
	}

	public java.util.Date getCreatetimeLessThan() {
		return createtimeLessThan;
	}
	public void setCreatetimeLessThan(java.util.Date createtimeLessThan) {
		this.createtimeLessThan = createtimeLessThan;
	}

	public Boolean getCreatetimeIsNull() {
		return createtimeIsNull;
	}
	public void setCreatetimeIsNull(Boolean createtimeIsNull) {
		this.createtimeIsNull = createtimeIsNull;
	}

	public Boolean getCreatetimeIsNotNull() {
		return createtimeIsNotNull;
	}
	public void setCreatetimeIsNotNull(Boolean createtimeIsNotNull) {
		this.createtimeIsNotNull = createtimeIsNotNull;
	}

	public java.util.List getCreatetimeIn() {
		return createtimeIn;
	}
	public void setCreatetimeIn(java.util.List createtimeIn) {
		this.createtimeIn = createtimeIn;
	}

	public java.util.Date getCreatetimeGreaterThanOrEqualTo() {
		return createtimeGreaterThanOrEqualTo;
	}
	public void setCreatetimeGreaterThanOrEqualTo(java.util.Date createtimeGreaterThanOrEqualTo) {
		this.createtimeGreaterThanOrEqualTo = createtimeGreaterThanOrEqualTo;
	}

	public java.util.Date getCreatetimeGreaterThan() {
		return createtimeGreaterThan;
	}
	public void setCreatetimeGreaterThan(java.util.Date createtimeGreaterThan) {
		this.createtimeGreaterThan = createtimeGreaterThan;
	}

	public java.util.Date getCreatetimeEqualTo() {
		return createtimeEqualTo;
	}
	public void setCreatetimeEqualTo(java.util.Date createtimeEqualTo) {
		this.createtimeEqualTo = createtimeEqualTo;
	}

	public void setSidx(String sidx) {
		this.sidx = sidx;
	}
	public String getSord() {
		return sord;
	}
	public void setSord(String sord) {
		 this.sord = sord;
	}
}
