package com.mrk.finance.queryvo;

import com.mrk.common.base.BaseQueryVo;
import io.swagger.annotations.ApiModelProperty;
import lombok.Getter;
import lombok.Setter;

import java.util.List;

@Setter
@Getter
public class FncContractRentalFeesQueryVo extends BaseQueryVo {



    @ApiModelProperty(value = "主键 精确匹配")
    private Long fcrfIdEqualTo;

    @ApiModelProperty(value = "主键 模糊匹配")
    private Long fcrfIdLike;


    @ApiModelProperty(value = "合同id 精确匹配")
    private Long fcrfContractIdEqualTo;
    private List<Long> fcrfContractIdIn;

    @ApiModelProperty(value = "合同id 模糊匹配")
    private Long fcrfContractIdLike;


    @ApiModelProperty(value = "租金费用id 精确匹配")
    private Long fcrfRentFeesIdEqualTo;

    @ApiModelProperty(value = "租金费用id 模糊匹配")
    private Long fcrfRentFeesIdLike;


    @ApiModelProperty(value = "是否填写 精确匹配")
    private Integer fcrfWriteEqualTo;

    @ApiModelProperty(value = "是否填写 模糊匹配")
    private Integer fcrfWriteLike;


    @ApiModelProperty(value = "数据值 精确匹配")
    private String fcrfValueEqualTo;

    @ApiModelProperty(value = "数据值 模糊匹配")
    private String fcrfValueLike;
    }
