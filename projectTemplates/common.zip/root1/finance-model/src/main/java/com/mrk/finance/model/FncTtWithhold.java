package com.mrk.finance.model;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.mrk.common.base.BaseEntity;
import io.swagger.annotations.ApiModelProperty;
import lombok.Getter;
import lombok.Setter;
import org.springframework.format.annotation.DateTimeFormat;

import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import java.io.Serializable;

@Setter
@Getter
public class FncTtWithhold extends BaseEntity implements Serializable {
private static final long serialVersionUID=1L;


    /**主键 */
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @ApiModelProperty(value = "主键")
    private Long ftwId;

    /**城市 */
    @ApiModelProperty(value = "城市")
    private Long ftwCityId;

    /**姓名 */
    @ApiModelProperty(value = "姓名")
    private String ftwName;

    /**身份证号 */
    @ApiModelProperty(value = "身份证号")
    private String ftwIdnumber;

    /**司机ID */
    @ApiModelProperty(value = "司机ID")
    private Long ftwMemberId;

    /**协议编号 */
    @ApiModelProperty(value = "协议编号")
    private String ftwAgreementNumber;

    /**起租日期 */
    @DateTimeFormat(pattern = "yyyy-MM-dd")
    @JsonFormat(pattern = "yyyy-MM-dd", timezone = "GMT+8")
    @ApiModelProperty(value = "起租日期")
    private java.util.Date ftwRentDate;

    /**租期 */
    @ApiModelProperty(value = "租期")
    private Integer ftwLeaseCount;

    /**车型 */
    @ApiModelProperty(value = "车型")
    private Long ftwCarModel;

    /**车架号 */
    @ApiModelProperty(value = "车架号")
    private String ftwCarVin;

    /**月租金 */
    @ApiModelProperty(value = "月租金")
    private Double ftwMonthRent;

    /**月扣款总额 */
    @ApiModelProperty(value = "月扣款总额")
    private Double ftwMonthWithhold;

    /**月租金余量 */
    @ApiModelProperty(value = "月租金余量")
    private Double ftwMonthRentBalance;

    /**匹配状态 */
    @ApiModelProperty(value = "匹配状态")
    private Integer ftwMatchState;

    /**匹配账单 */
    @ApiModelProperty(value = "匹配账单")
    private String ftwMatchBill;

    /**匹配方式 */
    @ApiModelProperty(value = "匹配方式")
    private Integer ftwMatchWay;

    /**已匹配金额 */
    @ApiModelProperty(value = "已匹配金额")
    private Double ftwMatchedAmount;

    /**未匹配金额 */
    @ApiModelProperty(value = "未匹配金额")
    private Double ftwNotMatchAmount;
    }
