package com.mrk.finance.example;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

public class FncBillManagementExample {
    protected String orderByClause;

    protected boolean distinct;

    protected List<Criteria> oredCriteria;

    public FncBillManagementExample() {
        oredCriteria = new ArrayList<Criteria>();
    }

    public void setOrderByClause(String orderByClause) {
        this.orderByClause = orderByClause;
    }

    public String getOrderByClause() {
        return orderByClause;
    }

    public void setDistinct(boolean distinct) {
        this.distinct = distinct;
    }

    public boolean isDistinct() {
        return distinct;
    }

    public List<Criteria> getOredCriteria() {
        return oredCriteria;
    }

    public void or(Criteria criteria) {
        oredCriteria.add(criteria);
    }

    public Criteria or() {
        Criteria criteria = createCriteriaInternal();
        oredCriteria.add(criteria);
        return criteria;
    }

    public Criteria createCriteria() {
        Criteria criteria = createCriteriaInternal();
        if (oredCriteria.size() == 0) {
            oredCriteria.add(criteria);
        }
        return criteria;
    }

    protected Criteria createCriteriaInternal() {
        Criteria criteria = new Criteria();
        return criteria;
    }

    public void clear() {
        oredCriteria.clear();
        orderByClause = null;
        distinct = false;
    }

    protected abstract static class GeneratedCriteria {
        protected List<Criterion> criteria;

        protected GeneratedCriteria() {
            super();
            criteria = new ArrayList<Criterion>();
        }

        public boolean isValid() {
            return criteria.size() > 0;
        }

        public List<Criterion> getAllCriteria() {
            return criteria;
        }

        public List<Criterion> getCriteria() {
            return criteria;
        }

        protected void addCriterion(String condition) {
            if (condition == null) {
                throw new RuntimeException("Value for condition cannot be null");
            }
            criteria.add(new Criterion(condition));
        }

        protected void addCriterion(String condition, Object value, String property) {
            if (value == null) {
                throw new RuntimeException("Value for " + property + " cannot be null");
            }
            criteria.add(new Criterion(condition, value));
        }

        protected void addCriterion(String condition, Object value1, Object value2, String property) {
            if (value1 == null || value2 == null) {
                throw new RuntimeException("Between values for " + property + " cannot be null");
            }
            criteria.add(new Criterion(condition, value1, value2));
        }

        public Criteria andFbmIdIsNull() {
            addCriterion("fbm_id is null");
            return (Criteria) this;
        }

        public Criteria andFbmIdIsNotNull() {
            addCriterion("fbm_id is not null");
            return (Criteria) this;
        }

        public Criteria andFbmIdEqualTo(Long value) {
            addCriterion("fbm_id =", value, "fbmId");
            return (Criteria) this;
        }

        public Criteria andFbmIdNotEqualTo(Long value) {
            addCriterion("fbm_id <>", value, "fbmId");
            return (Criteria) this;
        }

        public Criteria andFbmIdGreaterThan(Long value) {
            addCriterion("fbm_id >", value, "fbmId");
            return (Criteria) this;
        }

        public Criteria andFbmIdGreaterThanOrEqualTo(Long value) {
            addCriterion("fbm_id >=", value, "fbmId");
            return (Criteria) this;
        }

        public Criteria andFbmIdLessThan(Long value) {
            addCriterion("fbm_id <", value, "fbmId");
            return (Criteria) this;
        }

        public Criteria andFbmIdLessThanOrEqualTo(Long value) {
            addCriterion("fbm_id <=", value, "fbmId");
            return (Criteria) this;
        }

        public Criteria andFbmIdIn(List<Long> values) {
            addCriterion("fbm_id in", values, "fbmId");
            return (Criteria) this;
        }

        public Criteria andFbmIdNotIn(List<Long> values) {
            addCriterion("fbm_id not in", values, "fbmId");
            return (Criteria) this;
        }

        public Criteria andFbmIdBetween(Long value1, Long value2) {
            addCriterion("fbm_id between", value1, value2, "fbmId");
            return (Criteria) this;
        }

        public Criteria andFbmIdNotBetween(Long value1, Long value2) {
            addCriterion("fbm_id not between", value1, value2, "fbmId");
            return (Criteria) this;
        }

        public Criteria andFbmCityIdIsNull() {
            addCriterion("fbm_city_id is null");
            return (Criteria) this;
        }

        public Criteria andFbmCityIdIsNotNull() {
            addCriterion("fbm_city_id is not null");
            return (Criteria) this;
        }

        public Criteria andFbmCityIdEqualTo(Long value) {
            addCriterion("fbm_city_id =", value, "fbmCityId");
            return (Criteria) this;
        }

        public Criteria andFbmCityIdNotEqualTo(Long value) {
            addCriterion("fbm_city_id <>", value, "fbmCityId");
            return (Criteria) this;
        }

        public Criteria andFbmCityIdGreaterThan(Long value) {
            addCriterion("fbm_city_id >", value, "fbmCityId");
            return (Criteria) this;
        }

        public Criteria andFbmCityIdGreaterThanOrEqualTo(Long value) {
            addCriterion("fbm_city_id >=", value, "fbmCityId");
            return (Criteria) this;
        }

        public Criteria andFbmCityIdLessThan(Long value) {
            addCriterion("fbm_city_id <", value, "fbmCityId");
            return (Criteria) this;
        }

        public Criteria andFbmCityIdLessThanOrEqualTo(Long value) {
            addCriterion("fbm_city_id <=", value, "fbmCityId");
            return (Criteria) this;
        }

        public Criteria andFbmCityIdIn(List<Long> values) {
            addCriterion("fbm_city_id in", values, "fbmCityId");
            return (Criteria) this;
        }

        public Criteria andFbmCityIdNotIn(List<Long> values) {
            addCriterion("fbm_city_id not in", values, "fbmCityId");
            return (Criteria) this;
        }

        public Criteria andFbmCityIdBetween(Long value1, Long value2) {
            addCriterion("fbm_city_id between", value1, value2, "fbmCityId");
            return (Criteria) this;
        }

        public Criteria andFbmCityIdNotBetween(Long value1, Long value2) {
            addCriterion("fbm_city_id not between", value1, value2, "fbmCityId");
            return (Criteria) this;
        }

        public Criteria andFbmSubjectsIsNull() {
            addCriterion("fbm_subjects is null");
            return (Criteria) this;
        }

        public Criteria andFbmSubjectsIsNotNull() {
            addCriterion("fbm_subjects is not null");
            return (Criteria) this;
        }

        public Criteria andFbmSubjectsEqualTo(Integer value) {
            addCriterion("fbm_subjects =", value, "fbmSubjects");
            return (Criteria) this;
        }

        public Criteria andFbmSubjectsNotEqualTo(Integer value) {
            addCriterion("fbm_subjects <>", value, "fbmSubjects");
            return (Criteria) this;
        }

        public Criteria andFbmSubjectsGreaterThan(Integer value) {
            addCriterion("fbm_subjects >", value, "fbmSubjects");
            return (Criteria) this;
        }

        public Criteria andFbmSubjectsGreaterThanOrEqualTo(Integer value) {
            addCriterion("fbm_subjects >=", value, "fbmSubjects");
            return (Criteria) this;
        }

        public Criteria andFbmSubjectsLessThan(Integer value) {
            addCriterion("fbm_subjects <", value, "fbmSubjects");
            return (Criteria) this;
        }

        public Criteria andFbmSubjectsLessThanOrEqualTo(Integer value) {
            addCriterion("fbm_subjects <=", value, "fbmSubjects");
            return (Criteria) this;
        }

        public Criteria andFbmSubjectsIn(List<Integer> values) {
            addCriterion("fbm_subjects in", values, "fbmSubjects");
            return (Criteria) this;
        }

        public Criteria andFbmSubjectsNotIn(List<Integer> values) {
            addCriterion("fbm_subjects not in", values, "fbmSubjects");
            return (Criteria) this;
        }

        public Criteria andFbmSubjectsBetween(Integer value1, Integer value2) {
            addCriterion("fbm_subjects between", value1, value2, "fbmSubjects");
            return (Criteria) this;
        }

        public Criteria andFbmSubjectsNotBetween(Integer value1, Integer value2) {
            addCriterion("fbm_subjects not between", value1, value2, "fbmSubjects");
            return (Criteria) this;
        }

        public Criteria andFbmBillAmountIsNull() {
            addCriterion("fbm_bill_amount is null");
            return (Criteria) this;
        }

        public Criteria andFbmBillAmountIsNotNull() {
            addCriterion("fbm_bill_amount is not null");
            return (Criteria) this;
        }

        public Criteria andFbmBillAmountEqualTo(Double value) {
            addCriterion("fbm_bill_amount =", value, "fbmBillAmount");
            return (Criteria) this;
        }

        public Criteria andFbmBillAmountNotEqualTo(Double value) {
            addCriterion("fbm_bill_amount <>", value, "fbmBillAmount");
            return (Criteria) this;
        }

        public Criteria andFbmBillAmountGreaterThan(Double value) {
            addCriterion("fbm_bill_amount >", value, "fbmBillAmount");
            return (Criteria) this;
        }

        public Criteria andFbmBillAmountGreaterThanOrEqualTo(Double value) {
            addCriterion("fbm_bill_amount >=", value, "fbmBillAmount");
            return (Criteria) this;
        }

        public Criteria andFbmBillAmountLessThan(Double value) {
            addCriterion("fbm_bill_amount <", value, "fbmBillAmount");
            return (Criteria) this;
        }

        public Criteria andFbmBillAmountLessThanOrEqualTo(Double value) {
            addCriterion("fbm_bill_amount <=", value, "fbmBillAmount");
            return (Criteria) this;
        }

        public Criteria andFbmBillAmountIn(List<Double> values) {
            addCriterion("fbm_bill_amount in", values, "fbmBillAmount");
            return (Criteria) this;
        }

        public Criteria andFbmBillAmountNotIn(List<Double> values) {
            addCriterion("fbm_bill_amount not in", values, "fbmBillAmount");
            return (Criteria) this;
        }

        public Criteria andFbmBillAmountBetween(Double value1, Double value2) {
            addCriterion("fbm_bill_amount between", value1, value2, "fbmBillAmount");
            return (Criteria) this;
        }

        public Criteria andFbmBillAmountNotBetween(Double value1, Double value2) {
            addCriterion("fbm_bill_amount not between", value1, value2, "fbmBillAmount");
            return (Criteria) this;
        }

        public Criteria andFbmNperIsNull() {
            addCriterion("fbm_nper is null");
            return (Criteria) this;
        }

        public Criteria andFbmNperIsNotNull() {
            addCriterion("fbm_nper is not null");
            return (Criteria) this;
        }

        public Criteria andFbmNperEqualTo(String value) {
            addCriterion("fbm_nper =", value, "fbmNper");
            return (Criteria) this;
        }

        public Criteria andFbmNperNotEqualTo(String value) {
            addCriterion("fbm_nper <>", value, "fbmNper");
            return (Criteria) this;
        }

        public Criteria andFbmNperGreaterThan(String value) {
            addCriterion("fbm_nper >", value, "fbmNper");
            return (Criteria) this;
        }

        public Criteria andFbmNperGreaterThanOrEqualTo(String value) {
            addCriterion("fbm_nper >=", value, "fbmNper");
            return (Criteria) this;
        }

        public Criteria andFbmNperLessThan(String value) {
            addCriterion("fbm_nper <", value, "fbmNper");
            return (Criteria) this;
        }

        public Criteria andFbmNperLessThanOrEqualTo(String value) {
            addCriterion("fbm_nper <=", value, "fbmNper");
            return (Criteria) this;
        }

        public Criteria andFbmNperLike(String value) {
            addCriterion("fbm_nper like", value, "fbmNper");
            return (Criteria) this;
        }

        public Criteria andFbmNperNotLike(String value) {
            addCriterion("fbm_nper not like", value, "fbmNper");
            return (Criteria) this;
        }

        public Criteria andFbmNperIn(List<String> values) {
            addCriterion("fbm_nper in", values, "fbmNper");
            return (Criteria) this;
        }

        public Criteria andFbmNperNotIn(List<String> values) {
            addCriterion("fbm_nper not in", values, "fbmNper");
            return (Criteria) this;
        }

        public Criteria andFbmNperBetween(String value1, String value2) {
            addCriterion("fbm_nper between", value1, value2, "fbmNper");
            return (Criteria) this;
        }

        public Criteria andFbmNperNotBetween(String value1, String value2) {
            addCriterion("fbm_nper not between", value1, value2, "fbmNper");
            return (Criteria) this;
        }

        public Criteria andFbmBillGenerateTimeIsNull() {
            addCriterion("fbm_bill_generate_time is null");
            return (Criteria) this;
        }

        public Criteria andFbmBillGenerateTimeIsNotNull() {
            addCriterion("fbm_bill_generate_time is not null");
            return (Criteria) this;
        }

        public Criteria andFbmBillGenerateTimeEqualTo(Date value) {
            addCriterion("fbm_bill_generate_time =", value, "fbmBillGenerateTime");
            return (Criteria) this;
        }

        public Criteria andFbmBillGenerateTimeNotEqualTo(Date value) {
            addCriterion("fbm_bill_generate_time <>", value, "fbmBillGenerateTime");
            return (Criteria) this;
        }

        public Criteria andFbmBillGenerateTimeGreaterThan(Date value) {
            addCriterion("fbm_bill_generate_time >", value, "fbmBillGenerateTime");
            return (Criteria) this;
        }

        public Criteria andFbmBillGenerateTimeGreaterThanOrEqualTo(Date value) {
            addCriterion("fbm_bill_generate_time >=", value, "fbmBillGenerateTime");
            return (Criteria) this;
        }

        public Criteria andFbmBillGenerateTimeLessThan(Date value) {
            addCriterion("fbm_bill_generate_time <", value, "fbmBillGenerateTime");
            return (Criteria) this;
        }

        public Criteria andFbmBillGenerateTimeLessThanOrEqualTo(Date value) {
            addCriterion("fbm_bill_generate_time <=", value, "fbmBillGenerateTime");
            return (Criteria) this;
        }

        public Criteria andFbmBillGenerateTimeIn(List<Date> values) {
            addCriterion("fbm_bill_generate_time in", values, "fbmBillGenerateTime");
            return (Criteria) this;
        }

        public Criteria andFbmBillGenerateTimeNotIn(List<Date> values) {
            addCriterion("fbm_bill_generate_time not in", values, "fbmBillGenerateTime");
            return (Criteria) this;
        }

        public Criteria andFbmBillGenerateTimeBetween(Date value1, Date value2) {
            addCriterion("fbm_bill_generate_time between", value1, value2, "fbmBillGenerateTime");
            return (Criteria) this;
        }

        public Criteria andFbmBillGenerateTimeNotBetween(Date value1, Date value2) {
            addCriterion("fbm_bill_generate_time not between", value1, value2, "fbmBillGenerateTime");
            return (Criteria) this;
        }

        public Criteria andFbmBillGenerateWayIsNull() {
            addCriterion("fbm_bill_generate_way is null");
            return (Criteria) this;
        }

        public Criteria andFbmBillGenerateWayIsNotNull() {
            addCriterion("fbm_bill_generate_way is not null");
            return (Criteria) this;
        }

        public Criteria andFbmBillGenerateWayEqualTo(Integer value) {
            addCriterion("fbm_bill_generate_way =", value, "fbmBillGenerateWay");
            return (Criteria) this;
        }

        public Criteria andFbmBillGenerateWayNotEqualTo(Integer value) {
            addCriterion("fbm_bill_generate_way <>", value, "fbmBillGenerateWay");
            return (Criteria) this;
        }

        public Criteria andFbmBillGenerateWayGreaterThan(Integer value) {
            addCriterion("fbm_bill_generate_way >", value, "fbmBillGenerateWay");
            return (Criteria) this;
        }

        public Criteria andFbmBillGenerateWayGreaterThanOrEqualTo(Integer value) {
            addCriterion("fbm_bill_generate_way >=", value, "fbmBillGenerateWay");
            return (Criteria) this;
        }

        public Criteria andFbmBillGenerateWayLessThan(Integer value) {
            addCriterion("fbm_bill_generate_way <", value, "fbmBillGenerateWay");
            return (Criteria) this;
        }

        public Criteria andFbmBillGenerateWayLessThanOrEqualTo(Integer value) {
            addCriterion("fbm_bill_generate_way <=", value, "fbmBillGenerateWay");
            return (Criteria) this;
        }

        public Criteria andFbmBillGenerateWayIn(List<Integer> values) {
            addCriterion("fbm_bill_generate_way in", values, "fbmBillGenerateWay");
            return (Criteria) this;
        }

        public Criteria andFbmBillGenerateWayNotIn(List<Integer> values) {
            addCriterion("fbm_bill_generate_way not in", values, "fbmBillGenerateWay");
            return (Criteria) this;
        }

        public Criteria andFbmBillGenerateWayBetween(Integer value1, Integer value2) {
            addCriterion("fbm_bill_generate_way between", value1, value2, "fbmBillGenerateWay");
            return (Criteria) this;
        }

        public Criteria andFbmBillGenerateWayNotBetween(Integer value1, Integer value2) {
            addCriterion("fbm_bill_generate_way not between", value1, value2, "fbmBillGenerateWay");
            return (Criteria) this;
        }

        public Criteria andFbmBillCatoffTimeIsNull() {
            addCriterion("fbm_bill_catoff_time is null");
            return (Criteria) this;
        }

        public Criteria andFbmBillCatoffTimeIsNotNull() {
            addCriterion("fbm_bill_catoff_time is not null");
            return (Criteria) this;
        }

        public Criteria andFbmBillCatoffTimeEqualTo(Date value) {
            addCriterion("fbm_bill_catoff_time =", value, "fbmBillCatoffTime");
            return (Criteria) this;
        }

        public Criteria andFbmBillCatoffTimeNotEqualTo(Date value) {
            addCriterion("fbm_bill_catoff_time <>", value, "fbmBillCatoffTime");
            return (Criteria) this;
        }

        public Criteria andFbmBillCatoffTimeGreaterThan(Date value) {
            addCriterion("fbm_bill_catoff_time >", value, "fbmBillCatoffTime");
            return (Criteria) this;
        }

        public Criteria andFbmBillCatoffTimeGreaterThanOrEqualTo(Date value) {
            addCriterion("fbm_bill_catoff_time >=", value, "fbmBillCatoffTime");
            return (Criteria) this;
        }

        public Criteria andFbmBillCatoffTimeLessThan(Date value) {
            addCriterion("fbm_bill_catoff_time <", value, "fbmBillCatoffTime");
            return (Criteria) this;
        }

        public Criteria andFbmBillCatoffTimeLessThanOrEqualTo(Date value) {
            addCriterion("fbm_bill_catoff_time <=", value, "fbmBillCatoffTime");
            return (Criteria) this;
        }

        public Criteria andFbmBillCatoffTimeIn(List<Date> values) {
            addCriterion("fbm_bill_catoff_time in", values, "fbmBillCatoffTime");
            return (Criteria) this;
        }

        public Criteria andFbmBillCatoffTimeNotIn(List<Date> values) {
            addCriterion("fbm_bill_catoff_time not in", values, "fbmBillCatoffTime");
            return (Criteria) this;
        }

        public Criteria andFbmBillCatoffTimeBetween(Date value1, Date value2) {
            addCriterion("fbm_bill_catoff_time between", value1, value2, "fbmBillCatoffTime");
            return (Criteria) this;
        }

        public Criteria andFbmBillCatoffTimeNotBetween(Date value1, Date value2) {
            addCriterion("fbm_bill_catoff_time not between", value1, value2, "fbmBillCatoffTime");
            return (Criteria) this;
        }

        public Criteria andFbmAssociateCarIdIsNull() {
            addCriterion("fbm_associate_car_id is null");
            return (Criteria) this;
        }

        public Criteria andFbmAssociateCarIdIsNotNull() {
            addCriterion("fbm_associate_car_id is not null");
            return (Criteria) this;
        }

        public Criteria andFbmAssociateCarIdEqualTo(Long value) {
            addCriterion("fbm_associate_car_id =", value, "fbmAssociateCarId");
            return (Criteria) this;
        }

        public Criteria andFbmAssociateCarIdNotEqualTo(Long value) {
            addCriterion("fbm_associate_car_id <>", value, "fbmAssociateCarId");
            return (Criteria) this;
        }

        public Criteria andFbmAssociateCarIdGreaterThan(Long value) {
            addCriterion("fbm_associate_car_id >", value, "fbmAssociateCarId");
            return (Criteria) this;
        }

        public Criteria andFbmAssociateCarIdGreaterThanOrEqualTo(Long value) {
            addCriterion("fbm_associate_car_id >=", value, "fbmAssociateCarId");
            return (Criteria) this;
        }

        public Criteria andFbmAssociateCarIdLessThan(Long value) {
            addCriterion("fbm_associate_car_id <", value, "fbmAssociateCarId");
            return (Criteria) this;
        }

        public Criteria andFbmAssociateCarIdLessThanOrEqualTo(Long value) {
            addCriterion("fbm_associate_car_id <=", value, "fbmAssociateCarId");
            return (Criteria) this;
        }

        public Criteria andFbmAssociateCarIdIn(List<Long> values) {
            addCriterion("fbm_associate_car_id in", values, "fbmAssociateCarId");
            return (Criteria) this;
        }

        public Criteria andFbmAssociateCarIdNotIn(List<Long> values) {
            addCriterion("fbm_associate_car_id not in", values, "fbmAssociateCarId");
            return (Criteria) this;
        }

        public Criteria andFbmAssociateCarIdBetween(Long value1, Long value2) {
            addCriterion("fbm_associate_car_id between", value1, value2, "fbmAssociateCarId");
            return (Criteria) this;
        }

        public Criteria andFbmAssociateCarIdNotBetween(Long value1, Long value2) {
            addCriterion("fbm_associate_car_id not between", value1, value2, "fbmAssociateCarId");
            return (Criteria) this;
        }

        public Criteria andFbmAssociateContractIdIsNull() {
            addCriterion("fbm_associate_contract_id is null");
            return (Criteria) this;
        }

        public Criteria andFbmAssociateContractIdIsNotNull() {
            addCriterion("fbm_associate_contract_id is not null");
            return (Criteria) this;
        }

        public Criteria andFbmAssociateContractIdEqualTo(Long value) {
            addCriterion("fbm_associate_contract_id =", value, "fbmAssociateContractId");
            return (Criteria) this;
        }

        public Criteria andFbmAssociateContractIdNotEqualTo(Long value) {
            addCriterion("fbm_associate_contract_id <>", value, "fbmAssociateContractId");
            return (Criteria) this;
        }

        public Criteria andFbmAssociateContractIdGreaterThan(Long value) {
            addCriterion("fbm_associate_contract_id >", value, "fbmAssociateContractId");
            return (Criteria) this;
        }

        public Criteria andFbmAssociateContractIdGreaterThanOrEqualTo(Long value) {
            addCriterion("fbm_associate_contract_id >=", value, "fbmAssociateContractId");
            return (Criteria) this;
        }

        public Criteria andFbmAssociateContractIdLessThan(Long value) {
            addCriterion("fbm_associate_contract_id <", value, "fbmAssociateContractId");
            return (Criteria) this;
        }

        public Criteria andFbmAssociateContractIdLessThanOrEqualTo(Long value) {
            addCriterion("fbm_associate_contract_id <=", value, "fbmAssociateContractId");
            return (Criteria) this;
        }

        public Criteria andFbmAssociateContractIdIn(List<Long> values) {
            addCriterion("fbm_associate_contract_id in", values, "fbmAssociateContractId");
            return (Criteria) this;
        }

        public Criteria andFbmAssociateContractIdNotIn(List<Long> values) {
            addCriterion("fbm_associate_contract_id not in", values, "fbmAssociateContractId");
            return (Criteria) this;
        }

        public Criteria andFbmAssociateContractIdBetween(Long value1, Long value2) {
            addCriterion("fbm_associate_contract_id between", value1, value2, "fbmAssociateContractId");
            return (Criteria) this;
        }

        public Criteria andFbmAssociateContractIdNotBetween(Long value1, Long value2) {
            addCriterion("fbm_associate_contract_id not between", value1, value2, "fbmAssociateContractId");
            return (Criteria) this;
        }

        public Criteria andFbmBillStateIsNull() {
            addCriterion("fbm_bill_state is null");
            return (Criteria) this;
        }

        public Criteria andFbmBillStateIsNotNull() {
            addCriterion("fbm_bill_state is not null");
            return (Criteria) this;
        }

        public Criteria andFbmBillStateEqualTo(Integer value) {
            addCriterion("fbm_bill_state =", value, "fbmBillState");
            return (Criteria) this;
        }

        public Criteria andFbmBillStateNotEqualTo(Integer value) {
            addCriterion("fbm_bill_state <>", value, "fbmBillState");
            return (Criteria) this;
        }

        public Criteria andFbmBillStateGreaterThan(Integer value) {
            addCriterion("fbm_bill_state >", value, "fbmBillState");
            return (Criteria) this;
        }

        public Criteria andFbmBillStateGreaterThanOrEqualTo(Integer value) {
            addCriterion("fbm_bill_state >=", value, "fbmBillState");
            return (Criteria) this;
        }

        public Criteria andFbmBillStateLessThan(Integer value) {
            addCriterion("fbm_bill_state <", value, "fbmBillState");
            return (Criteria) this;
        }

        public Criteria andFbmBillStateLessThanOrEqualTo(Integer value) {
            addCriterion("fbm_bill_state <=", value, "fbmBillState");
            return (Criteria) this;
        }

        public Criteria andFbmBillStateIn(List<Integer> values) {
            addCriterion("fbm_bill_state in", values, "fbmBillState");
            return (Criteria) this;
        }

        public Criteria andFbmBillStateNotIn(List<Integer> values) {
            addCriterion("fbm_bill_state not in", values, "fbmBillState");
            return (Criteria) this;
        }

        public Criteria andFbmBillStateBetween(Integer value1, Integer value2) {
            addCriterion("fbm_bill_state between", value1, value2, "fbmBillState");
            return (Criteria) this;
        }

        public Criteria andFbmBillStateNotBetween(Integer value1, Integer value2) {
            addCriterion("fbm_bill_state not between", value1, value2, "fbmBillState");
            return (Criteria) this;
        }

        public Criteria andFbmMatchWayIsNull() {
            addCriterion("fbm_match_way is null");
            return (Criteria) this;
        }

        public Criteria andFbmMatchWayIsNotNull() {
            addCriterion("fbm_match_way is not null");
            return (Criteria) this;
        }

        public Criteria andFbmMatchWayEqualTo(Integer value) {
            addCriterion("fbm_match_way =", value, "fbmMatchWay");
            return (Criteria) this;
        }

        public Criteria andFbmMatchWayNotEqualTo(Integer value) {
            addCriterion("fbm_match_way <>", value, "fbmMatchWay");
            return (Criteria) this;
        }

        public Criteria andFbmMatchWayGreaterThan(Integer value) {
            addCriterion("fbm_match_way >", value, "fbmMatchWay");
            return (Criteria) this;
        }

        public Criteria andFbmMatchWayGreaterThanOrEqualTo(Integer value) {
            addCriterion("fbm_match_way >=", value, "fbmMatchWay");
            return (Criteria) this;
        }

        public Criteria andFbmMatchWayLessThan(Integer value) {
            addCriterion("fbm_match_way <", value, "fbmMatchWay");
            return (Criteria) this;
        }

        public Criteria andFbmMatchWayLessThanOrEqualTo(Integer value) {
            addCriterion("fbm_match_way <=", value, "fbmMatchWay");
            return (Criteria) this;
        }

        public Criteria andFbmMatchWayIn(List<Integer> values) {
            addCriterion("fbm_match_way in", values, "fbmMatchWay");
            return (Criteria) this;
        }

        public Criteria andFbmMatchWayNotIn(List<Integer> values) {
            addCriterion("fbm_match_way not in", values, "fbmMatchWay");
            return (Criteria) this;
        }

        public Criteria andFbmMatchWayBetween(Integer value1, Integer value2) {
            addCriterion("fbm_match_way between", value1, value2, "fbmMatchWay");
            return (Criteria) this;
        }

        public Criteria andFbmMatchWayNotBetween(Integer value1, Integer value2) {
            addCriterion("fbm_match_way not between", value1, value2, "fbmMatchWay");
            return (Criteria) this;
        }

        public Criteria andFbmMatchUserIdIsNull() {
            addCriterion("fbm_match_user_id is null");
            return (Criteria) this;
        }

        public Criteria andFbmMatchUserIdIsNotNull() {
            addCriterion("fbm_match_user_id is not null");
            return (Criteria) this;
        }

        public Criteria andFbmMatchUserIdEqualTo(Long value) {
            addCriterion("fbm_match_user_id =", value, "fbmMatchUserId");
            return (Criteria) this;
        }

        public Criteria andFbmMatchUserIdNotEqualTo(Long value) {
            addCriterion("fbm_match_user_id <>", value, "fbmMatchUserId");
            return (Criteria) this;
        }

        public Criteria andFbmMatchUserIdGreaterThan(Long value) {
            addCriterion("fbm_match_user_id >", value, "fbmMatchUserId");
            return (Criteria) this;
        }

        public Criteria andFbmMatchUserIdGreaterThanOrEqualTo(Long value) {
            addCriterion("fbm_match_user_id >=", value, "fbmMatchUserId");
            return (Criteria) this;
        }

        public Criteria andFbmMatchUserIdLessThan(Long value) {
            addCriterion("fbm_match_user_id <", value, "fbmMatchUserId");
            return (Criteria) this;
        }

        public Criteria andFbmMatchUserIdLessThanOrEqualTo(Long value) {
            addCriterion("fbm_match_user_id <=", value, "fbmMatchUserId");
            return (Criteria) this;
        }

        public Criteria andFbmMatchUserIdIn(List<Long> values) {
            addCriterion("fbm_match_user_id in", values, "fbmMatchUserId");
            return (Criteria) this;
        }

        public Criteria andFbmMatchUserIdNotIn(List<Long> values) {
            addCriterion("fbm_match_user_id not in", values, "fbmMatchUserId");
            return (Criteria) this;
        }

        public Criteria andFbmMatchUserIdBetween(Long value1, Long value2) {
            addCriterion("fbm_match_user_id between", value1, value2, "fbmMatchUserId");
            return (Criteria) this;
        }

        public Criteria andFbmMatchUserIdNotBetween(Long value1, Long value2) {
            addCriterion("fbm_match_user_id not between", value1, value2, "fbmMatchUserId");
            return (Criteria) this;
        }

        public Criteria andFbmMatchTimeIsNull() {
            addCriterion("fbm_match_time is null");
            return (Criteria) this;
        }

        public Criteria andFbmMatchTimeIsNotNull() {
            addCriterion("fbm_match_time is not null");
            return (Criteria) this;
        }

        public Criteria andFbmMatchTimeEqualTo(Date value) {
            addCriterion("fbm_match_time =", value, "fbmMatchTime");
            return (Criteria) this;
        }

        public Criteria andFbmMatchTimeNotEqualTo(Date value) {
            addCriterion("fbm_match_time <>", value, "fbmMatchTime");
            return (Criteria) this;
        }

        public Criteria andFbmMatchTimeGreaterThan(Date value) {
            addCriterion("fbm_match_time >", value, "fbmMatchTime");
            return (Criteria) this;
        }

        public Criteria andFbmMatchTimeGreaterThanOrEqualTo(Date value) {
            addCriterion("fbm_match_time >=", value, "fbmMatchTime");
            return (Criteria) this;
        }

        public Criteria andFbmMatchTimeLessThan(Date value) {
            addCriterion("fbm_match_time <", value, "fbmMatchTime");
            return (Criteria) this;
        }

        public Criteria andFbmMatchTimeLessThanOrEqualTo(Date value) {
            addCriterion("fbm_match_time <=", value, "fbmMatchTime");
            return (Criteria) this;
        }

        public Criteria andFbmMatchTimeIn(List<Date> values) {
            addCriterion("fbm_match_time in", values, "fbmMatchTime");
            return (Criteria) this;
        }

        public Criteria andFbmMatchTimeNotIn(List<Date> values) {
            addCriterion("fbm_match_time not in", values, "fbmMatchTime");
            return (Criteria) this;
        }

        public Criteria andFbmMatchTimeBetween(Date value1, Date value2) {
            addCriterion("fbm_match_time between", value1, value2, "fbmMatchTime");
            return (Criteria) this;
        }

        public Criteria andFbmMatchTimeNotBetween(Date value1, Date value2) {
            addCriterion("fbm_match_time not between", value1, value2, "fbmMatchTime");
            return (Criteria) this;
        }

        public Criteria andFbmMatchSerialNumberIsNull() {
            addCriterion("fbm_match_serial_number is null");
            return (Criteria) this;
        }

        public Criteria andFbmMatchSerialNumberIsNotNull() {
            addCriterion("fbm_match_serial_number is not null");
            return (Criteria) this;
        }

        public Criteria andFbmMatchSerialNumberEqualTo(String value) {
            addCriterion("fbm_match_serial_number =", value, "fbmMatchSerialNumber");
            return (Criteria) this;
        }

        public Criteria andFbmMatchSerialNumberNotEqualTo(String value) {
            addCriterion("fbm_match_serial_number <>", value, "fbmMatchSerialNumber");
            return (Criteria) this;
        }

        public Criteria andFbmMatchSerialNumberGreaterThan(String value) {
            addCriterion("fbm_match_serial_number >", value, "fbmMatchSerialNumber");
            return (Criteria) this;
        }

        public Criteria andFbmMatchSerialNumberGreaterThanOrEqualTo(String value) {
            addCriterion("fbm_match_serial_number >=", value, "fbmMatchSerialNumber");
            return (Criteria) this;
        }

        public Criteria andFbmMatchSerialNumberLessThan(String value) {
            addCriterion("fbm_match_serial_number <", value, "fbmMatchSerialNumber");
            return (Criteria) this;
        }

        public Criteria andFbmMatchSerialNumberLessThanOrEqualTo(String value) {
            addCriterion("fbm_match_serial_number <=", value, "fbmMatchSerialNumber");
            return (Criteria) this;
        }

        public Criteria andFbmMatchSerialNumberLike(String value) {
            addCriterion("fbm_match_serial_number like", value, "fbmMatchSerialNumber");
            return (Criteria) this;
        }

        public Criteria andFbmMatchSerialNumberNotLike(String value) {
            addCriterion("fbm_match_serial_number not like", value, "fbmMatchSerialNumber");
            return (Criteria) this;
        }

        public Criteria andFbmMatchSerialNumberIn(List<String> values) {
            addCriterion("fbm_match_serial_number in", values, "fbmMatchSerialNumber");
            return (Criteria) this;
        }

        public Criteria andFbmMatchSerialNumberNotIn(List<String> values) {
            addCriterion("fbm_match_serial_number not in", values, "fbmMatchSerialNumber");
            return (Criteria) this;
        }

        public Criteria andFbmMatchSerialNumberBetween(String value1, String value2) {
            addCriterion("fbm_match_serial_number between", value1, value2, "fbmMatchSerialNumber");
            return (Criteria) this;
        }

        public Criteria andFbmMatchSerialNumberNotBetween(String value1, String value2) {
            addCriterion("fbm_match_serial_number not between", value1, value2, "fbmMatchSerialNumber");
            return (Criteria) this;
        }

        public Criteria andFbmPayTimeIsNull() {
            addCriterion("fbm_pay_time is null");
            return (Criteria) this;
        }

        public Criteria andFbmPayTimeIsNotNull() {
            addCriterion("fbm_pay_time is not null");
            return (Criteria) this;
        }

        public Criteria andFbmPayTimeEqualTo(Date value) {
            addCriterion("fbm_pay_time =", value, "fbmPayTime");
            return (Criteria) this;
        }

        public Criteria andFbmPayTimeNotEqualTo(Date value) {
            addCriterion("fbm_pay_time <>", value, "fbmPayTime");
            return (Criteria) this;
        }

        public Criteria andFbmPayTimeGreaterThan(Date value) {
            addCriterion("fbm_pay_time >", value, "fbmPayTime");
            return (Criteria) this;
        }

        public Criteria andFbmPayTimeGreaterThanOrEqualTo(Date value) {
            addCriterion("fbm_pay_time >=", value, "fbmPayTime");
            return (Criteria) this;
        }

        public Criteria andFbmPayTimeLessThan(Date value) {
            addCriterion("fbm_pay_time <", value, "fbmPayTime");
            return (Criteria) this;
        }

        public Criteria andFbmPayTimeLessThanOrEqualTo(Date value) {
            addCriterion("fbm_pay_time <=", value, "fbmPayTime");
            return (Criteria) this;
        }

        public Criteria andFbmPayTimeIn(List<Date> values) {
            addCriterion("fbm_pay_time in", values, "fbmPayTime");
            return (Criteria) this;
        }

        public Criteria andFbmPayTimeNotIn(List<Date> values) {
            addCriterion("fbm_pay_time not in", values, "fbmPayTime");
            return (Criteria) this;
        }

        public Criteria andFbmPayTimeBetween(Date value1, Date value2) {
            addCriterion("fbm_pay_time between", value1, value2, "fbmPayTime");
            return (Criteria) this;
        }

        public Criteria andFbmPayTimeNotBetween(Date value1, Date value2) {
            addCriterion("fbm_pay_time not between", value1, value2, "fbmPayTime");
            return (Criteria) this;
        }

        public Criteria andFbmMatchedAmountIsNull() {
            addCriterion("fbm_matched_amount is null");
            return (Criteria) this;
        }

        public Criteria andFbmMatchedAmountIsNotNull() {
            addCriterion("fbm_matched_amount is not null");
            return (Criteria) this;
        }

        public Criteria andFbmMatchedAmountEqualTo(Double value) {
            addCriterion("fbm_matched_amount =", value, "fbmMatchedAmount");
            return (Criteria) this;
        }

        public Criteria andFbmMatchedAmountNotEqualTo(Double value) {
            addCriterion("fbm_matched_amount <>", value, "fbmMatchedAmount");
            return (Criteria) this;
        }

        public Criteria andFbmMatchedAmountGreaterThan(Double value) {
            addCriterion("fbm_matched_amount >", value, "fbmMatchedAmount");
            return (Criteria) this;
        }

        public Criteria andFbmMatchedAmountGreaterThanOrEqualTo(Double value) {
            addCriterion("fbm_matched_amount >=", value, "fbmMatchedAmount");
            return (Criteria) this;
        }

        public Criteria andFbmMatchedAmountLessThan(Double value) {
            addCriterion("fbm_matched_amount <", value, "fbmMatchedAmount");
            return (Criteria) this;
        }

        public Criteria andFbmMatchedAmountLessThanOrEqualTo(Double value) {
            addCriterion("fbm_matched_amount <=", value, "fbmMatchedAmount");
            return (Criteria) this;
        }

        public Criteria andFbmMatchedAmountIn(List<Double> values) {
            addCriterion("fbm_matched_amount in", values, "fbmMatchedAmount");
            return (Criteria) this;
        }

        public Criteria andFbmMatchedAmountNotIn(List<Double> values) {
            addCriterion("fbm_matched_amount not in", values, "fbmMatchedAmount");
            return (Criteria) this;
        }

        public Criteria andFbmMatchedAmountBetween(Double value1, Double value2) {
            addCriterion("fbm_matched_amount between", value1, value2, "fbmMatchedAmount");
            return (Criteria) this;
        }

        public Criteria andFbmMatchedAmountNotBetween(Double value1, Double value2) {
            addCriterion("fbm_matched_amount not between", value1, value2, "fbmMatchedAmount");
            return (Criteria) this;
        }

        public Criteria andFbmNotMatchAmountIsNull() {
            addCriterion("fbm_not_match_amount is null");
            return (Criteria) this;
        }

        public Criteria andFbmNotMatchAmountIsNotNull() {
            addCriterion("fbm_not_match_amount is not null");
            return (Criteria) this;
        }

        public Criteria andFbmNotMatchAmountEqualTo(Double value) {
            addCriterion("fbm_not_match_amount =", value, "fbmNotMatchAmount");
            return (Criteria) this;
        }

        public Criteria andFbmNotMatchAmountNotEqualTo(Double value) {
            addCriterion("fbm_not_match_amount <>", value, "fbmNotMatchAmount");
            return (Criteria) this;
        }

        public Criteria andFbmNotMatchAmountGreaterThan(Double value) {
            addCriterion("fbm_not_match_amount >", value, "fbmNotMatchAmount");
            return (Criteria) this;
        }

        public Criteria andFbmNotMatchAmountGreaterThanOrEqualTo(Double value) {
            addCriterion("fbm_not_match_amount >=", value, "fbmNotMatchAmount");
            return (Criteria) this;
        }

        public Criteria andFbmNotMatchAmountLessThan(Double value) {
            addCriterion("fbm_not_match_amount <", value, "fbmNotMatchAmount");
            return (Criteria) this;
        }

        public Criteria andFbmNotMatchAmountLessThanOrEqualTo(Double value) {
            addCriterion("fbm_not_match_amount <=", value, "fbmNotMatchAmount");
            return (Criteria) this;
        }

        public Criteria andFbmNotMatchAmountIn(List<Double> values) {
            addCriterion("fbm_not_match_amount in", values, "fbmNotMatchAmount");
            return (Criteria) this;
        }

        public Criteria andFbmNotMatchAmountNotIn(List<Double> values) {
            addCriterion("fbm_not_match_amount not in", values, "fbmNotMatchAmount");
            return (Criteria) this;
        }

        public Criteria andFbmNotMatchAmountBetween(Double value1, Double value2) {
            addCriterion("fbm_not_match_amount between", value1, value2, "fbmNotMatchAmount");
            return (Criteria) this;
        }

        public Criteria andFbmNotMatchAmountNotBetween(Double value1, Double value2) {
            addCriterion("fbm_not_match_amount not between", value1, value2, "fbmNotMatchAmount");
            return (Criteria) this;
        }

        public Criteria andFbmBillGenerateReasonIsNull() {
            addCriterion("fbm_bill_generate_reason is null");
            return (Criteria) this;
        }

        public Criteria andFbmBillGenerateReasonIsNotNull() {
            addCriterion("fbm_bill_generate_reason is not null");
            return (Criteria) this;
        }

        public Criteria andFbmBillGenerateReasonEqualTo(String value) {
            addCriterion("fbm_bill_generate_reason =", value, "fbmBillGenerateReason");
            return (Criteria) this;
        }

        public Criteria andFbmBillGenerateReasonNotEqualTo(String value) {
            addCriterion("fbm_bill_generate_reason <>", value, "fbmBillGenerateReason");
            return (Criteria) this;
        }

        public Criteria andFbmBillGenerateReasonGreaterThan(String value) {
            addCriterion("fbm_bill_generate_reason >", value, "fbmBillGenerateReason");
            return (Criteria) this;
        }

        public Criteria andFbmBillGenerateReasonGreaterThanOrEqualTo(String value) {
            addCriterion("fbm_bill_generate_reason >=", value, "fbmBillGenerateReason");
            return (Criteria) this;
        }

        public Criteria andFbmBillGenerateReasonLessThan(String value) {
            addCriterion("fbm_bill_generate_reason <", value, "fbmBillGenerateReason");
            return (Criteria) this;
        }

        public Criteria andFbmBillGenerateReasonLessThanOrEqualTo(String value) {
            addCriterion("fbm_bill_generate_reason <=", value, "fbmBillGenerateReason");
            return (Criteria) this;
        }

        public Criteria andFbmBillGenerateReasonLike(String value) {
            addCriterion("fbm_bill_generate_reason like", value, "fbmBillGenerateReason");
            return (Criteria) this;
        }

        public Criteria andFbmBillGenerateReasonNotLike(String value) {
            addCriterion("fbm_bill_generate_reason not like", value, "fbmBillGenerateReason");
            return (Criteria) this;
        }

        public Criteria andFbmBillGenerateReasonIn(List<String> values) {
            addCriterion("fbm_bill_generate_reason in", values, "fbmBillGenerateReason");
            return (Criteria) this;
        }

        public Criteria andFbmBillGenerateReasonNotIn(List<String> values) {
            addCriterion("fbm_bill_generate_reason not in", values, "fbmBillGenerateReason");
            return (Criteria) this;
        }

        public Criteria andFbmBillGenerateReasonBetween(String value1, String value2) {
            addCriterion("fbm_bill_generate_reason between", value1, value2, "fbmBillGenerateReason");
            return (Criteria) this;
        }

        public Criteria andFbmBillGenerateReasonNotBetween(String value1, String value2) {
            addCriterion("fbm_bill_generate_reason not between", value1, value2, "fbmBillGenerateReason");
            return (Criteria) this;
        }

        public Criteria andFbmBillVoucherIsNull() {
            addCriterion("fbm_bill_voucher is null");
            return (Criteria) this;
        }

        public Criteria andFbmBillVoucherIsNotNull() {
            addCriterion("fbm_bill_voucher is not null");
            return (Criteria) this;
        }

        public Criteria andFbmBillVoucherEqualTo(String value) {
            addCriterion("fbm_bill_voucher =", value, "fbmBillVoucher");
            return (Criteria) this;
        }

        public Criteria andFbmBillVoucherNotEqualTo(String value) {
            addCriterion("fbm_bill_voucher <>", value, "fbmBillVoucher");
            return (Criteria) this;
        }

        public Criteria andFbmBillVoucherGreaterThan(String value) {
            addCriterion("fbm_bill_voucher >", value, "fbmBillVoucher");
            return (Criteria) this;
        }

        public Criteria andFbmBillVoucherGreaterThanOrEqualTo(String value) {
            addCriterion("fbm_bill_voucher >=", value, "fbmBillVoucher");
            return (Criteria) this;
        }

        public Criteria andFbmBillVoucherLessThan(String value) {
            addCriterion("fbm_bill_voucher <", value, "fbmBillVoucher");
            return (Criteria) this;
        }

        public Criteria andFbmBillVoucherLessThanOrEqualTo(String value) {
            addCriterion("fbm_bill_voucher <=", value, "fbmBillVoucher");
            return (Criteria) this;
        }

        public Criteria andFbmBillVoucherLike(String value) {
            addCriterion("fbm_bill_voucher like", value, "fbmBillVoucher");
            return (Criteria) this;
        }

        public Criteria andFbmBillVoucherNotLike(String value) {
            addCriterion("fbm_bill_voucher not like", value, "fbmBillVoucher");
            return (Criteria) this;
        }

        public Criteria andFbmBillVoucherIn(List<String> values) {
            addCriterion("fbm_bill_voucher in", values, "fbmBillVoucher");
            return (Criteria) this;
        }

        public Criteria andFbmBillVoucherNotIn(List<String> values) {
            addCriterion("fbm_bill_voucher not in", values, "fbmBillVoucher");
            return (Criteria) this;
        }

        public Criteria andFbmBillVoucherBetween(String value1, String value2) {
            addCriterion("fbm_bill_voucher between", value1, value2, "fbmBillVoucher");
            return (Criteria) this;
        }

        public Criteria andFbmBillVoucherNotBetween(String value1, String value2) {
            addCriterion("fbm_bill_voucher not between", value1, value2, "fbmBillVoucher");
            return (Criteria) this;
        }

        public Criteria andFbmTurnerDealIsNull() {
            addCriterion("fbm_turner_deal is null");
            return (Criteria) this;
        }

        public Criteria andFbmTurnerDealIsNotNull() {
            addCriterion("fbm_turner_deal is not null");
            return (Criteria) this;
        }

        public Criteria andFbmTurnerDealEqualTo(Integer value) {
            addCriterion("fbm_turner_deal =", value, "fbmTurnerDeal");
            return (Criteria) this;
        }

        public Criteria andFbmTurnerDealNotEqualTo(Integer value) {
            addCriterion("fbm_turner_deal <>", value, "fbmTurnerDeal");
            return (Criteria) this;
        }

        public Criteria andFbmTurnerDealGreaterThan(Integer value) {
            addCriterion("fbm_turner_deal >", value, "fbmTurnerDeal");
            return (Criteria) this;
        }

        public Criteria andFbmTurnerDealGreaterThanOrEqualTo(Integer value) {
            addCriterion("fbm_turner_deal >=", value, "fbmTurnerDeal");
            return (Criteria) this;
        }

        public Criteria andFbmTurnerDealLessThan(Integer value) {
            addCriterion("fbm_turner_deal <", value, "fbmTurnerDeal");
            return (Criteria) this;
        }

        public Criteria andFbmTurnerDealLessThanOrEqualTo(Integer value) {
            addCriterion("fbm_turner_deal <=", value, "fbmTurnerDeal");
            return (Criteria) this;
        }

        public Criteria andFbmTurnerDealIn(List<Integer> values) {
            addCriterion("fbm_turner_deal in", values, "fbmTurnerDeal");
            return (Criteria) this;
        }

        public Criteria andFbmTurnerDealNotIn(List<Integer> values) {
            addCriterion("fbm_turner_deal not in", values, "fbmTurnerDeal");
            return (Criteria) this;
        }

        public Criteria andFbmTurnerDealBetween(Integer value1, Integer value2) {
            addCriterion("fbm_turner_deal between", value1, value2, "fbmTurnerDeal");
            return (Criteria) this;
        }

        public Criteria andFbmTurnerDealNotBetween(Integer value1, Integer value2) {
            addCriterion("fbm_turner_deal not between", value1, value2, "fbmTurnerDeal");
            return (Criteria) this;
        }

        public Criteria andFbmCarIdIsNull() {
            addCriterion("fbm_car_id is null");
            return (Criteria) this;
        }

        public Criteria andFbmCarIdIsNotNull() {
            addCriterion("fbm_car_id is not null");
            return (Criteria) this;
        }

        public Criteria andFbmCarIdEqualTo(Long value) {
            addCriterion("fbm_car_id =", value, "fbmCarId");
            return (Criteria) this;
        }

        public Criteria andFbmCarIdNotEqualTo(Long value) {
            addCriterion("fbm_car_id <>", value, "fbmCarId");
            return (Criteria) this;
        }

        public Criteria andFbmCarIdGreaterThan(Long value) {
            addCriterion("fbm_car_id >", value, "fbmCarId");
            return (Criteria) this;
        }

        public Criteria andFbmCarIdGreaterThanOrEqualTo(Long value) {
            addCriterion("fbm_car_id >=", value, "fbmCarId");
            return (Criteria) this;
        }

        public Criteria andFbmCarIdLessThan(Long value) {
            addCriterion("fbm_car_id <", value, "fbmCarId");
            return (Criteria) this;
        }

        public Criteria andFbmCarIdLessThanOrEqualTo(Long value) {
            addCriterion("fbm_car_id <=", value, "fbmCarId");
            return (Criteria) this;
        }

        public Criteria andFbmCarIdIn(List<Long> values) {
            addCriterion("fbm_car_id in", values, "fbmCarId");
            return (Criteria) this;
        }

        public Criteria andFbmCarIdNotIn(List<Long> values) {
            addCriterion("fbm_car_id not in", values, "fbmCarId");
            return (Criteria) this;
        }

        public Criteria andFbmCarIdBetween(Long value1, Long value2) {
            addCriterion("fbm_car_id between", value1, value2, "fbmCarId");
            return (Criteria) this;
        }

        public Criteria andFbmCarIdNotBetween(Long value1, Long value2) {
            addCriterion("fbm_car_id not between", value1, value2, "fbmCarId");
            return (Criteria) this;
        }

        public Criteria andFbmContractIdIsNull() {
            addCriterion("fbm_contract_id is null");
            return (Criteria) this;
        }

        public Criteria andFbmContractIdIsNotNull() {
            addCriterion("fbm_contract_id is not null");
            return (Criteria) this;
        }

        public Criteria andFbmContractIdEqualTo(Long value) {
            addCriterion("fbm_contract_id =", value, "fbmContractId");
            return (Criteria) this;
        }

        public Criteria andFbmContractIdNotEqualTo(Long value) {
            addCriterion("fbm_contract_id <>", value, "fbmContractId");
            return (Criteria) this;
        }

        public Criteria andFbmContractIdGreaterThan(Long value) {
            addCriterion("fbm_contract_id >", value, "fbmContractId");
            return (Criteria) this;
        }

        public Criteria andFbmContractIdGreaterThanOrEqualTo(Long value) {
            addCriterion("fbm_contract_id >=", value, "fbmContractId");
            return (Criteria) this;
        }

        public Criteria andFbmContractIdLessThan(Long value) {
            addCriterion("fbm_contract_id <", value, "fbmContractId");
            return (Criteria) this;
        }

        public Criteria andFbmContractIdLessThanOrEqualTo(Long value) {
            addCriterion("fbm_contract_id <=", value, "fbmContractId");
            return (Criteria) this;
        }

        public Criteria andFbmContractIdIn(List<Long> values) {
            addCriterion("fbm_contract_id in", values, "fbmContractId");
            return (Criteria) this;
        }

        public Criteria andFbmContractIdNotIn(List<Long> values) {
            addCriterion("fbm_contract_id not in", values, "fbmContractId");
            return (Criteria) this;
        }

        public Criteria andFbmContractIdBetween(Long value1, Long value2) {
            addCriterion("fbm_contract_id between", value1, value2, "fbmContractId");
            return (Criteria) this;
        }

        public Criteria andFbmContractIdNotBetween(Long value1, Long value2) {
            addCriterion("fbm_contract_id not between", value1, value2, "fbmContractId");
            return (Criteria) this;
        }

        public Criteria andFbmLeasePeriodIsNull() {
            addCriterion("fbm_lease_period is null");
            return (Criteria) this;
        }

        public Criteria andFbmLeasePeriodIsNotNull() {
            addCriterion("fbm_lease_period is not null");
            return (Criteria) this;
        }

        public Criteria andFbmLeasePeriodEqualTo(Date value) {
            addCriterion("fbm_lease_period =", value, "fbmLeasePeriod");
            return (Criteria) this;
        }

        public Criteria andFbmLeasePeriodNotEqualTo(Date value) {
            addCriterion("fbm_lease_period <>", value, "fbmLeasePeriod");
            return (Criteria) this;
        }

        public Criteria andFbmLeasePeriodGreaterThan(Date value) {
            addCriterion("fbm_lease_period >", value, "fbmLeasePeriod");
            return (Criteria) this;
        }

        public Criteria andFbmLeasePeriodGreaterThanOrEqualTo(Date value) {
            addCriterion("fbm_lease_period >=", value, "fbmLeasePeriod");
            return (Criteria) this;
        }

        public Criteria andFbmLeasePeriodLessThan(Date value) {
            addCriterion("fbm_lease_period <", value, "fbmLeasePeriod");
            return (Criteria) this;
        }

        public Criteria andFbmLeasePeriodLessThanOrEqualTo(Date value) {
            addCriterion("fbm_lease_period <=", value, "fbmLeasePeriod");
            return (Criteria) this;
        }

        public Criteria andFbmLeasePeriodIn(List<Date> values) {
            addCriterion("fbm_lease_period in", values, "fbmLeasePeriod");
            return (Criteria) this;
        }

        public Criteria andFbmLeasePeriodNotIn(List<Date> values) {
            addCriterion("fbm_lease_period not in", values, "fbmLeasePeriod");
            return (Criteria) this;
        }

        public Criteria andFbmLeasePeriodBetween(Date value1, Date value2) {
            addCriterion("fbm_lease_period between", value1, value2, "fbmLeasePeriod");
            return (Criteria) this;
        }

        public Criteria andFbmLeasePeriodNotBetween(Date value1, Date value2) {
            addCriterion("fbm_lease_period not between", value1, value2, "fbmLeasePeriod");
            return (Criteria) this;
        }

        public Criteria andFbmBreaksAmountIsNull() {
            addCriterion("fbm_breaks_amount is null");
            return (Criteria) this;
        }

        public Criteria andFbmBreaksAmountIsNotNull() {
            addCriterion("fbm_breaks_amount is not null");
            return (Criteria) this;
        }

        public Criteria andFbmBreaksAmountEqualTo(Double value) {
            addCriterion("fbm_breaks_amount =", value, "fbmBreaksAmount");
            return (Criteria) this;
        }

        public Criteria andFbmBreaksAmountNotEqualTo(Double value) {
            addCriterion("fbm_breaks_amount <>", value, "fbmBreaksAmount");
            return (Criteria) this;
        }

        public Criteria andFbmBreaksAmountGreaterThan(Double value) {
            addCriterion("fbm_breaks_amount >", value, "fbmBreaksAmount");
            return (Criteria) this;
        }

        public Criteria andFbmBreaksAmountGreaterThanOrEqualTo(Double value) {
            addCriterion("fbm_breaks_amount >=", value, "fbmBreaksAmount");
            return (Criteria) this;
        }

        public Criteria andFbmBreaksAmountLessThan(Double value) {
            addCriterion("fbm_breaks_amount <", value, "fbmBreaksAmount");
            return (Criteria) this;
        }

        public Criteria andFbmBreaksAmountLessThanOrEqualTo(Double value) {
            addCriterion("fbm_breaks_amount <=", value, "fbmBreaksAmount");
            return (Criteria) this;
        }

        public Criteria andFbmBreaksAmountIn(List<Double> values) {
            addCriterion("fbm_breaks_amount in", values, "fbmBreaksAmount");
            return (Criteria) this;
        }

        public Criteria andFbmBreaksAmountNotIn(List<Double> values) {
            addCriterion("fbm_breaks_amount not in", values, "fbmBreaksAmount");
            return (Criteria) this;
        }

        public Criteria andFbmBreaksAmountBetween(Double value1, Double value2) {
            addCriterion("fbm_breaks_amount between", value1, value2, "fbmBreaksAmount");
            return (Criteria) this;
        }

        public Criteria andFbmBreaksAmountNotBetween(Double value1, Double value2) {
            addCriterion("fbm_breaks_amount not between", value1, value2, "fbmBreaksAmount");
            return (Criteria) this;
        }

        public Criteria andFbmBreaksTypeIsNull() {
            addCriterion("fbm_breaks_type is null");
            return (Criteria) this;
        }

        public Criteria andFbmBreaksTypeIsNotNull() {
            addCriterion("fbm_breaks_type is not null");
            return (Criteria) this;
        }

        public Criteria andFbmBreaksTypeEqualTo(Integer value) {
            addCriterion("fbm_breaks_type =", value, "fbmBreaksType");
            return (Criteria) this;
        }

        public Criteria andFbmBreaksTypeNotEqualTo(Integer value) {
            addCriterion("fbm_breaks_type <>", value, "fbmBreaksType");
            return (Criteria) this;
        }

        public Criteria andFbmBreaksTypeGreaterThan(Integer value) {
            addCriterion("fbm_breaks_type >", value, "fbmBreaksType");
            return (Criteria) this;
        }

        public Criteria andFbmBreaksTypeGreaterThanOrEqualTo(Integer value) {
            addCriterion("fbm_breaks_type >=", value, "fbmBreaksType");
            return (Criteria) this;
        }

        public Criteria andFbmBreaksTypeLessThan(Integer value) {
            addCriterion("fbm_breaks_type <", value, "fbmBreaksType");
            return (Criteria) this;
        }

        public Criteria andFbmBreaksTypeLessThanOrEqualTo(Integer value) {
            addCriterion("fbm_breaks_type <=", value, "fbmBreaksType");
            return (Criteria) this;
        }

        public Criteria andFbmBreaksTypeIn(List<Integer> values) {
            addCriterion("fbm_breaks_type in", values, "fbmBreaksType");
            return (Criteria) this;
        }

        public Criteria andFbmBreaksTypeNotIn(List<Integer> values) {
            addCriterion("fbm_breaks_type not in", values, "fbmBreaksType");
            return (Criteria) this;
        }

        public Criteria andFbmBreaksTypeBetween(Integer value1, Integer value2) {
            addCriterion("fbm_breaks_type between", value1, value2, "fbmBreaksType");
            return (Criteria) this;
        }

        public Criteria andFbmBreaksTypeNotBetween(Integer value1, Integer value2) {
            addCriterion("fbm_breaks_type not between", value1, value2, "fbmBreaksType");
            return (Criteria) this;
        }

        public Criteria andFbmBreaksRemarkIsNull() {
            addCriterion("fbm_breaks_remark is null");
            return (Criteria) this;
        }

        public Criteria andFbmBreaksRemarkIsNotNull() {
            addCriterion("fbm_breaks_remark is not null");
            return (Criteria) this;
        }

        public Criteria andFbmBreaksRemarkEqualTo(String value) {
            addCriterion("fbm_breaks_remark =", value, "fbmBreaksRemark");
            return (Criteria) this;
        }

        public Criteria andFbmBreaksRemarkNotEqualTo(String value) {
            addCriterion("fbm_breaks_remark <>", value, "fbmBreaksRemark");
            return (Criteria) this;
        }

        public Criteria andFbmBreaksRemarkGreaterThan(String value) {
            addCriterion("fbm_breaks_remark >", value, "fbmBreaksRemark");
            return (Criteria) this;
        }

        public Criteria andFbmBreaksRemarkGreaterThanOrEqualTo(String value) {
            addCriterion("fbm_breaks_remark >=", value, "fbmBreaksRemark");
            return (Criteria) this;
        }

        public Criteria andFbmBreaksRemarkLessThan(String value) {
            addCriterion("fbm_breaks_remark <", value, "fbmBreaksRemark");
            return (Criteria) this;
        }

        public Criteria andFbmBreaksRemarkLessThanOrEqualTo(String value) {
            addCriterion("fbm_breaks_remark <=", value, "fbmBreaksRemark");
            return (Criteria) this;
        }

        public Criteria andFbmBreaksRemarkLike(String value) {
            addCriterion("fbm_breaks_remark like", value, "fbmBreaksRemark");
            return (Criteria) this;
        }

        public Criteria andFbmBreaksRemarkNotLike(String value) {
            addCriterion("fbm_breaks_remark not like", value, "fbmBreaksRemark");
            return (Criteria) this;
        }

        public Criteria andFbmBreaksRemarkIn(List<String> values) {
            addCriterion("fbm_breaks_remark in", values, "fbmBreaksRemark");
            return (Criteria) this;
        }

        public Criteria andFbmBreaksRemarkNotIn(List<String> values) {
            addCriterion("fbm_breaks_remark not in", values, "fbmBreaksRemark");
            return (Criteria) this;
        }

        public Criteria andFbmBreaksRemarkBetween(String value1, String value2) {
            addCriterion("fbm_breaks_remark between", value1, value2, "fbmBreaksRemark");
            return (Criteria) this;
        }

        public Criteria andFbmBreaksRemarkNotBetween(String value1, String value2) {
            addCriterion("fbm_breaks_remark not between", value1, value2, "fbmBreaksRemark");
            return (Criteria) this;
        }

        public Criteria andFbmBreaksAfterAmountIsNull() {
            addCriterion("fbm_breaks_after_amount is null");
            return (Criteria) this;
        }

        public Criteria andFbmBreaksAfterAmountIsNotNull() {
            addCriterion("fbm_breaks_after_amount is not null");
            return (Criteria) this;
        }

        public Criteria andFbmBreaksAfterAmountEqualTo(Double value) {
            addCriterion("fbm_breaks_after_amount =", value, "fbmBreaksAfterAmount");
            return (Criteria) this;
        }

        public Criteria andFbmBreaksAfterAmountNotEqualTo(Double value) {
            addCriterion("fbm_breaks_after_amount <>", value, "fbmBreaksAfterAmount");
            return (Criteria) this;
        }

        public Criteria andFbmBreaksAfterAmountGreaterThan(Double value) {
            addCriterion("fbm_breaks_after_amount >", value, "fbmBreaksAfterAmount");
            return (Criteria) this;
        }

        public Criteria andFbmBreaksAfterAmountGreaterThanOrEqualTo(Double value) {
            addCriterion("fbm_breaks_after_amount >=", value, "fbmBreaksAfterAmount");
            return (Criteria) this;
        }

        public Criteria andFbmBreaksAfterAmountLessThan(Double value) {
            addCriterion("fbm_breaks_after_amount <", value, "fbmBreaksAfterAmount");
            return (Criteria) this;
        }

        public Criteria andFbmBreaksAfterAmountLessThanOrEqualTo(Double value) {
            addCriterion("fbm_breaks_after_amount <=", value, "fbmBreaksAfterAmount");
            return (Criteria) this;
        }

        public Criteria andFbmBreaksAfterAmountIn(List<Double> values) {
            addCriterion("fbm_breaks_after_amount in", values, "fbmBreaksAfterAmount");
            return (Criteria) this;
        }

        public Criteria andFbmBreaksAfterAmountNotIn(List<Double> values) {
            addCriterion("fbm_breaks_after_amount not in", values, "fbmBreaksAfterAmount");
            return (Criteria) this;
        }

        public Criteria andFbmBreaksAfterAmountBetween(Double value1, Double value2) {
            addCriterion("fbm_breaks_after_amount between", value1, value2, "fbmBreaksAfterAmount");
            return (Criteria) this;
        }

        public Criteria andFbmBreaksAfterAmountNotBetween(Double value1, Double value2) {
            addCriterion("fbm_breaks_after_amount not between", value1, value2, "fbmBreaksAfterAmount");
            return (Criteria) this;
        }

        public Criteria andFbmBreaksPhoneIsNull() {
            addCriterion("fbm_breaks_phone is null");
            return (Criteria) this;
        }

        public Criteria andFbmBreaksPhoneIsNotNull() {
            addCriterion("fbm_breaks_phone is not null");
            return (Criteria) this;
        }

        public Criteria andFbmBreaksPhoneEqualTo(String value) {
            addCriterion("fbm_breaks_phone =", value, "fbmBreaksPhone");
            return (Criteria) this;
        }

        public Criteria andFbmBreaksPhoneNotEqualTo(String value) {
            addCriterion("fbm_breaks_phone <>", value, "fbmBreaksPhone");
            return (Criteria) this;
        }

        public Criteria andFbmBreaksPhoneGreaterThan(String value) {
            addCriterion("fbm_breaks_phone >", value, "fbmBreaksPhone");
            return (Criteria) this;
        }

        public Criteria andFbmBreaksPhoneGreaterThanOrEqualTo(String value) {
            addCriterion("fbm_breaks_phone >=", value, "fbmBreaksPhone");
            return (Criteria) this;
        }

        public Criteria andFbmBreaksPhoneLessThan(String value) {
            addCriterion("fbm_breaks_phone <", value, "fbmBreaksPhone");
            return (Criteria) this;
        }

        public Criteria andFbmBreaksPhoneLessThanOrEqualTo(String value) {
            addCriterion("fbm_breaks_phone <=", value, "fbmBreaksPhone");
            return (Criteria) this;
        }

        public Criteria andFbmBreaksPhoneLike(String value) {
            addCriterion("fbm_breaks_phone like", value, "fbmBreaksPhone");
            return (Criteria) this;
        }

        public Criteria andFbmBreaksPhoneNotLike(String value) {
            addCriterion("fbm_breaks_phone not like", value, "fbmBreaksPhone");
            return (Criteria) this;
        }

        public Criteria andFbmBreaksPhoneIn(List<String> values) {
            addCriterion("fbm_breaks_phone in", values, "fbmBreaksPhone");
            return (Criteria) this;
        }

        public Criteria andFbmBreaksPhoneNotIn(List<String> values) {
            addCriterion("fbm_breaks_phone not in", values, "fbmBreaksPhone");
            return (Criteria) this;
        }

        public Criteria andFbmBreaksPhoneBetween(String value1, String value2) {
            addCriterion("fbm_breaks_phone between", value1, value2, "fbmBreaksPhone");
            return (Criteria) this;
        }

        public Criteria andFbmBreaksPhoneNotBetween(String value1, String value2) {
            addCriterion("fbm_breaks_phone not between", value1, value2, "fbmBreaksPhone");
            return (Criteria) this;
        }

        public Criteria andFbmBreaksTimeIsNull() {
            addCriterion("fbm_breaks_time is null");
            return (Criteria) this;
        }

        public Criteria andFbmBreaksTimeIsNotNull() {
            addCriterion("fbm_breaks_time is not null");
            return (Criteria) this;
        }

        public Criteria andFbmBreaksTimeEqualTo(Date value) {
            addCriterion("fbm_breaks_time =", value, "fbmBreaksTime");
            return (Criteria) this;
        }

        public Criteria andFbmBreaksTimeNotEqualTo(Date value) {
            addCriterion("fbm_breaks_time <>", value, "fbmBreaksTime");
            return (Criteria) this;
        }

        public Criteria andFbmBreaksTimeGreaterThan(Date value) {
            addCriterion("fbm_breaks_time >", value, "fbmBreaksTime");
            return (Criteria) this;
        }

        public Criteria andFbmBreaksTimeGreaterThanOrEqualTo(Date value) {
            addCriterion("fbm_breaks_time >=", value, "fbmBreaksTime");
            return (Criteria) this;
        }

        public Criteria andFbmBreaksTimeLessThan(Date value) {
            addCriterion("fbm_breaks_time <", value, "fbmBreaksTime");
            return (Criteria) this;
        }

        public Criteria andFbmBreaksTimeLessThanOrEqualTo(Date value) {
            addCriterion("fbm_breaks_time <=", value, "fbmBreaksTime");
            return (Criteria) this;
        }

        public Criteria andFbmBreaksTimeIn(List<Date> values) {
            addCriterion("fbm_breaks_time in", values, "fbmBreaksTime");
            return (Criteria) this;
        }

        public Criteria andFbmBreaksTimeNotIn(List<Date> values) {
            addCriterion("fbm_breaks_time not in", values, "fbmBreaksTime");
            return (Criteria) this;
        }

        public Criteria andFbmBreaksTimeBetween(Date value1, Date value2) {
            addCriterion("fbm_breaks_time between", value1, value2, "fbmBreaksTime");
            return (Criteria) this;
        }

        public Criteria andFbmBreaksTimeNotBetween(Date value1, Date value2) {
            addCriterion("fbm_breaks_time not between", value1, value2, "fbmBreaksTime");
            return (Criteria) this;
        }

        public Criteria andFbmOverdueStateIsNull() {
            addCriterion("fbm_overdue_state is null");
            return (Criteria) this;
        }

        public Criteria andFbmOverdueStateIsNotNull() {
            addCriterion("fbm_overdue_state is not null");
            return (Criteria) this;
        }

        public Criteria andFbmOverdueStateEqualTo(Integer value) {
            addCriterion("fbm_overdue_state =", value, "fbmOverdueState");
            return (Criteria) this;
        }

        public Criteria andFbmOverdueStateNotEqualTo(Integer value) {
            addCriterion("fbm_overdue_state <>", value, "fbmOverdueState");
            return (Criteria) this;
        }

        public Criteria andFbmOverdueStateGreaterThan(Integer value) {
            addCriterion("fbm_overdue_state >", value, "fbmOverdueState");
            return (Criteria) this;
        }

        public Criteria andFbmOverdueStateGreaterThanOrEqualTo(Integer value) {
            addCriterion("fbm_overdue_state >=", value, "fbmOverdueState");
            return (Criteria) this;
        }

        public Criteria andFbmOverdueStateLessThan(Integer value) {
            addCriterion("fbm_overdue_state <", value, "fbmOverdueState");
            return (Criteria) this;
        }

        public Criteria andFbmOverdueStateLessThanOrEqualTo(Integer value) {
            addCriterion("fbm_overdue_state <=", value, "fbmOverdueState");
            return (Criteria) this;
        }

        public Criteria andFbmOverdueStateIn(List<Integer> values) {
            addCriterion("fbm_overdue_state in", values, "fbmOverdueState");
            return (Criteria) this;
        }

        public Criteria andFbmOverdueStateNotIn(List<Integer> values) {
            addCriterion("fbm_overdue_state not in", values, "fbmOverdueState");
            return (Criteria) this;
        }

        public Criteria andFbmOverdueStateBetween(Integer value1, Integer value2) {
            addCriterion("fbm_overdue_state between", value1, value2, "fbmOverdueState");
            return (Criteria) this;
        }

        public Criteria andFbmOverdueStateNotBetween(Integer value1, Integer value2) {
            addCriterion("fbm_overdue_state not between", value1, value2, "fbmOverdueState");
            return (Criteria) this;
        }

        public Criteria andFbmMatchTypeIsNull() {
            addCriterion("fbm_match_type is null");
            return (Criteria) this;
        }

        public Criteria andFbmMatchTypeIsNotNull() {
            addCriterion("fbm_match_type is not null");
            return (Criteria) this;
        }

        public Criteria andFbmMatchTypeEqualTo(String value) {
            addCriterion("fbm_match_type =", value, "fbmMatchType");
            return (Criteria) this;
        }

        public Criteria andFbmMatchTypeNotEqualTo(String value) {
            addCriterion("fbm_match_type <>", value, "fbmMatchType");
            return (Criteria) this;
        }

        public Criteria andFbmMatchTypeGreaterThan(String value) {
            addCriterion("fbm_match_type >", value, "fbmMatchType");
            return (Criteria) this;
        }

        public Criteria andFbmMatchTypeGreaterThanOrEqualTo(String value) {
            addCriterion("fbm_match_type >=", value, "fbmMatchType");
            return (Criteria) this;
        }

        public Criteria andFbmMatchTypeLessThan(String value) {
            addCriterion("fbm_match_type <", value, "fbmMatchType");
            return (Criteria) this;
        }

        public Criteria andFbmMatchTypeLessThanOrEqualTo(String value) {
            addCriterion("fbm_match_type <=", value, "fbmMatchType");
            return (Criteria) this;
        }

        public Criteria andFbmMatchTypeLike(String value) {
            addCriterion("fbm_match_type like", value, "fbmMatchType");
            return (Criteria) this;
        }

        public Criteria andFbmMatchTypeNotLike(String value) {
            addCriterion("fbm_match_type not like", value, "fbmMatchType");
            return (Criteria) this;
        }

        public Criteria andFbmMatchTypeIn(List<String> values) {
            addCriterion("fbm_match_type in", values, "fbmMatchType");
            return (Criteria) this;
        }

        public Criteria andFbmMatchTypeNotIn(List<String> values) {
            addCriterion("fbm_match_type not in", values, "fbmMatchType");
            return (Criteria) this;
        }

        public Criteria andFbmMatchTypeBetween(String value1, String value2) {
            addCriterion("fbm_match_type between", value1, value2, "fbmMatchType");
            return (Criteria) this;
        }

        public Criteria andFbmMatchTypeNotBetween(String value1, String value2) {
            addCriterion("fbm_match_type not between", value1, value2, "fbmMatchType");
            return (Criteria) this;
        }

        public Criteria andFbmMatchPhoneIsNull() {
            addCriterion("fbm_match_phone is null");
            return (Criteria) this;
        }

        public Criteria andFbmMatchPhoneIsNotNull() {
            addCriterion("fbm_match_phone is not null");
            return (Criteria) this;
        }

        public Criteria andFbmMatchPhoneEqualTo(String value) {
            addCriterion("fbm_match_phone =", value, "fbmMatchPhone");
            return (Criteria) this;
        }

        public Criteria andFbmMatchPhoneNotEqualTo(String value) {
            addCriterion("fbm_match_phone <>", value, "fbmMatchPhone");
            return (Criteria) this;
        }

        public Criteria andFbmMatchPhoneGreaterThan(String value) {
            addCriterion("fbm_match_phone >", value, "fbmMatchPhone");
            return (Criteria) this;
        }

        public Criteria andFbmMatchPhoneGreaterThanOrEqualTo(String value) {
            addCriterion("fbm_match_phone >=", value, "fbmMatchPhone");
            return (Criteria) this;
        }

        public Criteria andFbmMatchPhoneLessThan(String value) {
            addCriterion("fbm_match_phone <", value, "fbmMatchPhone");
            return (Criteria) this;
        }

        public Criteria andFbmMatchPhoneLessThanOrEqualTo(String value) {
            addCriterion("fbm_match_phone <=", value, "fbmMatchPhone");
            return (Criteria) this;
        }

        public Criteria andFbmMatchPhoneLike(String value) {
            addCriterion("fbm_match_phone like", value, "fbmMatchPhone");
            return (Criteria) this;
        }

        public Criteria andFbmMatchPhoneNotLike(String value) {
            addCriterion("fbm_match_phone not like", value, "fbmMatchPhone");
            return (Criteria) this;
        }

        public Criteria andFbmMatchPhoneIn(List<String> values) {
            addCriterion("fbm_match_phone in", values, "fbmMatchPhone");
            return (Criteria) this;
        }

        public Criteria andFbmMatchPhoneNotIn(List<String> values) {
            addCriterion("fbm_match_phone not in", values, "fbmMatchPhone");
            return (Criteria) this;
        }

        public Criteria andFbmMatchPhoneBetween(String value1, String value2) {
            addCriterion("fbm_match_phone between", value1, value2, "fbmMatchPhone");
            return (Criteria) this;
        }

        public Criteria andFbmMatchPhoneNotBetween(String value1, String value2) {
            addCriterion("fbm_match_phone not between", value1, value2, "fbmMatchPhone");
            return (Criteria) this;
        }

        public Criteria andFbmPayAmonutIsNull() {
            addCriterion("fbm_pay_amonut is null");
            return (Criteria) this;
        }

        public Criteria andFbmPayAmonutIsNotNull() {
            addCriterion("fbm_pay_amonut is not null");
            return (Criteria) this;
        }

        public Criteria andFbmPayAmonutEqualTo(Double value) {
            addCriterion("fbm_pay_amonut =", value, "fbmPayAmonut");
            return (Criteria) this;
        }

        public Criteria andFbmPayAmonutNotEqualTo(Double value) {
            addCriterion("fbm_pay_amonut <>", value, "fbmPayAmonut");
            return (Criteria) this;
        }

        public Criteria andFbmPayAmonutGreaterThan(Double value) {
            addCriterion("fbm_pay_amonut >", value, "fbmPayAmonut");
            return (Criteria) this;
        }

        public Criteria andFbmPayAmonutGreaterThanOrEqualTo(Double value) {
            addCriterion("fbm_pay_amonut >=", value, "fbmPayAmonut");
            return (Criteria) this;
        }

        public Criteria andFbmPayAmonutLessThan(Double value) {
            addCriterion("fbm_pay_amonut <", value, "fbmPayAmonut");
            return (Criteria) this;
        }

        public Criteria andFbmPayAmonutLessThanOrEqualTo(Double value) {
            addCriterion("fbm_pay_amonut <=", value, "fbmPayAmonut");
            return (Criteria) this;
        }

        public Criteria andFbmPayAmonutIn(List<Double> values) {
            addCriterion("fbm_pay_amonut in", values, "fbmPayAmonut");
            return (Criteria) this;
        }

        public Criteria andFbmPayAmonutNotIn(List<Double> values) {
            addCriterion("fbm_pay_amonut not in", values, "fbmPayAmonut");
            return (Criteria) this;
        }

        public Criteria andFbmPayAmonutBetween(Double value1, Double value2) {
            addCriterion("fbm_pay_amonut between", value1, value2, "fbmPayAmonut");
            return (Criteria) this;
        }

        public Criteria andFbmPayAmonutNotBetween(Double value1, Double value2) {
            addCriterion("fbm_pay_amonut not between", value1, value2, "fbmPayAmonut");
            return (Criteria) this;
        }

        public Criteria andFbmUnpayAmountIsNull() {
            addCriterion("fbm_unpay_amount is null");
            return (Criteria) this;
        }

        public Criteria andFbmUnpayAmountIsNotNull() {
            addCriterion("fbm_unpay_amount is not null");
            return (Criteria) this;
        }

        public Criteria andFbmUnpayAmountEqualTo(Double value) {
            addCriterion("fbm_unpay_amount =", value, "fbmUnpayAmount");
            return (Criteria) this;
        }

        public Criteria andFbmUnpayAmountNotEqualTo(Double value) {
            addCriterion("fbm_unpay_amount <>", value, "fbmUnpayAmount");
            return (Criteria) this;
        }

        public Criteria andFbmUnpayAmountGreaterThan(Double value) {
            addCriterion("fbm_unpay_amount >", value, "fbmUnpayAmount");
            return (Criteria) this;
        }

        public Criteria andFbmUnpayAmountGreaterThanOrEqualTo(Double value) {
            addCriterion("fbm_unpay_amount >=", value, "fbmUnpayAmount");
            return (Criteria) this;
        }

        public Criteria andFbmUnpayAmountLessThan(Double value) {
            addCriterion("fbm_unpay_amount <", value, "fbmUnpayAmount");
            return (Criteria) this;
        }

        public Criteria andFbmUnpayAmountLessThanOrEqualTo(Double value) {
            addCriterion("fbm_unpay_amount <=", value, "fbmUnpayAmount");
            return (Criteria) this;
        }

        public Criteria andFbmUnpayAmountIn(List<Double> values) {
            addCriterion("fbm_unpay_amount in", values, "fbmUnpayAmount");
            return (Criteria) this;
        }

        public Criteria andFbmUnpayAmountNotIn(List<Double> values) {
            addCriterion("fbm_unpay_amount not in", values, "fbmUnpayAmount");
            return (Criteria) this;
        }

        public Criteria andFbmUnpayAmountBetween(Double value1, Double value2) {
            addCriterion("fbm_unpay_amount between", value1, value2, "fbmUnpayAmount");
            return (Criteria) this;
        }

        public Criteria andFbmUnpayAmountNotBetween(Double value1, Double value2) {
            addCriterion("fbm_unpay_amount not between", value1, value2, "fbmUnpayAmount");
            return (Criteria) this;
        }

        public Criteria andFbmRefundAmountIsNull() {
            addCriterion("fbm_refund_amount is null");
            return (Criteria) this;
        }

        public Criteria andFbmRefundAmountIsNotNull() {
            addCriterion("fbm_refund_amount is not null");
            return (Criteria) this;
        }

        public Criteria andFbmRefundAmountEqualTo(Double value) {
            addCriterion("fbm_refund_amount =", value, "fbmRefundAmount");
            return (Criteria) this;
        }

        public Criteria andFbmRefundAmountNotEqualTo(Double value) {
            addCriterion("fbm_refund_amount <>", value, "fbmRefundAmount");
            return (Criteria) this;
        }

        public Criteria andFbmRefundAmountGreaterThan(Double value) {
            addCriterion("fbm_refund_amount >", value, "fbmRefundAmount");
            return (Criteria) this;
        }

        public Criteria andFbmRefundAmountGreaterThanOrEqualTo(Double value) {
            addCriterion("fbm_refund_amount >=", value, "fbmRefundAmount");
            return (Criteria) this;
        }

        public Criteria andFbmRefundAmountLessThan(Double value) {
            addCriterion("fbm_refund_amount <", value, "fbmRefundAmount");
            return (Criteria) this;
        }

        public Criteria andFbmRefundAmountLessThanOrEqualTo(Double value) {
            addCriterion("fbm_refund_amount <=", value, "fbmRefundAmount");
            return (Criteria) this;
        }

        public Criteria andFbmRefundAmountIn(List<Double> values) {
            addCriterion("fbm_refund_amount in", values, "fbmRefundAmount");
            return (Criteria) this;
        }

        public Criteria andFbmRefundAmountNotIn(List<Double> values) {
            addCriterion("fbm_refund_amount not in", values, "fbmRefundAmount");
            return (Criteria) this;
        }

        public Criteria andFbmRefundAmountBetween(Double value1, Double value2) {
            addCriterion("fbm_refund_amount between", value1, value2, "fbmRefundAmount");
            return (Criteria) this;
        }

        public Criteria andFbmRefundAmountNotBetween(Double value1, Double value2) {
            addCriterion("fbm_refund_amount not between", value1, value2, "fbmRefundAmount");
            return (Criteria) this;
        }

        public Criteria andFbmUnRefundAmountIsNull() {
            addCriterion("fbm_un_refund_amount is null");
            return (Criteria) this;
        }

        public Criteria andFbmUnRefundAmountIsNotNull() {
            addCriterion("fbm_un_refund_amount is not null");
            return (Criteria) this;
        }

        public Criteria andFbmUnRefundAmountEqualTo(Double value) {
            addCriterion("fbm_un_refund_amount =", value, "fbmUnRefundAmount");
            return (Criteria) this;
        }

        public Criteria andFbmUnRefundAmountNotEqualTo(Double value) {
            addCriterion("fbm_un_refund_amount <>", value, "fbmUnRefundAmount");
            return (Criteria) this;
        }

        public Criteria andFbmUnRefundAmountGreaterThan(Double value) {
            addCriterion("fbm_un_refund_amount >", value, "fbmUnRefundAmount");
            return (Criteria) this;
        }

        public Criteria andFbmUnRefundAmountGreaterThanOrEqualTo(Double value) {
            addCriterion("fbm_un_refund_amount >=", value, "fbmUnRefundAmount");
            return (Criteria) this;
        }

        public Criteria andFbmUnRefundAmountLessThan(Double value) {
            addCriterion("fbm_un_refund_amount <", value, "fbmUnRefundAmount");
            return (Criteria) this;
        }

        public Criteria andFbmUnRefundAmountLessThanOrEqualTo(Double value) {
            addCriterion("fbm_un_refund_amount <=", value, "fbmUnRefundAmount");
            return (Criteria) this;
        }

        public Criteria andFbmUnRefundAmountIn(List<Double> values) {
            addCriterion("fbm_un_refund_amount in", values, "fbmUnRefundAmount");
            return (Criteria) this;
        }

        public Criteria andFbmUnRefundAmountNotIn(List<Double> values) {
            addCriterion("fbm_un_refund_amount not in", values, "fbmUnRefundAmount");
            return (Criteria) this;
        }

        public Criteria andFbmUnRefundAmountBetween(Double value1, Double value2) {
            addCriterion("fbm_un_refund_amount between", value1, value2, "fbmUnRefundAmount");
            return (Criteria) this;
        }

        public Criteria andFbmUnRefundAmountNotBetween(Double value1, Double value2) {
            addCriterion("fbm_un_refund_amount not between", value1, value2, "fbmUnRefundAmount");
            return (Criteria) this;
        }

        public Criteria andFbmAlreadyRefundAmountIsNull() {
            addCriterion("fbm_already_refund_amount is null");
            return (Criteria) this;
        }

        public Criteria andFbmAlreadyRefundAmountIsNotNull() {
            addCriterion("fbm_already_refund_amount is not null");
            return (Criteria) this;
        }

        public Criteria andFbmAlreadyRefundAmountEqualTo(Double value) {
            addCriterion("fbm_already_refund_amount =", value, "fbmAlreadyRefundAmount");
            return (Criteria) this;
        }

        public Criteria andFbmAlreadyRefundAmountNotEqualTo(Double value) {
            addCriterion("fbm_already_refund_amount <>", value, "fbmAlreadyRefundAmount");
            return (Criteria) this;
        }

        public Criteria andFbmAlreadyRefundAmountGreaterThan(Double value) {
            addCriterion("fbm_already_refund_amount >", value, "fbmAlreadyRefundAmount");
            return (Criteria) this;
        }

        public Criteria andFbmAlreadyRefundAmountGreaterThanOrEqualTo(Double value) {
            addCriterion("fbm_already_refund_amount >=", value, "fbmAlreadyRefundAmount");
            return (Criteria) this;
        }

        public Criteria andFbmAlreadyRefundAmountLessThan(Double value) {
            addCriterion("fbm_already_refund_amount <", value, "fbmAlreadyRefundAmount");
            return (Criteria) this;
        }

        public Criteria andFbmAlreadyRefundAmountLessThanOrEqualTo(Double value) {
            addCriterion("fbm_already_refund_amount <=", value, "fbmAlreadyRefundAmount");
            return (Criteria) this;
        }

        public Criteria andFbmAlreadyRefundAmountIn(List<Double> values) {
            addCriterion("fbm_already_refund_amount in", values, "fbmAlreadyRefundAmount");
            return (Criteria) this;
        }

        public Criteria andFbmAlreadyRefundAmountNotIn(List<Double> values) {
            addCriterion("fbm_already_refund_amount not in", values, "fbmAlreadyRefundAmount");
            return (Criteria) this;
        }

        public Criteria andFbmAlreadyRefundAmountBetween(Double value1, Double value2) {
            addCriterion("fbm_already_refund_amount between", value1, value2, "fbmAlreadyRefundAmount");
            return (Criteria) this;
        }

        public Criteria andFbmAlreadyRefundAmountNotBetween(Double value1, Double value2) {
            addCriterion("fbm_already_refund_amount not between", value1, value2, "fbmAlreadyRefundAmount");
            return (Criteria) this;
        }

        public Criteria andRemarkIsNull() {
            addCriterion("remark is null");
            return (Criteria) this;
        }

        public Criteria andRemarkIsNotNull() {
            addCriterion("remark is not null");
            return (Criteria) this;
        }

        public Criteria andRemarkEqualTo(String value) {
            addCriterion("remark =", value, "remark");
            return (Criteria) this;
        }

        public Criteria andRemarkNotEqualTo(String value) {
            addCriterion("remark <>", value, "remark");
            return (Criteria) this;
        }

        public Criteria andRemarkGreaterThan(String value) {
            addCriterion("remark >", value, "remark");
            return (Criteria) this;
        }

        public Criteria andRemarkGreaterThanOrEqualTo(String value) {
            addCriterion("remark >=", value, "remark");
            return (Criteria) this;
        }

        public Criteria andRemarkLessThan(String value) {
            addCriterion("remark <", value, "remark");
            return (Criteria) this;
        }

        public Criteria andRemarkLessThanOrEqualTo(String value) {
            addCriterion("remark <=", value, "remark");
            return (Criteria) this;
        }

        public Criteria andRemarkLike(String value) {
            addCriterion("remark like", value, "remark");
            return (Criteria) this;
        }

        public Criteria andRemarkNotLike(String value) {
            addCriterion("remark not like", value, "remark");
            return (Criteria) this;
        }

        public Criteria andRemarkIn(List<String> values) {
            addCriterion("remark in", values, "remark");
            return (Criteria) this;
        }

        public Criteria andRemarkNotIn(List<String> values) {
            addCriterion("remark not in", values, "remark");
            return (Criteria) this;
        }

        public Criteria andRemarkBetween(String value1, String value2) {
            addCriterion("remark between", value1, value2, "remark");
            return (Criteria) this;
        }

        public Criteria andRemarkNotBetween(String value1, String value2) {
            addCriterion("remark not between", value1, value2, "remark");
            return (Criteria) this;
        }

        public Criteria andCreateuserIsNull() {
            addCriterion("createuser is null");
            return (Criteria) this;
        }

        public Criteria andCreateuserIsNotNull() {
            addCriterion("createuser is not null");
            return (Criteria) this;
        }

        public Criteria andCreateuserEqualTo(String value) {
            addCriterion("createuser =", value, "createuser");
            return (Criteria) this;
        }

        public Criteria andCreateuserNotEqualTo(String value) {
            addCriterion("createuser <>", value, "createuser");
            return (Criteria) this;
        }

        public Criteria andCreateuserGreaterThan(String value) {
            addCriterion("createuser >", value, "createuser");
            return (Criteria) this;
        }

        public Criteria andCreateuserGreaterThanOrEqualTo(String value) {
            addCriterion("createuser >=", value, "createuser");
            return (Criteria) this;
        }

        public Criteria andCreateuserLessThan(String value) {
            addCriterion("createuser <", value, "createuser");
            return (Criteria) this;
        }

        public Criteria andCreateuserLessThanOrEqualTo(String value) {
            addCriterion("createuser <=", value, "createuser");
            return (Criteria) this;
        }

        public Criteria andCreateuserLike(String value) {
            addCriterion("createuser like", value, "createuser");
            return (Criteria) this;
        }

        public Criteria andCreateuserNotLike(String value) {
            addCriterion("createuser not like", value, "createuser");
            return (Criteria) this;
        }

        public Criteria andCreateuserIn(List<String> values) {
            addCriterion("createuser in", values, "createuser");
            return (Criteria) this;
        }

        public Criteria andCreateuserNotIn(List<String> values) {
            addCriterion("createuser not in", values, "createuser");
            return (Criteria) this;
        }

        public Criteria andCreateuserBetween(String value1, String value2) {
            addCriterion("createuser between", value1, value2, "createuser");
            return (Criteria) this;
        }

        public Criteria andCreateuserNotBetween(String value1, String value2) {
            addCriterion("createuser not between", value1, value2, "createuser");
            return (Criteria) this;
        }

        public Criteria andCreatetimeIsNull() {
            addCriterion("createtime is null");
            return (Criteria) this;
        }

        public Criteria andCreatetimeIsNotNull() {
            addCriterion("createtime is not null");
            return (Criteria) this;
        }

        public Criteria andCreatetimeEqualTo(Date value) {
            addCriterion("createtime =", value, "createtime");
            return (Criteria) this;
        }

        public Criteria andCreatetimeNotEqualTo(Date value) {
            addCriterion("createtime <>", value, "createtime");
            return (Criteria) this;
        }

        public Criteria andCreatetimeGreaterThan(Date value) {
            addCriterion("createtime >", value, "createtime");
            return (Criteria) this;
        }

        public Criteria andCreatetimeGreaterThanOrEqualTo(Date value) {
            addCriterion("createtime >=", value, "createtime");
            return (Criteria) this;
        }

        public Criteria andCreatetimeLessThan(Date value) {
            addCriterion("createtime <", value, "createtime");
            return (Criteria) this;
        }

        public Criteria andCreatetimeLessThanOrEqualTo(Date value) {
            addCriterion("createtime <=", value, "createtime");
            return (Criteria) this;
        }

        public Criteria andCreatetimeIn(List<Date> values) {
            addCriterion("createtime in", values, "createtime");
            return (Criteria) this;
        }

        public Criteria andCreatetimeNotIn(List<Date> values) {
            addCriterion("createtime not in", values, "createtime");
            return (Criteria) this;
        }

        public Criteria andCreatetimeBetween(Date value1, Date value2) {
            addCriterion("createtime between", value1, value2, "createtime");
            return (Criteria) this;
        }

        public Criteria andCreatetimeNotBetween(Date value1, Date value2) {
            addCriterion("createtime not between", value1, value2, "createtime");
            return (Criteria) this;
        }

        public Criteria andUpdateuserIsNull() {
            addCriterion("updateuser is null");
            return (Criteria) this;
        }

        public Criteria andUpdateuserIsNotNull() {
            addCriterion("updateuser is not null");
            return (Criteria) this;
        }

        public Criteria andUpdateuserEqualTo(String value) {
            addCriterion("updateuser =", value, "updateuser");
            return (Criteria) this;
        }

        public Criteria andUpdateuserNotEqualTo(String value) {
            addCriterion("updateuser <>", value, "updateuser");
            return (Criteria) this;
        }

        public Criteria andUpdateuserGreaterThan(String value) {
            addCriterion("updateuser >", value, "updateuser");
            return (Criteria) this;
        }

        public Criteria andUpdateuserGreaterThanOrEqualTo(String value) {
            addCriterion("updateuser >=", value, "updateuser");
            return (Criteria) this;
        }

        public Criteria andUpdateuserLessThan(String value) {
            addCriterion("updateuser <", value, "updateuser");
            return (Criteria) this;
        }

        public Criteria andUpdateuserLessThanOrEqualTo(String value) {
            addCriterion("updateuser <=", value, "updateuser");
            return (Criteria) this;
        }

        public Criteria andUpdateuserLike(String value) {
            addCriterion("updateuser like", value, "updateuser");
            return (Criteria) this;
        }

        public Criteria andUpdateuserNotLike(String value) {
            addCriterion("updateuser not like", value, "updateuser");
            return (Criteria) this;
        }

        public Criteria andUpdateuserIn(List<String> values) {
            addCriterion("updateuser in", values, "updateuser");
            return (Criteria) this;
        }

        public Criteria andUpdateuserNotIn(List<String> values) {
            addCriterion("updateuser not in", values, "updateuser");
            return (Criteria) this;
        }

        public Criteria andUpdateuserBetween(String value1, String value2) {
            addCriterion("updateuser between", value1, value2, "updateuser");
            return (Criteria) this;
        }

        public Criteria andUpdateuserNotBetween(String value1, String value2) {
            addCriterion("updateuser not between", value1, value2, "updateuser");
            return (Criteria) this;
        }

        public Criteria andUpdatetimeIsNull() {
            addCriterion("updatetime is null");
            return (Criteria) this;
        }

        public Criteria andUpdatetimeIsNotNull() {
            addCriterion("updatetime is not null");
            return (Criteria) this;
        }

        public Criteria andUpdatetimeEqualTo(Date value) {
            addCriterion("updatetime =", value, "updatetime");
            return (Criteria) this;
        }

        public Criteria andUpdatetimeNotEqualTo(Date value) {
            addCriterion("updatetime <>", value, "updatetime");
            return (Criteria) this;
        }

        public Criteria andUpdatetimeGreaterThan(Date value) {
            addCriterion("updatetime >", value, "updatetime");
            return (Criteria) this;
        }

        public Criteria andUpdatetimeGreaterThanOrEqualTo(Date value) {
            addCriterion("updatetime >=", value, "updatetime");
            return (Criteria) this;
        }

        public Criteria andUpdatetimeLessThan(Date value) {
            addCriterion("updatetime <", value, "updatetime");
            return (Criteria) this;
        }

        public Criteria andUpdatetimeLessThanOrEqualTo(Date value) {
            addCriterion("updatetime <=", value, "updatetime");
            return (Criteria) this;
        }

        public Criteria andUpdatetimeIn(List<Date> values) {
            addCriterion("updatetime in", values, "updatetime");
            return (Criteria) this;
        }

        public Criteria andUpdatetimeNotIn(List<Date> values) {
            addCriterion("updatetime not in", values, "updatetime");
            return (Criteria) this;
        }

        public Criteria andUpdatetimeBetween(Date value1, Date value2) {
            addCriterion("updatetime between", value1, value2, "updatetime");
            return (Criteria) this;
        }

        public Criteria andUpdatetimeNotBetween(Date value1, Date value2) {
            addCriterion("updatetime not between", value1, value2, "updatetime");
            return (Criteria) this;
        }

        public Criteria andDrIsNull() {
            addCriterion("dr is null");
            return (Criteria) this;
        }

        public Criteria andDrIsNotNull() {
            addCriterion("dr is not null");
            return (Criteria) this;
        }

        public Criteria andDrEqualTo(Integer value) {
            addCriterion("dr =", value, "dr");
            return (Criteria) this;
        }

        public Criteria andDrNotEqualTo(Integer value) {
            addCriterion("dr <>", value, "dr");
            return (Criteria) this;
        }

        public Criteria andDrGreaterThan(Integer value) {
            addCriterion("dr >", value, "dr");
            return (Criteria) this;
        }

        public Criteria andDrGreaterThanOrEqualTo(Integer value) {
            addCriterion("dr >=", value, "dr");
            return (Criteria) this;
        }

        public Criteria andDrLessThan(Integer value) {
            addCriterion("dr <", value, "dr");
            return (Criteria) this;
        }

        public Criteria andDrLessThanOrEqualTo(Integer value) {
            addCriterion("dr <=", value, "dr");
            return (Criteria) this;
        }

        public Criteria andDrIn(List<Integer> values) {
            addCriterion("dr in", values, "dr");
            return (Criteria) this;
        }

        public Criteria andDrNotIn(List<Integer> values) {
            addCriterion("dr not in", values, "dr");
            return (Criteria) this;
        }

        public Criteria andDrBetween(Integer value1, Integer value2) {
            addCriterion("dr between", value1, value2, "dr");
            return (Criteria) this;
        }

        public Criteria andDrNotBetween(Integer value1, Integer value2) {
            addCriterion("dr not between", value1, value2, "dr");
            return (Criteria) this;
        }
    }

    public static class Criteria extends GeneratedCriteria {

        protected Criteria() {
            super();
        }
    }

    public static class Criterion {
        private String condition;

        private Object value;

        private Object secondValue;

        private boolean noValue;

        private boolean singleValue;

        private boolean betweenValue;

        private boolean listValue;

        private String typeHandler;

        public String getCondition() {
            return condition;
        }

        public Object getValue() {
            return value;
        }

        public Object getSecondValue() {
            return secondValue;
        }

        public boolean isNoValue() {
            return noValue;
        }

        public boolean isSingleValue() {
            return singleValue;
        }

        public boolean isBetweenValue() {
            return betweenValue;
        }

        public boolean isListValue() {
            return listValue;
        }

        public String getTypeHandler() {
            return typeHandler;
        }

        protected Criterion(String condition) {
            super();
            this.condition = condition;
            this.typeHandler = null;
            this.noValue = true;
        }

        protected Criterion(String condition, Object value, String typeHandler) {
            super();
            this.condition = condition;
            this.value = value;
            this.typeHandler = typeHandler;
            if (value instanceof List<?>) {
                this.listValue = true;
            } else {
                this.singleValue = true;
            }
        }

        protected Criterion(String condition, Object value) {
            this(condition, value, null);
        }

        protected Criterion(String condition, Object value, Object secondValue, String typeHandler) {
            super();
            this.condition = condition;
            this.value = value;
            this.secondValue = secondValue;
            this.typeHandler = typeHandler;
            this.betweenValue = true;
        }

        protected Criterion(String condition, Object value, Object secondValue) {
            this(condition, value, secondValue, null);
        }
    }
}
