package com.mrk.finance.dao;

import com.mrk.common.base.BaseMapper;
import com.mrk.finance.model.FncBillManagement;
import org.apache.ibatis.annotations.Param;

import java.util.List;

/**
 * Mapper接口
 * @author 自动工具
 */
public interface FncBillManagementMapper extends BaseMapper<FncBillManagement> {


    /**
     * 银行流水[精确匹配]账单, 查询满足条件的账单
     * @author Frank.Tang
     * @param loanType 借/贷
     * @param amount 流水金额
     * @param partyaId 甲方id
     * @param partybId 乙方id
     * @return *
     */
    List<FncBillManagement> selectBillOfBwAccurate(@Param("loanType") Integer loanType,
                                                   @Param("amount") Double amount,
                                                   @Param("partyaId") Long partyaId,
                                                   @Param("partybId") Long partybId);

    /**
     * 银行流水[模糊匹配]账单, 查询满足条件的账单
     * @author Frank.Tang
     * @param loanType 借/贷
     * @param partybId 乙方id
     * @return *
     */
    List<FncBillManagement> selectBillOfBwFuzzy(@Param("loanType") Integer loanType,
                                                @Param("partybId") Long partybId);

    /**
     * T3代扣[精确匹配]账单, 查询满足条件的账单
     * @author Frank.Tang
     * @param partybId 乙方id(合同上的)
     * @param agreementNumber 协议编号
     * @param amount 代扣金额
     * @param carId 车辆id
     * @return *
     */
    List<FncBillManagement> selectBillOfTwAccurate(@Param("partybId") Long partybId,
                                                   @Param("agreementNumber") String agreementNumber,
                                                   @Param("amount") Double amount,
                                                   @Param("carId") Long carId);
    /**
     * T3代扣[模糊匹配]账单, 查询满足条件的账单
     * @author Frank.Tang
     * @param partybId 乙方id(合同上的)
     * @param agreementNumber 协议编号
     * @return *
     */
    List<FncBillManagement> selectBillOfTwFuzzy(@Param("partybId") Long partybId,
                                                @Param("agreementNumber") String agreementNumber);

    /**
     * 获取租金账单截止日期前一天的账单
     * @param value
     * @return
     */
    List<FncBillManagement> selectRentBill(@Param("value")Integer value);
    /**
     * 获取租金账单截止日期早于等于3天的账单
     * @param value
     * @return
     */
    List<FncBillManagement> selectRentBillLess(@Param("value")Integer value);

}
