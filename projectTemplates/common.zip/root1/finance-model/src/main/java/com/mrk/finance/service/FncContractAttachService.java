package com.mrk.finance.service;

import java.util.List;
import com.mrk.finance.model.FncContractAttach;
import com.mrk.finance.queryvo.FncContractAttachQueryVo;
import com.github.pagehelper.PageInfo;

/**
 * @Description: FncContractAttach
 */
public interface FncContractAttachService {
    /**
     * 分页查询
     *
     * @param queryVo 前端查询对象
     * @return 分页查询数据
     */
    PageInfo<FncContractAttach> page(FncContractAttachQueryVo queryVo);

    /**
     * 列表查询
     * @param queryVo 前端查询对象
     * @return 分页查询数据
     */
    List<FncContractAttach> list(FncContractAttachQueryVo queryVo);

    /**
     * 新增
     *
     * @param entity
     * @return 结果
     */
    int add(FncContractAttach entity);

    /**
     * 修改
     *
     * @param entity
     * @return 结果
     */
    int update(FncContractAttach entity);

    /**
     * 删除
     */
    int delete(Long id);

    /**
    * 通过ID查询
    * @param id
    */
    FncContractAttach getById(Long id);

    /**
     * 批量新增
     * @param fncContractAttaches
     */
    void insertList(List<FncContractAttach> fncContractAttaches);

    /**
     * 根据合同id批量查询
     * @param contractIds
     * @return
     */
    List<FncContractAttach> selectByContractIds(List<Long> contractIds);

    /**
     * 根据合同id修改
     * @param fcmId
     */
    void updateByContarctId(Long fcmId);
}
