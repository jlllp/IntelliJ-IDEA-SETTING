package com.mrk.finance.service;

import com.github.pagehelper.PageInfo;
import com.mrk.finance.model.FncBillManagement;
import com.mrk.finance.queryvo.FncBillManagementQueryVo;

import java.util.Date;
import java.util.List;

/**
 * @Description: FncBillManagement
 */
public interface FncBillManagementService {
    /**
     * 分页查询
     *
     * @param queryVo 前端查询对象
     * @return 分页查询数据
     */
    PageInfo<FncBillManagement> page(FncBillManagementQueryVo queryVo);

    /**
     * 列表查询
     *
     * @param queryVo 前端查询对象
     * @return 分页查询数据
     */
    List<FncBillManagement> list(FncBillManagementQueryVo queryVo);

    /**
     * 新增
     *
     * @param entity
     * @return 结果
     */
    int add(FncBillManagement entity);

    /**
     * 修改
     *
     * @param entity
     * @return 结果
     */
    int update(FncBillManagement entity);

    /**
     * @author Frank.Tang
     * @return *
     */
    int updateSelective(FncBillManagement entity);

    /**
     * 删除
     */
    int delete(Long id);

    /**
     * 逻辑删除
     *
     * @return *
     * @author Frank.Tang
     */
    int deleteLogically(Long id);

    /**
     * 通过ID查询
     *
     * @param id
     */
    FncBillManagement getById(Long id);

    /**
     * ids批量查询
     * @author Frank.Tang
     * @return *
     */
    List<FncBillManagement> getByIds(List<Long> ids);

    /**
     * 通过合同ID  和科目查询
     *
     * @param fncContractManagementId
     * @param subject
     */
    List<FncBillManagement> selectByContractIdAndSubject(Long fncContractManagementId, Integer subject);


    /**
     * 通过合同id查询所属账单
     * @author Frank.Tang
     * @param
     * @return *
     */
    List<FncBillManagement> selectByContractId(Long id);

    /**
     * @author Bob
     * @date 2021/11/12
     * @description 根据合同ID获取所有的账单
     * @param contractId 合同id
     * @return 合同对应的所有账单
     */
    List<FncBillManagement> getByContractId(Long contractId);

    /**
     * @author Bob
     * @date 2021/11/15
     * @description 获取指定科目的账单
     * @param subject 科目
     * @return 指定科目的所有账单
     */
    List<FncBillManagement> getBySubject(Integer subject);

    /**
     * 批量修改账单
     * @param fncBillManagements
     */
    void updateList(List<FncBillManagement> fncBillManagements);

    /**
     * @author Bob
     * @date 2021/11/17
     * @description 获取指定科目和账单金额小于的账单列表
     * @param subject 科目
     * @param billAmount 金额
     * @return 指定科目和账单金额小于的账单列表
     */
    List<FncBillManagement> getBySubjectAndAmountLT(Integer subject, double billAmount);

    /**
     * @author Bob
     * @date 2021/11/17
     * @description 批量新增账单数据
     * @param fncBillManagements 待新增的账单集合
     */
    void batchAdd(List<FncBillManagement> fncBillManagements);

    /**
     * @author Bob
     * @date 2021/11/18
     * @description 通过账单截止时间小于且账单状态为旧状态集合时将账单的状态更新为新状态
     * @param newState 新状态
     * @param catOffTime 截止时间
     * @param oldState 旧状态集合
     */
    void updateStateByCatOffTimeLTAndStateIn(Integer newState, Date catOffTime, List<Integer> oldState);

    /**
     * @author Bob
     * @date 2021/11/24
     * @description 根据合同id 不包含科目 截止时间开始和结束时间获取账单
     * @param contractIdList 合同id
     * @param doesNotContain 不包含科目
     * @param catoffStart 截止时间开始
     * @param caroffEnd 截止时间结束
     * @return 符合条件的账单
     */
    List<FncBillManagement> getByContractIdAndNoSubjectAndCatoff(List<Long> contractIdList, List<Integer> doesNotContain, Date catoffStart, Date caroffEnd);

    /**
     * @author Bob
     * @date 2021/11/24
     * @description 根据合同id 科目 截止时间开始和结束时间获取账单
     * @param contractIdList 合同id
     * @param subject 科目
     * @param catoffStart 截止时间开始
     * @param caroffEnd 截止时间结束
     * @return 符合条件的账单
     */
    List<FncBillManagement> getByContractIdAndSubjectAndCatoff(List<Long> contractIdList, Integer subject, Date catoffStart, Date caroffEnd);

    /**
     * 银行流水[精确匹配]账单, 查询满足条件的账单
     * @author Frank.Tang
     * @param loanType 借/贷
     * @param amount 流水金额
     * @param partyaId 甲方id
     * @param partybId 乙方id
     * @return *
     */
    List<FncBillManagement> selectBillOfBwAccurate(Integer loanType, Double amount, Long partyaId, Long partybId);

    /**
     * 银行流水[模糊匹配]账单, 查询满足条件的账单
     * @author Frank.Tang
     * @param loanType 借/贷
     * @param partybId 乙方id
     * @return *
     */
    List<FncBillManagement> selectBillOfBwFuzzy(Integer loanType, Long partybId);

    /**
     * T3代扣[精确匹配]账单, 查询满足条件的账单
     * @author Frank.Tang
     * @param partybId 乙方id
     * @param agreementNumber 协议编号
     * @param amount 代扣金额
     * @param carId 车辆id
     * @return *
     */
    List<FncBillManagement> selectBillOfTwAccurate(Long partybId, String agreementNumber, Double amount, Long carId);

    /**
     * T3代扣[模糊匹配]账单, 查询满足条件的账单
     * @author Frank.Tang
     * @param partybId 乙方id
     * @param agreementNumber 协议编号
     * @return *
     */
    List<FncBillManagement> selectBillOfTwFuzzy(Long partybId, String agreementNumber);

    /**
     * @author Bob
     * @date 2021/11/30
     * @description 根据 合同id 科目 期数 获取账单
     * @param contractId 合同id
     * @param subject 科目
     * @param nper 期数
     * @return 符合条件的账单
     */
    List<FncBillManagement> getByContractIdAndSubjectAndNper(Long contractId, Integer subject, String nper);

    /**
     * 获取租金账单截止日期是前一天的账单
     * @return
     */
    List<FncBillManagement> selectRentBill();

    /**
     * 获取租金账单截止日期早于等于三天的的账单
     * @return
     */
    List<FncBillManagement> selectRentBillLess();

}
