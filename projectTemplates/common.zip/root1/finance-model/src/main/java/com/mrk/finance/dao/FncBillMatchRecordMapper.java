package com.mrk.finance.dao;

import com.mrk.common.base.BaseMapper;
import com.mrk.finance.model.FncBillMatchRecord;

/**
 * Mapper接口
 *
 * @author 自动工具
 */
public interface FncBillMatchRecordMapper extends BaseMapper<FncBillMatchRecord> {

}
