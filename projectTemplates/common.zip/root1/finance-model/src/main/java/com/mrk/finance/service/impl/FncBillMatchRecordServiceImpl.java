package com.mrk.finance.service.impl;

import com.github.pagehelper.PageInfo;
import com.mrk.common.constant.BaseConstants;
import com.mrk.common.utils.bean.BeanUtils;
import com.mrk.common.utils.page.PageUtils;
import com.mrk.finance.dao.FncBillMatchRecordMapper;
import com.mrk.finance.model.FncBillMatchRecord;
import com.mrk.finance.query.FncBillMatchRecordQuery;
import com.mrk.finance.queryvo.FncBillMatchRecordQueryVo;
import com.mrk.finance.service.FncBillMatchRecordService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import javax.annotation.Resource;
import java.util.Date;
import java.util.List;


/**
 * @Description: FncBillMatchRecordServiceImpl
 */
@Service
@Slf4j
public class FncBillMatchRecordServiceImpl implements FncBillMatchRecordService {
    @Resource
    private FncBillMatchRecordMapper fncBillMatchRecordMapper;

    @Override
    public PageInfo<FncBillMatchRecord> page(FncBillMatchRecordQueryVo queryVo){
        PageUtils.startPage();
        List<FncBillMatchRecord> list = this.list(queryVo);
        return new PageInfo<>(list);
    }

    @Override
    public List<FncBillMatchRecord> list(FncBillMatchRecordQueryVo queryVo){
        FncBillMatchRecordQuery query = new FncBillMatchRecordQuery();
        BeanUtils.copyBeanProp(queryVo, query);
        return fncBillMatchRecordMapper.selectByExample(query.getCrieria());
    }

    @Override
    @Transactional(rollbackFor = Exception.class)
    public int add(FncBillMatchRecord entity){
        entity.setCreatetime(new Date());
        entity.setUpdatetime(new Date());
        entity.setDr(BaseConstants.DR_NO);
        return fncBillMatchRecordMapper.insert(entity);
    }

    @Override
    @Transactional(rollbackFor = Exception.class)
    public int update(FncBillMatchRecord entity){
        entity.setUpdatetime(new Date());
        return fncBillMatchRecordMapper.updateByPrimaryKey(entity);
    }

    @Override
    @Transactional(rollbackFor = Exception.class)
    public int delete(Long id){
        return fncBillMatchRecordMapper.deleteByPrimaryKey(id);
    }

    @Override
    public FncBillMatchRecord getById(Long id){
        return fncBillMatchRecordMapper.selectByPrimaryKey(id);
    }
}
