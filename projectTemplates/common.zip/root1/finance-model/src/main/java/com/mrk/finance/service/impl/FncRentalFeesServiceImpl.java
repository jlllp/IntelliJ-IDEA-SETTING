package com.mrk.finance.service.impl;

import com.github.pagehelper.PageInfo;
import com.mrk.common.constant.BaseConstants;
import com.mrk.common.utils.bean.BeanUtils;
import com.mrk.common.utils.jwt.JWTUtil;
import com.mrk.common.utils.page.PageUtils;
import com.mrk.common.utils.text.StringUtils;
import com.mrk.finance.dao.FncRentalFeesMapper;
import com.mrk.finance.example.FncRentalFeesExample;
import com.mrk.finance.model.FncRentalFees;
import com.mrk.finance.query.FncRentalFeesQuery;
import com.mrk.finance.queryvo.FncRentalFeesQueryVo;
import com.mrk.finance.service.FncRentalFeesService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import javax.annotation.Resource;
import java.util.Date;
import java.util.List;


/**
 * @Description: FncRentalFeesServiceImpl
 */
@Service
@Slf4j
public class FncRentalFeesServiceImpl implements FncRentalFeesService {
    @Resource
    private FncRentalFeesMapper fncRentalFeesMapper;

    @Override
    public PageInfo<FncRentalFees> page(FncRentalFeesQueryVo queryVo) {
        PageUtils.startPage();
        List<FncRentalFees> list = this.list(queryVo);
        return new PageInfo<>(list);
    }

    @Override
    public List<FncRentalFees> list(FncRentalFeesQueryVo queryVo) {
        FncRentalFeesQuery query = new FncRentalFeesQuery();
        BeanUtils.copyBeanProp(queryVo, query);
        query.setSidx(StringUtils.camelToUnderlineAndFilterText(query.getSidx()));
        return fncRentalFeesMapper.selectByExample(query.getCrieria());
    }

    @Override
    public List<FncRentalFees> selectByName(String name) {
        FncRentalFeesExample example = new FncRentalFeesExample();
        example.createCriteria()
                .andFrfNameEqualTo(name)
                .andDrEqualTo(BaseConstants.DR_NO);
        return fncRentalFeesMapper.selectByExample(example);
    }

    @Override
    @Transactional(rollbackFor = Exception.class)
    public int add(FncRentalFees entity) {
        entity.setCreatetime(new Date());
        entity.setCreateuser(JWTUtil.getNikeName());
        entity.setDr(BaseConstants.DR_NO);
        return fncRentalFeesMapper.insert(entity);
    }

    @Override
    public int addList(List<FncRentalFees> rents) {
        Date date = new Date();
        String name = JWTUtil.getNikeName();
        for (FncRentalFees rent : rents) {
            rent.setCreatetime(date);
            rent.setCreateuser(name);
            rent.setDr(BaseConstants.DR_NO);
        }
        return fncRentalFeesMapper.insertList(rents);
    }

    @Override
    @Transactional(rollbackFor = Exception.class)
    public int update(FncRentalFees entity) {
        entity.setUpdatetime(new Date());
        entity.setUpdateuser(JWTUtil.getNikeName());
        return fncRentalFeesMapper.updateByPrimaryKey(entity);
    }

    @Override
    public int updateSelective(FncRentalFees entity) {
        entity.setUpdatetime(new Date());
        entity.setUpdateuser(JWTUtil.getNikeName());
        return fncRentalFeesMapper.updateByPrimaryKeySelective(entity);
    }

    @Override
    @Transactional(rollbackFor = Exception.class)
    public int delete(Long id) {
        return fncRentalFeesMapper.deleteByPrimaryKey(id);
    }

    @Override
    @Transactional(rollbackFor = Exception.class)
    public int deleteLogically(Long id) {
        FncRentalFees rentalFees = getById(id);
        rentalFees.setDr(BaseConstants.DR_YES);
        return this.update(rentalFees);
    }

    @Override
    public FncRentalFees getById(Long id) {
        return fncRentalFeesMapper.selectByPrimaryKey(id);
    }

    /**
     * 获取所有的租金包含费用
     *
     * @return 租金包含费用
     */
    @Override
    public List<FncRentalFees> getAll() {
        FncRentalFees rentalFees = new FncRentalFees();
        rentalFees.setDr(BaseConstants.DR_NO);
        return fncRentalFeesMapper.select(rentalFees);
    }
}
