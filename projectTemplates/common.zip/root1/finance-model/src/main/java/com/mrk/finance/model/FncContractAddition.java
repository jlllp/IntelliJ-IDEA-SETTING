package com.mrk.finance.model;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.mrk.common.base.BaseEntity;
import io.swagger.annotations.ApiModelProperty;
import lombok.Getter;
import lombok.Setter;
import org.springframework.format.annotation.DateTimeFormat;

import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import java.io.Serializable;

@Setter
@Getter
public class FncContractAddition extends BaseEntity implements Serializable {
private static final long serialVersionUID=1L;


    /**序号 */
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @ApiModelProperty(value = "序号")
    private Long fcaId;

    /**类型(提前还车/换车协议/解除租赁合同) */
    @ApiModelProperty(value = "类型(提前还车/换车协议/解除租赁合同)")
    private Integer fcaType;

    /**关联合同编号 */
    @ApiModelProperty(value = "公共-补充协议合同号(非合同表)")
    private String fcaContractNo;

    /**关联合同id */
    @ApiModelProperty(value = "关联合同id")
    private Long fcaContractId;

    /**公共-补充协议合同号(非合同表) */
    @ApiModelProperty(value = "关联合同编号")
    private String fcaAssociateContractNo;

    /**提前还车-租赁结束日期 */
    @DateTimeFormat(pattern = "yyyy-MM-dd")
    @JsonFormat(pattern = "yyyy-MM-dd", timezone = "GMT+8")
    @ApiModelProperty(value = "提前还车-租赁结束日期")
    private java.util.Date fcaLeaseEndDate;

    /**换车协议-新车车牌号 */
    @ApiModelProperty(value = "换车协议-新车车牌号")
    private String fcaNewCarPlateNum;

    /**换车协议-新车交付日期 */
    @DateTimeFormat(pattern = "yyyy-MM-dd")
    @JsonFormat(pattern = "yyyy-MM-dd", timezone = "GMT+8")
    @ApiModelProperty(value = "换车协议-新车交付日期")
    private java.util.Date fcaNewHandoverDate;

    /**换车协议-旧车归还日期 */
    @DateTimeFormat(pattern = "yyyy-MM-dd")
    @JsonFormat(pattern = "yyyy-MM-dd", timezone = "GMT+8")
    @ApiModelProperty(value = "换车协议-旧车归还日期")
    private java.util.Date fcaOldCarReturnDate;

    /**解除合同-解除合同日期 */
    @DateTimeFormat(pattern = "yyyy-MM-dd")
    @JsonFormat(pattern = "yyyy-MM-dd", timezone = "GMT+8")
    @ApiModelProperty(value = "解除合同-解除合同日期")
    private java.util.Date fcaContractTerminateDate;

    /**解除合同-信息服务费 */
    @ApiModelProperty(value = "解除合同-信息服务费")
    private Double fcaInformationFee;

    /**解除合同-支付方式 (0, "保证金抵扣"(1, "租金抵扣")2, "新账单支付"); */
    @ApiModelProperty(value = "解除合同-支付方式 (0, 保证金抵扣 (1, 租金抵扣)2, 新账单支付);")
    private Integer fcaPayType;
    }
