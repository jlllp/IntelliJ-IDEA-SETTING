package com.mrk.finance.queryvo;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.mrk.common.base.BaseQueryVo;
import io.swagger.annotations.ApiModelProperty;
import lombok.Getter;
import lombok.Setter;
import org.springframework.format.annotation.DateTimeFormat;

import java.util.List;

@Setter
@Getter
public class FncTtWithholdQueryVo extends BaseQueryVo {



    @ApiModelProperty(value = "主键 精确匹配")
    private Long ftwIdEqualTo;

    @ApiModelProperty(value = "主键 模糊匹配")
    private Long ftwIdLike;


    @ApiModelProperty(value = "城市 精确匹配")
    private Long ftwCityIdEqualTo;

    @ApiModelProperty(value = "城市 模糊匹配")
    private Long ftwCityIdLike;


    @ApiModelProperty(value = "姓名 精确匹配")
    private String ftwNameEqualTo;

    @ApiModelProperty(value = "姓名 模糊匹配")
    private String ftwNameLike;


    @ApiModelProperty(value = "身份证号 精确匹配")
    private String ftwIdnumberEqualTo;

    @ApiModelProperty(value = "身份证号 模糊匹配")
    private String ftwIdnumberLike;


    @ApiModelProperty(value = "司机ID 精确匹配")
    private Long ftwMemberIdEqualTo;

    @ApiModelProperty(value = "司机ID 模糊匹配")
    private Long ftwMemberIdLike;


    @ApiModelProperty(value = "协议编号 精确匹配")
    private String ftwAgreementNumberEqualTo;

    @ApiModelProperty(value = "协议编号 模糊匹配")
    private String ftwAgreementNumberLike;


    @ApiModelProperty(value = "起租日期 大于或等于")
    @DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss", timezone = "GMT+8")
    private java.util.Date ftwRentDateGreaterThanOrEqualTo;

    @DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss", timezone = "GMT+8")
    @ApiModelProperty(value = "起租日期 小于或等于")
    private java.util.Date ftwRentDateLessThanOrEqualTo;
    @ApiModelProperty(value = "起租日期 精确匹配")
    private java.util.Date ftwRentDateEqualTo;

    @ApiModelProperty(value = "起租日期 模糊匹配")
    private java.util.Date ftwRentDateLike;


    @ApiModelProperty(value = "租期 精确匹配")
    private Integer ftwLeaseCountEqualTo;

    @ApiModelProperty(value = "租期 模糊匹配")
    private Integer ftwLeaseCountLike;


    @ApiModelProperty(value = "车型 精确匹配")
    private Long ftwCarModelEqualTo;

    @ApiModelProperty(value = "车型 模糊匹配")
    private Long ftwCarModelLike;


    @ApiModelProperty(value = "车架号 精确匹配")
    private String ftwCarVinEqualTo;

    @ApiModelProperty(value = "车架号 模糊匹配")
    private String ftwCarVinLike;

    private List<String> ftwCarVinIn;


    @ApiModelProperty(value = "月租金 精确匹配")
    private Double ftwMonthRentEqualTo;

    @ApiModelProperty(value = "月租金 模糊匹配")
    private Double ftwMonthRentLike;


    @ApiModelProperty(value = "月扣款总额 精确匹配")
    private Double ftwMonthWithholdEqualTo;

    @ApiModelProperty(value = "月扣款总额 模糊匹配")
    private Double ftwMonthWithholdLike;


    @ApiModelProperty(value = "月租金余量 精确匹配")
    private Double ftwMonthRentBalanceEqualTo;

    @ApiModelProperty(value = "月租金余量 模糊匹配")
    private Double ftwMonthRentBalanceLike;


    @ApiModelProperty(value = "匹配状态 精确匹配")
    private Integer ftwMatchStateEqualTo;

    private List<Integer> ftwMatchStateIn;

    @ApiModelProperty(value = "匹配状态 模糊匹配")
    private Integer ftwMatchStateLike;


    @ApiModelProperty(value = "匹配账单 精确匹配")
    private String ftwMatchBillEqualTo;

    @ApiModelProperty(value = "匹配账单 模糊匹配")
    private String ftwMatchBillLike;


    @ApiModelProperty(value = "匹配方式 精确匹配")
    private Integer ftwMatchWayEqualTo;

    @ApiModelProperty(value = "匹配方式 模糊匹配")
    private Integer ftwMatchWayLike;


    @ApiModelProperty(value = "已匹配金额 精确匹配")
    private Double ftwMatchedAmountEqualTo;

    @ApiModelProperty(value = "已匹配金额 模糊匹配")
    private Double ftwMatchedAmountLike;
    @ApiModelProperty(value = "已匹配金额 小于或等于")
    private Double ftwMatchedAmountLessThanOrEqualTo;
    @ApiModelProperty(value = "已匹配金额 大于或等于")
    private Double ftwMatchedAmountGreaterThanOrEqualTo;


    @ApiModelProperty(value = "未匹配金额 精确匹配")
    private Double ftwNotMatchAmountEqualTo;

    @ApiModelProperty(value = "未匹配金额 模糊匹配")
    private Double ftwNotMatchAmountLike;

    @ApiModelProperty(value = "未匹配金额 小于或等于")
    private Double ftwNotMatchAmountLessThanOrEqualTo;
    @ApiModelProperty(value = "未匹配金额 大于或等于")
    private Double ftwNotMatchAmountGreaterThanOrEqualTo;

    @ApiModelProperty(value = "月租金余量 小于或等于")
    private Double ftwMonthRentBalanceLessThanOrEqualTo;
    @ApiModelProperty(value = "月租金余量  大于或等于")
    private Double ftwMonthRentBalanceGreaterThanOrEqualTo;

    @ApiModelProperty(value = "月扣款总额 小于或等于")
    private Double ftwMonthWithholdLessThanOrEqualTo;

    @ApiModelProperty(value = "月扣款总额 大于或等于")
    private Double ftwMonthWithholdGreaterThanOrEqualTo;

    @ApiModelProperty(value = "月租金 小于或等于")
    private Double ftwMonthRentLessThanOrEqualTo;

    @ApiModelProperty(value = "月租金 大于或等于")
    private Double ftwMonthRentGreaterThanOrEqualTo;

    @ApiModelProperty(value = "租期 小于或等于")
    private Integer ftwLeaseCountLessThanOrEqualTo;

    @ApiModelProperty(value = "租期 大于或等于")
    private Integer ftwLeaseCountGreaterThanOrEqualTo;
}
