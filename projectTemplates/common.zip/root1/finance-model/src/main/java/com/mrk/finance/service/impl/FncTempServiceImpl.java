package com.mrk.finance.service.impl;

import com.github.pagehelper.PageInfo;
import com.mrk.common.constant.BaseConstants;
import com.mrk.common.utils.bean.BeanUtils;
import com.mrk.common.utils.page.PageUtils;
import com.mrk.finance.dao.FncTempMapper;
import com.mrk.finance.example.FncTempExample;
import com.mrk.finance.model.FncTemp;
import com.mrk.finance.query.FncTempQuery;
import com.mrk.finance.queryvo.FncTempQueryVo;
import com.mrk.finance.service.FncTempService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import javax.annotation.Resource;
import java.util.Date;
import java.util.List;


/**
 * @Description: FncTempServiceImpl
 */
@Service
@Slf4j
public class FncTempServiceImpl implements FncTempService {
    @Resource
    private FncTempMapper fncTempMapper;

    @Override
    public PageInfo<FncTemp> page(FncTempQueryVo queryVo){
        PageUtils.startPage();
        List<FncTemp> list = this.list(queryVo);
        return new PageInfo<>(list);
    }

    @Override
    public List<FncTemp> list(FncTempQueryVo queryVo){
        FncTempQuery query = new FncTempQuery();
        BeanUtils.copyBeanProp(queryVo, query);
        return fncTempMapper.selectByExample(query.getCrieria());
    }

    @Override
    @Transactional(rollbackFor = Exception.class)
    public int add(FncTemp entity){
        entity.setCreatetime(new Date());
        entity.setUpdatetime(new Date());
        entity.setDr(BaseConstants.DR_NO);
        return fncTempMapper.insert(entity);
    }

    @Override
    @Transactional(rollbackFor = Exception.class)
    public int update(FncTemp entity){
        entity.setUpdatetime(new Date());
        return fncTempMapper.updateByPrimaryKey(entity);
    }

    @Override
    @Transactional(rollbackFor = Exception.class)
    public int delete(Long id){
        return fncTempMapper.deleteByPrimaryKey(id);
    }

    @Override
    public FncTemp getById(Long id){
        return fncTempMapper.selectByPrimaryKey(id);
    }

    @Override
    public void deleteByOperateCode(String operateCode) {
        FncTemp fncTemp=new FncTemp();
        fncTemp.setFncOperateCode(operateCode);
        fncTempMapper.delete(fncTemp);
    }

    @Override
    public List<FncTemp> selectErrorByOperateCode(String operateCode) {
        FncTemp entity = new FncTemp();
        entity.setFncError(1);
        entity.setFncOperateCode(operateCode);
        return fncTempMapper.select(entity);
    }

    @Override
    public List<FncTemp> selectByOperateCode(String operateCode) {
        FncTemp entity = new FncTemp();
        entity.setFncOperateCode(operateCode);
        return fncTempMapper.select(entity);
    }

    @Override
    public void deleteByLessTime(Date date) {
        FncTempExample example = new FncTempExample();
        example.createCriteria()
                .andCreatetimeLessThan(date);
        fncTempMapper.deleteByExample(example);
    }
}
