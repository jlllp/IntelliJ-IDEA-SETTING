package com.mrk.finance.queryvo;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.mrk.common.base.BaseQueryVo;
import io.swagger.annotations.ApiModelProperty;
import lombok.Getter;
import lombok.Setter;
import org.springframework.format.annotation.DateTimeFormat;

import java.util.List;

@Setter
@Getter
public class FncContractAdditionQueryVo extends BaseQueryVo {



    @ApiModelProperty(value = "序号 精确匹配")
    private Long fcaIdEqualTo;

    @ApiModelProperty(value = "序号 模糊匹配")
    private Long fcaIdLike;


    @ApiModelProperty(value = "类型(提前还车/换车协议/解除租赁合同) 精确匹配")
    private Integer fcaTypeEqualTo;

    @ApiModelProperty(value = "类型(提前还车/换车协议/解除租赁合同) 模糊匹配")
    private Integer fcaTypeLike;

    private List<Integer> fcaTypeIn;


    @ApiModelProperty(value = "关联合同id 精确匹配")
    private Long fcaContractIdEqualTo;

    @ApiModelProperty(value = "关联合同id 模糊匹配")
    private Long fcaContractIdLike;

    private List<Long> fcaContractIdIn;

    @ApiModelProperty(value = "关联合同编号 精确匹配")
    private String fcaContractNoEqualTo;

    @ApiModelProperty(value = "关联合同编号 模糊匹配")
    private String fcaContractNoLike;


    @ApiModelProperty(value = "公共-补充协议合同号(非合同表) 精确匹配")
    private String fcaAssociateContractNoEqualTo;

    @ApiModelProperty(value = "公共-补充协议合同号(非合同表) 模糊匹配")
    private String fcaAssociateContractNoLike;


    @ApiModelProperty(value = "提前还车-租赁结束日期 大于或等于")
    @DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss", timezone = "GMT+8")
    private java.util.Date fcaLeaseEndDateGreaterThanOrEqualTo;

    @DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss", timezone = "GMT+8")
    @ApiModelProperty(value = "提前还车-租赁结束日期 小于或等于")
    private java.util.Date fcaLeaseEndDateLessThanOrEqualTo;
    @ApiModelProperty(value = "提前还车-租赁结束日期 精确匹配")
    private java.util.Date fcaLeaseEndDateEqualTo;

    @ApiModelProperty(value = "提前还车-租赁结束日期 模糊匹配")
    private java.util.Date fcaLeaseEndDateLike;


    @ApiModelProperty(value = "换车协议-新车车牌号 精确匹配")
    private String fcaNewCarPlateNumEqualTo;

    @ApiModelProperty(value = "换车协议-新车车牌号 模糊匹配")
    private String fcaNewCarPlateNumLike;


    @ApiModelProperty(value = "换车协议-新车交付日期 大于或等于")
    @DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss", timezone = "GMT+8")
    private java.util.Date fcaNewHandoverDateGreaterThanOrEqualTo;

    @DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss", timezone = "GMT+8")
    @ApiModelProperty(value = "换车协议-新车交付日期 小于或等于")
    private java.util.Date fcaNewHandoverDateLessThanOrEqualTo;
    @ApiModelProperty(value = "换车协议-新车交付日期 精确匹配")
    private java.util.Date fcaNewHandoverDateEqualTo;

    @ApiModelProperty(value = "换车协议-新车交付日期 模糊匹配")
    private java.util.Date fcaNewHandoverDateLike;


    @ApiModelProperty(value = "换车协议-旧车归还日期 大于或等于")
    @DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss", timezone = "GMT+8")
    private java.util.Date fcaOldCarReturnDateGreaterThanOrEqualTo;

    @DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss", timezone = "GMT+8")
    @ApiModelProperty(value = "换车协议-旧车归还日期 小于或等于")
    private java.util.Date fcaOldCarReturnDateLessThanOrEqualTo;
    @ApiModelProperty(value = "换车协议-旧车归还日期 精确匹配")
    private java.util.Date fcaOldCarReturnDateEqualTo;

    @ApiModelProperty(value = "换车协议-旧车归还日期 模糊匹配")
    private java.util.Date fcaOldCarReturnDateLike;


    @ApiModelProperty(value = "解除合同-解除合同日期 大于或等于")
    @DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss", timezone = "GMT+8")
    private java.util.Date fcaContractTerminateDateGreaterThanOrEqualTo;

    @DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss", timezone = "GMT+8")
    @ApiModelProperty(value = "解除合同-解除合同日期 小于或等于")
    private java.util.Date fcaContractTerminateDateLessThanOrEqualTo;
    @ApiModelProperty(value = "解除合同-解除合同日期 精确匹配")
    private java.util.Date fcaContractTerminateDateEqualTo;

    @ApiModelProperty(value = "解除合同-解除合同日期 模糊匹配")
    private java.util.Date fcaContractTerminateDateLike;


    @ApiModelProperty(value = "解除合同-信息服务费 精确匹配")
    private Double fcaInformationFeeEqualTo;

    @ApiModelProperty(value = "解除合同-信息服务费 模糊匹配")
    private Double fcaInformationFeeLike;


    @ApiModelProperty(value = "解除合同-支付方式 (0, 保证金抵扣(1, 租金抵扣)2, 新账单支付); 精确匹配")
    private Integer fcaPayTypeEqualTo;


    @ApiModelProperty(value = "解除合同-支付方式 (0, 保证金抵扣(1, 租金抵扣)2, 新账单支付); 模糊匹配")
    private Integer fcaPayTypeLike;
    }
