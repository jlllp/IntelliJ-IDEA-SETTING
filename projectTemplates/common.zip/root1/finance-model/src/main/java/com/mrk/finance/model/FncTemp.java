package com.mrk.finance.model;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.mrk.common.base.BaseEntity;
import io.swagger.annotations.ApiModelProperty;
import lombok.Getter;
import lombok.Setter;
import org.springframework.format.annotation.DateTimeFormat;

import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import java.io.Serializable;

@Setter
@Getter
public class FncTemp extends BaseEntity implements Serializable {
private static final long serialVersionUID=1L;


    /**主键 */
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @ApiModelProperty(value = "主键")
    private Long fncId;

    /**城市 */
    @ApiModelProperty(value = "城市")
    private String fncCity;

    /**司机id */
    @ApiModelProperty(value = "司机id")
    private Long fncMemberId;

    /**姓名 */
    @ApiModelProperty(value = "姓名")
    private String fncName;

    /**身份证号 */
    @ApiModelProperty(value = "身份证号")
    private String fncIdnumber;

    /**车架号 */
    @ApiModelProperty(value = "车架号")
    private String fncCarVin;

    /**协议编号 */
    @ApiModelProperty(value = "协议编号")
    private String fncAgreementNumber;

    /**起租日期 */
    @DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss", timezone = "GMT+8")
    @ApiModelProperty(value = "起租日期")
    private java.util.Date fncRentDate;

    /**租期 */
    @ApiModelProperty(value = "租期")
    private Integer fncLeaseCount;

    /**代扣月份 */
    @DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss", timezone = "GMT+8")
    @ApiModelProperty(value = "代扣月份")
    private java.util.Date fncMonth;

    /**月租金 */
    @ApiModelProperty(value = "月租金")
    private Double fncMonthRent;

    /**月扣款总额 */
    @ApiModelProperty(value = "月扣款总额")
    private Double fncMonthWithhold;

    /**错误信息 */
    @ApiModelProperty(value = "错误信息")
    private String fncErrorMsg;

    /**是否错误（0否，1是） */
    @ApiModelProperty(value = "是否错误（0否，1是）")
    private Integer fncError;

    /**账单号（滴滴） */
    @ApiModelProperty(value = "账单号（滴滴）")
    private String fncAccountNo;

    /**操作标识 */
    @ApiModelProperty(value = "操作标识")
    private String fncOperateCode;

    /**交易时间 */
    @DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss", timezone = "GMT+8")
    @ApiModelProperty(value = "交易时间")
    private java.util.Date fncTradeTime;

    /**交易金额 */
    @ApiModelProperty(value = "交易金额")
    private Double fncTradeAmount;

    /**交易账目 */
    @ApiModelProperty(value = "交易账目")
    private String fncTradeNames;

    /**交易流水号 */
    @ApiModelProperty(value = "交易流水号")
    private String fncAccountDealFlow;

    /**交易方 */
    @ApiModelProperty(value = "交易方")
    private String fncTradeParty;

    /**订单号 */
    @ApiModelProperty(value = "订单号")
    private String fncOrderNo;

    /**银行流水-凭证号 */
    @ApiModelProperty(value = "银行流水-凭证号")
    private String fncVoucherNo;

    /**银行流水-本方账号 */
    @ApiModelProperty(value = "银行流水-本方账号")
    private String fncOwnAccount;

    /**月租金余量 */
    @ApiModelProperty(value = "月租金余量")
    private Double fncMonthRentBalance;

    /**银行流水-摘要 */
    @ApiModelProperty(value = "银行流水-摘要")
    private String fncDigest;

    /**银行流水-对方账号 */
    @ApiModelProperty(value = "银行流水-对方账号")
    private String fncOtherAccount;

    /**对方单位名称 */
    @ApiModelProperty(value = "对方单位名称")
    private String fncOtherUnitName;

    /**银行流水-借/贷 */
    @ApiModelProperty(value = "银行流水-借/贷")
    private String fncLoanType;

    /**银行流水-交易时间 */
    @DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss", timezone = "GMT+8")
    @ApiModelProperty(value = "银行流水-交易时间")
    private java.util.Date fncDealTime;

    /**银行流水-借方发生额度 */
    @ApiModelProperty(value = "银行流水-借方发生额度")
    private Double fncBorrowAmount;

    /**银行流水-贷方发生额度 */
    @ApiModelProperty(value = "银行流水-贷方发生额度")
    private Double fncCreditAmount;

    /**银行流水-用途 */
    @ApiModelProperty(value = "银行流水-用途")
    private String fncUse;
    }
