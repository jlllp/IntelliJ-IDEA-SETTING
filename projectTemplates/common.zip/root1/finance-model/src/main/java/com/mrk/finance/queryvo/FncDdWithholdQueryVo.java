package com.mrk.finance.queryvo;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.mrk.common.base.BaseQueryVo;
import io.swagger.annotations.ApiModelProperty;
import lombok.Getter;
import lombok.Setter;
import org.springframework.format.annotation.DateTimeFormat;

import java.util.List;

@Setter
@Getter
public class FncDdWithholdQueryVo extends BaseQueryVo {



    @ApiModelProperty(value = "主键 精确匹配")
    private Long fdwIdEqualTo;

    @ApiModelProperty(value = "主键 模糊匹配")
    private Long fdwIdLike;


    @ApiModelProperty(value = "交易名目 精确匹配")
    private String fdwTradeNamesEqualTo;

    @ApiModelProperty(value = "交易名目 模糊匹配")
    private String fdwTradeNamesLike;


    @ApiModelProperty(value = "账户交易流水 精确匹配")
    private String fdwAccountDealFlowEqualTo;

    @ApiModelProperty(value = "账户交易流水 模糊匹配")
    private String fdwAccountDealFlowLike;


    @ApiModelProperty(value = "交易时间 大于或等于")
    @DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss", timezone = "GMT+8")
    private java.util.Date fdwTradeTimeGreaterThanOrEqualTo;

    @DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss", timezone = "GMT+8")
    @ApiModelProperty(value = "交易时间 小于或等于")
    private java.util.Date fdwTradeTimeLessThanOrEqualTo;
    @ApiModelProperty(value = "交易时间 精确匹配")
    private java.util.Date fdwTradeTimeEqualTo;

    @ApiModelProperty(value = "交易时间 模糊匹配")
    private java.util.Date fdwTradeTimeLike;


    @ApiModelProperty(value = "交易方 精确匹配")
    private String fdwTradePartyEqualTo;

    @ApiModelProperty(value = "交易方 模糊匹配")
    private String fdwTradePartyLike;


    @ApiModelProperty(value = "交易金额 精确匹配")
    private Double fdwTradeAmountEqualTo;

    @ApiModelProperty(value = "交易金额 模糊匹配")
    private Double fdwTradeAmountLike;

    @ApiModelProperty(value = "交易金额 小于或等于")
    private Double fdwTradeAmountLessThanOrEqualTo;
    @ApiModelProperty(value = "交易金额 大于或等于")
    private Double fdwTradeAmountGreaterThanOrEqualTo;


    @ApiModelProperty(value = "订单号 精确匹配")
    private String fdwOrderNoEqualTo;

    @ApiModelProperty(value = "订单号 模糊匹配")
    private String fdwOrderNoLike;


    @ApiModelProperty(value = "账单号（滴滴） 精确匹配")
    private String fdwAccountNoEqualTo;

    @ApiModelProperty(value = "账单号（滴滴） 模糊匹配")
    private String fdwAccountNoLike;


    @ApiModelProperty(value = "车辆VIN码 精确匹配")
    private String fdwCarVinEqualTo;

    private List<String> fdwCarVinIn;

    @ApiModelProperty(value = "车辆VIN码 模糊匹配")
    private String fdwCarVinLike;


    @ApiModelProperty(value = "匹配状态 精确匹配")
    private Integer fdwMatchStateEqualTo;

    @ApiModelProperty(value = "匹配状态 模糊匹配")
    private Integer fdwMatchStateLike;

    private List<Integer> fdwMatchStateIn;


    @ApiModelProperty(value = "匹配账单 精确匹配")
    private String fdwMatchBillEqualTo;

    @ApiModelProperty(value = "匹配账单 模糊匹配")
    private String fdwMatchBillLike;


    @ApiModelProperty(value = "匹配方式 精确匹配")
    private Integer fdwMatchWayEqualTo;

    @ApiModelProperty(value = "匹配方式 模糊匹配")
    private Integer fdwMatchWayLike;


    @ApiModelProperty(value = "已匹配金额 精确匹配")
    private Double fdwMatchedAmountEqualTo;

    @ApiModelProperty(value = "已匹配金额 模糊匹配")
    private Double fdwMatchedAmountLike;

    @ApiModelProperty(value = "已匹配金额 小于或等于")
    private Double fdwMatchedAmountLessThanOrEqualTo;
    @ApiModelProperty(value = "已匹配金额 大于或等于")
    private Double fdwMatchedAmountGreaterThanOrEqualTo;


    @ApiModelProperty(value = "未匹配金额 精确匹配")
    private Double fdwNotMatchAmountEqualTo;

    @ApiModelProperty(value = "未匹配金额 模糊匹配")
    private Double fdwNotMatchAmountLike;

    @ApiModelProperty(value = "未匹配金额 小于或等于")
    private Double fdwNotMatchAmountLessThanOrEqualTo;
    @ApiModelProperty(value = "未匹配金额 大于或等于")
    private Double fdwNotMatchAmountGreaterThanOrEqualTo;
    }
