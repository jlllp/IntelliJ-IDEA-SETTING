package com.mrk.finance.service;

import com.github.pagehelper.PageInfo;
import com.mrk.finance.model.FncBankWater;
import com.mrk.finance.queryvo.FncBankWaterQueryVo;

import java.util.List;

/**
 * @Description: FncBankWater
 */
public interface FncBankWaterService {
    /**
     * 分页查询
     *
     * @param queryVo 前端查询对象
     * @return 分页查询数据
     */
    PageInfo<FncBankWater> page(FncBankWaterQueryVo queryVo);

    /**
     * 列表查询
     * @param queryVo 前端查询对象
     * @return 分页查询数据
     */
    List<FncBankWater> list(FncBankWaterQueryVo queryVo);

    /**
     * 新增
     *
     * @param entity
     * @return 结果
     */
    int add(FncBankWater entity);

    /**
     * 批量新增
     * @author Frank.Tang
     * @return *
     */
    int insertList(List<FncBankWater> waters);

    /**
     * 修改
     *
     * @param entity
     * @return 结果
     */
    int update(FncBankWater entity);

    /**
     * 删除
     */
    int delete(Long id);

    /**
     * 通过ID查询
     * @param id
     */
    FncBankWater getById(Long id);

    /**
     * 通过ids查询
     * @author Frank.Tang
     * @return *
     */
    List<FncBankWater> getByIds(List<Long> ids);

    /**
     * 通过账单id查询
     * @author Frank.Tang
     * @return *
     */
    List<FncBankWater> selectByBillId(Long id);

}
