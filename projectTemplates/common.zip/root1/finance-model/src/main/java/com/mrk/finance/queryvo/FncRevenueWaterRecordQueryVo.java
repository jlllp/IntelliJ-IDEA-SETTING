package com.mrk.finance.queryvo;

import com.mrk.common.base.BaseQueryVo;
import io.swagger.annotations.ApiModelProperty;
import lombok.Getter;
import lombok.Setter;

@Setter
@Getter
public class FncRevenueWaterRecordQueryVo extends BaseQueryVo {



    @ApiModelProperty(value = "主键 精确匹配")
    private Long frwrIdEqualTo;

    @ApiModelProperty(value = "主键 模糊匹配")
    private Long frwrIdLike;


    @ApiModelProperty(value = "账单ID 精确匹配")
    private Long frwrBillIdEqualTo;

    @ApiModelProperty(value = "账单ID 模糊匹配")
    private Long frwrBillIdLike;


    @ApiModelProperty(value = "收支流水类型 精确匹配")
    private Integer frwrRevenueTypeEqualTo;

    @ApiModelProperty(value = "收支流水类型 模糊匹配")
    private Integer frwrRevenueTypeLike;


    @ApiModelProperty(value = "收支流水ID 精确匹配")
    private Long frwrRevenueIdEqualTo;

    @ApiModelProperty(value = "收支流水ID 模糊匹配")
    private Long frwrRevenueIdLike;


    @ApiModelProperty(value = "匹配方式 精确匹配")
    private Integer frwrMatchStateEqualTo;

    @ApiModelProperty(value = "匹配方式 模糊匹配")
    private Integer frwrMatchStateLike;


    @ApiModelProperty(value = "描述 精确匹配")
    private String frwrDescribeEqualTo;

    @ApiModelProperty(value = "描述 模糊匹配")
    private String frwrDescribeLike;
    }
