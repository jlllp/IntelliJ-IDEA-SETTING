package com.mrk.finance.model;

import com.mrk.common.base.BaseEntity;
import io.swagger.annotations.ApiModelProperty;
import lombok.Getter;
import lombok.Setter;

import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import java.io.Serializable;

@Setter
@Getter
public class FncContractRentalFees extends BaseEntity implements Serializable {
private static final long serialVersionUID=1L;


    /**主键 */
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @ApiModelProperty(value = "主键")
    private Long fcrfId;

    /**合同id */
    @ApiModelProperty(value = "合同id")
    private Long fcrfContractId;

    /**租金费用id */
    @ApiModelProperty(value = "租金费用id")
    private Long fcrfRentFeesId;

    /**是否填写 */
    @ApiModelProperty(value = "是否填写")
    private Integer fcrfWrite;

    /**数据值 */
    @ApiModelProperty(value = "数据值")
    private String fcrfValue;
    }
