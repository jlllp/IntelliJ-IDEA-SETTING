package com.mrk.finance.service;

import com.github.pagehelper.PageInfo;
import com.mrk.finance.model.FncConfirmIncome;
import com.mrk.finance.queryvo.FncConfirmIncomeQueryVo;

import java.util.List;

/**
 * @Description: FncConfirmIncome
 */
public interface FncConfirmIncomeService {
    /**
     * 分页查询
     *
     * @param queryVo 前端查询对象
     * @return 分页查询数据
     */
    PageInfo<FncConfirmIncome> page(FncConfirmIncomeQueryVo queryVo);

    /**
     * 列表查询
     * @param queryVo 前端查询对象
     * @return 分页查询数据
     */
    List<FncConfirmIncome> list(FncConfirmIncomeQueryVo queryVo);

    /**
     * 新增
     *
     * @param entity
     * @return 结果
     */
    int add(FncConfirmIncome entity);

    /**
     * 修改
     *
     * @param entity
     * @return 结果
     */
    int update(FncConfirmIncome entity);

    /**
     * 删除
     */
    int delete(Long id);

    /**
    * 通过ID查询
    * @param id
    */
    FncConfirmIncome getById(Long id);

    /**
     * 根据部门查询收入
     * @param deptId 部门id
     * @return 部门收入
     */
    List<FncConfirmIncome> getByDept(Long deptId);
}
