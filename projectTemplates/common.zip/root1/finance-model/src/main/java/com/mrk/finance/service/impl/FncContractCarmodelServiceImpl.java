package com.mrk.finance.service.impl;

import com.github.pagehelper.PageInfo;
import com.mrk.common.constant.BaseConstants;
import com.mrk.common.utils.bean.BeanUtils;
import com.mrk.common.utils.jwt.JWTUtil;
import com.mrk.common.utils.page.PageUtils;
import com.mrk.common.utils.text.StringUtils;
import com.mrk.finance.dao.FncContractCarmodelMapper;
import com.mrk.finance.example.FncContractCarmodelExample;
import com.mrk.finance.model.FncContractCarmodel;
import com.mrk.finance.query.FncContractCarmodelQuery;
import com.mrk.finance.queryvo.FncContractCarmodelQueryVo;
import com.mrk.finance.service.FncContractCarmodelService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import javax.annotation.Resource;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;


/**
 * @Description: FncContractCarmodelServiceImpl
 */
@Service
@Slf4j
public class FncContractCarmodelServiceImpl implements FncContractCarmodelService {
    @Resource
    private FncContractCarmodelMapper fncContractCarmodelMapper;

    @Override
    public PageInfo<FncContractCarmodel> page(FncContractCarmodelQueryVo queryVo) {
        PageUtils.startPage();
        List<FncContractCarmodel> list = this.list(queryVo);
        return new PageInfo<>(list);
    }

    @Override
    public List<FncContractCarmodel> list(FncContractCarmodelQueryVo queryVo) {
        FncContractCarmodelQuery query = new FncContractCarmodelQuery();
        BeanUtils.copyBeanProp(queryVo, query);
        query.setSidx(StringUtils.camelToUnderlineAndFilterText(query.getSidx()));
        return fncContractCarmodelMapper.selectByExample(query.getCrieria());
    }

    @Override
    public List<FncContractCarmodel> batchSelectByContractIds(List<Long> ids) {
        if (ids == null || ids.isEmpty()) {
            return new ArrayList<>();
        }

        FncContractCarmodelQueryVo queryVo = new FncContractCarmodelQueryVo();
        queryVo.setFccContractIdIn(ids);

        List<FncContractCarmodel> list = this.list(queryVo);

        return list == null || list.isEmpty() ? new ArrayList<>() : list;
    }

    @Override
    @Transactional(rollbackFor = Exception.class)
    public int add(FncContractCarmodel entity) {
        entity.setCreatetime(new Date());
        entity.setCreateuser(JWTUtil.getNikeName());
        entity.setDr(BaseConstants.DR_NO);
        return fncContractCarmodelMapper.insert(entity);
    }

    @Override
    public int addList(List<FncContractCarmodel> carmodels) {
        if (carmodels == null || carmodels.isEmpty()) {
            return 0;
        }
        Date date = new Date();
        String name = JWTUtil.getNikeName();
        for (FncContractCarmodel carmodel : carmodels) {
            carmodel.setDr(BaseConstants.DR_NO);
            carmodel.setCreatetime(date);
            carmodel.setCreateuser(name);
        }
        return fncContractCarmodelMapper.insertList(carmodels);
    }

    @Override
    @Transactional(rollbackFor = Exception.class)
    public int update(FncContractCarmodel entity) {
        entity.setUpdatetime(new Date());
        entity.setUpdateuser(JWTUtil.getNikeName());
        return fncContractCarmodelMapper.updateByPrimaryKey(entity);
    }

    @Override
    public int updateSelective(FncContractCarmodel entity) {
        entity.setUpdatetime(new Date());
        entity.setUpdateuser(JWTUtil.getNikeName());
        return fncContractCarmodelMapper.updateByPrimaryKeySelective(entity);
    }

    @Override
    @Transactional(rollbackFor = Exception.class)
    public int delete(Long id) {
        return fncContractCarmodelMapper.deleteByPrimaryKey(id);
    }

    @Override
    public FncContractCarmodel getById(Long id) {
        return fncContractCarmodelMapper.selectByPrimaryKey(id);
    }

    @Override
    public List<FncContractCarmodel> selectByFncContractManagementId(Long fncContractManagementId) {
        FncContractCarmodelExample example = new FncContractCarmodelExample();
        example.createCriteria()
                .andFccContractIdEqualTo(fncContractManagementId)
                .andDrEqualTo(BaseConstants.DR_NO);
        return fncContractCarmodelMapper.selectByExample(example);
    }
}
