package com.mrk.finance.service.impl;

import com.github.pagehelper.PageInfo;
import com.mrk.common.constant.BaseConstants;
import com.mrk.common.utils.bean.BeanUtils;
import com.mrk.common.utils.jwt.JWTUtil;
import com.mrk.common.utils.page.PageUtils;
import com.mrk.common.utils.text.StringUtils;
import com.mrk.finance.dao.FncContractAdditionMapper;
import com.mrk.finance.example.FncContractAdditionExample;
import com.mrk.finance.model.FncContractAddition;
import com.mrk.finance.query.FncContractAdditionQuery;
import com.mrk.finance.queryvo.FncContractAdditionQueryVo;
import com.mrk.finance.service.FncContractAdditionService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import javax.annotation.Resource;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;


/**
 * @Description: FncContractAdditionServiceImpl
 */
@Service
@Slf4j
public class FncContractAdditionServiceImpl implements FncContractAdditionService {
    @Resource
    private FncContractAdditionMapper fncContractAdditionMapper;

    @Override
    public PageInfo<FncContractAddition> page(FncContractAdditionQueryVo queryVo){
        PageUtils.startPage();
        List<FncContractAddition> list = this.list(queryVo);
        return new PageInfo<>(list);
    }

    @Override
    public List<FncContractAddition> list(FncContractAdditionQueryVo queryVo){
        FncContractAdditionQuery query = new FncContractAdditionQuery();
        BeanUtils.copyBeanProp(queryVo, query);
        query.setSidx(StringUtils.camelToUnderlineAndFilterText(query.getSidx()));
        return fncContractAdditionMapper.selectByExample(query.getCrieria());
    }

    @Override
    public List<FncContractAddition> selectByContractIds(List<Long> ids) {
        if (ids == null || ids.isEmpty()) {
            return new ArrayList<>();
        }

        FncContractAdditionQueryVo queryVo = new FncContractAdditionQueryVo();
        queryVo.setFcaContractIdIn(ids);
        return list(queryVo);
    }

    @Override
    @Transactional(rollbackFor = Exception.class)
    public int add(FncContractAddition entity){
        entity.setCreatetime(new Date());
        entity.setCreateuser(JWTUtil.getNikeName());
        entity.setDr(BaseConstants.DR_NO);
        return fncContractAdditionMapper.insert(entity);
    }

    @Override
    @Transactional(rollbackFor = Exception.class)
    public int update(FncContractAddition entity){
        entity.setUpdatetime(new Date());
        entity.setUpdateuser(JWTUtil.getNikeName());
        return fncContractAdditionMapper.updateByPrimaryKey(entity);
    }

    @Override
    public int updateSelective(FncContractAddition entity) {
        entity.setUpdatetime(new Date());
        entity.setUpdateuser(JWTUtil.getNikeName());
        return fncContractAdditionMapper.updateByPrimaryKeySelective(entity);
    }

    @Override
    @Transactional(rollbackFor = Exception.class)
    public int delete(Long id){
        FncContractAddition addition = getById(id);

        addition.setDr(BaseConstants.DR_YES);

        return update(addition);
    }

    @Override
    public FncContractAddition getById(Long id){
        return fncContractAdditionMapper.selectByPrimaryKey(id);
    }

    @Override
    public List<FncContractAddition> getByLeaseEnd(Date start, Date end) {
        FncContractAdditionExample example = new FncContractAdditionExample();
        example.createCriteria()
                .andDrEqualTo(BaseConstants.DR_NO)
                .andFcaLeaseEndDateGreaterThanOrEqualTo(start)
                .andFcaLeaseEndDateLessThanOrEqualTo(end);
        return fncContractAdditionMapper.selectByExample(example);
    }

    @Override
    public List<FncContractAddition> getByTerminate(Date start, Date end) {
        FncContractAdditionExample example = new FncContractAdditionExample();
        example.createCriteria()
                .andDrEqualTo(BaseConstants.DR_NO)
                .andFcaContractTerminateDateGreaterThanOrEqualTo(start)
                .andFcaContractTerminateDateLessThanOrEqualTo(end);
        return fncContractAdditionMapper.selectByExample(example);
    }
}
