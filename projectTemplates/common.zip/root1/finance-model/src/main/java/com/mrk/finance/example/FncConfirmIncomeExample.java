package com.mrk.finance.example;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

public class FncConfirmIncomeExample {
    protected String orderByClause;

    protected boolean distinct;

    protected List<Criteria> oredCriteria;

    public FncConfirmIncomeExample() {
        oredCriteria = new ArrayList<Criteria>();
    }

    public void setOrderByClause(String orderByClause) {
        this.orderByClause = orderByClause;
    }

    public String getOrderByClause() {
        return orderByClause;
    }

    public void setDistinct(boolean distinct) {
        this.distinct = distinct;
    }

    public boolean isDistinct() {
        return distinct;
    }

    public List<Criteria> getOredCriteria() {
        return oredCriteria;
    }

    public void or(Criteria criteria) {
        oredCriteria.add(criteria);
    }

    public Criteria or() {
        Criteria criteria = createCriteriaInternal();
        oredCriteria.add(criteria);
        return criteria;
    }

    public Criteria createCriteria() {
        Criteria criteria = createCriteriaInternal();
        if (oredCriteria.size() == 0) {
            oredCriteria.add(criteria);
        }
        return criteria;
    }

    protected Criteria createCriteriaInternal() {
        Criteria criteria = new Criteria();
        return criteria;
    }

    public void clear() {
        oredCriteria.clear();
        orderByClause = null;
        distinct = false;
    }

    protected abstract static class GeneratedCriteria {
        protected List<Criterion> criteria;

        protected GeneratedCriteria() {
            super();
            criteria = new ArrayList<Criterion>();
        }

        public boolean isValid() {
            return criteria.size() > 0;
        }

        public List<Criterion> getAllCriteria() {
            return criteria;
        }

        public List<Criterion> getCriteria() {
            return criteria;
        }

        protected void addCriterion(String condition) {
            if (condition == null) {
                throw new RuntimeException("Value for condition cannot be null");
            }
            criteria.add(new Criterion(condition));
        }

        protected void addCriterion(String condition, Object value, String property) {
            if (value == null) {
                throw new RuntimeException("Value for " + property + " cannot be null");
            }
            criteria.add(new Criterion(condition, value));
        }

        protected void addCriterion(String condition, Object value1, Object value2, String property) {
            if (value1 == null || value2 == null) {
                throw new RuntimeException("Between values for " + property + " cannot be null");
            }
            criteria.add(new Criterion(condition, value1, value2));
        }

        public Criteria andFciIdIsNull() {
            addCriterion("fci_id is null");
            return (Criteria) this;
        }

        public Criteria andFciIdIsNotNull() {
            addCriterion("fci_id is not null");
            return (Criteria) this;
        }

        public Criteria andFciIdEqualTo(Long value) {
            addCriterion("fci_id =", value, "fciId");
            return (Criteria) this;
        }

        public Criteria andFciIdNotEqualTo(Long value) {
            addCriterion("fci_id <>", value, "fciId");
            return (Criteria) this;
        }

        public Criteria andFciIdGreaterThan(Long value) {
            addCriterion("fci_id >", value, "fciId");
            return (Criteria) this;
        }

        public Criteria andFciIdGreaterThanOrEqualTo(Long value) {
            addCriterion("fci_id >=", value, "fciId");
            return (Criteria) this;
        }

        public Criteria andFciIdLessThan(Long value) {
            addCriterion("fci_id <", value, "fciId");
            return (Criteria) this;
        }

        public Criteria andFciIdLessThanOrEqualTo(Long value) {
            addCriterion("fci_id <=", value, "fciId");
            return (Criteria) this;
        }

        public Criteria andFciIdIn(List<Long> values) {
            addCriterion("fci_id in", values, "fciId");
            return (Criteria) this;
        }

        public Criteria andFciIdNotIn(List<Long> values) {
            addCriterion("fci_id not in", values, "fciId");
            return (Criteria) this;
        }

        public Criteria andFciIdBetween(Long value1, Long value2) {
            addCriterion("fci_id between", value1, value2, "fciId");
            return (Criteria) this;
        }

        public Criteria andFciIdNotBetween(Long value1, Long value2) {
            addCriterion("fci_id not between", value1, value2, "fciId");
            return (Criteria) this;
        }

        public Criteria andFciDeptIdIsNull() {
            addCriterion("fci_dept_id is null");
            return (Criteria) this;
        }

        public Criteria andFciDeptIdIsNotNull() {
            addCriterion("fci_dept_id is not null");
            return (Criteria) this;
        }

        public Criteria andFciDeptIdEqualTo(Long value) {
            addCriterion("fci_dept_id =", value, "fciDeptId");
            return (Criteria) this;
        }

        public Criteria andFciDeptIdNotEqualTo(Long value) {
            addCriterion("fci_dept_id <>", value, "fciDeptId");
            return (Criteria) this;
        }

        public Criteria andFciDeptIdGreaterThan(Long value) {
            addCriterion("fci_dept_id >", value, "fciDeptId");
            return (Criteria) this;
        }

        public Criteria andFciDeptIdGreaterThanOrEqualTo(Long value) {
            addCriterion("fci_dept_id >=", value, "fciDeptId");
            return (Criteria) this;
        }

        public Criteria andFciDeptIdLessThan(Long value) {
            addCriterion("fci_dept_id <", value, "fciDeptId");
            return (Criteria) this;
        }

        public Criteria andFciDeptIdLessThanOrEqualTo(Long value) {
            addCriterion("fci_dept_id <=", value, "fciDeptId");
            return (Criteria) this;
        }

        public Criteria andFciDeptIdIn(List<Long> values) {
            addCriterion("fci_dept_id in", values, "fciDeptId");
            return (Criteria) this;
        }

        public Criteria andFciDeptIdNotIn(List<Long> values) {
            addCriterion("fci_dept_id not in", values, "fciDeptId");
            return (Criteria) this;
        }

        public Criteria andFciDeptIdBetween(Long value1, Long value2) {
            addCriterion("fci_dept_id between", value1, value2, "fciDeptId");
            return (Criteria) this;
        }

        public Criteria andFciDeptIdNotBetween(Long value1, Long value2) {
            addCriterion("fci_dept_id not between", value1, value2, "fciDeptId");
            return (Criteria) this;
        }

        public Criteria andFciIncomeMonthIsNull() {
            addCriterion("fci_income_month is null");
            return (Criteria) this;
        }

        public Criteria andFciIncomeMonthIsNotNull() {
            addCriterion("fci_income_month is not null");
            return (Criteria) this;
        }

        public Criteria andFciIncomeMonthEqualTo(Date value) {
            addCriterion("fci_income_month =", value, "fciIncomeMonth");
            return (Criteria) this;
        }

        public Criteria andFciIncomeMonthNotEqualTo(Date value) {
            addCriterion("fci_income_month <>", value, "fciIncomeMonth");
            return (Criteria) this;
        }

        public Criteria andFciIncomeMonthGreaterThan(Date value) {
            addCriterion("fci_income_month >", value, "fciIncomeMonth");
            return (Criteria) this;
        }

        public Criteria andFciIncomeMonthGreaterThanOrEqualTo(Date value) {
            addCriterion("fci_income_month >=", value, "fciIncomeMonth");
            return (Criteria) this;
        }

        public Criteria andFciIncomeMonthLessThan(Date value) {
            addCriterion("fci_income_month <", value, "fciIncomeMonth");
            return (Criteria) this;
        }

        public Criteria andFciIncomeMonthLessThanOrEqualTo(Date value) {
            addCriterion("fci_income_month <=", value, "fciIncomeMonth");
            return (Criteria) this;
        }

        public Criteria andFciIncomeMonthIn(List<Date> values) {
            addCriterion("fci_income_month in", values, "fciIncomeMonth");
            return (Criteria) this;
        }

        public Criteria andFciIncomeMonthNotIn(List<Date> values) {
            addCriterion("fci_income_month not in", values, "fciIncomeMonth");
            return (Criteria) this;
        }

        public Criteria andFciIncomeMonthBetween(Date value1, Date value2) {
            addCriterion("fci_income_month between", value1, value2, "fciIncomeMonth");
            return (Criteria) this;
        }

        public Criteria andFciIncomeMonthNotBetween(Date value1, Date value2) {
            addCriterion("fci_income_month not between", value1, value2, "fciIncomeMonth");
            return (Criteria) this;
        }

        public Criteria andFciRentIncomeIsNull() {
            addCriterion("fci_rent_income is null");
            return (Criteria) this;
        }

        public Criteria andFciRentIncomeIsNotNull() {
            addCriterion("fci_rent_income is not null");
            return (Criteria) this;
        }

        public Criteria andFciRentIncomeEqualTo(Double value) {
            addCriterion("fci_rent_income =", value, "fciRentIncome");
            return (Criteria) this;
        }

        public Criteria andFciRentIncomeNotEqualTo(Double value) {
            addCriterion("fci_rent_income <>", value, "fciRentIncome");
            return (Criteria) this;
        }

        public Criteria andFciRentIncomeGreaterThan(Double value) {
            addCriterion("fci_rent_income >", value, "fciRentIncome");
            return (Criteria) this;
        }

        public Criteria andFciRentIncomeGreaterThanOrEqualTo(Double value) {
            addCriterion("fci_rent_income >=", value, "fciRentIncome");
            return (Criteria) this;
        }

        public Criteria andFciRentIncomeLessThan(Double value) {
            addCriterion("fci_rent_income <", value, "fciRentIncome");
            return (Criteria) this;
        }

        public Criteria andFciRentIncomeLessThanOrEqualTo(Double value) {
            addCriterion("fci_rent_income <=", value, "fciRentIncome");
            return (Criteria) this;
        }

        public Criteria andFciRentIncomeIn(List<Double> values) {
            addCriterion("fci_rent_income in", values, "fciRentIncome");
            return (Criteria) this;
        }

        public Criteria andFciRentIncomeNotIn(List<Double> values) {
            addCriterion("fci_rent_income not in", values, "fciRentIncome");
            return (Criteria) this;
        }

        public Criteria andFciRentIncomeBetween(Double value1, Double value2) {
            addCriterion("fci_rent_income between", value1, value2, "fciRentIncome");
            return (Criteria) this;
        }

        public Criteria andFciRentIncomeNotBetween(Double value1, Double value2) {
            addCriterion("fci_rent_income not between", value1, value2, "fciRentIncome");
            return (Criteria) this;
        }

        public Criteria andFciPenaltyIncomeIsNull() {
            addCriterion("fci_penalty_income is null");
            return (Criteria) this;
        }

        public Criteria andFciPenaltyIncomeIsNotNull() {
            addCriterion("fci_penalty_income is not null");
            return (Criteria) this;
        }

        public Criteria andFciPenaltyIncomeEqualTo(Double value) {
            addCriterion("fci_penalty_income =", value, "fciPenaltyIncome");
            return (Criteria) this;
        }

        public Criteria andFciPenaltyIncomeNotEqualTo(Double value) {
            addCriterion("fci_penalty_income <>", value, "fciPenaltyIncome");
            return (Criteria) this;
        }

        public Criteria andFciPenaltyIncomeGreaterThan(Double value) {
            addCriterion("fci_penalty_income >", value, "fciPenaltyIncome");
            return (Criteria) this;
        }

        public Criteria andFciPenaltyIncomeGreaterThanOrEqualTo(Double value) {
            addCriterion("fci_penalty_income >=", value, "fciPenaltyIncome");
            return (Criteria) this;
        }

        public Criteria andFciPenaltyIncomeLessThan(Double value) {
            addCriterion("fci_penalty_income <", value, "fciPenaltyIncome");
            return (Criteria) this;
        }

        public Criteria andFciPenaltyIncomeLessThanOrEqualTo(Double value) {
            addCriterion("fci_penalty_income <=", value, "fciPenaltyIncome");
            return (Criteria) this;
        }

        public Criteria andFciPenaltyIncomeIn(List<Double> values) {
            addCriterion("fci_penalty_income in", values, "fciPenaltyIncome");
            return (Criteria) this;
        }

        public Criteria andFciPenaltyIncomeNotIn(List<Double> values) {
            addCriterion("fci_penalty_income not in", values, "fciPenaltyIncome");
            return (Criteria) this;
        }

        public Criteria andFciPenaltyIncomeBetween(Double value1, Double value2) {
            addCriterion("fci_penalty_income between", value1, value2, "fciPenaltyIncome");
            return (Criteria) this;
        }

        public Criteria andFciPenaltyIncomeNotBetween(Double value1, Double value2) {
            addCriterion("fci_penalty_income not between", value1, value2, "fciPenaltyIncome");
            return (Criteria) this;
        }

        public Criteria andFciCarPurchaseIncomeIsNull() {
            addCriterion("fci_car_purchase_income is null");
            return (Criteria) this;
        }

        public Criteria andFciCarPurchaseIncomeIsNotNull() {
            addCriterion("fci_car_purchase_income is not null");
            return (Criteria) this;
        }

        public Criteria andFciCarPurchaseIncomeEqualTo(Double value) {
            addCriterion("fci_car_purchase_income =", value, "fciCarPurchaseIncome");
            return (Criteria) this;
        }

        public Criteria andFciCarPurchaseIncomeNotEqualTo(Double value) {
            addCriterion("fci_car_purchase_income <>", value, "fciCarPurchaseIncome");
            return (Criteria) this;
        }

        public Criteria andFciCarPurchaseIncomeGreaterThan(Double value) {
            addCriterion("fci_car_purchase_income >", value, "fciCarPurchaseIncome");
            return (Criteria) this;
        }

        public Criteria andFciCarPurchaseIncomeGreaterThanOrEqualTo(Double value) {
            addCriterion("fci_car_purchase_income >=", value, "fciCarPurchaseIncome");
            return (Criteria) this;
        }

        public Criteria andFciCarPurchaseIncomeLessThan(Double value) {
            addCriterion("fci_car_purchase_income <", value, "fciCarPurchaseIncome");
            return (Criteria) this;
        }

        public Criteria andFciCarPurchaseIncomeLessThanOrEqualTo(Double value) {
            addCriterion("fci_car_purchase_income <=", value, "fciCarPurchaseIncome");
            return (Criteria) this;
        }

        public Criteria andFciCarPurchaseIncomeIn(List<Double> values) {
            addCriterion("fci_car_purchase_income in", values, "fciCarPurchaseIncome");
            return (Criteria) this;
        }

        public Criteria andFciCarPurchaseIncomeNotIn(List<Double> values) {
            addCriterion("fci_car_purchase_income not in", values, "fciCarPurchaseIncome");
            return (Criteria) this;
        }

        public Criteria andFciCarPurchaseIncomeBetween(Double value1, Double value2) {
            addCriterion("fci_car_purchase_income between", value1, value2, "fciCarPurchaseIncome");
            return (Criteria) this;
        }

        public Criteria andFciCarPurchaseIncomeNotBetween(Double value1, Double value2) {
            addCriterion("fci_car_purchase_income not between", value1, value2, "fciCarPurchaseIncome");
            return (Criteria) this;
        }

        public Criteria andFciTotalIncomeIsNull() {
            addCriterion("fci_total_income is null");
            return (Criteria) this;
        }

        public Criteria andFciTotalIncomeIsNotNull() {
            addCriterion("fci_total_income is not null");
            return (Criteria) this;
        }

        public Criteria andFciTotalIncomeEqualTo(Double value) {
            addCriterion("fci_total_income =", value, "fciTotalIncome");
            return (Criteria) this;
        }

        public Criteria andFciTotalIncomeNotEqualTo(Double value) {
            addCriterion("fci_total_income <>", value, "fciTotalIncome");
            return (Criteria) this;
        }

        public Criteria andFciTotalIncomeGreaterThan(Double value) {
            addCriterion("fci_total_income >", value, "fciTotalIncome");
            return (Criteria) this;
        }

        public Criteria andFciTotalIncomeGreaterThanOrEqualTo(Double value) {
            addCriterion("fci_total_income >=", value, "fciTotalIncome");
            return (Criteria) this;
        }

        public Criteria andFciTotalIncomeLessThan(Double value) {
            addCriterion("fci_total_income <", value, "fciTotalIncome");
            return (Criteria) this;
        }

        public Criteria andFciTotalIncomeLessThanOrEqualTo(Double value) {
            addCriterion("fci_total_income <=", value, "fciTotalIncome");
            return (Criteria) this;
        }

        public Criteria andFciTotalIncomeIn(List<Double> values) {
            addCriterion("fci_total_income in", values, "fciTotalIncome");
            return (Criteria) this;
        }

        public Criteria andFciTotalIncomeNotIn(List<Double> values) {
            addCriterion("fci_total_income not in", values, "fciTotalIncome");
            return (Criteria) this;
        }

        public Criteria andFciTotalIncomeBetween(Double value1, Double value2) {
            addCriterion("fci_total_income between", value1, value2, "fciTotalIncome");
            return (Criteria) this;
        }

        public Criteria andFciTotalIncomeNotBetween(Double value1, Double value2) {
            addCriterion("fci_total_income not between", value1, value2, "fciTotalIncome");
            return (Criteria) this;
        }

        public Criteria andRemarkIsNull() {
            addCriterion("remark is null");
            return (Criteria) this;
        }

        public Criteria andRemarkIsNotNull() {
            addCriterion("remark is not null");
            return (Criteria) this;
        }

        public Criteria andRemarkEqualTo(String value) {
            addCriterion("remark =", value, "remark");
            return (Criteria) this;
        }

        public Criteria andRemarkNotEqualTo(String value) {
            addCriterion("remark <>", value, "remark");
            return (Criteria) this;
        }

        public Criteria andRemarkGreaterThan(String value) {
            addCriterion("remark >", value, "remark");
            return (Criteria) this;
        }

        public Criteria andRemarkGreaterThanOrEqualTo(String value) {
            addCriterion("remark >=", value, "remark");
            return (Criteria) this;
        }

        public Criteria andRemarkLessThan(String value) {
            addCriterion("remark <", value, "remark");
            return (Criteria) this;
        }

        public Criteria andRemarkLessThanOrEqualTo(String value) {
            addCriterion("remark <=", value, "remark");
            return (Criteria) this;
        }

        public Criteria andRemarkLike(String value) {
            addCriterion("remark like", value, "remark");
            return (Criteria) this;
        }

        public Criteria andRemarkNotLike(String value) {
            addCriterion("remark not like", value, "remark");
            return (Criteria) this;
        }

        public Criteria andRemarkIn(List<String> values) {
            addCriterion("remark in", values, "remark");
            return (Criteria) this;
        }

        public Criteria andRemarkNotIn(List<String> values) {
            addCriterion("remark not in", values, "remark");
            return (Criteria) this;
        }

        public Criteria andRemarkBetween(String value1, String value2) {
            addCriterion("remark between", value1, value2, "remark");
            return (Criteria) this;
        }

        public Criteria andRemarkNotBetween(String value1, String value2) {
            addCriterion("remark not between", value1, value2, "remark");
            return (Criteria) this;
        }

        public Criteria andCreateuserIsNull() {
            addCriterion("createuser is null");
            return (Criteria) this;
        }

        public Criteria andCreateuserIsNotNull() {
            addCriterion("createuser is not null");
            return (Criteria) this;
        }

        public Criteria andCreateuserEqualTo(String value) {
            addCriterion("createuser =", value, "createuser");
            return (Criteria) this;
        }

        public Criteria andCreateuserNotEqualTo(String value) {
            addCriterion("createuser <>", value, "createuser");
            return (Criteria) this;
        }

        public Criteria andCreateuserGreaterThan(String value) {
            addCriterion("createuser >", value, "createuser");
            return (Criteria) this;
        }

        public Criteria andCreateuserGreaterThanOrEqualTo(String value) {
            addCriterion("createuser >=", value, "createuser");
            return (Criteria) this;
        }

        public Criteria andCreateuserLessThan(String value) {
            addCriterion("createuser <", value, "createuser");
            return (Criteria) this;
        }

        public Criteria andCreateuserLessThanOrEqualTo(String value) {
            addCriterion("createuser <=", value, "createuser");
            return (Criteria) this;
        }

        public Criteria andCreateuserLike(String value) {
            addCriterion("createuser like", value, "createuser");
            return (Criteria) this;
        }

        public Criteria andCreateuserNotLike(String value) {
            addCriterion("createuser not like", value, "createuser");
            return (Criteria) this;
        }

        public Criteria andCreateuserIn(List<String> values) {
            addCriterion("createuser in", values, "createuser");
            return (Criteria) this;
        }

        public Criteria andCreateuserNotIn(List<String> values) {
            addCriterion("createuser not in", values, "createuser");
            return (Criteria) this;
        }

        public Criteria andCreateuserBetween(String value1, String value2) {
            addCriterion("createuser between", value1, value2, "createuser");
            return (Criteria) this;
        }

        public Criteria andCreateuserNotBetween(String value1, String value2) {
            addCriterion("createuser not between", value1, value2, "createuser");
            return (Criteria) this;
        }

        public Criteria andCreatetimeIsNull() {
            addCriterion("createtime is null");
            return (Criteria) this;
        }

        public Criteria andCreatetimeIsNotNull() {
            addCriterion("createtime is not null");
            return (Criteria) this;
        }

        public Criteria andCreatetimeEqualTo(Date value) {
            addCriterion("createtime =", value, "createtime");
            return (Criteria) this;
        }

        public Criteria andCreatetimeNotEqualTo(Date value) {
            addCriterion("createtime <>", value, "createtime");
            return (Criteria) this;
        }

        public Criteria andCreatetimeGreaterThan(Date value) {
            addCriterion("createtime >", value, "createtime");
            return (Criteria) this;
        }

        public Criteria andCreatetimeGreaterThanOrEqualTo(Date value) {
            addCriterion("createtime >=", value, "createtime");
            return (Criteria) this;
        }

        public Criteria andCreatetimeLessThan(Date value) {
            addCriterion("createtime <", value, "createtime");
            return (Criteria) this;
        }

        public Criteria andCreatetimeLessThanOrEqualTo(Date value) {
            addCriterion("createtime <=", value, "createtime");
            return (Criteria) this;
        }

        public Criteria andCreatetimeIn(List<Date> values) {
            addCriterion("createtime in", values, "createtime");
            return (Criteria) this;
        }

        public Criteria andCreatetimeNotIn(List<Date> values) {
            addCriterion("createtime not in", values, "createtime");
            return (Criteria) this;
        }

        public Criteria andCreatetimeBetween(Date value1, Date value2) {
            addCriterion("createtime between", value1, value2, "createtime");
            return (Criteria) this;
        }

        public Criteria andCreatetimeNotBetween(Date value1, Date value2) {
            addCriterion("createtime not between", value1, value2, "createtime");
            return (Criteria) this;
        }

        public Criteria andUpdateuserIsNull() {
            addCriterion("updateuser is null");
            return (Criteria) this;
        }

        public Criteria andUpdateuserIsNotNull() {
            addCriterion("updateuser is not null");
            return (Criteria) this;
        }

        public Criteria andUpdateuserEqualTo(String value) {
            addCriterion("updateuser =", value, "updateuser");
            return (Criteria) this;
        }

        public Criteria andUpdateuserNotEqualTo(String value) {
            addCriterion("updateuser <>", value, "updateuser");
            return (Criteria) this;
        }

        public Criteria andUpdateuserGreaterThan(String value) {
            addCriterion("updateuser >", value, "updateuser");
            return (Criteria) this;
        }

        public Criteria andUpdateuserGreaterThanOrEqualTo(String value) {
            addCriterion("updateuser >=", value, "updateuser");
            return (Criteria) this;
        }

        public Criteria andUpdateuserLessThan(String value) {
            addCriterion("updateuser <", value, "updateuser");
            return (Criteria) this;
        }

        public Criteria andUpdateuserLessThanOrEqualTo(String value) {
            addCriterion("updateuser <=", value, "updateuser");
            return (Criteria) this;
        }

        public Criteria andUpdateuserLike(String value) {
            addCriterion("updateuser like", value, "updateuser");
            return (Criteria) this;
        }

        public Criteria andUpdateuserNotLike(String value) {
            addCriterion("updateuser not like", value, "updateuser");
            return (Criteria) this;
        }

        public Criteria andUpdateuserIn(List<String> values) {
            addCriterion("updateuser in", values, "updateuser");
            return (Criteria) this;
        }

        public Criteria andUpdateuserNotIn(List<String> values) {
            addCriterion("updateuser not in", values, "updateuser");
            return (Criteria) this;
        }

        public Criteria andUpdateuserBetween(String value1, String value2) {
            addCriterion("updateuser between", value1, value2, "updateuser");
            return (Criteria) this;
        }

        public Criteria andUpdateuserNotBetween(String value1, String value2) {
            addCriterion("updateuser not between", value1, value2, "updateuser");
            return (Criteria) this;
        }

        public Criteria andUpdatetimeIsNull() {
            addCriterion("updatetime is null");
            return (Criteria) this;
        }

        public Criteria andUpdatetimeIsNotNull() {
            addCriterion("updatetime is not null");
            return (Criteria) this;
        }

        public Criteria andUpdatetimeEqualTo(Date value) {
            addCriterion("updatetime =", value, "updatetime");
            return (Criteria) this;
        }

        public Criteria andUpdatetimeNotEqualTo(Date value) {
            addCriterion("updatetime <>", value, "updatetime");
            return (Criteria) this;
        }

        public Criteria andUpdatetimeGreaterThan(Date value) {
            addCriterion("updatetime >", value, "updatetime");
            return (Criteria) this;
        }

        public Criteria andUpdatetimeGreaterThanOrEqualTo(Date value) {
            addCriterion("updatetime >=", value, "updatetime");
            return (Criteria) this;
        }

        public Criteria andUpdatetimeLessThan(Date value) {
            addCriterion("updatetime <", value, "updatetime");
            return (Criteria) this;
        }

        public Criteria andUpdatetimeLessThanOrEqualTo(Date value) {
            addCriterion("updatetime <=", value, "updatetime");
            return (Criteria) this;
        }

        public Criteria andUpdatetimeIn(List<Date> values) {
            addCriterion("updatetime in", values, "updatetime");
            return (Criteria) this;
        }

        public Criteria andUpdatetimeNotIn(List<Date> values) {
            addCriterion("updatetime not in", values, "updatetime");
            return (Criteria) this;
        }

        public Criteria andUpdatetimeBetween(Date value1, Date value2) {
            addCriterion("updatetime between", value1, value2, "updatetime");
            return (Criteria) this;
        }

        public Criteria andUpdatetimeNotBetween(Date value1, Date value2) {
            addCriterion("updatetime not between", value1, value2, "updatetime");
            return (Criteria) this;
        }

        public Criteria andDrIsNull() {
            addCriterion("dr is null");
            return (Criteria) this;
        }

        public Criteria andDrIsNotNull() {
            addCriterion("dr is not null");
            return (Criteria) this;
        }

        public Criteria andDrEqualTo(Integer value) {
            addCriterion("dr =", value, "dr");
            return (Criteria) this;
        }

        public Criteria andDrNotEqualTo(Integer value) {
            addCriterion("dr <>", value, "dr");
            return (Criteria) this;
        }

        public Criteria andDrGreaterThan(Integer value) {
            addCriterion("dr >", value, "dr");
            return (Criteria) this;
        }

        public Criteria andDrGreaterThanOrEqualTo(Integer value) {
            addCriterion("dr >=", value, "dr");
            return (Criteria) this;
        }

        public Criteria andDrLessThan(Integer value) {
            addCriterion("dr <", value, "dr");
            return (Criteria) this;
        }

        public Criteria andDrLessThanOrEqualTo(Integer value) {
            addCriterion("dr <=", value, "dr");
            return (Criteria) this;
        }

        public Criteria andDrIn(List<Integer> values) {
            addCriterion("dr in", values, "dr");
            return (Criteria) this;
        }

        public Criteria andDrNotIn(List<Integer> values) {
            addCriterion("dr not in", values, "dr");
            return (Criteria) this;
        }

        public Criteria andDrBetween(Integer value1, Integer value2) {
            addCriterion("dr between", value1, value2, "dr");
            return (Criteria) this;
        }

        public Criteria andDrNotBetween(Integer value1, Integer value2) {
            addCriterion("dr not between", value1, value2, "dr");
            return (Criteria) this;
        }
    }

    public static class Criteria extends GeneratedCriteria {

        protected Criteria() {
            super();
        }
    }

    public static class Criterion {
        private String condition;

        private Object value;

        private Object secondValue;

        private boolean noValue;

        private boolean singleValue;

        private boolean betweenValue;

        private boolean listValue;

        private String typeHandler;

        public String getCondition() {
            return condition;
        }

        public Object getValue() {
            return value;
        }

        public Object getSecondValue() {
            return secondValue;
        }

        public boolean isNoValue() {
            return noValue;
        }

        public boolean isSingleValue() {
            return singleValue;
        }

        public boolean isBetweenValue() {
            return betweenValue;
        }

        public boolean isListValue() {
            return listValue;
        }

        public String getTypeHandler() {
            return typeHandler;
        }

        protected Criterion(String condition) {
            super();
            this.condition = condition;
            this.typeHandler = null;
            this.noValue = true;
        }

        protected Criterion(String condition, Object value, String typeHandler) {
            super();
            this.condition = condition;
            this.value = value;
            this.typeHandler = typeHandler;
            if (value instanceof List<?>) {
                this.listValue = true;
            } else {
                this.singleValue = true;
            }
        }

        protected Criterion(String condition, Object value) {
            this(condition, value, null);
        }

        protected Criterion(String condition, Object value, Object secondValue, String typeHandler) {
            super();
            this.condition = condition;
            this.value = value;
            this.secondValue = secondValue;
            this.typeHandler = typeHandler;
            this.betweenValue = true;
        }

        protected Criterion(String condition, Object value, Object secondValue) {
            this(condition, value, secondValue, null);
        }
    }
}
