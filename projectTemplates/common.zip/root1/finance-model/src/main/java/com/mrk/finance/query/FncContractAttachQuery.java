package com.mrk.finance.query;
import com.mrk.common.utils.text.CheckUtil;

/**
 * @author 自动生成工具
 * @date   2022/06/02 
 */
public class FncContractAttachQuery {
	private String updateuserNotLike;
	private java.util.List updateuserNotIn;
	private String updateuserNotEqualTo;
	private String updateuserLike;
	private String updateuserLessThanOrEqualTo;
	private String updateuserLessThan;
	private Boolean updateuserIsNull;
	private Boolean updateuserIsNotNull;
	private java.util.List updateuserIn;
	private String updateuserGreaterThanOrEqualTo;
	private String updateuserGreaterThan;
	private String updateuserEqualTo;
	private java.util.List updatetimeNotIn;
	private java.util.Date updatetimeNotEqualTo;
	private java.util.Date updatetimeLessThanOrEqualTo;
	private java.util.Date updatetimeLessThan;
	private Boolean updatetimeIsNull;
	private Boolean updatetimeIsNotNull;
	private java.util.List updatetimeIn;
	private java.util.Date updatetimeGreaterThanOrEqualTo;
	private java.util.Date updatetimeGreaterThan;
	private java.util.Date updatetimeEqualTo;
	private String remarkNotLike;
	private java.util.List remarkNotIn;
	private String remarkNotEqualTo;
	private String remarkLike;
	private String remarkLessThanOrEqualTo;
	private String remarkLessThan;
	private Boolean remarkIsNull;
	private Boolean remarkIsNotNull;
	private java.util.List remarkIn;
	private String remarkGreaterThanOrEqualTo;
	private String remarkGreaterThan;
	private String remarkEqualTo;
	private String fcaLinkNotLike;
	private java.util.List fcaLinkNotIn;
	private String fcaLinkNotEqualTo;
	private String fcaLinkLike;
	private String fcaLinkLessThanOrEqualTo;
	private String fcaLinkLessThan;
	private Boolean fcaLinkIsNull;
	private Boolean fcaLinkIsNotNull;
	private java.util.List fcaLinkIn;
	private String fcaLinkGreaterThanOrEqualTo;
	private String fcaLinkGreaterThan;
	private String fcaLinkEqualTo;
	private java.util.List fcaIdNotIn;
	private Long fcaIdNotEqualTo;
	private Long fcaIdLessThanOrEqualTo;
	private Long fcaIdLessThan;
	private Boolean fcaIdIsNull;
	private Boolean fcaIdIsNotNull;
	private java.util.List fcaIdIn;
	private Long fcaIdGreaterThanOrEqualTo;
	private Long fcaIdGreaterThan;
	private Long fcaIdEqualTo;
	private String fcaFileTypeNotLike;
	private java.util.List fcaFileTypeNotIn;
	private String fcaFileTypeNotEqualTo;
	private String fcaFileTypeLike;
	private String fcaFileTypeLessThanOrEqualTo;
	private String fcaFileTypeLessThan;
	private Boolean fcaFileTypeIsNull;
	private Boolean fcaFileTypeIsNotNull;
	private java.util.List fcaFileTypeIn;
	private String fcaFileTypeGreaterThanOrEqualTo;
	private String fcaFileTypeGreaterThan;
	private String fcaFileTypeEqualTo;
	private java.util.List fcaContractIdNotIn;
	private Long fcaContractIdNotEqualTo;
	private Long fcaContractIdLessThanOrEqualTo;
	private Long fcaContractIdLessThan;
	private Boolean fcaContractIdIsNull;
	private Boolean fcaContractIdIsNotNull;
	private java.util.List fcaContractIdIn;
	private Long fcaContractIdGreaterThanOrEqualTo;
	private Long fcaContractIdGreaterThan;
	private Long fcaContractIdEqualTo;
	private java.util.List drNotIn;
	private Integer drNotEqualTo;
	private Integer drLessThanOrEqualTo;
	private Integer drLessThan;
	private Boolean drIsNull;
	private Boolean drIsNotNull;
	private java.util.List drIn;
	private Integer drGreaterThanOrEqualTo;
	private Integer drGreaterThan;
	private Integer drEqualTo;
	private String createuserNotLike;
	private java.util.List createuserNotIn;
	private String createuserNotEqualTo;
	private String createuserLike;
	private String createuserLessThanOrEqualTo;
	private String createuserLessThan;
	private Boolean createuserIsNull;
	private Boolean createuserIsNotNull;
	private java.util.List createuserIn;
	private String createuserGreaterThanOrEqualTo;
	private String createuserGreaterThan;
	private String createuserEqualTo;
	private java.util.List createtimeNotIn;
	private java.util.Date createtimeNotEqualTo;
	private java.util.Date createtimeLessThanOrEqualTo;
	private java.util.Date createtimeLessThan;
	private Boolean createtimeIsNull;
	private Boolean createtimeIsNotNull;
	private java.util.List createtimeIn;
	private java.util.Date createtimeGreaterThanOrEqualTo;
	private java.util.Date createtimeGreaterThan;
	private java.util.Date createtimeEqualTo;
	private String sidx;
	private String sord;
	public String getSidx(){
		if(this.sidx == null){
			return "";
		}
		else if("updateuser".equals(this.sidx)){
			return "updateuser";
		}
		else if("updatetime".equals(this.sidx)){
			return "updatetime";
		}
		else if("remark".equals(this.sidx)){
			return "remark";
		}
		else if("fcaLink".equals(this.sidx)){
			return "fca_link";
		}
		else if("fcaId".equals(this.sidx)){
			return "fca_id";
		}
		else if("fcaFileType".equals(this.sidx)){
			return "fca_file_type";
		}
		else if("fcaContractId".equals(this.sidx)){
			return "fca_contract_id";
		}
		else if("dr".equals(this.sidx)){
			return "dr";
		}
		else if("createuser".equals(this.sidx)){
			return "createuser";
		}
		else if("createtime".equals(this.sidx)){
			return "createtime";
		}
		return this.sidx;
	}

	@com.fasterxml.jackson.annotation.JsonIgnore
	public com.mrk.finance.example.FncContractAttachExample getCrieria(){
		com.mrk.finance.example.FncContractAttachExample q = new com.mrk.finance.example.FncContractAttachExample();
		com.mrk.finance.example.FncContractAttachExample.Criteria c = q.createCriteria();
		c.andDrEqualTo(0);
		if(CheckUtil.isNotEmpty(getUpdateuserNotLike())){
			c.andUpdateuserNotLike("%"+this.getUpdateuserNotLike()+"%");
		}
		if(CheckUtil.isNotEmpty(getUpdateuserNotIn())){
			c.andUpdateuserNotIn(this.getUpdateuserNotIn());
		}
		if(CheckUtil.isNotEmpty(getUpdateuserNotEqualTo())){
			c.andUpdateuserNotEqualTo(this.getUpdateuserNotEqualTo());
		}
		if(CheckUtil.isNotEmpty(getUpdateuserLike())){
			c.andUpdateuserLike("%"+this.getUpdateuserLike()+"%");
		}
		if(CheckUtil.isNotEmpty(getUpdateuserLessThanOrEqualTo())){
			c.andUpdateuserLessThanOrEqualTo(this.getUpdateuserLessThanOrEqualTo());
		}
		if(CheckUtil.isNotEmpty(getUpdateuserLessThan())){
			c.andUpdateuserLessThan(this.getUpdateuserLessThan());
		}
		if(CheckUtil.isNotEmpty(getUpdateuserIsNull()) && this.getUpdateuserIsNull()){
			c.andUpdateuserIsNull();
		}
		if(CheckUtil.isNotEmpty(getUpdateuserIsNotNull()) && this.getUpdateuserIsNotNull()){
			c.andUpdateuserIsNotNull();
		}
		if(CheckUtil.isNotEmpty(getUpdateuserIn())){
			c.andUpdateuserIn(this.getUpdateuserIn());
		}
		if(CheckUtil.isNotEmpty(getUpdateuserGreaterThanOrEqualTo())){
			c.andUpdateuserGreaterThanOrEqualTo(this.getUpdateuserGreaterThanOrEqualTo());
		}
		if(CheckUtil.isNotEmpty(getUpdateuserGreaterThan())){
			c.andUpdateuserGreaterThan(this.getUpdateuserGreaterThan());
		}
		if(CheckUtil.isNotEmpty(getUpdateuserEqualTo())){
			c.andUpdateuserEqualTo(this.getUpdateuserEqualTo());
		}
		if(CheckUtil.isNotEmpty(getUpdatetimeNotIn())){
			c.andUpdatetimeNotIn(this.getUpdatetimeNotIn());
		}
		if(CheckUtil.isNotEmpty(getUpdatetimeNotEqualTo())){
			c.andUpdatetimeNotEqualTo(this.getUpdatetimeNotEqualTo());
		}
		if(CheckUtil.isNotEmpty(getUpdatetimeLessThanOrEqualTo())){
			c.andUpdatetimeLessThanOrEqualTo(this.getUpdatetimeLessThanOrEqualTo());
		}
		if(CheckUtil.isNotEmpty(getUpdatetimeLessThan())){
			c.andUpdatetimeLessThan(this.getUpdatetimeLessThan());
		}
		if(CheckUtil.isNotEmpty(getUpdatetimeIsNull()) && this.getUpdatetimeIsNull()){
			c.andUpdatetimeIsNull();
		}
		if(CheckUtil.isNotEmpty(getUpdatetimeIsNotNull()) && this.getUpdatetimeIsNotNull()){
			c.andUpdatetimeIsNotNull();
		}
		if(CheckUtil.isNotEmpty(getUpdatetimeIn())){
			c.andUpdatetimeIn(this.getUpdatetimeIn());
		}
		if(CheckUtil.isNotEmpty(getUpdatetimeGreaterThanOrEqualTo())){
			c.andUpdatetimeGreaterThanOrEqualTo(this.getUpdatetimeGreaterThanOrEqualTo());
		}
		if(CheckUtil.isNotEmpty(getUpdatetimeGreaterThan())){
			c.andUpdatetimeGreaterThan(this.getUpdatetimeGreaterThan());
		}
		if(CheckUtil.isNotEmpty(getUpdatetimeEqualTo())){
			c.andUpdatetimeEqualTo(this.getUpdatetimeEqualTo());
		}
		if(CheckUtil.isNotEmpty(getRemarkNotLike())){
			c.andRemarkNotLike("%"+this.getRemarkNotLike()+"%");
		}
		if(CheckUtil.isNotEmpty(getRemarkNotIn())){
			c.andRemarkNotIn(this.getRemarkNotIn());
		}
		if(CheckUtil.isNotEmpty(getRemarkNotEqualTo())){
			c.andRemarkNotEqualTo(this.getRemarkNotEqualTo());
		}
		if(CheckUtil.isNotEmpty(getRemarkLike())){
			c.andRemarkLike("%"+this.getRemarkLike()+"%");
		}
		if(CheckUtil.isNotEmpty(getRemarkLessThanOrEqualTo())){
			c.andRemarkLessThanOrEqualTo(this.getRemarkLessThanOrEqualTo());
		}
		if(CheckUtil.isNotEmpty(getRemarkLessThan())){
			c.andRemarkLessThan(this.getRemarkLessThan());
		}
		if(CheckUtil.isNotEmpty(getRemarkIsNull()) && this.getRemarkIsNull()){
			c.andRemarkIsNull();
		}
		if(CheckUtil.isNotEmpty(getRemarkIsNotNull()) && this.getRemarkIsNotNull()){
			c.andRemarkIsNotNull();
		}
		if(CheckUtil.isNotEmpty(getRemarkIn())){
			c.andRemarkIn(this.getRemarkIn());
		}
		if(CheckUtil.isNotEmpty(getRemarkGreaterThanOrEqualTo())){
			c.andRemarkGreaterThanOrEqualTo(this.getRemarkGreaterThanOrEqualTo());
		}
		if(CheckUtil.isNotEmpty(getRemarkGreaterThan())){
			c.andRemarkGreaterThan(this.getRemarkGreaterThan());
		}
		if(CheckUtil.isNotEmpty(getRemarkEqualTo())){
			c.andRemarkEqualTo(this.getRemarkEqualTo());
		}
		if(CheckUtil.isNotEmpty(getFcaLinkNotLike())){
			c.andFcaLinkNotLike("%"+this.getFcaLinkNotLike()+"%");
		}
		if(CheckUtil.isNotEmpty(getFcaLinkNotIn())){
			c.andFcaLinkNotIn(this.getFcaLinkNotIn());
		}
		if(CheckUtil.isNotEmpty(getFcaLinkNotEqualTo())){
			c.andFcaLinkNotEqualTo(this.getFcaLinkNotEqualTo());
		}
		if(CheckUtil.isNotEmpty(getFcaLinkLike())){
			c.andFcaLinkLike("%"+this.getFcaLinkLike()+"%");
		}
		if(CheckUtil.isNotEmpty(getFcaLinkLessThanOrEqualTo())){
			c.andFcaLinkLessThanOrEqualTo(this.getFcaLinkLessThanOrEqualTo());
		}
		if(CheckUtil.isNotEmpty(getFcaLinkLessThan())){
			c.andFcaLinkLessThan(this.getFcaLinkLessThan());
		}
		if(CheckUtil.isNotEmpty(getFcaLinkIsNull()) && this.getFcaLinkIsNull()){
			c.andFcaLinkIsNull();
		}
		if(CheckUtil.isNotEmpty(getFcaLinkIsNotNull()) && this.getFcaLinkIsNotNull()){
			c.andFcaLinkIsNotNull();
		}
		if(CheckUtil.isNotEmpty(getFcaLinkIn())){
			c.andFcaLinkIn(this.getFcaLinkIn());
		}
		if(CheckUtil.isNotEmpty(getFcaLinkGreaterThanOrEqualTo())){
			c.andFcaLinkGreaterThanOrEqualTo(this.getFcaLinkGreaterThanOrEqualTo());
		}
		if(CheckUtil.isNotEmpty(getFcaLinkGreaterThan())){
			c.andFcaLinkGreaterThan(this.getFcaLinkGreaterThan());
		}
		if(CheckUtil.isNotEmpty(getFcaLinkEqualTo())){
			c.andFcaLinkEqualTo(this.getFcaLinkEqualTo());
		}
		if(CheckUtil.isNotEmpty(getFcaIdNotIn())){
			c.andFcaIdNotIn(this.getFcaIdNotIn());
		}
		if(CheckUtil.isNotEmpty(getFcaIdNotEqualTo())){
			c.andFcaIdNotEqualTo(this.getFcaIdNotEqualTo());
		}
		if(CheckUtil.isNotEmpty(getFcaIdLessThanOrEqualTo())){
			c.andFcaIdLessThanOrEqualTo(this.getFcaIdLessThanOrEqualTo());
		}
		if(CheckUtil.isNotEmpty(getFcaIdLessThan())){
			c.andFcaIdLessThan(this.getFcaIdLessThan());
		}
		if(CheckUtil.isNotEmpty(getFcaIdIsNull()) && this.getFcaIdIsNull()){
			c.andFcaIdIsNull();
		}
		if(CheckUtil.isNotEmpty(getFcaIdIsNotNull()) && this.getFcaIdIsNotNull()){
			c.andFcaIdIsNotNull();
		}
		if(CheckUtil.isNotEmpty(getFcaIdIn())){
			c.andFcaIdIn(this.getFcaIdIn());
		}
		if(CheckUtil.isNotEmpty(getFcaIdGreaterThanOrEqualTo())){
			c.andFcaIdGreaterThanOrEqualTo(this.getFcaIdGreaterThanOrEqualTo());
		}
		if(CheckUtil.isNotEmpty(getFcaIdGreaterThan())){
			c.andFcaIdGreaterThan(this.getFcaIdGreaterThan());
		}
		if(CheckUtil.isNotEmpty(getFcaIdEqualTo())){
			c.andFcaIdEqualTo(this.getFcaIdEqualTo());
		}
		if(CheckUtil.isNotEmpty(getFcaFileTypeNotLike())){
			c.andFcaFileTypeNotLike("%"+this.getFcaFileTypeNotLike()+"%");
		}
		if(CheckUtil.isNotEmpty(getFcaFileTypeNotIn())){
			c.andFcaFileTypeNotIn(this.getFcaFileTypeNotIn());
		}
		if(CheckUtil.isNotEmpty(getFcaFileTypeNotEqualTo())){
			c.andFcaFileTypeNotEqualTo(this.getFcaFileTypeNotEqualTo());
		}
		if(CheckUtil.isNotEmpty(getFcaFileTypeLike())){
			c.andFcaFileTypeLike("%"+this.getFcaFileTypeLike()+"%");
		}
		if(CheckUtil.isNotEmpty(getFcaFileTypeLessThanOrEqualTo())){
			c.andFcaFileTypeLessThanOrEqualTo(this.getFcaFileTypeLessThanOrEqualTo());
		}
		if(CheckUtil.isNotEmpty(getFcaFileTypeLessThan())){
			c.andFcaFileTypeLessThan(this.getFcaFileTypeLessThan());
		}
		if(CheckUtil.isNotEmpty(getFcaFileTypeIsNull()) && this.getFcaFileTypeIsNull()){
			c.andFcaFileTypeIsNull();
		}
		if(CheckUtil.isNotEmpty(getFcaFileTypeIsNotNull()) && this.getFcaFileTypeIsNotNull()){
			c.andFcaFileTypeIsNotNull();
		}
		if(CheckUtil.isNotEmpty(getFcaFileTypeIn())){
			c.andFcaFileTypeIn(this.getFcaFileTypeIn());
		}
		if(CheckUtil.isNotEmpty(getFcaFileTypeGreaterThanOrEqualTo())){
			c.andFcaFileTypeGreaterThanOrEqualTo(this.getFcaFileTypeGreaterThanOrEqualTo());
		}
		if(CheckUtil.isNotEmpty(getFcaFileTypeGreaterThan())){
			c.andFcaFileTypeGreaterThan(this.getFcaFileTypeGreaterThan());
		}
		if(CheckUtil.isNotEmpty(getFcaFileTypeEqualTo())){
			c.andFcaFileTypeEqualTo(this.getFcaFileTypeEqualTo());
		}
		if(CheckUtil.isNotEmpty(getFcaContractIdNotIn())){
			c.andFcaContractIdNotIn(this.getFcaContractIdNotIn());
		}
		if(CheckUtil.isNotEmpty(getFcaContractIdNotEqualTo())){
			c.andFcaContractIdNotEqualTo(this.getFcaContractIdNotEqualTo());
		}
		if(CheckUtil.isNotEmpty(getFcaContractIdLessThanOrEqualTo())){
			c.andFcaContractIdLessThanOrEqualTo(this.getFcaContractIdLessThanOrEqualTo());
		}
		if(CheckUtil.isNotEmpty(getFcaContractIdLessThan())){
			c.andFcaContractIdLessThan(this.getFcaContractIdLessThan());
		}
		if(CheckUtil.isNotEmpty(getFcaContractIdIsNull()) && this.getFcaContractIdIsNull()){
			c.andFcaContractIdIsNull();
		}
		if(CheckUtil.isNotEmpty(getFcaContractIdIsNotNull()) && this.getFcaContractIdIsNotNull()){
			c.andFcaContractIdIsNotNull();
		}
		if(CheckUtil.isNotEmpty(getFcaContractIdIn())){
			c.andFcaContractIdIn(this.getFcaContractIdIn());
		}
		if(CheckUtil.isNotEmpty(getFcaContractIdGreaterThanOrEqualTo())){
			c.andFcaContractIdGreaterThanOrEqualTo(this.getFcaContractIdGreaterThanOrEqualTo());
		}
		if(CheckUtil.isNotEmpty(getFcaContractIdGreaterThan())){
			c.andFcaContractIdGreaterThan(this.getFcaContractIdGreaterThan());
		}
		if(CheckUtil.isNotEmpty(getFcaContractIdEqualTo())){
			c.andFcaContractIdEqualTo(this.getFcaContractIdEqualTo());
		}
		if(CheckUtil.isNotEmpty(getDrNotIn())){
			c.andDrNotIn(this.getDrNotIn());
		}
		if(CheckUtil.isNotEmpty(getDrNotEqualTo())){
			c.andDrNotEqualTo(this.getDrNotEqualTo());
		}
		if(CheckUtil.isNotEmpty(getDrLessThanOrEqualTo())){
			c.andDrLessThanOrEqualTo(this.getDrLessThanOrEqualTo());
		}
		if(CheckUtil.isNotEmpty(getDrLessThan())){
			c.andDrLessThan(this.getDrLessThan());
		}
		if(CheckUtil.isNotEmpty(getDrIsNull()) && this.getDrIsNull()){
			c.andDrIsNull();
		}
		if(CheckUtil.isNotEmpty(getDrIsNotNull()) && this.getDrIsNotNull()){
			c.andDrIsNotNull();
		}
		if(CheckUtil.isNotEmpty(getDrIn())){
			c.andDrIn(this.getDrIn());
		}
		if(CheckUtil.isNotEmpty(getDrGreaterThanOrEqualTo())){
			c.andDrGreaterThanOrEqualTo(this.getDrGreaterThanOrEqualTo());
		}
		if(CheckUtil.isNotEmpty(getDrGreaterThan())){
			c.andDrGreaterThan(this.getDrGreaterThan());
		}
		if(CheckUtil.isNotEmpty(getDrEqualTo())){
			c.andDrEqualTo(this.getDrEqualTo());
		}
		if(CheckUtil.isNotEmpty(getCreateuserNotLike())){
			c.andCreateuserNotLike("%"+this.getCreateuserNotLike()+"%");
		}
		if(CheckUtil.isNotEmpty(getCreateuserNotIn())){
			c.andCreateuserNotIn(this.getCreateuserNotIn());
		}
		if(CheckUtil.isNotEmpty(getCreateuserNotEqualTo())){
			c.andCreateuserNotEqualTo(this.getCreateuserNotEqualTo());
		}
		if(CheckUtil.isNotEmpty(getCreateuserLike())){
			c.andCreateuserLike("%"+this.getCreateuserLike()+"%");
		}
		if(CheckUtil.isNotEmpty(getCreateuserLessThanOrEqualTo())){
			c.andCreateuserLessThanOrEqualTo(this.getCreateuserLessThanOrEqualTo());
		}
		if(CheckUtil.isNotEmpty(getCreateuserLessThan())){
			c.andCreateuserLessThan(this.getCreateuserLessThan());
		}
		if(CheckUtil.isNotEmpty(getCreateuserIsNull()) && this.getCreateuserIsNull()){
			c.andCreateuserIsNull();
		}
		if(CheckUtil.isNotEmpty(getCreateuserIsNotNull()) && this.getCreateuserIsNotNull()){
			c.andCreateuserIsNotNull();
		}
		if(CheckUtil.isNotEmpty(getCreateuserIn())){
			c.andCreateuserIn(this.getCreateuserIn());
		}
		if(CheckUtil.isNotEmpty(getCreateuserGreaterThanOrEqualTo())){
			c.andCreateuserGreaterThanOrEqualTo(this.getCreateuserGreaterThanOrEqualTo());
		}
		if(CheckUtil.isNotEmpty(getCreateuserGreaterThan())){
			c.andCreateuserGreaterThan(this.getCreateuserGreaterThan());
		}
		if(CheckUtil.isNotEmpty(getCreateuserEqualTo())){
			c.andCreateuserEqualTo(this.getCreateuserEqualTo());
		}
		if(CheckUtil.isNotEmpty(getCreatetimeNotIn())){
			c.andCreatetimeNotIn(this.getCreatetimeNotIn());
		}
		if(CheckUtil.isNotEmpty(getCreatetimeNotEqualTo())){
			c.andCreatetimeNotEqualTo(this.getCreatetimeNotEqualTo());
		}
		if(CheckUtil.isNotEmpty(getCreatetimeLessThanOrEqualTo())){
			c.andCreatetimeLessThanOrEqualTo(this.getCreatetimeLessThanOrEqualTo());
		}
		if(CheckUtil.isNotEmpty(getCreatetimeLessThan())){
			c.andCreatetimeLessThan(this.getCreatetimeLessThan());
		}
		if(CheckUtil.isNotEmpty(getCreatetimeIsNull()) && this.getCreatetimeIsNull()){
			c.andCreatetimeIsNull();
		}
		if(CheckUtil.isNotEmpty(getCreatetimeIsNotNull()) && this.getCreatetimeIsNotNull()){
			c.andCreatetimeIsNotNull();
		}
		if(CheckUtil.isNotEmpty(getCreatetimeIn())){
			c.andCreatetimeIn(this.getCreatetimeIn());
		}
		if(CheckUtil.isNotEmpty(getCreatetimeGreaterThanOrEqualTo())){
			c.andCreatetimeGreaterThanOrEqualTo(this.getCreatetimeGreaterThanOrEqualTo());
		}
		if(CheckUtil.isNotEmpty(getCreatetimeGreaterThan())){
			c.andCreatetimeGreaterThan(this.getCreatetimeGreaterThan());
		}
		if(CheckUtil.isNotEmpty(getCreatetimeEqualTo())){
			c.andCreatetimeEqualTo(this.getCreatetimeEqualTo());
		}
		if((this.getSidx()!=null && !this.getSidx().trim().equals("")) && this.getSord()!=null) {
			q.setOrderByClause(""+ this.getSidx()+" "+this.getSord());
		}
		return q;
	}
	public String getUpdateuserNotLike() {
		return updateuserNotLike;
	}
	public void setUpdateuserNotLike(String updateuserNotLike) {
		this.updateuserNotLike = updateuserNotLike;
	}

	public java.util.List getUpdateuserNotIn() {
		return updateuserNotIn;
	}
	public void setUpdateuserNotIn(java.util.List updateuserNotIn) {
		this.updateuserNotIn = updateuserNotIn;
	}

	public String getUpdateuserNotEqualTo() {
		return updateuserNotEqualTo;
	}
	public void setUpdateuserNotEqualTo(String updateuserNotEqualTo) {
		this.updateuserNotEqualTo = updateuserNotEqualTo;
	}

	public String getUpdateuserLike() {
		return updateuserLike;
	}
	public void setUpdateuserLike(String updateuserLike) {
		this.updateuserLike = updateuserLike;
	}

	public String getUpdateuserLessThanOrEqualTo() {
		return updateuserLessThanOrEqualTo;
	}
	public void setUpdateuserLessThanOrEqualTo(String updateuserLessThanOrEqualTo) {
		this.updateuserLessThanOrEqualTo = updateuserLessThanOrEqualTo;
	}

	public String getUpdateuserLessThan() {
		return updateuserLessThan;
	}
	public void setUpdateuserLessThan(String updateuserLessThan) {
		this.updateuserLessThan = updateuserLessThan;
	}

	public Boolean getUpdateuserIsNull() {
		return updateuserIsNull;
	}
	public void setUpdateuserIsNull(Boolean updateuserIsNull) {
		this.updateuserIsNull = updateuserIsNull;
	}

	public Boolean getUpdateuserIsNotNull() {
		return updateuserIsNotNull;
	}
	public void setUpdateuserIsNotNull(Boolean updateuserIsNotNull) {
		this.updateuserIsNotNull = updateuserIsNotNull;
	}

	public java.util.List getUpdateuserIn() {
		return updateuserIn;
	}
	public void setUpdateuserIn(java.util.List updateuserIn) {
		this.updateuserIn = updateuserIn;
	}

	public String getUpdateuserGreaterThanOrEqualTo() {
		return updateuserGreaterThanOrEqualTo;
	}
	public void setUpdateuserGreaterThanOrEqualTo(String updateuserGreaterThanOrEqualTo) {
		this.updateuserGreaterThanOrEqualTo = updateuserGreaterThanOrEqualTo;
	}

	public String getUpdateuserGreaterThan() {
		return updateuserGreaterThan;
	}
	public void setUpdateuserGreaterThan(String updateuserGreaterThan) {
		this.updateuserGreaterThan = updateuserGreaterThan;
	}

	public String getUpdateuserEqualTo() {
		return updateuserEqualTo;
	}
	public void setUpdateuserEqualTo(String updateuserEqualTo) {
		this.updateuserEqualTo = updateuserEqualTo;
	}

	public java.util.List getUpdatetimeNotIn() {
		return updatetimeNotIn;
	}
	public void setUpdatetimeNotIn(java.util.List updatetimeNotIn) {
		this.updatetimeNotIn = updatetimeNotIn;
	}

	public java.util.Date getUpdatetimeNotEqualTo() {
		return updatetimeNotEqualTo;
	}
	public void setUpdatetimeNotEqualTo(java.util.Date updatetimeNotEqualTo) {
		this.updatetimeNotEqualTo = updatetimeNotEqualTo;
	}

	public java.util.Date getUpdatetimeLessThanOrEqualTo() {
		return updatetimeLessThanOrEqualTo;
	}
	public void setUpdatetimeLessThanOrEqualTo(java.util.Date updatetimeLessThanOrEqualTo) {
		this.updatetimeLessThanOrEqualTo = updatetimeLessThanOrEqualTo;
	}

	public java.util.Date getUpdatetimeLessThan() {
		return updatetimeLessThan;
	}
	public void setUpdatetimeLessThan(java.util.Date updatetimeLessThan) {
		this.updatetimeLessThan = updatetimeLessThan;
	}

	public Boolean getUpdatetimeIsNull() {
		return updatetimeIsNull;
	}
	public void setUpdatetimeIsNull(Boolean updatetimeIsNull) {
		this.updatetimeIsNull = updatetimeIsNull;
	}

	public Boolean getUpdatetimeIsNotNull() {
		return updatetimeIsNotNull;
	}
	public void setUpdatetimeIsNotNull(Boolean updatetimeIsNotNull) {
		this.updatetimeIsNotNull = updatetimeIsNotNull;
	}

	public java.util.List getUpdatetimeIn() {
		return updatetimeIn;
	}
	public void setUpdatetimeIn(java.util.List updatetimeIn) {
		this.updatetimeIn = updatetimeIn;
	}

	public java.util.Date getUpdatetimeGreaterThanOrEqualTo() {
		return updatetimeGreaterThanOrEqualTo;
	}
	public void setUpdatetimeGreaterThanOrEqualTo(java.util.Date updatetimeGreaterThanOrEqualTo) {
		this.updatetimeGreaterThanOrEqualTo = updatetimeGreaterThanOrEqualTo;
	}

	public java.util.Date getUpdatetimeGreaterThan() {
		return updatetimeGreaterThan;
	}
	public void setUpdatetimeGreaterThan(java.util.Date updatetimeGreaterThan) {
		this.updatetimeGreaterThan = updatetimeGreaterThan;
	}

	public java.util.Date getUpdatetimeEqualTo() {
		return updatetimeEqualTo;
	}
	public void setUpdatetimeEqualTo(java.util.Date updatetimeEqualTo) {
		this.updatetimeEqualTo = updatetimeEqualTo;
	}

	public String getRemarkNotLike() {
		return remarkNotLike;
	}
	public void setRemarkNotLike(String remarkNotLike) {
		this.remarkNotLike = remarkNotLike;
	}

	public java.util.List getRemarkNotIn() {
		return remarkNotIn;
	}
	public void setRemarkNotIn(java.util.List remarkNotIn) {
		this.remarkNotIn = remarkNotIn;
	}

	public String getRemarkNotEqualTo() {
		return remarkNotEqualTo;
	}
	public void setRemarkNotEqualTo(String remarkNotEqualTo) {
		this.remarkNotEqualTo = remarkNotEqualTo;
	}

	public String getRemarkLike() {
		return remarkLike;
	}
	public void setRemarkLike(String remarkLike) {
		this.remarkLike = remarkLike;
	}

	public String getRemarkLessThanOrEqualTo() {
		return remarkLessThanOrEqualTo;
	}
	public void setRemarkLessThanOrEqualTo(String remarkLessThanOrEqualTo) {
		this.remarkLessThanOrEqualTo = remarkLessThanOrEqualTo;
	}

	public String getRemarkLessThan() {
		return remarkLessThan;
	}
	public void setRemarkLessThan(String remarkLessThan) {
		this.remarkLessThan = remarkLessThan;
	}

	public Boolean getRemarkIsNull() {
		return remarkIsNull;
	}
	public void setRemarkIsNull(Boolean remarkIsNull) {
		this.remarkIsNull = remarkIsNull;
	}

	public Boolean getRemarkIsNotNull() {
		return remarkIsNotNull;
	}
	public void setRemarkIsNotNull(Boolean remarkIsNotNull) {
		this.remarkIsNotNull = remarkIsNotNull;
	}

	public java.util.List getRemarkIn() {
		return remarkIn;
	}
	public void setRemarkIn(java.util.List remarkIn) {
		this.remarkIn = remarkIn;
	}

	public String getRemarkGreaterThanOrEqualTo() {
		return remarkGreaterThanOrEqualTo;
	}
	public void setRemarkGreaterThanOrEqualTo(String remarkGreaterThanOrEqualTo) {
		this.remarkGreaterThanOrEqualTo = remarkGreaterThanOrEqualTo;
	}

	public String getRemarkGreaterThan() {
		return remarkGreaterThan;
	}
	public void setRemarkGreaterThan(String remarkGreaterThan) {
		this.remarkGreaterThan = remarkGreaterThan;
	}

	public String getRemarkEqualTo() {
		return remarkEqualTo;
	}
	public void setRemarkEqualTo(String remarkEqualTo) {
		this.remarkEqualTo = remarkEqualTo;
	}

	public String getFcaLinkNotLike() {
		return fcaLinkNotLike;
	}
	public void setFcaLinkNotLike(String fcaLinkNotLike) {
		this.fcaLinkNotLike = fcaLinkNotLike;
	}

	public java.util.List getFcaLinkNotIn() {
		return fcaLinkNotIn;
	}
	public void setFcaLinkNotIn(java.util.List fcaLinkNotIn) {
		this.fcaLinkNotIn = fcaLinkNotIn;
	}

	public String getFcaLinkNotEqualTo() {
		return fcaLinkNotEqualTo;
	}
	public void setFcaLinkNotEqualTo(String fcaLinkNotEqualTo) {
		this.fcaLinkNotEqualTo = fcaLinkNotEqualTo;
	}

	public String getFcaLinkLike() {
		return fcaLinkLike;
	}
	public void setFcaLinkLike(String fcaLinkLike) {
		this.fcaLinkLike = fcaLinkLike;
	}

	public String getFcaLinkLessThanOrEqualTo() {
		return fcaLinkLessThanOrEqualTo;
	}
	public void setFcaLinkLessThanOrEqualTo(String fcaLinkLessThanOrEqualTo) {
		this.fcaLinkLessThanOrEqualTo = fcaLinkLessThanOrEqualTo;
	}

	public String getFcaLinkLessThan() {
		return fcaLinkLessThan;
	}
	public void setFcaLinkLessThan(String fcaLinkLessThan) {
		this.fcaLinkLessThan = fcaLinkLessThan;
	}

	public Boolean getFcaLinkIsNull() {
		return fcaLinkIsNull;
	}
	public void setFcaLinkIsNull(Boolean fcaLinkIsNull) {
		this.fcaLinkIsNull = fcaLinkIsNull;
	}

	public Boolean getFcaLinkIsNotNull() {
		return fcaLinkIsNotNull;
	}
	public void setFcaLinkIsNotNull(Boolean fcaLinkIsNotNull) {
		this.fcaLinkIsNotNull = fcaLinkIsNotNull;
	}

	public java.util.List getFcaLinkIn() {
		return fcaLinkIn;
	}
	public void setFcaLinkIn(java.util.List fcaLinkIn) {
		this.fcaLinkIn = fcaLinkIn;
	}

	public String getFcaLinkGreaterThanOrEqualTo() {
		return fcaLinkGreaterThanOrEqualTo;
	}
	public void setFcaLinkGreaterThanOrEqualTo(String fcaLinkGreaterThanOrEqualTo) {
		this.fcaLinkGreaterThanOrEqualTo = fcaLinkGreaterThanOrEqualTo;
	}

	public String getFcaLinkGreaterThan() {
		return fcaLinkGreaterThan;
	}
	public void setFcaLinkGreaterThan(String fcaLinkGreaterThan) {
		this.fcaLinkGreaterThan = fcaLinkGreaterThan;
	}

	public String getFcaLinkEqualTo() {
		return fcaLinkEqualTo;
	}
	public void setFcaLinkEqualTo(String fcaLinkEqualTo) {
		this.fcaLinkEqualTo = fcaLinkEqualTo;
	}

	public java.util.List getFcaIdNotIn() {
		return fcaIdNotIn;
	}
	public void setFcaIdNotIn(java.util.List fcaIdNotIn) {
		this.fcaIdNotIn = fcaIdNotIn;
	}

	public Long getFcaIdNotEqualTo() {
		return fcaIdNotEqualTo;
	}
	public void setFcaIdNotEqualTo(Long fcaIdNotEqualTo) {
		this.fcaIdNotEqualTo = fcaIdNotEqualTo;
	}

	public Long getFcaIdLessThanOrEqualTo() {
		return fcaIdLessThanOrEqualTo;
	}
	public void setFcaIdLessThanOrEqualTo(Long fcaIdLessThanOrEqualTo) {
		this.fcaIdLessThanOrEqualTo = fcaIdLessThanOrEqualTo;
	}

	public Long getFcaIdLessThan() {
		return fcaIdLessThan;
	}
	public void setFcaIdLessThan(Long fcaIdLessThan) {
		this.fcaIdLessThan = fcaIdLessThan;
	}

	public Boolean getFcaIdIsNull() {
		return fcaIdIsNull;
	}
	public void setFcaIdIsNull(Boolean fcaIdIsNull) {
		this.fcaIdIsNull = fcaIdIsNull;
	}

	public Boolean getFcaIdIsNotNull() {
		return fcaIdIsNotNull;
	}
	public void setFcaIdIsNotNull(Boolean fcaIdIsNotNull) {
		this.fcaIdIsNotNull = fcaIdIsNotNull;
	}

	public java.util.List getFcaIdIn() {
		return fcaIdIn;
	}
	public void setFcaIdIn(java.util.List fcaIdIn) {
		this.fcaIdIn = fcaIdIn;
	}

	public Long getFcaIdGreaterThanOrEqualTo() {
		return fcaIdGreaterThanOrEqualTo;
	}
	public void setFcaIdGreaterThanOrEqualTo(Long fcaIdGreaterThanOrEqualTo) {
		this.fcaIdGreaterThanOrEqualTo = fcaIdGreaterThanOrEqualTo;
	}

	public Long getFcaIdGreaterThan() {
		return fcaIdGreaterThan;
	}
	public void setFcaIdGreaterThan(Long fcaIdGreaterThan) {
		this.fcaIdGreaterThan = fcaIdGreaterThan;
	}

	public Long getFcaIdEqualTo() {
		return fcaIdEqualTo;
	}
	public void setFcaIdEqualTo(Long fcaIdEqualTo) {
		this.fcaIdEqualTo = fcaIdEqualTo;
	}

	public String getFcaFileTypeNotLike() {
		return fcaFileTypeNotLike;
	}
	public void setFcaFileTypeNotLike(String fcaFileTypeNotLike) {
		this.fcaFileTypeNotLike = fcaFileTypeNotLike;
	}

	public java.util.List getFcaFileTypeNotIn() {
		return fcaFileTypeNotIn;
	}
	public void setFcaFileTypeNotIn(java.util.List fcaFileTypeNotIn) {
		this.fcaFileTypeNotIn = fcaFileTypeNotIn;
	}

	public String getFcaFileTypeNotEqualTo() {
		return fcaFileTypeNotEqualTo;
	}
	public void setFcaFileTypeNotEqualTo(String fcaFileTypeNotEqualTo) {
		this.fcaFileTypeNotEqualTo = fcaFileTypeNotEqualTo;
	}

	public String getFcaFileTypeLike() {
		return fcaFileTypeLike;
	}
	public void setFcaFileTypeLike(String fcaFileTypeLike) {
		this.fcaFileTypeLike = fcaFileTypeLike;
	}

	public String getFcaFileTypeLessThanOrEqualTo() {
		return fcaFileTypeLessThanOrEqualTo;
	}
	public void setFcaFileTypeLessThanOrEqualTo(String fcaFileTypeLessThanOrEqualTo) {
		this.fcaFileTypeLessThanOrEqualTo = fcaFileTypeLessThanOrEqualTo;
	}

	public String getFcaFileTypeLessThan() {
		return fcaFileTypeLessThan;
	}
	public void setFcaFileTypeLessThan(String fcaFileTypeLessThan) {
		this.fcaFileTypeLessThan = fcaFileTypeLessThan;
	}

	public Boolean getFcaFileTypeIsNull() {
		return fcaFileTypeIsNull;
	}
	public void setFcaFileTypeIsNull(Boolean fcaFileTypeIsNull) {
		this.fcaFileTypeIsNull = fcaFileTypeIsNull;
	}

	public Boolean getFcaFileTypeIsNotNull() {
		return fcaFileTypeIsNotNull;
	}
	public void setFcaFileTypeIsNotNull(Boolean fcaFileTypeIsNotNull) {
		this.fcaFileTypeIsNotNull = fcaFileTypeIsNotNull;
	}

	public java.util.List getFcaFileTypeIn() {
		return fcaFileTypeIn;
	}
	public void setFcaFileTypeIn(java.util.List fcaFileTypeIn) {
		this.fcaFileTypeIn = fcaFileTypeIn;
	}

	public String getFcaFileTypeGreaterThanOrEqualTo() {
		return fcaFileTypeGreaterThanOrEqualTo;
	}
	public void setFcaFileTypeGreaterThanOrEqualTo(String fcaFileTypeGreaterThanOrEqualTo) {
		this.fcaFileTypeGreaterThanOrEqualTo = fcaFileTypeGreaterThanOrEqualTo;
	}

	public String getFcaFileTypeGreaterThan() {
		return fcaFileTypeGreaterThan;
	}
	public void setFcaFileTypeGreaterThan(String fcaFileTypeGreaterThan) {
		this.fcaFileTypeGreaterThan = fcaFileTypeGreaterThan;
	}

	public String getFcaFileTypeEqualTo() {
		return fcaFileTypeEqualTo;
	}
	public void setFcaFileTypeEqualTo(String fcaFileTypeEqualTo) {
		this.fcaFileTypeEqualTo = fcaFileTypeEqualTo;
	}

	public java.util.List getFcaContractIdNotIn() {
		return fcaContractIdNotIn;
	}
	public void setFcaContractIdNotIn(java.util.List fcaContractIdNotIn) {
		this.fcaContractIdNotIn = fcaContractIdNotIn;
	}

	public Long getFcaContractIdNotEqualTo() {
		return fcaContractIdNotEqualTo;
	}
	public void setFcaContractIdNotEqualTo(Long fcaContractIdNotEqualTo) {
		this.fcaContractIdNotEqualTo = fcaContractIdNotEqualTo;
	}

	public Long getFcaContractIdLessThanOrEqualTo() {
		return fcaContractIdLessThanOrEqualTo;
	}
	public void setFcaContractIdLessThanOrEqualTo(Long fcaContractIdLessThanOrEqualTo) {
		this.fcaContractIdLessThanOrEqualTo = fcaContractIdLessThanOrEqualTo;
	}

	public Long getFcaContractIdLessThan() {
		return fcaContractIdLessThan;
	}
	public void setFcaContractIdLessThan(Long fcaContractIdLessThan) {
		this.fcaContractIdLessThan = fcaContractIdLessThan;
	}

	public Boolean getFcaContractIdIsNull() {
		return fcaContractIdIsNull;
	}
	public void setFcaContractIdIsNull(Boolean fcaContractIdIsNull) {
		this.fcaContractIdIsNull = fcaContractIdIsNull;
	}

	public Boolean getFcaContractIdIsNotNull() {
		return fcaContractIdIsNotNull;
	}
	public void setFcaContractIdIsNotNull(Boolean fcaContractIdIsNotNull) {
		this.fcaContractIdIsNotNull = fcaContractIdIsNotNull;
	}

	public java.util.List getFcaContractIdIn() {
		return fcaContractIdIn;
	}
	public void setFcaContractIdIn(java.util.List fcaContractIdIn) {
		this.fcaContractIdIn = fcaContractIdIn;
	}

	public Long getFcaContractIdGreaterThanOrEqualTo() {
		return fcaContractIdGreaterThanOrEqualTo;
	}
	public void setFcaContractIdGreaterThanOrEqualTo(Long fcaContractIdGreaterThanOrEqualTo) {
		this.fcaContractIdGreaterThanOrEqualTo = fcaContractIdGreaterThanOrEqualTo;
	}

	public Long getFcaContractIdGreaterThan() {
		return fcaContractIdGreaterThan;
	}
	public void setFcaContractIdGreaterThan(Long fcaContractIdGreaterThan) {
		this.fcaContractIdGreaterThan = fcaContractIdGreaterThan;
	}

	public Long getFcaContractIdEqualTo() {
		return fcaContractIdEqualTo;
	}
	public void setFcaContractIdEqualTo(Long fcaContractIdEqualTo) {
		this.fcaContractIdEqualTo = fcaContractIdEqualTo;
	}

	public java.util.List getDrNotIn() {
		return drNotIn;
	}
	public void setDrNotIn(java.util.List drNotIn) {
		this.drNotIn = drNotIn;
	}

	public Integer getDrNotEqualTo() {
		return drNotEqualTo;
	}
	public void setDrNotEqualTo(Integer drNotEqualTo) {
		this.drNotEqualTo = drNotEqualTo;
	}

	public Integer getDrLessThanOrEqualTo() {
		return drLessThanOrEqualTo;
	}
	public void setDrLessThanOrEqualTo(Integer drLessThanOrEqualTo) {
		this.drLessThanOrEqualTo = drLessThanOrEqualTo;
	}

	public Integer getDrLessThan() {
		return drLessThan;
	}
	public void setDrLessThan(Integer drLessThan) {
		this.drLessThan = drLessThan;
	}

	public Boolean getDrIsNull() {
		return drIsNull;
	}
	public void setDrIsNull(Boolean drIsNull) {
		this.drIsNull = drIsNull;
	}

	public Boolean getDrIsNotNull() {
		return drIsNotNull;
	}
	public void setDrIsNotNull(Boolean drIsNotNull) {
		this.drIsNotNull = drIsNotNull;
	}

	public java.util.List getDrIn() {
		return drIn;
	}
	public void setDrIn(java.util.List drIn) {
		this.drIn = drIn;
	}

	public Integer getDrGreaterThanOrEqualTo() {
		return drGreaterThanOrEqualTo;
	}
	public void setDrGreaterThanOrEqualTo(Integer drGreaterThanOrEqualTo) {
		this.drGreaterThanOrEqualTo = drGreaterThanOrEqualTo;
	}

	public Integer getDrGreaterThan() {
		return drGreaterThan;
	}
	public void setDrGreaterThan(Integer drGreaterThan) {
		this.drGreaterThan = drGreaterThan;
	}

	public Integer getDrEqualTo() {
		return drEqualTo;
	}
	public void setDrEqualTo(Integer drEqualTo) {
		this.drEqualTo = drEqualTo;
	}

	public String getCreateuserNotLike() {
		return createuserNotLike;
	}
	public void setCreateuserNotLike(String createuserNotLike) {
		this.createuserNotLike = createuserNotLike;
	}

	public java.util.List getCreateuserNotIn() {
		return createuserNotIn;
	}
	public void setCreateuserNotIn(java.util.List createuserNotIn) {
		this.createuserNotIn = createuserNotIn;
	}

	public String getCreateuserNotEqualTo() {
		return createuserNotEqualTo;
	}
	public void setCreateuserNotEqualTo(String createuserNotEqualTo) {
		this.createuserNotEqualTo = createuserNotEqualTo;
	}

	public String getCreateuserLike() {
		return createuserLike;
	}
	public void setCreateuserLike(String createuserLike) {
		this.createuserLike = createuserLike;
	}

	public String getCreateuserLessThanOrEqualTo() {
		return createuserLessThanOrEqualTo;
	}
	public void setCreateuserLessThanOrEqualTo(String createuserLessThanOrEqualTo) {
		this.createuserLessThanOrEqualTo = createuserLessThanOrEqualTo;
	}

	public String getCreateuserLessThan() {
		return createuserLessThan;
	}
	public void setCreateuserLessThan(String createuserLessThan) {
		this.createuserLessThan = createuserLessThan;
	}

	public Boolean getCreateuserIsNull() {
		return createuserIsNull;
	}
	public void setCreateuserIsNull(Boolean createuserIsNull) {
		this.createuserIsNull = createuserIsNull;
	}

	public Boolean getCreateuserIsNotNull() {
		return createuserIsNotNull;
	}
	public void setCreateuserIsNotNull(Boolean createuserIsNotNull) {
		this.createuserIsNotNull = createuserIsNotNull;
	}

	public java.util.List getCreateuserIn() {
		return createuserIn;
	}
	public void setCreateuserIn(java.util.List createuserIn) {
		this.createuserIn = createuserIn;
	}

	public String getCreateuserGreaterThanOrEqualTo() {
		return createuserGreaterThanOrEqualTo;
	}
	public void setCreateuserGreaterThanOrEqualTo(String createuserGreaterThanOrEqualTo) {
		this.createuserGreaterThanOrEqualTo = createuserGreaterThanOrEqualTo;
	}

	public String getCreateuserGreaterThan() {
		return createuserGreaterThan;
	}
	public void setCreateuserGreaterThan(String createuserGreaterThan) {
		this.createuserGreaterThan = createuserGreaterThan;
	}

	public String getCreateuserEqualTo() {
		return createuserEqualTo;
	}
	public void setCreateuserEqualTo(String createuserEqualTo) {
		this.createuserEqualTo = createuserEqualTo;
	}

	public java.util.List getCreatetimeNotIn() {
		return createtimeNotIn;
	}
	public void setCreatetimeNotIn(java.util.List createtimeNotIn) {
		this.createtimeNotIn = createtimeNotIn;
	}

	public java.util.Date getCreatetimeNotEqualTo() {
		return createtimeNotEqualTo;
	}
	public void setCreatetimeNotEqualTo(java.util.Date createtimeNotEqualTo) {
		this.createtimeNotEqualTo = createtimeNotEqualTo;
	}

	public java.util.Date getCreatetimeLessThanOrEqualTo() {
		return createtimeLessThanOrEqualTo;
	}
	public void setCreatetimeLessThanOrEqualTo(java.util.Date createtimeLessThanOrEqualTo) {
		this.createtimeLessThanOrEqualTo = createtimeLessThanOrEqualTo;
	}

	public java.util.Date getCreatetimeLessThan() {
		return createtimeLessThan;
	}
	public void setCreatetimeLessThan(java.util.Date createtimeLessThan) {
		this.createtimeLessThan = createtimeLessThan;
	}

	public Boolean getCreatetimeIsNull() {
		return createtimeIsNull;
	}
	public void setCreatetimeIsNull(Boolean createtimeIsNull) {
		this.createtimeIsNull = createtimeIsNull;
	}

	public Boolean getCreatetimeIsNotNull() {
		return createtimeIsNotNull;
	}
	public void setCreatetimeIsNotNull(Boolean createtimeIsNotNull) {
		this.createtimeIsNotNull = createtimeIsNotNull;
	}

	public java.util.List getCreatetimeIn() {
		return createtimeIn;
	}
	public void setCreatetimeIn(java.util.List createtimeIn) {
		this.createtimeIn = createtimeIn;
	}

	public java.util.Date getCreatetimeGreaterThanOrEqualTo() {
		return createtimeGreaterThanOrEqualTo;
	}
	public void setCreatetimeGreaterThanOrEqualTo(java.util.Date createtimeGreaterThanOrEqualTo) {
		this.createtimeGreaterThanOrEqualTo = createtimeGreaterThanOrEqualTo;
	}

	public java.util.Date getCreatetimeGreaterThan() {
		return createtimeGreaterThan;
	}
	public void setCreatetimeGreaterThan(java.util.Date createtimeGreaterThan) {
		this.createtimeGreaterThan = createtimeGreaterThan;
	}

	public java.util.Date getCreatetimeEqualTo() {
		return createtimeEqualTo;
	}
	public void setCreatetimeEqualTo(java.util.Date createtimeEqualTo) {
		this.createtimeEqualTo = createtimeEqualTo;
	}

	public void setSidx(String sidx) {
		this.sidx = sidx;
	}
	public String getSord() {
		return sord;
	}
	public void setSord(String sord) {
		 this.sord = sord;
	}
}
