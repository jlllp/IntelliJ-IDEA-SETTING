package com.mrk.finance.example;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

public class FncContractRentalFeesExample {
    protected String orderByClause;

    protected boolean distinct;

    protected List<Criteria> oredCriteria;

    public FncContractRentalFeesExample() {
        oredCriteria = new ArrayList<Criteria>();
    }

    public void setOrderByClause(String orderByClause) {
        this.orderByClause = orderByClause;
    }

    public String getOrderByClause() {
        return orderByClause;
    }

    public void setDistinct(boolean distinct) {
        this.distinct = distinct;
    }

    public boolean isDistinct() {
        return distinct;
    }

    public List<Criteria> getOredCriteria() {
        return oredCriteria;
    }

    public void or(Criteria criteria) {
        oredCriteria.add(criteria);
    }

    public Criteria or() {
        Criteria criteria = createCriteriaInternal();
        oredCriteria.add(criteria);
        return criteria;
    }

    public Criteria createCriteria() {
        Criteria criteria = createCriteriaInternal();
        if (oredCriteria.size() == 0) {
            oredCriteria.add(criteria);
        }
        return criteria;
    }

    protected Criteria createCriteriaInternal() {
        Criteria criteria = new Criteria();
        return criteria;
    }

    public void clear() {
        oredCriteria.clear();
        orderByClause = null;
        distinct = false;
    }

    protected abstract static class GeneratedCriteria {
        protected List<Criterion> criteria;

        protected GeneratedCriteria() {
            super();
            criteria = new ArrayList<Criterion>();
        }

        public boolean isValid() {
            return criteria.size() > 0;
        }

        public List<Criterion> getAllCriteria() {
            return criteria;
        }

        public List<Criterion> getCriteria() {
            return criteria;
        }

        protected void addCriterion(String condition) {
            if (condition == null) {
                throw new RuntimeException("Value for condition cannot be null");
            }
            criteria.add(new Criterion(condition));
        }

        protected void addCriterion(String condition, Object value, String property) {
            if (value == null) {
                throw new RuntimeException("Value for " + property + " cannot be null");
            }
            criteria.add(new Criterion(condition, value));
        }

        protected void addCriterion(String condition, Object value1, Object value2, String property) {
            if (value1 == null || value2 == null) {
                throw new RuntimeException("Between values for " + property + " cannot be null");
            }
            criteria.add(new Criterion(condition, value1, value2));
        }

        public Criteria andFcrfIdIsNull() {
            addCriterion("fcrf_id is null");
            return (Criteria) this;
        }

        public Criteria andFcrfIdIsNotNull() {
            addCriterion("fcrf_id is not null");
            return (Criteria) this;
        }

        public Criteria andFcrfIdEqualTo(Long value) {
            addCriterion("fcrf_id =", value, "fcrfId");
            return (Criteria) this;
        }

        public Criteria andFcrfIdNotEqualTo(Long value) {
            addCriterion("fcrf_id <>", value, "fcrfId");
            return (Criteria) this;
        }

        public Criteria andFcrfIdGreaterThan(Long value) {
            addCriterion("fcrf_id >", value, "fcrfId");
            return (Criteria) this;
        }

        public Criteria andFcrfIdGreaterThanOrEqualTo(Long value) {
            addCriterion("fcrf_id >=", value, "fcrfId");
            return (Criteria) this;
        }

        public Criteria andFcrfIdLessThan(Long value) {
            addCriterion("fcrf_id <", value, "fcrfId");
            return (Criteria) this;
        }

        public Criteria andFcrfIdLessThanOrEqualTo(Long value) {
            addCriterion("fcrf_id <=", value, "fcrfId");
            return (Criteria) this;
        }

        public Criteria andFcrfIdIn(List<Long> values) {
            addCriterion("fcrf_id in", values, "fcrfId");
            return (Criteria) this;
        }

        public Criteria andFcrfIdNotIn(List<Long> values) {
            addCriterion("fcrf_id not in", values, "fcrfId");
            return (Criteria) this;
        }

        public Criteria andFcrfIdBetween(Long value1, Long value2) {
            addCriterion("fcrf_id between", value1, value2, "fcrfId");
            return (Criteria) this;
        }

        public Criteria andFcrfIdNotBetween(Long value1, Long value2) {
            addCriterion("fcrf_id not between", value1, value2, "fcrfId");
            return (Criteria) this;
        }

        public Criteria andFcrfContractIdIsNull() {
            addCriterion("fcrf_contract_id is null");
            return (Criteria) this;
        }

        public Criteria andFcrfContractIdIsNotNull() {
            addCriterion("fcrf_contract_id is not null");
            return (Criteria) this;
        }

        public Criteria andFcrfContractIdEqualTo(Long value) {
            addCriterion("fcrf_contract_id =", value, "fcrfContractId");
            return (Criteria) this;
        }

        public Criteria andFcrfContractIdNotEqualTo(Long value) {
            addCriterion("fcrf_contract_id <>", value, "fcrfContractId");
            return (Criteria) this;
        }

        public Criteria andFcrfContractIdGreaterThan(Long value) {
            addCriterion("fcrf_contract_id >", value, "fcrfContractId");
            return (Criteria) this;
        }

        public Criteria andFcrfContractIdGreaterThanOrEqualTo(Long value) {
            addCriterion("fcrf_contract_id >=", value, "fcrfContractId");
            return (Criteria) this;
        }

        public Criteria andFcrfContractIdLessThan(Long value) {
            addCriterion("fcrf_contract_id <", value, "fcrfContractId");
            return (Criteria) this;
        }

        public Criteria andFcrfContractIdLessThanOrEqualTo(Long value) {
            addCriterion("fcrf_contract_id <=", value, "fcrfContractId");
            return (Criteria) this;
        }

        public Criteria andFcrfContractIdIn(List<Long> values) {
            addCriterion("fcrf_contract_id in", values, "fcrfContractId");
            return (Criteria) this;
        }

        public Criteria andFcrfContractIdNotIn(List<Long> values) {
            addCriterion("fcrf_contract_id not in", values, "fcrfContractId");
            return (Criteria) this;
        }

        public Criteria andFcrfContractIdBetween(Long value1, Long value2) {
            addCriterion("fcrf_contract_id between", value1, value2, "fcrfContractId");
            return (Criteria) this;
        }

        public Criteria andFcrfContractIdNotBetween(Long value1, Long value2) {
            addCriterion("fcrf_contract_id not between", value1, value2, "fcrfContractId");
            return (Criteria) this;
        }

        public Criteria andFcrfRentFeesIdIsNull() {
            addCriterion("fcrf_rent_fees_id is null");
            return (Criteria) this;
        }

        public Criteria andFcrfRentFeesIdIsNotNull() {
            addCriterion("fcrf_rent_fees_id is not null");
            return (Criteria) this;
        }

        public Criteria andFcrfRentFeesIdEqualTo(Long value) {
            addCriterion("fcrf_rent_fees_id =", value, "fcrfRentFeesId");
            return (Criteria) this;
        }

        public Criteria andFcrfRentFeesIdNotEqualTo(Long value) {
            addCriterion("fcrf_rent_fees_id <>", value, "fcrfRentFeesId");
            return (Criteria) this;
        }

        public Criteria andFcrfRentFeesIdGreaterThan(Long value) {
            addCriterion("fcrf_rent_fees_id >", value, "fcrfRentFeesId");
            return (Criteria) this;
        }

        public Criteria andFcrfRentFeesIdGreaterThanOrEqualTo(Long value) {
            addCriterion("fcrf_rent_fees_id >=", value, "fcrfRentFeesId");
            return (Criteria) this;
        }

        public Criteria andFcrfRentFeesIdLessThan(Long value) {
            addCriterion("fcrf_rent_fees_id <", value, "fcrfRentFeesId");
            return (Criteria) this;
        }

        public Criteria andFcrfRentFeesIdLessThanOrEqualTo(Long value) {
            addCriterion("fcrf_rent_fees_id <=", value, "fcrfRentFeesId");
            return (Criteria) this;
        }

        public Criteria andFcrfRentFeesIdIn(List<Long> values) {
            addCriterion("fcrf_rent_fees_id in", values, "fcrfRentFeesId");
            return (Criteria) this;
        }

        public Criteria andFcrfRentFeesIdNotIn(List<Long> values) {
            addCriterion("fcrf_rent_fees_id not in", values, "fcrfRentFeesId");
            return (Criteria) this;
        }

        public Criteria andFcrfRentFeesIdBetween(Long value1, Long value2) {
            addCriterion("fcrf_rent_fees_id between", value1, value2, "fcrfRentFeesId");
            return (Criteria) this;
        }

        public Criteria andFcrfRentFeesIdNotBetween(Long value1, Long value2) {
            addCriterion("fcrf_rent_fees_id not between", value1, value2, "fcrfRentFeesId");
            return (Criteria) this;
        }

        public Criteria andFcrfWriteIsNull() {
            addCriterion("fcrf_write is null");
            return (Criteria) this;
        }

        public Criteria andFcrfWriteIsNotNull() {
            addCriterion("fcrf_write is not null");
            return (Criteria) this;
        }

        public Criteria andFcrfWriteEqualTo(Integer value) {
            addCriterion("fcrf_write =", value, "fcrfWrite");
            return (Criteria) this;
        }

        public Criteria andFcrfWriteNotEqualTo(Integer value) {
            addCriterion("fcrf_write <>", value, "fcrfWrite");
            return (Criteria) this;
        }

        public Criteria andFcrfWriteGreaterThan(Integer value) {
            addCriterion("fcrf_write >", value, "fcrfWrite");
            return (Criteria) this;
        }

        public Criteria andFcrfWriteGreaterThanOrEqualTo(Integer value) {
            addCriterion("fcrf_write >=", value, "fcrfWrite");
            return (Criteria) this;
        }

        public Criteria andFcrfWriteLessThan(Integer value) {
            addCriterion("fcrf_write <", value, "fcrfWrite");
            return (Criteria) this;
        }

        public Criteria andFcrfWriteLessThanOrEqualTo(Integer value) {
            addCriterion("fcrf_write <=", value, "fcrfWrite");
            return (Criteria) this;
        }

        public Criteria andFcrfWriteIn(List<Integer> values) {
            addCriterion("fcrf_write in", values, "fcrfWrite");
            return (Criteria) this;
        }

        public Criteria andFcrfWriteNotIn(List<Integer> values) {
            addCriterion("fcrf_write not in", values, "fcrfWrite");
            return (Criteria) this;
        }

        public Criteria andFcrfWriteBetween(Integer value1, Integer value2) {
            addCriterion("fcrf_write between", value1, value2, "fcrfWrite");
            return (Criteria) this;
        }

        public Criteria andFcrfWriteNotBetween(Integer value1, Integer value2) {
            addCriterion("fcrf_write not between", value1, value2, "fcrfWrite");
            return (Criteria) this;
        }

        public Criteria andFcrfValueIsNull() {
            addCriterion("fcrf_value is null");
            return (Criteria) this;
        }

        public Criteria andFcrfValueIsNotNull() {
            addCriterion("fcrf_value is not null");
            return (Criteria) this;
        }

        public Criteria andFcrfValueEqualTo(String value) {
            addCriterion("fcrf_value =", value, "fcrfValue");
            return (Criteria) this;
        }

        public Criteria andFcrfValueNotEqualTo(String value) {
            addCriterion("fcrf_value <>", value, "fcrfValue");
            return (Criteria) this;
        }

        public Criteria andFcrfValueGreaterThan(String value) {
            addCriterion("fcrf_value >", value, "fcrfValue");
            return (Criteria) this;
        }

        public Criteria andFcrfValueGreaterThanOrEqualTo(String value) {
            addCriterion("fcrf_value >=", value, "fcrfValue");
            return (Criteria) this;
        }

        public Criteria andFcrfValueLessThan(String value) {
            addCriterion("fcrf_value <", value, "fcrfValue");
            return (Criteria) this;
        }

        public Criteria andFcrfValueLessThanOrEqualTo(String value) {
            addCriterion("fcrf_value <=", value, "fcrfValue");
            return (Criteria) this;
        }

        public Criteria andFcrfValueLike(String value) {
            addCriterion("fcrf_value like", value, "fcrfValue");
            return (Criteria) this;
        }

        public Criteria andFcrfValueNotLike(String value) {
            addCriterion("fcrf_value not like", value, "fcrfValue");
            return (Criteria) this;
        }

        public Criteria andFcrfValueIn(List<String> values) {
            addCriterion("fcrf_value in", values, "fcrfValue");
            return (Criteria) this;
        }

        public Criteria andFcrfValueNotIn(List<String> values) {
            addCriterion("fcrf_value not in", values, "fcrfValue");
            return (Criteria) this;
        }

        public Criteria andFcrfValueBetween(String value1, String value2) {
            addCriterion("fcrf_value between", value1, value2, "fcrfValue");
            return (Criteria) this;
        }

        public Criteria andFcrfValueNotBetween(String value1, String value2) {
            addCriterion("fcrf_value not between", value1, value2, "fcrfValue");
            return (Criteria) this;
        }

        public Criteria andRemarkIsNull() {
            addCriterion("remark is null");
            return (Criteria) this;
        }

        public Criteria andRemarkIsNotNull() {
            addCriterion("remark is not null");
            return (Criteria) this;
        }

        public Criteria andRemarkEqualTo(String value) {
            addCriterion("remark =", value, "remark");
            return (Criteria) this;
        }

        public Criteria andRemarkNotEqualTo(String value) {
            addCriterion("remark <>", value, "remark");
            return (Criteria) this;
        }

        public Criteria andRemarkGreaterThan(String value) {
            addCriterion("remark >", value, "remark");
            return (Criteria) this;
        }

        public Criteria andRemarkGreaterThanOrEqualTo(String value) {
            addCriterion("remark >=", value, "remark");
            return (Criteria) this;
        }

        public Criteria andRemarkLessThan(String value) {
            addCriterion("remark <", value, "remark");
            return (Criteria) this;
        }

        public Criteria andRemarkLessThanOrEqualTo(String value) {
            addCriterion("remark <=", value, "remark");
            return (Criteria) this;
        }

        public Criteria andRemarkLike(String value) {
            addCriterion("remark like", value, "remark");
            return (Criteria) this;
        }

        public Criteria andRemarkNotLike(String value) {
            addCriterion("remark not like", value, "remark");
            return (Criteria) this;
        }

        public Criteria andRemarkIn(List<String> values) {
            addCriterion("remark in", values, "remark");
            return (Criteria) this;
        }

        public Criteria andRemarkNotIn(List<String> values) {
            addCriterion("remark not in", values, "remark");
            return (Criteria) this;
        }

        public Criteria andRemarkBetween(String value1, String value2) {
            addCriterion("remark between", value1, value2, "remark");
            return (Criteria) this;
        }

        public Criteria andRemarkNotBetween(String value1, String value2) {
            addCriterion("remark not between", value1, value2, "remark");
            return (Criteria) this;
        }

        public Criteria andCreateuserIsNull() {
            addCriterion("createuser is null");
            return (Criteria) this;
        }

        public Criteria andCreateuserIsNotNull() {
            addCriterion("createuser is not null");
            return (Criteria) this;
        }

        public Criteria andCreateuserEqualTo(String value) {
            addCriterion("createuser =", value, "createuser");
            return (Criteria) this;
        }

        public Criteria andCreateuserNotEqualTo(String value) {
            addCriterion("createuser <>", value, "createuser");
            return (Criteria) this;
        }

        public Criteria andCreateuserGreaterThan(String value) {
            addCriterion("createuser >", value, "createuser");
            return (Criteria) this;
        }

        public Criteria andCreateuserGreaterThanOrEqualTo(String value) {
            addCriterion("createuser >=", value, "createuser");
            return (Criteria) this;
        }

        public Criteria andCreateuserLessThan(String value) {
            addCriterion("createuser <", value, "createuser");
            return (Criteria) this;
        }

        public Criteria andCreateuserLessThanOrEqualTo(String value) {
            addCriterion("createuser <=", value, "createuser");
            return (Criteria) this;
        }

        public Criteria andCreateuserLike(String value) {
            addCriterion("createuser like", value, "createuser");
            return (Criteria) this;
        }

        public Criteria andCreateuserNotLike(String value) {
            addCriterion("createuser not like", value, "createuser");
            return (Criteria) this;
        }

        public Criteria andCreateuserIn(List<String> values) {
            addCriterion("createuser in", values, "createuser");
            return (Criteria) this;
        }

        public Criteria andCreateuserNotIn(List<String> values) {
            addCriterion("createuser not in", values, "createuser");
            return (Criteria) this;
        }

        public Criteria andCreateuserBetween(String value1, String value2) {
            addCriterion("createuser between", value1, value2, "createuser");
            return (Criteria) this;
        }

        public Criteria andCreateuserNotBetween(String value1, String value2) {
            addCriterion("createuser not between", value1, value2, "createuser");
            return (Criteria) this;
        }

        public Criteria andCreatetimeIsNull() {
            addCriterion("createtime is null");
            return (Criteria) this;
        }

        public Criteria andCreatetimeIsNotNull() {
            addCriterion("createtime is not null");
            return (Criteria) this;
        }

        public Criteria andCreatetimeEqualTo(Date value) {
            addCriterion("createtime =", value, "createtime");
            return (Criteria) this;
        }

        public Criteria andCreatetimeNotEqualTo(Date value) {
            addCriterion("createtime <>", value, "createtime");
            return (Criteria) this;
        }

        public Criteria andCreatetimeGreaterThan(Date value) {
            addCriterion("createtime >", value, "createtime");
            return (Criteria) this;
        }

        public Criteria andCreatetimeGreaterThanOrEqualTo(Date value) {
            addCriterion("createtime >=", value, "createtime");
            return (Criteria) this;
        }

        public Criteria andCreatetimeLessThan(Date value) {
            addCriterion("createtime <", value, "createtime");
            return (Criteria) this;
        }

        public Criteria andCreatetimeLessThanOrEqualTo(Date value) {
            addCriterion("createtime <=", value, "createtime");
            return (Criteria) this;
        }

        public Criteria andCreatetimeIn(List<Date> values) {
            addCriterion("createtime in", values, "createtime");
            return (Criteria) this;
        }

        public Criteria andCreatetimeNotIn(List<Date> values) {
            addCriterion("createtime not in", values, "createtime");
            return (Criteria) this;
        }

        public Criteria andCreatetimeBetween(Date value1, Date value2) {
            addCriterion("createtime between", value1, value2, "createtime");
            return (Criteria) this;
        }

        public Criteria andCreatetimeNotBetween(Date value1, Date value2) {
            addCriterion("createtime not between", value1, value2, "createtime");
            return (Criteria) this;
        }

        public Criteria andUpdateuserIsNull() {
            addCriterion("updateuser is null");
            return (Criteria) this;
        }

        public Criteria andUpdateuserIsNotNull() {
            addCriterion("updateuser is not null");
            return (Criteria) this;
        }

        public Criteria andUpdateuserEqualTo(String value) {
            addCriterion("updateuser =", value, "updateuser");
            return (Criteria) this;
        }

        public Criteria andUpdateuserNotEqualTo(String value) {
            addCriterion("updateuser <>", value, "updateuser");
            return (Criteria) this;
        }

        public Criteria andUpdateuserGreaterThan(String value) {
            addCriterion("updateuser >", value, "updateuser");
            return (Criteria) this;
        }

        public Criteria andUpdateuserGreaterThanOrEqualTo(String value) {
            addCriterion("updateuser >=", value, "updateuser");
            return (Criteria) this;
        }

        public Criteria andUpdateuserLessThan(String value) {
            addCriterion("updateuser <", value, "updateuser");
            return (Criteria) this;
        }

        public Criteria andUpdateuserLessThanOrEqualTo(String value) {
            addCriterion("updateuser <=", value, "updateuser");
            return (Criteria) this;
        }

        public Criteria andUpdateuserLike(String value) {
            addCriterion("updateuser like", value, "updateuser");
            return (Criteria) this;
        }

        public Criteria andUpdateuserNotLike(String value) {
            addCriterion("updateuser not like", value, "updateuser");
            return (Criteria) this;
        }

        public Criteria andUpdateuserIn(List<String> values) {
            addCriterion("updateuser in", values, "updateuser");
            return (Criteria) this;
        }

        public Criteria andUpdateuserNotIn(List<String> values) {
            addCriterion("updateuser not in", values, "updateuser");
            return (Criteria) this;
        }

        public Criteria andUpdateuserBetween(String value1, String value2) {
            addCriterion("updateuser between", value1, value2, "updateuser");
            return (Criteria) this;
        }

        public Criteria andUpdateuserNotBetween(String value1, String value2) {
            addCriterion("updateuser not between", value1, value2, "updateuser");
            return (Criteria) this;
        }

        public Criteria andUpdatetimeIsNull() {
            addCriterion("updatetime is null");
            return (Criteria) this;
        }

        public Criteria andUpdatetimeIsNotNull() {
            addCriterion("updatetime is not null");
            return (Criteria) this;
        }

        public Criteria andUpdatetimeEqualTo(Date value) {
            addCriterion("updatetime =", value, "updatetime");
            return (Criteria) this;
        }

        public Criteria andUpdatetimeNotEqualTo(Date value) {
            addCriterion("updatetime <>", value, "updatetime");
            return (Criteria) this;
        }

        public Criteria andUpdatetimeGreaterThan(Date value) {
            addCriterion("updatetime >", value, "updatetime");
            return (Criteria) this;
        }

        public Criteria andUpdatetimeGreaterThanOrEqualTo(Date value) {
            addCriterion("updatetime >=", value, "updatetime");
            return (Criteria) this;
        }

        public Criteria andUpdatetimeLessThan(Date value) {
            addCriterion("updatetime <", value, "updatetime");
            return (Criteria) this;
        }

        public Criteria andUpdatetimeLessThanOrEqualTo(Date value) {
            addCriterion("updatetime <=", value, "updatetime");
            return (Criteria) this;
        }

        public Criteria andUpdatetimeIn(List<Date> values) {
            addCriterion("updatetime in", values, "updatetime");
            return (Criteria) this;
        }

        public Criteria andUpdatetimeNotIn(List<Date> values) {
            addCriterion("updatetime not in", values, "updatetime");
            return (Criteria) this;
        }

        public Criteria andUpdatetimeBetween(Date value1, Date value2) {
            addCriterion("updatetime between", value1, value2, "updatetime");
            return (Criteria) this;
        }

        public Criteria andUpdatetimeNotBetween(Date value1, Date value2) {
            addCriterion("updatetime not between", value1, value2, "updatetime");
            return (Criteria) this;
        }

        public Criteria andDrIsNull() {
            addCriterion("dr is null");
            return (Criteria) this;
        }

        public Criteria andDrIsNotNull() {
            addCriterion("dr is not null");
            return (Criteria) this;
        }

        public Criteria andDrEqualTo(Integer value) {
            addCriterion("dr =", value, "dr");
            return (Criteria) this;
        }

        public Criteria andDrNotEqualTo(Integer value) {
            addCriterion("dr <>", value, "dr");
            return (Criteria) this;
        }

        public Criteria andDrGreaterThan(Integer value) {
            addCriterion("dr >", value, "dr");
            return (Criteria) this;
        }

        public Criteria andDrGreaterThanOrEqualTo(Integer value) {
            addCriterion("dr >=", value, "dr");
            return (Criteria) this;
        }

        public Criteria andDrLessThan(Integer value) {
            addCriterion("dr <", value, "dr");
            return (Criteria) this;
        }

        public Criteria andDrLessThanOrEqualTo(Integer value) {
            addCriterion("dr <=", value, "dr");
            return (Criteria) this;
        }

        public Criteria andDrIn(List<Integer> values) {
            addCriterion("dr in", values, "dr");
            return (Criteria) this;
        }

        public Criteria andDrNotIn(List<Integer> values) {
            addCriterion("dr not in", values, "dr");
            return (Criteria) this;
        }

        public Criteria andDrBetween(Integer value1, Integer value2) {
            addCriterion("dr between", value1, value2, "dr");
            return (Criteria) this;
        }

        public Criteria andDrNotBetween(Integer value1, Integer value2) {
            addCriterion("dr not between", value1, value2, "dr");
            return (Criteria) this;
        }
    }

    public static class Criteria extends GeneratedCriteria {

        protected Criteria() {
            super();
        }
    }

    public static class Criterion {
        private String condition;

        private Object value;

        private Object secondValue;

        private boolean noValue;

        private boolean singleValue;

        private boolean betweenValue;

        private boolean listValue;

        private String typeHandler;

        public String getCondition() {
            return condition;
        }

        public Object getValue() {
            return value;
        }

        public Object getSecondValue() {
            return secondValue;
        }

        public boolean isNoValue() {
            return noValue;
        }

        public boolean isSingleValue() {
            return singleValue;
        }

        public boolean isBetweenValue() {
            return betweenValue;
        }

        public boolean isListValue() {
            return listValue;
        }

        public String getTypeHandler() {
            return typeHandler;
        }

        protected Criterion(String condition) {
            super();
            this.condition = condition;
            this.typeHandler = null;
            this.noValue = true;
        }

        protected Criterion(String condition, Object value, String typeHandler) {
            super();
            this.condition = condition;
            this.value = value;
            this.typeHandler = typeHandler;
            if (value instanceof List<?>) {
                this.listValue = true;
            } else {
                this.singleValue = true;
            }
        }

        protected Criterion(String condition, Object value) {
            this(condition, value, null);
        }

        protected Criterion(String condition, Object value, Object secondValue, String typeHandler) {
            super();
            this.condition = condition;
            this.value = value;
            this.secondValue = secondValue;
            this.typeHandler = typeHandler;
            this.betweenValue = true;
        }

        protected Criterion(String condition, Object value, Object secondValue) {
            this(condition, value, secondValue, null);
        }
    }
}
