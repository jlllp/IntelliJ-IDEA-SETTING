package com.mrk.finance.service;

import com.github.pagehelper.PageInfo;
import com.mrk.finance.model.FncRevenueWaterRecord;
import com.mrk.finance.queryvo.FncRevenueWaterRecordQueryVo;

import java.util.List;

/**
 * @Description: FncRevenueWaterRecord
 */
public interface FncRevenueWaterRecordService {
    /**
     * 分页查询
     *
     * @param queryVo 前端查询对象
     * @return 分页查询数据
     */
    PageInfo<FncRevenueWaterRecord> page(FncRevenueWaterRecordQueryVo queryVo);

    /**
     * 列表查询
     * @param queryVo 前端查询对象
     * @return 分页查询数据
     */
    List<FncRevenueWaterRecord> list(FncRevenueWaterRecordQueryVo queryVo);

    /**
     * 新增
     *
     * @param entity
     * @return 结果
     */
    int add(FncRevenueWaterRecord entity);

    /**
     * 修改
     *
     * @param entity
     * @return 结果
     */
    int update(FncRevenueWaterRecord entity);

    /**
     * 删除
     */
    int delete(Long id);

    /**
    * 通过ID查询
    * @param id
    */
    FncRevenueWaterRecord getById(Long id);
}
