package com.mrk.finance.dao;

import com.mrk.common.base.BaseMapper;
import com.mrk.finance.model.FncConfirmIncome;

/**
 * Mapper接口
 * @author 自动工具
 */
public interface FncConfirmIncomeMapper extends BaseMapper<FncConfirmIncome> {

}
