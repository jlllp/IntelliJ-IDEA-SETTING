package com.mrk.finance.query;
import com.mrk.common.utils.text.CheckUtil;

/**
 * @author 自动生成工具
 * @date   2021/11/10
 */
public class FncRevenueWaterRecordQuery {
	private String updateuserNotLike;
	private java.util.List updateuserNotIn;
	private String updateuserNotEqualTo;
	private String updateuserLike;
	private String updateuserLessThanOrEqualTo;
	private String updateuserLessThan;
	private Boolean updateuserIsNull;
	private Boolean updateuserIsNotNull;
	private java.util.List updateuserIn;
	private String updateuserGreaterThanOrEqualTo;
	private String updateuserGreaterThan;
	private String updateuserEqualTo;
	private java.util.List updatetimeNotIn;
	private java.util.Date updatetimeNotEqualTo;
	private java.util.Date updatetimeLessThanOrEqualTo;
	private java.util.Date updatetimeLessThan;
	private Boolean updatetimeIsNull;
	private Boolean updatetimeIsNotNull;
	private java.util.List updatetimeIn;
	private java.util.Date updatetimeGreaterThanOrEqualTo;
	private java.util.Date updatetimeGreaterThan;
	private java.util.Date updatetimeEqualTo;
	private String remarkNotLike;
	private java.util.List remarkNotIn;
	private String remarkNotEqualTo;
	private String remarkLike;
	private String remarkLessThanOrEqualTo;
	private String remarkLessThan;
	private Boolean remarkIsNull;
	private Boolean remarkIsNotNull;
	private java.util.List remarkIn;
	private String remarkGreaterThanOrEqualTo;
	private String remarkGreaterThan;
	private String remarkEqualTo;
	private java.util.List frwrRevenueTypeNotIn;
	private Integer frwrRevenueTypeNotEqualTo;
	private Integer frwrRevenueTypeLessThanOrEqualTo;
	private Integer frwrRevenueTypeLessThan;
	private Boolean frwrRevenueTypeIsNull;
	private Boolean frwrRevenueTypeIsNotNull;
	private java.util.List frwrRevenueTypeIn;
	private Integer frwrRevenueTypeGreaterThanOrEqualTo;
	private Integer frwrRevenueTypeGreaterThan;
	private Integer frwrRevenueTypeEqualTo;
	private java.util.List frwrRevenueIdNotIn;
	private Long frwrRevenueIdNotEqualTo;
	private Long frwrRevenueIdLessThanOrEqualTo;
	private Long frwrRevenueIdLessThan;
	private Boolean frwrRevenueIdIsNull;
	private Boolean frwrRevenueIdIsNotNull;
	private java.util.List frwrRevenueIdIn;
	private Long frwrRevenueIdGreaterThanOrEqualTo;
	private Long frwrRevenueIdGreaterThan;
	private Long frwrRevenueIdEqualTo;
	private java.util.List frwrMatchStateNotIn;
	private Integer frwrMatchStateNotEqualTo;
	private Integer frwrMatchStateLessThanOrEqualTo;
	private Integer frwrMatchStateLessThan;
	private Boolean frwrMatchStateIsNull;
	private Boolean frwrMatchStateIsNotNull;
	private java.util.List frwrMatchStateIn;
	private Integer frwrMatchStateGreaterThanOrEqualTo;
	private Integer frwrMatchStateGreaterThan;
	private Integer frwrMatchStateEqualTo;
	private java.util.List frwrIdNotIn;
	private Long frwrIdNotEqualTo;
	private Long frwrIdLessThanOrEqualTo;
	private Long frwrIdLessThan;
	private Boolean frwrIdIsNull;
	private Boolean frwrIdIsNotNull;
	private java.util.List frwrIdIn;
	private Long frwrIdGreaterThanOrEqualTo;
	private Long frwrIdGreaterThan;
	private Long frwrIdEqualTo;
	private String frwrDescribeNotLike;
	private java.util.List frwrDescribeNotIn;
	private String frwrDescribeNotEqualTo;
	private String frwrDescribeLike;
	private String frwrDescribeLessThanOrEqualTo;
	private String frwrDescribeLessThan;
	private Boolean frwrDescribeIsNull;
	private Boolean frwrDescribeIsNotNull;
	private java.util.List frwrDescribeIn;
	private String frwrDescribeGreaterThanOrEqualTo;
	private String frwrDescribeGreaterThan;
	private String frwrDescribeEqualTo;
	private java.util.List frwrBillIdNotIn;
	private Long frwrBillIdNotEqualTo;
	private Long frwrBillIdLessThanOrEqualTo;
	private Long frwrBillIdLessThan;
	private Boolean frwrBillIdIsNull;
	private Boolean frwrBillIdIsNotNull;
	private java.util.List frwrBillIdIn;
	private Long frwrBillIdGreaterThanOrEqualTo;
	private Long frwrBillIdGreaterThan;
	private Long frwrBillIdEqualTo;
	private java.util.List drNotIn;
	private Integer drNotEqualTo;
	private Integer drLessThanOrEqualTo;
	private Integer drLessThan;
	private Boolean drIsNull;
	private Boolean drIsNotNull;
	private java.util.List drIn;
	private Integer drGreaterThanOrEqualTo;
	private Integer drGreaterThan;
	private Integer drEqualTo;
	private String createuserNotLike;
	private java.util.List createuserNotIn;
	private String createuserNotEqualTo;
	private String createuserLike;
	private String createuserLessThanOrEqualTo;
	private String createuserLessThan;
	private Boolean createuserIsNull;
	private Boolean createuserIsNotNull;
	private java.util.List createuserIn;
	private String createuserGreaterThanOrEqualTo;
	private String createuserGreaterThan;
	private String createuserEqualTo;
	private java.util.List createtimeNotIn;
	private java.util.Date createtimeNotEqualTo;
	private java.util.Date createtimeLessThanOrEqualTo;
	private java.util.Date createtimeLessThan;
	private Boolean createtimeIsNull;
	private Boolean createtimeIsNotNull;
	private java.util.List createtimeIn;
	private java.util.Date createtimeGreaterThanOrEqualTo;
	private java.util.Date createtimeGreaterThan;
	private java.util.Date createtimeEqualTo;
	private String sidx;
	private String sord;
	public String getSidx(){
		if(this.sidx == null){
			return "";
		}
		else if("updateuser".equals(this.sidx)){
			return "updateuser";
		}
		else if("updatetime".equals(this.sidx)){
			return "updatetime";
		}
		else if("remark".equals(this.sidx)){
			return "remark";
		}
		else if("frwrRevenueType".equals(this.sidx)){
			return "frwr_revenue_type";
		}
		else if("frwrRevenueId".equals(this.sidx)){
			return "frwr_revenue_id";
		}
		else if("frwrMatchState".equals(this.sidx)){
			return "frwr_match_state";
		}
		else if("frwrId".equals(this.sidx)){
			return "frwr_id";
		}
		else if("frwrDescribe".equals(this.sidx)){
			return "frwr_describe";
		}
		else if("frwrBillId".equals(this.sidx)){
			return "frwr_bill_id";
		}
		else if("dr".equals(this.sidx)){
			return "dr";
		}
		else if("createuser".equals(this.sidx)){
			return "createuser";
		}
		else if("createtime".equals(this.sidx)){
			return "createtime";
		}
		return this.sidx;
	}

	@com.fasterxml.jackson.annotation.JsonIgnore
	public com.mrk.finance.example.FncRevenueWaterRecordExample getCrieria(){
		com.mrk.finance.example.FncRevenueWaterRecordExample q = new com.mrk.finance.example.FncRevenueWaterRecordExample();
		com.mrk.finance.example.FncRevenueWaterRecordExample.Criteria c = q.createCriteria();
		c.andDrEqualTo(0);
		if(CheckUtil.isNotEmpty(getUpdateuserNotLike())){
			c.andUpdateuserNotLike("%"+this.getUpdateuserNotLike()+"%");
		}
		if(CheckUtil.isNotEmpty(getUpdateuserNotIn())){
			c.andUpdateuserNotIn(this.getUpdateuserNotIn());
		}
		if(CheckUtil.isNotEmpty(getUpdateuserNotEqualTo())){
			c.andUpdateuserNotEqualTo(this.getUpdateuserNotEqualTo());
		}
		if(CheckUtil.isNotEmpty(getUpdateuserLike())){
			c.andUpdateuserLike("%"+this.getUpdateuserLike()+"%");
		}
		if(CheckUtil.isNotEmpty(getUpdateuserLessThanOrEqualTo())){
			c.andUpdateuserLessThanOrEqualTo(this.getUpdateuserLessThanOrEqualTo());
		}
		if(CheckUtil.isNotEmpty(getUpdateuserLessThan())){
			c.andUpdateuserLessThan(this.getUpdateuserLessThan());
		}
		if(CheckUtil.isNotEmpty(getUpdateuserIsNull()) && this.getUpdateuserIsNull()){
			c.andUpdateuserIsNull();
		}
		if(CheckUtil.isNotEmpty(getUpdateuserIsNotNull()) && this.getUpdateuserIsNotNull()){
			c.andUpdateuserIsNotNull();
		}
		if(CheckUtil.isNotEmpty(getUpdateuserIn())){
			c.andUpdateuserIn(this.getUpdateuserIn());
		}
		if(CheckUtil.isNotEmpty(getUpdateuserGreaterThanOrEqualTo())){
			c.andUpdateuserGreaterThanOrEqualTo(this.getUpdateuserGreaterThanOrEqualTo());
		}
		if(CheckUtil.isNotEmpty(getUpdateuserGreaterThan())){
			c.andUpdateuserGreaterThan(this.getUpdateuserGreaterThan());
		}
		if(CheckUtil.isNotEmpty(getUpdateuserEqualTo())){
			c.andUpdateuserEqualTo(this.getUpdateuserEqualTo());
		}
		if(CheckUtil.isNotEmpty(getUpdatetimeNotIn())){
			c.andUpdatetimeNotIn(this.getUpdatetimeNotIn());
		}
		if(CheckUtil.isNotEmpty(getUpdatetimeNotEqualTo())){
			c.andUpdatetimeNotEqualTo(this.getUpdatetimeNotEqualTo());
		}
		if(CheckUtil.isNotEmpty(getUpdatetimeLessThanOrEqualTo())){
			c.andUpdatetimeLessThanOrEqualTo(this.getUpdatetimeLessThanOrEqualTo());
		}
		if(CheckUtil.isNotEmpty(getUpdatetimeLessThan())){
			c.andUpdatetimeLessThan(this.getUpdatetimeLessThan());
		}
		if(CheckUtil.isNotEmpty(getUpdatetimeIsNull()) && this.getUpdatetimeIsNull()){
			c.andUpdatetimeIsNull();
		}
		if(CheckUtil.isNotEmpty(getUpdatetimeIsNotNull()) && this.getUpdatetimeIsNotNull()){
			c.andUpdatetimeIsNotNull();
		}
		if(CheckUtil.isNotEmpty(getUpdatetimeIn())){
			c.andUpdatetimeIn(this.getUpdatetimeIn());
		}
		if(CheckUtil.isNotEmpty(getUpdatetimeGreaterThanOrEqualTo())){
			c.andUpdatetimeGreaterThanOrEqualTo(this.getUpdatetimeGreaterThanOrEqualTo());
		}
		if(CheckUtil.isNotEmpty(getUpdatetimeGreaterThan())){
			c.andUpdatetimeGreaterThan(this.getUpdatetimeGreaterThan());
		}
		if(CheckUtil.isNotEmpty(getUpdatetimeEqualTo())){
			c.andUpdatetimeEqualTo(this.getUpdatetimeEqualTo());
		}
		if(CheckUtil.isNotEmpty(getRemarkNotLike())){
			c.andRemarkNotLike("%"+this.getRemarkNotLike()+"%");
		}
		if(CheckUtil.isNotEmpty(getRemarkNotIn())){
			c.andRemarkNotIn(this.getRemarkNotIn());
		}
		if(CheckUtil.isNotEmpty(getRemarkNotEqualTo())){
			c.andRemarkNotEqualTo(this.getRemarkNotEqualTo());
		}
		if(CheckUtil.isNotEmpty(getRemarkLike())){
			c.andRemarkLike("%"+this.getRemarkLike()+"%");
		}
		if(CheckUtil.isNotEmpty(getRemarkLessThanOrEqualTo())){
			c.andRemarkLessThanOrEqualTo(this.getRemarkLessThanOrEqualTo());
		}
		if(CheckUtil.isNotEmpty(getRemarkLessThan())){
			c.andRemarkLessThan(this.getRemarkLessThan());
		}
		if(CheckUtil.isNotEmpty(getRemarkIsNull()) && this.getRemarkIsNull()){
			c.andRemarkIsNull();
		}
		if(CheckUtil.isNotEmpty(getRemarkIsNotNull()) && this.getRemarkIsNotNull()){
			c.andRemarkIsNotNull();
		}
		if(CheckUtil.isNotEmpty(getRemarkIn())){
			c.andRemarkIn(this.getRemarkIn());
		}
		if(CheckUtil.isNotEmpty(getRemarkGreaterThanOrEqualTo())){
			c.andRemarkGreaterThanOrEqualTo(this.getRemarkGreaterThanOrEqualTo());
		}
		if(CheckUtil.isNotEmpty(getRemarkGreaterThan())){
			c.andRemarkGreaterThan(this.getRemarkGreaterThan());
		}
		if(CheckUtil.isNotEmpty(getRemarkEqualTo())){
			c.andRemarkEqualTo(this.getRemarkEqualTo());
		}
		if(CheckUtil.isNotEmpty(getFrwrRevenueTypeNotIn())){
			c.andFrwrRevenueTypeNotIn(this.getFrwrRevenueTypeNotIn());
		}
		if(CheckUtil.isNotEmpty(getFrwrRevenueTypeNotEqualTo())){
			c.andFrwrRevenueTypeNotEqualTo(this.getFrwrRevenueTypeNotEqualTo());
		}
		if(CheckUtil.isNotEmpty(getFrwrRevenueTypeLessThanOrEqualTo())){
			c.andFrwrRevenueTypeLessThanOrEqualTo(this.getFrwrRevenueTypeLessThanOrEqualTo());
		}
		if(CheckUtil.isNotEmpty(getFrwrRevenueTypeLessThan())){
			c.andFrwrRevenueTypeLessThan(this.getFrwrRevenueTypeLessThan());
		}
		if(CheckUtil.isNotEmpty(getFrwrRevenueTypeIsNull()) && this.getFrwrRevenueTypeIsNull()){
			c.andFrwrRevenueTypeIsNull();
		}
		if(CheckUtil.isNotEmpty(getFrwrRevenueTypeIsNotNull()) && this.getFrwrRevenueTypeIsNotNull()){
			c.andFrwrRevenueTypeIsNotNull();
		}
		if(CheckUtil.isNotEmpty(getFrwrRevenueTypeIn())){
			c.andFrwrRevenueTypeIn(this.getFrwrRevenueTypeIn());
		}
		if(CheckUtil.isNotEmpty(getFrwrRevenueTypeGreaterThanOrEqualTo())){
			c.andFrwrRevenueTypeGreaterThanOrEqualTo(this.getFrwrRevenueTypeGreaterThanOrEqualTo());
		}
		if(CheckUtil.isNotEmpty(getFrwrRevenueTypeGreaterThan())){
			c.andFrwrRevenueTypeGreaterThan(this.getFrwrRevenueTypeGreaterThan());
		}
		if(CheckUtil.isNotEmpty(getFrwrRevenueTypeEqualTo())){
			c.andFrwrRevenueTypeEqualTo(this.getFrwrRevenueTypeEqualTo());
		}
		if(CheckUtil.isNotEmpty(getFrwrRevenueIdNotIn())){
			c.andFrwrRevenueIdNotIn(this.getFrwrRevenueIdNotIn());
		}
		if(CheckUtil.isNotEmpty(getFrwrRevenueIdNotEqualTo())){
			c.andFrwrRevenueIdNotEqualTo(this.getFrwrRevenueIdNotEqualTo());
		}
		if(CheckUtil.isNotEmpty(getFrwrRevenueIdLessThanOrEqualTo())){
			c.andFrwrRevenueIdLessThanOrEqualTo(this.getFrwrRevenueIdLessThanOrEqualTo());
		}
		if(CheckUtil.isNotEmpty(getFrwrRevenueIdLessThan())){
			c.andFrwrRevenueIdLessThan(this.getFrwrRevenueIdLessThan());
		}
		if(CheckUtil.isNotEmpty(getFrwrRevenueIdIsNull()) && this.getFrwrRevenueIdIsNull()){
			c.andFrwrRevenueIdIsNull();
		}
		if(CheckUtil.isNotEmpty(getFrwrRevenueIdIsNotNull()) && this.getFrwrRevenueIdIsNotNull()){
			c.andFrwrRevenueIdIsNotNull();
		}
		if(CheckUtil.isNotEmpty(getFrwrRevenueIdIn())){
			c.andFrwrRevenueIdIn(this.getFrwrRevenueIdIn());
		}
		if(CheckUtil.isNotEmpty(getFrwrRevenueIdGreaterThanOrEqualTo())){
			c.andFrwrRevenueIdGreaterThanOrEqualTo(this.getFrwrRevenueIdGreaterThanOrEqualTo());
		}
		if(CheckUtil.isNotEmpty(getFrwrRevenueIdGreaterThan())){
			c.andFrwrRevenueIdGreaterThan(this.getFrwrRevenueIdGreaterThan());
		}
		if(CheckUtil.isNotEmpty(getFrwrRevenueIdEqualTo())){
			c.andFrwrRevenueIdEqualTo(this.getFrwrRevenueIdEqualTo());
		}
		if(CheckUtil.isNotEmpty(getFrwrMatchStateNotIn())){
			c.andFrwrMatchStateNotIn(this.getFrwrMatchStateNotIn());
		}
		if(CheckUtil.isNotEmpty(getFrwrMatchStateNotEqualTo())){
			c.andFrwrMatchStateNotEqualTo(this.getFrwrMatchStateNotEqualTo());
		}
		if(CheckUtil.isNotEmpty(getFrwrMatchStateLessThanOrEqualTo())){
			c.andFrwrMatchStateLessThanOrEqualTo(this.getFrwrMatchStateLessThanOrEqualTo());
		}
		if(CheckUtil.isNotEmpty(getFrwrMatchStateLessThan())){
			c.andFrwrMatchStateLessThan(this.getFrwrMatchStateLessThan());
		}
		if(CheckUtil.isNotEmpty(getFrwrMatchStateIsNull()) && this.getFrwrMatchStateIsNull()){
			c.andFrwrMatchStateIsNull();
		}
		if(CheckUtil.isNotEmpty(getFrwrMatchStateIsNotNull()) && this.getFrwrMatchStateIsNotNull()){
			c.andFrwrMatchStateIsNotNull();
		}
		if(CheckUtil.isNotEmpty(getFrwrMatchStateIn())){
			c.andFrwrMatchStateIn(this.getFrwrMatchStateIn());
		}
		if(CheckUtil.isNotEmpty(getFrwrMatchStateGreaterThanOrEqualTo())){
			c.andFrwrMatchStateGreaterThanOrEqualTo(this.getFrwrMatchStateGreaterThanOrEqualTo());
		}
		if(CheckUtil.isNotEmpty(getFrwrMatchStateGreaterThan())){
			c.andFrwrMatchStateGreaterThan(this.getFrwrMatchStateGreaterThan());
		}
		if(CheckUtil.isNotEmpty(getFrwrMatchStateEqualTo())){
			c.andFrwrMatchStateEqualTo(this.getFrwrMatchStateEqualTo());
		}
		if(CheckUtil.isNotEmpty(getFrwrIdNotIn())){
			c.andFrwrIdNotIn(this.getFrwrIdNotIn());
		}
		if(CheckUtil.isNotEmpty(getFrwrIdNotEqualTo())){
			c.andFrwrIdNotEqualTo(this.getFrwrIdNotEqualTo());
		}
		if(CheckUtil.isNotEmpty(getFrwrIdLessThanOrEqualTo())){
			c.andFrwrIdLessThanOrEqualTo(this.getFrwrIdLessThanOrEqualTo());
		}
		if(CheckUtil.isNotEmpty(getFrwrIdLessThan())){
			c.andFrwrIdLessThan(this.getFrwrIdLessThan());
		}
		if(CheckUtil.isNotEmpty(getFrwrIdIsNull()) && this.getFrwrIdIsNull()){
			c.andFrwrIdIsNull();
		}
		if(CheckUtil.isNotEmpty(getFrwrIdIsNotNull()) && this.getFrwrIdIsNotNull()){
			c.andFrwrIdIsNotNull();
		}
		if(CheckUtil.isNotEmpty(getFrwrIdIn())){
			c.andFrwrIdIn(this.getFrwrIdIn());
		}
		if(CheckUtil.isNotEmpty(getFrwrIdGreaterThanOrEqualTo())){
			c.andFrwrIdGreaterThanOrEqualTo(this.getFrwrIdGreaterThanOrEqualTo());
		}
		if(CheckUtil.isNotEmpty(getFrwrIdGreaterThan())){
			c.andFrwrIdGreaterThan(this.getFrwrIdGreaterThan());
		}
		if(CheckUtil.isNotEmpty(getFrwrIdEqualTo())){
			c.andFrwrIdEqualTo(this.getFrwrIdEqualTo());
		}
		if(CheckUtil.isNotEmpty(getFrwrDescribeNotLike())){
			c.andFrwrDescribeNotLike("%"+this.getFrwrDescribeNotLike()+"%");
		}
		if(CheckUtil.isNotEmpty(getFrwrDescribeNotIn())){
			c.andFrwrDescribeNotIn(this.getFrwrDescribeNotIn());
		}
		if(CheckUtil.isNotEmpty(getFrwrDescribeNotEqualTo())){
			c.andFrwrDescribeNotEqualTo(this.getFrwrDescribeNotEqualTo());
		}
		if(CheckUtil.isNotEmpty(getFrwrDescribeLike())){
			c.andFrwrDescribeLike("%"+this.getFrwrDescribeLike()+"%");
		}
		if(CheckUtil.isNotEmpty(getFrwrDescribeLessThanOrEqualTo())){
			c.andFrwrDescribeLessThanOrEqualTo(this.getFrwrDescribeLessThanOrEqualTo());
		}
		if(CheckUtil.isNotEmpty(getFrwrDescribeLessThan())){
			c.andFrwrDescribeLessThan(this.getFrwrDescribeLessThan());
		}
		if(CheckUtil.isNotEmpty(getFrwrDescribeIsNull()) && this.getFrwrDescribeIsNull()){
			c.andFrwrDescribeIsNull();
		}
		if(CheckUtil.isNotEmpty(getFrwrDescribeIsNotNull()) && this.getFrwrDescribeIsNotNull()){
			c.andFrwrDescribeIsNotNull();
		}
		if(CheckUtil.isNotEmpty(getFrwrDescribeIn())){
			c.andFrwrDescribeIn(this.getFrwrDescribeIn());
		}
		if(CheckUtil.isNotEmpty(getFrwrDescribeGreaterThanOrEqualTo())){
			c.andFrwrDescribeGreaterThanOrEqualTo(this.getFrwrDescribeGreaterThanOrEqualTo());
		}
		if(CheckUtil.isNotEmpty(getFrwrDescribeGreaterThan())){
			c.andFrwrDescribeGreaterThan(this.getFrwrDescribeGreaterThan());
		}
		if(CheckUtil.isNotEmpty(getFrwrDescribeEqualTo())){
			c.andFrwrDescribeEqualTo(this.getFrwrDescribeEqualTo());
		}
		if(CheckUtil.isNotEmpty(getFrwrBillIdNotIn())){
			c.andFrwrBillIdNotIn(this.getFrwrBillIdNotIn());
		}
		if(CheckUtil.isNotEmpty(getFrwrBillIdNotEqualTo())){
			c.andFrwrBillIdNotEqualTo(this.getFrwrBillIdNotEqualTo());
		}
		if(CheckUtil.isNotEmpty(getFrwrBillIdLessThanOrEqualTo())){
			c.andFrwrBillIdLessThanOrEqualTo(this.getFrwrBillIdLessThanOrEqualTo());
		}
		if(CheckUtil.isNotEmpty(getFrwrBillIdLessThan())){
			c.andFrwrBillIdLessThan(this.getFrwrBillIdLessThan());
		}
		if(CheckUtil.isNotEmpty(getFrwrBillIdIsNull()) && this.getFrwrBillIdIsNull()){
			c.andFrwrBillIdIsNull();
		}
		if(CheckUtil.isNotEmpty(getFrwrBillIdIsNotNull()) && this.getFrwrBillIdIsNotNull()){
			c.andFrwrBillIdIsNotNull();
		}
		if(CheckUtil.isNotEmpty(getFrwrBillIdIn())){
			c.andFrwrBillIdIn(this.getFrwrBillIdIn());
		}
		if(CheckUtil.isNotEmpty(getFrwrBillIdGreaterThanOrEqualTo())){
			c.andFrwrBillIdGreaterThanOrEqualTo(this.getFrwrBillIdGreaterThanOrEqualTo());
		}
		if(CheckUtil.isNotEmpty(getFrwrBillIdGreaterThan())){
			c.andFrwrBillIdGreaterThan(this.getFrwrBillIdGreaterThan());
		}
		if(CheckUtil.isNotEmpty(getFrwrBillIdEqualTo())){
			c.andFrwrBillIdEqualTo(this.getFrwrBillIdEqualTo());
		}
		if(CheckUtil.isNotEmpty(getDrNotIn())){
			c.andDrNotIn(this.getDrNotIn());
		}
		if(CheckUtil.isNotEmpty(getDrNotEqualTo())){
			c.andDrNotEqualTo(this.getDrNotEqualTo());
		}
		if(CheckUtil.isNotEmpty(getDrLessThanOrEqualTo())){
			c.andDrLessThanOrEqualTo(this.getDrLessThanOrEqualTo());
		}
		if(CheckUtil.isNotEmpty(getDrLessThan())){
			c.andDrLessThan(this.getDrLessThan());
		}
		if(CheckUtil.isNotEmpty(getDrIsNull()) && this.getDrIsNull()){
			c.andDrIsNull();
		}
		if(CheckUtil.isNotEmpty(getDrIsNotNull()) && this.getDrIsNotNull()){
			c.andDrIsNotNull();
		}
		if(CheckUtil.isNotEmpty(getDrIn())){
			c.andDrIn(this.getDrIn());
		}
		if(CheckUtil.isNotEmpty(getDrGreaterThanOrEqualTo())){
			c.andDrGreaterThanOrEqualTo(this.getDrGreaterThanOrEqualTo());
		}
		if(CheckUtil.isNotEmpty(getDrGreaterThan())){
			c.andDrGreaterThan(this.getDrGreaterThan());
		}
		if(CheckUtil.isNotEmpty(getDrEqualTo())){
			c.andDrEqualTo(this.getDrEqualTo());
		}
		if(CheckUtil.isNotEmpty(getCreateuserNotLike())){
			c.andCreateuserNotLike("%"+this.getCreateuserNotLike()+"%");
		}
		if(CheckUtil.isNotEmpty(getCreateuserNotIn())){
			c.andCreateuserNotIn(this.getCreateuserNotIn());
		}
		if(CheckUtil.isNotEmpty(getCreateuserNotEqualTo())){
			c.andCreateuserNotEqualTo(this.getCreateuserNotEqualTo());
		}
		if(CheckUtil.isNotEmpty(getCreateuserLike())){
			c.andCreateuserLike("%"+this.getCreateuserLike()+"%");
		}
		if(CheckUtil.isNotEmpty(getCreateuserLessThanOrEqualTo())){
			c.andCreateuserLessThanOrEqualTo(this.getCreateuserLessThanOrEqualTo());
		}
		if(CheckUtil.isNotEmpty(getCreateuserLessThan())){
			c.andCreateuserLessThan(this.getCreateuserLessThan());
		}
		if(CheckUtil.isNotEmpty(getCreateuserIsNull()) && this.getCreateuserIsNull()){
			c.andCreateuserIsNull();
		}
		if(CheckUtil.isNotEmpty(getCreateuserIsNotNull()) && this.getCreateuserIsNotNull()){
			c.andCreateuserIsNotNull();
		}
		if(CheckUtil.isNotEmpty(getCreateuserIn())){
			c.andCreateuserIn(this.getCreateuserIn());
		}
		if(CheckUtil.isNotEmpty(getCreateuserGreaterThanOrEqualTo())){
			c.andCreateuserGreaterThanOrEqualTo(this.getCreateuserGreaterThanOrEqualTo());
		}
		if(CheckUtil.isNotEmpty(getCreateuserGreaterThan())){
			c.andCreateuserGreaterThan(this.getCreateuserGreaterThan());
		}
		if(CheckUtil.isNotEmpty(getCreateuserEqualTo())){
			c.andCreateuserEqualTo(this.getCreateuserEqualTo());
		}
		if(CheckUtil.isNotEmpty(getCreatetimeNotIn())){
			c.andCreatetimeNotIn(this.getCreatetimeNotIn());
		}
		if(CheckUtil.isNotEmpty(getCreatetimeNotEqualTo())){
			c.andCreatetimeNotEqualTo(this.getCreatetimeNotEqualTo());
		}
		if(CheckUtil.isNotEmpty(getCreatetimeLessThanOrEqualTo())){
			c.andCreatetimeLessThanOrEqualTo(this.getCreatetimeLessThanOrEqualTo());
		}
		if(CheckUtil.isNotEmpty(getCreatetimeLessThan())){
			c.andCreatetimeLessThan(this.getCreatetimeLessThan());
		}
		if(CheckUtil.isNotEmpty(getCreatetimeIsNull()) && this.getCreatetimeIsNull()){
			c.andCreatetimeIsNull();
		}
		if(CheckUtil.isNotEmpty(getCreatetimeIsNotNull()) && this.getCreatetimeIsNotNull()){
			c.andCreatetimeIsNotNull();
		}
		if(CheckUtil.isNotEmpty(getCreatetimeIn())){
			c.andCreatetimeIn(this.getCreatetimeIn());
		}
		if(CheckUtil.isNotEmpty(getCreatetimeGreaterThanOrEqualTo())){
			c.andCreatetimeGreaterThanOrEqualTo(this.getCreatetimeGreaterThanOrEqualTo());
		}
		if(CheckUtil.isNotEmpty(getCreatetimeGreaterThan())){
			c.andCreatetimeGreaterThan(this.getCreatetimeGreaterThan());
		}
		if(CheckUtil.isNotEmpty(getCreatetimeEqualTo())){
			c.andCreatetimeEqualTo(this.getCreatetimeEqualTo());
		}
		if((this.getSidx()!=null && !this.getSidx().trim().equals("")) && this.getSord()!=null) {
			q.setOrderByClause(""+ this.getSidx()+" "+this.getSord());
		}
		return q;
	}
	public String getUpdateuserNotLike() {
		return updateuserNotLike;
	}
	public void setUpdateuserNotLike(String updateuserNotLike) {
		this.updateuserNotLike = updateuserNotLike;
	}

	public java.util.List getUpdateuserNotIn() {
		return updateuserNotIn;
	}
	public void setUpdateuserNotIn(java.util.List updateuserNotIn) {
		this.updateuserNotIn = updateuserNotIn;
	}

	public String getUpdateuserNotEqualTo() {
		return updateuserNotEqualTo;
	}
	public void setUpdateuserNotEqualTo(String updateuserNotEqualTo) {
		this.updateuserNotEqualTo = updateuserNotEqualTo;
	}

	public String getUpdateuserLike() {
		return updateuserLike;
	}
	public void setUpdateuserLike(String updateuserLike) {
		this.updateuserLike = updateuserLike;
	}

	public String getUpdateuserLessThanOrEqualTo() {
		return updateuserLessThanOrEqualTo;
	}
	public void setUpdateuserLessThanOrEqualTo(String updateuserLessThanOrEqualTo) {
		this.updateuserLessThanOrEqualTo = updateuserLessThanOrEqualTo;
	}

	public String getUpdateuserLessThan() {
		return updateuserLessThan;
	}
	public void setUpdateuserLessThan(String updateuserLessThan) {
		this.updateuserLessThan = updateuserLessThan;
	}

	public Boolean getUpdateuserIsNull() {
		return updateuserIsNull;
	}
	public void setUpdateuserIsNull(Boolean updateuserIsNull) {
		this.updateuserIsNull = updateuserIsNull;
	}

	public Boolean getUpdateuserIsNotNull() {
		return updateuserIsNotNull;
	}
	public void setUpdateuserIsNotNull(Boolean updateuserIsNotNull) {
		this.updateuserIsNotNull = updateuserIsNotNull;
	}

	public java.util.List getUpdateuserIn() {
		return updateuserIn;
	}
	public void setUpdateuserIn(java.util.List updateuserIn) {
		this.updateuserIn = updateuserIn;
	}

	public String getUpdateuserGreaterThanOrEqualTo() {
		return updateuserGreaterThanOrEqualTo;
	}
	public void setUpdateuserGreaterThanOrEqualTo(String updateuserGreaterThanOrEqualTo) {
		this.updateuserGreaterThanOrEqualTo = updateuserGreaterThanOrEqualTo;
	}

	public String getUpdateuserGreaterThan() {
		return updateuserGreaterThan;
	}
	public void setUpdateuserGreaterThan(String updateuserGreaterThan) {
		this.updateuserGreaterThan = updateuserGreaterThan;
	}

	public String getUpdateuserEqualTo() {
		return updateuserEqualTo;
	}
	public void setUpdateuserEqualTo(String updateuserEqualTo) {
		this.updateuserEqualTo = updateuserEqualTo;
	}

	public java.util.List getUpdatetimeNotIn() {
		return updatetimeNotIn;
	}
	public void setUpdatetimeNotIn(java.util.List updatetimeNotIn) {
		this.updatetimeNotIn = updatetimeNotIn;
	}

	public java.util.Date getUpdatetimeNotEqualTo() {
		return updatetimeNotEqualTo;
	}
	public void setUpdatetimeNotEqualTo(java.util.Date updatetimeNotEqualTo) {
		this.updatetimeNotEqualTo = updatetimeNotEqualTo;
	}

	public java.util.Date getUpdatetimeLessThanOrEqualTo() {
		return updatetimeLessThanOrEqualTo;
	}
	public void setUpdatetimeLessThanOrEqualTo(java.util.Date updatetimeLessThanOrEqualTo) {
		this.updatetimeLessThanOrEqualTo = updatetimeLessThanOrEqualTo;
	}

	public java.util.Date getUpdatetimeLessThan() {
		return updatetimeLessThan;
	}
	public void setUpdatetimeLessThan(java.util.Date updatetimeLessThan) {
		this.updatetimeLessThan = updatetimeLessThan;
	}

	public Boolean getUpdatetimeIsNull() {
		return updatetimeIsNull;
	}
	public void setUpdatetimeIsNull(Boolean updatetimeIsNull) {
		this.updatetimeIsNull = updatetimeIsNull;
	}

	public Boolean getUpdatetimeIsNotNull() {
		return updatetimeIsNotNull;
	}
	public void setUpdatetimeIsNotNull(Boolean updatetimeIsNotNull) {
		this.updatetimeIsNotNull = updatetimeIsNotNull;
	}

	public java.util.List getUpdatetimeIn() {
		return updatetimeIn;
	}
	public void setUpdatetimeIn(java.util.List updatetimeIn) {
		this.updatetimeIn = updatetimeIn;
	}

	public java.util.Date getUpdatetimeGreaterThanOrEqualTo() {
		return updatetimeGreaterThanOrEqualTo;
	}
	public void setUpdatetimeGreaterThanOrEqualTo(java.util.Date updatetimeGreaterThanOrEqualTo) {
		this.updatetimeGreaterThanOrEqualTo = updatetimeGreaterThanOrEqualTo;
	}

	public java.util.Date getUpdatetimeGreaterThan() {
		return updatetimeGreaterThan;
	}
	public void setUpdatetimeGreaterThan(java.util.Date updatetimeGreaterThan) {
		this.updatetimeGreaterThan = updatetimeGreaterThan;
	}

	public java.util.Date getUpdatetimeEqualTo() {
		return updatetimeEqualTo;
	}
	public void setUpdatetimeEqualTo(java.util.Date updatetimeEqualTo) {
		this.updatetimeEqualTo = updatetimeEqualTo;
	}

	public String getRemarkNotLike() {
		return remarkNotLike;
	}
	public void setRemarkNotLike(String remarkNotLike) {
		this.remarkNotLike = remarkNotLike;
	}

	public java.util.List getRemarkNotIn() {
		return remarkNotIn;
	}
	public void setRemarkNotIn(java.util.List remarkNotIn) {
		this.remarkNotIn = remarkNotIn;
	}

	public String getRemarkNotEqualTo() {
		return remarkNotEqualTo;
	}
	public void setRemarkNotEqualTo(String remarkNotEqualTo) {
		this.remarkNotEqualTo = remarkNotEqualTo;
	}

	public String getRemarkLike() {
		return remarkLike;
	}
	public void setRemarkLike(String remarkLike) {
		this.remarkLike = remarkLike;
	}

	public String getRemarkLessThanOrEqualTo() {
		return remarkLessThanOrEqualTo;
	}
	public void setRemarkLessThanOrEqualTo(String remarkLessThanOrEqualTo) {
		this.remarkLessThanOrEqualTo = remarkLessThanOrEqualTo;
	}

	public String getRemarkLessThan() {
		return remarkLessThan;
	}
	public void setRemarkLessThan(String remarkLessThan) {
		this.remarkLessThan = remarkLessThan;
	}

	public Boolean getRemarkIsNull() {
		return remarkIsNull;
	}
	public void setRemarkIsNull(Boolean remarkIsNull) {
		this.remarkIsNull = remarkIsNull;
	}

	public Boolean getRemarkIsNotNull() {
		return remarkIsNotNull;
	}
	public void setRemarkIsNotNull(Boolean remarkIsNotNull) {
		this.remarkIsNotNull = remarkIsNotNull;
	}

	public java.util.List getRemarkIn() {
		return remarkIn;
	}
	public void setRemarkIn(java.util.List remarkIn) {
		this.remarkIn = remarkIn;
	}

	public String getRemarkGreaterThanOrEqualTo() {
		return remarkGreaterThanOrEqualTo;
	}
	public void setRemarkGreaterThanOrEqualTo(String remarkGreaterThanOrEqualTo) {
		this.remarkGreaterThanOrEqualTo = remarkGreaterThanOrEqualTo;
	}

	public String getRemarkGreaterThan() {
		return remarkGreaterThan;
	}
	public void setRemarkGreaterThan(String remarkGreaterThan) {
		this.remarkGreaterThan = remarkGreaterThan;
	}

	public String getRemarkEqualTo() {
		return remarkEqualTo;
	}
	public void setRemarkEqualTo(String remarkEqualTo) {
		this.remarkEqualTo = remarkEqualTo;
	}

	public java.util.List getFrwrRevenueTypeNotIn() {
		return frwrRevenueTypeNotIn;
	}
	public void setFrwrRevenueTypeNotIn(java.util.List frwrRevenueTypeNotIn) {
		this.frwrRevenueTypeNotIn = frwrRevenueTypeNotIn;
	}

	public Integer getFrwrRevenueTypeNotEqualTo() {
		return frwrRevenueTypeNotEqualTo;
	}
	public void setFrwrRevenueTypeNotEqualTo(Integer frwrRevenueTypeNotEqualTo) {
		this.frwrRevenueTypeNotEqualTo = frwrRevenueTypeNotEqualTo;
	}

	public Integer getFrwrRevenueTypeLessThanOrEqualTo() {
		return frwrRevenueTypeLessThanOrEqualTo;
	}
	public void setFrwrRevenueTypeLessThanOrEqualTo(Integer frwrRevenueTypeLessThanOrEqualTo) {
		this.frwrRevenueTypeLessThanOrEqualTo = frwrRevenueTypeLessThanOrEqualTo;
	}

	public Integer getFrwrRevenueTypeLessThan() {
		return frwrRevenueTypeLessThan;
	}
	public void setFrwrRevenueTypeLessThan(Integer frwrRevenueTypeLessThan) {
		this.frwrRevenueTypeLessThan = frwrRevenueTypeLessThan;
	}

	public Boolean getFrwrRevenueTypeIsNull() {
		return frwrRevenueTypeIsNull;
	}
	public void setFrwrRevenueTypeIsNull(Boolean frwrRevenueTypeIsNull) {
		this.frwrRevenueTypeIsNull = frwrRevenueTypeIsNull;
	}

	public Boolean getFrwrRevenueTypeIsNotNull() {
		return frwrRevenueTypeIsNotNull;
	}
	public void setFrwrRevenueTypeIsNotNull(Boolean frwrRevenueTypeIsNotNull) {
		this.frwrRevenueTypeIsNotNull = frwrRevenueTypeIsNotNull;
	}

	public java.util.List getFrwrRevenueTypeIn() {
		return frwrRevenueTypeIn;
	}
	public void setFrwrRevenueTypeIn(java.util.List frwrRevenueTypeIn) {
		this.frwrRevenueTypeIn = frwrRevenueTypeIn;
	}

	public Integer getFrwrRevenueTypeGreaterThanOrEqualTo() {
		return frwrRevenueTypeGreaterThanOrEqualTo;
	}
	public void setFrwrRevenueTypeGreaterThanOrEqualTo(Integer frwrRevenueTypeGreaterThanOrEqualTo) {
		this.frwrRevenueTypeGreaterThanOrEqualTo = frwrRevenueTypeGreaterThanOrEqualTo;
	}

	public Integer getFrwrRevenueTypeGreaterThan() {
		return frwrRevenueTypeGreaterThan;
	}
	public void setFrwrRevenueTypeGreaterThan(Integer frwrRevenueTypeGreaterThan) {
		this.frwrRevenueTypeGreaterThan = frwrRevenueTypeGreaterThan;
	}

	public Integer getFrwrRevenueTypeEqualTo() {
		return frwrRevenueTypeEqualTo;
	}
	public void setFrwrRevenueTypeEqualTo(Integer frwrRevenueTypeEqualTo) {
		this.frwrRevenueTypeEqualTo = frwrRevenueTypeEqualTo;
	}

	public java.util.List getFrwrRevenueIdNotIn() {
		return frwrRevenueIdNotIn;
	}
	public void setFrwrRevenueIdNotIn(java.util.List frwrRevenueIdNotIn) {
		this.frwrRevenueIdNotIn = frwrRevenueIdNotIn;
	}

	public Long getFrwrRevenueIdNotEqualTo() {
		return frwrRevenueIdNotEqualTo;
	}
	public void setFrwrRevenueIdNotEqualTo(Long frwrRevenueIdNotEqualTo) {
		this.frwrRevenueIdNotEqualTo = frwrRevenueIdNotEqualTo;
	}

	public Long getFrwrRevenueIdLessThanOrEqualTo() {
		return frwrRevenueIdLessThanOrEqualTo;
	}
	public void setFrwrRevenueIdLessThanOrEqualTo(Long frwrRevenueIdLessThanOrEqualTo) {
		this.frwrRevenueIdLessThanOrEqualTo = frwrRevenueIdLessThanOrEqualTo;
	}

	public Long getFrwrRevenueIdLessThan() {
		return frwrRevenueIdLessThan;
	}
	public void setFrwrRevenueIdLessThan(Long frwrRevenueIdLessThan) {
		this.frwrRevenueIdLessThan = frwrRevenueIdLessThan;
	}

	public Boolean getFrwrRevenueIdIsNull() {
		return frwrRevenueIdIsNull;
	}
	public void setFrwrRevenueIdIsNull(Boolean frwrRevenueIdIsNull) {
		this.frwrRevenueIdIsNull = frwrRevenueIdIsNull;
	}

	public Boolean getFrwrRevenueIdIsNotNull() {
		return frwrRevenueIdIsNotNull;
	}
	public void setFrwrRevenueIdIsNotNull(Boolean frwrRevenueIdIsNotNull) {
		this.frwrRevenueIdIsNotNull = frwrRevenueIdIsNotNull;
	}

	public java.util.List getFrwrRevenueIdIn() {
		return frwrRevenueIdIn;
	}
	public void setFrwrRevenueIdIn(java.util.List frwrRevenueIdIn) {
		this.frwrRevenueIdIn = frwrRevenueIdIn;
	}

	public Long getFrwrRevenueIdGreaterThanOrEqualTo() {
		return frwrRevenueIdGreaterThanOrEqualTo;
	}
	public void setFrwrRevenueIdGreaterThanOrEqualTo(Long frwrRevenueIdGreaterThanOrEqualTo) {
		this.frwrRevenueIdGreaterThanOrEqualTo = frwrRevenueIdGreaterThanOrEqualTo;
	}

	public Long getFrwrRevenueIdGreaterThan() {
		return frwrRevenueIdGreaterThan;
	}
	public void setFrwrRevenueIdGreaterThan(Long frwrRevenueIdGreaterThan) {
		this.frwrRevenueIdGreaterThan = frwrRevenueIdGreaterThan;
	}

	public Long getFrwrRevenueIdEqualTo() {
		return frwrRevenueIdEqualTo;
	}
	public void setFrwrRevenueIdEqualTo(Long frwrRevenueIdEqualTo) {
		this.frwrRevenueIdEqualTo = frwrRevenueIdEqualTo;
	}

	public java.util.List getFrwrMatchStateNotIn() {
		return frwrMatchStateNotIn;
	}
	public void setFrwrMatchStateNotIn(java.util.List frwrMatchStateNotIn) {
		this.frwrMatchStateNotIn = frwrMatchStateNotIn;
	}

	public Integer getFrwrMatchStateNotEqualTo() {
		return frwrMatchStateNotEqualTo;
	}
	public void setFrwrMatchStateNotEqualTo(Integer frwrMatchStateNotEqualTo) {
		this.frwrMatchStateNotEqualTo = frwrMatchStateNotEqualTo;
	}

	public Integer getFrwrMatchStateLessThanOrEqualTo() {
		return frwrMatchStateLessThanOrEqualTo;
	}
	public void setFrwrMatchStateLessThanOrEqualTo(Integer frwrMatchStateLessThanOrEqualTo) {
		this.frwrMatchStateLessThanOrEqualTo = frwrMatchStateLessThanOrEqualTo;
	}

	public Integer getFrwrMatchStateLessThan() {
		return frwrMatchStateLessThan;
	}
	public void setFrwrMatchStateLessThan(Integer frwrMatchStateLessThan) {
		this.frwrMatchStateLessThan = frwrMatchStateLessThan;
	}

	public Boolean getFrwrMatchStateIsNull() {
		return frwrMatchStateIsNull;
	}
	public void setFrwrMatchStateIsNull(Boolean frwrMatchStateIsNull) {
		this.frwrMatchStateIsNull = frwrMatchStateIsNull;
	}

	public Boolean getFrwrMatchStateIsNotNull() {
		return frwrMatchStateIsNotNull;
	}
	public void setFrwrMatchStateIsNotNull(Boolean frwrMatchStateIsNotNull) {
		this.frwrMatchStateIsNotNull = frwrMatchStateIsNotNull;
	}

	public java.util.List getFrwrMatchStateIn() {
		return frwrMatchStateIn;
	}
	public void setFrwrMatchStateIn(java.util.List frwrMatchStateIn) {
		this.frwrMatchStateIn = frwrMatchStateIn;
	}

	public Integer getFrwrMatchStateGreaterThanOrEqualTo() {
		return frwrMatchStateGreaterThanOrEqualTo;
	}
	public void setFrwrMatchStateGreaterThanOrEqualTo(Integer frwrMatchStateGreaterThanOrEqualTo) {
		this.frwrMatchStateGreaterThanOrEqualTo = frwrMatchStateGreaterThanOrEqualTo;
	}

	public Integer getFrwrMatchStateGreaterThan() {
		return frwrMatchStateGreaterThan;
	}
	public void setFrwrMatchStateGreaterThan(Integer frwrMatchStateGreaterThan) {
		this.frwrMatchStateGreaterThan = frwrMatchStateGreaterThan;
	}

	public Integer getFrwrMatchStateEqualTo() {
		return frwrMatchStateEqualTo;
	}
	public void setFrwrMatchStateEqualTo(Integer frwrMatchStateEqualTo) {
		this.frwrMatchStateEqualTo = frwrMatchStateEqualTo;
	}

	public java.util.List getFrwrIdNotIn() {
		return frwrIdNotIn;
	}
	public void setFrwrIdNotIn(java.util.List frwrIdNotIn) {
		this.frwrIdNotIn = frwrIdNotIn;
	}

	public Long getFrwrIdNotEqualTo() {
		return frwrIdNotEqualTo;
	}
	public void setFrwrIdNotEqualTo(Long frwrIdNotEqualTo) {
		this.frwrIdNotEqualTo = frwrIdNotEqualTo;
	}

	public Long getFrwrIdLessThanOrEqualTo() {
		return frwrIdLessThanOrEqualTo;
	}
	public void setFrwrIdLessThanOrEqualTo(Long frwrIdLessThanOrEqualTo) {
		this.frwrIdLessThanOrEqualTo = frwrIdLessThanOrEqualTo;
	}

	public Long getFrwrIdLessThan() {
		return frwrIdLessThan;
	}
	public void setFrwrIdLessThan(Long frwrIdLessThan) {
		this.frwrIdLessThan = frwrIdLessThan;
	}

	public Boolean getFrwrIdIsNull() {
		return frwrIdIsNull;
	}
	public void setFrwrIdIsNull(Boolean frwrIdIsNull) {
		this.frwrIdIsNull = frwrIdIsNull;
	}

	public Boolean getFrwrIdIsNotNull() {
		return frwrIdIsNotNull;
	}
	public void setFrwrIdIsNotNull(Boolean frwrIdIsNotNull) {
		this.frwrIdIsNotNull = frwrIdIsNotNull;
	}

	public java.util.List getFrwrIdIn() {
		return frwrIdIn;
	}
	public void setFrwrIdIn(java.util.List frwrIdIn) {
		this.frwrIdIn = frwrIdIn;
	}

	public Long getFrwrIdGreaterThanOrEqualTo() {
		return frwrIdGreaterThanOrEqualTo;
	}
	public void setFrwrIdGreaterThanOrEqualTo(Long frwrIdGreaterThanOrEqualTo) {
		this.frwrIdGreaterThanOrEqualTo = frwrIdGreaterThanOrEqualTo;
	}

	public Long getFrwrIdGreaterThan() {
		return frwrIdGreaterThan;
	}
	public void setFrwrIdGreaterThan(Long frwrIdGreaterThan) {
		this.frwrIdGreaterThan = frwrIdGreaterThan;
	}

	public Long getFrwrIdEqualTo() {
		return frwrIdEqualTo;
	}
	public void setFrwrIdEqualTo(Long frwrIdEqualTo) {
		this.frwrIdEqualTo = frwrIdEqualTo;
	}

	public String getFrwrDescribeNotLike() {
		return frwrDescribeNotLike;
	}
	public void setFrwrDescribeNotLike(String frwrDescribeNotLike) {
		this.frwrDescribeNotLike = frwrDescribeNotLike;
	}

	public java.util.List getFrwrDescribeNotIn() {
		return frwrDescribeNotIn;
	}
	public void setFrwrDescribeNotIn(java.util.List frwrDescribeNotIn) {
		this.frwrDescribeNotIn = frwrDescribeNotIn;
	}

	public String getFrwrDescribeNotEqualTo() {
		return frwrDescribeNotEqualTo;
	}
	public void setFrwrDescribeNotEqualTo(String frwrDescribeNotEqualTo) {
		this.frwrDescribeNotEqualTo = frwrDescribeNotEqualTo;
	}

	public String getFrwrDescribeLike() {
		return frwrDescribeLike;
	}
	public void setFrwrDescribeLike(String frwrDescribeLike) {
		this.frwrDescribeLike = frwrDescribeLike;
	}

	public String getFrwrDescribeLessThanOrEqualTo() {
		return frwrDescribeLessThanOrEqualTo;
	}
	public void setFrwrDescribeLessThanOrEqualTo(String frwrDescribeLessThanOrEqualTo) {
		this.frwrDescribeLessThanOrEqualTo = frwrDescribeLessThanOrEqualTo;
	}

	public String getFrwrDescribeLessThan() {
		return frwrDescribeLessThan;
	}
	public void setFrwrDescribeLessThan(String frwrDescribeLessThan) {
		this.frwrDescribeLessThan = frwrDescribeLessThan;
	}

	public Boolean getFrwrDescribeIsNull() {
		return frwrDescribeIsNull;
	}
	public void setFrwrDescribeIsNull(Boolean frwrDescribeIsNull) {
		this.frwrDescribeIsNull = frwrDescribeIsNull;
	}

	public Boolean getFrwrDescribeIsNotNull() {
		return frwrDescribeIsNotNull;
	}
	public void setFrwrDescribeIsNotNull(Boolean frwrDescribeIsNotNull) {
		this.frwrDescribeIsNotNull = frwrDescribeIsNotNull;
	}

	public java.util.List getFrwrDescribeIn() {
		return frwrDescribeIn;
	}
	public void setFrwrDescribeIn(java.util.List frwrDescribeIn) {
		this.frwrDescribeIn = frwrDescribeIn;
	}

	public String getFrwrDescribeGreaterThanOrEqualTo() {
		return frwrDescribeGreaterThanOrEqualTo;
	}
	public void setFrwrDescribeGreaterThanOrEqualTo(String frwrDescribeGreaterThanOrEqualTo) {
		this.frwrDescribeGreaterThanOrEqualTo = frwrDescribeGreaterThanOrEqualTo;
	}

	public String getFrwrDescribeGreaterThan() {
		return frwrDescribeGreaterThan;
	}
	public void setFrwrDescribeGreaterThan(String frwrDescribeGreaterThan) {
		this.frwrDescribeGreaterThan = frwrDescribeGreaterThan;
	}

	public String getFrwrDescribeEqualTo() {
		return frwrDescribeEqualTo;
	}
	public void setFrwrDescribeEqualTo(String frwrDescribeEqualTo) {
		this.frwrDescribeEqualTo = frwrDescribeEqualTo;
	}

	public java.util.List getFrwrBillIdNotIn() {
		return frwrBillIdNotIn;
	}
	public void setFrwrBillIdNotIn(java.util.List frwrBillIdNotIn) {
		this.frwrBillIdNotIn = frwrBillIdNotIn;
	}

	public Long getFrwrBillIdNotEqualTo() {
		return frwrBillIdNotEqualTo;
	}
	public void setFrwrBillIdNotEqualTo(Long frwrBillIdNotEqualTo) {
		this.frwrBillIdNotEqualTo = frwrBillIdNotEqualTo;
	}

	public Long getFrwrBillIdLessThanOrEqualTo() {
		return frwrBillIdLessThanOrEqualTo;
	}
	public void setFrwrBillIdLessThanOrEqualTo(Long frwrBillIdLessThanOrEqualTo) {
		this.frwrBillIdLessThanOrEqualTo = frwrBillIdLessThanOrEqualTo;
	}

	public Long getFrwrBillIdLessThan() {
		return frwrBillIdLessThan;
	}
	public void setFrwrBillIdLessThan(Long frwrBillIdLessThan) {
		this.frwrBillIdLessThan = frwrBillIdLessThan;
	}

	public Boolean getFrwrBillIdIsNull() {
		return frwrBillIdIsNull;
	}
	public void setFrwrBillIdIsNull(Boolean frwrBillIdIsNull) {
		this.frwrBillIdIsNull = frwrBillIdIsNull;
	}

	public Boolean getFrwrBillIdIsNotNull() {
		return frwrBillIdIsNotNull;
	}
	public void setFrwrBillIdIsNotNull(Boolean frwrBillIdIsNotNull) {
		this.frwrBillIdIsNotNull = frwrBillIdIsNotNull;
	}

	public java.util.List getFrwrBillIdIn() {
		return frwrBillIdIn;
	}
	public void setFrwrBillIdIn(java.util.List frwrBillIdIn) {
		this.frwrBillIdIn = frwrBillIdIn;
	}

	public Long getFrwrBillIdGreaterThanOrEqualTo() {
		return frwrBillIdGreaterThanOrEqualTo;
	}
	public void setFrwrBillIdGreaterThanOrEqualTo(Long frwrBillIdGreaterThanOrEqualTo) {
		this.frwrBillIdGreaterThanOrEqualTo = frwrBillIdGreaterThanOrEqualTo;
	}

	public Long getFrwrBillIdGreaterThan() {
		return frwrBillIdGreaterThan;
	}
	public void setFrwrBillIdGreaterThan(Long frwrBillIdGreaterThan) {
		this.frwrBillIdGreaterThan = frwrBillIdGreaterThan;
	}

	public Long getFrwrBillIdEqualTo() {
		return frwrBillIdEqualTo;
	}
	public void setFrwrBillIdEqualTo(Long frwrBillIdEqualTo) {
		this.frwrBillIdEqualTo = frwrBillIdEqualTo;
	}

	public java.util.List getDrNotIn() {
		return drNotIn;
	}
	public void setDrNotIn(java.util.List drNotIn) {
		this.drNotIn = drNotIn;
	}

	public Integer getDrNotEqualTo() {
		return drNotEqualTo;
	}
	public void setDrNotEqualTo(Integer drNotEqualTo) {
		this.drNotEqualTo = drNotEqualTo;
	}

	public Integer getDrLessThanOrEqualTo() {
		return drLessThanOrEqualTo;
	}
	public void setDrLessThanOrEqualTo(Integer drLessThanOrEqualTo) {
		this.drLessThanOrEqualTo = drLessThanOrEqualTo;
	}

	public Integer getDrLessThan() {
		return drLessThan;
	}
	public void setDrLessThan(Integer drLessThan) {
		this.drLessThan = drLessThan;
	}

	public Boolean getDrIsNull() {
		return drIsNull;
	}
	public void setDrIsNull(Boolean drIsNull) {
		this.drIsNull = drIsNull;
	}

	public Boolean getDrIsNotNull() {
		return drIsNotNull;
	}
	public void setDrIsNotNull(Boolean drIsNotNull) {
		this.drIsNotNull = drIsNotNull;
	}

	public java.util.List getDrIn() {
		return drIn;
	}
	public void setDrIn(java.util.List drIn) {
		this.drIn = drIn;
	}

	public Integer getDrGreaterThanOrEqualTo() {
		return drGreaterThanOrEqualTo;
	}
	public void setDrGreaterThanOrEqualTo(Integer drGreaterThanOrEqualTo) {
		this.drGreaterThanOrEqualTo = drGreaterThanOrEqualTo;
	}

	public Integer getDrGreaterThan() {
		return drGreaterThan;
	}
	public void setDrGreaterThan(Integer drGreaterThan) {
		this.drGreaterThan = drGreaterThan;
	}

	public Integer getDrEqualTo() {
		return drEqualTo;
	}
	public void setDrEqualTo(Integer drEqualTo) {
		this.drEqualTo = drEqualTo;
	}

	public String getCreateuserNotLike() {
		return createuserNotLike;
	}
	public void setCreateuserNotLike(String createuserNotLike) {
		this.createuserNotLike = createuserNotLike;
	}

	public java.util.List getCreateuserNotIn() {
		return createuserNotIn;
	}
	public void setCreateuserNotIn(java.util.List createuserNotIn) {
		this.createuserNotIn = createuserNotIn;
	}

	public String getCreateuserNotEqualTo() {
		return createuserNotEqualTo;
	}
	public void setCreateuserNotEqualTo(String createuserNotEqualTo) {
		this.createuserNotEqualTo = createuserNotEqualTo;
	}

	public String getCreateuserLike() {
		return createuserLike;
	}
	public void setCreateuserLike(String createuserLike) {
		this.createuserLike = createuserLike;
	}

	public String getCreateuserLessThanOrEqualTo() {
		return createuserLessThanOrEqualTo;
	}
	public void setCreateuserLessThanOrEqualTo(String createuserLessThanOrEqualTo) {
		this.createuserLessThanOrEqualTo = createuserLessThanOrEqualTo;
	}

	public String getCreateuserLessThan() {
		return createuserLessThan;
	}
	public void setCreateuserLessThan(String createuserLessThan) {
		this.createuserLessThan = createuserLessThan;
	}

	public Boolean getCreateuserIsNull() {
		return createuserIsNull;
	}
	public void setCreateuserIsNull(Boolean createuserIsNull) {
		this.createuserIsNull = createuserIsNull;
	}

	public Boolean getCreateuserIsNotNull() {
		return createuserIsNotNull;
	}
	public void setCreateuserIsNotNull(Boolean createuserIsNotNull) {
		this.createuserIsNotNull = createuserIsNotNull;
	}

	public java.util.List getCreateuserIn() {
		return createuserIn;
	}
	public void setCreateuserIn(java.util.List createuserIn) {
		this.createuserIn = createuserIn;
	}

	public String getCreateuserGreaterThanOrEqualTo() {
		return createuserGreaterThanOrEqualTo;
	}
	public void setCreateuserGreaterThanOrEqualTo(String createuserGreaterThanOrEqualTo) {
		this.createuserGreaterThanOrEqualTo = createuserGreaterThanOrEqualTo;
	}

	public String getCreateuserGreaterThan() {
		return createuserGreaterThan;
	}
	public void setCreateuserGreaterThan(String createuserGreaterThan) {
		this.createuserGreaterThan = createuserGreaterThan;
	}

	public String getCreateuserEqualTo() {
		return createuserEqualTo;
	}
	public void setCreateuserEqualTo(String createuserEqualTo) {
		this.createuserEqualTo = createuserEqualTo;
	}

	public java.util.List getCreatetimeNotIn() {
		return createtimeNotIn;
	}
	public void setCreatetimeNotIn(java.util.List createtimeNotIn) {
		this.createtimeNotIn = createtimeNotIn;
	}

	public java.util.Date getCreatetimeNotEqualTo() {
		return createtimeNotEqualTo;
	}
	public void setCreatetimeNotEqualTo(java.util.Date createtimeNotEqualTo) {
		this.createtimeNotEqualTo = createtimeNotEqualTo;
	}

	public java.util.Date getCreatetimeLessThanOrEqualTo() {
		return createtimeLessThanOrEqualTo;
	}
	public void setCreatetimeLessThanOrEqualTo(java.util.Date createtimeLessThanOrEqualTo) {
		this.createtimeLessThanOrEqualTo = createtimeLessThanOrEqualTo;
	}

	public java.util.Date getCreatetimeLessThan() {
		return createtimeLessThan;
	}
	public void setCreatetimeLessThan(java.util.Date createtimeLessThan) {
		this.createtimeLessThan = createtimeLessThan;
	}

	public Boolean getCreatetimeIsNull() {
		return createtimeIsNull;
	}
	public void setCreatetimeIsNull(Boolean createtimeIsNull) {
		this.createtimeIsNull = createtimeIsNull;
	}

	public Boolean getCreatetimeIsNotNull() {
		return createtimeIsNotNull;
	}
	public void setCreatetimeIsNotNull(Boolean createtimeIsNotNull) {
		this.createtimeIsNotNull = createtimeIsNotNull;
	}

	public java.util.List getCreatetimeIn() {
		return createtimeIn;
	}
	public void setCreatetimeIn(java.util.List createtimeIn) {
		this.createtimeIn = createtimeIn;
	}

	public java.util.Date getCreatetimeGreaterThanOrEqualTo() {
		return createtimeGreaterThanOrEqualTo;
	}
	public void setCreatetimeGreaterThanOrEqualTo(java.util.Date createtimeGreaterThanOrEqualTo) {
		this.createtimeGreaterThanOrEqualTo = createtimeGreaterThanOrEqualTo;
	}

	public java.util.Date getCreatetimeGreaterThan() {
		return createtimeGreaterThan;
	}
	public void setCreatetimeGreaterThan(java.util.Date createtimeGreaterThan) {
		this.createtimeGreaterThan = createtimeGreaterThan;
	}

	public java.util.Date getCreatetimeEqualTo() {
		return createtimeEqualTo;
	}
	public void setCreatetimeEqualTo(java.util.Date createtimeEqualTo) {
		this.createtimeEqualTo = createtimeEqualTo;
	}

	public void setSidx(String sidx) {
		this.sidx = sidx;
	}
	public String getSord() {
		return sord;
	}
	public void setSord(String sord) {
		 this.sord = sord;
	}
}
