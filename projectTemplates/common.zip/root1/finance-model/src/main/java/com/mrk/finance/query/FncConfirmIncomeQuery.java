package com.mrk.finance.query;
import com.mrk.common.utils.text.CheckUtil;

/**
 * @author 自动生成工具
 * @date   2021/11/10
 */
public class FncConfirmIncomeQuery {
	private String updateuserNotLike;
	private java.util.List updateuserNotIn;
	private String updateuserNotEqualTo;
	private String updateuserLike;
	private String updateuserLessThanOrEqualTo;
	private String updateuserLessThan;
	private Boolean updateuserIsNull;
	private Boolean updateuserIsNotNull;
	private java.util.List updateuserIn;
	private String updateuserGreaterThanOrEqualTo;
	private String updateuserGreaterThan;
	private String updateuserEqualTo;
	private java.util.List updatetimeNotIn;
	private java.util.Date updatetimeNotEqualTo;
	private java.util.Date updatetimeLessThanOrEqualTo;
	private java.util.Date updatetimeLessThan;
	private Boolean updatetimeIsNull;
	private Boolean updatetimeIsNotNull;
	private java.util.List updatetimeIn;
	private java.util.Date updatetimeGreaterThanOrEqualTo;
	private java.util.Date updatetimeGreaterThan;
	private java.util.Date updatetimeEqualTo;
	private String remarkNotLike;
	private java.util.List remarkNotIn;
	private String remarkNotEqualTo;
	private String remarkLike;
	private String remarkLessThanOrEqualTo;
	private String remarkLessThan;
	private Boolean remarkIsNull;
	private Boolean remarkIsNotNull;
	private java.util.List remarkIn;
	private String remarkGreaterThanOrEqualTo;
	private String remarkGreaterThan;
	private String remarkEqualTo;
	private java.util.List fciTotalIncomeNotIn;
	private Double fciTotalIncomeNotEqualTo;
	private Double fciTotalIncomeLessThanOrEqualTo;
	private Double fciTotalIncomeLessThan;
	private Boolean fciTotalIncomeIsNull;
	private Boolean fciTotalIncomeIsNotNull;
	private java.util.List fciTotalIncomeIn;
	private Double fciTotalIncomeGreaterThanOrEqualTo;
	private Double fciTotalIncomeGreaterThan;
	private Double fciTotalIncomeEqualTo;
	private java.util.List fciRentIncomeNotIn;
	private Double fciRentIncomeNotEqualTo;
	private Double fciRentIncomeLessThanOrEqualTo;
	private Double fciRentIncomeLessThan;
	private Boolean fciRentIncomeIsNull;
	private Boolean fciRentIncomeIsNotNull;
	private java.util.List fciRentIncomeIn;
	private Double fciRentIncomeGreaterThanOrEqualTo;
	private Double fciRentIncomeGreaterThan;
	private Double fciRentIncomeEqualTo;
	private java.util.List fciPenaltyIncomeNotIn;
	private Double fciPenaltyIncomeNotEqualTo;
	private Double fciPenaltyIncomeLessThanOrEqualTo;
	private Double fciPenaltyIncomeLessThan;
	private Boolean fciPenaltyIncomeIsNull;
	private Boolean fciPenaltyIncomeIsNotNull;
	private java.util.List fciPenaltyIncomeIn;
	private Double fciPenaltyIncomeGreaterThanOrEqualTo;
	private Double fciPenaltyIncomeGreaterThan;
	private Double fciPenaltyIncomeEqualTo;
	private java.util.List fciIncomeMonthNotIn;
	private java.util.Date fciIncomeMonthNotEqualTo;
	private java.util.Date fciIncomeMonthLessThanOrEqualTo;
	private java.util.Date fciIncomeMonthLessThan;
	private Boolean fciIncomeMonthIsNull;
	private Boolean fciIncomeMonthIsNotNull;
	private java.util.List fciIncomeMonthIn;
	private java.util.Date fciIncomeMonthGreaterThanOrEqualTo;
	private java.util.Date fciIncomeMonthGreaterThan;
	private java.util.Date fciIncomeMonthEqualTo;
	private java.util.List fciIdNotIn;
	private Long fciIdNotEqualTo;
	private Long fciIdLessThanOrEqualTo;
	private Long fciIdLessThan;
	private Boolean fciIdIsNull;
	private Boolean fciIdIsNotNull;
	private java.util.List fciIdIn;
	private Long fciIdGreaterThanOrEqualTo;
	private Long fciIdGreaterThan;
	private Long fciIdEqualTo;
	private java.util.List fciDeptIdNotIn;
	private Long fciDeptIdNotEqualTo;
	private Long fciDeptIdLessThanOrEqualTo;
	private Long fciDeptIdLessThan;
	private Boolean fciDeptIdIsNull;
	private Boolean fciDeptIdIsNotNull;
	private java.util.List fciDeptIdIn;
	private Long fciDeptIdGreaterThanOrEqualTo;
	private Long fciDeptIdGreaterThan;
	private Long fciDeptIdEqualTo;
	private java.util.List fciCarPurchaseIncomeNotIn;
	private Double fciCarPurchaseIncomeNotEqualTo;
	private Double fciCarPurchaseIncomeLessThanOrEqualTo;
	private Double fciCarPurchaseIncomeLessThan;
	private Boolean fciCarPurchaseIncomeIsNull;
	private Boolean fciCarPurchaseIncomeIsNotNull;
	private java.util.List fciCarPurchaseIncomeIn;
	private Double fciCarPurchaseIncomeGreaterThanOrEqualTo;
	private Double fciCarPurchaseIncomeGreaterThan;
	private Double fciCarPurchaseIncomeEqualTo;
	private java.util.List drNotIn;
	private Integer drNotEqualTo;
	private Integer drLessThanOrEqualTo;
	private Integer drLessThan;
	private Boolean drIsNull;
	private Boolean drIsNotNull;
	private java.util.List drIn;
	private Integer drGreaterThanOrEqualTo;
	private Integer drGreaterThan;
	private Integer drEqualTo;
	private String createuserNotLike;
	private java.util.List createuserNotIn;
	private String createuserNotEqualTo;
	private String createuserLike;
	private String createuserLessThanOrEqualTo;
	private String createuserLessThan;
	private Boolean createuserIsNull;
	private Boolean createuserIsNotNull;
	private java.util.List createuserIn;
	private String createuserGreaterThanOrEqualTo;
	private String createuserGreaterThan;
	private String createuserEqualTo;
	private java.util.List createtimeNotIn;
	private java.util.Date createtimeNotEqualTo;
	private java.util.Date createtimeLessThanOrEqualTo;
	private java.util.Date createtimeLessThan;
	private Boolean createtimeIsNull;
	private Boolean createtimeIsNotNull;
	private java.util.List createtimeIn;
	private java.util.Date createtimeGreaterThanOrEqualTo;
	private java.util.Date createtimeGreaterThan;
	private java.util.Date createtimeEqualTo;
	private String sidx;
	private String sord;
	public String getSidx(){
		if(this.sidx == null){
			return "";
		}
		else if("updateuser".equals(this.sidx)){
			return "updateuser";
		}
		else if("updatetime".equals(this.sidx)){
			return "updatetime";
		}
		else if("remark".equals(this.sidx)){
			return "remark";
		}
		else if("fciTotalcomeIn".equals(this.sidx)){
			return "fci_totalcome_in";
		}
		else if("fciTotalcome".equals(this.sidx)){
			return "fci_totalcome";
		}
		else if("fciRentcomeIn".equals(this.sidx)){
			return "fci_rentcome_in";
		}
		else if("fciRentcome".equals(this.sidx)){
			return "fci_rentcome";
		}
		else if("fciPenaltycomeIn".equals(this.sidx)){
			return "fci_penaltycome_in";
		}
		else if("fciPenaltycome".equals(this.sidx)){
			return "fci_penaltycome";
		}
		else if("fcicomeMonthIn".equals(this.sidx)){
			return "fcicome_month_in";
		}
		else if("fcicomeMonth".equals(this.sidx)){
			return "fcicome_month";
		}
		else if("fciId".equals(this.sidx)){
			return "fci_id";
		}
		else if("fciDeptId".equals(this.sidx)){
			return "fci_dept_id";
		}
		else if("fciCarPurchasecomeIn".equals(this.sidx)){
			return "fci_car_purchasecome_in";
		}
		else if("fciCarPurchasecome".equals(this.sidx)){
			return "fci_car_purchasecome";
		}
		else if("dr".equals(this.sidx)){
			return "dr";
		}
		else if("createuser".equals(this.sidx)){
			return "createuser";
		}
		else if("createtime".equals(this.sidx)){
			return "createtime";
		}
		return this.sidx;
	}

	@com.fasterxml.jackson.annotation.JsonIgnore
	public com.mrk.finance.example.FncConfirmIncomeExample getCrieria(){
		com.mrk.finance.example.FncConfirmIncomeExample q = new com.mrk.finance.example.FncConfirmIncomeExample();
		com.mrk.finance.example.FncConfirmIncomeExample.Criteria c = q.createCriteria();
		c.andDrEqualTo(0);
		if(CheckUtil.isNotEmpty(getUpdateuserNotLike())){
			c.andUpdateuserNotLike("%"+this.getUpdateuserNotLike()+"%");
		}
		if(CheckUtil.isNotEmpty(getUpdateuserNotIn())){
			c.andUpdateuserNotIn(this.getUpdateuserNotIn());
		}
		if(CheckUtil.isNotEmpty(getUpdateuserNotEqualTo())){
			c.andUpdateuserNotEqualTo(this.getUpdateuserNotEqualTo());
		}
		if(CheckUtil.isNotEmpty(getUpdateuserLike())){
			c.andUpdateuserLike("%"+this.getUpdateuserLike()+"%");
		}
		if(CheckUtil.isNotEmpty(getUpdateuserLessThanOrEqualTo())){
			c.andUpdateuserLessThanOrEqualTo(this.getUpdateuserLessThanOrEqualTo());
		}
		if(CheckUtil.isNotEmpty(getUpdateuserLessThan())){
			c.andUpdateuserLessThan(this.getUpdateuserLessThan());
		}
		if(CheckUtil.isNotEmpty(getUpdateuserIsNull()) && this.getUpdateuserIsNull()){
			c.andUpdateuserIsNull();
		}
		if(CheckUtil.isNotEmpty(getUpdateuserIsNotNull()) && this.getUpdateuserIsNotNull()){
			c.andUpdateuserIsNotNull();
		}
		if(CheckUtil.isNotEmpty(getUpdateuserIn())){
			c.andUpdateuserIn(this.getUpdateuserIn());
		}
		if(CheckUtil.isNotEmpty(getUpdateuserGreaterThanOrEqualTo())){
			c.andUpdateuserGreaterThanOrEqualTo(this.getUpdateuserGreaterThanOrEqualTo());
		}
		if(CheckUtil.isNotEmpty(getUpdateuserGreaterThan())){
			c.andUpdateuserGreaterThan(this.getUpdateuserGreaterThan());
		}
		if(CheckUtil.isNotEmpty(getUpdateuserEqualTo())){
			c.andUpdateuserEqualTo(this.getUpdateuserEqualTo());
		}
		if(CheckUtil.isNotEmpty(getUpdatetimeNotIn())){
			c.andUpdatetimeNotIn(this.getUpdatetimeNotIn());
		}
		if(CheckUtil.isNotEmpty(getUpdatetimeNotEqualTo())){
			c.andUpdatetimeNotEqualTo(this.getUpdatetimeNotEqualTo());
		}
		if(CheckUtil.isNotEmpty(getUpdatetimeLessThanOrEqualTo())){
			c.andUpdatetimeLessThanOrEqualTo(this.getUpdatetimeLessThanOrEqualTo());
		}
		if(CheckUtil.isNotEmpty(getUpdatetimeLessThan())){
			c.andUpdatetimeLessThan(this.getUpdatetimeLessThan());
		}
		if(CheckUtil.isNotEmpty(getUpdatetimeIsNull()) && this.getUpdatetimeIsNull()){
			c.andUpdatetimeIsNull();
		}
		if(CheckUtil.isNotEmpty(getUpdatetimeIsNotNull()) && this.getUpdatetimeIsNotNull()){
			c.andUpdatetimeIsNotNull();
		}
		if(CheckUtil.isNotEmpty(getUpdatetimeIn())){
			c.andUpdatetimeIn(this.getUpdatetimeIn());
		}
		if(CheckUtil.isNotEmpty(getUpdatetimeGreaterThanOrEqualTo())){
			c.andUpdatetimeGreaterThanOrEqualTo(this.getUpdatetimeGreaterThanOrEqualTo());
		}
		if(CheckUtil.isNotEmpty(getUpdatetimeGreaterThan())){
			c.andUpdatetimeGreaterThan(this.getUpdatetimeGreaterThan());
		}
		if(CheckUtil.isNotEmpty(getUpdatetimeEqualTo())){
			c.andUpdatetimeEqualTo(this.getUpdatetimeEqualTo());
		}
		if(CheckUtil.isNotEmpty(getRemarkNotLike())){
			c.andRemarkNotLike("%"+this.getRemarkNotLike()+"%");
		}
		if(CheckUtil.isNotEmpty(getRemarkNotIn())){
			c.andRemarkNotIn(this.getRemarkNotIn());
		}
		if(CheckUtil.isNotEmpty(getRemarkNotEqualTo())){
			c.andRemarkNotEqualTo(this.getRemarkNotEqualTo());
		}
		if(CheckUtil.isNotEmpty(getRemarkLike())){
			c.andRemarkLike("%"+this.getRemarkLike()+"%");
		}
		if(CheckUtil.isNotEmpty(getRemarkLessThanOrEqualTo())){
			c.andRemarkLessThanOrEqualTo(this.getRemarkLessThanOrEqualTo());
		}
		if(CheckUtil.isNotEmpty(getRemarkLessThan())){
			c.andRemarkLessThan(this.getRemarkLessThan());
		}
		if(CheckUtil.isNotEmpty(getRemarkIsNull()) && this.getRemarkIsNull()){
			c.andRemarkIsNull();
		}
		if(CheckUtil.isNotEmpty(getRemarkIsNotNull()) && this.getRemarkIsNotNull()){
			c.andRemarkIsNotNull();
		}
		if(CheckUtil.isNotEmpty(getRemarkIn())){
			c.andRemarkIn(this.getRemarkIn());
		}
		if(CheckUtil.isNotEmpty(getRemarkGreaterThanOrEqualTo())){
			c.andRemarkGreaterThanOrEqualTo(this.getRemarkGreaterThanOrEqualTo());
		}
		if(CheckUtil.isNotEmpty(getRemarkGreaterThan())){
			c.andRemarkGreaterThan(this.getRemarkGreaterThan());
		}
		if(CheckUtil.isNotEmpty(getRemarkEqualTo())){
			c.andRemarkEqualTo(this.getRemarkEqualTo());
		}
		if(CheckUtil.isNotEmpty(getFciTotalIncomeNotIn())){
			c.andFciTotalIncomeNotIn(this.getFciTotalIncomeNotIn());
		}
		if(CheckUtil.isNotEmpty(getFciTotalIncomeNotEqualTo())){
			c.andFciTotalIncomeNotEqualTo(this.getFciTotalIncomeNotEqualTo());
		}
		if(CheckUtil.isNotEmpty(getFciTotalIncomeLessThanOrEqualTo())){
			c.andFciTotalIncomeLessThanOrEqualTo(this.getFciTotalIncomeLessThanOrEqualTo());
		}
		if(CheckUtil.isNotEmpty(getFciTotalIncomeLessThan())){
			c.andFciTotalIncomeLessThan(this.getFciTotalIncomeLessThan());
		}
		if(CheckUtil.isNotEmpty(getFciTotalIncomeIsNull()) && this.getFciTotalIncomeIsNull()){
			c.andFciTotalIncomeIsNull();
		}
		if(CheckUtil.isNotEmpty(getFciTotalIncomeIsNotNull()) && this.getFciTotalIncomeIsNotNull()){
			c.andFciTotalIncomeIsNotNull();
		}
		if(CheckUtil.isNotEmpty(getFciTotalIncomeIn())){
			c.andFciTotalIncomeIn(this.getFciTotalIncomeIn());
		}
		if(CheckUtil.isNotEmpty(getFciTotalIncomeGreaterThanOrEqualTo())){
			c.andFciTotalIncomeGreaterThanOrEqualTo(this.getFciTotalIncomeGreaterThanOrEqualTo());
		}
		if(CheckUtil.isNotEmpty(getFciTotalIncomeGreaterThan())){
			c.andFciTotalIncomeGreaterThan(this.getFciTotalIncomeGreaterThan());
		}
		if(CheckUtil.isNotEmpty(getFciTotalIncomeEqualTo())){
			c.andFciTotalIncomeEqualTo(this.getFciTotalIncomeEqualTo());
		}
		if(CheckUtil.isNotEmpty(getFciRentIncomeNotIn())){
			c.andFciRentIncomeNotIn(this.getFciRentIncomeNotIn());
		}
		if(CheckUtil.isNotEmpty(getFciRentIncomeNotEqualTo())){
			c.andFciRentIncomeNotEqualTo(this.getFciRentIncomeNotEqualTo());
		}
		if(CheckUtil.isNotEmpty(getFciRentIncomeLessThanOrEqualTo())){
			c.andFciRentIncomeLessThanOrEqualTo(this.getFciRentIncomeLessThanOrEqualTo());
		}
		if(CheckUtil.isNotEmpty(getFciRentIncomeLessThan())){
			c.andFciRentIncomeLessThan(this.getFciRentIncomeLessThan());
		}
		if(CheckUtil.isNotEmpty(getFciRentIncomeIsNull()) && this.getFciRentIncomeIsNull()){
			c.andFciRentIncomeIsNull();
		}
		if(CheckUtil.isNotEmpty(getFciRentIncomeIsNotNull()) && this.getFciRentIncomeIsNotNull()){
			c.andFciRentIncomeIsNotNull();
		}
		if(CheckUtil.isNotEmpty(getFciRentIncomeIn())){
			c.andFciRentIncomeIn(this.getFciRentIncomeIn());
		}
		if(CheckUtil.isNotEmpty(getFciRentIncomeGreaterThanOrEqualTo())){
			c.andFciRentIncomeGreaterThanOrEqualTo(this.getFciRentIncomeGreaterThanOrEqualTo());
		}
		if(CheckUtil.isNotEmpty(getFciRentIncomeGreaterThan())){
			c.andFciRentIncomeGreaterThan(this.getFciRentIncomeGreaterThan());
		}
		if(CheckUtil.isNotEmpty(getFciRentIncomeEqualTo())){
			c.andFciRentIncomeEqualTo(this.getFciRentIncomeEqualTo());
		}
		if(CheckUtil.isNotEmpty(getFciPenaltyIncomeNotIn())){
			c.andFciPenaltyIncomeNotIn(this.getFciPenaltyIncomeNotIn());
		}
		if(CheckUtil.isNotEmpty(getFciPenaltyIncomeNotEqualTo())){
			c.andFciPenaltyIncomeNotEqualTo(this.getFciPenaltyIncomeNotEqualTo());
		}
		if(CheckUtil.isNotEmpty(getFciPenaltyIncomeLessThanOrEqualTo())){
			c.andFciPenaltyIncomeLessThanOrEqualTo(this.getFciPenaltyIncomeLessThanOrEqualTo());
		}
		if(CheckUtil.isNotEmpty(getFciPenaltyIncomeLessThan())){
			c.andFciPenaltyIncomeLessThan(this.getFciPenaltyIncomeLessThan());
		}
		if(CheckUtil.isNotEmpty(getFciPenaltyIncomeIsNull()) && this.getFciPenaltyIncomeIsNull()){
			c.andFciPenaltyIncomeIsNull();
		}
		if(CheckUtil.isNotEmpty(getFciPenaltyIncomeIsNotNull()) && this.getFciPenaltyIncomeIsNotNull()){
			c.andFciPenaltyIncomeIsNotNull();
		}
		if(CheckUtil.isNotEmpty(getFciPenaltyIncomeIn())){
			c.andFciPenaltyIncomeIn(this.getFciPenaltyIncomeIn());
		}
		if(CheckUtil.isNotEmpty(getFciPenaltyIncomeGreaterThanOrEqualTo())){
			c.andFciPenaltyIncomeGreaterThanOrEqualTo(this.getFciPenaltyIncomeGreaterThanOrEqualTo());
		}
		if(CheckUtil.isNotEmpty(getFciPenaltyIncomeGreaterThan())){
			c.andFciPenaltyIncomeGreaterThan(this.getFciPenaltyIncomeGreaterThan());
		}
		if(CheckUtil.isNotEmpty(getFciPenaltyIncomeEqualTo())){
			c.andFciPenaltyIncomeEqualTo(this.getFciPenaltyIncomeEqualTo());
		}
		if(CheckUtil.isNotEmpty(getFciIncomeMonthNotIn())){
			c.andFciIncomeMonthNotIn(this.getFciIncomeMonthNotIn());
		}
		if(CheckUtil.isNotEmpty(getFciIncomeMonthNotEqualTo())){
			c.andFciIncomeMonthNotEqualTo(this.getFciIncomeMonthNotEqualTo());
		}
		if(CheckUtil.isNotEmpty(getFciIncomeMonthLessThanOrEqualTo())){
			c.andFciIncomeMonthLessThanOrEqualTo(this.getFciIncomeMonthLessThanOrEqualTo());
		}
		if(CheckUtil.isNotEmpty(getFciIncomeMonthLessThan())){
			c.andFciIncomeMonthLessThan(this.getFciIncomeMonthLessThan());
		}
		if(CheckUtil.isNotEmpty(getFciIncomeMonthIsNull()) && this.getFciIncomeMonthIsNull()){
			c.andFciIncomeMonthIsNull();
		}
		if(CheckUtil.isNotEmpty(getFciIncomeMonthIsNotNull()) && this.getFciIncomeMonthIsNotNull()){
			c.andFciIncomeMonthIsNotNull();
		}
		if(CheckUtil.isNotEmpty(getFciIncomeMonthIn())){
			c.andFciIncomeMonthIn(this.getFciIncomeMonthIn());
		}
		if(CheckUtil.isNotEmpty(getFciIncomeMonthGreaterThanOrEqualTo())){
			c.andFciIncomeMonthGreaterThanOrEqualTo(this.getFciIncomeMonthGreaterThanOrEqualTo());
		}
		if(CheckUtil.isNotEmpty(getFciIncomeMonthGreaterThan())){
			c.andFciIncomeMonthGreaterThan(this.getFciIncomeMonthGreaterThan());
		}
		if(CheckUtil.isNotEmpty(getFciIncomeMonthEqualTo())){
			c.andFciIncomeMonthEqualTo(this.getFciIncomeMonthEqualTo());
		}
		if(CheckUtil.isNotEmpty(getFciIdNotIn())){
			c.andFciIdNotIn(this.getFciIdNotIn());
		}
		if(CheckUtil.isNotEmpty(getFciIdNotEqualTo())){
			c.andFciIdNotEqualTo(this.getFciIdNotEqualTo());
		}
		if(CheckUtil.isNotEmpty(getFciIdLessThanOrEqualTo())){
			c.andFciIdLessThanOrEqualTo(this.getFciIdLessThanOrEqualTo());
		}
		if(CheckUtil.isNotEmpty(getFciIdLessThan())){
			c.andFciIdLessThan(this.getFciIdLessThan());
		}
		if(CheckUtil.isNotEmpty(getFciIdIsNull()) && this.getFciIdIsNull()){
			c.andFciIdIsNull();
		}
		if(CheckUtil.isNotEmpty(getFciIdIsNotNull()) && this.getFciIdIsNotNull()){
			c.andFciIdIsNotNull();
		}
		if(CheckUtil.isNotEmpty(getFciIdIn())){
			c.andFciIdIn(this.getFciIdIn());
		}
		if(CheckUtil.isNotEmpty(getFciIdGreaterThanOrEqualTo())){
			c.andFciIdGreaterThanOrEqualTo(this.getFciIdGreaterThanOrEqualTo());
		}
		if(CheckUtil.isNotEmpty(getFciIdGreaterThan())){
			c.andFciIdGreaterThan(this.getFciIdGreaterThan());
		}
		if(CheckUtil.isNotEmpty(getFciIdEqualTo())){
			c.andFciIdEqualTo(this.getFciIdEqualTo());
		}
		if(CheckUtil.isNotEmpty(getFciDeptIdNotIn())){
			c.andFciDeptIdNotIn(this.getFciDeptIdNotIn());
		}
		if(CheckUtil.isNotEmpty(getFciDeptIdNotEqualTo())){
			c.andFciDeptIdNotEqualTo(this.getFciDeptIdNotEqualTo());
		}
		if(CheckUtil.isNotEmpty(getFciDeptIdLessThanOrEqualTo())){
			c.andFciDeptIdLessThanOrEqualTo(this.getFciDeptIdLessThanOrEqualTo());
		}
		if(CheckUtil.isNotEmpty(getFciDeptIdLessThan())){
			c.andFciDeptIdLessThan(this.getFciDeptIdLessThan());
		}
		if(CheckUtil.isNotEmpty(getFciDeptIdIsNull()) && this.getFciDeptIdIsNull()){
			c.andFciDeptIdIsNull();
		}
		if(CheckUtil.isNotEmpty(getFciDeptIdIsNotNull()) && this.getFciDeptIdIsNotNull()){
			c.andFciDeptIdIsNotNull();
		}
		if(CheckUtil.isNotEmpty(getFciDeptIdIn())){
			c.andFciDeptIdIn(this.getFciDeptIdIn());
		}
		if(CheckUtil.isNotEmpty(getFciDeptIdGreaterThanOrEqualTo())){
			c.andFciDeptIdGreaterThanOrEqualTo(this.getFciDeptIdGreaterThanOrEqualTo());
		}
		if(CheckUtil.isNotEmpty(getFciDeptIdGreaterThan())){
			c.andFciDeptIdGreaterThan(this.getFciDeptIdGreaterThan());
		}
		if(CheckUtil.isNotEmpty(getFciDeptIdEqualTo())){
			c.andFciDeptIdEqualTo(this.getFciDeptIdEqualTo());
		}
		if(CheckUtil.isNotEmpty(getFciCarPurchaseIncomeNotIn())){
			c.andFciCarPurchaseIncomeNotIn(this.getFciCarPurchaseIncomeNotIn());
		}
		if(CheckUtil.isNotEmpty(getFciCarPurchaseIncomeNotEqualTo())){
			c.andFciCarPurchaseIncomeNotEqualTo(this.getFciCarPurchaseIncomeNotEqualTo());
		}
		if(CheckUtil.isNotEmpty(getFciCarPurchaseIncomeLessThanOrEqualTo())){
			c.andFciCarPurchaseIncomeLessThanOrEqualTo(this.getFciCarPurchaseIncomeLessThanOrEqualTo());
		}
		if(CheckUtil.isNotEmpty(getFciCarPurchaseIncomeLessThan())){
			c.andFciCarPurchaseIncomeLessThan(this.getFciCarPurchaseIncomeLessThan());
		}
		if(CheckUtil.isNotEmpty(getFciCarPurchaseIncomeIsNull()) && this.getFciCarPurchaseIncomeIsNull()){
			c.andFciCarPurchaseIncomeIsNull();
		}
		if(CheckUtil.isNotEmpty(getFciCarPurchaseIncomeIsNotNull()) && this.getFciCarPurchaseIncomeIsNotNull()){
			c.andFciCarPurchaseIncomeIsNotNull();
		}
		if(CheckUtil.isNotEmpty(getFciCarPurchaseIncomeIn())){
			c.andFciCarPurchaseIncomeIn(this.getFciCarPurchaseIncomeIn());
		}
		if(CheckUtil.isNotEmpty(getFciCarPurchaseIncomeGreaterThanOrEqualTo())){
			c.andFciCarPurchaseIncomeGreaterThanOrEqualTo(this.getFciCarPurchaseIncomeGreaterThanOrEqualTo());
		}
		if(CheckUtil.isNotEmpty(getFciCarPurchaseIncomeGreaterThan())){
			c.andFciCarPurchaseIncomeGreaterThan(this.getFciCarPurchaseIncomeGreaterThan());
		}
		if(CheckUtil.isNotEmpty(getFciCarPurchaseIncomeEqualTo())){
			c.andFciCarPurchaseIncomeEqualTo(this.getFciCarPurchaseIncomeEqualTo());
		}
		if(CheckUtil.isNotEmpty(getDrNotIn())){
			c.andDrNotIn(this.getDrNotIn());
		}
		if(CheckUtil.isNotEmpty(getDrNotEqualTo())){
			c.andDrNotEqualTo(this.getDrNotEqualTo());
		}
		if(CheckUtil.isNotEmpty(getDrLessThanOrEqualTo())){
			c.andDrLessThanOrEqualTo(this.getDrLessThanOrEqualTo());
		}
		if(CheckUtil.isNotEmpty(getDrLessThan())){
			c.andDrLessThan(this.getDrLessThan());
		}
		if(CheckUtil.isNotEmpty(getDrIsNull()) && this.getDrIsNull()){
			c.andDrIsNull();
		}
		if(CheckUtil.isNotEmpty(getDrIsNotNull()) && this.getDrIsNotNull()){
			c.andDrIsNotNull();
		}
		if(CheckUtil.isNotEmpty(getDrIn())){
			c.andDrIn(this.getDrIn());
		}
		if(CheckUtil.isNotEmpty(getDrGreaterThanOrEqualTo())){
			c.andDrGreaterThanOrEqualTo(this.getDrGreaterThanOrEqualTo());
		}
		if(CheckUtil.isNotEmpty(getDrGreaterThan())){
			c.andDrGreaterThan(this.getDrGreaterThan());
		}
		if(CheckUtil.isNotEmpty(getDrEqualTo())){
			c.andDrEqualTo(this.getDrEqualTo());
		}
		if(CheckUtil.isNotEmpty(getCreateuserNotLike())){
			c.andCreateuserNotLike("%"+this.getCreateuserNotLike()+"%");
		}
		if(CheckUtil.isNotEmpty(getCreateuserNotIn())){
			c.andCreateuserNotIn(this.getCreateuserNotIn());
		}
		if(CheckUtil.isNotEmpty(getCreateuserNotEqualTo())){
			c.andCreateuserNotEqualTo(this.getCreateuserNotEqualTo());
		}
		if(CheckUtil.isNotEmpty(getCreateuserLike())){
			c.andCreateuserLike("%"+this.getCreateuserLike()+"%");
		}
		if(CheckUtil.isNotEmpty(getCreateuserLessThanOrEqualTo())){
			c.andCreateuserLessThanOrEqualTo(this.getCreateuserLessThanOrEqualTo());
		}
		if(CheckUtil.isNotEmpty(getCreateuserLessThan())){
			c.andCreateuserLessThan(this.getCreateuserLessThan());
		}
		if(CheckUtil.isNotEmpty(getCreateuserIsNull()) && this.getCreateuserIsNull()){
			c.andCreateuserIsNull();
		}
		if(CheckUtil.isNotEmpty(getCreateuserIsNotNull()) && this.getCreateuserIsNotNull()){
			c.andCreateuserIsNotNull();
		}
		if(CheckUtil.isNotEmpty(getCreateuserIn())){
			c.andCreateuserIn(this.getCreateuserIn());
		}
		if(CheckUtil.isNotEmpty(getCreateuserGreaterThanOrEqualTo())){
			c.andCreateuserGreaterThanOrEqualTo(this.getCreateuserGreaterThanOrEqualTo());
		}
		if(CheckUtil.isNotEmpty(getCreateuserGreaterThan())){
			c.andCreateuserGreaterThan(this.getCreateuserGreaterThan());
		}
		if(CheckUtil.isNotEmpty(getCreateuserEqualTo())){
			c.andCreateuserEqualTo(this.getCreateuserEqualTo());
		}
		if(CheckUtil.isNotEmpty(getCreatetimeNotIn())){
			c.andCreatetimeNotIn(this.getCreatetimeNotIn());
		}
		if(CheckUtil.isNotEmpty(getCreatetimeNotEqualTo())){
			c.andCreatetimeNotEqualTo(this.getCreatetimeNotEqualTo());
		}
		if(CheckUtil.isNotEmpty(getCreatetimeLessThanOrEqualTo())){
			c.andCreatetimeLessThanOrEqualTo(this.getCreatetimeLessThanOrEqualTo());
		}
		if(CheckUtil.isNotEmpty(getCreatetimeLessThan())){
			c.andCreatetimeLessThan(this.getCreatetimeLessThan());
		}
		if(CheckUtil.isNotEmpty(getCreatetimeIsNull()) && this.getCreatetimeIsNull()){
			c.andCreatetimeIsNull();
		}
		if(CheckUtil.isNotEmpty(getCreatetimeIsNotNull()) && this.getCreatetimeIsNotNull()){
			c.andCreatetimeIsNotNull();
		}
		if(CheckUtil.isNotEmpty(getCreatetimeIn())){
			c.andCreatetimeIn(this.getCreatetimeIn());
		}
		if(CheckUtil.isNotEmpty(getCreatetimeGreaterThanOrEqualTo())){
			c.andCreatetimeGreaterThanOrEqualTo(this.getCreatetimeGreaterThanOrEqualTo());
		}
		if(CheckUtil.isNotEmpty(getCreatetimeGreaterThan())){
			c.andCreatetimeGreaterThan(this.getCreatetimeGreaterThan());
		}
		if(CheckUtil.isNotEmpty(getCreatetimeEqualTo())){
			c.andCreatetimeEqualTo(this.getCreatetimeEqualTo());
		}
		if((this.getSidx()!=null && !this.getSidx().trim().equals("")) && this.getSord()!=null) {
			q.setOrderByClause(""+ this.getSidx()+" "+this.getSord());
		}
		return q;
	}
	public String getUpdateuserNotLike() {
		return updateuserNotLike;
	}
	public void setUpdateuserNotLike(String updateuserNotLike) {
		this.updateuserNotLike = updateuserNotLike;
	}

	public java.util.List getUpdateuserNotIn() {
		return updateuserNotIn;
	}
	public void setUpdateuserNotIn(java.util.List updateuserNotIn) {
		this.updateuserNotIn = updateuserNotIn;
	}

	public String getUpdateuserNotEqualTo() {
		return updateuserNotEqualTo;
	}
	public void setUpdateuserNotEqualTo(String updateuserNotEqualTo) {
		this.updateuserNotEqualTo = updateuserNotEqualTo;
	}

	public String getUpdateuserLike() {
		return updateuserLike;
	}
	public void setUpdateuserLike(String updateuserLike) {
		this.updateuserLike = updateuserLike;
	}

	public String getUpdateuserLessThanOrEqualTo() {
		return updateuserLessThanOrEqualTo;
	}
	public void setUpdateuserLessThanOrEqualTo(String updateuserLessThanOrEqualTo) {
		this.updateuserLessThanOrEqualTo = updateuserLessThanOrEqualTo;
	}

	public String getUpdateuserLessThan() {
		return updateuserLessThan;
	}
	public void setUpdateuserLessThan(String updateuserLessThan) {
		this.updateuserLessThan = updateuserLessThan;
	}

	public Boolean getUpdateuserIsNull() {
		return updateuserIsNull;
	}
	public void setUpdateuserIsNull(Boolean updateuserIsNull) {
		this.updateuserIsNull = updateuserIsNull;
	}

	public Boolean getUpdateuserIsNotNull() {
		return updateuserIsNotNull;
	}
	public void setUpdateuserIsNotNull(Boolean updateuserIsNotNull) {
		this.updateuserIsNotNull = updateuserIsNotNull;
	}

	public java.util.List getUpdateuserIn() {
		return updateuserIn;
	}
	public void setUpdateuserIn(java.util.List updateuserIn) {
		this.updateuserIn = updateuserIn;
	}

	public String getUpdateuserGreaterThanOrEqualTo() {
		return updateuserGreaterThanOrEqualTo;
	}
	public void setUpdateuserGreaterThanOrEqualTo(String updateuserGreaterThanOrEqualTo) {
		this.updateuserGreaterThanOrEqualTo = updateuserGreaterThanOrEqualTo;
	}

	public String getUpdateuserGreaterThan() {
		return updateuserGreaterThan;
	}
	public void setUpdateuserGreaterThan(String updateuserGreaterThan) {
		this.updateuserGreaterThan = updateuserGreaterThan;
	}

	public String getUpdateuserEqualTo() {
		return updateuserEqualTo;
	}
	public void setUpdateuserEqualTo(String updateuserEqualTo) {
		this.updateuserEqualTo = updateuserEqualTo;
	}

	public java.util.List getUpdatetimeNotIn() {
		return updatetimeNotIn;
	}
	public void setUpdatetimeNotIn(java.util.List updatetimeNotIn) {
		this.updatetimeNotIn = updatetimeNotIn;
	}

	public java.util.Date getUpdatetimeNotEqualTo() {
		return updatetimeNotEqualTo;
	}
	public void setUpdatetimeNotEqualTo(java.util.Date updatetimeNotEqualTo) {
		this.updatetimeNotEqualTo = updatetimeNotEqualTo;
	}

	public java.util.Date getUpdatetimeLessThanOrEqualTo() {
		return updatetimeLessThanOrEqualTo;
	}
	public void setUpdatetimeLessThanOrEqualTo(java.util.Date updatetimeLessThanOrEqualTo) {
		this.updatetimeLessThanOrEqualTo = updatetimeLessThanOrEqualTo;
	}

	public java.util.Date getUpdatetimeLessThan() {
		return updatetimeLessThan;
	}
	public void setUpdatetimeLessThan(java.util.Date updatetimeLessThan) {
		this.updatetimeLessThan = updatetimeLessThan;
	}

	public Boolean getUpdatetimeIsNull() {
		return updatetimeIsNull;
	}
	public void setUpdatetimeIsNull(Boolean updatetimeIsNull) {
		this.updatetimeIsNull = updatetimeIsNull;
	}

	public Boolean getUpdatetimeIsNotNull() {
		return updatetimeIsNotNull;
	}
	public void setUpdatetimeIsNotNull(Boolean updatetimeIsNotNull) {
		this.updatetimeIsNotNull = updatetimeIsNotNull;
	}

	public java.util.List getUpdatetimeIn() {
		return updatetimeIn;
	}
	public void setUpdatetimeIn(java.util.List updatetimeIn) {
		this.updatetimeIn = updatetimeIn;
	}

	public java.util.Date getUpdatetimeGreaterThanOrEqualTo() {
		return updatetimeGreaterThanOrEqualTo;
	}
	public void setUpdatetimeGreaterThanOrEqualTo(java.util.Date updatetimeGreaterThanOrEqualTo) {
		this.updatetimeGreaterThanOrEqualTo = updatetimeGreaterThanOrEqualTo;
	}

	public java.util.Date getUpdatetimeGreaterThan() {
		return updatetimeGreaterThan;
	}
	public void setUpdatetimeGreaterThan(java.util.Date updatetimeGreaterThan) {
		this.updatetimeGreaterThan = updatetimeGreaterThan;
	}

	public java.util.Date getUpdatetimeEqualTo() {
		return updatetimeEqualTo;
	}
	public void setUpdatetimeEqualTo(java.util.Date updatetimeEqualTo) {
		this.updatetimeEqualTo = updatetimeEqualTo;
	}

	public String getRemarkNotLike() {
		return remarkNotLike;
	}
	public void setRemarkNotLike(String remarkNotLike) {
		this.remarkNotLike = remarkNotLike;
	}

	public java.util.List getRemarkNotIn() {
		return remarkNotIn;
	}
	public void setRemarkNotIn(java.util.List remarkNotIn) {
		this.remarkNotIn = remarkNotIn;
	}

	public String getRemarkNotEqualTo() {
		return remarkNotEqualTo;
	}
	public void setRemarkNotEqualTo(String remarkNotEqualTo) {
		this.remarkNotEqualTo = remarkNotEqualTo;
	}

	public String getRemarkLike() {
		return remarkLike;
	}
	public void setRemarkLike(String remarkLike) {
		this.remarkLike = remarkLike;
	}

	public String getRemarkLessThanOrEqualTo() {
		return remarkLessThanOrEqualTo;
	}
	public void setRemarkLessThanOrEqualTo(String remarkLessThanOrEqualTo) {
		this.remarkLessThanOrEqualTo = remarkLessThanOrEqualTo;
	}

	public String getRemarkLessThan() {
		return remarkLessThan;
	}
	public void setRemarkLessThan(String remarkLessThan) {
		this.remarkLessThan = remarkLessThan;
	}

	public Boolean getRemarkIsNull() {
		return remarkIsNull;
	}
	public void setRemarkIsNull(Boolean remarkIsNull) {
		this.remarkIsNull = remarkIsNull;
	}

	public Boolean getRemarkIsNotNull() {
		return remarkIsNotNull;
	}
	public void setRemarkIsNotNull(Boolean remarkIsNotNull) {
		this.remarkIsNotNull = remarkIsNotNull;
	}

	public java.util.List getRemarkIn() {
		return remarkIn;
	}
	public void setRemarkIn(java.util.List remarkIn) {
		this.remarkIn = remarkIn;
	}

	public String getRemarkGreaterThanOrEqualTo() {
		return remarkGreaterThanOrEqualTo;
	}
	public void setRemarkGreaterThanOrEqualTo(String remarkGreaterThanOrEqualTo) {
		this.remarkGreaterThanOrEqualTo = remarkGreaterThanOrEqualTo;
	}

	public String getRemarkGreaterThan() {
		return remarkGreaterThan;
	}
	public void setRemarkGreaterThan(String remarkGreaterThan) {
		this.remarkGreaterThan = remarkGreaterThan;
	}

	public String getRemarkEqualTo() {
		return remarkEqualTo;
	}
	public void setRemarkEqualTo(String remarkEqualTo) {
		this.remarkEqualTo = remarkEqualTo;
	}

	public java.util.List getFciTotalIncomeNotIn() {
		return fciTotalIncomeNotIn;
	}
	public void setFciTotalIncomeNotIn(java.util.List fciTotalIncomeNotIn) {
		this.fciTotalIncomeNotIn = fciTotalIncomeNotIn;
	}

	public Double getFciTotalIncomeNotEqualTo() {
		return fciTotalIncomeNotEqualTo;
	}
	public void setFciTotalIncomeNotEqualTo(Double fciTotalIncomeNotEqualTo) {
		this.fciTotalIncomeNotEqualTo = fciTotalIncomeNotEqualTo;
	}

	public Double getFciTotalIncomeLessThanOrEqualTo() {
		return fciTotalIncomeLessThanOrEqualTo;
	}
	public void setFciTotalIncomeLessThanOrEqualTo(Double fciTotalIncomeLessThanOrEqualTo) {
		this.fciTotalIncomeLessThanOrEqualTo = fciTotalIncomeLessThanOrEqualTo;
	}

	public Double getFciTotalIncomeLessThan() {
		return fciTotalIncomeLessThan;
	}
	public void setFciTotalIncomeLessThan(Double fciTotalIncomeLessThan) {
		this.fciTotalIncomeLessThan = fciTotalIncomeLessThan;
	}

	public Boolean getFciTotalIncomeIsNull() {
		return fciTotalIncomeIsNull;
	}
	public void setFciTotalIncomeIsNull(Boolean fciTotalIncomeIsNull) {
		this.fciTotalIncomeIsNull = fciTotalIncomeIsNull;
	}

	public Boolean getFciTotalIncomeIsNotNull() {
		return fciTotalIncomeIsNotNull;
	}
	public void setFciTotalIncomeIsNotNull(Boolean fciTotalIncomeIsNotNull) {
		this.fciTotalIncomeIsNotNull = fciTotalIncomeIsNotNull;
	}

	public java.util.List getFciTotalIncomeIn() {
		return fciTotalIncomeIn;
	}
	public void setFciTotalIncomeIn(java.util.List fciTotalIncomeIn) {
		this.fciTotalIncomeIn = fciTotalIncomeIn;
	}

	public Double getFciTotalIncomeGreaterThanOrEqualTo() {
		return fciTotalIncomeGreaterThanOrEqualTo;
	}
	public void setFciTotalIncomeGreaterThanOrEqualTo(Double fciTotalIncomeGreaterThanOrEqualTo) {
		this.fciTotalIncomeGreaterThanOrEqualTo = fciTotalIncomeGreaterThanOrEqualTo;
	}

	public Double getFciTotalIncomeGreaterThan() {
		return fciTotalIncomeGreaterThan;
	}
	public void setFciTotalIncomeGreaterThan(Double fciTotalIncomeGreaterThan) {
		this.fciTotalIncomeGreaterThan = fciTotalIncomeGreaterThan;
	}

	public Double getFciTotalIncomeEqualTo() {
		return fciTotalIncomeEqualTo;
	}
	public void setFciTotalIncomeEqualTo(Double fciTotalIncomeEqualTo) {
		this.fciTotalIncomeEqualTo = fciTotalIncomeEqualTo;
	}

	public java.util.List getFciRentIncomeNotIn() {
		return fciRentIncomeNotIn;
	}
	public void setFciRentIncomeNotIn(java.util.List fciRentIncomeNotIn) {
		this.fciRentIncomeNotIn = fciRentIncomeNotIn;
	}

	public Double getFciRentIncomeNotEqualTo() {
		return fciRentIncomeNotEqualTo;
	}
	public void setFciRentIncomeNotEqualTo(Double fciRentIncomeNotEqualTo) {
		this.fciRentIncomeNotEqualTo = fciRentIncomeNotEqualTo;
	}

	public Double getFciRentIncomeLessThanOrEqualTo() {
		return fciRentIncomeLessThanOrEqualTo;
	}
	public void setFciRentIncomeLessThanOrEqualTo(Double fciRentIncomeLessThanOrEqualTo) {
		this.fciRentIncomeLessThanOrEqualTo = fciRentIncomeLessThanOrEqualTo;
	}

	public Double getFciRentIncomeLessThan() {
		return fciRentIncomeLessThan;
	}
	public void setFciRentIncomeLessThan(Double fciRentIncomeLessThan) {
		this.fciRentIncomeLessThan = fciRentIncomeLessThan;
	}

	public Boolean getFciRentIncomeIsNull() {
		return fciRentIncomeIsNull;
	}
	public void setFciRentIncomeIsNull(Boolean fciRentIncomeIsNull) {
		this.fciRentIncomeIsNull = fciRentIncomeIsNull;
	}

	public Boolean getFciRentIncomeIsNotNull() {
		return fciRentIncomeIsNotNull;
	}
	public void setFciRentIncomeIsNotNull(Boolean fciRentIncomeIsNotNull) {
		this.fciRentIncomeIsNotNull = fciRentIncomeIsNotNull;
	}

	public java.util.List getFciRentIncomeIn() {
		return fciRentIncomeIn;
	}
	public void setFciRentIncomeIn(java.util.List fciRentIncomeIn) {
		this.fciRentIncomeIn = fciRentIncomeIn;
	}

	public Double getFciRentIncomeGreaterThanOrEqualTo() {
		return fciRentIncomeGreaterThanOrEqualTo;
	}
	public void setFciRentIncomeGreaterThanOrEqualTo(Double fciRentIncomeGreaterThanOrEqualTo) {
		this.fciRentIncomeGreaterThanOrEqualTo = fciRentIncomeGreaterThanOrEqualTo;
	}

	public Double getFciRentIncomeGreaterThan() {
		return fciRentIncomeGreaterThan;
	}
	public void setFciRentIncomeGreaterThan(Double fciRentIncomeGreaterThan) {
		this.fciRentIncomeGreaterThan = fciRentIncomeGreaterThan;
	}

	public Double getFciRentIncomeEqualTo() {
		return fciRentIncomeEqualTo;
	}
	public void setFciRentIncomeEqualTo(Double fciRentIncomeEqualTo) {
		this.fciRentIncomeEqualTo = fciRentIncomeEqualTo;
	}

	public java.util.List getFciPenaltyIncomeNotIn() {
		return fciPenaltyIncomeNotIn;
	}
	public void setFciPenaltyIncomeNotIn(java.util.List fciPenaltyIncomeNotIn) {
		this.fciPenaltyIncomeNotIn = fciPenaltyIncomeNotIn;
	}

	public Double getFciPenaltyIncomeNotEqualTo() {
		return fciPenaltyIncomeNotEqualTo;
	}
	public void setFciPenaltyIncomeNotEqualTo(Double fciPenaltyIncomeNotEqualTo) {
		this.fciPenaltyIncomeNotEqualTo = fciPenaltyIncomeNotEqualTo;
	}

	public Double getFciPenaltyIncomeLessThanOrEqualTo() {
		return fciPenaltyIncomeLessThanOrEqualTo;
	}
	public void setFciPenaltyIncomeLessThanOrEqualTo(Double fciPenaltyIncomeLessThanOrEqualTo) {
		this.fciPenaltyIncomeLessThanOrEqualTo = fciPenaltyIncomeLessThanOrEqualTo;
	}

	public Double getFciPenaltyIncomeLessThan() {
		return fciPenaltyIncomeLessThan;
	}
	public void setFciPenaltyIncomeLessThan(Double fciPenaltyIncomeLessThan) {
		this.fciPenaltyIncomeLessThan = fciPenaltyIncomeLessThan;
	}

	public Boolean getFciPenaltyIncomeIsNull() {
		return fciPenaltyIncomeIsNull;
	}
	public void setFciPenaltyIncomeIsNull(Boolean fciPenaltyIncomeIsNull) {
		this.fciPenaltyIncomeIsNull = fciPenaltyIncomeIsNull;
	}

	public Boolean getFciPenaltyIncomeIsNotNull() {
		return fciPenaltyIncomeIsNotNull;
	}
	public void setFciPenaltyIncomeIsNotNull(Boolean fciPenaltyIncomeIsNotNull) {
		this.fciPenaltyIncomeIsNotNull = fciPenaltyIncomeIsNotNull;
	}

	public java.util.List getFciPenaltyIncomeIn() {
		return fciPenaltyIncomeIn;
	}
	public void setFciPenaltyIncomeIn(java.util.List fciPenaltyIncomeIn) {
		this.fciPenaltyIncomeIn = fciPenaltyIncomeIn;
	}

	public Double getFciPenaltyIncomeGreaterThanOrEqualTo() {
		return fciPenaltyIncomeGreaterThanOrEqualTo;
	}
	public void setFciPenaltyIncomeGreaterThanOrEqualTo(Double fciPenaltyIncomeGreaterThanOrEqualTo) {
		this.fciPenaltyIncomeGreaterThanOrEqualTo = fciPenaltyIncomeGreaterThanOrEqualTo;
	}

	public Double getFciPenaltyIncomeGreaterThan() {
		return fciPenaltyIncomeGreaterThan;
	}
	public void setFciPenaltyIncomeGreaterThan(Double fciPenaltyIncomeGreaterThan) {
		this.fciPenaltyIncomeGreaterThan = fciPenaltyIncomeGreaterThan;
	}

	public Double getFciPenaltyIncomeEqualTo() {
		return fciPenaltyIncomeEqualTo;
	}
	public void setFciPenaltyIncomeEqualTo(Double fciPenaltyIncomeEqualTo) {
		this.fciPenaltyIncomeEqualTo = fciPenaltyIncomeEqualTo;
	}

	public java.util.List getFciIncomeMonthNotIn() {
		return fciIncomeMonthNotIn;
	}
	public void setFciIncomeMonthNotIn(java.util.List fciIncomeMonthNotIn) {
		this.fciIncomeMonthNotIn = fciIncomeMonthNotIn;
	}

	public java.util.Date getFciIncomeMonthNotEqualTo() {
		return fciIncomeMonthNotEqualTo;
	}
	public void setFciIncomeMonthNotEqualTo(java.util.Date fciIncomeMonthNotEqualTo) {
		this.fciIncomeMonthNotEqualTo = fciIncomeMonthNotEqualTo;
	}

	public java.util.Date getFciIncomeMonthLessThanOrEqualTo() {
		return fciIncomeMonthLessThanOrEqualTo;
	}
	public void setFciIncomeMonthLessThanOrEqualTo(java.util.Date fciIncomeMonthLessThanOrEqualTo) {
		this.fciIncomeMonthLessThanOrEqualTo = fciIncomeMonthLessThanOrEqualTo;
	}

	public java.util.Date getFciIncomeMonthLessThan() {
		return fciIncomeMonthLessThan;
	}
	public void setFciIncomeMonthLessThan(java.util.Date fciIncomeMonthLessThan) {
		this.fciIncomeMonthLessThan = fciIncomeMonthLessThan;
	}

	public Boolean getFciIncomeMonthIsNull() {
		return fciIncomeMonthIsNull;
	}
	public void setFciIncomeMonthIsNull(Boolean fciIncomeMonthIsNull) {
		this.fciIncomeMonthIsNull = fciIncomeMonthIsNull;
	}

	public Boolean getFciIncomeMonthIsNotNull() {
		return fciIncomeMonthIsNotNull;
	}
	public void setFciIncomeMonthIsNotNull(Boolean fciIncomeMonthIsNotNull) {
		this.fciIncomeMonthIsNotNull = fciIncomeMonthIsNotNull;
	}

	public java.util.List getFciIncomeMonthIn() {
		return fciIncomeMonthIn;
	}
	public void setFciIncomeMonthIn(java.util.List fciIncomeMonthIn) {
		this.fciIncomeMonthIn = fciIncomeMonthIn;
	}

	public java.util.Date getFciIncomeMonthGreaterThanOrEqualTo() {
		return fciIncomeMonthGreaterThanOrEqualTo;
	}
	public void setFciIncomeMonthGreaterThanOrEqualTo(java.util.Date fciIncomeMonthGreaterThanOrEqualTo) {
		this.fciIncomeMonthGreaterThanOrEqualTo = fciIncomeMonthGreaterThanOrEqualTo;
	}

	public java.util.Date getFciIncomeMonthGreaterThan() {
		return fciIncomeMonthGreaterThan;
	}
	public void setFciIncomeMonthGreaterThan(java.util.Date fciIncomeMonthGreaterThan) {
		this.fciIncomeMonthGreaterThan = fciIncomeMonthGreaterThan;
	}

	public java.util.Date getFciIncomeMonthEqualTo() {
		return fciIncomeMonthEqualTo;
	}
	public void setFciIncomeMonthEqualTo(java.util.Date fciIncomeMonthEqualTo) {
		this.fciIncomeMonthEqualTo = fciIncomeMonthEqualTo;
	}

	public java.util.List getFciIdNotIn() {
		return fciIdNotIn;
	}
	public void setFciIdNotIn(java.util.List fciIdNotIn) {
		this.fciIdNotIn = fciIdNotIn;
	}

	public Long getFciIdNotEqualTo() {
		return fciIdNotEqualTo;
	}
	public void setFciIdNotEqualTo(Long fciIdNotEqualTo) {
		this.fciIdNotEqualTo = fciIdNotEqualTo;
	}

	public Long getFciIdLessThanOrEqualTo() {
		return fciIdLessThanOrEqualTo;
	}
	public void setFciIdLessThanOrEqualTo(Long fciIdLessThanOrEqualTo) {
		this.fciIdLessThanOrEqualTo = fciIdLessThanOrEqualTo;
	}

	public Long getFciIdLessThan() {
		return fciIdLessThan;
	}
	public void setFciIdLessThan(Long fciIdLessThan) {
		this.fciIdLessThan = fciIdLessThan;
	}

	public Boolean getFciIdIsNull() {
		return fciIdIsNull;
	}
	public void setFciIdIsNull(Boolean fciIdIsNull) {
		this.fciIdIsNull = fciIdIsNull;
	}

	public Boolean getFciIdIsNotNull() {
		return fciIdIsNotNull;
	}
	public void setFciIdIsNotNull(Boolean fciIdIsNotNull) {
		this.fciIdIsNotNull = fciIdIsNotNull;
	}

	public java.util.List getFciIdIn() {
		return fciIdIn;
	}
	public void setFciIdIn(java.util.List fciIdIn) {
		this.fciIdIn = fciIdIn;
	}

	public Long getFciIdGreaterThanOrEqualTo() {
		return fciIdGreaterThanOrEqualTo;
	}
	public void setFciIdGreaterThanOrEqualTo(Long fciIdGreaterThanOrEqualTo) {
		this.fciIdGreaterThanOrEqualTo = fciIdGreaterThanOrEqualTo;
	}

	public Long getFciIdGreaterThan() {
		return fciIdGreaterThan;
	}
	public void setFciIdGreaterThan(Long fciIdGreaterThan) {
		this.fciIdGreaterThan = fciIdGreaterThan;
	}

	public Long getFciIdEqualTo() {
		return fciIdEqualTo;
	}
	public void setFciIdEqualTo(Long fciIdEqualTo) {
		this.fciIdEqualTo = fciIdEqualTo;
	}

	public java.util.List getFciDeptIdNotIn() {
		return fciDeptIdNotIn;
	}
	public void setFciDeptIdNotIn(java.util.List fciDeptIdNotIn) {
		this.fciDeptIdNotIn = fciDeptIdNotIn;
	}

	public Long getFciDeptIdNotEqualTo() {
		return fciDeptIdNotEqualTo;
	}
	public void setFciDeptIdNotEqualTo(Long fciDeptIdNotEqualTo) {
		this.fciDeptIdNotEqualTo = fciDeptIdNotEqualTo;
	}

	public Long getFciDeptIdLessThanOrEqualTo() {
		return fciDeptIdLessThanOrEqualTo;
	}
	public void setFciDeptIdLessThanOrEqualTo(Long fciDeptIdLessThanOrEqualTo) {
		this.fciDeptIdLessThanOrEqualTo = fciDeptIdLessThanOrEqualTo;
	}

	public Long getFciDeptIdLessThan() {
		return fciDeptIdLessThan;
	}
	public void setFciDeptIdLessThan(Long fciDeptIdLessThan) {
		this.fciDeptIdLessThan = fciDeptIdLessThan;
	}

	public Boolean getFciDeptIdIsNull() {
		return fciDeptIdIsNull;
	}
	public void setFciDeptIdIsNull(Boolean fciDeptIdIsNull) {
		this.fciDeptIdIsNull = fciDeptIdIsNull;
	}

	public Boolean getFciDeptIdIsNotNull() {
		return fciDeptIdIsNotNull;
	}
	public void setFciDeptIdIsNotNull(Boolean fciDeptIdIsNotNull) {
		this.fciDeptIdIsNotNull = fciDeptIdIsNotNull;
	}

	public java.util.List getFciDeptIdIn() {
		return fciDeptIdIn;
	}
	public void setFciDeptIdIn(java.util.List fciDeptIdIn) {
		this.fciDeptIdIn = fciDeptIdIn;
	}

	public Long getFciDeptIdGreaterThanOrEqualTo() {
		return fciDeptIdGreaterThanOrEqualTo;
	}
	public void setFciDeptIdGreaterThanOrEqualTo(Long fciDeptIdGreaterThanOrEqualTo) {
		this.fciDeptIdGreaterThanOrEqualTo = fciDeptIdGreaterThanOrEqualTo;
	}

	public Long getFciDeptIdGreaterThan() {
		return fciDeptIdGreaterThan;
	}
	public void setFciDeptIdGreaterThan(Long fciDeptIdGreaterThan) {
		this.fciDeptIdGreaterThan = fciDeptIdGreaterThan;
	}

	public Long getFciDeptIdEqualTo() {
		return fciDeptIdEqualTo;
	}
	public void setFciDeptIdEqualTo(Long fciDeptIdEqualTo) {
		this.fciDeptIdEqualTo = fciDeptIdEqualTo;
	}

	public java.util.List getFciCarPurchaseIncomeNotIn() {
		return fciCarPurchaseIncomeNotIn;
	}
	public void setFciCarPurchaseIncomeNotIn(java.util.List fciCarPurchaseIncomeNotIn) {
		this.fciCarPurchaseIncomeNotIn = fciCarPurchaseIncomeNotIn;
	}

	public Double getFciCarPurchaseIncomeNotEqualTo() {
		return fciCarPurchaseIncomeNotEqualTo;
	}
	public void setFciCarPurchaseIncomeNotEqualTo(Double fciCarPurchaseIncomeNotEqualTo) {
		this.fciCarPurchaseIncomeNotEqualTo = fciCarPurchaseIncomeNotEqualTo;
	}

	public Double getFciCarPurchaseIncomeLessThanOrEqualTo() {
		return fciCarPurchaseIncomeLessThanOrEqualTo;
	}
	public void setFciCarPurchaseIncomeLessThanOrEqualTo(Double fciCarPurchaseIncomeLessThanOrEqualTo) {
		this.fciCarPurchaseIncomeLessThanOrEqualTo = fciCarPurchaseIncomeLessThanOrEqualTo;
	}

	public Double getFciCarPurchaseIncomeLessThan() {
		return fciCarPurchaseIncomeLessThan;
	}
	public void setFciCarPurchaseIncomeLessThan(Double fciCarPurchaseIncomeLessThan) {
		this.fciCarPurchaseIncomeLessThan = fciCarPurchaseIncomeLessThan;
	}

	public Boolean getFciCarPurchaseIncomeIsNull() {
		return fciCarPurchaseIncomeIsNull;
	}
	public void setFciCarPurchaseIncomeIsNull(Boolean fciCarPurchaseIncomeIsNull) {
		this.fciCarPurchaseIncomeIsNull = fciCarPurchaseIncomeIsNull;
	}

	public Boolean getFciCarPurchaseIncomeIsNotNull() {
		return fciCarPurchaseIncomeIsNotNull;
	}
	public void setFciCarPurchaseIncomeIsNotNull(Boolean fciCarPurchaseIncomeIsNotNull) {
		this.fciCarPurchaseIncomeIsNotNull = fciCarPurchaseIncomeIsNotNull;
	}

	public java.util.List getFciCarPurchaseIncomeIn() {
		return fciCarPurchaseIncomeIn;
	}
	public void setFciCarPurchaseIncomeIn(java.util.List fciCarPurchaseIncomeIn) {
		this.fciCarPurchaseIncomeIn = fciCarPurchaseIncomeIn;
	}

	public Double getFciCarPurchaseIncomeGreaterThanOrEqualTo() {
		return fciCarPurchaseIncomeGreaterThanOrEqualTo;
	}
	public void setFciCarPurchaseIncomeGreaterThanOrEqualTo(Double fciCarPurchaseIncomeGreaterThanOrEqualTo) {
		this.fciCarPurchaseIncomeGreaterThanOrEqualTo = fciCarPurchaseIncomeGreaterThanOrEqualTo;
	}

	public Double getFciCarPurchaseIncomeGreaterThan() {
		return fciCarPurchaseIncomeGreaterThan;
	}
	public void setFciCarPurchaseIncomeGreaterThan(Double fciCarPurchaseIncomeGreaterThan) {
		this.fciCarPurchaseIncomeGreaterThan = fciCarPurchaseIncomeGreaterThan;
	}

	public Double getFciCarPurchaseIncomeEqualTo() {
		return fciCarPurchaseIncomeEqualTo;
	}
	public void setFciCarPurchaseIncomeEqualTo(Double fciCarPurchaseIncomeEqualTo) {
		this.fciCarPurchaseIncomeEqualTo = fciCarPurchaseIncomeEqualTo;
	}

	public java.util.List getDrNotIn() {
		return drNotIn;
	}
	public void setDrNotIn(java.util.List drNotIn) {
		this.drNotIn = drNotIn;
	}

	public Integer getDrNotEqualTo() {
		return drNotEqualTo;
	}
	public void setDrNotEqualTo(Integer drNotEqualTo) {
		this.drNotEqualTo = drNotEqualTo;
	}

	public Integer getDrLessThanOrEqualTo() {
		return drLessThanOrEqualTo;
	}
	public void setDrLessThanOrEqualTo(Integer drLessThanOrEqualTo) {
		this.drLessThanOrEqualTo = drLessThanOrEqualTo;
	}

	public Integer getDrLessThan() {
		return drLessThan;
	}
	public void setDrLessThan(Integer drLessThan) {
		this.drLessThan = drLessThan;
	}

	public Boolean getDrIsNull() {
		return drIsNull;
	}
	public void setDrIsNull(Boolean drIsNull) {
		this.drIsNull = drIsNull;
	}

	public Boolean getDrIsNotNull() {
		return drIsNotNull;
	}
	public void setDrIsNotNull(Boolean drIsNotNull) {
		this.drIsNotNull = drIsNotNull;
	}

	public java.util.List getDrIn() {
		return drIn;
	}
	public void setDrIn(java.util.List drIn) {
		this.drIn = drIn;
	}

	public Integer getDrGreaterThanOrEqualTo() {
		return drGreaterThanOrEqualTo;
	}
	public void setDrGreaterThanOrEqualTo(Integer drGreaterThanOrEqualTo) {
		this.drGreaterThanOrEqualTo = drGreaterThanOrEqualTo;
	}

	public Integer getDrGreaterThan() {
		return drGreaterThan;
	}
	public void setDrGreaterThan(Integer drGreaterThan) {
		this.drGreaterThan = drGreaterThan;
	}

	public Integer getDrEqualTo() {
		return drEqualTo;
	}
	public void setDrEqualTo(Integer drEqualTo) {
		this.drEqualTo = drEqualTo;
	}

	public String getCreateuserNotLike() {
		return createuserNotLike;
	}
	public void setCreateuserNotLike(String createuserNotLike) {
		this.createuserNotLike = createuserNotLike;
	}

	public java.util.List getCreateuserNotIn() {
		return createuserNotIn;
	}
	public void setCreateuserNotIn(java.util.List createuserNotIn) {
		this.createuserNotIn = createuserNotIn;
	}

	public String getCreateuserNotEqualTo() {
		return createuserNotEqualTo;
	}
	public void setCreateuserNotEqualTo(String createuserNotEqualTo) {
		this.createuserNotEqualTo = createuserNotEqualTo;
	}

	public String getCreateuserLike() {
		return createuserLike;
	}
	public void setCreateuserLike(String createuserLike) {
		this.createuserLike = createuserLike;
	}

	public String getCreateuserLessThanOrEqualTo() {
		return createuserLessThanOrEqualTo;
	}
	public void setCreateuserLessThanOrEqualTo(String createuserLessThanOrEqualTo) {
		this.createuserLessThanOrEqualTo = createuserLessThanOrEqualTo;
	}

	public String getCreateuserLessThan() {
		return createuserLessThan;
	}
	public void setCreateuserLessThan(String createuserLessThan) {
		this.createuserLessThan = createuserLessThan;
	}

	public Boolean getCreateuserIsNull() {
		return createuserIsNull;
	}
	public void setCreateuserIsNull(Boolean createuserIsNull) {
		this.createuserIsNull = createuserIsNull;
	}

	public Boolean getCreateuserIsNotNull() {
		return createuserIsNotNull;
	}
	public void setCreateuserIsNotNull(Boolean createuserIsNotNull) {
		this.createuserIsNotNull = createuserIsNotNull;
	}

	public java.util.List getCreateuserIn() {
		return createuserIn;
	}
	public void setCreateuserIn(java.util.List createuserIn) {
		this.createuserIn = createuserIn;
	}

	public String getCreateuserGreaterThanOrEqualTo() {
		return createuserGreaterThanOrEqualTo;
	}
	public void setCreateuserGreaterThanOrEqualTo(String createuserGreaterThanOrEqualTo) {
		this.createuserGreaterThanOrEqualTo = createuserGreaterThanOrEqualTo;
	}

	public String getCreateuserGreaterThan() {
		return createuserGreaterThan;
	}
	public void setCreateuserGreaterThan(String createuserGreaterThan) {
		this.createuserGreaterThan = createuserGreaterThan;
	}

	public String getCreateuserEqualTo() {
		return createuserEqualTo;
	}
	public void setCreateuserEqualTo(String createuserEqualTo) {
		this.createuserEqualTo = createuserEqualTo;
	}

	public java.util.List getCreatetimeNotIn() {
		return createtimeNotIn;
	}
	public void setCreatetimeNotIn(java.util.List createtimeNotIn) {
		this.createtimeNotIn = createtimeNotIn;
	}

	public java.util.Date getCreatetimeNotEqualTo() {
		return createtimeNotEqualTo;
	}
	public void setCreatetimeNotEqualTo(java.util.Date createtimeNotEqualTo) {
		this.createtimeNotEqualTo = createtimeNotEqualTo;
	}

	public java.util.Date getCreatetimeLessThanOrEqualTo() {
		return createtimeLessThanOrEqualTo;
	}
	public void setCreatetimeLessThanOrEqualTo(java.util.Date createtimeLessThanOrEqualTo) {
		this.createtimeLessThanOrEqualTo = createtimeLessThanOrEqualTo;
	}

	public java.util.Date getCreatetimeLessThan() {
		return createtimeLessThan;
	}
	public void setCreatetimeLessThan(java.util.Date createtimeLessThan) {
		this.createtimeLessThan = createtimeLessThan;
	}

	public Boolean getCreatetimeIsNull() {
		return createtimeIsNull;
	}
	public void setCreatetimeIsNull(Boolean createtimeIsNull) {
		this.createtimeIsNull = createtimeIsNull;
	}

	public Boolean getCreatetimeIsNotNull() {
		return createtimeIsNotNull;
	}
	public void setCreatetimeIsNotNull(Boolean createtimeIsNotNull) {
		this.createtimeIsNotNull = createtimeIsNotNull;
	}

	public java.util.List getCreatetimeIn() {
		return createtimeIn;
	}
	public void setCreatetimeIn(java.util.List createtimeIn) {
		this.createtimeIn = createtimeIn;
	}

	public java.util.Date getCreatetimeGreaterThanOrEqualTo() {
		return createtimeGreaterThanOrEqualTo;
	}
	public void setCreatetimeGreaterThanOrEqualTo(java.util.Date createtimeGreaterThanOrEqualTo) {
		this.createtimeGreaterThanOrEqualTo = createtimeGreaterThanOrEqualTo;
	}

	public java.util.Date getCreatetimeGreaterThan() {
		return createtimeGreaterThan;
	}
	public void setCreatetimeGreaterThan(java.util.Date createtimeGreaterThan) {
		this.createtimeGreaterThan = createtimeGreaterThan;
	}

	public java.util.Date getCreatetimeEqualTo() {
		return createtimeEqualTo;
	}
	public void setCreatetimeEqualTo(java.util.Date createtimeEqualTo) {
		this.createtimeEqualTo = createtimeEqualTo;
	}

	public void setSidx(String sidx) {
		this.sidx = sidx;
	}
	public String getSord() {
		return sord;
	}
	public void setSord(String sord) {
		 this.sord = sord;
	}
}
