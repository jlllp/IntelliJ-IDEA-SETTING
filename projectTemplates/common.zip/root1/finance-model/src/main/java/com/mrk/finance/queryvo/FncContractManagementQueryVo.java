package com.mrk.finance.queryvo;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.mrk.common.base.BaseQueryVo;
import io.swagger.annotations.ApiModelProperty;
import lombok.Getter;
import lombok.Setter;
import org.springframework.format.annotation.DateTimeFormat;

import java.util.List;

@Setter
@Getter
public class FncContractManagementQueryVo extends BaseQueryVo {



    @ApiModelProperty(value = "序号 精确匹配")
    private Long fcmIdEqualTo;

    @ApiModelProperty(value = "序号 模糊匹配")
    private Long fcmIdLike;

    @ApiModelProperty(value = "序号 In")
    private List<Long> fcmIdIn;


    @ApiModelProperty(value = "城市（废弃） 精确匹配")
    private Long fcmCityIdEqualTo;

    @ApiModelProperty(value = "城市（废弃） 模糊匹配")
    private Long fcmCityIdLike;


    @ApiModelProperty(value = "合同类型 0以租代售 1经营性租赁 2自营网约车_新租 3 营网约车_续租 4租赁合同 5租售合同 精确匹配")
    private Integer fcmContractTypeEqualTo;

    @ApiModelProperty(value = "合同类型 集合")
    private List<Integer> fcmContractTypeList;

    @ApiModelProperty(value = "合同类型 0以租代售 1经营性租赁 2自营网约车_新租 3 营网约车_续租 4租赁合同 5租售合同 模糊匹配")
    private Integer fcmContractTypeLike;

    private List<Integer> fcmContractStateIn;

    @ApiModelProperty(value = "合同编号 精确匹配")
    private String fcmContractNoEqualTo;

    @ApiModelProperty(value = "合同编号 模糊匹配")
    private String fcmContractNoLike;


    @ApiModelProperty(value = "甲方类型 1个人 2组织（废弃） 精确匹配")
    private Integer fcmPartyaTypeEqualTo;

    @ApiModelProperty(value = "甲方类型 1个人 2组织（废弃） 模糊匹配")
    private Integer fcmPartyaTypeLike;


    @ApiModelProperty(value = "甲方ID 精确匹配")
    private Long fcmPartyaIdEqualTo;

    @ApiModelProperty(value = "甲方ID 模糊匹配")
    private Long fcmPartyaIdLike;


    @ApiModelProperty(value = "乙方类型 1个人 2组织 精确匹配")
    private Integer fcmPartybTypeEqualTo;

    @ApiModelProperty(value = "乙方类型 1个人 2组织 模糊匹配")
    private Integer fcmPartybTypeLike;


    @ApiModelProperty(value = "乙方ID 精确匹配")
    private Long fcmPartybIdEqualTo;

    @ApiModelProperty(value = "乙方ID 模糊匹配")
    private Long fcmPartybIdLike;


    @ApiModelProperty(value = "车型ID 精确匹配")
    private Long fcmCarTypeIdEqualTo;

    @ApiModelProperty(value = "车型ID 模糊匹配")
    private Long fcmCarTypeIdLike;


    @ApiModelProperty(value = "运营平台（废弃） 精确匹配")
    private Integer fcmOperatPlatformEqualTo;

    @ApiModelProperty(value = "运营平台（废弃） 模糊匹配")
    private Integer fcmOperatPlatformLike;


    @ApiModelProperty(value = "签订日期 大于或等于")
    @DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss", timezone = "GMT+8")
    private java.util.Date fcmSignedDateGreaterThanOrEqualTo;

    @DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss", timezone = "GMT+8")
    @ApiModelProperty(value = "签订日期 小于或等于")
    private java.util.Date fcmSignedDateLessThanOrEqualTo;
    @ApiModelProperty(value = "签订日期 精确匹配")
    private java.util.Date fcmSignedDateEqualTo;

    @ApiModelProperty(value = "签订日期 模糊匹配")
    private java.util.Date fcmSignedDateLike;


    @ApiModelProperty(value = "租赁类型 0无 1自然周期 2相对周期 精确匹配")
    private Integer fcmLeaseCalculateTypeEqualTo;

    @ApiModelProperty(value = "租赁类型 0无 1自然周期 2相对周期 模糊匹配")
    private Integer fcmLeaseCalculateTypeLike;


    @ApiModelProperty(value = "租期（月） 精确匹配")
    private Integer fcmLeaseCountEqualTo;

    @ApiModelProperty(value = "租期（月） 模糊匹配")
    private Integer fcmLeaseCountLike;


    @ApiModelProperty(value = "租赁起始类型 0确定日期 1交车日期 精确匹配")
    private Integer fcmLeaseStartTypeEqualTo;

    @ApiModelProperty(value = "租赁起始类型 0确定日期 1交车日期 模糊匹配")
    private Integer fcmLeaseStartTypeLike;


    @ApiModelProperty(value = "租赁起始日期 大于或等于")
    @DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss", timezone = "GMT+8")
    private java.util.Date fcmLeaseStartDateGreaterThanOrEqualTo;

    @DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss", timezone = "GMT+8")
    @ApiModelProperty(value = "租赁起始日期 小于或等于")
    private java.util.Date fcmLeaseStartDateLessThanOrEqualTo;
    @ApiModelProperty(value = "租赁起始日期 精确匹配")
    private java.util.Date fcmLeaseStartDateEqualTo;

    @ApiModelProperty(value = "租赁起始日期 模糊匹配")
    private java.util.Date fcmLeaseStartDateLike;


    @ApiModelProperty(value = "租赁结束日期 大于或等于")
    @DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss", timezone = "GMT+8")
    private java.util.Date fcmLeaseEndDateGreaterThanOrEqualTo;

    @DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss", timezone = "GMT+8")
    @ApiModelProperty(value = "租赁结束日期 小于或等于")
    private java.util.Date fcmLeaseEndDateLessThanOrEqualTo;
    @ApiModelProperty(value = "租赁结束日期 精确匹配")
    private java.util.Date fcmLeaseEndDateEqualTo;

    @ApiModelProperty(value = "租赁结束日期 模糊匹配")
    private java.util.Date fcmLeaseEndDateLike;


    @ApiModelProperty(value = "租赁类型 0固定 1不固定 精确匹配")
    private Integer fcmLeaseTypeEqualTo;

    @ApiModelProperty(value = "租赁类型 0固定 1不固定 模糊匹配")
    private Integer fcmLeaseTypeLike;


    @ApiModelProperty(value = "租金金额 精确匹配")
    private Double fcmLeaseAmountEqualTo;

    @ApiModelProperty(value = "租金金额 模糊匹配")
    private Double fcmLeaseAmountLike;


    @ApiModelProperty(value = "租金支付类型 0自然周期 1相对周期 精确匹配")
    private Integer fcmRentPayTypeEqualTo;

    @ApiModelProperty(value = "租金支付类型 0自然周期 1相对周期 模糊匹配")
    private Integer fcmRentPayTypeLike;


    @ApiModelProperty(value = "租金支付周期 精确匹配")
    private Integer fcmRentPayCycleEqualTo;

    @ApiModelProperty(value = "租金支付周期 模糊匹配")
    private Integer fcmRentPayCycleLike;


    @ApiModelProperty(value = "赠送租期（废弃） 精确匹配")
    private Integer fcmGiveLeaseEqualTo;

    @ApiModelProperty(value = "赠送租期（废弃） 模糊匹配")
    private Integer fcmGiveLeaseLike;


    @ApiModelProperty(value = "赠送顺序（废弃） 精确匹配")
    private Integer fcmGiveSequenceEqualTo;

    @ApiModelProperty(value = "赠送顺序（废弃） 模糊匹配")
    private Integer fcmGiveSequenceLike;


    @ApiModelProperty(value = "账单生成类型 精确匹配")
    private Integer fcmBillGenerateTypeEqualTo;

    @ApiModelProperty(value = "账单生成类型 模糊匹配")
    private Integer fcmBillGenerateTypeLike;


    @ApiModelProperty(value = "账单生成间隔 精确匹配")
    private Integer fcmBillGenerateIntervalEqualTo;

    @ApiModelProperty(value = "账单生成间隔 模糊匹配")
    private Integer fcmBillGenerateIntervalLike;


    @ApiModelProperty(value = "账单截止类型 精确匹配")
    private Integer fcmBillCatoffTypeEqualTo;

    @ApiModelProperty(value = "账单截止类型 模糊匹配")
    private Integer fcmBillCatoffTypeLike;


    @ApiModelProperty(value = "账单截止间隔 精确匹配")
    private Integer fcmBillCatoffIntervalEqualTo;

    @ApiModelProperty(value = "账单截止间隔 模糊匹配")
    private Integer fcmBillCatoffIntervalLike;


    @ApiModelProperty(value = "车辆总数 精确匹配")
    private Integer fcmCarnumTotalEqualTo;

    @ApiModelProperty(value = "车辆总数 模糊匹配")
    private Integer fcmCarnumTotalLike;


    @ApiModelProperty(value = "单车保证金 精确匹配")
    private Double fcmSingleMarginEqualTo;

    @ApiModelProperty(value = "单车保证金 模糊匹配")
    private Double fcmSingleMarginLike;


    @ApiModelProperty(value = "保证金支付要求 0提车前一次性支付 1每次提车前分批支付 2灵活支付 精确匹配")
    private Integer fcmMarginPayRequireEqualTo;

    @ApiModelProperty(value = "保证金支付要求 0提车前一次性支付 1每次提车前分批支付 2灵活支付 模糊匹配")
    private Integer fcmMarginPayRequireLike;


    @ApiModelProperty(value = "租金总额 精确匹配")
    private Double fcmLeaseAmountTotalEqualTo;

    @ApiModelProperty(value = "租金总额 模糊匹配")
    private Double fcmLeaseAmountTotalLike;


    @ApiModelProperty(value = "保证金类型 0无 1总额 2单车 精确匹配")
    private Integer fcmMarginTypeEqualTo;

    @ApiModelProperty(value = "保证金类型 0无 1总额 2单车 模糊匹配")
    private Integer fcmMarginTypeLike;


    @ApiModelProperty(value = "保证金金额 精确匹配")
    private Double fcmMarginMoneyEqualTo;

    @ApiModelProperty(value = "保证金金额 模糊匹配")
    private Double fcmMarginMoneyLike;


    @ApiModelProperty(value = "保证金总额 精确匹配")
    private Double fcmMarginTotalEqualTo;

    @ApiModelProperty(value = "保证金总额 模糊匹配")
    private Double fcmMarginTotalLike;


    @ApiModelProperty(value = "车辆购车尾款（废弃） 精确匹配")
    private Double fcmCarPurchaseEqualTo;

    @ApiModelProperty(value = "车辆购车尾款（废弃） 模糊匹配")
    private Double fcmCarPurchaseLike;


    @ApiModelProperty(value = "保底租金 精确匹配")
    private Double fcmBoldRentEqualTo;

    @ApiModelProperty(value = "保底租金 模糊匹配")
    private Double fcmBoldRentLike;


    @ApiModelProperty(value = "提前购车价计算方式（废弃） 精确匹配")
    private String fcmCarPurchaseAdvanceEqualTo;

    @ApiModelProperty(value = "提前购车价计算方式（废弃） 模糊匹配")
    private String fcmCarPurchaseAdvanceLike;


    @ApiModelProperty(value = "合同状态 0租赁待开始 1租赁中 2租赁中止 3租赁结束 精确匹配")
    private Integer fcmContractStateEqualTo;

    @ApiModelProperty(value = "合同状态 0租赁待开始 1租赁中 2租赁中止 3租赁结束 模糊匹配")
    private Integer fcmContractStateLike;


    @ApiModelProperty(value = "结算状态 精确匹配")
    private Integer fcmSettlementStateEqualTo;

    @ApiModelProperty(value = "结算状态 模糊匹配")
    private Integer fcmSettlementStateLike;


    @ApiModelProperty(value = "关联合同ID（废弃） 精确匹配")
    private Long fcmAssociateContractIdEqualTo;

    @ApiModelProperty(value = "关联合同ID（废弃） 模糊匹配")
    private Long fcmAssociateContractIdLike;


    @ApiModelProperty(value = "关联合同编号（废弃） 精确匹配")
    private String fcmAssociateContractNoEqualTo;

    @ApiModelProperty(value = "关联合同编号（废弃） 模糊匹配")
    private String fcmAssociateContractNoLike;


    @ApiModelProperty(value = "收车工单是否处理标识 0未处理 1已处理 精确匹配")
    private Integer fncTurnerSingleDealEqualTo;

    @ApiModelProperty(value = "收车工单是否处理标识 0未处理 1已处理 模糊匹配")
    private Integer fncTurnerSingleDealLike;


    @ApiModelProperty(value = "车辆性质 精确匹配")
    private String fcmCarNatureEqualTo;

    @ApiModelProperty(value = "车辆性质 模糊匹配")
    private String fcmCarNatureLike;


    @ApiModelProperty(value = "交车地点 精确匹配")
    private Long fcmDeliverCityEqualTo;

    @ApiModelProperty(value = "交车地点 模糊匹配")
    private Long fcmDeliverCityLike;


    @ApiModelProperty(value = "归还地点 精确匹配")
    private Long fcmReturnCityEqualTo;

    @ApiModelProperty(value = "归还地点 模糊匹配")
    private Long fcmReturnCityLike;


    @ApiModelProperty(value = "车辆交付方式 0无 1交车前一次性交付 2分批交付 精确匹配")
    private Integer fcmDeliverTypeEqualTo;

    @ApiModelProperty(value = "车辆交付方式 0无 1交车前一次性交付 2分批交付 模糊匹配")
    private Integer fcmDeliverTypeLike;


    @ApiModelProperty(value = "是否可以转租 0无 1是 2否 精确匹配")
    private Integer fcmSubletEqualTo;

    @ApiModelProperty(value = "是否可以转租 0无 1是 2否 模糊匹配")
    private Integer fcmSubletLike;


    @ApiModelProperty(value = "签订地点 精确匹配")
    private Long fcmSignedAddrEqualTo;

    @ApiModelProperty(value = "签订地点 模糊匹配")
    private Long fcmSignedAddrLike;


    @ApiModelProperty(value = "合同创建人手机号 精确匹配")
    private String fcmCreatePhoneEqualTo;

    @ApiModelProperty(value = "合同创建人手机号 模糊匹配")
    private String fcmCreatePhoneLike;


    @ApiModelProperty(value = "用途 精确匹配")
    private String fcmUseEqualTo;

    @ApiModelProperty(value = "用途 模糊匹配")
    private String fcmUseLike;

    @ApiModelProperty(value = "附件上传状态")
    private Integer typeState;

    }
