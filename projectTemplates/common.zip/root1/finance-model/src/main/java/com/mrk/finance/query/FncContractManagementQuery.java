package com.mrk.finance.query;
import com.mrk.common.utils.text.CheckUtil;

/**
 * @author 自动生成工具
 * @date   2022/06/16 
 */
public class FncContractManagementQuery {
	private java.lang.String updateuserNotLike;
	private java.util.List updateuserNotIn;
	private java.lang.String updateuserNotEqualTo;
	private java.lang.String updateuserLike;
	private java.lang.String updateuserLessThanOrEqualTo;
	private java.lang.String updateuserLessThan;
	private java.lang.Boolean updateuserIsNull;
	private java.lang.Boolean updateuserIsNotNull;
	private java.util.List updateuserIn;
	private java.lang.String updateuserGreaterThanOrEqualTo;
	private java.lang.String updateuserGreaterThan;
	private java.lang.String updateuserEqualTo;
	private java.util.List updatetimeNotIn;
	private java.util.Date updatetimeNotEqualTo;
	private java.util.Date updatetimeLessThanOrEqualTo;
	private java.util.Date updatetimeLessThan;
	private java.lang.Boolean updatetimeIsNull;
	private java.lang.Boolean updatetimeIsNotNull;
	private java.util.List updatetimeIn;
	private java.util.Date updatetimeGreaterThanOrEqualTo;
	private java.util.Date updatetimeGreaterThan;
	private java.util.Date updatetimeEqualTo;
	private java.lang.String remarkNotLike;
	private java.util.List remarkNotIn;
	private java.lang.String remarkNotEqualTo;
	private java.lang.String remarkLike;
	private java.lang.String remarkLessThanOrEqualTo;
	private java.lang.String remarkLessThan;
	private java.lang.Boolean remarkIsNull;
	private java.lang.Boolean remarkIsNotNull;
	private java.util.List remarkIn;
	private java.lang.String remarkGreaterThanOrEqualTo;
	private java.lang.String remarkGreaterThan;
	private java.lang.String remarkEqualTo;
	private java.util.List fncTurnerSingleDealNotIn;
	private java.lang.Integer fncTurnerSingleDealNotEqualTo;
	private java.lang.Integer fncTurnerSingleDealLessThanOrEqualTo;
	private java.lang.Integer fncTurnerSingleDealLessThan;
	private java.lang.Boolean fncTurnerSingleDealIsNull;
	private java.lang.Boolean fncTurnerSingleDealIsNotNull;
	private java.util.List fncTurnerSingleDealIn;
	private java.lang.Integer fncTurnerSingleDealGreaterThanOrEqualTo;
	private java.lang.Integer fncTurnerSingleDealGreaterThan;
	private java.lang.Integer fncTurnerSingleDealEqualTo;
	private java.lang.String fcmUseNotLike;
	private java.util.List fcmUseNotIn;
	private java.lang.String fcmUseNotEqualTo;
	private java.lang.String fcmUseLike;
	private java.lang.String fcmUseLessThanOrEqualTo;
	private java.lang.String fcmUseLessThan;
	private java.lang.Boolean fcmUseIsNull;
	private java.lang.Boolean fcmUseIsNotNull;
	private java.util.List fcmUseIn;
	private java.lang.String fcmUseGreaterThanOrEqualTo;
	private java.lang.String fcmUseGreaterThan;
	private java.lang.String fcmUseEqualTo;
	private java.util.List fcmSubletNotIn;
	private java.lang.Integer fcmSubletNotEqualTo;
	private java.lang.Integer fcmSubletLessThanOrEqualTo;
	private java.lang.Integer fcmSubletLessThan;
	private java.lang.Boolean fcmSubletIsNull;
	private java.lang.Boolean fcmSubletIsNotNull;
	private java.util.List fcmSubletIn;
	private java.lang.Integer fcmSubletGreaterThanOrEqualTo;
	private java.lang.Integer fcmSubletGreaterThan;
	private java.lang.Integer fcmSubletEqualTo;
	private java.util.List fcmSingleMarginNotIn;
	private java.lang.Double fcmSingleMarginNotEqualTo;
	private java.lang.Double fcmSingleMarginLessThanOrEqualTo;
	private java.lang.Double fcmSingleMarginLessThan;
	private java.lang.Boolean fcmSingleMarginIsNull;
	private java.lang.Boolean fcmSingleMarginIsNotNull;
	private java.util.List fcmSingleMarginIn;
	private java.lang.Double fcmSingleMarginGreaterThanOrEqualTo;
	private java.lang.Double fcmSingleMarginGreaterThan;
	private java.lang.Double fcmSingleMarginEqualTo;
	private java.util.List fcmSignedDateNotIn;
	private java.util.Date fcmSignedDateNotEqualTo;
	private java.util.Date fcmSignedDateLessThanOrEqualTo;
	private java.util.Date fcmSignedDateLessThan;
	private java.lang.Boolean fcmSignedDateIsNull;
	private java.lang.Boolean fcmSignedDateIsNotNull;
	private java.util.List fcmSignedDateIn;
	private java.util.Date fcmSignedDateGreaterThanOrEqualTo;
	private java.util.Date fcmSignedDateGreaterThan;
	private java.util.Date fcmSignedDateEqualTo;
	private java.util.List fcmSignedAddrNotIn;
	private java.lang.Long fcmSignedAddrNotEqualTo;
	private java.lang.Long fcmSignedAddrLessThanOrEqualTo;
	private java.lang.Long fcmSignedAddrLessThan;
	private java.lang.Boolean fcmSignedAddrIsNull;
	private java.lang.Boolean fcmSignedAddrIsNotNull;
	private java.util.List fcmSignedAddrIn;
	private java.lang.Long fcmSignedAddrGreaterThanOrEqualTo;
	private java.lang.Long fcmSignedAddrGreaterThan;
	private java.lang.Long fcmSignedAddrEqualTo;
	private java.util.List fcmSettlementStateNotIn;
	private java.lang.Integer fcmSettlementStateNotEqualTo;
	private java.lang.Integer fcmSettlementStateLessThanOrEqualTo;
	private java.lang.Integer fcmSettlementStateLessThan;
	private java.lang.Boolean fcmSettlementStateIsNull;
	private java.lang.Boolean fcmSettlementStateIsNotNull;
	private java.util.List fcmSettlementStateIn;
	private java.lang.Integer fcmSettlementStateGreaterThanOrEqualTo;
	private java.lang.Integer fcmSettlementStateGreaterThan;
	private java.lang.Integer fcmSettlementStateEqualTo;
	private java.util.List fcmReturnCityNotIn;
	private java.lang.Long fcmReturnCityNotEqualTo;
	private java.lang.Long fcmReturnCityLessThanOrEqualTo;
	private java.lang.Long fcmReturnCityLessThan;
	private java.lang.Boolean fcmReturnCityIsNull;
	private java.lang.Boolean fcmReturnCityIsNotNull;
	private java.util.List fcmReturnCityIn;
	private java.lang.Long fcmReturnCityGreaterThanOrEqualTo;
	private java.lang.Long fcmReturnCityGreaterThan;
	private java.lang.Long fcmReturnCityEqualTo;
	private java.util.List fcmRentPayTypeNotIn;
	private java.lang.Integer fcmRentPayTypeNotEqualTo;
	private java.lang.Integer fcmRentPayTypeLessThanOrEqualTo;
	private java.lang.Integer fcmRentPayTypeLessThan;
	private java.lang.Boolean fcmRentPayTypeIsNull;
	private java.lang.Boolean fcmRentPayTypeIsNotNull;
	private java.util.List fcmRentPayTypeIn;
	private java.lang.Integer fcmRentPayTypeGreaterThanOrEqualTo;
	private java.lang.Integer fcmRentPayTypeGreaterThan;
	private java.lang.Integer fcmRentPayTypeEqualTo;
	private java.util.List fcmRentPayCycleNotIn;
	private java.lang.Integer fcmRentPayCycleNotEqualTo;
	private java.lang.Integer fcmRentPayCycleLessThanOrEqualTo;
	private java.lang.Integer fcmRentPayCycleLessThan;
	private java.lang.Boolean fcmRentPayCycleIsNull;
	private java.lang.Boolean fcmRentPayCycleIsNotNull;
	private java.util.List fcmRentPayCycleIn;
	private java.lang.Integer fcmRentPayCycleGreaterThanOrEqualTo;
	private java.lang.Integer fcmRentPayCycleGreaterThan;
	private java.lang.Integer fcmRentPayCycleEqualTo;
	private java.util.List fcmPartybTypeNotIn;
	private java.lang.Integer fcmPartybTypeNotEqualTo;
	private java.lang.Integer fcmPartybTypeLessThanOrEqualTo;
	private java.lang.Integer fcmPartybTypeLessThan;
	private java.lang.Boolean fcmPartybTypeIsNull;
	private java.lang.Boolean fcmPartybTypeIsNotNull;
	private java.util.List fcmPartybTypeIn;
	private java.lang.Integer fcmPartybTypeGreaterThanOrEqualTo;
	private java.lang.Integer fcmPartybTypeGreaterThan;
	private java.lang.Integer fcmPartybTypeEqualTo;
	private java.util.List fcmPartybIdNotIn;
	private java.lang.Long fcmPartybIdNotEqualTo;
	private java.lang.Long fcmPartybIdLessThanOrEqualTo;
	private java.lang.Long fcmPartybIdLessThan;
	private java.lang.Boolean fcmPartybIdIsNull;
	private java.lang.Boolean fcmPartybIdIsNotNull;
	private java.util.List fcmPartybIdIn;
	private java.lang.Long fcmPartybIdGreaterThanOrEqualTo;
	private java.lang.Long fcmPartybIdGreaterThan;
	private java.lang.Long fcmPartybIdEqualTo;
	private java.util.List fcmPartyaTypeNotIn;
	private java.lang.Integer fcmPartyaTypeNotEqualTo;
	private java.lang.Integer fcmPartyaTypeLessThanOrEqualTo;
	private java.lang.Integer fcmPartyaTypeLessThan;
	private java.lang.Boolean fcmPartyaTypeIsNull;
	private java.lang.Boolean fcmPartyaTypeIsNotNull;
	private java.util.List fcmPartyaTypeIn;
	private java.lang.Integer fcmPartyaTypeGreaterThanOrEqualTo;
	private java.lang.Integer fcmPartyaTypeGreaterThan;
	private java.lang.Integer fcmPartyaTypeEqualTo;
	private java.util.List fcmPartyaIdNotIn;
	private java.lang.Long fcmPartyaIdNotEqualTo;
	private java.lang.Long fcmPartyaIdLessThanOrEqualTo;
	private java.lang.Long fcmPartyaIdLessThan;
	private java.lang.Boolean fcmPartyaIdIsNull;
	private java.lang.Boolean fcmPartyaIdIsNotNull;
	private java.util.List fcmPartyaIdIn;
	private java.lang.Long fcmPartyaIdGreaterThanOrEqualTo;
	private java.lang.Long fcmPartyaIdGreaterThan;
	private java.lang.Long fcmPartyaIdEqualTo;
	private java.util.List fcmOperatPlatformNotIn;
	private java.lang.Integer fcmOperatPlatformNotEqualTo;
	private java.lang.Integer fcmOperatPlatformLessThanOrEqualTo;
	private java.lang.Integer fcmOperatPlatformLessThan;
	private java.lang.Boolean fcmOperatPlatformIsNull;
	private java.lang.Boolean fcmOperatPlatformIsNotNull;
	private java.util.List fcmOperatPlatformIn;
	private java.lang.Integer fcmOperatPlatformGreaterThanOrEqualTo;
	private java.lang.Integer fcmOperatPlatformGreaterThan;
	private java.lang.Integer fcmOperatPlatformEqualTo;
	private java.util.List fcmMarginTypeNotIn;
	private java.lang.Integer fcmMarginTypeNotEqualTo;
	private java.lang.Integer fcmMarginTypeLessThanOrEqualTo;
	private java.lang.Integer fcmMarginTypeLessThan;
	private java.lang.Boolean fcmMarginTypeIsNull;
	private java.lang.Boolean fcmMarginTypeIsNotNull;
	private java.util.List fcmMarginTypeIn;
	private java.lang.Integer fcmMarginTypeGreaterThanOrEqualTo;
	private java.lang.Integer fcmMarginTypeGreaterThan;
	private java.lang.Integer fcmMarginTypeEqualTo;
	private java.util.List fcmMarginTotalNotIn;
	private java.lang.Double fcmMarginTotalNotEqualTo;
	private java.lang.Double fcmMarginTotalLessThanOrEqualTo;
	private java.lang.Double fcmMarginTotalLessThan;
	private java.lang.Boolean fcmMarginTotalIsNull;
	private java.lang.Boolean fcmMarginTotalIsNotNull;
	private java.util.List fcmMarginTotalIn;
	private java.lang.Double fcmMarginTotalGreaterThanOrEqualTo;
	private java.lang.Double fcmMarginTotalGreaterThan;
	private java.lang.Double fcmMarginTotalEqualTo;
	private java.util.List fcmMarginPayRequireNotIn;
	private java.lang.Integer fcmMarginPayRequireNotEqualTo;
	private java.lang.Integer fcmMarginPayRequireLessThanOrEqualTo;
	private java.lang.Integer fcmMarginPayRequireLessThan;
	private java.lang.Boolean fcmMarginPayRequireIsNull;
	private java.lang.Boolean fcmMarginPayRequireIsNotNull;
	private java.util.List fcmMarginPayRequireIn;
	private java.lang.Integer fcmMarginPayRequireGreaterThanOrEqualTo;
	private java.lang.Integer fcmMarginPayRequireGreaterThan;
	private java.lang.Integer fcmMarginPayRequireEqualTo;
	private java.util.List fcmMarginMoneyNotIn;
	private java.lang.Double fcmMarginMoneyNotEqualTo;
	private java.lang.Double fcmMarginMoneyLessThanOrEqualTo;
	private java.lang.Double fcmMarginMoneyLessThan;
	private java.lang.Boolean fcmMarginMoneyIsNull;
	private java.lang.Boolean fcmMarginMoneyIsNotNull;
	private java.util.List fcmMarginMoneyIn;
	private java.lang.Double fcmMarginMoneyGreaterThanOrEqualTo;
	private java.lang.Double fcmMarginMoneyGreaterThan;
	private java.lang.Double fcmMarginMoneyEqualTo;
	private java.util.List fcmLeaseTypeNotIn;
	private java.lang.Integer fcmLeaseTypeNotEqualTo;
	private java.lang.Integer fcmLeaseTypeLessThanOrEqualTo;
	private java.lang.Integer fcmLeaseTypeLessThan;
	private java.lang.Boolean fcmLeaseTypeIsNull;
	private java.lang.Boolean fcmLeaseTypeIsNotNull;
	private java.util.List fcmLeaseTypeIn;
	private java.lang.Integer fcmLeaseTypeGreaterThanOrEqualTo;
	private java.lang.Integer fcmLeaseTypeGreaterThan;
	private java.lang.Integer fcmLeaseTypeEqualTo;
	private java.util.List fcmLeaseStartTypeNotIn;
	private java.lang.Integer fcmLeaseStartTypeNotEqualTo;
	private java.lang.Integer fcmLeaseStartTypeLessThanOrEqualTo;
	private java.lang.Integer fcmLeaseStartTypeLessThan;
	private java.lang.Boolean fcmLeaseStartTypeIsNull;
	private java.lang.Boolean fcmLeaseStartTypeIsNotNull;
	private java.util.List fcmLeaseStartTypeIn;
	private java.lang.Integer fcmLeaseStartTypeGreaterThanOrEqualTo;
	private java.lang.Integer fcmLeaseStartTypeGreaterThan;
	private java.lang.Integer fcmLeaseStartTypeEqualTo;
	private java.util.List fcmLeaseStartDateNotIn;
	private java.util.Date fcmLeaseStartDateNotEqualTo;
	private java.util.Date fcmLeaseStartDateLessThanOrEqualTo;
	private java.util.Date fcmLeaseStartDateLessThan;
	private java.lang.Boolean fcmLeaseStartDateIsNull;
	private java.lang.Boolean fcmLeaseStartDateIsNotNull;
	private java.util.List fcmLeaseStartDateIn;
	private java.util.Date fcmLeaseStartDateGreaterThanOrEqualTo;
	private java.util.Date fcmLeaseStartDateGreaterThan;
	private java.util.Date fcmLeaseStartDateEqualTo;
	private java.util.List fcmLeaseEndDateNotIn;
	private java.util.Date fcmLeaseEndDateNotEqualTo;
	private java.util.Date fcmLeaseEndDateLessThanOrEqualTo;
	private java.util.Date fcmLeaseEndDateLessThan;
	private java.lang.Boolean fcmLeaseEndDateIsNull;
	private java.lang.Boolean fcmLeaseEndDateIsNotNull;
	private java.util.List fcmLeaseEndDateIn;
	private java.util.Date fcmLeaseEndDateGreaterThanOrEqualTo;
	private java.util.Date fcmLeaseEndDateGreaterThan;
	private java.util.Date fcmLeaseEndDateEqualTo;
	private java.util.List fcmLeaseCountNotIn;
	private java.lang.Integer fcmLeaseCountNotEqualTo;
	private java.lang.Integer fcmLeaseCountLessThanOrEqualTo;
	private java.lang.Integer fcmLeaseCountLessThan;
	private java.lang.Boolean fcmLeaseCountIsNull;
	private java.lang.Boolean fcmLeaseCountIsNotNull;
	private java.util.List fcmLeaseCountIn;
	private java.lang.Integer fcmLeaseCountGreaterThanOrEqualTo;
	private java.lang.Integer fcmLeaseCountGreaterThan;
	private java.lang.Integer fcmLeaseCountEqualTo;
	private java.util.List fcmLeaseCalculateTypeNotIn;
	private java.lang.Integer fcmLeaseCalculateTypeNotEqualTo;
	private java.lang.Integer fcmLeaseCalculateTypeLessThanOrEqualTo;
	private java.lang.Integer fcmLeaseCalculateTypeLessThan;
	private java.lang.Boolean fcmLeaseCalculateTypeIsNull;
	private java.lang.Boolean fcmLeaseCalculateTypeIsNotNull;
	private java.util.List fcmLeaseCalculateTypeIn;
	private java.lang.Integer fcmLeaseCalculateTypeGreaterThanOrEqualTo;
	private java.lang.Integer fcmLeaseCalculateTypeGreaterThan;
	private java.lang.Integer fcmLeaseCalculateTypeEqualTo;
	private java.util.List fcmLeaseAmountTotalNotIn;
	private java.lang.Double fcmLeaseAmountTotalNotEqualTo;
	private java.lang.Double fcmLeaseAmountTotalLessThanOrEqualTo;
	private java.lang.Double fcmLeaseAmountTotalLessThan;
	private java.lang.Boolean fcmLeaseAmountTotalIsNull;
	private java.lang.Boolean fcmLeaseAmountTotalIsNotNull;
	private java.util.List fcmLeaseAmountTotalIn;
	private java.lang.Double fcmLeaseAmountTotalGreaterThanOrEqualTo;
	private java.lang.Double fcmLeaseAmountTotalGreaterThan;
	private java.lang.Double fcmLeaseAmountTotalEqualTo;
	private java.util.List fcmLeaseAmountNotIn;
	private java.lang.Double fcmLeaseAmountNotEqualTo;
	private java.lang.Double fcmLeaseAmountLessThanOrEqualTo;
	private java.lang.Double fcmLeaseAmountLessThan;
	private java.lang.Boolean fcmLeaseAmountIsNull;
	private java.lang.Boolean fcmLeaseAmountIsNotNull;
	private java.util.List fcmLeaseAmountIn;
	private java.lang.Double fcmLeaseAmountGreaterThanOrEqualTo;
	private java.lang.Double fcmLeaseAmountGreaterThan;
	private java.lang.Double fcmLeaseAmountEqualTo;
	private java.util.List fcmIdNotIn;
	private java.lang.Long fcmIdNotEqualTo;
	private java.lang.Long fcmIdLessThanOrEqualTo;
	private java.lang.Long fcmIdLessThan;
	private java.lang.Boolean fcmIdIsNull;
	private java.lang.Boolean fcmIdIsNotNull;
	private java.util.List fcmIdIn;
	private java.lang.Long fcmIdGreaterThanOrEqualTo;
	private java.lang.Long fcmIdGreaterThan;
	private java.lang.Long fcmIdEqualTo;
	private java.util.List fcmGiveSequenceNotIn;
	private java.lang.Integer fcmGiveSequenceNotEqualTo;
	private java.lang.Integer fcmGiveSequenceLessThanOrEqualTo;
	private java.lang.Integer fcmGiveSequenceLessThan;
	private java.lang.Boolean fcmGiveSequenceIsNull;
	private java.lang.Boolean fcmGiveSequenceIsNotNull;
	private java.util.List fcmGiveSequenceIn;
	private java.lang.Integer fcmGiveSequenceGreaterThanOrEqualTo;
	private java.lang.Integer fcmGiveSequenceGreaterThan;
	private java.lang.Integer fcmGiveSequenceEqualTo;
	private java.util.List fcmGiveLeaseNotIn;
	private java.lang.Integer fcmGiveLeaseNotEqualTo;
	private java.lang.Integer fcmGiveLeaseLessThanOrEqualTo;
	private java.lang.Integer fcmGiveLeaseLessThan;
	private java.lang.Boolean fcmGiveLeaseIsNull;
	private java.lang.Boolean fcmGiveLeaseIsNotNull;
	private java.util.List fcmGiveLeaseIn;
	private java.lang.Integer fcmGiveLeaseGreaterThanOrEqualTo;
	private java.lang.Integer fcmGiveLeaseGreaterThan;
	private java.lang.Integer fcmGiveLeaseEqualTo;
	private java.util.List fcmDeliverTypeNotIn;
	private java.lang.Integer fcmDeliverTypeNotEqualTo;
	private java.lang.Integer fcmDeliverTypeLessThanOrEqualTo;
	private java.lang.Integer fcmDeliverTypeLessThan;
	private java.lang.Boolean fcmDeliverTypeIsNull;
	private java.lang.Boolean fcmDeliverTypeIsNotNull;
	private java.util.List fcmDeliverTypeIn;
	private java.lang.Integer fcmDeliverTypeGreaterThanOrEqualTo;
	private java.lang.Integer fcmDeliverTypeGreaterThan;
	private java.lang.Integer fcmDeliverTypeEqualTo;
	private java.util.List fcmDeliverCityNotIn;
	private java.lang.Long fcmDeliverCityNotEqualTo;
	private java.lang.Long fcmDeliverCityLessThanOrEqualTo;
	private java.lang.Long fcmDeliverCityLessThan;
	private java.lang.Boolean fcmDeliverCityIsNull;
	private java.lang.Boolean fcmDeliverCityIsNotNull;
	private java.util.List fcmDeliverCityIn;
	private java.lang.Long fcmDeliverCityGreaterThanOrEqualTo;
	private java.lang.Long fcmDeliverCityGreaterThan;
	private java.lang.Long fcmDeliverCityEqualTo;
	private java.lang.String fcmCreatePhoneNotLike;
	private java.util.List fcmCreatePhoneNotIn;
	private java.lang.String fcmCreatePhoneNotEqualTo;
	private java.lang.String fcmCreatePhoneLike;
	private java.lang.String fcmCreatePhoneLessThanOrEqualTo;
	private java.lang.String fcmCreatePhoneLessThan;
	private java.lang.Boolean fcmCreatePhoneIsNull;
	private java.lang.Boolean fcmCreatePhoneIsNotNull;
	private java.util.List fcmCreatePhoneIn;
	private java.lang.String fcmCreatePhoneGreaterThanOrEqualTo;
	private java.lang.String fcmCreatePhoneGreaterThan;
	private java.lang.String fcmCreatePhoneEqualTo;
	private java.util.List fcmContractTypeNotIn;
	private java.lang.Integer fcmContractTypeNotEqualTo;
	private java.lang.Integer fcmContractTypeLessThanOrEqualTo;
	private java.lang.Integer fcmContractTypeLessThan;
	private java.lang.Boolean fcmContractTypeIsNull;
	private java.lang.Boolean fcmContractTypeIsNotNull;
	private java.util.List fcmContractTypeIn;
	private java.lang.Integer fcmContractTypeGreaterThanOrEqualTo;
	private java.lang.Integer fcmContractTypeGreaterThan;
	private java.lang.Integer fcmContractTypeEqualTo;
	private java.util.List fcmContractStateNotIn;
	private java.lang.Integer fcmContractStateNotEqualTo;
	private java.lang.Integer fcmContractStateLessThanOrEqualTo;
	private java.lang.Integer fcmContractStateLessThan;
	private java.lang.Boolean fcmContractStateIsNull;
	private java.lang.Boolean fcmContractStateIsNotNull;
	private java.util.List fcmContractStateIn;
	private java.lang.Integer fcmContractStateGreaterThanOrEqualTo;
	private java.lang.Integer fcmContractStateGreaterThan;
	private java.lang.Integer fcmContractStateEqualTo;
	private java.lang.String fcmContractNoNotLike;
	private java.util.List fcmContractNoNotIn;
	private java.lang.String fcmContractNoNotEqualTo;
	private java.lang.String fcmContractNoLike;
	private java.lang.String fcmContractNoLessThanOrEqualTo;
	private java.lang.String fcmContractNoLessThan;
	private java.lang.Boolean fcmContractNoIsNull;
	private java.lang.Boolean fcmContractNoIsNotNull;
	private java.util.List fcmContractNoIn;
	private java.lang.String fcmContractNoGreaterThanOrEqualTo;
	private java.lang.String fcmContractNoGreaterThan;
	private java.lang.String fcmContractNoEqualTo;
	private java.util.List fcmCityIdNotIn;
	private java.lang.Long fcmCityIdNotEqualTo;
	private java.lang.Long fcmCityIdLessThanOrEqualTo;
	private java.lang.Long fcmCityIdLessThan;
	private java.lang.Boolean fcmCityIdIsNull;
	private java.lang.Boolean fcmCityIdIsNotNull;
	private java.util.List fcmCityIdIn;
	private java.lang.Long fcmCityIdGreaterThanOrEqualTo;
	private java.lang.Long fcmCityIdGreaterThan;
	private java.lang.Long fcmCityIdEqualTo;
	private java.util.List fcmCarnumTotalNotIn;
	private java.lang.Integer fcmCarnumTotalNotEqualTo;
	private java.lang.Integer fcmCarnumTotalLessThanOrEqualTo;
	private java.lang.Integer fcmCarnumTotalLessThan;
	private java.lang.Boolean fcmCarnumTotalIsNull;
	private java.lang.Boolean fcmCarnumTotalIsNotNull;
	private java.util.List fcmCarnumTotalIn;
	private java.lang.Integer fcmCarnumTotalGreaterThanOrEqualTo;
	private java.lang.Integer fcmCarnumTotalGreaterThan;
	private java.lang.Integer fcmCarnumTotalEqualTo;
	private java.util.List fcmCarTypeIdNotIn;
	private java.lang.Long fcmCarTypeIdNotEqualTo;
	private java.lang.Long fcmCarTypeIdLessThanOrEqualTo;
	private java.lang.Long fcmCarTypeIdLessThan;
	private java.lang.Boolean fcmCarTypeIdIsNull;
	private java.lang.Boolean fcmCarTypeIdIsNotNull;
	private java.util.List fcmCarTypeIdIn;
	private java.lang.Long fcmCarTypeIdGreaterThanOrEqualTo;
	private java.lang.Long fcmCarTypeIdGreaterThan;
	private java.lang.Long fcmCarTypeIdEqualTo;
	private java.util.List fcmCarPurchaseNotIn;
	private java.lang.Double fcmCarPurchaseNotEqualTo;
	private java.lang.Double fcmCarPurchaseLessThanOrEqualTo;
	private java.lang.Double fcmCarPurchaseLessThan;
	private java.lang.Boolean fcmCarPurchaseIsNull;
	private java.lang.Boolean fcmCarPurchaseIsNotNull;
	private java.util.List fcmCarPurchaseIn;
	private java.lang.Double fcmCarPurchaseGreaterThanOrEqualTo;
	private java.lang.Double fcmCarPurchaseGreaterThan;
	private java.lang.Double fcmCarPurchaseEqualTo;
	private java.lang.String fcmCarPurchaseAdvanceNotLike;
	private java.util.List fcmCarPurchaseAdvanceNotIn;
	private java.lang.String fcmCarPurchaseAdvanceNotEqualTo;
	private java.lang.String fcmCarPurchaseAdvanceLike;
	private java.lang.String fcmCarPurchaseAdvanceLessThanOrEqualTo;
	private java.lang.String fcmCarPurchaseAdvanceLessThan;
	private java.lang.Boolean fcmCarPurchaseAdvanceIsNull;
	private java.lang.Boolean fcmCarPurchaseAdvanceIsNotNull;
	private java.util.List fcmCarPurchaseAdvanceIn;
	private java.lang.String fcmCarPurchaseAdvanceGreaterThanOrEqualTo;
	private java.lang.String fcmCarPurchaseAdvanceGreaterThan;
	private java.lang.String fcmCarPurchaseAdvanceEqualTo;
	private java.lang.String fcmCarNatureNotLike;
	private java.util.List fcmCarNatureNotIn;
	private java.lang.String fcmCarNatureNotEqualTo;
	private java.lang.String fcmCarNatureLike;
	private java.lang.String fcmCarNatureLessThanOrEqualTo;
	private java.lang.String fcmCarNatureLessThan;
	private java.lang.Boolean fcmCarNatureIsNull;
	private java.lang.Boolean fcmCarNatureIsNotNull;
	private java.util.List fcmCarNatureIn;
	private java.lang.String fcmCarNatureGreaterThanOrEqualTo;
	private java.lang.String fcmCarNatureGreaterThan;
	private java.lang.String fcmCarNatureEqualTo;
	private java.util.List fcmBoldRentNotIn;
	private java.lang.Double fcmBoldRentNotEqualTo;
	private java.lang.Double fcmBoldRentLessThanOrEqualTo;
	private java.lang.Double fcmBoldRentLessThan;
	private java.lang.Boolean fcmBoldRentIsNull;
	private java.lang.Boolean fcmBoldRentIsNotNull;
	private java.util.List fcmBoldRentIn;
	private java.lang.Double fcmBoldRentGreaterThanOrEqualTo;
	private java.lang.Double fcmBoldRentGreaterThan;
	private java.lang.Double fcmBoldRentEqualTo;
	private java.util.List fcmBillGenerateTypeNotIn;
	private java.lang.Integer fcmBillGenerateTypeNotEqualTo;
	private java.lang.Integer fcmBillGenerateTypeLessThanOrEqualTo;
	private java.lang.Integer fcmBillGenerateTypeLessThan;
	private java.lang.Boolean fcmBillGenerateTypeIsNull;
	private java.lang.Boolean fcmBillGenerateTypeIsNotNull;
	private java.util.List fcmBillGenerateTypeIn;
	private java.lang.Integer fcmBillGenerateTypeGreaterThanOrEqualTo;
	private java.lang.Integer fcmBillGenerateTypeGreaterThan;
	private java.lang.Integer fcmBillGenerateTypeEqualTo;
	private java.util.List fcmBillGenerateIntervalNotIn;
	private java.lang.Integer fcmBillGenerateIntervalNotEqualTo;
	private java.lang.Integer fcmBillGenerateIntervalLessThanOrEqualTo;
	private java.lang.Integer fcmBillGenerateIntervalLessThan;
	private java.lang.Boolean fcmBillGenerateIntervalIsNull;
	private java.lang.Boolean fcmBillGenerateIntervalIsNotNull;
	private java.util.List fcmBillGenerateIntervalIn;
	private java.lang.Integer fcmBillGenerateIntervalGreaterThanOrEqualTo;
	private java.lang.Integer fcmBillGenerateIntervalGreaterThan;
	private java.lang.Integer fcmBillGenerateIntervalEqualTo;
	private java.util.List fcmBillCatoffTypeNotIn;
	private java.lang.Integer fcmBillCatoffTypeNotEqualTo;
	private java.lang.Integer fcmBillCatoffTypeLessThanOrEqualTo;
	private java.lang.Integer fcmBillCatoffTypeLessThan;
	private java.lang.Boolean fcmBillCatoffTypeIsNull;
	private java.lang.Boolean fcmBillCatoffTypeIsNotNull;
	private java.util.List fcmBillCatoffTypeIn;
	private java.lang.Integer fcmBillCatoffTypeGreaterThanOrEqualTo;
	private java.lang.Integer fcmBillCatoffTypeGreaterThan;
	private java.lang.Integer fcmBillCatoffTypeEqualTo;
	private java.util.List fcmBillCatoffIntervalNotIn;
	private java.lang.Integer fcmBillCatoffIntervalNotEqualTo;
	private java.lang.Integer fcmBillCatoffIntervalLessThanOrEqualTo;
	private java.lang.Integer fcmBillCatoffIntervalLessThan;
	private java.lang.Boolean fcmBillCatoffIntervalIsNull;
	private java.lang.Boolean fcmBillCatoffIntervalIsNotNull;
	private java.util.List fcmBillCatoffIntervalIn;
	private java.lang.Integer fcmBillCatoffIntervalGreaterThanOrEqualTo;
	private java.lang.Integer fcmBillCatoffIntervalGreaterThan;
	private java.lang.Integer fcmBillCatoffIntervalEqualTo;
	private java.lang.String fcmAssociateContractNoNotLike;
	private java.util.List fcmAssociateContractNoNotIn;
	private java.lang.String fcmAssociateContractNoNotEqualTo;
	private java.lang.String fcmAssociateContractNoLike;
	private java.lang.String fcmAssociateContractNoLessThanOrEqualTo;
	private java.lang.String fcmAssociateContractNoLessThan;
	private java.lang.Boolean fcmAssociateContractNoIsNull;
	private java.lang.Boolean fcmAssociateContractNoIsNotNull;
	private java.util.List fcmAssociateContractNoIn;
	private java.lang.String fcmAssociateContractNoGreaterThanOrEqualTo;
	private java.lang.String fcmAssociateContractNoGreaterThan;
	private java.lang.String fcmAssociateContractNoEqualTo;
	private java.util.List fcmAssociateContractIdNotIn;
	private java.lang.Long fcmAssociateContractIdNotEqualTo;
	private java.lang.Long fcmAssociateContractIdLessThanOrEqualTo;
	private java.lang.Long fcmAssociateContractIdLessThan;
	private java.lang.Boolean fcmAssociateContractIdIsNull;
	private java.lang.Boolean fcmAssociateContractIdIsNotNull;
	private java.util.List fcmAssociateContractIdIn;
	private java.lang.Long fcmAssociateContractIdGreaterThanOrEqualTo;
	private java.lang.Long fcmAssociateContractIdGreaterThan;
	private java.lang.Long fcmAssociateContractIdEqualTo;
	private java.util.List drNotIn;
	private java.lang.Integer drNotEqualTo;
	private java.lang.Integer drLessThanOrEqualTo;
	private java.lang.Integer drLessThan;
	private java.lang.Boolean drIsNull;
	private java.lang.Boolean drIsNotNull;
	private java.util.List drIn;
	private java.lang.Integer drGreaterThanOrEqualTo;
	private java.lang.Integer drGreaterThan;
	private java.lang.Integer drEqualTo;
	private java.lang.String createuserNotLike;
	private java.util.List createuserNotIn;
	private java.lang.String createuserNotEqualTo;
	private java.lang.String createuserLike;
	private java.lang.String createuserLessThanOrEqualTo;
	private java.lang.String createuserLessThan;
	private java.lang.Boolean createuserIsNull;
	private java.lang.Boolean createuserIsNotNull;
	private java.util.List createuserIn;
	private java.lang.String createuserGreaterThanOrEqualTo;
	private java.lang.String createuserGreaterThan;
	private java.lang.String createuserEqualTo;
	private java.util.List createtimeNotIn;
	private java.util.Date createtimeNotEqualTo;
	private java.util.Date createtimeLessThanOrEqualTo;
	private java.util.Date createtimeLessThan;
	private java.lang.Boolean createtimeIsNull;
	private java.lang.Boolean createtimeIsNotNull;
	private java.util.List createtimeIn;
	private java.util.Date createtimeGreaterThanOrEqualTo;
	private java.util.Date createtimeGreaterThan;
	private java.util.Date createtimeEqualTo;
	private String sidx;
	private String sord;
	public String getSidx(){
		if(this.sidx == null){
			return "";
		}
		else if("updateuser".equals(this.sidx)){
			return "updateuser";
		}
		else if("updatetime".equals(this.sidx)){
			return "updatetime";
		}
		else if("remark".equals(this.sidx)){
			return "remark";
		}
		else if("fncTurnerSingleDeal".equals(this.sidx)){
			return "fnc_turner_single_deal";
		}
		else if("fcmUse".equals(this.sidx)){
			return "fcm_use";
		}
		else if("fcmSublet".equals(this.sidx)){
			return "fcm_sublet";
		}
		else if("fcmSingleMargin".equals(this.sidx)){
			return "fcm_single_margin";
		}
		else if("fcmSignedDate".equals(this.sidx)){
			return "fcm_signed_date";
		}
		else if("fcmSignedAddr".equals(this.sidx)){
			return "fcm_signed_addr";
		}
		else if("fcmSettlementState".equals(this.sidx)){
			return "fcm_settlement_state";
		}
		else if("fcmReturnCity".equals(this.sidx)){
			return "fcm_return_city";
		}
		else if("fcmRentPayType".equals(this.sidx)){
			return "fcm_rent_pay_type";
		}
		else if("fcmRentPayCycle".equals(this.sidx)){
			return "fcm_rent_pay_cycle";
		}
		else if("fcmPartybType".equals(this.sidx)){
			return "fcm_partyb_type";
		}
		else if("fcmPartybId".equals(this.sidx)){
			return "fcm_partyb_id";
		}
		else if("fcmPartyaType".equals(this.sidx)){
			return "fcm_partya_type";
		}
		else if("fcmPartyaId".equals(this.sidx)){
			return "fcm_partya_id";
		}
		else if("fcmOperatPlatform".equals(this.sidx)){
			return "fcm_operat_platform";
		}
		else if("fcmMarginType".equals(this.sidx)){
			return "fcm_margin_type";
		}
		else if("fcmMarginTotal".equals(this.sidx)){
			return "fcm_margin_total";
		}
		else if("fcmMarginPayRequire".equals(this.sidx)){
			return "fcm_margin_pay_require";
		}
		else if("fcmMarginMoney".equals(this.sidx)){
			return "fcm_margin_money";
		}
		else if("fcmLeaseType".equals(this.sidx)){
			return "fcm_lease_type";
		}
		else if("fcmLeaseDate".equals(this.sidx)){
			return "fcm_lease_date";
		}
		else if("fcmLeaseCount".equals(this.sidx)){
			return "fcm_lease_count";
		}
		else if("fcmLeaseCalculateType".equals(this.sidx)){
			return "fcm_lease_calculate_type";
		}
		else if("fcmLeaseAmountTotal".equals(this.sidx)){
			return "fcm_lease_amount_total";
		}
		else if("fcmLeaseAmount".equals(this.sidx)){
			return "fcm_lease_amount";
		}
		else if("fcmId".equals(this.sidx)){
			return "fcm_id";
		}
		else if("fcmGiveSequence".equals(this.sidx)){
			return "fcm_give_sequence";
		}
		else if("fcmGiveLease".equals(this.sidx)){
			return "fcm_give_lease";
		}
		else if("fcmDeliverType".equals(this.sidx)){
			return "fcm_deliver_type";
		}
		else if("fcmDeliverCity".equals(this.sidx)){
			return "fcm_deliver_city";
		}
		else if("fcmCreatePhone".equals(this.sidx)){
			return "fcm_create_phone";
		}
		else if("fcmContractType".equals(this.sidx)){
			return "fcm_contract_type";
		}
		else if("fcmContractState".equals(this.sidx)){
			return "fcm_contract_state";
		}
		else if("fcmContractNo".equals(this.sidx)){
			return "fcm_contract_no";
		}
		else if("fcmCityId".equals(this.sidx)){
			return "fcm_city_id";
		}
		else if("fcmCarnumTotal".equals(this.sidx)){
			return "fcm_carnum_total";
		}
		else if("fcmCarTypeId".equals(this.sidx)){
			return "fcm_car_type_id";
		}
		else if("fcmCarPurchase".equals(this.sidx)){
			return "fcm_car_purchase";
		}
		else if("fcmCarPurchaseAdvance".equals(this.sidx)){
			return "fcm_car_purchase_advance";
		}
		else if("fcmCarNature".equals(this.sidx)){
			return "fcm_car_nature";
		}
		else if("fcmBoldRent".equals(this.sidx)){
			return "fcm_bold_rent";
		}
		else if("fcmBillGenerateType".equals(this.sidx)){
			return "fcm_bill_generate_type";
		}
		else if("fcmBillGeneratetervalIn".equals(this.sidx)){
			return "fcm_bill_generateterval_in";
		}
		else if("fcmBillGenerateterval".equals(this.sidx)){
			return "fcm_bill_generateterval";
		}
		else if("fcmBillCatoffType".equals(this.sidx)){
			return "fcm_bill_catoff_type";
		}
		else if("fcmBillCatofftervalIn".equals(this.sidx)){
			return "fcm_bill_catoffterval_in";
		}
		else if("fcmBillCatoffterval".equals(this.sidx)){
			return "fcm_bill_catoffterval";
		}
		else if("fcmAssociateContractNo".equals(this.sidx)){
			return "fcm_associate_contract_no";
		}
		else if("fcmAssociateContractId".equals(this.sidx)){
			return "fcm_associate_contract_id";
		}
		else if("dr".equals(this.sidx)){
			return "dr";
		}
		else if("createuser".equals(this.sidx)){
			return "createuser";
		}
		else if("createtime".equals(this.sidx)){
			return "createtime";
		}
		return this.sidx;
	}

	@com.fasterxml.jackson.annotation.JsonIgnore
	public com.mrk.finance.example.FncContractManagementExample getCrieria(){
		com.mrk.finance.example.FncContractManagementExample q = new com.mrk.finance.example.FncContractManagementExample();
		com.mrk.finance.example.FncContractManagementExample.Criteria c = q.createCriteria();
		c.andDrEqualTo(0);
		if(CheckUtil.isNotEmpty(getUpdateuserNotLike())){
			c.andUpdateuserNotLike("%"+this.getUpdateuserNotLike()+"%");
		}
		if(CheckUtil.isNotEmpty(getUpdateuserNotIn())){
			c.andUpdateuserNotIn(this.getUpdateuserNotIn());
		}
		if(CheckUtil.isNotEmpty(getUpdateuserNotEqualTo())){
			c.andUpdateuserNotEqualTo(this.getUpdateuserNotEqualTo());
		}
		if(CheckUtil.isNotEmpty(getUpdateuserLike())){
			c.andUpdateuserLike("%"+this.getUpdateuserLike()+"%");
		}
		if(CheckUtil.isNotEmpty(getUpdateuserLessThanOrEqualTo())){
			c.andUpdateuserLessThanOrEqualTo(this.getUpdateuserLessThanOrEqualTo());
		}
		if(CheckUtil.isNotEmpty(getUpdateuserLessThan())){
			c.andUpdateuserLessThan(this.getUpdateuserLessThan());
		}
		if(CheckUtil.isNotEmpty(getUpdateuserIsNull()) && this.getUpdateuserIsNull()){
			c.andUpdateuserIsNull();
		}
		if(CheckUtil.isNotEmpty(getUpdateuserIsNotNull()) && this.getUpdateuserIsNotNull()){
			c.andUpdateuserIsNotNull();
		}
		if(CheckUtil.isNotEmpty(getUpdateuserIn())){
			c.andUpdateuserIn(this.getUpdateuserIn());
		}
		if(CheckUtil.isNotEmpty(getUpdateuserGreaterThanOrEqualTo())){
			c.andUpdateuserGreaterThanOrEqualTo(this.getUpdateuserGreaterThanOrEqualTo());
		}
		if(CheckUtil.isNotEmpty(getUpdateuserGreaterThan())){
			c.andUpdateuserGreaterThan(this.getUpdateuserGreaterThan());
		}
		if(CheckUtil.isNotEmpty(getUpdateuserEqualTo())){
			c.andUpdateuserEqualTo(this.getUpdateuserEqualTo());
		}
		if(CheckUtil.isNotEmpty(getUpdatetimeNotIn())){
			c.andUpdatetimeNotIn(this.getUpdatetimeNotIn());
		}
		if(CheckUtil.isNotEmpty(getUpdatetimeNotEqualTo())){
			c.andUpdatetimeNotEqualTo(this.getUpdatetimeNotEqualTo());
		}
		if(CheckUtil.isNotEmpty(getUpdatetimeLessThanOrEqualTo())){
			c.andUpdatetimeLessThanOrEqualTo(this.getUpdatetimeLessThanOrEqualTo());
		}
		if(CheckUtil.isNotEmpty(getUpdatetimeLessThan())){
			c.andUpdatetimeLessThan(this.getUpdatetimeLessThan());
		}
		if(CheckUtil.isNotEmpty(getUpdatetimeIsNull()) && this.getUpdatetimeIsNull()){
			c.andUpdatetimeIsNull();
		}
		if(CheckUtil.isNotEmpty(getUpdatetimeIsNotNull()) && this.getUpdatetimeIsNotNull()){
			c.andUpdatetimeIsNotNull();
		}
		if(CheckUtil.isNotEmpty(getUpdatetimeIn())){
			c.andUpdatetimeIn(this.getUpdatetimeIn());
		}
		if(CheckUtil.isNotEmpty(getUpdatetimeGreaterThanOrEqualTo())){
			c.andUpdatetimeGreaterThanOrEqualTo(this.getUpdatetimeGreaterThanOrEqualTo());
		}
		if(CheckUtil.isNotEmpty(getUpdatetimeGreaterThan())){
			c.andUpdatetimeGreaterThan(this.getUpdatetimeGreaterThan());
		}
		if(CheckUtil.isNotEmpty(getUpdatetimeEqualTo())){
			c.andUpdatetimeEqualTo(this.getUpdatetimeEqualTo());
		}
		if(CheckUtil.isNotEmpty(getRemarkNotLike())){
			c.andRemarkNotLike("%"+this.getRemarkNotLike()+"%");
		}
		if(CheckUtil.isNotEmpty(getRemarkNotIn())){
			c.andRemarkNotIn(this.getRemarkNotIn());
		}
		if(CheckUtil.isNotEmpty(getRemarkNotEqualTo())){
			c.andRemarkNotEqualTo(this.getRemarkNotEqualTo());
		}
		if(CheckUtil.isNotEmpty(getRemarkLike())){
			c.andRemarkLike("%"+this.getRemarkLike()+"%");
		}
		if(CheckUtil.isNotEmpty(getRemarkLessThanOrEqualTo())){
			c.andRemarkLessThanOrEqualTo(this.getRemarkLessThanOrEqualTo());
		}
		if(CheckUtil.isNotEmpty(getRemarkLessThan())){
			c.andRemarkLessThan(this.getRemarkLessThan());
		}
		if(CheckUtil.isNotEmpty(getRemarkIsNull()) && this.getRemarkIsNull()){
			c.andRemarkIsNull();
		}
		if(CheckUtil.isNotEmpty(getRemarkIsNotNull()) && this.getRemarkIsNotNull()){
			c.andRemarkIsNotNull();
		}
		if(CheckUtil.isNotEmpty(getRemarkIn())){
			c.andRemarkIn(this.getRemarkIn());
		}
		if(CheckUtil.isNotEmpty(getRemarkGreaterThanOrEqualTo())){
			c.andRemarkGreaterThanOrEqualTo(this.getRemarkGreaterThanOrEqualTo());
		}
		if(CheckUtil.isNotEmpty(getRemarkGreaterThan())){
			c.andRemarkGreaterThan(this.getRemarkGreaterThan());
		}
		if(CheckUtil.isNotEmpty(getRemarkEqualTo())){
			c.andRemarkEqualTo(this.getRemarkEqualTo());
		}
		if(CheckUtil.isNotEmpty(getFncTurnerSingleDealNotIn())){
			c.andFncTurnerSingleDealNotIn(this.getFncTurnerSingleDealNotIn());
		}
		if(CheckUtil.isNotEmpty(getFncTurnerSingleDealNotEqualTo())){
			c.andFncTurnerSingleDealNotEqualTo(this.getFncTurnerSingleDealNotEqualTo());
		}
		if(CheckUtil.isNotEmpty(getFncTurnerSingleDealLessThanOrEqualTo())){
			c.andFncTurnerSingleDealLessThanOrEqualTo(this.getFncTurnerSingleDealLessThanOrEqualTo());
		}
		if(CheckUtil.isNotEmpty(getFncTurnerSingleDealLessThan())){
			c.andFncTurnerSingleDealLessThan(this.getFncTurnerSingleDealLessThan());
		}
		if(CheckUtil.isNotEmpty(getFncTurnerSingleDealIsNull()) && this.getFncTurnerSingleDealIsNull()){
			c.andFncTurnerSingleDealIsNull();
		}
		if(CheckUtil.isNotEmpty(getFncTurnerSingleDealIsNotNull()) && this.getFncTurnerSingleDealIsNotNull()){
			c.andFncTurnerSingleDealIsNotNull();
		}
		if(CheckUtil.isNotEmpty(getFncTurnerSingleDealIn())){
			c.andFncTurnerSingleDealIn(this.getFncTurnerSingleDealIn());
		}
		if(CheckUtil.isNotEmpty(getFncTurnerSingleDealGreaterThanOrEqualTo())){
			c.andFncTurnerSingleDealGreaterThanOrEqualTo(this.getFncTurnerSingleDealGreaterThanOrEqualTo());
		}
		if(CheckUtil.isNotEmpty(getFncTurnerSingleDealGreaterThan())){
			c.andFncTurnerSingleDealGreaterThan(this.getFncTurnerSingleDealGreaterThan());
		}
		if(CheckUtil.isNotEmpty(getFncTurnerSingleDealEqualTo())){
			c.andFncTurnerSingleDealEqualTo(this.getFncTurnerSingleDealEqualTo());
		}
		if(CheckUtil.isNotEmpty(getFcmUseNotLike())){
			c.andFcmUseNotLike("%"+this.getFcmUseNotLike()+"%");
		}
		if(CheckUtil.isNotEmpty(getFcmUseNotIn())){
			c.andFcmUseNotIn(this.getFcmUseNotIn());
		}
		if(CheckUtil.isNotEmpty(getFcmUseNotEqualTo())){
			c.andFcmUseNotEqualTo(this.getFcmUseNotEqualTo());
		}
		if(CheckUtil.isNotEmpty(getFcmUseLike())){
			c.andFcmUseLike("%"+this.getFcmUseLike()+"%");
		}
		if(CheckUtil.isNotEmpty(getFcmUseLessThanOrEqualTo())){
			c.andFcmUseLessThanOrEqualTo(this.getFcmUseLessThanOrEqualTo());
		}
		if(CheckUtil.isNotEmpty(getFcmUseLessThan())){
			c.andFcmUseLessThan(this.getFcmUseLessThan());
		}
		if(CheckUtil.isNotEmpty(getFcmUseIsNull()) && this.getFcmUseIsNull()){
			c.andFcmUseIsNull();
		}
		if(CheckUtil.isNotEmpty(getFcmUseIsNotNull()) && this.getFcmUseIsNotNull()){
			c.andFcmUseIsNotNull();
		}
		if(CheckUtil.isNotEmpty(getFcmUseIn())){
			c.andFcmUseIn(this.getFcmUseIn());
		}
		if(CheckUtil.isNotEmpty(getFcmUseGreaterThanOrEqualTo())){
			c.andFcmUseGreaterThanOrEqualTo(this.getFcmUseGreaterThanOrEqualTo());
		}
		if(CheckUtil.isNotEmpty(getFcmUseGreaterThan())){
			c.andFcmUseGreaterThan(this.getFcmUseGreaterThan());
		}
		if(CheckUtil.isNotEmpty(getFcmUseEqualTo())){
			c.andFcmUseEqualTo(this.getFcmUseEqualTo());
		}
		if(CheckUtil.isNotEmpty(getFcmSubletNotIn())){
			c.andFcmSubletNotIn(this.getFcmSubletNotIn());
		}
		if(CheckUtil.isNotEmpty(getFcmSubletNotEqualTo())){
			c.andFcmSubletNotEqualTo(this.getFcmSubletNotEqualTo());
		}
		if(CheckUtil.isNotEmpty(getFcmSubletLessThanOrEqualTo())){
			c.andFcmSubletLessThanOrEqualTo(this.getFcmSubletLessThanOrEqualTo());
		}
		if(CheckUtil.isNotEmpty(getFcmSubletLessThan())){
			c.andFcmSubletLessThan(this.getFcmSubletLessThan());
		}
		if(CheckUtil.isNotEmpty(getFcmSubletIsNull()) && this.getFcmSubletIsNull()){
			c.andFcmSubletIsNull();
		}
		if(CheckUtil.isNotEmpty(getFcmSubletIsNotNull()) && this.getFcmSubletIsNotNull()){
			c.andFcmSubletIsNotNull();
		}
		if(CheckUtil.isNotEmpty(getFcmSubletIn())){
			c.andFcmSubletIn(this.getFcmSubletIn());
		}
		if(CheckUtil.isNotEmpty(getFcmSubletGreaterThanOrEqualTo())){
			c.andFcmSubletGreaterThanOrEqualTo(this.getFcmSubletGreaterThanOrEqualTo());
		}
		if(CheckUtil.isNotEmpty(getFcmSubletGreaterThan())){
			c.andFcmSubletGreaterThan(this.getFcmSubletGreaterThan());
		}
		if(CheckUtil.isNotEmpty(getFcmSubletEqualTo())){
			c.andFcmSubletEqualTo(this.getFcmSubletEqualTo());
		}
		if(CheckUtil.isNotEmpty(getFcmSingleMarginNotIn())){
			c.andFcmSingleMarginNotIn(this.getFcmSingleMarginNotIn());
		}
		if(CheckUtil.isNotEmpty(getFcmSingleMarginNotEqualTo())){
			c.andFcmSingleMarginNotEqualTo(this.getFcmSingleMarginNotEqualTo());
		}
		if(CheckUtil.isNotEmpty(getFcmSingleMarginLessThanOrEqualTo())){
			c.andFcmSingleMarginLessThanOrEqualTo(this.getFcmSingleMarginLessThanOrEqualTo());
		}
		if(CheckUtil.isNotEmpty(getFcmSingleMarginLessThan())){
			c.andFcmSingleMarginLessThan(this.getFcmSingleMarginLessThan());
		}
		if(CheckUtil.isNotEmpty(getFcmSingleMarginIsNull()) && this.getFcmSingleMarginIsNull()){
			c.andFcmSingleMarginIsNull();
		}
		if(CheckUtil.isNotEmpty(getFcmSingleMarginIsNotNull()) && this.getFcmSingleMarginIsNotNull()){
			c.andFcmSingleMarginIsNotNull();
		}
		if(CheckUtil.isNotEmpty(getFcmSingleMarginIn())){
			c.andFcmSingleMarginIn(this.getFcmSingleMarginIn());
		}
		if(CheckUtil.isNotEmpty(getFcmSingleMarginGreaterThanOrEqualTo())){
			c.andFcmSingleMarginGreaterThanOrEqualTo(this.getFcmSingleMarginGreaterThanOrEqualTo());
		}
		if(CheckUtil.isNotEmpty(getFcmSingleMarginGreaterThan())){
			c.andFcmSingleMarginGreaterThan(this.getFcmSingleMarginGreaterThan());
		}
		if(CheckUtil.isNotEmpty(getFcmSingleMarginEqualTo())){
			c.andFcmSingleMarginEqualTo(this.getFcmSingleMarginEqualTo());
		}
		if(CheckUtil.isNotEmpty(getFcmSignedDateNotIn())){
			c.andFcmSignedDateNotIn(this.getFcmSignedDateNotIn());
		}
		if(CheckUtil.isNotEmpty(getFcmSignedDateNotEqualTo())){
			c.andFcmSignedDateNotEqualTo(this.getFcmSignedDateNotEqualTo());
		}
		if(CheckUtil.isNotEmpty(getFcmSignedDateLessThanOrEqualTo())){
			c.andFcmSignedDateLessThanOrEqualTo(this.getFcmSignedDateLessThanOrEqualTo());
		}
		if(CheckUtil.isNotEmpty(getFcmSignedDateLessThan())){
			c.andFcmSignedDateLessThan(this.getFcmSignedDateLessThan());
		}
		if(CheckUtil.isNotEmpty(getFcmSignedDateIsNull()) && this.getFcmSignedDateIsNull()){
			c.andFcmSignedDateIsNull();
		}
		if(CheckUtil.isNotEmpty(getFcmSignedDateIsNotNull()) && this.getFcmSignedDateIsNotNull()){
			c.andFcmSignedDateIsNotNull();
		}
		if(CheckUtil.isNotEmpty(getFcmSignedDateIn())){
			c.andFcmSignedDateIn(this.getFcmSignedDateIn());
		}
		if(CheckUtil.isNotEmpty(getFcmSignedDateGreaterThanOrEqualTo())){
			c.andFcmSignedDateGreaterThanOrEqualTo(this.getFcmSignedDateGreaterThanOrEqualTo());
		}
		if(CheckUtil.isNotEmpty(getFcmSignedDateGreaterThan())){
			c.andFcmSignedDateGreaterThan(this.getFcmSignedDateGreaterThan());
		}
		if(CheckUtil.isNotEmpty(getFcmSignedDateEqualTo())){
			c.andFcmSignedDateEqualTo(this.getFcmSignedDateEqualTo());
		}
		if(CheckUtil.isNotEmpty(getFcmSignedAddrNotIn())){
			c.andFcmSignedAddrNotIn(this.getFcmSignedAddrNotIn());
		}
		if(CheckUtil.isNotEmpty(getFcmSignedAddrNotEqualTo())){
			c.andFcmSignedAddrNotEqualTo(this.getFcmSignedAddrNotEqualTo());
		}
		if(CheckUtil.isNotEmpty(getFcmSignedAddrLessThanOrEqualTo())){
			c.andFcmSignedAddrLessThanOrEqualTo(this.getFcmSignedAddrLessThanOrEqualTo());
		}
		if(CheckUtil.isNotEmpty(getFcmSignedAddrLessThan())){
			c.andFcmSignedAddrLessThan(this.getFcmSignedAddrLessThan());
		}
		if(CheckUtil.isNotEmpty(getFcmSignedAddrIsNull()) && this.getFcmSignedAddrIsNull()){
			c.andFcmSignedAddrIsNull();
		}
		if(CheckUtil.isNotEmpty(getFcmSignedAddrIsNotNull()) && this.getFcmSignedAddrIsNotNull()){
			c.andFcmSignedAddrIsNotNull();
		}
		if(CheckUtil.isNotEmpty(getFcmSignedAddrIn())){
			c.andFcmSignedAddrIn(this.getFcmSignedAddrIn());
		}
		if(CheckUtil.isNotEmpty(getFcmSignedAddrGreaterThanOrEqualTo())){
			c.andFcmSignedAddrGreaterThanOrEqualTo(this.getFcmSignedAddrGreaterThanOrEqualTo());
		}
		if(CheckUtil.isNotEmpty(getFcmSignedAddrGreaterThan())){
			c.andFcmSignedAddrGreaterThan(this.getFcmSignedAddrGreaterThan());
		}
		if(CheckUtil.isNotEmpty(getFcmSignedAddrEqualTo())){
			c.andFcmSignedAddrEqualTo(this.getFcmSignedAddrEqualTo());
		}
		if(CheckUtil.isNotEmpty(getFcmSettlementStateNotIn())){
			c.andFcmSettlementStateNotIn(this.getFcmSettlementStateNotIn());
		}
		if(CheckUtil.isNotEmpty(getFcmSettlementStateNotEqualTo())){
			c.andFcmSettlementStateNotEqualTo(this.getFcmSettlementStateNotEqualTo());
		}
		if(CheckUtil.isNotEmpty(getFcmSettlementStateLessThanOrEqualTo())){
			c.andFcmSettlementStateLessThanOrEqualTo(this.getFcmSettlementStateLessThanOrEqualTo());
		}
		if(CheckUtil.isNotEmpty(getFcmSettlementStateLessThan())){
			c.andFcmSettlementStateLessThan(this.getFcmSettlementStateLessThan());
		}
		if(CheckUtil.isNotEmpty(getFcmSettlementStateIsNull()) && this.getFcmSettlementStateIsNull()){
			c.andFcmSettlementStateIsNull();
		}
		if(CheckUtil.isNotEmpty(getFcmSettlementStateIsNotNull()) && this.getFcmSettlementStateIsNotNull()){
			c.andFcmSettlementStateIsNotNull();
		}
		if(CheckUtil.isNotEmpty(getFcmSettlementStateIn())){
			c.andFcmSettlementStateIn(this.getFcmSettlementStateIn());
		}
		if(CheckUtil.isNotEmpty(getFcmSettlementStateGreaterThanOrEqualTo())){
			c.andFcmSettlementStateGreaterThanOrEqualTo(this.getFcmSettlementStateGreaterThanOrEqualTo());
		}
		if(CheckUtil.isNotEmpty(getFcmSettlementStateGreaterThan())){
			c.andFcmSettlementStateGreaterThan(this.getFcmSettlementStateGreaterThan());
		}
		if(CheckUtil.isNotEmpty(getFcmSettlementStateEqualTo())){
			c.andFcmSettlementStateEqualTo(this.getFcmSettlementStateEqualTo());
		}
		if(CheckUtil.isNotEmpty(getFcmReturnCityNotIn())){
			c.andFcmReturnCityNotIn(this.getFcmReturnCityNotIn());
		}
		if(CheckUtil.isNotEmpty(getFcmReturnCityNotEqualTo())){
			c.andFcmReturnCityNotEqualTo(this.getFcmReturnCityNotEqualTo());
		}
		if(CheckUtil.isNotEmpty(getFcmReturnCityLessThanOrEqualTo())){
			c.andFcmReturnCityLessThanOrEqualTo(this.getFcmReturnCityLessThanOrEqualTo());
		}
		if(CheckUtil.isNotEmpty(getFcmReturnCityLessThan())){
			c.andFcmReturnCityLessThan(this.getFcmReturnCityLessThan());
		}
		if(CheckUtil.isNotEmpty(getFcmReturnCityIsNull()) && this.getFcmReturnCityIsNull()){
			c.andFcmReturnCityIsNull();
		}
		if(CheckUtil.isNotEmpty(getFcmReturnCityIsNotNull()) && this.getFcmReturnCityIsNotNull()){
			c.andFcmReturnCityIsNotNull();
		}
		if(CheckUtil.isNotEmpty(getFcmReturnCityIn())){
			c.andFcmReturnCityIn(this.getFcmReturnCityIn());
		}
		if(CheckUtil.isNotEmpty(getFcmReturnCityGreaterThanOrEqualTo())){
			c.andFcmReturnCityGreaterThanOrEqualTo(this.getFcmReturnCityGreaterThanOrEqualTo());
		}
		if(CheckUtil.isNotEmpty(getFcmReturnCityGreaterThan())){
			c.andFcmReturnCityGreaterThan(this.getFcmReturnCityGreaterThan());
		}
		if(CheckUtil.isNotEmpty(getFcmReturnCityEqualTo())){
			c.andFcmReturnCityEqualTo(this.getFcmReturnCityEqualTo());
		}
		if(CheckUtil.isNotEmpty(getFcmRentPayTypeNotIn())){
			c.andFcmRentPayTypeNotIn(this.getFcmRentPayTypeNotIn());
		}
		if(CheckUtil.isNotEmpty(getFcmRentPayTypeNotEqualTo())){
			c.andFcmRentPayTypeNotEqualTo(this.getFcmRentPayTypeNotEqualTo());
		}
		if(CheckUtil.isNotEmpty(getFcmRentPayTypeLessThanOrEqualTo())){
			c.andFcmRentPayTypeLessThanOrEqualTo(this.getFcmRentPayTypeLessThanOrEqualTo());
		}
		if(CheckUtil.isNotEmpty(getFcmRentPayTypeLessThan())){
			c.andFcmRentPayTypeLessThan(this.getFcmRentPayTypeLessThan());
		}
		if(CheckUtil.isNotEmpty(getFcmRentPayTypeIsNull()) && this.getFcmRentPayTypeIsNull()){
			c.andFcmRentPayTypeIsNull();
		}
		if(CheckUtil.isNotEmpty(getFcmRentPayTypeIsNotNull()) && this.getFcmRentPayTypeIsNotNull()){
			c.andFcmRentPayTypeIsNotNull();
		}
		if(CheckUtil.isNotEmpty(getFcmRentPayTypeIn())){
			c.andFcmRentPayTypeIn(this.getFcmRentPayTypeIn());
		}
		if(CheckUtil.isNotEmpty(getFcmRentPayTypeGreaterThanOrEqualTo())){
			c.andFcmRentPayTypeGreaterThanOrEqualTo(this.getFcmRentPayTypeGreaterThanOrEqualTo());
		}
		if(CheckUtil.isNotEmpty(getFcmRentPayTypeGreaterThan())){
			c.andFcmRentPayTypeGreaterThan(this.getFcmRentPayTypeGreaterThan());
		}
		if(CheckUtil.isNotEmpty(getFcmRentPayTypeEqualTo())){
			c.andFcmRentPayTypeEqualTo(this.getFcmRentPayTypeEqualTo());
		}
		if(CheckUtil.isNotEmpty(getFcmRentPayCycleNotIn())){
			c.andFcmRentPayCycleNotIn(this.getFcmRentPayCycleNotIn());
		}
		if(CheckUtil.isNotEmpty(getFcmRentPayCycleNotEqualTo())){
			c.andFcmRentPayCycleNotEqualTo(this.getFcmRentPayCycleNotEqualTo());
		}
		if(CheckUtil.isNotEmpty(getFcmRentPayCycleLessThanOrEqualTo())){
			c.andFcmRentPayCycleLessThanOrEqualTo(this.getFcmRentPayCycleLessThanOrEqualTo());
		}
		if(CheckUtil.isNotEmpty(getFcmRentPayCycleLessThan())){
			c.andFcmRentPayCycleLessThan(this.getFcmRentPayCycleLessThan());
		}
		if(CheckUtil.isNotEmpty(getFcmRentPayCycleIsNull()) && this.getFcmRentPayCycleIsNull()){
			c.andFcmRentPayCycleIsNull();
		}
		if(CheckUtil.isNotEmpty(getFcmRentPayCycleIsNotNull()) && this.getFcmRentPayCycleIsNotNull()){
			c.andFcmRentPayCycleIsNotNull();
		}
		if(CheckUtil.isNotEmpty(getFcmRentPayCycleIn())){
			c.andFcmRentPayCycleIn(this.getFcmRentPayCycleIn());
		}
		if(CheckUtil.isNotEmpty(getFcmRentPayCycleGreaterThanOrEqualTo())){
			c.andFcmRentPayCycleGreaterThanOrEqualTo(this.getFcmRentPayCycleGreaterThanOrEqualTo());
		}
		if(CheckUtil.isNotEmpty(getFcmRentPayCycleGreaterThan())){
			c.andFcmRentPayCycleGreaterThan(this.getFcmRentPayCycleGreaterThan());
		}
		if(CheckUtil.isNotEmpty(getFcmRentPayCycleEqualTo())){
			c.andFcmRentPayCycleEqualTo(this.getFcmRentPayCycleEqualTo());
		}
		if(CheckUtil.isNotEmpty(getFcmPartybTypeNotIn())){
			c.andFcmPartybTypeNotIn(this.getFcmPartybTypeNotIn());
		}
		if(CheckUtil.isNotEmpty(getFcmPartybTypeNotEqualTo())){
			c.andFcmPartybTypeNotEqualTo(this.getFcmPartybTypeNotEqualTo());
		}
		if(CheckUtil.isNotEmpty(getFcmPartybTypeLessThanOrEqualTo())){
			c.andFcmPartybTypeLessThanOrEqualTo(this.getFcmPartybTypeLessThanOrEqualTo());
		}
		if(CheckUtil.isNotEmpty(getFcmPartybTypeLessThan())){
			c.andFcmPartybTypeLessThan(this.getFcmPartybTypeLessThan());
		}
		if(CheckUtil.isNotEmpty(getFcmPartybTypeIsNull()) && this.getFcmPartybTypeIsNull()){
			c.andFcmPartybTypeIsNull();
		}
		if(CheckUtil.isNotEmpty(getFcmPartybTypeIsNotNull()) && this.getFcmPartybTypeIsNotNull()){
			c.andFcmPartybTypeIsNotNull();
		}
		if(CheckUtil.isNotEmpty(getFcmPartybTypeIn())){
			c.andFcmPartybTypeIn(this.getFcmPartybTypeIn());
		}
		if(CheckUtil.isNotEmpty(getFcmPartybTypeGreaterThanOrEqualTo())){
			c.andFcmPartybTypeGreaterThanOrEqualTo(this.getFcmPartybTypeGreaterThanOrEqualTo());
		}
		if(CheckUtil.isNotEmpty(getFcmPartybTypeGreaterThan())){
			c.andFcmPartybTypeGreaterThan(this.getFcmPartybTypeGreaterThan());
		}
		if(CheckUtil.isNotEmpty(getFcmPartybTypeEqualTo())){
			c.andFcmPartybTypeEqualTo(this.getFcmPartybTypeEqualTo());
		}
		if(CheckUtil.isNotEmpty(getFcmPartybIdNotIn())){
			c.andFcmPartybIdNotIn(this.getFcmPartybIdNotIn());
		}
		if(CheckUtil.isNotEmpty(getFcmPartybIdNotEqualTo())){
			c.andFcmPartybIdNotEqualTo(this.getFcmPartybIdNotEqualTo());
		}
		if(CheckUtil.isNotEmpty(getFcmPartybIdLessThanOrEqualTo())){
			c.andFcmPartybIdLessThanOrEqualTo(this.getFcmPartybIdLessThanOrEqualTo());
		}
		if(CheckUtil.isNotEmpty(getFcmPartybIdLessThan())){
			c.andFcmPartybIdLessThan(this.getFcmPartybIdLessThan());
		}
		if(CheckUtil.isNotEmpty(getFcmPartybIdIsNull()) && this.getFcmPartybIdIsNull()){
			c.andFcmPartybIdIsNull();
		}
		if(CheckUtil.isNotEmpty(getFcmPartybIdIsNotNull()) && this.getFcmPartybIdIsNotNull()){
			c.andFcmPartybIdIsNotNull();
		}
		if(CheckUtil.isNotEmpty(getFcmPartybIdIn())){
			c.andFcmPartybIdIn(this.getFcmPartybIdIn());
		}
		if(CheckUtil.isNotEmpty(getFcmPartybIdGreaterThanOrEqualTo())){
			c.andFcmPartybIdGreaterThanOrEqualTo(this.getFcmPartybIdGreaterThanOrEqualTo());
		}
		if(CheckUtil.isNotEmpty(getFcmPartybIdGreaterThan())){
			c.andFcmPartybIdGreaterThan(this.getFcmPartybIdGreaterThan());
		}
		if(CheckUtil.isNotEmpty(getFcmPartybIdEqualTo())){
			c.andFcmPartybIdEqualTo(this.getFcmPartybIdEqualTo());
		}
		if(CheckUtil.isNotEmpty(getFcmPartyaTypeNotIn())){
			c.andFcmPartyaTypeNotIn(this.getFcmPartyaTypeNotIn());
		}
		if(CheckUtil.isNotEmpty(getFcmPartyaTypeNotEqualTo())){
			c.andFcmPartyaTypeNotEqualTo(this.getFcmPartyaTypeNotEqualTo());
		}
		if(CheckUtil.isNotEmpty(getFcmPartyaTypeLessThanOrEqualTo())){
			c.andFcmPartyaTypeLessThanOrEqualTo(this.getFcmPartyaTypeLessThanOrEqualTo());
		}
		if(CheckUtil.isNotEmpty(getFcmPartyaTypeLessThan())){
			c.andFcmPartyaTypeLessThan(this.getFcmPartyaTypeLessThan());
		}
		if(CheckUtil.isNotEmpty(getFcmPartyaTypeIsNull()) && this.getFcmPartyaTypeIsNull()){
			c.andFcmPartyaTypeIsNull();
		}
		if(CheckUtil.isNotEmpty(getFcmPartyaTypeIsNotNull()) && this.getFcmPartyaTypeIsNotNull()){
			c.andFcmPartyaTypeIsNotNull();
		}
		if(CheckUtil.isNotEmpty(getFcmPartyaTypeIn())){
			c.andFcmPartyaTypeIn(this.getFcmPartyaTypeIn());
		}
		if(CheckUtil.isNotEmpty(getFcmPartyaTypeGreaterThanOrEqualTo())){
			c.andFcmPartyaTypeGreaterThanOrEqualTo(this.getFcmPartyaTypeGreaterThanOrEqualTo());
		}
		if(CheckUtil.isNotEmpty(getFcmPartyaTypeGreaterThan())){
			c.andFcmPartyaTypeGreaterThan(this.getFcmPartyaTypeGreaterThan());
		}
		if(CheckUtil.isNotEmpty(getFcmPartyaTypeEqualTo())){
			c.andFcmPartyaTypeEqualTo(this.getFcmPartyaTypeEqualTo());
		}
		if(CheckUtil.isNotEmpty(getFcmPartyaIdNotIn())){
			c.andFcmPartyaIdNotIn(this.getFcmPartyaIdNotIn());
		}
		if(CheckUtil.isNotEmpty(getFcmPartyaIdNotEqualTo())){
			c.andFcmPartyaIdNotEqualTo(this.getFcmPartyaIdNotEqualTo());
		}
		if(CheckUtil.isNotEmpty(getFcmPartyaIdLessThanOrEqualTo())){
			c.andFcmPartyaIdLessThanOrEqualTo(this.getFcmPartyaIdLessThanOrEqualTo());
		}
		if(CheckUtil.isNotEmpty(getFcmPartyaIdLessThan())){
			c.andFcmPartyaIdLessThan(this.getFcmPartyaIdLessThan());
		}
		if(CheckUtil.isNotEmpty(getFcmPartyaIdIsNull()) && this.getFcmPartyaIdIsNull()){
			c.andFcmPartyaIdIsNull();
		}
		if(CheckUtil.isNotEmpty(getFcmPartyaIdIsNotNull()) && this.getFcmPartyaIdIsNotNull()){
			c.andFcmPartyaIdIsNotNull();
		}
		if(CheckUtil.isNotEmpty(getFcmPartyaIdIn())){
			c.andFcmPartyaIdIn(this.getFcmPartyaIdIn());
		}
		if(CheckUtil.isNotEmpty(getFcmPartyaIdGreaterThanOrEqualTo())){
			c.andFcmPartyaIdGreaterThanOrEqualTo(this.getFcmPartyaIdGreaterThanOrEqualTo());
		}
		if(CheckUtil.isNotEmpty(getFcmPartyaIdGreaterThan())){
			c.andFcmPartyaIdGreaterThan(this.getFcmPartyaIdGreaterThan());
		}
		if(CheckUtil.isNotEmpty(getFcmPartyaIdEqualTo())){
			c.andFcmPartyaIdEqualTo(this.getFcmPartyaIdEqualTo());
		}
		if(CheckUtil.isNotEmpty(getFcmOperatPlatformNotIn())){
			c.andFcmOperatPlatformNotIn(this.getFcmOperatPlatformNotIn());
		}
		if(CheckUtil.isNotEmpty(getFcmOperatPlatformNotEqualTo())){
			c.andFcmOperatPlatformNotEqualTo(this.getFcmOperatPlatformNotEqualTo());
		}
		if(CheckUtil.isNotEmpty(getFcmOperatPlatformLessThanOrEqualTo())){
			c.andFcmOperatPlatformLessThanOrEqualTo(this.getFcmOperatPlatformLessThanOrEqualTo());
		}
		if(CheckUtil.isNotEmpty(getFcmOperatPlatformLessThan())){
			c.andFcmOperatPlatformLessThan(this.getFcmOperatPlatformLessThan());
		}
		if(CheckUtil.isNotEmpty(getFcmOperatPlatformIsNull()) && this.getFcmOperatPlatformIsNull()){
			c.andFcmOperatPlatformIsNull();
		}
		if(CheckUtil.isNotEmpty(getFcmOperatPlatformIsNotNull()) && this.getFcmOperatPlatformIsNotNull()){
			c.andFcmOperatPlatformIsNotNull();
		}
		if(CheckUtil.isNotEmpty(getFcmOperatPlatformIn())){
			c.andFcmOperatPlatformIn(this.getFcmOperatPlatformIn());
		}
		if(CheckUtil.isNotEmpty(getFcmOperatPlatformGreaterThanOrEqualTo())){
			c.andFcmOperatPlatformGreaterThanOrEqualTo(this.getFcmOperatPlatformGreaterThanOrEqualTo());
		}
		if(CheckUtil.isNotEmpty(getFcmOperatPlatformGreaterThan())){
			c.andFcmOperatPlatformGreaterThan(this.getFcmOperatPlatformGreaterThan());
		}
		if(CheckUtil.isNotEmpty(getFcmOperatPlatformEqualTo())){
			c.andFcmOperatPlatformEqualTo(this.getFcmOperatPlatformEqualTo());
		}
		if(CheckUtil.isNotEmpty(getFcmMarginTypeNotIn())){
			c.andFcmMarginTypeNotIn(this.getFcmMarginTypeNotIn());
		}
		if(CheckUtil.isNotEmpty(getFcmMarginTypeNotEqualTo())){
			c.andFcmMarginTypeNotEqualTo(this.getFcmMarginTypeNotEqualTo());
		}
		if(CheckUtil.isNotEmpty(getFcmMarginTypeLessThanOrEqualTo())){
			c.andFcmMarginTypeLessThanOrEqualTo(this.getFcmMarginTypeLessThanOrEqualTo());
		}
		if(CheckUtil.isNotEmpty(getFcmMarginTypeLessThan())){
			c.andFcmMarginTypeLessThan(this.getFcmMarginTypeLessThan());
		}
		if(CheckUtil.isNotEmpty(getFcmMarginTypeIsNull()) && this.getFcmMarginTypeIsNull()){
			c.andFcmMarginTypeIsNull();
		}
		if(CheckUtil.isNotEmpty(getFcmMarginTypeIsNotNull()) && this.getFcmMarginTypeIsNotNull()){
			c.andFcmMarginTypeIsNotNull();
		}
		if(CheckUtil.isNotEmpty(getFcmMarginTypeIn())){
			c.andFcmMarginTypeIn(this.getFcmMarginTypeIn());
		}
		if(CheckUtil.isNotEmpty(getFcmMarginTypeGreaterThanOrEqualTo())){
			c.andFcmMarginTypeGreaterThanOrEqualTo(this.getFcmMarginTypeGreaterThanOrEqualTo());
		}
		if(CheckUtil.isNotEmpty(getFcmMarginTypeGreaterThan())){
			c.andFcmMarginTypeGreaterThan(this.getFcmMarginTypeGreaterThan());
		}
		if(CheckUtil.isNotEmpty(getFcmMarginTypeEqualTo())){
			c.andFcmMarginTypeEqualTo(this.getFcmMarginTypeEqualTo());
		}
		if(CheckUtil.isNotEmpty(getFcmMarginTotalNotIn())){
			c.andFcmMarginTotalNotIn(this.getFcmMarginTotalNotIn());
		}
		if(CheckUtil.isNotEmpty(getFcmMarginTotalNotEqualTo())){
			c.andFcmMarginTotalNotEqualTo(this.getFcmMarginTotalNotEqualTo());
		}
		if(CheckUtil.isNotEmpty(getFcmMarginTotalLessThanOrEqualTo())){
			c.andFcmMarginTotalLessThanOrEqualTo(this.getFcmMarginTotalLessThanOrEqualTo());
		}
		if(CheckUtil.isNotEmpty(getFcmMarginTotalLessThan())){
			c.andFcmMarginTotalLessThan(this.getFcmMarginTotalLessThan());
		}
		if(CheckUtil.isNotEmpty(getFcmMarginTotalIsNull()) && this.getFcmMarginTotalIsNull()){
			c.andFcmMarginTotalIsNull();
		}
		if(CheckUtil.isNotEmpty(getFcmMarginTotalIsNotNull()) && this.getFcmMarginTotalIsNotNull()){
			c.andFcmMarginTotalIsNotNull();
		}
		if(CheckUtil.isNotEmpty(getFcmMarginTotalIn())){
			c.andFcmMarginTotalIn(this.getFcmMarginTotalIn());
		}
		if(CheckUtil.isNotEmpty(getFcmMarginTotalGreaterThanOrEqualTo())){
			c.andFcmMarginTotalGreaterThanOrEqualTo(this.getFcmMarginTotalGreaterThanOrEqualTo());
		}
		if(CheckUtil.isNotEmpty(getFcmMarginTotalGreaterThan())){
			c.andFcmMarginTotalGreaterThan(this.getFcmMarginTotalGreaterThan());
		}
		if(CheckUtil.isNotEmpty(getFcmMarginTotalEqualTo())){
			c.andFcmMarginTotalEqualTo(this.getFcmMarginTotalEqualTo());
		}
		if(CheckUtil.isNotEmpty(getFcmMarginPayRequireNotIn())){
			c.andFcmMarginPayRequireNotIn(this.getFcmMarginPayRequireNotIn());
		}
		if(CheckUtil.isNotEmpty(getFcmMarginPayRequireNotEqualTo())){
			c.andFcmMarginPayRequireNotEqualTo(this.getFcmMarginPayRequireNotEqualTo());
		}
		if(CheckUtil.isNotEmpty(getFcmMarginPayRequireLessThanOrEqualTo())){
			c.andFcmMarginPayRequireLessThanOrEqualTo(this.getFcmMarginPayRequireLessThanOrEqualTo());
		}
		if(CheckUtil.isNotEmpty(getFcmMarginPayRequireLessThan())){
			c.andFcmMarginPayRequireLessThan(this.getFcmMarginPayRequireLessThan());
		}
		if(CheckUtil.isNotEmpty(getFcmMarginPayRequireIsNull()) && this.getFcmMarginPayRequireIsNull()){
			c.andFcmMarginPayRequireIsNull();
		}
		if(CheckUtil.isNotEmpty(getFcmMarginPayRequireIsNotNull()) && this.getFcmMarginPayRequireIsNotNull()){
			c.andFcmMarginPayRequireIsNotNull();
		}
		if(CheckUtil.isNotEmpty(getFcmMarginPayRequireIn())){
			c.andFcmMarginPayRequireIn(this.getFcmMarginPayRequireIn());
		}
		if(CheckUtil.isNotEmpty(getFcmMarginPayRequireGreaterThanOrEqualTo())){
			c.andFcmMarginPayRequireGreaterThanOrEqualTo(this.getFcmMarginPayRequireGreaterThanOrEqualTo());
		}
		if(CheckUtil.isNotEmpty(getFcmMarginPayRequireGreaterThan())){
			c.andFcmMarginPayRequireGreaterThan(this.getFcmMarginPayRequireGreaterThan());
		}
		if(CheckUtil.isNotEmpty(getFcmMarginPayRequireEqualTo())){
			c.andFcmMarginPayRequireEqualTo(this.getFcmMarginPayRequireEqualTo());
		}
		if(CheckUtil.isNotEmpty(getFcmMarginMoneyNotIn())){
			c.andFcmMarginMoneyNotIn(this.getFcmMarginMoneyNotIn());
		}
		if(CheckUtil.isNotEmpty(getFcmMarginMoneyNotEqualTo())){
			c.andFcmMarginMoneyNotEqualTo(this.getFcmMarginMoneyNotEqualTo());
		}
		if(CheckUtil.isNotEmpty(getFcmMarginMoneyLessThanOrEqualTo())){
			c.andFcmMarginMoneyLessThanOrEqualTo(this.getFcmMarginMoneyLessThanOrEqualTo());
		}
		if(CheckUtil.isNotEmpty(getFcmMarginMoneyLessThan())){
			c.andFcmMarginMoneyLessThan(this.getFcmMarginMoneyLessThan());
		}
		if(CheckUtil.isNotEmpty(getFcmMarginMoneyIsNull()) && this.getFcmMarginMoneyIsNull()){
			c.andFcmMarginMoneyIsNull();
		}
		if(CheckUtil.isNotEmpty(getFcmMarginMoneyIsNotNull()) && this.getFcmMarginMoneyIsNotNull()){
			c.andFcmMarginMoneyIsNotNull();
		}
		if(CheckUtil.isNotEmpty(getFcmMarginMoneyIn())){
			c.andFcmMarginMoneyIn(this.getFcmMarginMoneyIn());
		}
		if(CheckUtil.isNotEmpty(getFcmMarginMoneyGreaterThanOrEqualTo())){
			c.andFcmMarginMoneyGreaterThanOrEqualTo(this.getFcmMarginMoneyGreaterThanOrEqualTo());
		}
		if(CheckUtil.isNotEmpty(getFcmMarginMoneyGreaterThan())){
			c.andFcmMarginMoneyGreaterThan(this.getFcmMarginMoneyGreaterThan());
		}
		if(CheckUtil.isNotEmpty(getFcmMarginMoneyEqualTo())){
			c.andFcmMarginMoneyEqualTo(this.getFcmMarginMoneyEqualTo());
		}
		if(CheckUtil.isNotEmpty(getFcmLeaseTypeNotIn())){
			c.andFcmLeaseTypeNotIn(this.getFcmLeaseTypeNotIn());
		}
		if(CheckUtil.isNotEmpty(getFcmLeaseTypeNotEqualTo())){
			c.andFcmLeaseTypeNotEqualTo(this.getFcmLeaseTypeNotEqualTo());
		}
		if(CheckUtil.isNotEmpty(getFcmLeaseTypeLessThanOrEqualTo())){
			c.andFcmLeaseTypeLessThanOrEqualTo(this.getFcmLeaseTypeLessThanOrEqualTo());
		}
		if(CheckUtil.isNotEmpty(getFcmLeaseTypeLessThan())){
			c.andFcmLeaseTypeLessThan(this.getFcmLeaseTypeLessThan());
		}
		if(CheckUtil.isNotEmpty(getFcmLeaseTypeIsNull()) && this.getFcmLeaseTypeIsNull()){
			c.andFcmLeaseTypeIsNull();
		}
		if(CheckUtil.isNotEmpty(getFcmLeaseTypeIsNotNull()) && this.getFcmLeaseTypeIsNotNull()){
			c.andFcmLeaseTypeIsNotNull();
		}
		if(CheckUtil.isNotEmpty(getFcmLeaseTypeIn())){
			c.andFcmLeaseTypeIn(this.getFcmLeaseTypeIn());
		}
		if(CheckUtil.isNotEmpty(getFcmLeaseTypeGreaterThanOrEqualTo())){
			c.andFcmLeaseTypeGreaterThanOrEqualTo(this.getFcmLeaseTypeGreaterThanOrEqualTo());
		}
		if(CheckUtil.isNotEmpty(getFcmLeaseTypeGreaterThan())){
			c.andFcmLeaseTypeGreaterThan(this.getFcmLeaseTypeGreaterThan());
		}
		if(CheckUtil.isNotEmpty(getFcmLeaseTypeEqualTo())){
			c.andFcmLeaseTypeEqualTo(this.getFcmLeaseTypeEqualTo());
		}
		if(CheckUtil.isNotEmpty(getFcmLeaseStartTypeNotIn())){
			c.andFcmLeaseStartTypeNotIn(this.getFcmLeaseStartTypeNotIn());
		}
		if(CheckUtil.isNotEmpty(getFcmLeaseStartTypeNotEqualTo())){
			c.andFcmLeaseStartTypeNotEqualTo(this.getFcmLeaseStartTypeNotEqualTo());
		}
		if(CheckUtil.isNotEmpty(getFcmLeaseStartTypeLessThanOrEqualTo())){
			c.andFcmLeaseStartTypeLessThanOrEqualTo(this.getFcmLeaseStartTypeLessThanOrEqualTo());
		}
		if(CheckUtil.isNotEmpty(getFcmLeaseStartTypeLessThan())){
			c.andFcmLeaseStartTypeLessThan(this.getFcmLeaseStartTypeLessThan());
		}
		if(CheckUtil.isNotEmpty(getFcmLeaseStartTypeIsNull()) && this.getFcmLeaseStartTypeIsNull()){
			c.andFcmLeaseStartTypeIsNull();
		}
		if(CheckUtil.isNotEmpty(getFcmLeaseStartTypeIsNotNull()) && this.getFcmLeaseStartTypeIsNotNull()){
			c.andFcmLeaseStartTypeIsNotNull();
		}
		if(CheckUtil.isNotEmpty(getFcmLeaseStartTypeIn())){
			c.andFcmLeaseStartTypeIn(this.getFcmLeaseStartTypeIn());
		}
		if(CheckUtil.isNotEmpty(getFcmLeaseStartTypeGreaterThanOrEqualTo())){
			c.andFcmLeaseStartTypeGreaterThanOrEqualTo(this.getFcmLeaseStartTypeGreaterThanOrEqualTo());
		}
		if(CheckUtil.isNotEmpty(getFcmLeaseStartTypeGreaterThan())){
			c.andFcmLeaseStartTypeGreaterThan(this.getFcmLeaseStartTypeGreaterThan());
		}
		if(CheckUtil.isNotEmpty(getFcmLeaseStartTypeEqualTo())){
			c.andFcmLeaseStartTypeEqualTo(this.getFcmLeaseStartTypeEqualTo());
		}
		if(CheckUtil.isNotEmpty(getFcmLeaseStartDateNotIn())){
			c.andFcmLeaseStartDateNotIn(this.getFcmLeaseStartDateNotIn());
		}
		if(CheckUtil.isNotEmpty(getFcmLeaseStartDateNotEqualTo())){
			c.andFcmLeaseStartDateNotEqualTo(this.getFcmLeaseStartDateNotEqualTo());
		}
		if(CheckUtil.isNotEmpty(getFcmLeaseStartDateLessThanOrEqualTo())){
			c.andFcmLeaseStartDateLessThanOrEqualTo(this.getFcmLeaseStartDateLessThanOrEqualTo());
		}
		if(CheckUtil.isNotEmpty(getFcmLeaseStartDateLessThan())){
			c.andFcmLeaseStartDateLessThan(this.getFcmLeaseStartDateLessThan());
		}
		if(CheckUtil.isNotEmpty(getFcmLeaseStartDateIsNull()) && this.getFcmLeaseStartDateIsNull()){
			c.andFcmLeaseStartDateIsNull();
		}
		if(CheckUtil.isNotEmpty(getFcmLeaseStartDateIsNotNull()) && this.getFcmLeaseStartDateIsNotNull()){
			c.andFcmLeaseStartDateIsNotNull();
		}
		if(CheckUtil.isNotEmpty(getFcmLeaseStartDateIn())){
			c.andFcmLeaseStartDateIn(this.getFcmLeaseStartDateIn());
		}
		if(CheckUtil.isNotEmpty(getFcmLeaseStartDateGreaterThanOrEqualTo())){
			c.andFcmLeaseStartDateGreaterThanOrEqualTo(this.getFcmLeaseStartDateGreaterThanOrEqualTo());
		}
		if(CheckUtil.isNotEmpty(getFcmLeaseStartDateGreaterThan())){
			c.andFcmLeaseStartDateGreaterThan(this.getFcmLeaseStartDateGreaterThan());
		}
		if(CheckUtil.isNotEmpty(getFcmLeaseStartDateEqualTo())){
			c.andFcmLeaseStartDateEqualTo(this.getFcmLeaseStartDateEqualTo());
		}
		if(CheckUtil.isNotEmpty(getFcmLeaseEndDateNotIn())){
			c.andFcmLeaseEndDateNotIn(this.getFcmLeaseEndDateNotIn());
		}
		if(CheckUtil.isNotEmpty(getFcmLeaseEndDateNotEqualTo())){
			c.andFcmLeaseEndDateNotEqualTo(this.getFcmLeaseEndDateNotEqualTo());
		}
		if(CheckUtil.isNotEmpty(getFcmLeaseEndDateLessThanOrEqualTo())){
			c.andFcmLeaseEndDateLessThanOrEqualTo(this.getFcmLeaseEndDateLessThanOrEqualTo());
		}
		if(CheckUtil.isNotEmpty(getFcmLeaseEndDateLessThan())){
			c.andFcmLeaseEndDateLessThan(this.getFcmLeaseEndDateLessThan());
		}
		if(CheckUtil.isNotEmpty(getFcmLeaseEndDateIsNull()) && this.getFcmLeaseEndDateIsNull()){
			c.andFcmLeaseEndDateIsNull();
		}
		if(CheckUtil.isNotEmpty(getFcmLeaseEndDateIsNotNull()) && this.getFcmLeaseEndDateIsNotNull()){
			c.andFcmLeaseEndDateIsNotNull();
		}
		if(CheckUtil.isNotEmpty(getFcmLeaseEndDateIn())){
			c.andFcmLeaseEndDateIn(this.getFcmLeaseEndDateIn());
		}
		if(CheckUtil.isNotEmpty(getFcmLeaseEndDateGreaterThanOrEqualTo())){
			c.andFcmLeaseEndDateGreaterThanOrEqualTo(this.getFcmLeaseEndDateGreaterThanOrEqualTo());
		}
		if(CheckUtil.isNotEmpty(getFcmLeaseEndDateGreaterThan())){
			c.andFcmLeaseEndDateGreaterThan(this.getFcmLeaseEndDateGreaterThan());
		}
		if(CheckUtil.isNotEmpty(getFcmLeaseEndDateEqualTo())){
			c.andFcmLeaseEndDateEqualTo(this.getFcmLeaseEndDateEqualTo());
		}
		if(CheckUtil.isNotEmpty(getFcmLeaseCountNotIn())){
			c.andFcmLeaseCountNotIn(this.getFcmLeaseCountNotIn());
		}
		if(CheckUtil.isNotEmpty(getFcmLeaseCountNotEqualTo())){
			c.andFcmLeaseCountNotEqualTo(this.getFcmLeaseCountNotEqualTo());
		}
		if(CheckUtil.isNotEmpty(getFcmLeaseCountLessThanOrEqualTo())){
			c.andFcmLeaseCountLessThanOrEqualTo(this.getFcmLeaseCountLessThanOrEqualTo());
		}
		if(CheckUtil.isNotEmpty(getFcmLeaseCountLessThan())){
			c.andFcmLeaseCountLessThan(this.getFcmLeaseCountLessThan());
		}
		if(CheckUtil.isNotEmpty(getFcmLeaseCountIsNull()) && this.getFcmLeaseCountIsNull()){
			c.andFcmLeaseCountIsNull();
		}
		if(CheckUtil.isNotEmpty(getFcmLeaseCountIsNotNull()) && this.getFcmLeaseCountIsNotNull()){
			c.andFcmLeaseCountIsNotNull();
		}
		if(CheckUtil.isNotEmpty(getFcmLeaseCountIn())){
			c.andFcmLeaseCountIn(this.getFcmLeaseCountIn());
		}
		if(CheckUtil.isNotEmpty(getFcmLeaseCountGreaterThanOrEqualTo())){
			c.andFcmLeaseCountGreaterThanOrEqualTo(this.getFcmLeaseCountGreaterThanOrEqualTo());
		}
		if(CheckUtil.isNotEmpty(getFcmLeaseCountGreaterThan())){
			c.andFcmLeaseCountGreaterThan(this.getFcmLeaseCountGreaterThan());
		}
		if(CheckUtil.isNotEmpty(getFcmLeaseCountEqualTo())){
			c.andFcmLeaseCountEqualTo(this.getFcmLeaseCountEqualTo());
		}
		if(CheckUtil.isNotEmpty(getFcmLeaseCalculateTypeNotIn())){
			c.andFcmLeaseCalculateTypeNotIn(this.getFcmLeaseCalculateTypeNotIn());
		}
		if(CheckUtil.isNotEmpty(getFcmLeaseCalculateTypeNotEqualTo())){
			c.andFcmLeaseCalculateTypeNotEqualTo(this.getFcmLeaseCalculateTypeNotEqualTo());
		}
		if(CheckUtil.isNotEmpty(getFcmLeaseCalculateTypeLessThanOrEqualTo())){
			c.andFcmLeaseCalculateTypeLessThanOrEqualTo(this.getFcmLeaseCalculateTypeLessThanOrEqualTo());
		}
		if(CheckUtil.isNotEmpty(getFcmLeaseCalculateTypeLessThan())){
			c.andFcmLeaseCalculateTypeLessThan(this.getFcmLeaseCalculateTypeLessThan());
		}
		if(CheckUtil.isNotEmpty(getFcmLeaseCalculateTypeIsNull()) && this.getFcmLeaseCalculateTypeIsNull()){
			c.andFcmLeaseCalculateTypeIsNull();
		}
		if(CheckUtil.isNotEmpty(getFcmLeaseCalculateTypeIsNotNull()) && this.getFcmLeaseCalculateTypeIsNotNull()){
			c.andFcmLeaseCalculateTypeIsNotNull();
		}
		if(CheckUtil.isNotEmpty(getFcmLeaseCalculateTypeIn())){
			c.andFcmLeaseCalculateTypeIn(this.getFcmLeaseCalculateTypeIn());
		}
		if(CheckUtil.isNotEmpty(getFcmLeaseCalculateTypeGreaterThanOrEqualTo())){
			c.andFcmLeaseCalculateTypeGreaterThanOrEqualTo(this.getFcmLeaseCalculateTypeGreaterThanOrEqualTo());
		}
		if(CheckUtil.isNotEmpty(getFcmLeaseCalculateTypeGreaterThan())){
			c.andFcmLeaseCalculateTypeGreaterThan(this.getFcmLeaseCalculateTypeGreaterThan());
		}
		if(CheckUtil.isNotEmpty(getFcmLeaseCalculateTypeEqualTo())){
			c.andFcmLeaseCalculateTypeEqualTo(this.getFcmLeaseCalculateTypeEqualTo());
		}
		if(CheckUtil.isNotEmpty(getFcmLeaseAmountTotalNotIn())){
			c.andFcmLeaseAmountTotalNotIn(this.getFcmLeaseAmountTotalNotIn());
		}
		if(CheckUtil.isNotEmpty(getFcmLeaseAmountTotalNotEqualTo())){
			c.andFcmLeaseAmountTotalNotEqualTo(this.getFcmLeaseAmountTotalNotEqualTo());
		}
		if(CheckUtil.isNotEmpty(getFcmLeaseAmountTotalLessThanOrEqualTo())){
			c.andFcmLeaseAmountTotalLessThanOrEqualTo(this.getFcmLeaseAmountTotalLessThanOrEqualTo());
		}
		if(CheckUtil.isNotEmpty(getFcmLeaseAmountTotalLessThan())){
			c.andFcmLeaseAmountTotalLessThan(this.getFcmLeaseAmountTotalLessThan());
		}
		if(CheckUtil.isNotEmpty(getFcmLeaseAmountTotalIsNull()) && this.getFcmLeaseAmountTotalIsNull()){
			c.andFcmLeaseAmountTotalIsNull();
		}
		if(CheckUtil.isNotEmpty(getFcmLeaseAmountTotalIsNotNull()) && this.getFcmLeaseAmountTotalIsNotNull()){
			c.andFcmLeaseAmountTotalIsNotNull();
		}
		if(CheckUtil.isNotEmpty(getFcmLeaseAmountTotalIn())){
			c.andFcmLeaseAmountTotalIn(this.getFcmLeaseAmountTotalIn());
		}
		if(CheckUtil.isNotEmpty(getFcmLeaseAmountTotalGreaterThanOrEqualTo())){
			c.andFcmLeaseAmountTotalGreaterThanOrEqualTo(this.getFcmLeaseAmountTotalGreaterThanOrEqualTo());
		}
		if(CheckUtil.isNotEmpty(getFcmLeaseAmountTotalGreaterThan())){
			c.andFcmLeaseAmountTotalGreaterThan(this.getFcmLeaseAmountTotalGreaterThan());
		}
		if(CheckUtil.isNotEmpty(getFcmLeaseAmountTotalEqualTo())){
			c.andFcmLeaseAmountTotalEqualTo(this.getFcmLeaseAmountTotalEqualTo());
		}
		if(CheckUtil.isNotEmpty(getFcmLeaseAmountNotIn())){
			c.andFcmLeaseAmountNotIn(this.getFcmLeaseAmountNotIn());
		}
		if(CheckUtil.isNotEmpty(getFcmLeaseAmountNotEqualTo())){
			c.andFcmLeaseAmountNotEqualTo(this.getFcmLeaseAmountNotEqualTo());
		}
		if(CheckUtil.isNotEmpty(getFcmLeaseAmountLessThanOrEqualTo())){
			c.andFcmLeaseAmountLessThanOrEqualTo(this.getFcmLeaseAmountLessThanOrEqualTo());
		}
		if(CheckUtil.isNotEmpty(getFcmLeaseAmountLessThan())){
			c.andFcmLeaseAmountLessThan(this.getFcmLeaseAmountLessThan());
		}
		if(CheckUtil.isNotEmpty(getFcmLeaseAmountIsNull()) && this.getFcmLeaseAmountIsNull()){
			c.andFcmLeaseAmountIsNull();
		}
		if(CheckUtil.isNotEmpty(getFcmLeaseAmountIsNotNull()) && this.getFcmLeaseAmountIsNotNull()){
			c.andFcmLeaseAmountIsNotNull();
		}
		if(CheckUtil.isNotEmpty(getFcmLeaseAmountIn())){
			c.andFcmLeaseAmountIn(this.getFcmLeaseAmountIn());
		}
		if(CheckUtil.isNotEmpty(getFcmLeaseAmountGreaterThanOrEqualTo())){
			c.andFcmLeaseAmountGreaterThanOrEqualTo(this.getFcmLeaseAmountGreaterThanOrEqualTo());
		}
		if(CheckUtil.isNotEmpty(getFcmLeaseAmountGreaterThan())){
			c.andFcmLeaseAmountGreaterThan(this.getFcmLeaseAmountGreaterThan());
		}
		if(CheckUtil.isNotEmpty(getFcmLeaseAmountEqualTo())){
			c.andFcmLeaseAmountEqualTo(this.getFcmLeaseAmountEqualTo());
		}
		if(CheckUtil.isNotEmpty(getFcmIdNotIn())){
			c.andFcmIdNotIn(this.getFcmIdNotIn());
		}
		if(CheckUtil.isNotEmpty(getFcmIdNotEqualTo())){
			c.andFcmIdNotEqualTo(this.getFcmIdNotEqualTo());
		}
		if(CheckUtil.isNotEmpty(getFcmIdLessThanOrEqualTo())){
			c.andFcmIdLessThanOrEqualTo(this.getFcmIdLessThanOrEqualTo());
		}
		if(CheckUtil.isNotEmpty(getFcmIdLessThan())){
			c.andFcmIdLessThan(this.getFcmIdLessThan());
		}
		if(CheckUtil.isNotEmpty(getFcmIdIsNull()) && this.getFcmIdIsNull()){
			c.andFcmIdIsNull();
		}
		if(CheckUtil.isNotEmpty(getFcmIdIsNotNull()) && this.getFcmIdIsNotNull()){
			c.andFcmIdIsNotNull();
		}
		if(CheckUtil.isNotEmpty(getFcmIdIn())){
			c.andFcmIdIn(this.getFcmIdIn());
		}
		if(CheckUtil.isNotEmpty(getFcmIdGreaterThanOrEqualTo())){
			c.andFcmIdGreaterThanOrEqualTo(this.getFcmIdGreaterThanOrEqualTo());
		}
		if(CheckUtil.isNotEmpty(getFcmIdGreaterThan())){
			c.andFcmIdGreaterThan(this.getFcmIdGreaterThan());
		}
		if(CheckUtil.isNotEmpty(getFcmIdEqualTo())){
			c.andFcmIdEqualTo(this.getFcmIdEqualTo());
		}
		if(CheckUtil.isNotEmpty(getFcmGiveSequenceNotIn())){
			c.andFcmGiveSequenceNotIn(this.getFcmGiveSequenceNotIn());
		}
		if(CheckUtil.isNotEmpty(getFcmGiveSequenceNotEqualTo())){
			c.andFcmGiveSequenceNotEqualTo(this.getFcmGiveSequenceNotEqualTo());
		}
		if(CheckUtil.isNotEmpty(getFcmGiveSequenceLessThanOrEqualTo())){
			c.andFcmGiveSequenceLessThanOrEqualTo(this.getFcmGiveSequenceLessThanOrEqualTo());
		}
		if(CheckUtil.isNotEmpty(getFcmGiveSequenceLessThan())){
			c.andFcmGiveSequenceLessThan(this.getFcmGiveSequenceLessThan());
		}
		if(CheckUtil.isNotEmpty(getFcmGiveSequenceIsNull()) && this.getFcmGiveSequenceIsNull()){
			c.andFcmGiveSequenceIsNull();
		}
		if(CheckUtil.isNotEmpty(getFcmGiveSequenceIsNotNull()) && this.getFcmGiveSequenceIsNotNull()){
			c.andFcmGiveSequenceIsNotNull();
		}
		if(CheckUtil.isNotEmpty(getFcmGiveSequenceIn())){
			c.andFcmGiveSequenceIn(this.getFcmGiveSequenceIn());
		}
		if(CheckUtil.isNotEmpty(getFcmGiveSequenceGreaterThanOrEqualTo())){
			c.andFcmGiveSequenceGreaterThanOrEqualTo(this.getFcmGiveSequenceGreaterThanOrEqualTo());
		}
		if(CheckUtil.isNotEmpty(getFcmGiveSequenceGreaterThan())){
			c.andFcmGiveSequenceGreaterThan(this.getFcmGiveSequenceGreaterThan());
		}
		if(CheckUtil.isNotEmpty(getFcmGiveSequenceEqualTo())){
			c.andFcmGiveSequenceEqualTo(this.getFcmGiveSequenceEqualTo());
		}
		if(CheckUtil.isNotEmpty(getFcmGiveLeaseNotIn())){
			c.andFcmGiveLeaseNotIn(this.getFcmGiveLeaseNotIn());
		}
		if(CheckUtil.isNotEmpty(getFcmGiveLeaseNotEqualTo())){
			c.andFcmGiveLeaseNotEqualTo(this.getFcmGiveLeaseNotEqualTo());
		}
		if(CheckUtil.isNotEmpty(getFcmGiveLeaseLessThanOrEqualTo())){
			c.andFcmGiveLeaseLessThanOrEqualTo(this.getFcmGiveLeaseLessThanOrEqualTo());
		}
		if(CheckUtil.isNotEmpty(getFcmGiveLeaseLessThan())){
			c.andFcmGiveLeaseLessThan(this.getFcmGiveLeaseLessThan());
		}
		if(CheckUtil.isNotEmpty(getFcmGiveLeaseIsNull()) && this.getFcmGiveLeaseIsNull()){
			c.andFcmGiveLeaseIsNull();
		}
		if(CheckUtil.isNotEmpty(getFcmGiveLeaseIsNotNull()) && this.getFcmGiveLeaseIsNotNull()){
			c.andFcmGiveLeaseIsNotNull();
		}
		if(CheckUtil.isNotEmpty(getFcmGiveLeaseIn())){
			c.andFcmGiveLeaseIn(this.getFcmGiveLeaseIn());
		}
		if(CheckUtil.isNotEmpty(getFcmGiveLeaseGreaterThanOrEqualTo())){
			c.andFcmGiveLeaseGreaterThanOrEqualTo(this.getFcmGiveLeaseGreaterThanOrEqualTo());
		}
		if(CheckUtil.isNotEmpty(getFcmGiveLeaseGreaterThan())){
			c.andFcmGiveLeaseGreaterThan(this.getFcmGiveLeaseGreaterThan());
		}
		if(CheckUtil.isNotEmpty(getFcmGiveLeaseEqualTo())){
			c.andFcmGiveLeaseEqualTo(this.getFcmGiveLeaseEqualTo());
		}
		if(CheckUtil.isNotEmpty(getFcmDeliverTypeNotIn())){
			c.andFcmDeliverTypeNotIn(this.getFcmDeliverTypeNotIn());
		}
		if(CheckUtil.isNotEmpty(getFcmDeliverTypeNotEqualTo())){
			c.andFcmDeliverTypeNotEqualTo(this.getFcmDeliverTypeNotEqualTo());
		}
		if(CheckUtil.isNotEmpty(getFcmDeliverTypeLessThanOrEqualTo())){
			c.andFcmDeliverTypeLessThanOrEqualTo(this.getFcmDeliverTypeLessThanOrEqualTo());
		}
		if(CheckUtil.isNotEmpty(getFcmDeliverTypeLessThan())){
			c.andFcmDeliverTypeLessThan(this.getFcmDeliverTypeLessThan());
		}
		if(CheckUtil.isNotEmpty(getFcmDeliverTypeIsNull()) && this.getFcmDeliverTypeIsNull()){
			c.andFcmDeliverTypeIsNull();
		}
		if(CheckUtil.isNotEmpty(getFcmDeliverTypeIsNotNull()) && this.getFcmDeliverTypeIsNotNull()){
			c.andFcmDeliverTypeIsNotNull();
		}
		if(CheckUtil.isNotEmpty(getFcmDeliverTypeIn())){
			c.andFcmDeliverTypeIn(this.getFcmDeliverTypeIn());
		}
		if(CheckUtil.isNotEmpty(getFcmDeliverTypeGreaterThanOrEqualTo())){
			c.andFcmDeliverTypeGreaterThanOrEqualTo(this.getFcmDeliverTypeGreaterThanOrEqualTo());
		}
		if(CheckUtil.isNotEmpty(getFcmDeliverTypeGreaterThan())){
			c.andFcmDeliverTypeGreaterThan(this.getFcmDeliverTypeGreaterThan());
		}
		if(CheckUtil.isNotEmpty(getFcmDeliverTypeEqualTo())){
			c.andFcmDeliverTypeEqualTo(this.getFcmDeliverTypeEqualTo());
		}
		if(CheckUtil.isNotEmpty(getFcmDeliverCityNotIn())){
			c.andFcmDeliverCityNotIn(this.getFcmDeliverCityNotIn());
		}
		if(CheckUtil.isNotEmpty(getFcmDeliverCityNotEqualTo())){
			c.andFcmDeliverCityNotEqualTo(this.getFcmDeliverCityNotEqualTo());
		}
		if(CheckUtil.isNotEmpty(getFcmDeliverCityLessThanOrEqualTo())){
			c.andFcmDeliverCityLessThanOrEqualTo(this.getFcmDeliverCityLessThanOrEqualTo());
		}
		if(CheckUtil.isNotEmpty(getFcmDeliverCityLessThan())){
			c.andFcmDeliverCityLessThan(this.getFcmDeliverCityLessThan());
		}
		if(CheckUtil.isNotEmpty(getFcmDeliverCityIsNull()) && this.getFcmDeliverCityIsNull()){
			c.andFcmDeliverCityIsNull();
		}
		if(CheckUtil.isNotEmpty(getFcmDeliverCityIsNotNull()) && this.getFcmDeliverCityIsNotNull()){
			c.andFcmDeliverCityIsNotNull();
		}
		if(CheckUtil.isNotEmpty(getFcmDeliverCityIn())){
			c.andFcmDeliverCityIn(this.getFcmDeliverCityIn());
		}
		if(CheckUtil.isNotEmpty(getFcmDeliverCityGreaterThanOrEqualTo())){
			c.andFcmDeliverCityGreaterThanOrEqualTo(this.getFcmDeliverCityGreaterThanOrEqualTo());
		}
		if(CheckUtil.isNotEmpty(getFcmDeliverCityGreaterThan())){
			c.andFcmDeliverCityGreaterThan(this.getFcmDeliverCityGreaterThan());
		}
		if(CheckUtil.isNotEmpty(getFcmDeliverCityEqualTo())){
			c.andFcmDeliverCityEqualTo(this.getFcmDeliverCityEqualTo());
		}
		if(CheckUtil.isNotEmpty(getFcmCreatePhoneNotLike())){
			c.andFcmCreatePhoneNotLike("%"+this.getFcmCreatePhoneNotLike()+"%");
		}
		if(CheckUtil.isNotEmpty(getFcmCreatePhoneNotIn())){
			c.andFcmCreatePhoneNotIn(this.getFcmCreatePhoneNotIn());
		}
		if(CheckUtil.isNotEmpty(getFcmCreatePhoneNotEqualTo())){
			c.andFcmCreatePhoneNotEqualTo(this.getFcmCreatePhoneNotEqualTo());
		}
		if(CheckUtil.isNotEmpty(getFcmCreatePhoneLike())){
			c.andFcmCreatePhoneLike("%"+this.getFcmCreatePhoneLike()+"%");
		}
		if(CheckUtil.isNotEmpty(getFcmCreatePhoneLessThanOrEqualTo())){
			c.andFcmCreatePhoneLessThanOrEqualTo(this.getFcmCreatePhoneLessThanOrEqualTo());
		}
		if(CheckUtil.isNotEmpty(getFcmCreatePhoneLessThan())){
			c.andFcmCreatePhoneLessThan(this.getFcmCreatePhoneLessThan());
		}
		if(CheckUtil.isNotEmpty(getFcmCreatePhoneIsNull()) && this.getFcmCreatePhoneIsNull()){
			c.andFcmCreatePhoneIsNull();
		}
		if(CheckUtil.isNotEmpty(getFcmCreatePhoneIsNotNull()) && this.getFcmCreatePhoneIsNotNull()){
			c.andFcmCreatePhoneIsNotNull();
		}
		if(CheckUtil.isNotEmpty(getFcmCreatePhoneIn())){
			c.andFcmCreatePhoneIn(this.getFcmCreatePhoneIn());
		}
		if(CheckUtil.isNotEmpty(getFcmCreatePhoneGreaterThanOrEqualTo())){
			c.andFcmCreatePhoneGreaterThanOrEqualTo(this.getFcmCreatePhoneGreaterThanOrEqualTo());
		}
		if(CheckUtil.isNotEmpty(getFcmCreatePhoneGreaterThan())){
			c.andFcmCreatePhoneGreaterThan(this.getFcmCreatePhoneGreaterThan());
		}
		if(CheckUtil.isNotEmpty(getFcmCreatePhoneEqualTo())){
			c.andFcmCreatePhoneEqualTo(this.getFcmCreatePhoneEqualTo());
		}
		if(CheckUtil.isNotEmpty(getFcmContractTypeNotIn())){
			c.andFcmContractTypeNotIn(this.getFcmContractTypeNotIn());
		}
		if(CheckUtil.isNotEmpty(getFcmContractTypeNotEqualTo())){
			c.andFcmContractTypeNotEqualTo(this.getFcmContractTypeNotEqualTo());
		}
		if(CheckUtil.isNotEmpty(getFcmContractTypeLessThanOrEqualTo())){
			c.andFcmContractTypeLessThanOrEqualTo(this.getFcmContractTypeLessThanOrEqualTo());
		}
		if(CheckUtil.isNotEmpty(getFcmContractTypeLessThan())){
			c.andFcmContractTypeLessThan(this.getFcmContractTypeLessThan());
		}
		if(CheckUtil.isNotEmpty(getFcmContractTypeIsNull()) && this.getFcmContractTypeIsNull()){
			c.andFcmContractTypeIsNull();
		}
		if(CheckUtil.isNotEmpty(getFcmContractTypeIsNotNull()) && this.getFcmContractTypeIsNotNull()){
			c.andFcmContractTypeIsNotNull();
		}
		if(CheckUtil.isNotEmpty(getFcmContractTypeIn())){
			c.andFcmContractTypeIn(this.getFcmContractTypeIn());
		}
		if(CheckUtil.isNotEmpty(getFcmContractTypeGreaterThanOrEqualTo())){
			c.andFcmContractTypeGreaterThanOrEqualTo(this.getFcmContractTypeGreaterThanOrEqualTo());
		}
		if(CheckUtil.isNotEmpty(getFcmContractTypeGreaterThan())){
			c.andFcmContractTypeGreaterThan(this.getFcmContractTypeGreaterThan());
		}
		if(CheckUtil.isNotEmpty(getFcmContractTypeEqualTo())){
			c.andFcmContractTypeEqualTo(this.getFcmContractTypeEqualTo());
		}
		if(CheckUtil.isNotEmpty(getFcmContractStateNotIn())){
			c.andFcmContractStateNotIn(this.getFcmContractStateNotIn());
		}
		if(CheckUtil.isNotEmpty(getFcmContractStateNotEqualTo())){
			c.andFcmContractStateNotEqualTo(this.getFcmContractStateNotEqualTo());
		}
		if(CheckUtil.isNotEmpty(getFcmContractStateLessThanOrEqualTo())){
			c.andFcmContractStateLessThanOrEqualTo(this.getFcmContractStateLessThanOrEqualTo());
		}
		if(CheckUtil.isNotEmpty(getFcmContractStateLessThan())){
			c.andFcmContractStateLessThan(this.getFcmContractStateLessThan());
		}
		if(CheckUtil.isNotEmpty(getFcmContractStateIsNull()) && this.getFcmContractStateIsNull()){
			c.andFcmContractStateIsNull();
		}
		if(CheckUtil.isNotEmpty(getFcmContractStateIsNotNull()) && this.getFcmContractStateIsNotNull()){
			c.andFcmContractStateIsNotNull();
		}
		if(CheckUtil.isNotEmpty(getFcmContractStateIn())){
			c.andFcmContractStateIn(this.getFcmContractStateIn());
		}
		if(CheckUtil.isNotEmpty(getFcmContractStateGreaterThanOrEqualTo())){
			c.andFcmContractStateGreaterThanOrEqualTo(this.getFcmContractStateGreaterThanOrEqualTo());
		}
		if(CheckUtil.isNotEmpty(getFcmContractStateGreaterThan())){
			c.andFcmContractStateGreaterThan(this.getFcmContractStateGreaterThan());
		}
		if(CheckUtil.isNotEmpty(getFcmContractStateEqualTo())){
			c.andFcmContractStateEqualTo(this.getFcmContractStateEqualTo());
		}
		if(CheckUtil.isNotEmpty(getFcmContractNoNotLike())){
			c.andFcmContractNoNotLike("%"+this.getFcmContractNoNotLike()+"%");
		}
		if(CheckUtil.isNotEmpty(getFcmContractNoNotIn())){
			c.andFcmContractNoNotIn(this.getFcmContractNoNotIn());
		}
		if(CheckUtil.isNotEmpty(getFcmContractNoNotEqualTo())){
			c.andFcmContractNoNotEqualTo(this.getFcmContractNoNotEqualTo());
		}
		if(CheckUtil.isNotEmpty(getFcmContractNoLike())){
			c.andFcmContractNoLike("%"+this.getFcmContractNoLike()+"%");
		}
		if(CheckUtil.isNotEmpty(getFcmContractNoLessThanOrEqualTo())){
			c.andFcmContractNoLessThanOrEqualTo(this.getFcmContractNoLessThanOrEqualTo());
		}
		if(CheckUtil.isNotEmpty(getFcmContractNoLessThan())){
			c.andFcmContractNoLessThan(this.getFcmContractNoLessThan());
		}
		if(CheckUtil.isNotEmpty(getFcmContractNoIsNull()) && this.getFcmContractNoIsNull()){
			c.andFcmContractNoIsNull();
		}
		if(CheckUtil.isNotEmpty(getFcmContractNoIsNotNull()) && this.getFcmContractNoIsNotNull()){
			c.andFcmContractNoIsNotNull();
		}
		if(CheckUtil.isNotEmpty(getFcmContractNoIn())){
			c.andFcmContractNoIn(this.getFcmContractNoIn());
		}
		if(CheckUtil.isNotEmpty(getFcmContractNoGreaterThanOrEqualTo())){
			c.andFcmContractNoGreaterThanOrEqualTo(this.getFcmContractNoGreaterThanOrEqualTo());
		}
		if(CheckUtil.isNotEmpty(getFcmContractNoGreaterThan())){
			c.andFcmContractNoGreaterThan(this.getFcmContractNoGreaterThan());
		}
		if(CheckUtil.isNotEmpty(getFcmContractNoEqualTo())){
			c.andFcmContractNoEqualTo(this.getFcmContractNoEqualTo());
		}
		if(CheckUtil.isNotEmpty(getFcmCityIdNotIn())){
			c.andFcmCityIdNotIn(this.getFcmCityIdNotIn());
		}
		if(CheckUtil.isNotEmpty(getFcmCityIdNotEqualTo())){
			c.andFcmCityIdNotEqualTo(this.getFcmCityIdNotEqualTo());
		}
		if(CheckUtil.isNotEmpty(getFcmCityIdLessThanOrEqualTo())){
			c.andFcmCityIdLessThanOrEqualTo(this.getFcmCityIdLessThanOrEqualTo());
		}
		if(CheckUtil.isNotEmpty(getFcmCityIdLessThan())){
			c.andFcmCityIdLessThan(this.getFcmCityIdLessThan());
		}
		if(CheckUtil.isNotEmpty(getFcmCityIdIsNull()) && this.getFcmCityIdIsNull()){
			c.andFcmCityIdIsNull();
		}
		if(CheckUtil.isNotEmpty(getFcmCityIdIsNotNull()) && this.getFcmCityIdIsNotNull()){
			c.andFcmCityIdIsNotNull();
		}
		if(CheckUtil.isNotEmpty(getFcmCityIdIn())){
			c.andFcmCityIdIn(this.getFcmCityIdIn());
		}
		if(CheckUtil.isNotEmpty(getFcmCityIdGreaterThanOrEqualTo())){
			c.andFcmCityIdGreaterThanOrEqualTo(this.getFcmCityIdGreaterThanOrEqualTo());
		}
		if(CheckUtil.isNotEmpty(getFcmCityIdGreaterThan())){
			c.andFcmCityIdGreaterThan(this.getFcmCityIdGreaterThan());
		}
		if(CheckUtil.isNotEmpty(getFcmCityIdEqualTo())){
			c.andFcmCityIdEqualTo(this.getFcmCityIdEqualTo());
		}
		if(CheckUtil.isNotEmpty(getFcmCarnumTotalNotIn())){
			c.andFcmCarnumTotalNotIn(this.getFcmCarnumTotalNotIn());
		}
		if(CheckUtil.isNotEmpty(getFcmCarnumTotalNotEqualTo())){
			c.andFcmCarnumTotalNotEqualTo(this.getFcmCarnumTotalNotEqualTo());
		}
		if(CheckUtil.isNotEmpty(getFcmCarnumTotalLessThanOrEqualTo())){
			c.andFcmCarnumTotalLessThanOrEqualTo(this.getFcmCarnumTotalLessThanOrEqualTo());
		}
		if(CheckUtil.isNotEmpty(getFcmCarnumTotalLessThan())){
			c.andFcmCarnumTotalLessThan(this.getFcmCarnumTotalLessThan());
		}
		if(CheckUtil.isNotEmpty(getFcmCarnumTotalIsNull()) && this.getFcmCarnumTotalIsNull()){
			c.andFcmCarnumTotalIsNull();
		}
		if(CheckUtil.isNotEmpty(getFcmCarnumTotalIsNotNull()) && this.getFcmCarnumTotalIsNotNull()){
			c.andFcmCarnumTotalIsNotNull();
		}
		if(CheckUtil.isNotEmpty(getFcmCarnumTotalIn())){
			c.andFcmCarnumTotalIn(this.getFcmCarnumTotalIn());
		}
		if(CheckUtil.isNotEmpty(getFcmCarnumTotalGreaterThanOrEqualTo())){
			c.andFcmCarnumTotalGreaterThanOrEqualTo(this.getFcmCarnumTotalGreaterThanOrEqualTo());
		}
		if(CheckUtil.isNotEmpty(getFcmCarnumTotalGreaterThan())){
			c.andFcmCarnumTotalGreaterThan(this.getFcmCarnumTotalGreaterThan());
		}
		if(CheckUtil.isNotEmpty(getFcmCarnumTotalEqualTo())){
			c.andFcmCarnumTotalEqualTo(this.getFcmCarnumTotalEqualTo());
		}
		if(CheckUtil.isNotEmpty(getFcmCarTypeIdNotIn())){
			c.andFcmCarTypeIdNotIn(this.getFcmCarTypeIdNotIn());
		}
		if(CheckUtil.isNotEmpty(getFcmCarTypeIdNotEqualTo())){
			c.andFcmCarTypeIdNotEqualTo(this.getFcmCarTypeIdNotEqualTo());
		}
		if(CheckUtil.isNotEmpty(getFcmCarTypeIdLessThanOrEqualTo())){
			c.andFcmCarTypeIdLessThanOrEqualTo(this.getFcmCarTypeIdLessThanOrEqualTo());
		}
		if(CheckUtil.isNotEmpty(getFcmCarTypeIdLessThan())){
			c.andFcmCarTypeIdLessThan(this.getFcmCarTypeIdLessThan());
		}
		if(CheckUtil.isNotEmpty(getFcmCarTypeIdIsNull()) && this.getFcmCarTypeIdIsNull()){
			c.andFcmCarTypeIdIsNull();
		}
		if(CheckUtil.isNotEmpty(getFcmCarTypeIdIsNotNull()) && this.getFcmCarTypeIdIsNotNull()){
			c.andFcmCarTypeIdIsNotNull();
		}
		if(CheckUtil.isNotEmpty(getFcmCarTypeIdIn())){
			c.andFcmCarTypeIdIn(this.getFcmCarTypeIdIn());
		}
		if(CheckUtil.isNotEmpty(getFcmCarTypeIdGreaterThanOrEqualTo())){
			c.andFcmCarTypeIdGreaterThanOrEqualTo(this.getFcmCarTypeIdGreaterThanOrEqualTo());
		}
		if(CheckUtil.isNotEmpty(getFcmCarTypeIdGreaterThan())){
			c.andFcmCarTypeIdGreaterThan(this.getFcmCarTypeIdGreaterThan());
		}
		if(CheckUtil.isNotEmpty(getFcmCarTypeIdEqualTo())){
			c.andFcmCarTypeIdEqualTo(this.getFcmCarTypeIdEqualTo());
		}
		if(CheckUtil.isNotEmpty(getFcmCarPurchaseNotIn())){
			c.andFcmCarPurchaseNotIn(this.getFcmCarPurchaseNotIn());
		}
		if(CheckUtil.isNotEmpty(getFcmCarPurchaseNotEqualTo())){
			c.andFcmCarPurchaseNotEqualTo(this.getFcmCarPurchaseNotEqualTo());
		}
		if(CheckUtil.isNotEmpty(getFcmCarPurchaseLessThanOrEqualTo())){
			c.andFcmCarPurchaseLessThanOrEqualTo(this.getFcmCarPurchaseLessThanOrEqualTo());
		}
		if(CheckUtil.isNotEmpty(getFcmCarPurchaseLessThan())){
			c.andFcmCarPurchaseLessThan(this.getFcmCarPurchaseLessThan());
		}
		if(CheckUtil.isNotEmpty(getFcmCarPurchaseIsNull()) && this.getFcmCarPurchaseIsNull()){
			c.andFcmCarPurchaseIsNull();
		}
		if(CheckUtil.isNotEmpty(getFcmCarPurchaseIsNotNull()) && this.getFcmCarPurchaseIsNotNull()){
			c.andFcmCarPurchaseIsNotNull();
		}
		if(CheckUtil.isNotEmpty(getFcmCarPurchaseIn())){
			c.andFcmCarPurchaseIn(this.getFcmCarPurchaseIn());
		}
		if(CheckUtil.isNotEmpty(getFcmCarPurchaseGreaterThanOrEqualTo())){
			c.andFcmCarPurchaseGreaterThanOrEqualTo(this.getFcmCarPurchaseGreaterThanOrEqualTo());
		}
		if(CheckUtil.isNotEmpty(getFcmCarPurchaseGreaterThan())){
			c.andFcmCarPurchaseGreaterThan(this.getFcmCarPurchaseGreaterThan());
		}
		if(CheckUtil.isNotEmpty(getFcmCarPurchaseEqualTo())){
			c.andFcmCarPurchaseEqualTo(this.getFcmCarPurchaseEqualTo());
		}
		if(CheckUtil.isNotEmpty(getFcmCarPurchaseAdvanceNotLike())){
			c.andFcmCarPurchaseAdvanceNotLike("%"+this.getFcmCarPurchaseAdvanceNotLike()+"%");
		}
		if(CheckUtil.isNotEmpty(getFcmCarPurchaseAdvanceNotIn())){
			c.andFcmCarPurchaseAdvanceNotIn(this.getFcmCarPurchaseAdvanceNotIn());
		}
		if(CheckUtil.isNotEmpty(getFcmCarPurchaseAdvanceNotEqualTo())){
			c.andFcmCarPurchaseAdvanceNotEqualTo(this.getFcmCarPurchaseAdvanceNotEqualTo());
		}
		if(CheckUtil.isNotEmpty(getFcmCarPurchaseAdvanceLike())){
			c.andFcmCarPurchaseAdvanceLike("%"+this.getFcmCarPurchaseAdvanceLike()+"%");
		}
		if(CheckUtil.isNotEmpty(getFcmCarPurchaseAdvanceLessThanOrEqualTo())){
			c.andFcmCarPurchaseAdvanceLessThanOrEqualTo(this.getFcmCarPurchaseAdvanceLessThanOrEqualTo());
		}
		if(CheckUtil.isNotEmpty(getFcmCarPurchaseAdvanceLessThan())){
			c.andFcmCarPurchaseAdvanceLessThan(this.getFcmCarPurchaseAdvanceLessThan());
		}
		if(CheckUtil.isNotEmpty(getFcmCarPurchaseAdvanceIsNull()) && this.getFcmCarPurchaseAdvanceIsNull()){
			c.andFcmCarPurchaseAdvanceIsNull();
		}
		if(CheckUtil.isNotEmpty(getFcmCarPurchaseAdvanceIsNotNull()) && this.getFcmCarPurchaseAdvanceIsNotNull()){
			c.andFcmCarPurchaseAdvanceIsNotNull();
		}
		if(CheckUtil.isNotEmpty(getFcmCarPurchaseAdvanceIn())){
			c.andFcmCarPurchaseAdvanceIn(this.getFcmCarPurchaseAdvanceIn());
		}
		if(CheckUtil.isNotEmpty(getFcmCarPurchaseAdvanceGreaterThanOrEqualTo())){
			c.andFcmCarPurchaseAdvanceGreaterThanOrEqualTo(this.getFcmCarPurchaseAdvanceGreaterThanOrEqualTo());
		}
		if(CheckUtil.isNotEmpty(getFcmCarPurchaseAdvanceGreaterThan())){
			c.andFcmCarPurchaseAdvanceGreaterThan(this.getFcmCarPurchaseAdvanceGreaterThan());
		}
		if(CheckUtil.isNotEmpty(getFcmCarPurchaseAdvanceEqualTo())){
			c.andFcmCarPurchaseAdvanceEqualTo(this.getFcmCarPurchaseAdvanceEqualTo());
		}
		if(CheckUtil.isNotEmpty(getFcmCarNatureNotLike())){
			c.andFcmCarNatureNotLike("%"+this.getFcmCarNatureNotLike()+"%");
		}
		if(CheckUtil.isNotEmpty(getFcmCarNatureNotIn())){
			c.andFcmCarNatureNotIn(this.getFcmCarNatureNotIn());
		}
		if(CheckUtil.isNotEmpty(getFcmCarNatureNotEqualTo())){
			c.andFcmCarNatureNotEqualTo(this.getFcmCarNatureNotEqualTo());
		}
		if(CheckUtil.isNotEmpty(getFcmCarNatureLike())){
			c.andFcmCarNatureLike("%"+this.getFcmCarNatureLike()+"%");
		}
		if(CheckUtil.isNotEmpty(getFcmCarNatureLessThanOrEqualTo())){
			c.andFcmCarNatureLessThanOrEqualTo(this.getFcmCarNatureLessThanOrEqualTo());
		}
		if(CheckUtil.isNotEmpty(getFcmCarNatureLessThan())){
			c.andFcmCarNatureLessThan(this.getFcmCarNatureLessThan());
		}
		if(CheckUtil.isNotEmpty(getFcmCarNatureIsNull()) && this.getFcmCarNatureIsNull()){
			c.andFcmCarNatureIsNull();
		}
		if(CheckUtil.isNotEmpty(getFcmCarNatureIsNotNull()) && this.getFcmCarNatureIsNotNull()){
			c.andFcmCarNatureIsNotNull();
		}
		if(CheckUtil.isNotEmpty(getFcmCarNatureIn())){
			c.andFcmCarNatureIn(this.getFcmCarNatureIn());
		}
		if(CheckUtil.isNotEmpty(getFcmCarNatureGreaterThanOrEqualTo())){
			c.andFcmCarNatureGreaterThanOrEqualTo(this.getFcmCarNatureGreaterThanOrEqualTo());
		}
		if(CheckUtil.isNotEmpty(getFcmCarNatureGreaterThan())){
			c.andFcmCarNatureGreaterThan(this.getFcmCarNatureGreaterThan());
		}
		if(CheckUtil.isNotEmpty(getFcmCarNatureEqualTo())){
			c.andFcmCarNatureEqualTo(this.getFcmCarNatureEqualTo());
		}
		if(CheckUtil.isNotEmpty(getFcmBoldRentNotIn())){
			c.andFcmBoldRentNotIn(this.getFcmBoldRentNotIn());
		}
		if(CheckUtil.isNotEmpty(getFcmBoldRentNotEqualTo())){
			c.andFcmBoldRentNotEqualTo(this.getFcmBoldRentNotEqualTo());
		}
		if(CheckUtil.isNotEmpty(getFcmBoldRentLessThanOrEqualTo())){
			c.andFcmBoldRentLessThanOrEqualTo(this.getFcmBoldRentLessThanOrEqualTo());
		}
		if(CheckUtil.isNotEmpty(getFcmBoldRentLessThan())){
			c.andFcmBoldRentLessThan(this.getFcmBoldRentLessThan());
		}
		if(CheckUtil.isNotEmpty(getFcmBoldRentIsNull()) && this.getFcmBoldRentIsNull()){
			c.andFcmBoldRentIsNull();
		}
		if(CheckUtil.isNotEmpty(getFcmBoldRentIsNotNull()) && this.getFcmBoldRentIsNotNull()){
			c.andFcmBoldRentIsNotNull();
		}
		if(CheckUtil.isNotEmpty(getFcmBoldRentIn())){
			c.andFcmBoldRentIn(this.getFcmBoldRentIn());
		}
		if(CheckUtil.isNotEmpty(getFcmBoldRentGreaterThanOrEqualTo())){
			c.andFcmBoldRentGreaterThanOrEqualTo(this.getFcmBoldRentGreaterThanOrEqualTo());
		}
		if(CheckUtil.isNotEmpty(getFcmBoldRentGreaterThan())){
			c.andFcmBoldRentGreaterThan(this.getFcmBoldRentGreaterThan());
		}
		if(CheckUtil.isNotEmpty(getFcmBoldRentEqualTo())){
			c.andFcmBoldRentEqualTo(this.getFcmBoldRentEqualTo());
		}
		if(CheckUtil.isNotEmpty(getFcmBillGenerateTypeNotIn())){
			c.andFcmBillGenerateTypeNotIn(this.getFcmBillGenerateTypeNotIn());
		}
		if(CheckUtil.isNotEmpty(getFcmBillGenerateTypeNotEqualTo())){
			c.andFcmBillGenerateTypeNotEqualTo(this.getFcmBillGenerateTypeNotEqualTo());
		}
		if(CheckUtil.isNotEmpty(getFcmBillGenerateTypeLessThanOrEqualTo())){
			c.andFcmBillGenerateTypeLessThanOrEqualTo(this.getFcmBillGenerateTypeLessThanOrEqualTo());
		}
		if(CheckUtil.isNotEmpty(getFcmBillGenerateTypeLessThan())){
			c.andFcmBillGenerateTypeLessThan(this.getFcmBillGenerateTypeLessThan());
		}
		if(CheckUtil.isNotEmpty(getFcmBillGenerateTypeIsNull()) && this.getFcmBillGenerateTypeIsNull()){
			c.andFcmBillGenerateTypeIsNull();
		}
		if(CheckUtil.isNotEmpty(getFcmBillGenerateTypeIsNotNull()) && this.getFcmBillGenerateTypeIsNotNull()){
			c.andFcmBillGenerateTypeIsNotNull();
		}
		if(CheckUtil.isNotEmpty(getFcmBillGenerateTypeIn())){
			c.andFcmBillGenerateTypeIn(this.getFcmBillGenerateTypeIn());
		}
		if(CheckUtil.isNotEmpty(getFcmBillGenerateTypeGreaterThanOrEqualTo())){
			c.andFcmBillGenerateTypeGreaterThanOrEqualTo(this.getFcmBillGenerateTypeGreaterThanOrEqualTo());
		}
		if(CheckUtil.isNotEmpty(getFcmBillGenerateTypeGreaterThan())){
			c.andFcmBillGenerateTypeGreaterThan(this.getFcmBillGenerateTypeGreaterThan());
		}
		if(CheckUtil.isNotEmpty(getFcmBillGenerateTypeEqualTo())){
			c.andFcmBillGenerateTypeEqualTo(this.getFcmBillGenerateTypeEqualTo());
		}
		if(CheckUtil.isNotEmpty(getFcmBillGenerateIntervalNotIn())){
			c.andFcmBillGenerateIntervalNotIn(this.getFcmBillGenerateIntervalNotIn());
		}
		if(CheckUtil.isNotEmpty(getFcmBillGenerateIntervalNotEqualTo())){
			c.andFcmBillGenerateIntervalNotEqualTo(this.getFcmBillGenerateIntervalNotEqualTo());
		}
		if(CheckUtil.isNotEmpty(getFcmBillGenerateIntervalLessThanOrEqualTo())){
			c.andFcmBillGenerateIntervalLessThanOrEqualTo(this.getFcmBillGenerateIntervalLessThanOrEqualTo());
		}
		if(CheckUtil.isNotEmpty(getFcmBillGenerateIntervalLessThan())){
			c.andFcmBillGenerateIntervalLessThan(this.getFcmBillGenerateIntervalLessThan());
		}
		if(CheckUtil.isNotEmpty(getFcmBillGenerateIntervalIsNull()) && this.getFcmBillGenerateIntervalIsNull()){
			c.andFcmBillGenerateIntervalIsNull();
		}
		if(CheckUtil.isNotEmpty(getFcmBillGenerateIntervalIsNotNull()) && this.getFcmBillGenerateIntervalIsNotNull()){
			c.andFcmBillGenerateIntervalIsNotNull();
		}
		if(CheckUtil.isNotEmpty(getFcmBillGenerateIntervalIn())){
			c.andFcmBillGenerateIntervalIn(this.getFcmBillGenerateIntervalIn());
		}
		if(CheckUtil.isNotEmpty(getFcmBillGenerateIntervalGreaterThanOrEqualTo())){
			c.andFcmBillGenerateIntervalGreaterThanOrEqualTo(this.getFcmBillGenerateIntervalGreaterThanOrEqualTo());
		}
		if(CheckUtil.isNotEmpty(getFcmBillGenerateIntervalGreaterThan())){
			c.andFcmBillGenerateIntervalGreaterThan(this.getFcmBillGenerateIntervalGreaterThan());
		}
		if(CheckUtil.isNotEmpty(getFcmBillGenerateIntervalEqualTo())){
			c.andFcmBillGenerateIntervalEqualTo(this.getFcmBillGenerateIntervalEqualTo());
		}
		if(CheckUtil.isNotEmpty(getFcmBillCatoffTypeNotIn())){
			c.andFcmBillCatoffTypeNotIn(this.getFcmBillCatoffTypeNotIn());
		}
		if(CheckUtil.isNotEmpty(getFcmBillCatoffTypeNotEqualTo())){
			c.andFcmBillCatoffTypeNotEqualTo(this.getFcmBillCatoffTypeNotEqualTo());
		}
		if(CheckUtil.isNotEmpty(getFcmBillCatoffTypeLessThanOrEqualTo())){
			c.andFcmBillCatoffTypeLessThanOrEqualTo(this.getFcmBillCatoffTypeLessThanOrEqualTo());
		}
		if(CheckUtil.isNotEmpty(getFcmBillCatoffTypeLessThan())){
			c.andFcmBillCatoffTypeLessThan(this.getFcmBillCatoffTypeLessThan());
		}
		if(CheckUtil.isNotEmpty(getFcmBillCatoffTypeIsNull()) && this.getFcmBillCatoffTypeIsNull()){
			c.andFcmBillCatoffTypeIsNull();
		}
		if(CheckUtil.isNotEmpty(getFcmBillCatoffTypeIsNotNull()) && this.getFcmBillCatoffTypeIsNotNull()){
			c.andFcmBillCatoffTypeIsNotNull();
		}
		if(CheckUtil.isNotEmpty(getFcmBillCatoffTypeIn())){
			c.andFcmBillCatoffTypeIn(this.getFcmBillCatoffTypeIn());
		}
		if(CheckUtil.isNotEmpty(getFcmBillCatoffTypeGreaterThanOrEqualTo())){
			c.andFcmBillCatoffTypeGreaterThanOrEqualTo(this.getFcmBillCatoffTypeGreaterThanOrEqualTo());
		}
		if(CheckUtil.isNotEmpty(getFcmBillCatoffTypeGreaterThan())){
			c.andFcmBillCatoffTypeGreaterThan(this.getFcmBillCatoffTypeGreaterThan());
		}
		if(CheckUtil.isNotEmpty(getFcmBillCatoffTypeEqualTo())){
			c.andFcmBillCatoffTypeEqualTo(this.getFcmBillCatoffTypeEqualTo());
		}
		if(CheckUtil.isNotEmpty(getFcmBillCatoffIntervalNotIn())){
			c.andFcmBillCatoffIntervalNotIn(this.getFcmBillCatoffIntervalNotIn());
		}
		if(CheckUtil.isNotEmpty(getFcmBillCatoffIntervalNotEqualTo())){
			c.andFcmBillCatoffIntervalNotEqualTo(this.getFcmBillCatoffIntervalNotEqualTo());
		}
		if(CheckUtil.isNotEmpty(getFcmBillCatoffIntervalLessThanOrEqualTo())){
			c.andFcmBillCatoffIntervalLessThanOrEqualTo(this.getFcmBillCatoffIntervalLessThanOrEqualTo());
		}
		if(CheckUtil.isNotEmpty(getFcmBillCatoffIntervalLessThan())){
			c.andFcmBillCatoffIntervalLessThan(this.getFcmBillCatoffIntervalLessThan());
		}
		if(CheckUtil.isNotEmpty(getFcmBillCatoffIntervalIsNull()) && this.getFcmBillCatoffIntervalIsNull()){
			c.andFcmBillCatoffIntervalIsNull();
		}
		if(CheckUtil.isNotEmpty(getFcmBillCatoffIntervalIsNotNull()) && this.getFcmBillCatoffIntervalIsNotNull()){
			c.andFcmBillCatoffIntervalIsNotNull();
		}
		if(CheckUtil.isNotEmpty(getFcmBillCatoffIntervalIn())){
			c.andFcmBillCatoffIntervalIn(this.getFcmBillCatoffIntervalIn());
		}
		if(CheckUtil.isNotEmpty(getFcmBillCatoffIntervalGreaterThanOrEqualTo())){
			c.andFcmBillCatoffIntervalGreaterThanOrEqualTo(this.getFcmBillCatoffIntervalGreaterThanOrEqualTo());
		}
		if(CheckUtil.isNotEmpty(getFcmBillCatoffIntervalGreaterThan())){
			c.andFcmBillCatoffIntervalGreaterThan(this.getFcmBillCatoffIntervalGreaterThan());
		}
		if(CheckUtil.isNotEmpty(getFcmBillCatoffIntervalEqualTo())){
			c.andFcmBillCatoffIntervalEqualTo(this.getFcmBillCatoffIntervalEqualTo());
		}
		if(CheckUtil.isNotEmpty(getFcmAssociateContractNoNotLike())){
			c.andFcmAssociateContractNoNotLike("%"+this.getFcmAssociateContractNoNotLike()+"%");
		}
		if(CheckUtil.isNotEmpty(getFcmAssociateContractNoNotIn())){
			c.andFcmAssociateContractNoNotIn(this.getFcmAssociateContractNoNotIn());
		}
		if(CheckUtil.isNotEmpty(getFcmAssociateContractNoNotEqualTo())){
			c.andFcmAssociateContractNoNotEqualTo(this.getFcmAssociateContractNoNotEqualTo());
		}
		if(CheckUtil.isNotEmpty(getFcmAssociateContractNoLike())){
			c.andFcmAssociateContractNoLike("%"+this.getFcmAssociateContractNoLike()+"%");
		}
		if(CheckUtil.isNotEmpty(getFcmAssociateContractNoLessThanOrEqualTo())){
			c.andFcmAssociateContractNoLessThanOrEqualTo(this.getFcmAssociateContractNoLessThanOrEqualTo());
		}
		if(CheckUtil.isNotEmpty(getFcmAssociateContractNoLessThan())){
			c.andFcmAssociateContractNoLessThan(this.getFcmAssociateContractNoLessThan());
		}
		if(CheckUtil.isNotEmpty(getFcmAssociateContractNoIsNull()) && this.getFcmAssociateContractNoIsNull()){
			c.andFcmAssociateContractNoIsNull();
		}
		if(CheckUtil.isNotEmpty(getFcmAssociateContractNoIsNotNull()) && this.getFcmAssociateContractNoIsNotNull()){
			c.andFcmAssociateContractNoIsNotNull();
		}
		if(CheckUtil.isNotEmpty(getFcmAssociateContractNoIn())){
			c.andFcmAssociateContractNoIn(this.getFcmAssociateContractNoIn());
		}
		if(CheckUtil.isNotEmpty(getFcmAssociateContractNoGreaterThanOrEqualTo())){
			c.andFcmAssociateContractNoGreaterThanOrEqualTo(this.getFcmAssociateContractNoGreaterThanOrEqualTo());
		}
		if(CheckUtil.isNotEmpty(getFcmAssociateContractNoGreaterThan())){
			c.andFcmAssociateContractNoGreaterThan(this.getFcmAssociateContractNoGreaterThan());
		}
		if(CheckUtil.isNotEmpty(getFcmAssociateContractNoEqualTo())){
			c.andFcmAssociateContractNoEqualTo(this.getFcmAssociateContractNoEqualTo());
		}
		if(CheckUtil.isNotEmpty(getFcmAssociateContractIdNotIn())){
			c.andFcmAssociateContractIdNotIn(this.getFcmAssociateContractIdNotIn());
		}
		if(CheckUtil.isNotEmpty(getFcmAssociateContractIdNotEqualTo())){
			c.andFcmAssociateContractIdNotEqualTo(this.getFcmAssociateContractIdNotEqualTo());
		}
		if(CheckUtil.isNotEmpty(getFcmAssociateContractIdLessThanOrEqualTo())){
			c.andFcmAssociateContractIdLessThanOrEqualTo(this.getFcmAssociateContractIdLessThanOrEqualTo());
		}
		if(CheckUtil.isNotEmpty(getFcmAssociateContractIdLessThan())){
			c.andFcmAssociateContractIdLessThan(this.getFcmAssociateContractIdLessThan());
		}
		if(CheckUtil.isNotEmpty(getFcmAssociateContractIdIsNull()) && this.getFcmAssociateContractIdIsNull()){
			c.andFcmAssociateContractIdIsNull();
		}
		if(CheckUtil.isNotEmpty(getFcmAssociateContractIdIsNotNull()) && this.getFcmAssociateContractIdIsNotNull()){
			c.andFcmAssociateContractIdIsNotNull();
		}
		if(CheckUtil.isNotEmpty(getFcmAssociateContractIdIn())){
			c.andFcmAssociateContractIdIn(this.getFcmAssociateContractIdIn());
		}
		if(CheckUtil.isNotEmpty(getFcmAssociateContractIdGreaterThanOrEqualTo())){
			c.andFcmAssociateContractIdGreaterThanOrEqualTo(this.getFcmAssociateContractIdGreaterThanOrEqualTo());
		}
		if(CheckUtil.isNotEmpty(getFcmAssociateContractIdGreaterThan())){
			c.andFcmAssociateContractIdGreaterThan(this.getFcmAssociateContractIdGreaterThan());
		}
		if(CheckUtil.isNotEmpty(getFcmAssociateContractIdEqualTo())){
			c.andFcmAssociateContractIdEqualTo(this.getFcmAssociateContractIdEqualTo());
		}
		if(CheckUtil.isNotEmpty(getDrNotIn())){
			c.andDrNotIn(this.getDrNotIn());
		}
		if(CheckUtil.isNotEmpty(getDrNotEqualTo())){
			c.andDrNotEqualTo(this.getDrNotEqualTo());
		}
		if(CheckUtil.isNotEmpty(getDrLessThanOrEqualTo())){
			c.andDrLessThanOrEqualTo(this.getDrLessThanOrEqualTo());
		}
		if(CheckUtil.isNotEmpty(getDrLessThan())){
			c.andDrLessThan(this.getDrLessThan());
		}
		if(CheckUtil.isNotEmpty(getDrIsNull()) && this.getDrIsNull()){
			c.andDrIsNull();
		}
		if(CheckUtil.isNotEmpty(getDrIsNotNull()) && this.getDrIsNotNull()){
			c.andDrIsNotNull();
		}
		if(CheckUtil.isNotEmpty(getDrIn())){
			c.andDrIn(this.getDrIn());
		}
		if(CheckUtil.isNotEmpty(getDrGreaterThanOrEqualTo())){
			c.andDrGreaterThanOrEqualTo(this.getDrGreaterThanOrEqualTo());
		}
		if(CheckUtil.isNotEmpty(getDrGreaterThan())){
			c.andDrGreaterThan(this.getDrGreaterThan());
		}
		if(CheckUtil.isNotEmpty(getDrEqualTo())){
			c.andDrEqualTo(this.getDrEqualTo());
		}
		if(CheckUtil.isNotEmpty(getCreateuserNotLike())){
			c.andCreateuserNotLike("%"+this.getCreateuserNotLike()+"%");
		}
		if(CheckUtil.isNotEmpty(getCreateuserNotIn())){
			c.andCreateuserNotIn(this.getCreateuserNotIn());
		}
		if(CheckUtil.isNotEmpty(getCreateuserNotEqualTo())){
			c.andCreateuserNotEqualTo(this.getCreateuserNotEqualTo());
		}
		if(CheckUtil.isNotEmpty(getCreateuserLike())){
			c.andCreateuserLike("%"+this.getCreateuserLike()+"%");
		}
		if(CheckUtil.isNotEmpty(getCreateuserLessThanOrEqualTo())){
			c.andCreateuserLessThanOrEqualTo(this.getCreateuserLessThanOrEqualTo());
		}
		if(CheckUtil.isNotEmpty(getCreateuserLessThan())){
			c.andCreateuserLessThan(this.getCreateuserLessThan());
		}
		if(CheckUtil.isNotEmpty(getCreateuserIsNull()) && this.getCreateuserIsNull()){
			c.andCreateuserIsNull();
		}
		if(CheckUtil.isNotEmpty(getCreateuserIsNotNull()) && this.getCreateuserIsNotNull()){
			c.andCreateuserIsNotNull();
		}
		if(CheckUtil.isNotEmpty(getCreateuserIn())){
			c.andCreateuserIn(this.getCreateuserIn());
		}
		if(CheckUtil.isNotEmpty(getCreateuserGreaterThanOrEqualTo())){
			c.andCreateuserGreaterThanOrEqualTo(this.getCreateuserGreaterThanOrEqualTo());
		}
		if(CheckUtil.isNotEmpty(getCreateuserGreaterThan())){
			c.andCreateuserGreaterThan(this.getCreateuserGreaterThan());
		}
		if(CheckUtil.isNotEmpty(getCreateuserEqualTo())){
			c.andCreateuserEqualTo(this.getCreateuserEqualTo());
		}
		if(CheckUtil.isNotEmpty(getCreatetimeNotIn())){
			c.andCreatetimeNotIn(this.getCreatetimeNotIn());
		}
		if(CheckUtil.isNotEmpty(getCreatetimeNotEqualTo())){
			c.andCreatetimeNotEqualTo(this.getCreatetimeNotEqualTo());
		}
		if(CheckUtil.isNotEmpty(getCreatetimeLessThanOrEqualTo())){
			c.andCreatetimeLessThanOrEqualTo(this.getCreatetimeLessThanOrEqualTo());
		}
		if(CheckUtil.isNotEmpty(getCreatetimeLessThan())){
			c.andCreatetimeLessThan(this.getCreatetimeLessThan());
		}
		if(CheckUtil.isNotEmpty(getCreatetimeIsNull()) && this.getCreatetimeIsNull()){
			c.andCreatetimeIsNull();
		}
		if(CheckUtil.isNotEmpty(getCreatetimeIsNotNull()) && this.getCreatetimeIsNotNull()){
			c.andCreatetimeIsNotNull();
		}
		if(CheckUtil.isNotEmpty(getCreatetimeIn())){
			c.andCreatetimeIn(this.getCreatetimeIn());
		}
		if(CheckUtil.isNotEmpty(getCreatetimeGreaterThanOrEqualTo())){
			c.andCreatetimeGreaterThanOrEqualTo(this.getCreatetimeGreaterThanOrEqualTo());
		}
		if(CheckUtil.isNotEmpty(getCreatetimeGreaterThan())){
			c.andCreatetimeGreaterThan(this.getCreatetimeGreaterThan());
		}
		if(CheckUtil.isNotEmpty(getCreatetimeEqualTo())){
			c.andCreatetimeEqualTo(this.getCreatetimeEqualTo());
		}
		if((this.getSidx()!=null && !this.getSidx().trim().equals("")) && this.getSord()!=null) {
			q.setOrderByClause(""+ this.getSidx()+" "+this.getSord());
		}
		return q;
	}
	public java.lang.String getUpdateuserNotLike() {
		return updateuserNotLike;
	}
	public void setUpdateuserNotLike(java.lang.String updateuserNotLike) {
		this.updateuserNotLike = updateuserNotLike;
	}

	public java.util.List getUpdateuserNotIn() {
		return updateuserNotIn;
	}
	public void setUpdateuserNotIn(java.util.List updateuserNotIn) {
		this.updateuserNotIn = updateuserNotIn;
	}

	public java.lang.String getUpdateuserNotEqualTo() {
		return updateuserNotEqualTo;
	}
	public void setUpdateuserNotEqualTo(java.lang.String updateuserNotEqualTo) {
		this.updateuserNotEqualTo = updateuserNotEqualTo;
	}

	public java.lang.String getUpdateuserLike() {
		return updateuserLike;
	}
	public void setUpdateuserLike(java.lang.String updateuserLike) {
		this.updateuserLike = updateuserLike;
	}

	public java.lang.String getUpdateuserLessThanOrEqualTo() {
		return updateuserLessThanOrEqualTo;
	}
	public void setUpdateuserLessThanOrEqualTo(java.lang.String updateuserLessThanOrEqualTo) {
		this.updateuserLessThanOrEqualTo = updateuserLessThanOrEqualTo;
	}

	public java.lang.String getUpdateuserLessThan() {
		return updateuserLessThan;
	}
	public void setUpdateuserLessThan(java.lang.String updateuserLessThan) {
		this.updateuserLessThan = updateuserLessThan;
	}

	public java.lang.Boolean getUpdateuserIsNull() {
		return updateuserIsNull;
	}
	public void setUpdateuserIsNull(java.lang.Boolean updateuserIsNull) {
		this.updateuserIsNull = updateuserIsNull;
	}

	public java.lang.Boolean getUpdateuserIsNotNull() {
		return updateuserIsNotNull;
	}
	public void setUpdateuserIsNotNull(java.lang.Boolean updateuserIsNotNull) {
		this.updateuserIsNotNull = updateuserIsNotNull;
	}

	public java.util.List getUpdateuserIn() {
		return updateuserIn;
	}
	public void setUpdateuserIn(java.util.List updateuserIn) {
		this.updateuserIn = updateuserIn;
	}

	public java.lang.String getUpdateuserGreaterThanOrEqualTo() {
		return updateuserGreaterThanOrEqualTo;
	}
	public void setUpdateuserGreaterThanOrEqualTo(java.lang.String updateuserGreaterThanOrEqualTo) {
		this.updateuserGreaterThanOrEqualTo = updateuserGreaterThanOrEqualTo;
	}

	public java.lang.String getUpdateuserGreaterThan() {
		return updateuserGreaterThan;
	}
	public void setUpdateuserGreaterThan(java.lang.String updateuserGreaterThan) {
		this.updateuserGreaterThan = updateuserGreaterThan;
	}

	public java.lang.String getUpdateuserEqualTo() {
		return updateuserEqualTo;
	}
	public void setUpdateuserEqualTo(java.lang.String updateuserEqualTo) {
		this.updateuserEqualTo = updateuserEqualTo;
	}

	public java.util.List getUpdatetimeNotIn() {
		return updatetimeNotIn;
	}
	public void setUpdatetimeNotIn(java.util.List updatetimeNotIn) {
		this.updatetimeNotIn = updatetimeNotIn;
	}

	public java.util.Date getUpdatetimeNotEqualTo() {
		return updatetimeNotEqualTo;
	}
	public void setUpdatetimeNotEqualTo(java.util.Date updatetimeNotEqualTo) {
		this.updatetimeNotEqualTo = updatetimeNotEqualTo;
	}

	public java.util.Date getUpdatetimeLessThanOrEqualTo() {
		return updatetimeLessThanOrEqualTo;
	}
	public void setUpdatetimeLessThanOrEqualTo(java.util.Date updatetimeLessThanOrEqualTo) {
		this.updatetimeLessThanOrEqualTo = updatetimeLessThanOrEqualTo;
	}

	public java.util.Date getUpdatetimeLessThan() {
		return updatetimeLessThan;
	}
	public void setUpdatetimeLessThan(java.util.Date updatetimeLessThan) {
		this.updatetimeLessThan = updatetimeLessThan;
	}

	public java.lang.Boolean getUpdatetimeIsNull() {
		return updatetimeIsNull;
	}
	public void setUpdatetimeIsNull(java.lang.Boolean updatetimeIsNull) {
		this.updatetimeIsNull = updatetimeIsNull;
	}

	public java.lang.Boolean getUpdatetimeIsNotNull() {
		return updatetimeIsNotNull;
	}
	public void setUpdatetimeIsNotNull(java.lang.Boolean updatetimeIsNotNull) {
		this.updatetimeIsNotNull = updatetimeIsNotNull;
	}

	public java.util.List getUpdatetimeIn() {
		return updatetimeIn;
	}
	public void setUpdatetimeIn(java.util.List updatetimeIn) {
		this.updatetimeIn = updatetimeIn;
	}

	public java.util.Date getUpdatetimeGreaterThanOrEqualTo() {
		return updatetimeGreaterThanOrEqualTo;
	}
	public void setUpdatetimeGreaterThanOrEqualTo(java.util.Date updatetimeGreaterThanOrEqualTo) {
		this.updatetimeGreaterThanOrEqualTo = updatetimeGreaterThanOrEqualTo;
	}

	public java.util.Date getUpdatetimeGreaterThan() {
		return updatetimeGreaterThan;
	}
	public void setUpdatetimeGreaterThan(java.util.Date updatetimeGreaterThan) {
		this.updatetimeGreaterThan = updatetimeGreaterThan;
	}

	public java.util.Date getUpdatetimeEqualTo() {
		return updatetimeEqualTo;
	}
	public void setUpdatetimeEqualTo(java.util.Date updatetimeEqualTo) {
		this.updatetimeEqualTo = updatetimeEqualTo;
	}

	public java.lang.String getRemarkNotLike() {
		return remarkNotLike;
	}
	public void setRemarkNotLike(java.lang.String remarkNotLike) {
		this.remarkNotLike = remarkNotLike;
	}

	public java.util.List getRemarkNotIn() {
		return remarkNotIn;
	}
	public void setRemarkNotIn(java.util.List remarkNotIn) {
		this.remarkNotIn = remarkNotIn;
	}

	public java.lang.String getRemarkNotEqualTo() {
		return remarkNotEqualTo;
	}
	public void setRemarkNotEqualTo(java.lang.String remarkNotEqualTo) {
		this.remarkNotEqualTo = remarkNotEqualTo;
	}

	public java.lang.String getRemarkLike() {
		return remarkLike;
	}
	public void setRemarkLike(java.lang.String remarkLike) {
		this.remarkLike = remarkLike;
	}

	public java.lang.String getRemarkLessThanOrEqualTo() {
		return remarkLessThanOrEqualTo;
	}
	public void setRemarkLessThanOrEqualTo(java.lang.String remarkLessThanOrEqualTo) {
		this.remarkLessThanOrEqualTo = remarkLessThanOrEqualTo;
	}

	public java.lang.String getRemarkLessThan() {
		return remarkLessThan;
	}
	public void setRemarkLessThan(java.lang.String remarkLessThan) {
		this.remarkLessThan = remarkLessThan;
	}

	public java.lang.Boolean getRemarkIsNull() {
		return remarkIsNull;
	}
	public void setRemarkIsNull(java.lang.Boolean remarkIsNull) {
		this.remarkIsNull = remarkIsNull;
	}

	public java.lang.Boolean getRemarkIsNotNull() {
		return remarkIsNotNull;
	}
	public void setRemarkIsNotNull(java.lang.Boolean remarkIsNotNull) {
		this.remarkIsNotNull = remarkIsNotNull;
	}

	public java.util.List getRemarkIn() {
		return remarkIn;
	}
	public void setRemarkIn(java.util.List remarkIn) {
		this.remarkIn = remarkIn;
	}

	public java.lang.String getRemarkGreaterThanOrEqualTo() {
		return remarkGreaterThanOrEqualTo;
	}
	public void setRemarkGreaterThanOrEqualTo(java.lang.String remarkGreaterThanOrEqualTo) {
		this.remarkGreaterThanOrEqualTo = remarkGreaterThanOrEqualTo;
	}

	public java.lang.String getRemarkGreaterThan() {
		return remarkGreaterThan;
	}
	public void setRemarkGreaterThan(java.lang.String remarkGreaterThan) {
		this.remarkGreaterThan = remarkGreaterThan;
	}

	public java.lang.String getRemarkEqualTo() {
		return remarkEqualTo;
	}
	public void setRemarkEqualTo(java.lang.String remarkEqualTo) {
		this.remarkEqualTo = remarkEqualTo;
	}

	public java.util.List getFncTurnerSingleDealNotIn() {
		return fncTurnerSingleDealNotIn;
	}
	public void setFncTurnerSingleDealNotIn(java.util.List fncTurnerSingleDealNotIn) {
		this.fncTurnerSingleDealNotIn = fncTurnerSingleDealNotIn;
	}

	public java.lang.Integer getFncTurnerSingleDealNotEqualTo() {
		return fncTurnerSingleDealNotEqualTo;
	}
	public void setFncTurnerSingleDealNotEqualTo(java.lang.Integer fncTurnerSingleDealNotEqualTo) {
		this.fncTurnerSingleDealNotEqualTo = fncTurnerSingleDealNotEqualTo;
	}

	public java.lang.Integer getFncTurnerSingleDealLessThanOrEqualTo() {
		return fncTurnerSingleDealLessThanOrEqualTo;
	}
	public void setFncTurnerSingleDealLessThanOrEqualTo(java.lang.Integer fncTurnerSingleDealLessThanOrEqualTo) {
		this.fncTurnerSingleDealLessThanOrEqualTo = fncTurnerSingleDealLessThanOrEqualTo;
	}

	public java.lang.Integer getFncTurnerSingleDealLessThan() {
		return fncTurnerSingleDealLessThan;
	}
	public void setFncTurnerSingleDealLessThan(java.lang.Integer fncTurnerSingleDealLessThan) {
		this.fncTurnerSingleDealLessThan = fncTurnerSingleDealLessThan;
	}

	public java.lang.Boolean getFncTurnerSingleDealIsNull() {
		return fncTurnerSingleDealIsNull;
	}
	public void setFncTurnerSingleDealIsNull(java.lang.Boolean fncTurnerSingleDealIsNull) {
		this.fncTurnerSingleDealIsNull = fncTurnerSingleDealIsNull;
	}

	public java.lang.Boolean getFncTurnerSingleDealIsNotNull() {
		return fncTurnerSingleDealIsNotNull;
	}
	public void setFncTurnerSingleDealIsNotNull(java.lang.Boolean fncTurnerSingleDealIsNotNull) {
		this.fncTurnerSingleDealIsNotNull = fncTurnerSingleDealIsNotNull;
	}

	public java.util.List getFncTurnerSingleDealIn() {
		return fncTurnerSingleDealIn;
	}
	public void setFncTurnerSingleDealIn(java.util.List fncTurnerSingleDealIn) {
		this.fncTurnerSingleDealIn = fncTurnerSingleDealIn;
	}

	public java.lang.Integer getFncTurnerSingleDealGreaterThanOrEqualTo() {
		return fncTurnerSingleDealGreaterThanOrEqualTo;
	}
	public void setFncTurnerSingleDealGreaterThanOrEqualTo(java.lang.Integer fncTurnerSingleDealGreaterThanOrEqualTo) {
		this.fncTurnerSingleDealGreaterThanOrEqualTo = fncTurnerSingleDealGreaterThanOrEqualTo;
	}

	public java.lang.Integer getFncTurnerSingleDealGreaterThan() {
		return fncTurnerSingleDealGreaterThan;
	}
	public void setFncTurnerSingleDealGreaterThan(java.lang.Integer fncTurnerSingleDealGreaterThan) {
		this.fncTurnerSingleDealGreaterThan = fncTurnerSingleDealGreaterThan;
	}

	public java.lang.Integer getFncTurnerSingleDealEqualTo() {
		return fncTurnerSingleDealEqualTo;
	}
	public void setFncTurnerSingleDealEqualTo(java.lang.Integer fncTurnerSingleDealEqualTo) {
		this.fncTurnerSingleDealEqualTo = fncTurnerSingleDealEqualTo;
	}

	public java.lang.String getFcmUseNotLike() {
		return fcmUseNotLike;
	}
	public void setFcmUseNotLike(java.lang.String fcmUseNotLike) {
		this.fcmUseNotLike = fcmUseNotLike;
	}

	public java.util.List getFcmUseNotIn() {
		return fcmUseNotIn;
	}
	public void setFcmUseNotIn(java.util.List fcmUseNotIn) {
		this.fcmUseNotIn = fcmUseNotIn;
	}

	public java.lang.String getFcmUseNotEqualTo() {
		return fcmUseNotEqualTo;
	}
	public void setFcmUseNotEqualTo(java.lang.String fcmUseNotEqualTo) {
		this.fcmUseNotEqualTo = fcmUseNotEqualTo;
	}

	public java.lang.String getFcmUseLike() {
		return fcmUseLike;
	}
	public void setFcmUseLike(java.lang.String fcmUseLike) {
		this.fcmUseLike = fcmUseLike;
	}

	public java.lang.String getFcmUseLessThanOrEqualTo() {
		return fcmUseLessThanOrEqualTo;
	}
	public void setFcmUseLessThanOrEqualTo(java.lang.String fcmUseLessThanOrEqualTo) {
		this.fcmUseLessThanOrEqualTo = fcmUseLessThanOrEqualTo;
	}

	public java.lang.String getFcmUseLessThan() {
		return fcmUseLessThan;
	}
	public void setFcmUseLessThan(java.lang.String fcmUseLessThan) {
		this.fcmUseLessThan = fcmUseLessThan;
	}

	public java.lang.Boolean getFcmUseIsNull() {
		return fcmUseIsNull;
	}
	public void setFcmUseIsNull(java.lang.Boolean fcmUseIsNull) {
		this.fcmUseIsNull = fcmUseIsNull;
	}

	public java.lang.Boolean getFcmUseIsNotNull() {
		return fcmUseIsNotNull;
	}
	public void setFcmUseIsNotNull(java.lang.Boolean fcmUseIsNotNull) {
		this.fcmUseIsNotNull = fcmUseIsNotNull;
	}

	public java.util.List getFcmUseIn() {
		return fcmUseIn;
	}
	public void setFcmUseIn(java.util.List fcmUseIn) {
		this.fcmUseIn = fcmUseIn;
	}

	public java.lang.String getFcmUseGreaterThanOrEqualTo() {
		return fcmUseGreaterThanOrEqualTo;
	}
	public void setFcmUseGreaterThanOrEqualTo(java.lang.String fcmUseGreaterThanOrEqualTo) {
		this.fcmUseGreaterThanOrEqualTo = fcmUseGreaterThanOrEqualTo;
	}

	public java.lang.String getFcmUseGreaterThan() {
		return fcmUseGreaterThan;
	}
	public void setFcmUseGreaterThan(java.lang.String fcmUseGreaterThan) {
		this.fcmUseGreaterThan = fcmUseGreaterThan;
	}

	public java.lang.String getFcmUseEqualTo() {
		return fcmUseEqualTo;
	}
	public void setFcmUseEqualTo(java.lang.String fcmUseEqualTo) {
		this.fcmUseEqualTo = fcmUseEqualTo;
	}

	public java.util.List getFcmSubletNotIn() {
		return fcmSubletNotIn;
	}
	public void setFcmSubletNotIn(java.util.List fcmSubletNotIn) {
		this.fcmSubletNotIn = fcmSubletNotIn;
	}

	public java.lang.Integer getFcmSubletNotEqualTo() {
		return fcmSubletNotEqualTo;
	}
	public void setFcmSubletNotEqualTo(java.lang.Integer fcmSubletNotEqualTo) {
		this.fcmSubletNotEqualTo = fcmSubletNotEqualTo;
	}

	public java.lang.Integer getFcmSubletLessThanOrEqualTo() {
		return fcmSubletLessThanOrEqualTo;
	}
	public void setFcmSubletLessThanOrEqualTo(java.lang.Integer fcmSubletLessThanOrEqualTo) {
		this.fcmSubletLessThanOrEqualTo = fcmSubletLessThanOrEqualTo;
	}

	public java.lang.Integer getFcmSubletLessThan() {
		return fcmSubletLessThan;
	}
	public void setFcmSubletLessThan(java.lang.Integer fcmSubletLessThan) {
		this.fcmSubletLessThan = fcmSubletLessThan;
	}

	public java.lang.Boolean getFcmSubletIsNull() {
		return fcmSubletIsNull;
	}
	public void setFcmSubletIsNull(java.lang.Boolean fcmSubletIsNull) {
		this.fcmSubletIsNull = fcmSubletIsNull;
	}

	public java.lang.Boolean getFcmSubletIsNotNull() {
		return fcmSubletIsNotNull;
	}
	public void setFcmSubletIsNotNull(java.lang.Boolean fcmSubletIsNotNull) {
		this.fcmSubletIsNotNull = fcmSubletIsNotNull;
	}

	public java.util.List getFcmSubletIn() {
		return fcmSubletIn;
	}
	public void setFcmSubletIn(java.util.List fcmSubletIn) {
		this.fcmSubletIn = fcmSubletIn;
	}

	public java.lang.Integer getFcmSubletGreaterThanOrEqualTo() {
		return fcmSubletGreaterThanOrEqualTo;
	}
	public void setFcmSubletGreaterThanOrEqualTo(java.lang.Integer fcmSubletGreaterThanOrEqualTo) {
		this.fcmSubletGreaterThanOrEqualTo = fcmSubletGreaterThanOrEqualTo;
	}

	public java.lang.Integer getFcmSubletGreaterThan() {
		return fcmSubletGreaterThan;
	}
	public void setFcmSubletGreaterThan(java.lang.Integer fcmSubletGreaterThan) {
		this.fcmSubletGreaterThan = fcmSubletGreaterThan;
	}

	public java.lang.Integer getFcmSubletEqualTo() {
		return fcmSubletEqualTo;
	}
	public void setFcmSubletEqualTo(java.lang.Integer fcmSubletEqualTo) {
		this.fcmSubletEqualTo = fcmSubletEqualTo;
	}

	public java.util.List getFcmSingleMarginNotIn() {
		return fcmSingleMarginNotIn;
	}
	public void setFcmSingleMarginNotIn(java.util.List fcmSingleMarginNotIn) {
		this.fcmSingleMarginNotIn = fcmSingleMarginNotIn;
	}

	public java.lang.Double getFcmSingleMarginNotEqualTo() {
		return fcmSingleMarginNotEqualTo;
	}
	public void setFcmSingleMarginNotEqualTo(java.lang.Double fcmSingleMarginNotEqualTo) {
		this.fcmSingleMarginNotEqualTo = fcmSingleMarginNotEqualTo;
	}

	public java.lang.Double getFcmSingleMarginLessThanOrEqualTo() {
		return fcmSingleMarginLessThanOrEqualTo;
	}
	public void setFcmSingleMarginLessThanOrEqualTo(java.lang.Double fcmSingleMarginLessThanOrEqualTo) {
		this.fcmSingleMarginLessThanOrEqualTo = fcmSingleMarginLessThanOrEqualTo;
	}

	public java.lang.Double getFcmSingleMarginLessThan() {
		return fcmSingleMarginLessThan;
	}
	public void setFcmSingleMarginLessThan(java.lang.Double fcmSingleMarginLessThan) {
		this.fcmSingleMarginLessThan = fcmSingleMarginLessThan;
	}

	public java.lang.Boolean getFcmSingleMarginIsNull() {
		return fcmSingleMarginIsNull;
	}
	public void setFcmSingleMarginIsNull(java.lang.Boolean fcmSingleMarginIsNull) {
		this.fcmSingleMarginIsNull = fcmSingleMarginIsNull;
	}

	public java.lang.Boolean getFcmSingleMarginIsNotNull() {
		return fcmSingleMarginIsNotNull;
	}
	public void setFcmSingleMarginIsNotNull(java.lang.Boolean fcmSingleMarginIsNotNull) {
		this.fcmSingleMarginIsNotNull = fcmSingleMarginIsNotNull;
	}

	public java.util.List getFcmSingleMarginIn() {
		return fcmSingleMarginIn;
	}
	public void setFcmSingleMarginIn(java.util.List fcmSingleMarginIn) {
		this.fcmSingleMarginIn = fcmSingleMarginIn;
	}

	public java.lang.Double getFcmSingleMarginGreaterThanOrEqualTo() {
		return fcmSingleMarginGreaterThanOrEqualTo;
	}
	public void setFcmSingleMarginGreaterThanOrEqualTo(java.lang.Double fcmSingleMarginGreaterThanOrEqualTo) {
		this.fcmSingleMarginGreaterThanOrEqualTo = fcmSingleMarginGreaterThanOrEqualTo;
	}

	public java.lang.Double getFcmSingleMarginGreaterThan() {
		return fcmSingleMarginGreaterThan;
	}
	public void setFcmSingleMarginGreaterThan(java.lang.Double fcmSingleMarginGreaterThan) {
		this.fcmSingleMarginGreaterThan = fcmSingleMarginGreaterThan;
	}

	public java.lang.Double getFcmSingleMarginEqualTo() {
		return fcmSingleMarginEqualTo;
	}
	public void setFcmSingleMarginEqualTo(java.lang.Double fcmSingleMarginEqualTo) {
		this.fcmSingleMarginEqualTo = fcmSingleMarginEqualTo;
	}

	public java.util.List getFcmSignedDateNotIn() {
		return fcmSignedDateNotIn;
	}
	public void setFcmSignedDateNotIn(java.util.List fcmSignedDateNotIn) {
		this.fcmSignedDateNotIn = fcmSignedDateNotIn;
	}

	public java.util.Date getFcmSignedDateNotEqualTo() {
		return fcmSignedDateNotEqualTo;
	}
	public void setFcmSignedDateNotEqualTo(java.util.Date fcmSignedDateNotEqualTo) {
		this.fcmSignedDateNotEqualTo = fcmSignedDateNotEqualTo;
	}

	public java.util.Date getFcmSignedDateLessThanOrEqualTo() {
		return fcmSignedDateLessThanOrEqualTo;
	}
	public void setFcmSignedDateLessThanOrEqualTo(java.util.Date fcmSignedDateLessThanOrEqualTo) {
		this.fcmSignedDateLessThanOrEqualTo = fcmSignedDateLessThanOrEqualTo;
	}

	public java.util.Date getFcmSignedDateLessThan() {
		return fcmSignedDateLessThan;
	}
	public void setFcmSignedDateLessThan(java.util.Date fcmSignedDateLessThan) {
		this.fcmSignedDateLessThan = fcmSignedDateLessThan;
	}

	public java.lang.Boolean getFcmSignedDateIsNull() {
		return fcmSignedDateIsNull;
	}
	public void setFcmSignedDateIsNull(java.lang.Boolean fcmSignedDateIsNull) {
		this.fcmSignedDateIsNull = fcmSignedDateIsNull;
	}

	public java.lang.Boolean getFcmSignedDateIsNotNull() {
		return fcmSignedDateIsNotNull;
	}
	public void setFcmSignedDateIsNotNull(java.lang.Boolean fcmSignedDateIsNotNull) {
		this.fcmSignedDateIsNotNull = fcmSignedDateIsNotNull;
	}

	public java.util.List getFcmSignedDateIn() {
		return fcmSignedDateIn;
	}
	public void setFcmSignedDateIn(java.util.List fcmSignedDateIn) {
		this.fcmSignedDateIn = fcmSignedDateIn;
	}

	public java.util.Date getFcmSignedDateGreaterThanOrEqualTo() {
		return fcmSignedDateGreaterThanOrEqualTo;
	}
	public void setFcmSignedDateGreaterThanOrEqualTo(java.util.Date fcmSignedDateGreaterThanOrEqualTo) {
		this.fcmSignedDateGreaterThanOrEqualTo = fcmSignedDateGreaterThanOrEqualTo;
	}

	public java.util.Date getFcmSignedDateGreaterThan() {
		return fcmSignedDateGreaterThan;
	}
	public void setFcmSignedDateGreaterThan(java.util.Date fcmSignedDateGreaterThan) {
		this.fcmSignedDateGreaterThan = fcmSignedDateGreaterThan;
	}

	public java.util.Date getFcmSignedDateEqualTo() {
		return fcmSignedDateEqualTo;
	}
	public void setFcmSignedDateEqualTo(java.util.Date fcmSignedDateEqualTo) {
		this.fcmSignedDateEqualTo = fcmSignedDateEqualTo;
	}

	public java.util.List getFcmSignedAddrNotIn() {
		return fcmSignedAddrNotIn;
	}
	public void setFcmSignedAddrNotIn(java.util.List fcmSignedAddrNotIn) {
		this.fcmSignedAddrNotIn = fcmSignedAddrNotIn;
	}

	public java.lang.Long getFcmSignedAddrNotEqualTo() {
		return fcmSignedAddrNotEqualTo;
	}
	public void setFcmSignedAddrNotEqualTo(java.lang.Long fcmSignedAddrNotEqualTo) {
		this.fcmSignedAddrNotEqualTo = fcmSignedAddrNotEqualTo;
	}

	public java.lang.Long getFcmSignedAddrLessThanOrEqualTo() {
		return fcmSignedAddrLessThanOrEqualTo;
	}
	public void setFcmSignedAddrLessThanOrEqualTo(java.lang.Long fcmSignedAddrLessThanOrEqualTo) {
		this.fcmSignedAddrLessThanOrEqualTo = fcmSignedAddrLessThanOrEqualTo;
	}

	public java.lang.Long getFcmSignedAddrLessThan() {
		return fcmSignedAddrLessThan;
	}
	public void setFcmSignedAddrLessThan(java.lang.Long fcmSignedAddrLessThan) {
		this.fcmSignedAddrLessThan = fcmSignedAddrLessThan;
	}

	public java.lang.Boolean getFcmSignedAddrIsNull() {
		return fcmSignedAddrIsNull;
	}
	public void setFcmSignedAddrIsNull(java.lang.Boolean fcmSignedAddrIsNull) {
		this.fcmSignedAddrIsNull = fcmSignedAddrIsNull;
	}

	public java.lang.Boolean getFcmSignedAddrIsNotNull() {
		return fcmSignedAddrIsNotNull;
	}
	public void setFcmSignedAddrIsNotNull(java.lang.Boolean fcmSignedAddrIsNotNull) {
		this.fcmSignedAddrIsNotNull = fcmSignedAddrIsNotNull;
	}

	public java.util.List getFcmSignedAddrIn() {
		return fcmSignedAddrIn;
	}
	public void setFcmSignedAddrIn(java.util.List fcmSignedAddrIn) {
		this.fcmSignedAddrIn = fcmSignedAddrIn;
	}

	public java.lang.Long getFcmSignedAddrGreaterThanOrEqualTo() {
		return fcmSignedAddrGreaterThanOrEqualTo;
	}
	public void setFcmSignedAddrGreaterThanOrEqualTo(java.lang.Long fcmSignedAddrGreaterThanOrEqualTo) {
		this.fcmSignedAddrGreaterThanOrEqualTo = fcmSignedAddrGreaterThanOrEqualTo;
	}

	public java.lang.Long getFcmSignedAddrGreaterThan() {
		return fcmSignedAddrGreaterThan;
	}
	public void setFcmSignedAddrGreaterThan(java.lang.Long fcmSignedAddrGreaterThan) {
		this.fcmSignedAddrGreaterThan = fcmSignedAddrGreaterThan;
	}

	public java.lang.Long getFcmSignedAddrEqualTo() {
		return fcmSignedAddrEqualTo;
	}
	public void setFcmSignedAddrEqualTo(java.lang.Long fcmSignedAddrEqualTo) {
		this.fcmSignedAddrEqualTo = fcmSignedAddrEqualTo;
	}

	public java.util.List getFcmSettlementStateNotIn() {
		return fcmSettlementStateNotIn;
	}
	public void setFcmSettlementStateNotIn(java.util.List fcmSettlementStateNotIn) {
		this.fcmSettlementStateNotIn = fcmSettlementStateNotIn;
	}

	public java.lang.Integer getFcmSettlementStateNotEqualTo() {
		return fcmSettlementStateNotEqualTo;
	}
	public void setFcmSettlementStateNotEqualTo(java.lang.Integer fcmSettlementStateNotEqualTo) {
		this.fcmSettlementStateNotEqualTo = fcmSettlementStateNotEqualTo;
	}

	public java.lang.Integer getFcmSettlementStateLessThanOrEqualTo() {
		return fcmSettlementStateLessThanOrEqualTo;
	}
	public void setFcmSettlementStateLessThanOrEqualTo(java.lang.Integer fcmSettlementStateLessThanOrEqualTo) {
		this.fcmSettlementStateLessThanOrEqualTo = fcmSettlementStateLessThanOrEqualTo;
	}

	public java.lang.Integer getFcmSettlementStateLessThan() {
		return fcmSettlementStateLessThan;
	}
	public void setFcmSettlementStateLessThan(java.lang.Integer fcmSettlementStateLessThan) {
		this.fcmSettlementStateLessThan = fcmSettlementStateLessThan;
	}

	public java.lang.Boolean getFcmSettlementStateIsNull() {
		return fcmSettlementStateIsNull;
	}
	public void setFcmSettlementStateIsNull(java.lang.Boolean fcmSettlementStateIsNull) {
		this.fcmSettlementStateIsNull = fcmSettlementStateIsNull;
	}

	public java.lang.Boolean getFcmSettlementStateIsNotNull() {
		return fcmSettlementStateIsNotNull;
	}
	public void setFcmSettlementStateIsNotNull(java.lang.Boolean fcmSettlementStateIsNotNull) {
		this.fcmSettlementStateIsNotNull = fcmSettlementStateIsNotNull;
	}

	public java.util.List getFcmSettlementStateIn() {
		return fcmSettlementStateIn;
	}
	public void setFcmSettlementStateIn(java.util.List fcmSettlementStateIn) {
		this.fcmSettlementStateIn = fcmSettlementStateIn;
	}

	public java.lang.Integer getFcmSettlementStateGreaterThanOrEqualTo() {
		return fcmSettlementStateGreaterThanOrEqualTo;
	}
	public void setFcmSettlementStateGreaterThanOrEqualTo(java.lang.Integer fcmSettlementStateGreaterThanOrEqualTo) {
		this.fcmSettlementStateGreaterThanOrEqualTo = fcmSettlementStateGreaterThanOrEqualTo;
	}

	public java.lang.Integer getFcmSettlementStateGreaterThan() {
		return fcmSettlementStateGreaterThan;
	}
	public void setFcmSettlementStateGreaterThan(java.lang.Integer fcmSettlementStateGreaterThan) {
		this.fcmSettlementStateGreaterThan = fcmSettlementStateGreaterThan;
	}

	public java.lang.Integer getFcmSettlementStateEqualTo() {
		return fcmSettlementStateEqualTo;
	}
	public void setFcmSettlementStateEqualTo(java.lang.Integer fcmSettlementStateEqualTo) {
		this.fcmSettlementStateEqualTo = fcmSettlementStateEqualTo;
	}

	public java.util.List getFcmReturnCityNotIn() {
		return fcmReturnCityNotIn;
	}
	public void setFcmReturnCityNotIn(java.util.List fcmReturnCityNotIn) {
		this.fcmReturnCityNotIn = fcmReturnCityNotIn;
	}

	public java.lang.Long getFcmReturnCityNotEqualTo() {
		return fcmReturnCityNotEqualTo;
	}
	public void setFcmReturnCityNotEqualTo(java.lang.Long fcmReturnCityNotEqualTo) {
		this.fcmReturnCityNotEqualTo = fcmReturnCityNotEqualTo;
	}

	public java.lang.Long getFcmReturnCityLessThanOrEqualTo() {
		return fcmReturnCityLessThanOrEqualTo;
	}
	public void setFcmReturnCityLessThanOrEqualTo(java.lang.Long fcmReturnCityLessThanOrEqualTo) {
		this.fcmReturnCityLessThanOrEqualTo = fcmReturnCityLessThanOrEqualTo;
	}

	public java.lang.Long getFcmReturnCityLessThan() {
		return fcmReturnCityLessThan;
	}
	public void setFcmReturnCityLessThan(java.lang.Long fcmReturnCityLessThan) {
		this.fcmReturnCityLessThan = fcmReturnCityLessThan;
	}

	public java.lang.Boolean getFcmReturnCityIsNull() {
		return fcmReturnCityIsNull;
	}
	public void setFcmReturnCityIsNull(java.lang.Boolean fcmReturnCityIsNull) {
		this.fcmReturnCityIsNull = fcmReturnCityIsNull;
	}

	public java.lang.Boolean getFcmReturnCityIsNotNull() {
		return fcmReturnCityIsNotNull;
	}
	public void setFcmReturnCityIsNotNull(java.lang.Boolean fcmReturnCityIsNotNull) {
		this.fcmReturnCityIsNotNull = fcmReturnCityIsNotNull;
	}

	public java.util.List getFcmReturnCityIn() {
		return fcmReturnCityIn;
	}
	public void setFcmReturnCityIn(java.util.List fcmReturnCityIn) {
		this.fcmReturnCityIn = fcmReturnCityIn;
	}

	public java.lang.Long getFcmReturnCityGreaterThanOrEqualTo() {
		return fcmReturnCityGreaterThanOrEqualTo;
	}
	public void setFcmReturnCityGreaterThanOrEqualTo(java.lang.Long fcmReturnCityGreaterThanOrEqualTo) {
		this.fcmReturnCityGreaterThanOrEqualTo = fcmReturnCityGreaterThanOrEqualTo;
	}

	public java.lang.Long getFcmReturnCityGreaterThan() {
		return fcmReturnCityGreaterThan;
	}
	public void setFcmReturnCityGreaterThan(java.lang.Long fcmReturnCityGreaterThan) {
		this.fcmReturnCityGreaterThan = fcmReturnCityGreaterThan;
	}

	public java.lang.Long getFcmReturnCityEqualTo() {
		return fcmReturnCityEqualTo;
	}
	public void setFcmReturnCityEqualTo(java.lang.Long fcmReturnCityEqualTo) {
		this.fcmReturnCityEqualTo = fcmReturnCityEqualTo;
	}

	public java.util.List getFcmRentPayTypeNotIn() {
		return fcmRentPayTypeNotIn;
	}
	public void setFcmRentPayTypeNotIn(java.util.List fcmRentPayTypeNotIn) {
		this.fcmRentPayTypeNotIn = fcmRentPayTypeNotIn;
	}

	public java.lang.Integer getFcmRentPayTypeNotEqualTo() {
		return fcmRentPayTypeNotEqualTo;
	}
	public void setFcmRentPayTypeNotEqualTo(java.lang.Integer fcmRentPayTypeNotEqualTo) {
		this.fcmRentPayTypeNotEqualTo = fcmRentPayTypeNotEqualTo;
	}

	public java.lang.Integer getFcmRentPayTypeLessThanOrEqualTo() {
		return fcmRentPayTypeLessThanOrEqualTo;
	}
	public void setFcmRentPayTypeLessThanOrEqualTo(java.lang.Integer fcmRentPayTypeLessThanOrEqualTo) {
		this.fcmRentPayTypeLessThanOrEqualTo = fcmRentPayTypeLessThanOrEqualTo;
	}

	public java.lang.Integer getFcmRentPayTypeLessThan() {
		return fcmRentPayTypeLessThan;
	}
	public void setFcmRentPayTypeLessThan(java.lang.Integer fcmRentPayTypeLessThan) {
		this.fcmRentPayTypeLessThan = fcmRentPayTypeLessThan;
	}

	public java.lang.Boolean getFcmRentPayTypeIsNull() {
		return fcmRentPayTypeIsNull;
	}
	public void setFcmRentPayTypeIsNull(java.lang.Boolean fcmRentPayTypeIsNull) {
		this.fcmRentPayTypeIsNull = fcmRentPayTypeIsNull;
	}

	public java.lang.Boolean getFcmRentPayTypeIsNotNull() {
		return fcmRentPayTypeIsNotNull;
	}
	public void setFcmRentPayTypeIsNotNull(java.lang.Boolean fcmRentPayTypeIsNotNull) {
		this.fcmRentPayTypeIsNotNull = fcmRentPayTypeIsNotNull;
	}

	public java.util.List getFcmRentPayTypeIn() {
		return fcmRentPayTypeIn;
	}
	public void setFcmRentPayTypeIn(java.util.List fcmRentPayTypeIn) {
		this.fcmRentPayTypeIn = fcmRentPayTypeIn;
	}

	public java.lang.Integer getFcmRentPayTypeGreaterThanOrEqualTo() {
		return fcmRentPayTypeGreaterThanOrEqualTo;
	}
	public void setFcmRentPayTypeGreaterThanOrEqualTo(java.lang.Integer fcmRentPayTypeGreaterThanOrEqualTo) {
		this.fcmRentPayTypeGreaterThanOrEqualTo = fcmRentPayTypeGreaterThanOrEqualTo;
	}

	public java.lang.Integer getFcmRentPayTypeGreaterThan() {
		return fcmRentPayTypeGreaterThan;
	}
	public void setFcmRentPayTypeGreaterThan(java.lang.Integer fcmRentPayTypeGreaterThan) {
		this.fcmRentPayTypeGreaterThan = fcmRentPayTypeGreaterThan;
	}

	public java.lang.Integer getFcmRentPayTypeEqualTo() {
		return fcmRentPayTypeEqualTo;
	}
	public void setFcmRentPayTypeEqualTo(java.lang.Integer fcmRentPayTypeEqualTo) {
		this.fcmRentPayTypeEqualTo = fcmRentPayTypeEqualTo;
	}

	public java.util.List getFcmRentPayCycleNotIn() {
		return fcmRentPayCycleNotIn;
	}
	public void setFcmRentPayCycleNotIn(java.util.List fcmRentPayCycleNotIn) {
		this.fcmRentPayCycleNotIn = fcmRentPayCycleNotIn;
	}

	public java.lang.Integer getFcmRentPayCycleNotEqualTo() {
		return fcmRentPayCycleNotEqualTo;
	}
	public void setFcmRentPayCycleNotEqualTo(java.lang.Integer fcmRentPayCycleNotEqualTo) {
		this.fcmRentPayCycleNotEqualTo = fcmRentPayCycleNotEqualTo;
	}

	public java.lang.Integer getFcmRentPayCycleLessThanOrEqualTo() {
		return fcmRentPayCycleLessThanOrEqualTo;
	}
	public void setFcmRentPayCycleLessThanOrEqualTo(java.lang.Integer fcmRentPayCycleLessThanOrEqualTo) {
		this.fcmRentPayCycleLessThanOrEqualTo = fcmRentPayCycleLessThanOrEqualTo;
	}

	public java.lang.Integer getFcmRentPayCycleLessThan() {
		return fcmRentPayCycleLessThan;
	}
	public void setFcmRentPayCycleLessThan(java.lang.Integer fcmRentPayCycleLessThan) {
		this.fcmRentPayCycleLessThan = fcmRentPayCycleLessThan;
	}

	public java.lang.Boolean getFcmRentPayCycleIsNull() {
		return fcmRentPayCycleIsNull;
	}
	public void setFcmRentPayCycleIsNull(java.lang.Boolean fcmRentPayCycleIsNull) {
		this.fcmRentPayCycleIsNull = fcmRentPayCycleIsNull;
	}

	public java.lang.Boolean getFcmRentPayCycleIsNotNull() {
		return fcmRentPayCycleIsNotNull;
	}
	public void setFcmRentPayCycleIsNotNull(java.lang.Boolean fcmRentPayCycleIsNotNull) {
		this.fcmRentPayCycleIsNotNull = fcmRentPayCycleIsNotNull;
	}

	public java.util.List getFcmRentPayCycleIn() {
		return fcmRentPayCycleIn;
	}
	public void setFcmRentPayCycleIn(java.util.List fcmRentPayCycleIn) {
		this.fcmRentPayCycleIn = fcmRentPayCycleIn;
	}

	public java.lang.Integer getFcmRentPayCycleGreaterThanOrEqualTo() {
		return fcmRentPayCycleGreaterThanOrEqualTo;
	}
	public void setFcmRentPayCycleGreaterThanOrEqualTo(java.lang.Integer fcmRentPayCycleGreaterThanOrEqualTo) {
		this.fcmRentPayCycleGreaterThanOrEqualTo = fcmRentPayCycleGreaterThanOrEqualTo;
	}

	public java.lang.Integer getFcmRentPayCycleGreaterThan() {
		return fcmRentPayCycleGreaterThan;
	}
	public void setFcmRentPayCycleGreaterThan(java.lang.Integer fcmRentPayCycleGreaterThan) {
		this.fcmRentPayCycleGreaterThan = fcmRentPayCycleGreaterThan;
	}

	public java.lang.Integer getFcmRentPayCycleEqualTo() {
		return fcmRentPayCycleEqualTo;
	}
	public void setFcmRentPayCycleEqualTo(java.lang.Integer fcmRentPayCycleEqualTo) {
		this.fcmRentPayCycleEqualTo = fcmRentPayCycleEqualTo;
	}

	public java.util.List getFcmPartybTypeNotIn() {
		return fcmPartybTypeNotIn;
	}
	public void setFcmPartybTypeNotIn(java.util.List fcmPartybTypeNotIn) {
		this.fcmPartybTypeNotIn = fcmPartybTypeNotIn;
	}

	public java.lang.Integer getFcmPartybTypeNotEqualTo() {
		return fcmPartybTypeNotEqualTo;
	}
	public void setFcmPartybTypeNotEqualTo(java.lang.Integer fcmPartybTypeNotEqualTo) {
		this.fcmPartybTypeNotEqualTo = fcmPartybTypeNotEqualTo;
	}

	public java.lang.Integer getFcmPartybTypeLessThanOrEqualTo() {
		return fcmPartybTypeLessThanOrEqualTo;
	}
	public void setFcmPartybTypeLessThanOrEqualTo(java.lang.Integer fcmPartybTypeLessThanOrEqualTo) {
		this.fcmPartybTypeLessThanOrEqualTo = fcmPartybTypeLessThanOrEqualTo;
	}

	public java.lang.Integer getFcmPartybTypeLessThan() {
		return fcmPartybTypeLessThan;
	}
	public void setFcmPartybTypeLessThan(java.lang.Integer fcmPartybTypeLessThan) {
		this.fcmPartybTypeLessThan = fcmPartybTypeLessThan;
	}

	public java.lang.Boolean getFcmPartybTypeIsNull() {
		return fcmPartybTypeIsNull;
	}
	public void setFcmPartybTypeIsNull(java.lang.Boolean fcmPartybTypeIsNull) {
		this.fcmPartybTypeIsNull = fcmPartybTypeIsNull;
	}

	public java.lang.Boolean getFcmPartybTypeIsNotNull() {
		return fcmPartybTypeIsNotNull;
	}
	public void setFcmPartybTypeIsNotNull(java.lang.Boolean fcmPartybTypeIsNotNull) {
		this.fcmPartybTypeIsNotNull = fcmPartybTypeIsNotNull;
	}

	public java.util.List getFcmPartybTypeIn() {
		return fcmPartybTypeIn;
	}
	public void setFcmPartybTypeIn(java.util.List fcmPartybTypeIn) {
		this.fcmPartybTypeIn = fcmPartybTypeIn;
	}

	public java.lang.Integer getFcmPartybTypeGreaterThanOrEqualTo() {
		return fcmPartybTypeGreaterThanOrEqualTo;
	}
	public void setFcmPartybTypeGreaterThanOrEqualTo(java.lang.Integer fcmPartybTypeGreaterThanOrEqualTo) {
		this.fcmPartybTypeGreaterThanOrEqualTo = fcmPartybTypeGreaterThanOrEqualTo;
	}

	public java.lang.Integer getFcmPartybTypeGreaterThan() {
		return fcmPartybTypeGreaterThan;
	}
	public void setFcmPartybTypeGreaterThan(java.lang.Integer fcmPartybTypeGreaterThan) {
		this.fcmPartybTypeGreaterThan = fcmPartybTypeGreaterThan;
	}

	public java.lang.Integer getFcmPartybTypeEqualTo() {
		return fcmPartybTypeEqualTo;
	}
	public void setFcmPartybTypeEqualTo(java.lang.Integer fcmPartybTypeEqualTo) {
		this.fcmPartybTypeEqualTo = fcmPartybTypeEqualTo;
	}

	public java.util.List getFcmPartybIdNotIn() {
		return fcmPartybIdNotIn;
	}
	public void setFcmPartybIdNotIn(java.util.List fcmPartybIdNotIn) {
		this.fcmPartybIdNotIn = fcmPartybIdNotIn;
	}

	public java.lang.Long getFcmPartybIdNotEqualTo() {
		return fcmPartybIdNotEqualTo;
	}
	public void setFcmPartybIdNotEqualTo(java.lang.Long fcmPartybIdNotEqualTo) {
		this.fcmPartybIdNotEqualTo = fcmPartybIdNotEqualTo;
	}

	public java.lang.Long getFcmPartybIdLessThanOrEqualTo() {
		return fcmPartybIdLessThanOrEqualTo;
	}
	public void setFcmPartybIdLessThanOrEqualTo(java.lang.Long fcmPartybIdLessThanOrEqualTo) {
		this.fcmPartybIdLessThanOrEqualTo = fcmPartybIdLessThanOrEqualTo;
	}

	public java.lang.Long getFcmPartybIdLessThan() {
		return fcmPartybIdLessThan;
	}
	public void setFcmPartybIdLessThan(java.lang.Long fcmPartybIdLessThan) {
		this.fcmPartybIdLessThan = fcmPartybIdLessThan;
	}

	public java.lang.Boolean getFcmPartybIdIsNull() {
		return fcmPartybIdIsNull;
	}
	public void setFcmPartybIdIsNull(java.lang.Boolean fcmPartybIdIsNull) {
		this.fcmPartybIdIsNull = fcmPartybIdIsNull;
	}

	public java.lang.Boolean getFcmPartybIdIsNotNull() {
		return fcmPartybIdIsNotNull;
	}
	public void setFcmPartybIdIsNotNull(java.lang.Boolean fcmPartybIdIsNotNull) {
		this.fcmPartybIdIsNotNull = fcmPartybIdIsNotNull;
	}

	public java.util.List getFcmPartybIdIn() {
		return fcmPartybIdIn;
	}
	public void setFcmPartybIdIn(java.util.List fcmPartybIdIn) {
		this.fcmPartybIdIn = fcmPartybIdIn;
	}

	public java.lang.Long getFcmPartybIdGreaterThanOrEqualTo() {
		return fcmPartybIdGreaterThanOrEqualTo;
	}
	public void setFcmPartybIdGreaterThanOrEqualTo(java.lang.Long fcmPartybIdGreaterThanOrEqualTo) {
		this.fcmPartybIdGreaterThanOrEqualTo = fcmPartybIdGreaterThanOrEqualTo;
	}

	public java.lang.Long getFcmPartybIdGreaterThan() {
		return fcmPartybIdGreaterThan;
	}
	public void setFcmPartybIdGreaterThan(java.lang.Long fcmPartybIdGreaterThan) {
		this.fcmPartybIdGreaterThan = fcmPartybIdGreaterThan;
	}

	public java.lang.Long getFcmPartybIdEqualTo() {
		return fcmPartybIdEqualTo;
	}
	public void setFcmPartybIdEqualTo(java.lang.Long fcmPartybIdEqualTo) {
		this.fcmPartybIdEqualTo = fcmPartybIdEqualTo;
	}

	public java.util.List getFcmPartyaTypeNotIn() {
		return fcmPartyaTypeNotIn;
	}
	public void setFcmPartyaTypeNotIn(java.util.List fcmPartyaTypeNotIn) {
		this.fcmPartyaTypeNotIn = fcmPartyaTypeNotIn;
	}

	public java.lang.Integer getFcmPartyaTypeNotEqualTo() {
		return fcmPartyaTypeNotEqualTo;
	}
	public void setFcmPartyaTypeNotEqualTo(java.lang.Integer fcmPartyaTypeNotEqualTo) {
		this.fcmPartyaTypeNotEqualTo = fcmPartyaTypeNotEqualTo;
	}

	public java.lang.Integer getFcmPartyaTypeLessThanOrEqualTo() {
		return fcmPartyaTypeLessThanOrEqualTo;
	}
	public void setFcmPartyaTypeLessThanOrEqualTo(java.lang.Integer fcmPartyaTypeLessThanOrEqualTo) {
		this.fcmPartyaTypeLessThanOrEqualTo = fcmPartyaTypeLessThanOrEqualTo;
	}

	public java.lang.Integer getFcmPartyaTypeLessThan() {
		return fcmPartyaTypeLessThan;
	}
	public void setFcmPartyaTypeLessThan(java.lang.Integer fcmPartyaTypeLessThan) {
		this.fcmPartyaTypeLessThan = fcmPartyaTypeLessThan;
	}

	public java.lang.Boolean getFcmPartyaTypeIsNull() {
		return fcmPartyaTypeIsNull;
	}
	public void setFcmPartyaTypeIsNull(java.lang.Boolean fcmPartyaTypeIsNull) {
		this.fcmPartyaTypeIsNull = fcmPartyaTypeIsNull;
	}

	public java.lang.Boolean getFcmPartyaTypeIsNotNull() {
		return fcmPartyaTypeIsNotNull;
	}
	public void setFcmPartyaTypeIsNotNull(java.lang.Boolean fcmPartyaTypeIsNotNull) {
		this.fcmPartyaTypeIsNotNull = fcmPartyaTypeIsNotNull;
	}

	public java.util.List getFcmPartyaTypeIn() {
		return fcmPartyaTypeIn;
	}
	public void setFcmPartyaTypeIn(java.util.List fcmPartyaTypeIn) {
		this.fcmPartyaTypeIn = fcmPartyaTypeIn;
	}

	public java.lang.Integer getFcmPartyaTypeGreaterThanOrEqualTo() {
		return fcmPartyaTypeGreaterThanOrEqualTo;
	}
	public void setFcmPartyaTypeGreaterThanOrEqualTo(java.lang.Integer fcmPartyaTypeGreaterThanOrEqualTo) {
		this.fcmPartyaTypeGreaterThanOrEqualTo = fcmPartyaTypeGreaterThanOrEqualTo;
	}

	public java.lang.Integer getFcmPartyaTypeGreaterThan() {
		return fcmPartyaTypeGreaterThan;
	}
	public void setFcmPartyaTypeGreaterThan(java.lang.Integer fcmPartyaTypeGreaterThan) {
		this.fcmPartyaTypeGreaterThan = fcmPartyaTypeGreaterThan;
	}

	public java.lang.Integer getFcmPartyaTypeEqualTo() {
		return fcmPartyaTypeEqualTo;
	}
	public void setFcmPartyaTypeEqualTo(java.lang.Integer fcmPartyaTypeEqualTo) {
		this.fcmPartyaTypeEqualTo = fcmPartyaTypeEqualTo;
	}

	public java.util.List getFcmPartyaIdNotIn() {
		return fcmPartyaIdNotIn;
	}
	public void setFcmPartyaIdNotIn(java.util.List fcmPartyaIdNotIn) {
		this.fcmPartyaIdNotIn = fcmPartyaIdNotIn;
	}

	public java.lang.Long getFcmPartyaIdNotEqualTo() {
		return fcmPartyaIdNotEqualTo;
	}
	public void setFcmPartyaIdNotEqualTo(java.lang.Long fcmPartyaIdNotEqualTo) {
		this.fcmPartyaIdNotEqualTo = fcmPartyaIdNotEqualTo;
	}

	public java.lang.Long getFcmPartyaIdLessThanOrEqualTo() {
		return fcmPartyaIdLessThanOrEqualTo;
	}
	public void setFcmPartyaIdLessThanOrEqualTo(java.lang.Long fcmPartyaIdLessThanOrEqualTo) {
		this.fcmPartyaIdLessThanOrEqualTo = fcmPartyaIdLessThanOrEqualTo;
	}

	public java.lang.Long getFcmPartyaIdLessThan() {
		return fcmPartyaIdLessThan;
	}
	public void setFcmPartyaIdLessThan(java.lang.Long fcmPartyaIdLessThan) {
		this.fcmPartyaIdLessThan = fcmPartyaIdLessThan;
	}

	public java.lang.Boolean getFcmPartyaIdIsNull() {
		return fcmPartyaIdIsNull;
	}
	public void setFcmPartyaIdIsNull(java.lang.Boolean fcmPartyaIdIsNull) {
		this.fcmPartyaIdIsNull = fcmPartyaIdIsNull;
	}

	public java.lang.Boolean getFcmPartyaIdIsNotNull() {
		return fcmPartyaIdIsNotNull;
	}
	public void setFcmPartyaIdIsNotNull(java.lang.Boolean fcmPartyaIdIsNotNull) {
		this.fcmPartyaIdIsNotNull = fcmPartyaIdIsNotNull;
	}

	public java.util.List getFcmPartyaIdIn() {
		return fcmPartyaIdIn;
	}
	public void setFcmPartyaIdIn(java.util.List fcmPartyaIdIn) {
		this.fcmPartyaIdIn = fcmPartyaIdIn;
	}

	public java.lang.Long getFcmPartyaIdGreaterThanOrEqualTo() {
		return fcmPartyaIdGreaterThanOrEqualTo;
	}
	public void setFcmPartyaIdGreaterThanOrEqualTo(java.lang.Long fcmPartyaIdGreaterThanOrEqualTo) {
		this.fcmPartyaIdGreaterThanOrEqualTo = fcmPartyaIdGreaterThanOrEqualTo;
	}

	public java.lang.Long getFcmPartyaIdGreaterThan() {
		return fcmPartyaIdGreaterThan;
	}
	public void setFcmPartyaIdGreaterThan(java.lang.Long fcmPartyaIdGreaterThan) {
		this.fcmPartyaIdGreaterThan = fcmPartyaIdGreaterThan;
	}

	public java.lang.Long getFcmPartyaIdEqualTo() {
		return fcmPartyaIdEqualTo;
	}
	public void setFcmPartyaIdEqualTo(java.lang.Long fcmPartyaIdEqualTo) {
		this.fcmPartyaIdEqualTo = fcmPartyaIdEqualTo;
	}

	public java.util.List getFcmOperatPlatformNotIn() {
		return fcmOperatPlatformNotIn;
	}
	public void setFcmOperatPlatformNotIn(java.util.List fcmOperatPlatformNotIn) {
		this.fcmOperatPlatformNotIn = fcmOperatPlatformNotIn;
	}

	public java.lang.Integer getFcmOperatPlatformNotEqualTo() {
		return fcmOperatPlatformNotEqualTo;
	}
	public void setFcmOperatPlatformNotEqualTo(java.lang.Integer fcmOperatPlatformNotEqualTo) {
		this.fcmOperatPlatformNotEqualTo = fcmOperatPlatformNotEqualTo;
	}

	public java.lang.Integer getFcmOperatPlatformLessThanOrEqualTo() {
		return fcmOperatPlatformLessThanOrEqualTo;
	}
	public void setFcmOperatPlatformLessThanOrEqualTo(java.lang.Integer fcmOperatPlatformLessThanOrEqualTo) {
		this.fcmOperatPlatformLessThanOrEqualTo = fcmOperatPlatformLessThanOrEqualTo;
	}

	public java.lang.Integer getFcmOperatPlatformLessThan() {
		return fcmOperatPlatformLessThan;
	}
	public void setFcmOperatPlatformLessThan(java.lang.Integer fcmOperatPlatformLessThan) {
		this.fcmOperatPlatformLessThan = fcmOperatPlatformLessThan;
	}

	public java.lang.Boolean getFcmOperatPlatformIsNull() {
		return fcmOperatPlatformIsNull;
	}
	public void setFcmOperatPlatformIsNull(java.lang.Boolean fcmOperatPlatformIsNull) {
		this.fcmOperatPlatformIsNull = fcmOperatPlatformIsNull;
	}

	public java.lang.Boolean getFcmOperatPlatformIsNotNull() {
		return fcmOperatPlatformIsNotNull;
	}
	public void setFcmOperatPlatformIsNotNull(java.lang.Boolean fcmOperatPlatformIsNotNull) {
		this.fcmOperatPlatformIsNotNull = fcmOperatPlatformIsNotNull;
	}

	public java.util.List getFcmOperatPlatformIn() {
		return fcmOperatPlatformIn;
	}
	public void setFcmOperatPlatformIn(java.util.List fcmOperatPlatformIn) {
		this.fcmOperatPlatformIn = fcmOperatPlatformIn;
	}

	public java.lang.Integer getFcmOperatPlatformGreaterThanOrEqualTo() {
		return fcmOperatPlatformGreaterThanOrEqualTo;
	}
	public void setFcmOperatPlatformGreaterThanOrEqualTo(java.lang.Integer fcmOperatPlatformGreaterThanOrEqualTo) {
		this.fcmOperatPlatformGreaterThanOrEqualTo = fcmOperatPlatformGreaterThanOrEqualTo;
	}

	public java.lang.Integer getFcmOperatPlatformGreaterThan() {
		return fcmOperatPlatformGreaterThan;
	}
	public void setFcmOperatPlatformGreaterThan(java.lang.Integer fcmOperatPlatformGreaterThan) {
		this.fcmOperatPlatformGreaterThan = fcmOperatPlatformGreaterThan;
	}

	public java.lang.Integer getFcmOperatPlatformEqualTo() {
		return fcmOperatPlatformEqualTo;
	}
	public void setFcmOperatPlatformEqualTo(java.lang.Integer fcmOperatPlatformEqualTo) {
		this.fcmOperatPlatformEqualTo = fcmOperatPlatformEqualTo;
	}

	public java.util.List getFcmMarginTypeNotIn() {
		return fcmMarginTypeNotIn;
	}
	public void setFcmMarginTypeNotIn(java.util.List fcmMarginTypeNotIn) {
		this.fcmMarginTypeNotIn = fcmMarginTypeNotIn;
	}

	public java.lang.Integer getFcmMarginTypeNotEqualTo() {
		return fcmMarginTypeNotEqualTo;
	}
	public void setFcmMarginTypeNotEqualTo(java.lang.Integer fcmMarginTypeNotEqualTo) {
		this.fcmMarginTypeNotEqualTo = fcmMarginTypeNotEqualTo;
	}

	public java.lang.Integer getFcmMarginTypeLessThanOrEqualTo() {
		return fcmMarginTypeLessThanOrEqualTo;
	}
	public void setFcmMarginTypeLessThanOrEqualTo(java.lang.Integer fcmMarginTypeLessThanOrEqualTo) {
		this.fcmMarginTypeLessThanOrEqualTo = fcmMarginTypeLessThanOrEqualTo;
	}

	public java.lang.Integer getFcmMarginTypeLessThan() {
		return fcmMarginTypeLessThan;
	}
	public void setFcmMarginTypeLessThan(java.lang.Integer fcmMarginTypeLessThan) {
		this.fcmMarginTypeLessThan = fcmMarginTypeLessThan;
	}

	public java.lang.Boolean getFcmMarginTypeIsNull() {
		return fcmMarginTypeIsNull;
	}
	public void setFcmMarginTypeIsNull(java.lang.Boolean fcmMarginTypeIsNull) {
		this.fcmMarginTypeIsNull = fcmMarginTypeIsNull;
	}

	public java.lang.Boolean getFcmMarginTypeIsNotNull() {
		return fcmMarginTypeIsNotNull;
	}
	public void setFcmMarginTypeIsNotNull(java.lang.Boolean fcmMarginTypeIsNotNull) {
		this.fcmMarginTypeIsNotNull = fcmMarginTypeIsNotNull;
	}

	public java.util.List getFcmMarginTypeIn() {
		return fcmMarginTypeIn;
	}
	public void setFcmMarginTypeIn(java.util.List fcmMarginTypeIn) {
		this.fcmMarginTypeIn = fcmMarginTypeIn;
	}

	public java.lang.Integer getFcmMarginTypeGreaterThanOrEqualTo() {
		return fcmMarginTypeGreaterThanOrEqualTo;
	}
	public void setFcmMarginTypeGreaterThanOrEqualTo(java.lang.Integer fcmMarginTypeGreaterThanOrEqualTo) {
		this.fcmMarginTypeGreaterThanOrEqualTo = fcmMarginTypeGreaterThanOrEqualTo;
	}

	public java.lang.Integer getFcmMarginTypeGreaterThan() {
		return fcmMarginTypeGreaterThan;
	}
	public void setFcmMarginTypeGreaterThan(java.lang.Integer fcmMarginTypeGreaterThan) {
		this.fcmMarginTypeGreaterThan = fcmMarginTypeGreaterThan;
	}

	public java.lang.Integer getFcmMarginTypeEqualTo() {
		return fcmMarginTypeEqualTo;
	}
	public void setFcmMarginTypeEqualTo(java.lang.Integer fcmMarginTypeEqualTo) {
		this.fcmMarginTypeEqualTo = fcmMarginTypeEqualTo;
	}

	public java.util.List getFcmMarginTotalNotIn() {
		return fcmMarginTotalNotIn;
	}
	public void setFcmMarginTotalNotIn(java.util.List fcmMarginTotalNotIn) {
		this.fcmMarginTotalNotIn = fcmMarginTotalNotIn;
	}

	public java.lang.Double getFcmMarginTotalNotEqualTo() {
		return fcmMarginTotalNotEqualTo;
	}
	public void setFcmMarginTotalNotEqualTo(java.lang.Double fcmMarginTotalNotEqualTo) {
		this.fcmMarginTotalNotEqualTo = fcmMarginTotalNotEqualTo;
	}

	public java.lang.Double getFcmMarginTotalLessThanOrEqualTo() {
		return fcmMarginTotalLessThanOrEqualTo;
	}
	public void setFcmMarginTotalLessThanOrEqualTo(java.lang.Double fcmMarginTotalLessThanOrEqualTo) {
		this.fcmMarginTotalLessThanOrEqualTo = fcmMarginTotalLessThanOrEqualTo;
	}

	public java.lang.Double getFcmMarginTotalLessThan() {
		return fcmMarginTotalLessThan;
	}
	public void setFcmMarginTotalLessThan(java.lang.Double fcmMarginTotalLessThan) {
		this.fcmMarginTotalLessThan = fcmMarginTotalLessThan;
	}

	public java.lang.Boolean getFcmMarginTotalIsNull() {
		return fcmMarginTotalIsNull;
	}
	public void setFcmMarginTotalIsNull(java.lang.Boolean fcmMarginTotalIsNull) {
		this.fcmMarginTotalIsNull = fcmMarginTotalIsNull;
	}

	public java.lang.Boolean getFcmMarginTotalIsNotNull() {
		return fcmMarginTotalIsNotNull;
	}
	public void setFcmMarginTotalIsNotNull(java.lang.Boolean fcmMarginTotalIsNotNull) {
		this.fcmMarginTotalIsNotNull = fcmMarginTotalIsNotNull;
	}

	public java.util.List getFcmMarginTotalIn() {
		return fcmMarginTotalIn;
	}
	public void setFcmMarginTotalIn(java.util.List fcmMarginTotalIn) {
		this.fcmMarginTotalIn = fcmMarginTotalIn;
	}

	public java.lang.Double getFcmMarginTotalGreaterThanOrEqualTo() {
		return fcmMarginTotalGreaterThanOrEqualTo;
	}
	public void setFcmMarginTotalGreaterThanOrEqualTo(java.lang.Double fcmMarginTotalGreaterThanOrEqualTo) {
		this.fcmMarginTotalGreaterThanOrEqualTo = fcmMarginTotalGreaterThanOrEqualTo;
	}

	public java.lang.Double getFcmMarginTotalGreaterThan() {
		return fcmMarginTotalGreaterThan;
	}
	public void setFcmMarginTotalGreaterThan(java.lang.Double fcmMarginTotalGreaterThan) {
		this.fcmMarginTotalGreaterThan = fcmMarginTotalGreaterThan;
	}

	public java.lang.Double getFcmMarginTotalEqualTo() {
		return fcmMarginTotalEqualTo;
	}
	public void setFcmMarginTotalEqualTo(java.lang.Double fcmMarginTotalEqualTo) {
		this.fcmMarginTotalEqualTo = fcmMarginTotalEqualTo;
	}

	public java.util.List getFcmMarginPayRequireNotIn() {
		return fcmMarginPayRequireNotIn;
	}
	public void setFcmMarginPayRequireNotIn(java.util.List fcmMarginPayRequireNotIn) {
		this.fcmMarginPayRequireNotIn = fcmMarginPayRequireNotIn;
	}

	public java.lang.Integer getFcmMarginPayRequireNotEqualTo() {
		return fcmMarginPayRequireNotEqualTo;
	}
	public void setFcmMarginPayRequireNotEqualTo(java.lang.Integer fcmMarginPayRequireNotEqualTo) {
		this.fcmMarginPayRequireNotEqualTo = fcmMarginPayRequireNotEqualTo;
	}

	public java.lang.Integer getFcmMarginPayRequireLessThanOrEqualTo() {
		return fcmMarginPayRequireLessThanOrEqualTo;
	}
	public void setFcmMarginPayRequireLessThanOrEqualTo(java.lang.Integer fcmMarginPayRequireLessThanOrEqualTo) {
		this.fcmMarginPayRequireLessThanOrEqualTo = fcmMarginPayRequireLessThanOrEqualTo;
	}

	public java.lang.Integer getFcmMarginPayRequireLessThan() {
		return fcmMarginPayRequireLessThan;
	}
	public void setFcmMarginPayRequireLessThan(java.lang.Integer fcmMarginPayRequireLessThan) {
		this.fcmMarginPayRequireLessThan = fcmMarginPayRequireLessThan;
	}

	public java.lang.Boolean getFcmMarginPayRequireIsNull() {
		return fcmMarginPayRequireIsNull;
	}
	public void setFcmMarginPayRequireIsNull(java.lang.Boolean fcmMarginPayRequireIsNull) {
		this.fcmMarginPayRequireIsNull = fcmMarginPayRequireIsNull;
	}

	public java.lang.Boolean getFcmMarginPayRequireIsNotNull() {
		return fcmMarginPayRequireIsNotNull;
	}
	public void setFcmMarginPayRequireIsNotNull(java.lang.Boolean fcmMarginPayRequireIsNotNull) {
		this.fcmMarginPayRequireIsNotNull = fcmMarginPayRequireIsNotNull;
	}

	public java.util.List getFcmMarginPayRequireIn() {
		return fcmMarginPayRequireIn;
	}
	public void setFcmMarginPayRequireIn(java.util.List fcmMarginPayRequireIn) {
		this.fcmMarginPayRequireIn = fcmMarginPayRequireIn;
	}

	public java.lang.Integer getFcmMarginPayRequireGreaterThanOrEqualTo() {
		return fcmMarginPayRequireGreaterThanOrEqualTo;
	}
	public void setFcmMarginPayRequireGreaterThanOrEqualTo(java.lang.Integer fcmMarginPayRequireGreaterThanOrEqualTo) {
		this.fcmMarginPayRequireGreaterThanOrEqualTo = fcmMarginPayRequireGreaterThanOrEqualTo;
	}

	public java.lang.Integer getFcmMarginPayRequireGreaterThan() {
		return fcmMarginPayRequireGreaterThan;
	}
	public void setFcmMarginPayRequireGreaterThan(java.lang.Integer fcmMarginPayRequireGreaterThan) {
		this.fcmMarginPayRequireGreaterThan = fcmMarginPayRequireGreaterThan;
	}

	public java.lang.Integer getFcmMarginPayRequireEqualTo() {
		return fcmMarginPayRequireEqualTo;
	}
	public void setFcmMarginPayRequireEqualTo(java.lang.Integer fcmMarginPayRequireEqualTo) {
		this.fcmMarginPayRequireEqualTo = fcmMarginPayRequireEqualTo;
	}

	public java.util.List getFcmMarginMoneyNotIn() {
		return fcmMarginMoneyNotIn;
	}
	public void setFcmMarginMoneyNotIn(java.util.List fcmMarginMoneyNotIn) {
		this.fcmMarginMoneyNotIn = fcmMarginMoneyNotIn;
	}

	public java.lang.Double getFcmMarginMoneyNotEqualTo() {
		return fcmMarginMoneyNotEqualTo;
	}
	public void setFcmMarginMoneyNotEqualTo(java.lang.Double fcmMarginMoneyNotEqualTo) {
		this.fcmMarginMoneyNotEqualTo = fcmMarginMoneyNotEqualTo;
	}

	public java.lang.Double getFcmMarginMoneyLessThanOrEqualTo() {
		return fcmMarginMoneyLessThanOrEqualTo;
	}
	public void setFcmMarginMoneyLessThanOrEqualTo(java.lang.Double fcmMarginMoneyLessThanOrEqualTo) {
		this.fcmMarginMoneyLessThanOrEqualTo = fcmMarginMoneyLessThanOrEqualTo;
	}

	public java.lang.Double getFcmMarginMoneyLessThan() {
		return fcmMarginMoneyLessThan;
	}
	public void setFcmMarginMoneyLessThan(java.lang.Double fcmMarginMoneyLessThan) {
		this.fcmMarginMoneyLessThan = fcmMarginMoneyLessThan;
	}

	public java.lang.Boolean getFcmMarginMoneyIsNull() {
		return fcmMarginMoneyIsNull;
	}
	public void setFcmMarginMoneyIsNull(java.lang.Boolean fcmMarginMoneyIsNull) {
		this.fcmMarginMoneyIsNull = fcmMarginMoneyIsNull;
	}

	public java.lang.Boolean getFcmMarginMoneyIsNotNull() {
		return fcmMarginMoneyIsNotNull;
	}
	public void setFcmMarginMoneyIsNotNull(java.lang.Boolean fcmMarginMoneyIsNotNull) {
		this.fcmMarginMoneyIsNotNull = fcmMarginMoneyIsNotNull;
	}

	public java.util.List getFcmMarginMoneyIn() {
		return fcmMarginMoneyIn;
	}
	public void setFcmMarginMoneyIn(java.util.List fcmMarginMoneyIn) {
		this.fcmMarginMoneyIn = fcmMarginMoneyIn;
	}

	public java.lang.Double getFcmMarginMoneyGreaterThanOrEqualTo() {
		return fcmMarginMoneyGreaterThanOrEqualTo;
	}
	public void setFcmMarginMoneyGreaterThanOrEqualTo(java.lang.Double fcmMarginMoneyGreaterThanOrEqualTo) {
		this.fcmMarginMoneyGreaterThanOrEqualTo = fcmMarginMoneyGreaterThanOrEqualTo;
	}

	public java.lang.Double getFcmMarginMoneyGreaterThan() {
		return fcmMarginMoneyGreaterThan;
	}
	public void setFcmMarginMoneyGreaterThan(java.lang.Double fcmMarginMoneyGreaterThan) {
		this.fcmMarginMoneyGreaterThan = fcmMarginMoneyGreaterThan;
	}

	public java.lang.Double getFcmMarginMoneyEqualTo() {
		return fcmMarginMoneyEqualTo;
	}
	public void setFcmMarginMoneyEqualTo(java.lang.Double fcmMarginMoneyEqualTo) {
		this.fcmMarginMoneyEqualTo = fcmMarginMoneyEqualTo;
	}

	public java.util.List getFcmLeaseTypeNotIn() {
		return fcmLeaseTypeNotIn;
	}
	public void setFcmLeaseTypeNotIn(java.util.List fcmLeaseTypeNotIn) {
		this.fcmLeaseTypeNotIn = fcmLeaseTypeNotIn;
	}

	public java.lang.Integer getFcmLeaseTypeNotEqualTo() {
		return fcmLeaseTypeNotEqualTo;
	}
	public void setFcmLeaseTypeNotEqualTo(java.lang.Integer fcmLeaseTypeNotEqualTo) {
		this.fcmLeaseTypeNotEqualTo = fcmLeaseTypeNotEqualTo;
	}

	public java.lang.Integer getFcmLeaseTypeLessThanOrEqualTo() {
		return fcmLeaseTypeLessThanOrEqualTo;
	}
	public void setFcmLeaseTypeLessThanOrEqualTo(java.lang.Integer fcmLeaseTypeLessThanOrEqualTo) {
		this.fcmLeaseTypeLessThanOrEqualTo = fcmLeaseTypeLessThanOrEqualTo;
	}

	public java.lang.Integer getFcmLeaseTypeLessThan() {
		return fcmLeaseTypeLessThan;
	}
	public void setFcmLeaseTypeLessThan(java.lang.Integer fcmLeaseTypeLessThan) {
		this.fcmLeaseTypeLessThan = fcmLeaseTypeLessThan;
	}

	public java.lang.Boolean getFcmLeaseTypeIsNull() {
		return fcmLeaseTypeIsNull;
	}
	public void setFcmLeaseTypeIsNull(java.lang.Boolean fcmLeaseTypeIsNull) {
		this.fcmLeaseTypeIsNull = fcmLeaseTypeIsNull;
	}

	public java.lang.Boolean getFcmLeaseTypeIsNotNull() {
		return fcmLeaseTypeIsNotNull;
	}
	public void setFcmLeaseTypeIsNotNull(java.lang.Boolean fcmLeaseTypeIsNotNull) {
		this.fcmLeaseTypeIsNotNull = fcmLeaseTypeIsNotNull;
	}

	public java.util.List getFcmLeaseTypeIn() {
		return fcmLeaseTypeIn;
	}
	public void setFcmLeaseTypeIn(java.util.List fcmLeaseTypeIn) {
		this.fcmLeaseTypeIn = fcmLeaseTypeIn;
	}

	public java.lang.Integer getFcmLeaseTypeGreaterThanOrEqualTo() {
		return fcmLeaseTypeGreaterThanOrEqualTo;
	}
	public void setFcmLeaseTypeGreaterThanOrEqualTo(java.lang.Integer fcmLeaseTypeGreaterThanOrEqualTo) {
		this.fcmLeaseTypeGreaterThanOrEqualTo = fcmLeaseTypeGreaterThanOrEqualTo;
	}

	public java.lang.Integer getFcmLeaseTypeGreaterThan() {
		return fcmLeaseTypeGreaterThan;
	}
	public void setFcmLeaseTypeGreaterThan(java.lang.Integer fcmLeaseTypeGreaterThan) {
		this.fcmLeaseTypeGreaterThan = fcmLeaseTypeGreaterThan;
	}

	public java.lang.Integer getFcmLeaseTypeEqualTo() {
		return fcmLeaseTypeEqualTo;
	}
	public void setFcmLeaseTypeEqualTo(java.lang.Integer fcmLeaseTypeEqualTo) {
		this.fcmLeaseTypeEqualTo = fcmLeaseTypeEqualTo;
	}

	public java.util.List getFcmLeaseStartTypeNotIn() {
		return fcmLeaseStartTypeNotIn;
	}
	public void setFcmLeaseStartTypeNotIn(java.util.List fcmLeaseStartTypeNotIn) {
		this.fcmLeaseStartTypeNotIn = fcmLeaseStartTypeNotIn;
	}

	public java.lang.Integer getFcmLeaseStartTypeNotEqualTo() {
		return fcmLeaseStartTypeNotEqualTo;
	}
	public void setFcmLeaseStartTypeNotEqualTo(java.lang.Integer fcmLeaseStartTypeNotEqualTo) {
		this.fcmLeaseStartTypeNotEqualTo = fcmLeaseStartTypeNotEqualTo;
	}

	public java.lang.Integer getFcmLeaseStartTypeLessThanOrEqualTo() {
		return fcmLeaseStartTypeLessThanOrEqualTo;
	}
	public void setFcmLeaseStartTypeLessThanOrEqualTo(java.lang.Integer fcmLeaseStartTypeLessThanOrEqualTo) {
		this.fcmLeaseStartTypeLessThanOrEqualTo = fcmLeaseStartTypeLessThanOrEqualTo;
	}

	public java.lang.Integer getFcmLeaseStartTypeLessThan() {
		return fcmLeaseStartTypeLessThan;
	}
	public void setFcmLeaseStartTypeLessThan(java.lang.Integer fcmLeaseStartTypeLessThan) {
		this.fcmLeaseStartTypeLessThan = fcmLeaseStartTypeLessThan;
	}

	public java.lang.Boolean getFcmLeaseStartTypeIsNull() {
		return fcmLeaseStartTypeIsNull;
	}
	public void setFcmLeaseStartTypeIsNull(java.lang.Boolean fcmLeaseStartTypeIsNull) {
		this.fcmLeaseStartTypeIsNull = fcmLeaseStartTypeIsNull;
	}

	public java.lang.Boolean getFcmLeaseStartTypeIsNotNull() {
		return fcmLeaseStartTypeIsNotNull;
	}
	public void setFcmLeaseStartTypeIsNotNull(java.lang.Boolean fcmLeaseStartTypeIsNotNull) {
		this.fcmLeaseStartTypeIsNotNull = fcmLeaseStartTypeIsNotNull;
	}

	public java.util.List getFcmLeaseStartTypeIn() {
		return fcmLeaseStartTypeIn;
	}
	public void setFcmLeaseStartTypeIn(java.util.List fcmLeaseStartTypeIn) {
		this.fcmLeaseStartTypeIn = fcmLeaseStartTypeIn;
	}

	public java.lang.Integer getFcmLeaseStartTypeGreaterThanOrEqualTo() {
		return fcmLeaseStartTypeGreaterThanOrEqualTo;
	}
	public void setFcmLeaseStartTypeGreaterThanOrEqualTo(java.lang.Integer fcmLeaseStartTypeGreaterThanOrEqualTo) {
		this.fcmLeaseStartTypeGreaterThanOrEqualTo = fcmLeaseStartTypeGreaterThanOrEqualTo;
	}

	public java.lang.Integer getFcmLeaseStartTypeGreaterThan() {
		return fcmLeaseStartTypeGreaterThan;
	}
	public void setFcmLeaseStartTypeGreaterThan(java.lang.Integer fcmLeaseStartTypeGreaterThan) {
		this.fcmLeaseStartTypeGreaterThan = fcmLeaseStartTypeGreaterThan;
	}

	public java.lang.Integer getFcmLeaseStartTypeEqualTo() {
		return fcmLeaseStartTypeEqualTo;
	}
	public void setFcmLeaseStartTypeEqualTo(java.lang.Integer fcmLeaseStartTypeEqualTo) {
		this.fcmLeaseStartTypeEqualTo = fcmLeaseStartTypeEqualTo;
	}

	public java.util.List getFcmLeaseStartDateNotIn() {
		return fcmLeaseStartDateNotIn;
	}
	public void setFcmLeaseStartDateNotIn(java.util.List fcmLeaseStartDateNotIn) {
		this.fcmLeaseStartDateNotIn = fcmLeaseStartDateNotIn;
	}

	public java.util.Date getFcmLeaseStartDateNotEqualTo() {
		return fcmLeaseStartDateNotEqualTo;
	}
	public void setFcmLeaseStartDateNotEqualTo(java.util.Date fcmLeaseStartDateNotEqualTo) {
		this.fcmLeaseStartDateNotEqualTo = fcmLeaseStartDateNotEqualTo;
	}

	public java.util.Date getFcmLeaseStartDateLessThanOrEqualTo() {
		return fcmLeaseStartDateLessThanOrEqualTo;
	}
	public void setFcmLeaseStartDateLessThanOrEqualTo(java.util.Date fcmLeaseStartDateLessThanOrEqualTo) {
		this.fcmLeaseStartDateLessThanOrEqualTo = fcmLeaseStartDateLessThanOrEqualTo;
	}

	public java.util.Date getFcmLeaseStartDateLessThan() {
		return fcmLeaseStartDateLessThan;
	}
	public void setFcmLeaseStartDateLessThan(java.util.Date fcmLeaseStartDateLessThan) {
		this.fcmLeaseStartDateLessThan = fcmLeaseStartDateLessThan;
	}

	public java.lang.Boolean getFcmLeaseStartDateIsNull() {
		return fcmLeaseStartDateIsNull;
	}
	public void setFcmLeaseStartDateIsNull(java.lang.Boolean fcmLeaseStartDateIsNull) {
		this.fcmLeaseStartDateIsNull = fcmLeaseStartDateIsNull;
	}

	public java.lang.Boolean getFcmLeaseStartDateIsNotNull() {
		return fcmLeaseStartDateIsNotNull;
	}
	public void setFcmLeaseStartDateIsNotNull(java.lang.Boolean fcmLeaseStartDateIsNotNull) {
		this.fcmLeaseStartDateIsNotNull = fcmLeaseStartDateIsNotNull;
	}

	public java.util.List getFcmLeaseStartDateIn() {
		return fcmLeaseStartDateIn;
	}
	public void setFcmLeaseStartDateIn(java.util.List fcmLeaseStartDateIn) {
		this.fcmLeaseStartDateIn = fcmLeaseStartDateIn;
	}

	public java.util.Date getFcmLeaseStartDateGreaterThanOrEqualTo() {
		return fcmLeaseStartDateGreaterThanOrEqualTo;
	}
	public void setFcmLeaseStartDateGreaterThanOrEqualTo(java.util.Date fcmLeaseStartDateGreaterThanOrEqualTo) {
		this.fcmLeaseStartDateGreaterThanOrEqualTo = fcmLeaseStartDateGreaterThanOrEqualTo;
	}

	public java.util.Date getFcmLeaseStartDateGreaterThan() {
		return fcmLeaseStartDateGreaterThan;
	}
	public void setFcmLeaseStartDateGreaterThan(java.util.Date fcmLeaseStartDateGreaterThan) {
		this.fcmLeaseStartDateGreaterThan = fcmLeaseStartDateGreaterThan;
	}

	public java.util.Date getFcmLeaseStartDateEqualTo() {
		return fcmLeaseStartDateEqualTo;
	}
	public void setFcmLeaseStartDateEqualTo(java.util.Date fcmLeaseStartDateEqualTo) {
		this.fcmLeaseStartDateEqualTo = fcmLeaseStartDateEqualTo;
	}

	public java.util.List getFcmLeaseEndDateNotIn() {
		return fcmLeaseEndDateNotIn;
	}
	public void setFcmLeaseEndDateNotIn(java.util.List fcmLeaseEndDateNotIn) {
		this.fcmLeaseEndDateNotIn = fcmLeaseEndDateNotIn;
	}

	public java.util.Date getFcmLeaseEndDateNotEqualTo() {
		return fcmLeaseEndDateNotEqualTo;
	}
	public void setFcmLeaseEndDateNotEqualTo(java.util.Date fcmLeaseEndDateNotEqualTo) {
		this.fcmLeaseEndDateNotEqualTo = fcmLeaseEndDateNotEqualTo;
	}

	public java.util.Date getFcmLeaseEndDateLessThanOrEqualTo() {
		return fcmLeaseEndDateLessThanOrEqualTo;
	}
	public void setFcmLeaseEndDateLessThanOrEqualTo(java.util.Date fcmLeaseEndDateLessThanOrEqualTo) {
		this.fcmLeaseEndDateLessThanOrEqualTo = fcmLeaseEndDateLessThanOrEqualTo;
	}

	public java.util.Date getFcmLeaseEndDateLessThan() {
		return fcmLeaseEndDateLessThan;
	}
	public void setFcmLeaseEndDateLessThan(java.util.Date fcmLeaseEndDateLessThan) {
		this.fcmLeaseEndDateLessThan = fcmLeaseEndDateLessThan;
	}

	public java.lang.Boolean getFcmLeaseEndDateIsNull() {
		return fcmLeaseEndDateIsNull;
	}
	public void setFcmLeaseEndDateIsNull(java.lang.Boolean fcmLeaseEndDateIsNull) {
		this.fcmLeaseEndDateIsNull = fcmLeaseEndDateIsNull;
	}

	public java.lang.Boolean getFcmLeaseEndDateIsNotNull() {
		return fcmLeaseEndDateIsNotNull;
	}
	public void setFcmLeaseEndDateIsNotNull(java.lang.Boolean fcmLeaseEndDateIsNotNull) {
		this.fcmLeaseEndDateIsNotNull = fcmLeaseEndDateIsNotNull;
	}

	public java.util.List getFcmLeaseEndDateIn() {
		return fcmLeaseEndDateIn;
	}
	public void setFcmLeaseEndDateIn(java.util.List fcmLeaseEndDateIn) {
		this.fcmLeaseEndDateIn = fcmLeaseEndDateIn;
	}

	public java.util.Date getFcmLeaseEndDateGreaterThanOrEqualTo() {
		return fcmLeaseEndDateGreaterThanOrEqualTo;
	}
	public void setFcmLeaseEndDateGreaterThanOrEqualTo(java.util.Date fcmLeaseEndDateGreaterThanOrEqualTo) {
		this.fcmLeaseEndDateGreaterThanOrEqualTo = fcmLeaseEndDateGreaterThanOrEqualTo;
	}

	public java.util.Date getFcmLeaseEndDateGreaterThan() {
		return fcmLeaseEndDateGreaterThan;
	}
	public void setFcmLeaseEndDateGreaterThan(java.util.Date fcmLeaseEndDateGreaterThan) {
		this.fcmLeaseEndDateGreaterThan = fcmLeaseEndDateGreaterThan;
	}

	public java.util.Date getFcmLeaseEndDateEqualTo() {
		return fcmLeaseEndDateEqualTo;
	}
	public void setFcmLeaseEndDateEqualTo(java.util.Date fcmLeaseEndDateEqualTo) {
		this.fcmLeaseEndDateEqualTo = fcmLeaseEndDateEqualTo;
	}

	public java.util.List getFcmLeaseCountNotIn() {
		return fcmLeaseCountNotIn;
	}
	public void setFcmLeaseCountNotIn(java.util.List fcmLeaseCountNotIn) {
		this.fcmLeaseCountNotIn = fcmLeaseCountNotIn;
	}

	public java.lang.Integer getFcmLeaseCountNotEqualTo() {
		return fcmLeaseCountNotEqualTo;
	}
	public void setFcmLeaseCountNotEqualTo(java.lang.Integer fcmLeaseCountNotEqualTo) {
		this.fcmLeaseCountNotEqualTo = fcmLeaseCountNotEqualTo;
	}

	public java.lang.Integer getFcmLeaseCountLessThanOrEqualTo() {
		return fcmLeaseCountLessThanOrEqualTo;
	}
	public void setFcmLeaseCountLessThanOrEqualTo(java.lang.Integer fcmLeaseCountLessThanOrEqualTo) {
		this.fcmLeaseCountLessThanOrEqualTo = fcmLeaseCountLessThanOrEqualTo;
	}

	public java.lang.Integer getFcmLeaseCountLessThan() {
		return fcmLeaseCountLessThan;
	}
	public void setFcmLeaseCountLessThan(java.lang.Integer fcmLeaseCountLessThan) {
		this.fcmLeaseCountLessThan = fcmLeaseCountLessThan;
	}

	public java.lang.Boolean getFcmLeaseCountIsNull() {
		return fcmLeaseCountIsNull;
	}
	public void setFcmLeaseCountIsNull(java.lang.Boolean fcmLeaseCountIsNull) {
		this.fcmLeaseCountIsNull = fcmLeaseCountIsNull;
	}

	public java.lang.Boolean getFcmLeaseCountIsNotNull() {
		return fcmLeaseCountIsNotNull;
	}
	public void setFcmLeaseCountIsNotNull(java.lang.Boolean fcmLeaseCountIsNotNull) {
		this.fcmLeaseCountIsNotNull = fcmLeaseCountIsNotNull;
	}

	public java.util.List getFcmLeaseCountIn() {
		return fcmLeaseCountIn;
	}
	public void setFcmLeaseCountIn(java.util.List fcmLeaseCountIn) {
		this.fcmLeaseCountIn = fcmLeaseCountIn;
	}

	public java.lang.Integer getFcmLeaseCountGreaterThanOrEqualTo() {
		return fcmLeaseCountGreaterThanOrEqualTo;
	}
	public void setFcmLeaseCountGreaterThanOrEqualTo(java.lang.Integer fcmLeaseCountGreaterThanOrEqualTo) {
		this.fcmLeaseCountGreaterThanOrEqualTo = fcmLeaseCountGreaterThanOrEqualTo;
	}

	public java.lang.Integer getFcmLeaseCountGreaterThan() {
		return fcmLeaseCountGreaterThan;
	}
	public void setFcmLeaseCountGreaterThan(java.lang.Integer fcmLeaseCountGreaterThan) {
		this.fcmLeaseCountGreaterThan = fcmLeaseCountGreaterThan;
	}

	public java.lang.Integer getFcmLeaseCountEqualTo() {
		return fcmLeaseCountEqualTo;
	}
	public void setFcmLeaseCountEqualTo(java.lang.Integer fcmLeaseCountEqualTo) {
		this.fcmLeaseCountEqualTo = fcmLeaseCountEqualTo;
	}

	public java.util.List getFcmLeaseCalculateTypeNotIn() {
		return fcmLeaseCalculateTypeNotIn;
	}
	public void setFcmLeaseCalculateTypeNotIn(java.util.List fcmLeaseCalculateTypeNotIn) {
		this.fcmLeaseCalculateTypeNotIn = fcmLeaseCalculateTypeNotIn;
	}

	public java.lang.Integer getFcmLeaseCalculateTypeNotEqualTo() {
		return fcmLeaseCalculateTypeNotEqualTo;
	}
	public void setFcmLeaseCalculateTypeNotEqualTo(java.lang.Integer fcmLeaseCalculateTypeNotEqualTo) {
		this.fcmLeaseCalculateTypeNotEqualTo = fcmLeaseCalculateTypeNotEqualTo;
	}

	public java.lang.Integer getFcmLeaseCalculateTypeLessThanOrEqualTo() {
		return fcmLeaseCalculateTypeLessThanOrEqualTo;
	}
	public void setFcmLeaseCalculateTypeLessThanOrEqualTo(java.lang.Integer fcmLeaseCalculateTypeLessThanOrEqualTo) {
		this.fcmLeaseCalculateTypeLessThanOrEqualTo = fcmLeaseCalculateTypeLessThanOrEqualTo;
	}

	public java.lang.Integer getFcmLeaseCalculateTypeLessThan() {
		return fcmLeaseCalculateTypeLessThan;
	}
	public void setFcmLeaseCalculateTypeLessThan(java.lang.Integer fcmLeaseCalculateTypeLessThan) {
		this.fcmLeaseCalculateTypeLessThan = fcmLeaseCalculateTypeLessThan;
	}

	public java.lang.Boolean getFcmLeaseCalculateTypeIsNull() {
		return fcmLeaseCalculateTypeIsNull;
	}
	public void setFcmLeaseCalculateTypeIsNull(java.lang.Boolean fcmLeaseCalculateTypeIsNull) {
		this.fcmLeaseCalculateTypeIsNull = fcmLeaseCalculateTypeIsNull;
	}

	public java.lang.Boolean getFcmLeaseCalculateTypeIsNotNull() {
		return fcmLeaseCalculateTypeIsNotNull;
	}
	public void setFcmLeaseCalculateTypeIsNotNull(java.lang.Boolean fcmLeaseCalculateTypeIsNotNull) {
		this.fcmLeaseCalculateTypeIsNotNull = fcmLeaseCalculateTypeIsNotNull;
	}

	public java.util.List getFcmLeaseCalculateTypeIn() {
		return fcmLeaseCalculateTypeIn;
	}
	public void setFcmLeaseCalculateTypeIn(java.util.List fcmLeaseCalculateTypeIn) {
		this.fcmLeaseCalculateTypeIn = fcmLeaseCalculateTypeIn;
	}

	public java.lang.Integer getFcmLeaseCalculateTypeGreaterThanOrEqualTo() {
		return fcmLeaseCalculateTypeGreaterThanOrEqualTo;
	}
	public void setFcmLeaseCalculateTypeGreaterThanOrEqualTo(java.lang.Integer fcmLeaseCalculateTypeGreaterThanOrEqualTo) {
		this.fcmLeaseCalculateTypeGreaterThanOrEqualTo = fcmLeaseCalculateTypeGreaterThanOrEqualTo;
	}

	public java.lang.Integer getFcmLeaseCalculateTypeGreaterThan() {
		return fcmLeaseCalculateTypeGreaterThan;
	}
	public void setFcmLeaseCalculateTypeGreaterThan(java.lang.Integer fcmLeaseCalculateTypeGreaterThan) {
		this.fcmLeaseCalculateTypeGreaterThan = fcmLeaseCalculateTypeGreaterThan;
	}

	public java.lang.Integer getFcmLeaseCalculateTypeEqualTo() {
		return fcmLeaseCalculateTypeEqualTo;
	}
	public void setFcmLeaseCalculateTypeEqualTo(java.lang.Integer fcmLeaseCalculateTypeEqualTo) {
		this.fcmLeaseCalculateTypeEqualTo = fcmLeaseCalculateTypeEqualTo;
	}

	public java.util.List getFcmLeaseAmountTotalNotIn() {
		return fcmLeaseAmountTotalNotIn;
	}
	public void setFcmLeaseAmountTotalNotIn(java.util.List fcmLeaseAmountTotalNotIn) {
		this.fcmLeaseAmountTotalNotIn = fcmLeaseAmountTotalNotIn;
	}

	public java.lang.Double getFcmLeaseAmountTotalNotEqualTo() {
		return fcmLeaseAmountTotalNotEqualTo;
	}
	public void setFcmLeaseAmountTotalNotEqualTo(java.lang.Double fcmLeaseAmountTotalNotEqualTo) {
		this.fcmLeaseAmountTotalNotEqualTo = fcmLeaseAmountTotalNotEqualTo;
	}

	public java.lang.Double getFcmLeaseAmountTotalLessThanOrEqualTo() {
		return fcmLeaseAmountTotalLessThanOrEqualTo;
	}
	public void setFcmLeaseAmountTotalLessThanOrEqualTo(java.lang.Double fcmLeaseAmountTotalLessThanOrEqualTo) {
		this.fcmLeaseAmountTotalLessThanOrEqualTo = fcmLeaseAmountTotalLessThanOrEqualTo;
	}

	public java.lang.Double getFcmLeaseAmountTotalLessThan() {
		return fcmLeaseAmountTotalLessThan;
	}
	public void setFcmLeaseAmountTotalLessThan(java.lang.Double fcmLeaseAmountTotalLessThan) {
		this.fcmLeaseAmountTotalLessThan = fcmLeaseAmountTotalLessThan;
	}

	public java.lang.Boolean getFcmLeaseAmountTotalIsNull() {
		return fcmLeaseAmountTotalIsNull;
	}
	public void setFcmLeaseAmountTotalIsNull(java.lang.Boolean fcmLeaseAmountTotalIsNull) {
		this.fcmLeaseAmountTotalIsNull = fcmLeaseAmountTotalIsNull;
	}

	public java.lang.Boolean getFcmLeaseAmountTotalIsNotNull() {
		return fcmLeaseAmountTotalIsNotNull;
	}
	public void setFcmLeaseAmountTotalIsNotNull(java.lang.Boolean fcmLeaseAmountTotalIsNotNull) {
		this.fcmLeaseAmountTotalIsNotNull = fcmLeaseAmountTotalIsNotNull;
	}

	public java.util.List getFcmLeaseAmountTotalIn() {
		return fcmLeaseAmountTotalIn;
	}
	public void setFcmLeaseAmountTotalIn(java.util.List fcmLeaseAmountTotalIn) {
		this.fcmLeaseAmountTotalIn = fcmLeaseAmountTotalIn;
	}

	public java.lang.Double getFcmLeaseAmountTotalGreaterThanOrEqualTo() {
		return fcmLeaseAmountTotalGreaterThanOrEqualTo;
	}
	public void setFcmLeaseAmountTotalGreaterThanOrEqualTo(java.lang.Double fcmLeaseAmountTotalGreaterThanOrEqualTo) {
		this.fcmLeaseAmountTotalGreaterThanOrEqualTo = fcmLeaseAmountTotalGreaterThanOrEqualTo;
	}

	public java.lang.Double getFcmLeaseAmountTotalGreaterThan() {
		return fcmLeaseAmountTotalGreaterThan;
	}
	public void setFcmLeaseAmountTotalGreaterThan(java.lang.Double fcmLeaseAmountTotalGreaterThan) {
		this.fcmLeaseAmountTotalGreaterThan = fcmLeaseAmountTotalGreaterThan;
	}

	public java.lang.Double getFcmLeaseAmountTotalEqualTo() {
		return fcmLeaseAmountTotalEqualTo;
	}
	public void setFcmLeaseAmountTotalEqualTo(java.lang.Double fcmLeaseAmountTotalEqualTo) {
		this.fcmLeaseAmountTotalEqualTo = fcmLeaseAmountTotalEqualTo;
	}

	public java.util.List getFcmLeaseAmountNotIn() {
		return fcmLeaseAmountNotIn;
	}
	public void setFcmLeaseAmountNotIn(java.util.List fcmLeaseAmountNotIn) {
		this.fcmLeaseAmountNotIn = fcmLeaseAmountNotIn;
	}

	public java.lang.Double getFcmLeaseAmountNotEqualTo() {
		return fcmLeaseAmountNotEqualTo;
	}
	public void setFcmLeaseAmountNotEqualTo(java.lang.Double fcmLeaseAmountNotEqualTo) {
		this.fcmLeaseAmountNotEqualTo = fcmLeaseAmountNotEqualTo;
	}

	public java.lang.Double getFcmLeaseAmountLessThanOrEqualTo() {
		return fcmLeaseAmountLessThanOrEqualTo;
	}
	public void setFcmLeaseAmountLessThanOrEqualTo(java.lang.Double fcmLeaseAmountLessThanOrEqualTo) {
		this.fcmLeaseAmountLessThanOrEqualTo = fcmLeaseAmountLessThanOrEqualTo;
	}

	public java.lang.Double getFcmLeaseAmountLessThan() {
		return fcmLeaseAmountLessThan;
	}
	public void setFcmLeaseAmountLessThan(java.lang.Double fcmLeaseAmountLessThan) {
		this.fcmLeaseAmountLessThan = fcmLeaseAmountLessThan;
	}

	public java.lang.Boolean getFcmLeaseAmountIsNull() {
		return fcmLeaseAmountIsNull;
	}
	public void setFcmLeaseAmountIsNull(java.lang.Boolean fcmLeaseAmountIsNull) {
		this.fcmLeaseAmountIsNull = fcmLeaseAmountIsNull;
	}

	public java.lang.Boolean getFcmLeaseAmountIsNotNull() {
		return fcmLeaseAmountIsNotNull;
	}
	public void setFcmLeaseAmountIsNotNull(java.lang.Boolean fcmLeaseAmountIsNotNull) {
		this.fcmLeaseAmountIsNotNull = fcmLeaseAmountIsNotNull;
	}

	public java.util.List getFcmLeaseAmountIn() {
		return fcmLeaseAmountIn;
	}
	public void setFcmLeaseAmountIn(java.util.List fcmLeaseAmountIn) {
		this.fcmLeaseAmountIn = fcmLeaseAmountIn;
	}

	public java.lang.Double getFcmLeaseAmountGreaterThanOrEqualTo() {
		return fcmLeaseAmountGreaterThanOrEqualTo;
	}
	public void setFcmLeaseAmountGreaterThanOrEqualTo(java.lang.Double fcmLeaseAmountGreaterThanOrEqualTo) {
		this.fcmLeaseAmountGreaterThanOrEqualTo = fcmLeaseAmountGreaterThanOrEqualTo;
	}

	public java.lang.Double getFcmLeaseAmountGreaterThan() {
		return fcmLeaseAmountGreaterThan;
	}
	public void setFcmLeaseAmountGreaterThan(java.lang.Double fcmLeaseAmountGreaterThan) {
		this.fcmLeaseAmountGreaterThan = fcmLeaseAmountGreaterThan;
	}

	public java.lang.Double getFcmLeaseAmountEqualTo() {
		return fcmLeaseAmountEqualTo;
	}
	public void setFcmLeaseAmountEqualTo(java.lang.Double fcmLeaseAmountEqualTo) {
		this.fcmLeaseAmountEqualTo = fcmLeaseAmountEqualTo;
	}

	public java.util.List getFcmIdNotIn() {
		return fcmIdNotIn;
	}
	public void setFcmIdNotIn(java.util.List fcmIdNotIn) {
		this.fcmIdNotIn = fcmIdNotIn;
	}

	public java.lang.Long getFcmIdNotEqualTo() {
		return fcmIdNotEqualTo;
	}
	public void setFcmIdNotEqualTo(java.lang.Long fcmIdNotEqualTo) {
		this.fcmIdNotEqualTo = fcmIdNotEqualTo;
	}

	public java.lang.Long getFcmIdLessThanOrEqualTo() {
		return fcmIdLessThanOrEqualTo;
	}
	public void setFcmIdLessThanOrEqualTo(java.lang.Long fcmIdLessThanOrEqualTo) {
		this.fcmIdLessThanOrEqualTo = fcmIdLessThanOrEqualTo;
	}

	public java.lang.Long getFcmIdLessThan() {
		return fcmIdLessThan;
	}
	public void setFcmIdLessThan(java.lang.Long fcmIdLessThan) {
		this.fcmIdLessThan = fcmIdLessThan;
	}

	public java.lang.Boolean getFcmIdIsNull() {
		return fcmIdIsNull;
	}
	public void setFcmIdIsNull(java.lang.Boolean fcmIdIsNull) {
		this.fcmIdIsNull = fcmIdIsNull;
	}

	public java.lang.Boolean getFcmIdIsNotNull() {
		return fcmIdIsNotNull;
	}
	public void setFcmIdIsNotNull(java.lang.Boolean fcmIdIsNotNull) {
		this.fcmIdIsNotNull = fcmIdIsNotNull;
	}

	public java.util.List getFcmIdIn() {
		return fcmIdIn;
	}
	public void setFcmIdIn(java.util.List fcmIdIn) {
		this.fcmIdIn = fcmIdIn;
	}

	public java.lang.Long getFcmIdGreaterThanOrEqualTo() {
		return fcmIdGreaterThanOrEqualTo;
	}
	public void setFcmIdGreaterThanOrEqualTo(java.lang.Long fcmIdGreaterThanOrEqualTo) {
		this.fcmIdGreaterThanOrEqualTo = fcmIdGreaterThanOrEqualTo;
	}

	public java.lang.Long getFcmIdGreaterThan() {
		return fcmIdGreaterThan;
	}
	public void setFcmIdGreaterThan(java.lang.Long fcmIdGreaterThan) {
		this.fcmIdGreaterThan = fcmIdGreaterThan;
	}

	public java.lang.Long getFcmIdEqualTo() {
		return fcmIdEqualTo;
	}
	public void setFcmIdEqualTo(java.lang.Long fcmIdEqualTo) {
		this.fcmIdEqualTo = fcmIdEqualTo;
	}

	public java.util.List getFcmGiveSequenceNotIn() {
		return fcmGiveSequenceNotIn;
	}
	public void setFcmGiveSequenceNotIn(java.util.List fcmGiveSequenceNotIn) {
		this.fcmGiveSequenceNotIn = fcmGiveSequenceNotIn;
	}

	public java.lang.Integer getFcmGiveSequenceNotEqualTo() {
		return fcmGiveSequenceNotEqualTo;
	}
	public void setFcmGiveSequenceNotEqualTo(java.lang.Integer fcmGiveSequenceNotEqualTo) {
		this.fcmGiveSequenceNotEqualTo = fcmGiveSequenceNotEqualTo;
	}

	public java.lang.Integer getFcmGiveSequenceLessThanOrEqualTo() {
		return fcmGiveSequenceLessThanOrEqualTo;
	}
	public void setFcmGiveSequenceLessThanOrEqualTo(java.lang.Integer fcmGiveSequenceLessThanOrEqualTo) {
		this.fcmGiveSequenceLessThanOrEqualTo = fcmGiveSequenceLessThanOrEqualTo;
	}

	public java.lang.Integer getFcmGiveSequenceLessThan() {
		return fcmGiveSequenceLessThan;
	}
	public void setFcmGiveSequenceLessThan(java.lang.Integer fcmGiveSequenceLessThan) {
		this.fcmGiveSequenceLessThan = fcmGiveSequenceLessThan;
	}

	public java.lang.Boolean getFcmGiveSequenceIsNull() {
		return fcmGiveSequenceIsNull;
	}
	public void setFcmGiveSequenceIsNull(java.lang.Boolean fcmGiveSequenceIsNull) {
		this.fcmGiveSequenceIsNull = fcmGiveSequenceIsNull;
	}

	public java.lang.Boolean getFcmGiveSequenceIsNotNull() {
		return fcmGiveSequenceIsNotNull;
	}
	public void setFcmGiveSequenceIsNotNull(java.lang.Boolean fcmGiveSequenceIsNotNull) {
		this.fcmGiveSequenceIsNotNull = fcmGiveSequenceIsNotNull;
	}

	public java.util.List getFcmGiveSequenceIn() {
		return fcmGiveSequenceIn;
	}
	public void setFcmGiveSequenceIn(java.util.List fcmGiveSequenceIn) {
		this.fcmGiveSequenceIn = fcmGiveSequenceIn;
	}

	public java.lang.Integer getFcmGiveSequenceGreaterThanOrEqualTo() {
		return fcmGiveSequenceGreaterThanOrEqualTo;
	}
	public void setFcmGiveSequenceGreaterThanOrEqualTo(java.lang.Integer fcmGiveSequenceGreaterThanOrEqualTo) {
		this.fcmGiveSequenceGreaterThanOrEqualTo = fcmGiveSequenceGreaterThanOrEqualTo;
	}

	public java.lang.Integer getFcmGiveSequenceGreaterThan() {
		return fcmGiveSequenceGreaterThan;
	}
	public void setFcmGiveSequenceGreaterThan(java.lang.Integer fcmGiveSequenceGreaterThan) {
		this.fcmGiveSequenceGreaterThan = fcmGiveSequenceGreaterThan;
	}

	public java.lang.Integer getFcmGiveSequenceEqualTo() {
		return fcmGiveSequenceEqualTo;
	}
	public void setFcmGiveSequenceEqualTo(java.lang.Integer fcmGiveSequenceEqualTo) {
		this.fcmGiveSequenceEqualTo = fcmGiveSequenceEqualTo;
	}

	public java.util.List getFcmGiveLeaseNotIn() {
		return fcmGiveLeaseNotIn;
	}
	public void setFcmGiveLeaseNotIn(java.util.List fcmGiveLeaseNotIn) {
		this.fcmGiveLeaseNotIn = fcmGiveLeaseNotIn;
	}

	public java.lang.Integer getFcmGiveLeaseNotEqualTo() {
		return fcmGiveLeaseNotEqualTo;
	}
	public void setFcmGiveLeaseNotEqualTo(java.lang.Integer fcmGiveLeaseNotEqualTo) {
		this.fcmGiveLeaseNotEqualTo = fcmGiveLeaseNotEqualTo;
	}

	public java.lang.Integer getFcmGiveLeaseLessThanOrEqualTo() {
		return fcmGiveLeaseLessThanOrEqualTo;
	}
	public void setFcmGiveLeaseLessThanOrEqualTo(java.lang.Integer fcmGiveLeaseLessThanOrEqualTo) {
		this.fcmGiveLeaseLessThanOrEqualTo = fcmGiveLeaseLessThanOrEqualTo;
	}

	public java.lang.Integer getFcmGiveLeaseLessThan() {
		return fcmGiveLeaseLessThan;
	}
	public void setFcmGiveLeaseLessThan(java.lang.Integer fcmGiveLeaseLessThan) {
		this.fcmGiveLeaseLessThan = fcmGiveLeaseLessThan;
	}

	public java.lang.Boolean getFcmGiveLeaseIsNull() {
		return fcmGiveLeaseIsNull;
	}
	public void setFcmGiveLeaseIsNull(java.lang.Boolean fcmGiveLeaseIsNull) {
		this.fcmGiveLeaseIsNull = fcmGiveLeaseIsNull;
	}

	public java.lang.Boolean getFcmGiveLeaseIsNotNull() {
		return fcmGiveLeaseIsNotNull;
	}
	public void setFcmGiveLeaseIsNotNull(java.lang.Boolean fcmGiveLeaseIsNotNull) {
		this.fcmGiveLeaseIsNotNull = fcmGiveLeaseIsNotNull;
	}

	public java.util.List getFcmGiveLeaseIn() {
		return fcmGiveLeaseIn;
	}
	public void setFcmGiveLeaseIn(java.util.List fcmGiveLeaseIn) {
		this.fcmGiveLeaseIn = fcmGiveLeaseIn;
	}

	public java.lang.Integer getFcmGiveLeaseGreaterThanOrEqualTo() {
		return fcmGiveLeaseGreaterThanOrEqualTo;
	}
	public void setFcmGiveLeaseGreaterThanOrEqualTo(java.lang.Integer fcmGiveLeaseGreaterThanOrEqualTo) {
		this.fcmGiveLeaseGreaterThanOrEqualTo = fcmGiveLeaseGreaterThanOrEqualTo;
	}

	public java.lang.Integer getFcmGiveLeaseGreaterThan() {
		return fcmGiveLeaseGreaterThan;
	}
	public void setFcmGiveLeaseGreaterThan(java.lang.Integer fcmGiveLeaseGreaterThan) {
		this.fcmGiveLeaseGreaterThan = fcmGiveLeaseGreaterThan;
	}

	public java.lang.Integer getFcmGiveLeaseEqualTo() {
		return fcmGiveLeaseEqualTo;
	}
	public void setFcmGiveLeaseEqualTo(java.lang.Integer fcmGiveLeaseEqualTo) {
		this.fcmGiveLeaseEqualTo = fcmGiveLeaseEqualTo;
	}

	public java.util.List getFcmDeliverTypeNotIn() {
		return fcmDeliverTypeNotIn;
	}
	public void setFcmDeliverTypeNotIn(java.util.List fcmDeliverTypeNotIn) {
		this.fcmDeliverTypeNotIn = fcmDeliverTypeNotIn;
	}

	public java.lang.Integer getFcmDeliverTypeNotEqualTo() {
		return fcmDeliverTypeNotEqualTo;
	}
	public void setFcmDeliverTypeNotEqualTo(java.lang.Integer fcmDeliverTypeNotEqualTo) {
		this.fcmDeliverTypeNotEqualTo = fcmDeliverTypeNotEqualTo;
	}

	public java.lang.Integer getFcmDeliverTypeLessThanOrEqualTo() {
		return fcmDeliverTypeLessThanOrEqualTo;
	}
	public void setFcmDeliverTypeLessThanOrEqualTo(java.lang.Integer fcmDeliverTypeLessThanOrEqualTo) {
		this.fcmDeliverTypeLessThanOrEqualTo = fcmDeliverTypeLessThanOrEqualTo;
	}

	public java.lang.Integer getFcmDeliverTypeLessThan() {
		return fcmDeliverTypeLessThan;
	}
	public void setFcmDeliverTypeLessThan(java.lang.Integer fcmDeliverTypeLessThan) {
		this.fcmDeliverTypeLessThan = fcmDeliverTypeLessThan;
	}

	public java.lang.Boolean getFcmDeliverTypeIsNull() {
		return fcmDeliverTypeIsNull;
	}
	public void setFcmDeliverTypeIsNull(java.lang.Boolean fcmDeliverTypeIsNull) {
		this.fcmDeliverTypeIsNull = fcmDeliverTypeIsNull;
	}

	public java.lang.Boolean getFcmDeliverTypeIsNotNull() {
		return fcmDeliverTypeIsNotNull;
	}
	public void setFcmDeliverTypeIsNotNull(java.lang.Boolean fcmDeliverTypeIsNotNull) {
		this.fcmDeliverTypeIsNotNull = fcmDeliverTypeIsNotNull;
	}

	public java.util.List getFcmDeliverTypeIn() {
		return fcmDeliverTypeIn;
	}
	public void setFcmDeliverTypeIn(java.util.List fcmDeliverTypeIn) {
		this.fcmDeliverTypeIn = fcmDeliverTypeIn;
	}

	public java.lang.Integer getFcmDeliverTypeGreaterThanOrEqualTo() {
		return fcmDeliverTypeGreaterThanOrEqualTo;
	}
	public void setFcmDeliverTypeGreaterThanOrEqualTo(java.lang.Integer fcmDeliverTypeGreaterThanOrEqualTo) {
		this.fcmDeliverTypeGreaterThanOrEqualTo = fcmDeliverTypeGreaterThanOrEqualTo;
	}

	public java.lang.Integer getFcmDeliverTypeGreaterThan() {
		return fcmDeliverTypeGreaterThan;
	}
	public void setFcmDeliverTypeGreaterThan(java.lang.Integer fcmDeliverTypeGreaterThan) {
		this.fcmDeliverTypeGreaterThan = fcmDeliverTypeGreaterThan;
	}

	public java.lang.Integer getFcmDeliverTypeEqualTo() {
		return fcmDeliverTypeEqualTo;
	}
	public void setFcmDeliverTypeEqualTo(java.lang.Integer fcmDeliverTypeEqualTo) {
		this.fcmDeliverTypeEqualTo = fcmDeliverTypeEqualTo;
	}

	public java.util.List getFcmDeliverCityNotIn() {
		return fcmDeliverCityNotIn;
	}
	public void setFcmDeliverCityNotIn(java.util.List fcmDeliverCityNotIn) {
		this.fcmDeliverCityNotIn = fcmDeliverCityNotIn;
	}

	public java.lang.Long getFcmDeliverCityNotEqualTo() {
		return fcmDeliverCityNotEqualTo;
	}
	public void setFcmDeliverCityNotEqualTo(java.lang.Long fcmDeliverCityNotEqualTo) {
		this.fcmDeliverCityNotEqualTo = fcmDeliverCityNotEqualTo;
	}

	public java.lang.Long getFcmDeliverCityLessThanOrEqualTo() {
		return fcmDeliverCityLessThanOrEqualTo;
	}
	public void setFcmDeliverCityLessThanOrEqualTo(java.lang.Long fcmDeliverCityLessThanOrEqualTo) {
		this.fcmDeliverCityLessThanOrEqualTo = fcmDeliverCityLessThanOrEqualTo;
	}

	public java.lang.Long getFcmDeliverCityLessThan() {
		return fcmDeliverCityLessThan;
	}
	public void setFcmDeliverCityLessThan(java.lang.Long fcmDeliverCityLessThan) {
		this.fcmDeliverCityLessThan = fcmDeliverCityLessThan;
	}

	public java.lang.Boolean getFcmDeliverCityIsNull() {
		return fcmDeliverCityIsNull;
	}
	public void setFcmDeliverCityIsNull(java.lang.Boolean fcmDeliverCityIsNull) {
		this.fcmDeliverCityIsNull = fcmDeliverCityIsNull;
	}

	public java.lang.Boolean getFcmDeliverCityIsNotNull() {
		return fcmDeliverCityIsNotNull;
	}
	public void setFcmDeliverCityIsNotNull(java.lang.Boolean fcmDeliverCityIsNotNull) {
		this.fcmDeliverCityIsNotNull = fcmDeliverCityIsNotNull;
	}

	public java.util.List getFcmDeliverCityIn() {
		return fcmDeliverCityIn;
	}
	public void setFcmDeliverCityIn(java.util.List fcmDeliverCityIn) {
		this.fcmDeliverCityIn = fcmDeliverCityIn;
	}

	public java.lang.Long getFcmDeliverCityGreaterThanOrEqualTo() {
		return fcmDeliverCityGreaterThanOrEqualTo;
	}
	public void setFcmDeliverCityGreaterThanOrEqualTo(java.lang.Long fcmDeliverCityGreaterThanOrEqualTo) {
		this.fcmDeliverCityGreaterThanOrEqualTo = fcmDeliverCityGreaterThanOrEqualTo;
	}

	public java.lang.Long getFcmDeliverCityGreaterThan() {
		return fcmDeliverCityGreaterThan;
	}
	public void setFcmDeliverCityGreaterThan(java.lang.Long fcmDeliverCityGreaterThan) {
		this.fcmDeliverCityGreaterThan = fcmDeliverCityGreaterThan;
	}

	public java.lang.Long getFcmDeliverCityEqualTo() {
		return fcmDeliverCityEqualTo;
	}
	public void setFcmDeliverCityEqualTo(java.lang.Long fcmDeliverCityEqualTo) {
		this.fcmDeliverCityEqualTo = fcmDeliverCityEqualTo;
	}

	public java.lang.String getFcmCreatePhoneNotLike() {
		return fcmCreatePhoneNotLike;
	}
	public void setFcmCreatePhoneNotLike(java.lang.String fcmCreatePhoneNotLike) {
		this.fcmCreatePhoneNotLike = fcmCreatePhoneNotLike;
	}

	public java.util.List getFcmCreatePhoneNotIn() {
		return fcmCreatePhoneNotIn;
	}
	public void setFcmCreatePhoneNotIn(java.util.List fcmCreatePhoneNotIn) {
		this.fcmCreatePhoneNotIn = fcmCreatePhoneNotIn;
	}

	public java.lang.String getFcmCreatePhoneNotEqualTo() {
		return fcmCreatePhoneNotEqualTo;
	}
	public void setFcmCreatePhoneNotEqualTo(java.lang.String fcmCreatePhoneNotEqualTo) {
		this.fcmCreatePhoneNotEqualTo = fcmCreatePhoneNotEqualTo;
	}

	public java.lang.String getFcmCreatePhoneLike() {
		return fcmCreatePhoneLike;
	}
	public void setFcmCreatePhoneLike(java.lang.String fcmCreatePhoneLike) {
		this.fcmCreatePhoneLike = fcmCreatePhoneLike;
	}

	public java.lang.String getFcmCreatePhoneLessThanOrEqualTo() {
		return fcmCreatePhoneLessThanOrEqualTo;
	}
	public void setFcmCreatePhoneLessThanOrEqualTo(java.lang.String fcmCreatePhoneLessThanOrEqualTo) {
		this.fcmCreatePhoneLessThanOrEqualTo = fcmCreatePhoneLessThanOrEqualTo;
	}

	public java.lang.String getFcmCreatePhoneLessThan() {
		return fcmCreatePhoneLessThan;
	}
	public void setFcmCreatePhoneLessThan(java.lang.String fcmCreatePhoneLessThan) {
		this.fcmCreatePhoneLessThan = fcmCreatePhoneLessThan;
	}

	public java.lang.Boolean getFcmCreatePhoneIsNull() {
		return fcmCreatePhoneIsNull;
	}
	public void setFcmCreatePhoneIsNull(java.lang.Boolean fcmCreatePhoneIsNull) {
		this.fcmCreatePhoneIsNull = fcmCreatePhoneIsNull;
	}

	public java.lang.Boolean getFcmCreatePhoneIsNotNull() {
		return fcmCreatePhoneIsNotNull;
	}
	public void setFcmCreatePhoneIsNotNull(java.lang.Boolean fcmCreatePhoneIsNotNull) {
		this.fcmCreatePhoneIsNotNull = fcmCreatePhoneIsNotNull;
	}

	public java.util.List getFcmCreatePhoneIn() {
		return fcmCreatePhoneIn;
	}
	public void setFcmCreatePhoneIn(java.util.List fcmCreatePhoneIn) {
		this.fcmCreatePhoneIn = fcmCreatePhoneIn;
	}

	public java.lang.String getFcmCreatePhoneGreaterThanOrEqualTo() {
		return fcmCreatePhoneGreaterThanOrEqualTo;
	}
	public void setFcmCreatePhoneGreaterThanOrEqualTo(java.lang.String fcmCreatePhoneGreaterThanOrEqualTo) {
		this.fcmCreatePhoneGreaterThanOrEqualTo = fcmCreatePhoneGreaterThanOrEqualTo;
	}

	public java.lang.String getFcmCreatePhoneGreaterThan() {
		return fcmCreatePhoneGreaterThan;
	}
	public void setFcmCreatePhoneGreaterThan(java.lang.String fcmCreatePhoneGreaterThan) {
		this.fcmCreatePhoneGreaterThan = fcmCreatePhoneGreaterThan;
	}

	public java.lang.String getFcmCreatePhoneEqualTo() {
		return fcmCreatePhoneEqualTo;
	}
	public void setFcmCreatePhoneEqualTo(java.lang.String fcmCreatePhoneEqualTo) {
		this.fcmCreatePhoneEqualTo = fcmCreatePhoneEqualTo;
	}

	public java.util.List getFcmContractTypeNotIn() {
		return fcmContractTypeNotIn;
	}
	public void setFcmContractTypeNotIn(java.util.List fcmContractTypeNotIn) {
		this.fcmContractTypeNotIn = fcmContractTypeNotIn;
	}

	public java.lang.Integer getFcmContractTypeNotEqualTo() {
		return fcmContractTypeNotEqualTo;
	}
	public void setFcmContractTypeNotEqualTo(java.lang.Integer fcmContractTypeNotEqualTo) {
		this.fcmContractTypeNotEqualTo = fcmContractTypeNotEqualTo;
	}

	public java.lang.Integer getFcmContractTypeLessThanOrEqualTo() {
		return fcmContractTypeLessThanOrEqualTo;
	}
	public void setFcmContractTypeLessThanOrEqualTo(java.lang.Integer fcmContractTypeLessThanOrEqualTo) {
		this.fcmContractTypeLessThanOrEqualTo = fcmContractTypeLessThanOrEqualTo;
	}

	public java.lang.Integer getFcmContractTypeLessThan() {
		return fcmContractTypeLessThan;
	}
	public void setFcmContractTypeLessThan(java.lang.Integer fcmContractTypeLessThan) {
		this.fcmContractTypeLessThan = fcmContractTypeLessThan;
	}

	public java.lang.Boolean getFcmContractTypeIsNull() {
		return fcmContractTypeIsNull;
	}
	public void setFcmContractTypeIsNull(java.lang.Boolean fcmContractTypeIsNull) {
		this.fcmContractTypeIsNull = fcmContractTypeIsNull;
	}

	public java.lang.Boolean getFcmContractTypeIsNotNull() {
		return fcmContractTypeIsNotNull;
	}
	public void setFcmContractTypeIsNotNull(java.lang.Boolean fcmContractTypeIsNotNull) {
		this.fcmContractTypeIsNotNull = fcmContractTypeIsNotNull;
	}

	public java.util.List getFcmContractTypeIn() {
		return fcmContractTypeIn;
	}
	public void setFcmContractTypeIn(java.util.List fcmContractTypeIn) {
		this.fcmContractTypeIn = fcmContractTypeIn;
	}

	public java.lang.Integer getFcmContractTypeGreaterThanOrEqualTo() {
		return fcmContractTypeGreaterThanOrEqualTo;
	}
	public void setFcmContractTypeGreaterThanOrEqualTo(java.lang.Integer fcmContractTypeGreaterThanOrEqualTo) {
		this.fcmContractTypeGreaterThanOrEqualTo = fcmContractTypeGreaterThanOrEqualTo;
	}

	public java.lang.Integer getFcmContractTypeGreaterThan() {
		return fcmContractTypeGreaterThan;
	}
	public void setFcmContractTypeGreaterThan(java.lang.Integer fcmContractTypeGreaterThan) {
		this.fcmContractTypeGreaterThan = fcmContractTypeGreaterThan;
	}

	public java.lang.Integer getFcmContractTypeEqualTo() {
		return fcmContractTypeEqualTo;
	}
	public void setFcmContractTypeEqualTo(java.lang.Integer fcmContractTypeEqualTo) {
		this.fcmContractTypeEqualTo = fcmContractTypeEqualTo;
	}

	public java.util.List getFcmContractStateNotIn() {
		return fcmContractStateNotIn;
	}
	public void setFcmContractStateNotIn(java.util.List fcmContractStateNotIn) {
		this.fcmContractStateNotIn = fcmContractStateNotIn;
	}

	public java.lang.Integer getFcmContractStateNotEqualTo() {
		return fcmContractStateNotEqualTo;
	}
	public void setFcmContractStateNotEqualTo(java.lang.Integer fcmContractStateNotEqualTo) {
		this.fcmContractStateNotEqualTo = fcmContractStateNotEqualTo;
	}

	public java.lang.Integer getFcmContractStateLessThanOrEqualTo() {
		return fcmContractStateLessThanOrEqualTo;
	}
	public void setFcmContractStateLessThanOrEqualTo(java.lang.Integer fcmContractStateLessThanOrEqualTo) {
		this.fcmContractStateLessThanOrEqualTo = fcmContractStateLessThanOrEqualTo;
	}

	public java.lang.Integer getFcmContractStateLessThan() {
		return fcmContractStateLessThan;
	}
	public void setFcmContractStateLessThan(java.lang.Integer fcmContractStateLessThan) {
		this.fcmContractStateLessThan = fcmContractStateLessThan;
	}

	public java.lang.Boolean getFcmContractStateIsNull() {
		return fcmContractStateIsNull;
	}
	public void setFcmContractStateIsNull(java.lang.Boolean fcmContractStateIsNull) {
		this.fcmContractStateIsNull = fcmContractStateIsNull;
	}

	public java.lang.Boolean getFcmContractStateIsNotNull() {
		return fcmContractStateIsNotNull;
	}
	public void setFcmContractStateIsNotNull(java.lang.Boolean fcmContractStateIsNotNull) {
		this.fcmContractStateIsNotNull = fcmContractStateIsNotNull;
	}

	public java.util.List getFcmContractStateIn() {
		return fcmContractStateIn;
	}
	public void setFcmContractStateIn(java.util.List fcmContractStateIn) {
		this.fcmContractStateIn = fcmContractStateIn;
	}

	public java.lang.Integer getFcmContractStateGreaterThanOrEqualTo() {
		return fcmContractStateGreaterThanOrEqualTo;
	}
	public void setFcmContractStateGreaterThanOrEqualTo(java.lang.Integer fcmContractStateGreaterThanOrEqualTo) {
		this.fcmContractStateGreaterThanOrEqualTo = fcmContractStateGreaterThanOrEqualTo;
	}

	public java.lang.Integer getFcmContractStateGreaterThan() {
		return fcmContractStateGreaterThan;
	}
	public void setFcmContractStateGreaterThan(java.lang.Integer fcmContractStateGreaterThan) {
		this.fcmContractStateGreaterThan = fcmContractStateGreaterThan;
	}

	public java.lang.Integer getFcmContractStateEqualTo() {
		return fcmContractStateEqualTo;
	}
	public void setFcmContractStateEqualTo(java.lang.Integer fcmContractStateEqualTo) {
		this.fcmContractStateEqualTo = fcmContractStateEqualTo;
	}

	public java.lang.String getFcmContractNoNotLike() {
		return fcmContractNoNotLike;
	}
	public void setFcmContractNoNotLike(java.lang.String fcmContractNoNotLike) {
		this.fcmContractNoNotLike = fcmContractNoNotLike;
	}

	public java.util.List getFcmContractNoNotIn() {
		return fcmContractNoNotIn;
	}
	public void setFcmContractNoNotIn(java.util.List fcmContractNoNotIn) {
		this.fcmContractNoNotIn = fcmContractNoNotIn;
	}

	public java.lang.String getFcmContractNoNotEqualTo() {
		return fcmContractNoNotEqualTo;
	}
	public void setFcmContractNoNotEqualTo(java.lang.String fcmContractNoNotEqualTo) {
		this.fcmContractNoNotEqualTo = fcmContractNoNotEqualTo;
	}

	public java.lang.String getFcmContractNoLike() {
		return fcmContractNoLike;
	}
	public void setFcmContractNoLike(java.lang.String fcmContractNoLike) {
		this.fcmContractNoLike = fcmContractNoLike;
	}

	public java.lang.String getFcmContractNoLessThanOrEqualTo() {
		return fcmContractNoLessThanOrEqualTo;
	}
	public void setFcmContractNoLessThanOrEqualTo(java.lang.String fcmContractNoLessThanOrEqualTo) {
		this.fcmContractNoLessThanOrEqualTo = fcmContractNoLessThanOrEqualTo;
	}

	public java.lang.String getFcmContractNoLessThan() {
		return fcmContractNoLessThan;
	}
	public void setFcmContractNoLessThan(java.lang.String fcmContractNoLessThan) {
		this.fcmContractNoLessThan = fcmContractNoLessThan;
	}

	public java.lang.Boolean getFcmContractNoIsNull() {
		return fcmContractNoIsNull;
	}
	public void setFcmContractNoIsNull(java.lang.Boolean fcmContractNoIsNull) {
		this.fcmContractNoIsNull = fcmContractNoIsNull;
	}

	public java.lang.Boolean getFcmContractNoIsNotNull() {
		return fcmContractNoIsNotNull;
	}
	public void setFcmContractNoIsNotNull(java.lang.Boolean fcmContractNoIsNotNull) {
		this.fcmContractNoIsNotNull = fcmContractNoIsNotNull;
	}

	public java.util.List getFcmContractNoIn() {
		return fcmContractNoIn;
	}
	public void setFcmContractNoIn(java.util.List fcmContractNoIn) {
		this.fcmContractNoIn = fcmContractNoIn;
	}

	public java.lang.String getFcmContractNoGreaterThanOrEqualTo() {
		return fcmContractNoGreaterThanOrEqualTo;
	}
	public void setFcmContractNoGreaterThanOrEqualTo(java.lang.String fcmContractNoGreaterThanOrEqualTo) {
		this.fcmContractNoGreaterThanOrEqualTo = fcmContractNoGreaterThanOrEqualTo;
	}

	public java.lang.String getFcmContractNoGreaterThan() {
		return fcmContractNoGreaterThan;
	}
	public void setFcmContractNoGreaterThan(java.lang.String fcmContractNoGreaterThan) {
		this.fcmContractNoGreaterThan = fcmContractNoGreaterThan;
	}

	public java.lang.String getFcmContractNoEqualTo() {
		return fcmContractNoEqualTo;
	}
	public void setFcmContractNoEqualTo(java.lang.String fcmContractNoEqualTo) {
		this.fcmContractNoEqualTo = fcmContractNoEqualTo;
	}

	public java.util.List getFcmCityIdNotIn() {
		return fcmCityIdNotIn;
	}
	public void setFcmCityIdNotIn(java.util.List fcmCityIdNotIn) {
		this.fcmCityIdNotIn = fcmCityIdNotIn;
	}

	public java.lang.Long getFcmCityIdNotEqualTo() {
		return fcmCityIdNotEqualTo;
	}
	public void setFcmCityIdNotEqualTo(java.lang.Long fcmCityIdNotEqualTo) {
		this.fcmCityIdNotEqualTo = fcmCityIdNotEqualTo;
	}

	public java.lang.Long getFcmCityIdLessThanOrEqualTo() {
		return fcmCityIdLessThanOrEqualTo;
	}
	public void setFcmCityIdLessThanOrEqualTo(java.lang.Long fcmCityIdLessThanOrEqualTo) {
		this.fcmCityIdLessThanOrEqualTo = fcmCityIdLessThanOrEqualTo;
	}

	public java.lang.Long getFcmCityIdLessThan() {
		return fcmCityIdLessThan;
	}
	public void setFcmCityIdLessThan(java.lang.Long fcmCityIdLessThan) {
		this.fcmCityIdLessThan = fcmCityIdLessThan;
	}

	public java.lang.Boolean getFcmCityIdIsNull() {
		return fcmCityIdIsNull;
	}
	public void setFcmCityIdIsNull(java.lang.Boolean fcmCityIdIsNull) {
		this.fcmCityIdIsNull = fcmCityIdIsNull;
	}

	public java.lang.Boolean getFcmCityIdIsNotNull() {
		return fcmCityIdIsNotNull;
	}
	public void setFcmCityIdIsNotNull(java.lang.Boolean fcmCityIdIsNotNull) {
		this.fcmCityIdIsNotNull = fcmCityIdIsNotNull;
	}

	public java.util.List getFcmCityIdIn() {
		return fcmCityIdIn;
	}
	public void setFcmCityIdIn(java.util.List fcmCityIdIn) {
		this.fcmCityIdIn = fcmCityIdIn;
	}

	public java.lang.Long getFcmCityIdGreaterThanOrEqualTo() {
		return fcmCityIdGreaterThanOrEqualTo;
	}
	public void setFcmCityIdGreaterThanOrEqualTo(java.lang.Long fcmCityIdGreaterThanOrEqualTo) {
		this.fcmCityIdGreaterThanOrEqualTo = fcmCityIdGreaterThanOrEqualTo;
	}

	public java.lang.Long getFcmCityIdGreaterThan() {
		return fcmCityIdGreaterThan;
	}
	public void setFcmCityIdGreaterThan(java.lang.Long fcmCityIdGreaterThan) {
		this.fcmCityIdGreaterThan = fcmCityIdGreaterThan;
	}

	public java.lang.Long getFcmCityIdEqualTo() {
		return fcmCityIdEqualTo;
	}
	public void setFcmCityIdEqualTo(java.lang.Long fcmCityIdEqualTo) {
		this.fcmCityIdEqualTo = fcmCityIdEqualTo;
	}

	public java.util.List getFcmCarnumTotalNotIn() {
		return fcmCarnumTotalNotIn;
	}
	public void setFcmCarnumTotalNotIn(java.util.List fcmCarnumTotalNotIn) {
		this.fcmCarnumTotalNotIn = fcmCarnumTotalNotIn;
	}

	public java.lang.Integer getFcmCarnumTotalNotEqualTo() {
		return fcmCarnumTotalNotEqualTo;
	}
	public void setFcmCarnumTotalNotEqualTo(java.lang.Integer fcmCarnumTotalNotEqualTo) {
		this.fcmCarnumTotalNotEqualTo = fcmCarnumTotalNotEqualTo;
	}

	public java.lang.Integer getFcmCarnumTotalLessThanOrEqualTo() {
		return fcmCarnumTotalLessThanOrEqualTo;
	}
	public void setFcmCarnumTotalLessThanOrEqualTo(java.lang.Integer fcmCarnumTotalLessThanOrEqualTo) {
		this.fcmCarnumTotalLessThanOrEqualTo = fcmCarnumTotalLessThanOrEqualTo;
	}

	public java.lang.Integer getFcmCarnumTotalLessThan() {
		return fcmCarnumTotalLessThan;
	}
	public void setFcmCarnumTotalLessThan(java.lang.Integer fcmCarnumTotalLessThan) {
		this.fcmCarnumTotalLessThan = fcmCarnumTotalLessThan;
	}

	public java.lang.Boolean getFcmCarnumTotalIsNull() {
		return fcmCarnumTotalIsNull;
	}
	public void setFcmCarnumTotalIsNull(java.lang.Boolean fcmCarnumTotalIsNull) {
		this.fcmCarnumTotalIsNull = fcmCarnumTotalIsNull;
	}

	public java.lang.Boolean getFcmCarnumTotalIsNotNull() {
		return fcmCarnumTotalIsNotNull;
	}
	public void setFcmCarnumTotalIsNotNull(java.lang.Boolean fcmCarnumTotalIsNotNull) {
		this.fcmCarnumTotalIsNotNull = fcmCarnumTotalIsNotNull;
	}

	public java.util.List getFcmCarnumTotalIn() {
		return fcmCarnumTotalIn;
	}
	public void setFcmCarnumTotalIn(java.util.List fcmCarnumTotalIn) {
		this.fcmCarnumTotalIn = fcmCarnumTotalIn;
	}

	public java.lang.Integer getFcmCarnumTotalGreaterThanOrEqualTo() {
		return fcmCarnumTotalGreaterThanOrEqualTo;
	}
	public void setFcmCarnumTotalGreaterThanOrEqualTo(java.lang.Integer fcmCarnumTotalGreaterThanOrEqualTo) {
		this.fcmCarnumTotalGreaterThanOrEqualTo = fcmCarnumTotalGreaterThanOrEqualTo;
	}

	public java.lang.Integer getFcmCarnumTotalGreaterThan() {
		return fcmCarnumTotalGreaterThan;
	}
	public void setFcmCarnumTotalGreaterThan(java.lang.Integer fcmCarnumTotalGreaterThan) {
		this.fcmCarnumTotalGreaterThan = fcmCarnumTotalGreaterThan;
	}

	public java.lang.Integer getFcmCarnumTotalEqualTo() {
		return fcmCarnumTotalEqualTo;
	}
	public void setFcmCarnumTotalEqualTo(java.lang.Integer fcmCarnumTotalEqualTo) {
		this.fcmCarnumTotalEqualTo = fcmCarnumTotalEqualTo;
	}

	public java.util.List getFcmCarTypeIdNotIn() {
		return fcmCarTypeIdNotIn;
	}
	public void setFcmCarTypeIdNotIn(java.util.List fcmCarTypeIdNotIn) {
		this.fcmCarTypeIdNotIn = fcmCarTypeIdNotIn;
	}

	public java.lang.Long getFcmCarTypeIdNotEqualTo() {
		return fcmCarTypeIdNotEqualTo;
	}
	public void setFcmCarTypeIdNotEqualTo(java.lang.Long fcmCarTypeIdNotEqualTo) {
		this.fcmCarTypeIdNotEqualTo = fcmCarTypeIdNotEqualTo;
	}

	public java.lang.Long getFcmCarTypeIdLessThanOrEqualTo() {
		return fcmCarTypeIdLessThanOrEqualTo;
	}
	public void setFcmCarTypeIdLessThanOrEqualTo(java.lang.Long fcmCarTypeIdLessThanOrEqualTo) {
		this.fcmCarTypeIdLessThanOrEqualTo = fcmCarTypeIdLessThanOrEqualTo;
	}

	public java.lang.Long getFcmCarTypeIdLessThan() {
		return fcmCarTypeIdLessThan;
	}
	public void setFcmCarTypeIdLessThan(java.lang.Long fcmCarTypeIdLessThan) {
		this.fcmCarTypeIdLessThan = fcmCarTypeIdLessThan;
	}

	public java.lang.Boolean getFcmCarTypeIdIsNull() {
		return fcmCarTypeIdIsNull;
	}
	public void setFcmCarTypeIdIsNull(java.lang.Boolean fcmCarTypeIdIsNull) {
		this.fcmCarTypeIdIsNull = fcmCarTypeIdIsNull;
	}

	public java.lang.Boolean getFcmCarTypeIdIsNotNull() {
		return fcmCarTypeIdIsNotNull;
	}
	public void setFcmCarTypeIdIsNotNull(java.lang.Boolean fcmCarTypeIdIsNotNull) {
		this.fcmCarTypeIdIsNotNull = fcmCarTypeIdIsNotNull;
	}

	public java.util.List getFcmCarTypeIdIn() {
		return fcmCarTypeIdIn;
	}
	public void setFcmCarTypeIdIn(java.util.List fcmCarTypeIdIn) {
		this.fcmCarTypeIdIn = fcmCarTypeIdIn;
	}

	public java.lang.Long getFcmCarTypeIdGreaterThanOrEqualTo() {
		return fcmCarTypeIdGreaterThanOrEqualTo;
	}
	public void setFcmCarTypeIdGreaterThanOrEqualTo(java.lang.Long fcmCarTypeIdGreaterThanOrEqualTo) {
		this.fcmCarTypeIdGreaterThanOrEqualTo = fcmCarTypeIdGreaterThanOrEqualTo;
	}

	public java.lang.Long getFcmCarTypeIdGreaterThan() {
		return fcmCarTypeIdGreaterThan;
	}
	public void setFcmCarTypeIdGreaterThan(java.lang.Long fcmCarTypeIdGreaterThan) {
		this.fcmCarTypeIdGreaterThan = fcmCarTypeIdGreaterThan;
	}

	public java.lang.Long getFcmCarTypeIdEqualTo() {
		return fcmCarTypeIdEqualTo;
	}
	public void setFcmCarTypeIdEqualTo(java.lang.Long fcmCarTypeIdEqualTo) {
		this.fcmCarTypeIdEqualTo = fcmCarTypeIdEqualTo;
	}

	public java.util.List getFcmCarPurchaseNotIn() {
		return fcmCarPurchaseNotIn;
	}
	public void setFcmCarPurchaseNotIn(java.util.List fcmCarPurchaseNotIn) {
		this.fcmCarPurchaseNotIn = fcmCarPurchaseNotIn;
	}

	public java.lang.Double getFcmCarPurchaseNotEqualTo() {
		return fcmCarPurchaseNotEqualTo;
	}
	public void setFcmCarPurchaseNotEqualTo(java.lang.Double fcmCarPurchaseNotEqualTo) {
		this.fcmCarPurchaseNotEqualTo = fcmCarPurchaseNotEqualTo;
	}

	public java.lang.Double getFcmCarPurchaseLessThanOrEqualTo() {
		return fcmCarPurchaseLessThanOrEqualTo;
	}
	public void setFcmCarPurchaseLessThanOrEqualTo(java.lang.Double fcmCarPurchaseLessThanOrEqualTo) {
		this.fcmCarPurchaseLessThanOrEqualTo = fcmCarPurchaseLessThanOrEqualTo;
	}

	public java.lang.Double getFcmCarPurchaseLessThan() {
		return fcmCarPurchaseLessThan;
	}
	public void setFcmCarPurchaseLessThan(java.lang.Double fcmCarPurchaseLessThan) {
		this.fcmCarPurchaseLessThan = fcmCarPurchaseLessThan;
	}

	public java.lang.Boolean getFcmCarPurchaseIsNull() {
		return fcmCarPurchaseIsNull;
	}
	public void setFcmCarPurchaseIsNull(java.lang.Boolean fcmCarPurchaseIsNull) {
		this.fcmCarPurchaseIsNull = fcmCarPurchaseIsNull;
	}

	public java.lang.Boolean getFcmCarPurchaseIsNotNull() {
		return fcmCarPurchaseIsNotNull;
	}
	public void setFcmCarPurchaseIsNotNull(java.lang.Boolean fcmCarPurchaseIsNotNull) {
		this.fcmCarPurchaseIsNotNull = fcmCarPurchaseIsNotNull;
	}

	public java.util.List getFcmCarPurchaseIn() {
		return fcmCarPurchaseIn;
	}
	public void setFcmCarPurchaseIn(java.util.List fcmCarPurchaseIn) {
		this.fcmCarPurchaseIn = fcmCarPurchaseIn;
	}

	public java.lang.Double getFcmCarPurchaseGreaterThanOrEqualTo() {
		return fcmCarPurchaseGreaterThanOrEqualTo;
	}
	public void setFcmCarPurchaseGreaterThanOrEqualTo(java.lang.Double fcmCarPurchaseGreaterThanOrEqualTo) {
		this.fcmCarPurchaseGreaterThanOrEqualTo = fcmCarPurchaseGreaterThanOrEqualTo;
	}

	public java.lang.Double getFcmCarPurchaseGreaterThan() {
		return fcmCarPurchaseGreaterThan;
	}
	public void setFcmCarPurchaseGreaterThan(java.lang.Double fcmCarPurchaseGreaterThan) {
		this.fcmCarPurchaseGreaterThan = fcmCarPurchaseGreaterThan;
	}

	public java.lang.Double getFcmCarPurchaseEqualTo() {
		return fcmCarPurchaseEqualTo;
	}
	public void setFcmCarPurchaseEqualTo(java.lang.Double fcmCarPurchaseEqualTo) {
		this.fcmCarPurchaseEqualTo = fcmCarPurchaseEqualTo;
	}

	public java.lang.String getFcmCarPurchaseAdvanceNotLike() {
		return fcmCarPurchaseAdvanceNotLike;
	}
	public void setFcmCarPurchaseAdvanceNotLike(java.lang.String fcmCarPurchaseAdvanceNotLike) {
		this.fcmCarPurchaseAdvanceNotLike = fcmCarPurchaseAdvanceNotLike;
	}

	public java.util.List getFcmCarPurchaseAdvanceNotIn() {
		return fcmCarPurchaseAdvanceNotIn;
	}
	public void setFcmCarPurchaseAdvanceNotIn(java.util.List fcmCarPurchaseAdvanceNotIn) {
		this.fcmCarPurchaseAdvanceNotIn = fcmCarPurchaseAdvanceNotIn;
	}

	public java.lang.String getFcmCarPurchaseAdvanceNotEqualTo() {
		return fcmCarPurchaseAdvanceNotEqualTo;
	}
	public void setFcmCarPurchaseAdvanceNotEqualTo(java.lang.String fcmCarPurchaseAdvanceNotEqualTo) {
		this.fcmCarPurchaseAdvanceNotEqualTo = fcmCarPurchaseAdvanceNotEqualTo;
	}

	public java.lang.String getFcmCarPurchaseAdvanceLike() {
		return fcmCarPurchaseAdvanceLike;
	}
	public void setFcmCarPurchaseAdvanceLike(java.lang.String fcmCarPurchaseAdvanceLike) {
		this.fcmCarPurchaseAdvanceLike = fcmCarPurchaseAdvanceLike;
	}

	public java.lang.String getFcmCarPurchaseAdvanceLessThanOrEqualTo() {
		return fcmCarPurchaseAdvanceLessThanOrEqualTo;
	}
	public void setFcmCarPurchaseAdvanceLessThanOrEqualTo(java.lang.String fcmCarPurchaseAdvanceLessThanOrEqualTo) {
		this.fcmCarPurchaseAdvanceLessThanOrEqualTo = fcmCarPurchaseAdvanceLessThanOrEqualTo;
	}

	public java.lang.String getFcmCarPurchaseAdvanceLessThan() {
		return fcmCarPurchaseAdvanceLessThan;
	}
	public void setFcmCarPurchaseAdvanceLessThan(java.lang.String fcmCarPurchaseAdvanceLessThan) {
		this.fcmCarPurchaseAdvanceLessThan = fcmCarPurchaseAdvanceLessThan;
	}

	public java.lang.Boolean getFcmCarPurchaseAdvanceIsNull() {
		return fcmCarPurchaseAdvanceIsNull;
	}
	public void setFcmCarPurchaseAdvanceIsNull(java.lang.Boolean fcmCarPurchaseAdvanceIsNull) {
		this.fcmCarPurchaseAdvanceIsNull = fcmCarPurchaseAdvanceIsNull;
	}

	public java.lang.Boolean getFcmCarPurchaseAdvanceIsNotNull() {
		return fcmCarPurchaseAdvanceIsNotNull;
	}
	public void setFcmCarPurchaseAdvanceIsNotNull(java.lang.Boolean fcmCarPurchaseAdvanceIsNotNull) {
		this.fcmCarPurchaseAdvanceIsNotNull = fcmCarPurchaseAdvanceIsNotNull;
	}

	public java.util.List getFcmCarPurchaseAdvanceIn() {
		return fcmCarPurchaseAdvanceIn;
	}
	public void setFcmCarPurchaseAdvanceIn(java.util.List fcmCarPurchaseAdvanceIn) {
		this.fcmCarPurchaseAdvanceIn = fcmCarPurchaseAdvanceIn;
	}

	public java.lang.String getFcmCarPurchaseAdvanceGreaterThanOrEqualTo() {
		return fcmCarPurchaseAdvanceGreaterThanOrEqualTo;
	}
	public void setFcmCarPurchaseAdvanceGreaterThanOrEqualTo(java.lang.String fcmCarPurchaseAdvanceGreaterThanOrEqualTo) {
		this.fcmCarPurchaseAdvanceGreaterThanOrEqualTo = fcmCarPurchaseAdvanceGreaterThanOrEqualTo;
	}

	public java.lang.String getFcmCarPurchaseAdvanceGreaterThan() {
		return fcmCarPurchaseAdvanceGreaterThan;
	}
	public void setFcmCarPurchaseAdvanceGreaterThan(java.lang.String fcmCarPurchaseAdvanceGreaterThan) {
		this.fcmCarPurchaseAdvanceGreaterThan = fcmCarPurchaseAdvanceGreaterThan;
	}

	public java.lang.String getFcmCarPurchaseAdvanceEqualTo() {
		return fcmCarPurchaseAdvanceEqualTo;
	}
	public void setFcmCarPurchaseAdvanceEqualTo(java.lang.String fcmCarPurchaseAdvanceEqualTo) {
		this.fcmCarPurchaseAdvanceEqualTo = fcmCarPurchaseAdvanceEqualTo;
	}

	public java.lang.String getFcmCarNatureNotLike() {
		return fcmCarNatureNotLike;
	}
	public void setFcmCarNatureNotLike(java.lang.String fcmCarNatureNotLike) {
		this.fcmCarNatureNotLike = fcmCarNatureNotLike;
	}

	public java.util.List getFcmCarNatureNotIn() {
		return fcmCarNatureNotIn;
	}
	public void setFcmCarNatureNotIn(java.util.List fcmCarNatureNotIn) {
		this.fcmCarNatureNotIn = fcmCarNatureNotIn;
	}

	public java.lang.String getFcmCarNatureNotEqualTo() {
		return fcmCarNatureNotEqualTo;
	}
	public void setFcmCarNatureNotEqualTo(java.lang.String fcmCarNatureNotEqualTo) {
		this.fcmCarNatureNotEqualTo = fcmCarNatureNotEqualTo;
	}

	public java.lang.String getFcmCarNatureLike() {
		return fcmCarNatureLike;
	}
	public void setFcmCarNatureLike(java.lang.String fcmCarNatureLike) {
		this.fcmCarNatureLike = fcmCarNatureLike;
	}

	public java.lang.String getFcmCarNatureLessThanOrEqualTo() {
		return fcmCarNatureLessThanOrEqualTo;
	}
	public void setFcmCarNatureLessThanOrEqualTo(java.lang.String fcmCarNatureLessThanOrEqualTo) {
		this.fcmCarNatureLessThanOrEqualTo = fcmCarNatureLessThanOrEqualTo;
	}

	public java.lang.String getFcmCarNatureLessThan() {
		return fcmCarNatureLessThan;
	}
	public void setFcmCarNatureLessThan(java.lang.String fcmCarNatureLessThan) {
		this.fcmCarNatureLessThan = fcmCarNatureLessThan;
	}

	public java.lang.Boolean getFcmCarNatureIsNull() {
		return fcmCarNatureIsNull;
	}
	public void setFcmCarNatureIsNull(java.lang.Boolean fcmCarNatureIsNull) {
		this.fcmCarNatureIsNull = fcmCarNatureIsNull;
	}

	public java.lang.Boolean getFcmCarNatureIsNotNull() {
		return fcmCarNatureIsNotNull;
	}
	public void setFcmCarNatureIsNotNull(java.lang.Boolean fcmCarNatureIsNotNull) {
		this.fcmCarNatureIsNotNull = fcmCarNatureIsNotNull;
	}

	public java.util.List getFcmCarNatureIn() {
		return fcmCarNatureIn;
	}
	public void setFcmCarNatureIn(java.util.List fcmCarNatureIn) {
		this.fcmCarNatureIn = fcmCarNatureIn;
	}

	public java.lang.String getFcmCarNatureGreaterThanOrEqualTo() {
		return fcmCarNatureGreaterThanOrEqualTo;
	}
	public void setFcmCarNatureGreaterThanOrEqualTo(java.lang.String fcmCarNatureGreaterThanOrEqualTo) {
		this.fcmCarNatureGreaterThanOrEqualTo = fcmCarNatureGreaterThanOrEqualTo;
	}

	public java.lang.String getFcmCarNatureGreaterThan() {
		return fcmCarNatureGreaterThan;
	}
	public void setFcmCarNatureGreaterThan(java.lang.String fcmCarNatureGreaterThan) {
		this.fcmCarNatureGreaterThan = fcmCarNatureGreaterThan;
	}

	public java.lang.String getFcmCarNatureEqualTo() {
		return fcmCarNatureEqualTo;
	}
	public void setFcmCarNatureEqualTo(java.lang.String fcmCarNatureEqualTo) {
		this.fcmCarNatureEqualTo = fcmCarNatureEqualTo;
	}

	public java.util.List getFcmBoldRentNotIn() {
		return fcmBoldRentNotIn;
	}
	public void setFcmBoldRentNotIn(java.util.List fcmBoldRentNotIn) {
		this.fcmBoldRentNotIn = fcmBoldRentNotIn;
	}

	public java.lang.Double getFcmBoldRentNotEqualTo() {
		return fcmBoldRentNotEqualTo;
	}
	public void setFcmBoldRentNotEqualTo(java.lang.Double fcmBoldRentNotEqualTo) {
		this.fcmBoldRentNotEqualTo = fcmBoldRentNotEqualTo;
	}

	public java.lang.Double getFcmBoldRentLessThanOrEqualTo() {
		return fcmBoldRentLessThanOrEqualTo;
	}
	public void setFcmBoldRentLessThanOrEqualTo(java.lang.Double fcmBoldRentLessThanOrEqualTo) {
		this.fcmBoldRentLessThanOrEqualTo = fcmBoldRentLessThanOrEqualTo;
	}

	public java.lang.Double getFcmBoldRentLessThan() {
		return fcmBoldRentLessThan;
	}
	public void setFcmBoldRentLessThan(java.lang.Double fcmBoldRentLessThan) {
		this.fcmBoldRentLessThan = fcmBoldRentLessThan;
	}

	public java.lang.Boolean getFcmBoldRentIsNull() {
		return fcmBoldRentIsNull;
	}
	public void setFcmBoldRentIsNull(java.lang.Boolean fcmBoldRentIsNull) {
		this.fcmBoldRentIsNull = fcmBoldRentIsNull;
	}

	public java.lang.Boolean getFcmBoldRentIsNotNull() {
		return fcmBoldRentIsNotNull;
	}
	public void setFcmBoldRentIsNotNull(java.lang.Boolean fcmBoldRentIsNotNull) {
		this.fcmBoldRentIsNotNull = fcmBoldRentIsNotNull;
	}

	public java.util.List getFcmBoldRentIn() {
		return fcmBoldRentIn;
	}
	public void setFcmBoldRentIn(java.util.List fcmBoldRentIn) {
		this.fcmBoldRentIn = fcmBoldRentIn;
	}

	public java.lang.Double getFcmBoldRentGreaterThanOrEqualTo() {
		return fcmBoldRentGreaterThanOrEqualTo;
	}
	public void setFcmBoldRentGreaterThanOrEqualTo(java.lang.Double fcmBoldRentGreaterThanOrEqualTo) {
		this.fcmBoldRentGreaterThanOrEqualTo = fcmBoldRentGreaterThanOrEqualTo;
	}

	public java.lang.Double getFcmBoldRentGreaterThan() {
		return fcmBoldRentGreaterThan;
	}
	public void setFcmBoldRentGreaterThan(java.lang.Double fcmBoldRentGreaterThan) {
		this.fcmBoldRentGreaterThan = fcmBoldRentGreaterThan;
	}

	public java.lang.Double getFcmBoldRentEqualTo() {
		return fcmBoldRentEqualTo;
	}
	public void setFcmBoldRentEqualTo(java.lang.Double fcmBoldRentEqualTo) {
		this.fcmBoldRentEqualTo = fcmBoldRentEqualTo;
	}

	public java.util.List getFcmBillGenerateTypeNotIn() {
		return fcmBillGenerateTypeNotIn;
	}
	public void setFcmBillGenerateTypeNotIn(java.util.List fcmBillGenerateTypeNotIn) {
		this.fcmBillGenerateTypeNotIn = fcmBillGenerateTypeNotIn;
	}

	public java.lang.Integer getFcmBillGenerateTypeNotEqualTo() {
		return fcmBillGenerateTypeNotEqualTo;
	}
	public void setFcmBillGenerateTypeNotEqualTo(java.lang.Integer fcmBillGenerateTypeNotEqualTo) {
		this.fcmBillGenerateTypeNotEqualTo = fcmBillGenerateTypeNotEqualTo;
	}

	public java.lang.Integer getFcmBillGenerateTypeLessThanOrEqualTo() {
		return fcmBillGenerateTypeLessThanOrEqualTo;
	}
	public void setFcmBillGenerateTypeLessThanOrEqualTo(java.lang.Integer fcmBillGenerateTypeLessThanOrEqualTo) {
		this.fcmBillGenerateTypeLessThanOrEqualTo = fcmBillGenerateTypeLessThanOrEqualTo;
	}

	public java.lang.Integer getFcmBillGenerateTypeLessThan() {
		return fcmBillGenerateTypeLessThan;
	}
	public void setFcmBillGenerateTypeLessThan(java.lang.Integer fcmBillGenerateTypeLessThan) {
		this.fcmBillGenerateTypeLessThan = fcmBillGenerateTypeLessThan;
	}

	public java.lang.Boolean getFcmBillGenerateTypeIsNull() {
		return fcmBillGenerateTypeIsNull;
	}
	public void setFcmBillGenerateTypeIsNull(java.lang.Boolean fcmBillGenerateTypeIsNull) {
		this.fcmBillGenerateTypeIsNull = fcmBillGenerateTypeIsNull;
	}

	public java.lang.Boolean getFcmBillGenerateTypeIsNotNull() {
		return fcmBillGenerateTypeIsNotNull;
	}
	public void setFcmBillGenerateTypeIsNotNull(java.lang.Boolean fcmBillGenerateTypeIsNotNull) {
		this.fcmBillGenerateTypeIsNotNull = fcmBillGenerateTypeIsNotNull;
	}

	public java.util.List getFcmBillGenerateTypeIn() {
		return fcmBillGenerateTypeIn;
	}
	public void setFcmBillGenerateTypeIn(java.util.List fcmBillGenerateTypeIn) {
		this.fcmBillGenerateTypeIn = fcmBillGenerateTypeIn;
	}

	public java.lang.Integer getFcmBillGenerateTypeGreaterThanOrEqualTo() {
		return fcmBillGenerateTypeGreaterThanOrEqualTo;
	}
	public void setFcmBillGenerateTypeGreaterThanOrEqualTo(java.lang.Integer fcmBillGenerateTypeGreaterThanOrEqualTo) {
		this.fcmBillGenerateTypeGreaterThanOrEqualTo = fcmBillGenerateTypeGreaterThanOrEqualTo;
	}

	public java.lang.Integer getFcmBillGenerateTypeGreaterThan() {
		return fcmBillGenerateTypeGreaterThan;
	}
	public void setFcmBillGenerateTypeGreaterThan(java.lang.Integer fcmBillGenerateTypeGreaterThan) {
		this.fcmBillGenerateTypeGreaterThan = fcmBillGenerateTypeGreaterThan;
	}

	public java.lang.Integer getFcmBillGenerateTypeEqualTo() {
		return fcmBillGenerateTypeEqualTo;
	}
	public void setFcmBillGenerateTypeEqualTo(java.lang.Integer fcmBillGenerateTypeEqualTo) {
		this.fcmBillGenerateTypeEqualTo = fcmBillGenerateTypeEqualTo;
	}

	public java.util.List getFcmBillGenerateIntervalNotIn() {
		return fcmBillGenerateIntervalNotIn;
	}
	public void setFcmBillGenerateIntervalNotIn(java.util.List fcmBillGenerateIntervalNotIn) {
		this.fcmBillGenerateIntervalNotIn = fcmBillGenerateIntervalNotIn;
	}

	public java.lang.Integer getFcmBillGenerateIntervalNotEqualTo() {
		return fcmBillGenerateIntervalNotEqualTo;
	}
	public void setFcmBillGenerateIntervalNotEqualTo(java.lang.Integer fcmBillGenerateIntervalNotEqualTo) {
		this.fcmBillGenerateIntervalNotEqualTo = fcmBillGenerateIntervalNotEqualTo;
	}

	public java.lang.Integer getFcmBillGenerateIntervalLessThanOrEqualTo() {
		return fcmBillGenerateIntervalLessThanOrEqualTo;
	}
	public void setFcmBillGenerateIntervalLessThanOrEqualTo(java.lang.Integer fcmBillGenerateIntervalLessThanOrEqualTo) {
		this.fcmBillGenerateIntervalLessThanOrEqualTo = fcmBillGenerateIntervalLessThanOrEqualTo;
	}

	public java.lang.Integer getFcmBillGenerateIntervalLessThan() {
		return fcmBillGenerateIntervalLessThan;
	}
	public void setFcmBillGenerateIntervalLessThan(java.lang.Integer fcmBillGenerateIntervalLessThan) {
		this.fcmBillGenerateIntervalLessThan = fcmBillGenerateIntervalLessThan;
	}

	public java.lang.Boolean getFcmBillGenerateIntervalIsNull() {
		return fcmBillGenerateIntervalIsNull;
	}
	public void setFcmBillGenerateIntervalIsNull(java.lang.Boolean fcmBillGenerateIntervalIsNull) {
		this.fcmBillGenerateIntervalIsNull = fcmBillGenerateIntervalIsNull;
	}

	public java.lang.Boolean getFcmBillGenerateIntervalIsNotNull() {
		return fcmBillGenerateIntervalIsNotNull;
	}
	public void setFcmBillGenerateIntervalIsNotNull(java.lang.Boolean fcmBillGenerateIntervalIsNotNull) {
		this.fcmBillGenerateIntervalIsNotNull = fcmBillGenerateIntervalIsNotNull;
	}

	public java.util.List getFcmBillGenerateIntervalIn() {
		return fcmBillGenerateIntervalIn;
	}
	public void setFcmBillGenerateIntervalIn(java.util.List fcmBillGenerateIntervalIn) {
		this.fcmBillGenerateIntervalIn = fcmBillGenerateIntervalIn;
	}

	public java.lang.Integer getFcmBillGenerateIntervalGreaterThanOrEqualTo() {
		return fcmBillGenerateIntervalGreaterThanOrEqualTo;
	}
	public void setFcmBillGenerateIntervalGreaterThanOrEqualTo(java.lang.Integer fcmBillGenerateIntervalGreaterThanOrEqualTo) {
		this.fcmBillGenerateIntervalGreaterThanOrEqualTo = fcmBillGenerateIntervalGreaterThanOrEqualTo;
	}

	public java.lang.Integer getFcmBillGenerateIntervalGreaterThan() {
		return fcmBillGenerateIntervalGreaterThan;
	}
	public void setFcmBillGenerateIntervalGreaterThan(java.lang.Integer fcmBillGenerateIntervalGreaterThan) {
		this.fcmBillGenerateIntervalGreaterThan = fcmBillGenerateIntervalGreaterThan;
	}

	public java.lang.Integer getFcmBillGenerateIntervalEqualTo() {
		return fcmBillGenerateIntervalEqualTo;
	}
	public void setFcmBillGenerateIntervalEqualTo(java.lang.Integer fcmBillGenerateIntervalEqualTo) {
		this.fcmBillGenerateIntervalEqualTo = fcmBillGenerateIntervalEqualTo;
	}

	public java.util.List getFcmBillCatoffTypeNotIn() {
		return fcmBillCatoffTypeNotIn;
	}
	public void setFcmBillCatoffTypeNotIn(java.util.List fcmBillCatoffTypeNotIn) {
		this.fcmBillCatoffTypeNotIn = fcmBillCatoffTypeNotIn;
	}

	public java.lang.Integer getFcmBillCatoffTypeNotEqualTo() {
		return fcmBillCatoffTypeNotEqualTo;
	}
	public void setFcmBillCatoffTypeNotEqualTo(java.lang.Integer fcmBillCatoffTypeNotEqualTo) {
		this.fcmBillCatoffTypeNotEqualTo = fcmBillCatoffTypeNotEqualTo;
	}

	public java.lang.Integer getFcmBillCatoffTypeLessThanOrEqualTo() {
		return fcmBillCatoffTypeLessThanOrEqualTo;
	}
	public void setFcmBillCatoffTypeLessThanOrEqualTo(java.lang.Integer fcmBillCatoffTypeLessThanOrEqualTo) {
		this.fcmBillCatoffTypeLessThanOrEqualTo = fcmBillCatoffTypeLessThanOrEqualTo;
	}

	public java.lang.Integer getFcmBillCatoffTypeLessThan() {
		return fcmBillCatoffTypeLessThan;
	}
	public void setFcmBillCatoffTypeLessThan(java.lang.Integer fcmBillCatoffTypeLessThan) {
		this.fcmBillCatoffTypeLessThan = fcmBillCatoffTypeLessThan;
	}

	public java.lang.Boolean getFcmBillCatoffTypeIsNull() {
		return fcmBillCatoffTypeIsNull;
	}
	public void setFcmBillCatoffTypeIsNull(java.lang.Boolean fcmBillCatoffTypeIsNull) {
		this.fcmBillCatoffTypeIsNull = fcmBillCatoffTypeIsNull;
	}

	public java.lang.Boolean getFcmBillCatoffTypeIsNotNull() {
		return fcmBillCatoffTypeIsNotNull;
	}
	public void setFcmBillCatoffTypeIsNotNull(java.lang.Boolean fcmBillCatoffTypeIsNotNull) {
		this.fcmBillCatoffTypeIsNotNull = fcmBillCatoffTypeIsNotNull;
	}

	public java.util.List getFcmBillCatoffTypeIn() {
		return fcmBillCatoffTypeIn;
	}
	public void setFcmBillCatoffTypeIn(java.util.List fcmBillCatoffTypeIn) {
		this.fcmBillCatoffTypeIn = fcmBillCatoffTypeIn;
	}

	public java.lang.Integer getFcmBillCatoffTypeGreaterThanOrEqualTo() {
		return fcmBillCatoffTypeGreaterThanOrEqualTo;
	}
	public void setFcmBillCatoffTypeGreaterThanOrEqualTo(java.lang.Integer fcmBillCatoffTypeGreaterThanOrEqualTo) {
		this.fcmBillCatoffTypeGreaterThanOrEqualTo = fcmBillCatoffTypeGreaterThanOrEqualTo;
	}

	public java.lang.Integer getFcmBillCatoffTypeGreaterThan() {
		return fcmBillCatoffTypeGreaterThan;
	}
	public void setFcmBillCatoffTypeGreaterThan(java.lang.Integer fcmBillCatoffTypeGreaterThan) {
		this.fcmBillCatoffTypeGreaterThan = fcmBillCatoffTypeGreaterThan;
	}

	public java.lang.Integer getFcmBillCatoffTypeEqualTo() {
		return fcmBillCatoffTypeEqualTo;
	}
	public void setFcmBillCatoffTypeEqualTo(java.lang.Integer fcmBillCatoffTypeEqualTo) {
		this.fcmBillCatoffTypeEqualTo = fcmBillCatoffTypeEqualTo;
	}

	public java.util.List getFcmBillCatoffIntervalNotIn() {
		return fcmBillCatoffIntervalNotIn;
	}
	public void setFcmBillCatoffIntervalNotIn(java.util.List fcmBillCatoffIntervalNotIn) {
		this.fcmBillCatoffIntervalNotIn = fcmBillCatoffIntervalNotIn;
	}

	public java.lang.Integer getFcmBillCatoffIntervalNotEqualTo() {
		return fcmBillCatoffIntervalNotEqualTo;
	}
	public void setFcmBillCatoffIntervalNotEqualTo(java.lang.Integer fcmBillCatoffIntervalNotEqualTo) {
		this.fcmBillCatoffIntervalNotEqualTo = fcmBillCatoffIntervalNotEqualTo;
	}

	public java.lang.Integer getFcmBillCatoffIntervalLessThanOrEqualTo() {
		return fcmBillCatoffIntervalLessThanOrEqualTo;
	}
	public void setFcmBillCatoffIntervalLessThanOrEqualTo(java.lang.Integer fcmBillCatoffIntervalLessThanOrEqualTo) {
		this.fcmBillCatoffIntervalLessThanOrEqualTo = fcmBillCatoffIntervalLessThanOrEqualTo;
	}

	public java.lang.Integer getFcmBillCatoffIntervalLessThan() {
		return fcmBillCatoffIntervalLessThan;
	}
	public void setFcmBillCatoffIntervalLessThan(java.lang.Integer fcmBillCatoffIntervalLessThan) {
		this.fcmBillCatoffIntervalLessThan = fcmBillCatoffIntervalLessThan;
	}

	public java.lang.Boolean getFcmBillCatoffIntervalIsNull() {
		return fcmBillCatoffIntervalIsNull;
	}
	public void setFcmBillCatoffIntervalIsNull(java.lang.Boolean fcmBillCatoffIntervalIsNull) {
		this.fcmBillCatoffIntervalIsNull = fcmBillCatoffIntervalIsNull;
	}

	public java.lang.Boolean getFcmBillCatoffIntervalIsNotNull() {
		return fcmBillCatoffIntervalIsNotNull;
	}
	public void setFcmBillCatoffIntervalIsNotNull(java.lang.Boolean fcmBillCatoffIntervalIsNotNull) {
		this.fcmBillCatoffIntervalIsNotNull = fcmBillCatoffIntervalIsNotNull;
	}

	public java.util.List getFcmBillCatoffIntervalIn() {
		return fcmBillCatoffIntervalIn;
	}
	public void setFcmBillCatoffIntervalIn(java.util.List fcmBillCatoffIntervalIn) {
		this.fcmBillCatoffIntervalIn = fcmBillCatoffIntervalIn;
	}

	public java.lang.Integer getFcmBillCatoffIntervalGreaterThanOrEqualTo() {
		return fcmBillCatoffIntervalGreaterThanOrEqualTo;
	}
	public void setFcmBillCatoffIntervalGreaterThanOrEqualTo(java.lang.Integer fcmBillCatoffIntervalGreaterThanOrEqualTo) {
		this.fcmBillCatoffIntervalGreaterThanOrEqualTo = fcmBillCatoffIntervalGreaterThanOrEqualTo;
	}

	public java.lang.Integer getFcmBillCatoffIntervalGreaterThan() {
		return fcmBillCatoffIntervalGreaterThan;
	}
	public void setFcmBillCatoffIntervalGreaterThan(java.lang.Integer fcmBillCatoffIntervalGreaterThan) {
		this.fcmBillCatoffIntervalGreaterThan = fcmBillCatoffIntervalGreaterThan;
	}

	public java.lang.Integer getFcmBillCatoffIntervalEqualTo() {
		return fcmBillCatoffIntervalEqualTo;
	}
	public void setFcmBillCatoffIntervalEqualTo(java.lang.Integer fcmBillCatoffIntervalEqualTo) {
		this.fcmBillCatoffIntervalEqualTo = fcmBillCatoffIntervalEqualTo;
	}

	public java.lang.String getFcmAssociateContractNoNotLike() {
		return fcmAssociateContractNoNotLike;
	}
	public void setFcmAssociateContractNoNotLike(java.lang.String fcmAssociateContractNoNotLike) {
		this.fcmAssociateContractNoNotLike = fcmAssociateContractNoNotLike;
	}

	public java.util.List getFcmAssociateContractNoNotIn() {
		return fcmAssociateContractNoNotIn;
	}
	public void setFcmAssociateContractNoNotIn(java.util.List fcmAssociateContractNoNotIn) {
		this.fcmAssociateContractNoNotIn = fcmAssociateContractNoNotIn;
	}

	public java.lang.String getFcmAssociateContractNoNotEqualTo() {
		return fcmAssociateContractNoNotEqualTo;
	}
	public void setFcmAssociateContractNoNotEqualTo(java.lang.String fcmAssociateContractNoNotEqualTo) {
		this.fcmAssociateContractNoNotEqualTo = fcmAssociateContractNoNotEqualTo;
	}

	public java.lang.String getFcmAssociateContractNoLike() {
		return fcmAssociateContractNoLike;
	}
	public void setFcmAssociateContractNoLike(java.lang.String fcmAssociateContractNoLike) {
		this.fcmAssociateContractNoLike = fcmAssociateContractNoLike;
	}

	public java.lang.String getFcmAssociateContractNoLessThanOrEqualTo() {
		return fcmAssociateContractNoLessThanOrEqualTo;
	}
	public void setFcmAssociateContractNoLessThanOrEqualTo(java.lang.String fcmAssociateContractNoLessThanOrEqualTo) {
		this.fcmAssociateContractNoLessThanOrEqualTo = fcmAssociateContractNoLessThanOrEqualTo;
	}

	public java.lang.String getFcmAssociateContractNoLessThan() {
		return fcmAssociateContractNoLessThan;
	}
	public void setFcmAssociateContractNoLessThan(java.lang.String fcmAssociateContractNoLessThan) {
		this.fcmAssociateContractNoLessThan = fcmAssociateContractNoLessThan;
	}

	public java.lang.Boolean getFcmAssociateContractNoIsNull() {
		return fcmAssociateContractNoIsNull;
	}
	public void setFcmAssociateContractNoIsNull(java.lang.Boolean fcmAssociateContractNoIsNull) {
		this.fcmAssociateContractNoIsNull = fcmAssociateContractNoIsNull;
	}

	public java.lang.Boolean getFcmAssociateContractNoIsNotNull() {
		return fcmAssociateContractNoIsNotNull;
	}
	public void setFcmAssociateContractNoIsNotNull(java.lang.Boolean fcmAssociateContractNoIsNotNull) {
		this.fcmAssociateContractNoIsNotNull = fcmAssociateContractNoIsNotNull;
	}

	public java.util.List getFcmAssociateContractNoIn() {
		return fcmAssociateContractNoIn;
	}
	public void setFcmAssociateContractNoIn(java.util.List fcmAssociateContractNoIn) {
		this.fcmAssociateContractNoIn = fcmAssociateContractNoIn;
	}

	public java.lang.String getFcmAssociateContractNoGreaterThanOrEqualTo() {
		return fcmAssociateContractNoGreaterThanOrEqualTo;
	}
	public void setFcmAssociateContractNoGreaterThanOrEqualTo(java.lang.String fcmAssociateContractNoGreaterThanOrEqualTo) {
		this.fcmAssociateContractNoGreaterThanOrEqualTo = fcmAssociateContractNoGreaterThanOrEqualTo;
	}

	public java.lang.String getFcmAssociateContractNoGreaterThan() {
		return fcmAssociateContractNoGreaterThan;
	}
	public void setFcmAssociateContractNoGreaterThan(java.lang.String fcmAssociateContractNoGreaterThan) {
		this.fcmAssociateContractNoGreaterThan = fcmAssociateContractNoGreaterThan;
	}

	public java.lang.String getFcmAssociateContractNoEqualTo() {
		return fcmAssociateContractNoEqualTo;
	}
	public void setFcmAssociateContractNoEqualTo(java.lang.String fcmAssociateContractNoEqualTo) {
		this.fcmAssociateContractNoEqualTo = fcmAssociateContractNoEqualTo;
	}

	public java.util.List getFcmAssociateContractIdNotIn() {
		return fcmAssociateContractIdNotIn;
	}
	public void setFcmAssociateContractIdNotIn(java.util.List fcmAssociateContractIdNotIn) {
		this.fcmAssociateContractIdNotIn = fcmAssociateContractIdNotIn;
	}

	public java.lang.Long getFcmAssociateContractIdNotEqualTo() {
		return fcmAssociateContractIdNotEqualTo;
	}
	public void setFcmAssociateContractIdNotEqualTo(java.lang.Long fcmAssociateContractIdNotEqualTo) {
		this.fcmAssociateContractIdNotEqualTo = fcmAssociateContractIdNotEqualTo;
	}

	public java.lang.Long getFcmAssociateContractIdLessThanOrEqualTo() {
		return fcmAssociateContractIdLessThanOrEqualTo;
	}
	public void setFcmAssociateContractIdLessThanOrEqualTo(java.lang.Long fcmAssociateContractIdLessThanOrEqualTo) {
		this.fcmAssociateContractIdLessThanOrEqualTo = fcmAssociateContractIdLessThanOrEqualTo;
	}

	public java.lang.Long getFcmAssociateContractIdLessThan() {
		return fcmAssociateContractIdLessThan;
	}
	public void setFcmAssociateContractIdLessThan(java.lang.Long fcmAssociateContractIdLessThan) {
		this.fcmAssociateContractIdLessThan = fcmAssociateContractIdLessThan;
	}

	public java.lang.Boolean getFcmAssociateContractIdIsNull() {
		return fcmAssociateContractIdIsNull;
	}
	public void setFcmAssociateContractIdIsNull(java.lang.Boolean fcmAssociateContractIdIsNull) {
		this.fcmAssociateContractIdIsNull = fcmAssociateContractIdIsNull;
	}

	public java.lang.Boolean getFcmAssociateContractIdIsNotNull() {
		return fcmAssociateContractIdIsNotNull;
	}
	public void setFcmAssociateContractIdIsNotNull(java.lang.Boolean fcmAssociateContractIdIsNotNull) {
		this.fcmAssociateContractIdIsNotNull = fcmAssociateContractIdIsNotNull;
	}

	public java.util.List getFcmAssociateContractIdIn() {
		return fcmAssociateContractIdIn;
	}
	public void setFcmAssociateContractIdIn(java.util.List fcmAssociateContractIdIn) {
		this.fcmAssociateContractIdIn = fcmAssociateContractIdIn;
	}

	public java.lang.Long getFcmAssociateContractIdGreaterThanOrEqualTo() {
		return fcmAssociateContractIdGreaterThanOrEqualTo;
	}
	public void setFcmAssociateContractIdGreaterThanOrEqualTo(java.lang.Long fcmAssociateContractIdGreaterThanOrEqualTo) {
		this.fcmAssociateContractIdGreaterThanOrEqualTo = fcmAssociateContractIdGreaterThanOrEqualTo;
	}

	public java.lang.Long getFcmAssociateContractIdGreaterThan() {
		return fcmAssociateContractIdGreaterThan;
	}
	public void setFcmAssociateContractIdGreaterThan(java.lang.Long fcmAssociateContractIdGreaterThan) {
		this.fcmAssociateContractIdGreaterThan = fcmAssociateContractIdGreaterThan;
	}

	public java.lang.Long getFcmAssociateContractIdEqualTo() {
		return fcmAssociateContractIdEqualTo;
	}
	public void setFcmAssociateContractIdEqualTo(java.lang.Long fcmAssociateContractIdEqualTo) {
		this.fcmAssociateContractIdEqualTo = fcmAssociateContractIdEqualTo;
	}

	public java.util.List getDrNotIn() {
		return drNotIn;
	}
	public void setDrNotIn(java.util.List drNotIn) {
		this.drNotIn = drNotIn;
	}

	public java.lang.Integer getDrNotEqualTo() {
		return drNotEqualTo;
	}
	public void setDrNotEqualTo(java.lang.Integer drNotEqualTo) {
		this.drNotEqualTo = drNotEqualTo;
	}

	public java.lang.Integer getDrLessThanOrEqualTo() {
		return drLessThanOrEqualTo;
	}
	public void setDrLessThanOrEqualTo(java.lang.Integer drLessThanOrEqualTo) {
		this.drLessThanOrEqualTo = drLessThanOrEqualTo;
	}

	public java.lang.Integer getDrLessThan() {
		return drLessThan;
	}
	public void setDrLessThan(java.lang.Integer drLessThan) {
		this.drLessThan = drLessThan;
	}

	public java.lang.Boolean getDrIsNull() {
		return drIsNull;
	}
	public void setDrIsNull(java.lang.Boolean drIsNull) {
		this.drIsNull = drIsNull;
	}

	public java.lang.Boolean getDrIsNotNull() {
		return drIsNotNull;
	}
	public void setDrIsNotNull(java.lang.Boolean drIsNotNull) {
		this.drIsNotNull = drIsNotNull;
	}

	public java.util.List getDrIn() {
		return drIn;
	}
	public void setDrIn(java.util.List drIn) {
		this.drIn = drIn;
	}

	public java.lang.Integer getDrGreaterThanOrEqualTo() {
		return drGreaterThanOrEqualTo;
	}
	public void setDrGreaterThanOrEqualTo(java.lang.Integer drGreaterThanOrEqualTo) {
		this.drGreaterThanOrEqualTo = drGreaterThanOrEqualTo;
	}

	public java.lang.Integer getDrGreaterThan() {
		return drGreaterThan;
	}
	public void setDrGreaterThan(java.lang.Integer drGreaterThan) {
		this.drGreaterThan = drGreaterThan;
	}

	public java.lang.Integer getDrEqualTo() {
		return drEqualTo;
	}
	public void setDrEqualTo(java.lang.Integer drEqualTo) {
		this.drEqualTo = drEqualTo;
	}

	public java.lang.String getCreateuserNotLike() {
		return createuserNotLike;
	}
	public void setCreateuserNotLike(java.lang.String createuserNotLike) {
		this.createuserNotLike = createuserNotLike;
	}

	public java.util.List getCreateuserNotIn() {
		return createuserNotIn;
	}
	public void setCreateuserNotIn(java.util.List createuserNotIn) {
		this.createuserNotIn = createuserNotIn;
	}

	public java.lang.String getCreateuserNotEqualTo() {
		return createuserNotEqualTo;
	}
	public void setCreateuserNotEqualTo(java.lang.String createuserNotEqualTo) {
		this.createuserNotEqualTo = createuserNotEqualTo;
	}

	public java.lang.String getCreateuserLike() {
		return createuserLike;
	}
	public void setCreateuserLike(java.lang.String createuserLike) {
		this.createuserLike = createuserLike;
	}

	public java.lang.String getCreateuserLessThanOrEqualTo() {
		return createuserLessThanOrEqualTo;
	}
	public void setCreateuserLessThanOrEqualTo(java.lang.String createuserLessThanOrEqualTo) {
		this.createuserLessThanOrEqualTo = createuserLessThanOrEqualTo;
	}

	public java.lang.String getCreateuserLessThan() {
		return createuserLessThan;
	}
	public void setCreateuserLessThan(java.lang.String createuserLessThan) {
		this.createuserLessThan = createuserLessThan;
	}

	public java.lang.Boolean getCreateuserIsNull() {
		return createuserIsNull;
	}
	public void setCreateuserIsNull(java.lang.Boolean createuserIsNull) {
		this.createuserIsNull = createuserIsNull;
	}

	public java.lang.Boolean getCreateuserIsNotNull() {
		return createuserIsNotNull;
	}
	public void setCreateuserIsNotNull(java.lang.Boolean createuserIsNotNull) {
		this.createuserIsNotNull = createuserIsNotNull;
	}

	public java.util.List getCreateuserIn() {
		return createuserIn;
	}
	public void setCreateuserIn(java.util.List createuserIn) {
		this.createuserIn = createuserIn;
	}

	public java.lang.String getCreateuserGreaterThanOrEqualTo() {
		return createuserGreaterThanOrEqualTo;
	}
	public void setCreateuserGreaterThanOrEqualTo(java.lang.String createuserGreaterThanOrEqualTo) {
		this.createuserGreaterThanOrEqualTo = createuserGreaterThanOrEqualTo;
	}

	public java.lang.String getCreateuserGreaterThan() {
		return createuserGreaterThan;
	}
	public void setCreateuserGreaterThan(java.lang.String createuserGreaterThan) {
		this.createuserGreaterThan = createuserGreaterThan;
	}

	public java.lang.String getCreateuserEqualTo() {
		return createuserEqualTo;
	}
	public void setCreateuserEqualTo(java.lang.String createuserEqualTo) {
		this.createuserEqualTo = createuserEqualTo;
	}

	public java.util.List getCreatetimeNotIn() {
		return createtimeNotIn;
	}
	public void setCreatetimeNotIn(java.util.List createtimeNotIn) {
		this.createtimeNotIn = createtimeNotIn;
	}

	public java.util.Date getCreatetimeNotEqualTo() {
		return createtimeNotEqualTo;
	}
	public void setCreatetimeNotEqualTo(java.util.Date createtimeNotEqualTo) {
		this.createtimeNotEqualTo = createtimeNotEqualTo;
	}

	public java.util.Date getCreatetimeLessThanOrEqualTo() {
		return createtimeLessThanOrEqualTo;
	}
	public void setCreatetimeLessThanOrEqualTo(java.util.Date createtimeLessThanOrEqualTo) {
		this.createtimeLessThanOrEqualTo = createtimeLessThanOrEqualTo;
	}

	public java.util.Date getCreatetimeLessThan() {
		return createtimeLessThan;
	}
	public void setCreatetimeLessThan(java.util.Date createtimeLessThan) {
		this.createtimeLessThan = createtimeLessThan;
	}

	public java.lang.Boolean getCreatetimeIsNull() {
		return createtimeIsNull;
	}
	public void setCreatetimeIsNull(java.lang.Boolean createtimeIsNull) {
		this.createtimeIsNull = createtimeIsNull;
	}

	public java.lang.Boolean getCreatetimeIsNotNull() {
		return createtimeIsNotNull;
	}
	public void setCreatetimeIsNotNull(java.lang.Boolean createtimeIsNotNull) {
		this.createtimeIsNotNull = createtimeIsNotNull;
	}

	public java.util.List getCreatetimeIn() {
		return createtimeIn;
	}
	public void setCreatetimeIn(java.util.List createtimeIn) {
		this.createtimeIn = createtimeIn;
	}

	public java.util.Date getCreatetimeGreaterThanOrEqualTo() {
		return createtimeGreaterThanOrEqualTo;
	}
	public void setCreatetimeGreaterThanOrEqualTo(java.util.Date createtimeGreaterThanOrEqualTo) {
		this.createtimeGreaterThanOrEqualTo = createtimeGreaterThanOrEqualTo;
	}

	public java.util.Date getCreatetimeGreaterThan() {
		return createtimeGreaterThan;
	}
	public void setCreatetimeGreaterThan(java.util.Date createtimeGreaterThan) {
		this.createtimeGreaterThan = createtimeGreaterThan;
	}

	public java.util.Date getCreatetimeEqualTo() {
		return createtimeEqualTo;
	}
	public void setCreatetimeEqualTo(java.util.Date createtimeEqualTo) {
		this.createtimeEqualTo = createtimeEqualTo;
	}

	public void setSidx(String sidx) {
		this.sidx = sidx;
	}
	public String getSord() {
		return sord;
	}
	public void setSord(String sord) {
		 this.sord = sord;
	}
}
