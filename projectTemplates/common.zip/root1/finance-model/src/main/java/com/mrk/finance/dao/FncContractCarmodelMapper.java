package com.mrk.finance.dao;

import com.mrk.common.base.BaseMapper;
import com.mrk.finance.model.FncContractCarmodel;

/**
 * Mapper接口
 * @author 自动工具
 */
public interface FncContractCarmodelMapper extends BaseMapper<FncContractCarmodel> {

}
