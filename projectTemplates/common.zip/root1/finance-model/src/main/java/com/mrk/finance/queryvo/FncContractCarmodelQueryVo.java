package com.mrk.finance.queryvo;

import com.mrk.common.base.BaseQueryVo;
import io.swagger.annotations.ApiModelProperty;
import lombok.Getter;
import lombok.Setter;

import java.util.List;

@Setter
@Getter
public class FncContractCarmodelQueryVo extends BaseQueryVo {



    @ApiModelProperty(value = "主键 精确匹配")
    private Long fccIdEqualTo;

    @ApiModelProperty(value = "主键 模糊匹配")
    private Long fccIdLike;


    @ApiModelProperty(value = "合同id 精确匹配")
    private Long fccContractIdEqualTo;

    @ApiModelProperty(value = "合同id 模糊匹配")
    private Long fccContractIdLike;

    private List<Long> fccContractIdIn;


    @ApiModelProperty(value = "车型id 精确匹配")
    private Long fccContractCarmodelIdEqualTo;

    @ApiModelProperty(value = "车型id 模糊匹配")
    private Long fccContractCarmodelIdLike;


    @ApiModelProperty(value = "数量 精确匹配")
    private Integer fccCarnumEqualTo;

    @ApiModelProperty(value = "数量 模糊匹配")
    private Integer fccCarnumLike;
    }
