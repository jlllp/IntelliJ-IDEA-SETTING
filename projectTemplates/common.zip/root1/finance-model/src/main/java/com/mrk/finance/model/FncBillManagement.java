package com.mrk.finance.model;

import com.mrk.common.base.BaseEntity;
import io.swagger.annotations.ApiModelProperty;
import lombok.Getter;
import lombok.Setter;
import com.fasterxml.jackson.annotation.JsonFormat;
import org.springframework.format.annotation.DateTimeFormat;

import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import java.io.Serializable;

@Setter
@Getter
public class FncBillManagement extends BaseEntity implements Serializable {
    private static final long serialVersionUID = 1L;


    /**
     * 主键
     */
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @ApiModelProperty(value = "主键")
    private Long fbmId;

    /**
     * 城市
     */
    @ApiModelProperty(value = "城市")
    private Long fbmCityId;

    /**
     * 科目（类型）0, "租金")1, "滞纳金")2, "违约金"(3, "购车尾款")4, "保证金");
     */
    @ApiModelProperty(value = "科目（类型）0, 租金)1, 滞纳金)2, 违约金(3, 购车尾款)4, 保证金);")
    private Integer fbmSubjects;

    /**
     * 账单金额
     */
    @ApiModelProperty(value = "账单金额")
    private Double fbmBillAmount;

    /**
     * 期数
     */
    @ApiModelProperty(value = "期数")
    private String fbmNper;

    /**
     * 账单生成时间
     */
    @DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss", timezone = "GMT+8")
    @ApiModelProperty(value = "账单生成时间")
    private java.util.Date fbmBillGenerateTime;

    /**
     * 账单生成方式（0, "手动生成")1, "自动生成
     */
    @ApiModelProperty(value = "账单生成方式（0, 手动生成)1, 自动生成")
    private Integer fbmBillGenerateWay;

    /**
     * 账单截止时间
     */
    @DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss", timezone = "GMT+8")
    @ApiModelProperty(value = "账单截止时间")
    private java.util.Date fbmBillCatoffTime;

    /**
     * 关联车辆ID
     */
    @ApiModelProperty(value = "关联车辆ID")
    private Long fbmAssociateCarId;

    /**
     * 关联合同ID
     */
    @ApiModelProperty(value = "关联合同ID")
    private Long fbmAssociateContractId;

    /**
     * 账单状态(账单状态 0无 1审批中 2已驳回 3未支付 4部分支付 5已支付 6已作废 7开票中 8已开票 9退还中 10部分退还 11已退还
     */
    @ApiModelProperty(value = "账单状态(账单状态 0无 1审批中 2已驳回 3未支付 4部分支付 5已支付 6已作废 7开票中 8已开票 9退还中 10部分退还 11已退还")
    private Integer fbmBillState;

    /**
     * 匹配方式
     */
    @ApiModelProperty(value = "匹配方式")
    private Integer fbmMatchWay;

    /**
     * 匹配人ID
     */
    @ApiModelProperty(value = "匹配人ID")
    private Long fbmMatchUserId;

    /**
     * 匹配时间
     */
    @DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss", timezone = "GMT+8")
    @ApiModelProperty(value = "匹配时间")
    private java.util.Date fbmMatchTime;

    /**
     * 匹配流水号
     */
    @ApiModelProperty(value = "匹配流水号")
    private String fbmMatchSerialNumber;

    /**
     * 支付时间
     */
    @DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss", timezone = "GMT+8")
    @ApiModelProperty(value = "支付时间")
    private java.util.Date fbmPayTime;

    /**
     * 已匹配金额
     */
    @ApiModelProperty(value = "已匹配金额")
    private Double fbmMatchedAmount;

    /**
     * 未匹配金额
     */
    @ApiModelProperty(value = "未匹配金额")
    private Double fbmNotMatchAmount;

    /**
     * 账单生成原因
     */
    @ApiModelProperty(value = "账单生成原因")
    private String fbmBillGenerateReason;

    /**
     * 账单凭证
     */
    @ApiModelProperty(value = "账单凭证")
    private String fbmBillVoucher;

    /**
     * 收车工单是否处理标识（0未处理，1已处理）
     */
    @ApiModelProperty(value = "收车工单是否处理标识（0未处理，1已处理）")
    private Integer fbmTurnerDeal;

    /**
     * 车辆ID
     */
    @ApiModelProperty(value = "车辆ID")
    private Long fbmCarId;

    /**
     * 合同id
     */
    @ApiModelProperty(value = "合同id")
    private Long fbmContractId;

    /**
     * 计租日期
     */
    @DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss", timezone = "GMT+8")
    @ApiModelProperty(value = "计租日期")
    private java.util.Date fbmLeasePeriod;

    /**
     * 减免金额
     */
    @ApiModelProperty(value = "减免金额")
    private Double fbmBreaksAmount;

    /**
     * 减免类型
     */
    @ApiModelProperty(value = "减免类型")
    private Integer fbmBreaksType;

    /**
     * 减免凭证
     */
    @ApiModelProperty(value = "减免凭证")
    private String fbmBreaksCredentials;

    /**
     * 减免备注
     */
    @ApiModelProperty(value = "减免备注")
    private String fbmBreaksRemark;

    /**
     * 减免后金额
     */
    @ApiModelProperty(value = "减免后金额")
    private Double fbmBreaksAfterAmount;

    /**
     * 减免操作人手机号
     */
    @ApiModelProperty(value = "减免操作人手机号")
    private String fbmBreaksPhone;

    /**
     * 减免操作时间
     */
    @DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss", timezone = "GMT+8")
    @ApiModelProperty(value = "减免操作时间")
    private java.util.Date fbmBreaksTime;

    /**
     * 逾期状态 0无 1未逾期 2已逾期
     */
    @ApiModelProperty(value = "逾期状态 0无 1未逾期 2已逾期")
    private Integer fbmOverdueState;

    /**
     * 批量方式
     */
    @ApiModelProperty(value = "批量方式")
    private String fbmMatchType;

    /**
     * 匹配人手机号
     */
    @ApiModelProperty(value = "匹配人手机号")
    private String fbmMatchPhone;

    /**
     * 已支付金额
     */
    @ApiModelProperty(value = "已支付金额")
    private Double fbmPayAmonut;

    /**
     * 未支付金额
     */
    @ApiModelProperty(value = "未支付金额")
    private Double fbmUnpayAmount;

    /**
     * 应退还金额
     */
    @ApiModelProperty(value = "应退还金额")
    private Double fbmRefundAmount;

    /**
     * 未退还金额
     */
    @ApiModelProperty(value = "未退还金额")
    private Double fbmUnRefundAmount;

    /**
     * 已退还金额
     */
    @ApiModelProperty(value = "已退还金额")
    private Double fbmAlreadyRefundAmount;
}
