package com.mrk.finance.model;

import com.mrk.common.base.BaseEntity;
import io.swagger.annotations.ApiModelProperty;
import lombok.Getter;
import lombok.Setter;
import com.fasterxml.jackson.annotation.JsonFormat;
import org.springframework.format.annotation.DateTimeFormat;

import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import java.io.Serializable;

@Setter
@Getter
public class FncContractAttach extends BaseEntity implements Serializable {
    private static final long serialVersionUID = 1L;


    /**
     * 主键
     */
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @ApiModelProperty(value = "主键")
    private Long fcaId;

    /**
     * 合同ID
     */
    @ApiModelProperty(value = "合同ID")
    private Long fcaContractId;

    /**
     * 链接地址
     */
    @ApiModelProperty(value = "链接地址")
    private String fcaLink;

    /**
     * 文件类型
     */
    @ApiModelProperty(value = "文件类型")
    private String fcaFileType;
}
