package com.mrk.finance.queryvo;

import com.mrk.common.base.BaseQueryVo;
import io.swagger.annotations.ApiModelProperty;
import lombok.Getter;
import lombok.Setter;
import com.fasterxml.jackson.annotation.JsonFormat;
import org.springframework.format.annotation.DateTimeFormat;

@Setter
@Getter
public class FncContractAttachQueryVo extends BaseQueryVo {



    @ApiModelProperty(value = "主键 精确匹配")
    private Long fcaIdEqualTo;

    @ApiModelProperty(value = "主键 模糊匹配")
    private Long fcaIdLike;


    @ApiModelProperty(value = "合同ID 精确匹配")
    private Long fcaContractIdEqualTo;

    @ApiModelProperty(value = "合同ID 模糊匹配")
    private Long fcaContractIdLike;


    @ApiModelProperty(value = "链接地址 精确匹配")
    private String fcaLinkEqualTo;

    @ApiModelProperty(value = "链接地址 模糊匹配")
    private String fcaLinkLike;


    @ApiModelProperty(value = "文件类型 精确匹配")
    private String fcaFileTypeEqualTo;

    @ApiModelProperty(value = "文件类型 模糊匹配")
    private String fcaFileTypeLike;
    }
