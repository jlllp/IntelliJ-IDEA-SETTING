package com.mrk.finance.queryvo;

import com.mrk.common.base.BaseQueryVo;
import io.swagger.annotations.ApiModelProperty;
import lombok.Getter;
import lombok.Setter;

import java.util.List;

@Setter
@Getter
public class FncContractRentQueryVo extends BaseQueryVo {



    @ApiModelProperty(value = "id 精确匹配")
    private Long fccIdEqualTo;

    @ApiModelProperty(value = "id 模糊匹配")
    private Long fccIdLike;


    @ApiModelProperty(value = "合同id 精确匹配")
    private Long fccContractIdEqualTo;
    private List<Long> fccContractIdIn;

    @ApiModelProperty(value = "合同id 模糊匹配")
    private Long fccContractIdLike;


    @ApiModelProperty(value = "开始月份 精确匹配")
    private Integer fccStartMonthEqualTo;

    @ApiModelProperty(value = "开始月份 模糊匹配")
    private Integer fccStartMonthLike;


    @ApiModelProperty(value = "结束月份 精确匹配")
    private Integer fccEndMonthEqualTo;

    @ApiModelProperty(value = "结束月份 模糊匹配")
    private Integer fccEndMonthLike;


    @ApiModelProperty(value = "租金金额 精确匹配")
    private Double fccRentAmountEqualTo;

    @ApiModelProperty(value = "租金金额 模糊匹配")
    private Double fccRentAmountLike;
    }
