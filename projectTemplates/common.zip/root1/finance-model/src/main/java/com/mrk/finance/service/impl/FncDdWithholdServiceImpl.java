package com.mrk.finance.service.impl;

import com.github.pagehelper.PageInfo;
import com.mrk.common.constant.BaseConstants;
import com.mrk.common.utils.bean.BeanUtils;
import com.mrk.common.utils.jwt.JWTUtil;
import com.mrk.common.utils.page.PageUtils;
import com.mrk.common.utils.text.StringUtils;
import com.mrk.finance.dao.FncDdWithholdMapper;
import com.mrk.finance.example.FncDdWithholdExample;
import com.mrk.finance.model.FncDdWithhold;
import com.mrk.finance.query.FncDdWithholdQuery;
import com.mrk.finance.queryvo.FncDdWithholdQueryVo;
import com.mrk.finance.service.FncDdWithholdService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import javax.annotation.Resource;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;


/**
 * @Description: FncDdWithholdServiceImpl
 */
@Service
@Slf4j
public class FncDdWithholdServiceImpl implements FncDdWithholdService {
    @Resource
    private FncDdWithholdMapper fncDdWithholdMapper;

    @Override
    public PageInfo<FncDdWithhold> page(FncDdWithholdQueryVo queryVo){
        PageUtils.startPage();
        List<FncDdWithhold> list = this.list(queryVo);
        return new PageInfo<>(list);
    }

    @Override
    public List<FncDdWithhold> list(FncDdWithholdQueryVo queryVo){
        FncDdWithholdQuery query = new FncDdWithholdQuery();
        BeanUtils.copyBeanProp(queryVo, query);
        query.setSidx(StringUtils.camelToUnderlineAndFilterText(query.getSidx()));
        return fncDdWithholdMapper.selectByExample(query.getCrieria());
    }

    @Override
    @Transactional(rollbackFor = Exception.class)
    public int add(FncDdWithhold entity){
        entity.setCreatetime(new Date());
        entity.setCreateuser(JWTUtil.getNikeName());
        entity.setDr(BaseConstants.DR_NO);
        return fncDdWithholdMapper.insert(entity);
    }

    @Override
    @Transactional(rollbackFor = Exception.class)
    public int update(FncDdWithhold entity){
        entity.setUpdatetime(new Date());
        entity.setUpdateuser(JWTUtil.getNikeName());
        return fncDdWithholdMapper.updateByPrimaryKey(entity);
    }

    @Override
    @Transactional(rollbackFor = Exception.class)
    public int delete(Long id){
        return fncDdWithholdMapper.deleteByPrimaryKey(id);
    }

    @Override
    public FncDdWithhold getById(Long id){
        return fncDdWithholdMapper.selectByPrimaryKey(id);
    }

    @Override
    public List<FncDdWithhold> getByIds(List<Long> ids) {
        if (ids == null || ids.isEmpty()) {
            return new ArrayList<>();
        }

        FncDdWithholdExample example = new FncDdWithholdExample();
        example.createCriteria()
                .andDrEqualTo(BaseConstants.DR_NO)
                .andFdwIdIn(ids);

        return fncDdWithholdMapper.selectByExample(example);
    }

    @Override
    public int insertList(List<FncDdWithhold> fncDdWithholdList) {
        return fncDdWithholdMapper.insertList(fncDdWithholdList);
    }
}
