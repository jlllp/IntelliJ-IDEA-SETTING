package com.mrk.finance.service.impl;

import com.github.pagehelper.PageInfo;
import com.mrk.common.constant.BaseConstants;
import com.mrk.common.utils.bean.BeanUtils;
import com.mrk.common.utils.jwt.JWTUtil;
import com.mrk.common.utils.page.PageUtils;
import com.mrk.common.utils.text.StringUtils;
import com.mrk.finance.dao.FncContractRentalFeesMapper;
import com.mrk.finance.example.FncContractRentalFeesExample;
import com.mrk.finance.model.FncContractRentalFees;
import com.mrk.finance.query.FncContractRentalFeesQuery;
import com.mrk.finance.queryvo.FncContractRentalFeesQueryVo;
import com.mrk.finance.service.FncContractRentalFeesService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import javax.annotation.Resource;
import java.util.Date;
import java.util.List;


/**
 * @Description: FncContractRentalFeesServiceImpl
 */
@Service
@Slf4j
public class FncContractRentalFeesServiceImpl implements FncContractRentalFeesService {
    @Resource
    private FncContractRentalFeesMapper fncContractRentalFeesMapper;

    @Override
    public PageInfo<FncContractRentalFees> page(FncContractRentalFeesQueryVo queryVo) {
        PageUtils.startPage();
        List<FncContractRentalFees> list = this.list(queryVo);
        return new PageInfo<>(list);
    }

    @Override
    public List<FncContractRentalFees> list(FncContractRentalFeesQueryVo queryVo) {
        FncContractRentalFeesQuery query = new FncContractRentalFeesQuery();
        BeanUtils.copyBeanProp(queryVo, query);
        query.setSidx(StringUtils.camelToUnderlineAndFilterText(query.getSidx()));
        return fncContractRentalFeesMapper.selectByExample(query.getCrieria());
    }

    @Override
    @Transactional(rollbackFor = Exception.class)
    public int add(FncContractRentalFees entity) {
        entity.setCreatetime(new Date());
        entity.setCreateuser(JWTUtil.getNikeName());
        entity.setDr(BaseConstants.DR_NO);
        return fncContractRentalFeesMapper.insert(entity);
    }

    @Override
    public int addList(List<FncContractRentalFees> contractRentalFeesList) {
        if (contractRentalFeesList == null || contractRentalFeesList.isEmpty()) {
            return 0;
        }
        Date date = new Date();
        String name = JWTUtil.getNikeName();
        for (FncContractRentalFees rentalFees : contractRentalFeesList) {
            rentalFees.setCreateuser(name);
            rentalFees.setCreatetime(date);
            rentalFees.setDr(BaseConstants.DR_NO);
        }
        return fncContractRentalFeesMapper.insertList(contractRentalFeesList);
    }

    @Override
    @Transactional(rollbackFor = Exception.class)
    public int update(FncContractRentalFees entity) {
        entity.setUpdatetime(new Date());
        entity.setUpdateuser(JWTUtil.getNikeName());
        return fncContractRentalFeesMapper.updateByPrimaryKey(entity);
    }

    @Override
    public int updateSelective(FncContractRentalFees entity) {
        entity.setUpdatetime(new Date());
        entity.setUpdateuser(JWTUtil.getNikeName());
        return fncContractRentalFeesMapper.updateByPrimaryKeySelective(entity);
    }

    @Override
    public int updateByExampleSelective(FncContractRentalFees entity, FncContractRentalFeesExample example) {
        entity.setUpdatetime(new Date());
        entity.setUpdateuser(JWTUtil.getNikeName());
        return fncContractRentalFeesMapper.updateByExampleSelective(entity, example);
    }

    @Override
    @Transactional(rollbackFor = Exception.class)
    public int delete(Long id) {
        return fncContractRentalFeesMapper.deleteByPrimaryKey(id);
    }

    @Override
    public FncContractRentalFees getById(Long id) {
        return fncContractRentalFeesMapper.selectByPrimaryKey(id);
    }

    /**
     * 根据合同获取租金包含费用明细
     *
     * @param contractId 合同id
     * @return 租金包含费用明细
     */
    @Override
    public List<FncContractRentalFees> getByContractId(Long contractId) {
        FncContractRentalFeesExample example = new FncContractRentalFeesExample();
        example.createCriteria()
                .andDrEqualTo(BaseConstants.DR_NO)
                .andFcrfContractIdEqualTo(contractId);
        return fncContractRentalFeesMapper.selectByExample(example);
    }
}
