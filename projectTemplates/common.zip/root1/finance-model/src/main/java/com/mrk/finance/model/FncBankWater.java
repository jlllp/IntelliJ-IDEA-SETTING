package com.mrk.finance.model;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.mrk.common.base.BaseEntity;
import io.swagger.annotations.ApiModelProperty;
import lombok.Getter;
import lombok.Setter;
import org.springframework.format.annotation.DateTimeFormat;

import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import java.io.Serializable;

@Setter
@Getter
public class FncBankWater extends BaseEntity implements Serializable {
private static final long serialVersionUID=1L;


    /**主键 */
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @ApiModelProperty(value = "主键")
    private Long fbwId;

    /**凭证号 */
    @ApiModelProperty(value = "凭证号")
    private String fbwVoucherNo;

    /**本方账号 */
    @ApiModelProperty(value = "本方账号")
    private String fbwOwnAccount;

    /**对方账号 */
    @ApiModelProperty(value = "对方账号")
    private String fbwOtherAccount;

    /**对方单位名称 */
    @ApiModelProperty(value = "对方单位名称")
    private String fbwOtherUnitName;

    /**借/贷 */
    @ApiModelProperty(value = "借/贷")
    private Integer fbwLoanType;

    /**交易时间 */
    @DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss", timezone = "GMT+8")
    @ApiModelProperty(value = "交易时间")
    private java.util.Date fbwDealTime;

    /**借方发生额 */
    @ApiModelProperty(value = "借方发生额")
    private Double fbwBorrowAmount;

    /**贷方发生额 */
    @ApiModelProperty(value = "贷方发生额")
    private Double fbwCreditAmount;

    /**用途 */
    @ApiModelProperty(value = "用途")
    private String fbwUse;

    /**摘要 */
    @ApiModelProperty(value = "摘要")
    private String fbwDigest;

    /**个性化信息 */
    @ApiModelProperty(value = "个性化信息")
    private String fbwPersonalizedInformation;

    /**匹配状态 */
    @ApiModelProperty(value = "匹配状态")
    private Integer fbwMatchState;

    /**匹配账单 */
    @ApiModelProperty(value = "匹配账单")
    private String fbwMatchBill;

    /**匹配方式 */
    @ApiModelProperty(value = "匹配方式")
    private Integer fbwMatchType;

    /**已匹配金额 */
    @ApiModelProperty(value = "已匹配金额")
    private Double fbwMatchedAmount;

    /**未匹配金额 */
    @ApiModelProperty(value = "未匹配金额")
    private Double fbwNotMatchAmount;
    }
