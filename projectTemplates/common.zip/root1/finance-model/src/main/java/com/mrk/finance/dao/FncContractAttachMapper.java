package com.mrk.finance.dao;

import com.mrk.finance.model.FncContractAttach;
import com.mrk.common.base.BaseMapper;

/**
 * Mapper接口
 * @author 自动工具
 */
public interface FncContractAttachMapper extends BaseMapper<FncContractAttach> {

}
