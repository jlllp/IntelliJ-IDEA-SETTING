package com.mrk.finance.service.impl;

import com.github.pagehelper.PageInfo;
import com.mrk.common.constant.BaseConstants;
import com.mrk.common.utils.bean.BeanUtils;
import com.mrk.common.utils.jwt.JWTUtil;
import com.mrk.common.utils.page.PageUtils;
import com.mrk.common.utils.text.StringUtils;
import com.mrk.finance.dao.FncBillManagementMapper;
import com.mrk.finance.example.FncBillManagementExample;
import com.mrk.finance.model.FncBillManagement;
import com.mrk.finance.query.FncBillManagementQuery;
import com.mrk.finance.queryvo.FncBillManagementQueryVo;
import com.mrk.finance.service.FncBillManagementService;
import com.mrk.universal.enums.contract.BillSubjectsEnum;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import javax.annotation.Resource;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;


/**
 * @Description: FncBillManagementServiceImpl
 */
@Service
@Slf4j
public class FncBillManagementServiceImpl implements FncBillManagementService {
    @Resource
    private FncBillManagementMapper fncBillManagementMapper;

    @Override
    public PageInfo<FncBillManagement> page(FncBillManagementQueryVo queryVo) {
        PageUtils.startPage();
        List<FncBillManagement> list = this.list(queryVo);
        return new PageInfo<>(list);
    }

    @Override
    public List<FncBillManagement> list(FncBillManagementQueryVo queryVo) {
        FncBillManagementQuery query = new FncBillManagementQuery();
        BeanUtils.copyBeanProp(queryVo, query);
        query.setSidx(StringUtils.camelToUnderlineAndFilterText(query.getSidx()));
        return fncBillManagementMapper.selectByExample(query.getCrieria());
    }

    @Override
    @Transactional(rollbackFor = Exception.class)
    public int add(FncBillManagement entity) {
        entity.setCreatetime(new Date());
        entity.setCreateuser(JWTUtil.getNikeName());
        entity.setDr(BaseConstants.DR_NO);
        return fncBillManagementMapper.insert(entity);
    }

    @Override
    @Transactional(rollbackFor = Exception.class)
    public int update(FncBillManagement entity) {
        entity.setUpdatetime(new Date());
        entity.setUpdateuser(JWTUtil.getNikeName());
        return fncBillManagementMapper.updateByPrimaryKey(entity);
    }

    @Override
    @Transactional(rollbackFor = Exception.class)
    public int updateSelective(FncBillManagement entity) {
        entity.setUpdatetime(new Date());
        entity.setUpdateuser(JWTUtil.getNikeName());
        return fncBillManagementMapper.updateByPrimaryKeySelective(entity);
    }

    @Override
    @Transactional(rollbackFor = Exception.class)
    public int delete(Long id) {
        return fncBillManagementMapper.deleteByPrimaryKey(id);
    }

    @Override
    @Transactional(rollbackFor = Exception.class)
    public int deleteLogically(Long id) {
        FncBillManagement bill = getById(id);
        bill.setDr(BaseConstants.DR_YES);
        return update(bill);
    }

    @Override
    public FncBillManagement getById(Long id) {
        return fncBillManagementMapper.selectByPrimaryKey(id);
    }

    @Override
    public List<FncBillManagement> getByIds(List<Long> ids) {
        if (ids == null || ids.isEmpty()) {
            return new ArrayList<>();
        }

        FncBillManagementExample example = new FncBillManagementExample();
        example.createCriteria()
                .andFbmIdIn(ids)
                .andDrEqualTo(BaseConstants.DR_NO);

        return fncBillManagementMapper.selectByExample(example);
    }

    @Override
    public List<FncBillManagement> selectByContractIdAndSubject(Long fncContractManagementId, Integer subject) {
        FncBillManagementExample example = new FncBillManagementExample();
        example.createCriteria().andFbmAssociateContractIdEqualTo(fncContractManagementId)
                .andFbmSubjectsEqualTo(subject)
                .andFbmBillAmountGreaterThanOrEqualTo(0.0)
                .andDrEqualTo(BaseConstants.DR_NO);
        return fncBillManagementMapper.selectByExample(example);
    }

    @Override
    public List<FncBillManagement> selectByContractId(Long id) {
        FncBillManagementQueryVo queryVo = new FncBillManagementQueryVo();
        queryVo.setFbmAssociateContractIdEqualTo(id);
        return this.list(queryVo);
    }

    @Override
    public List<FncBillManagement> getByContractId(Long contractId) {
        FncBillManagementExample example = new FncBillManagementExample();
        example.createCriteria()
                .andFbmAssociateContractIdEqualTo(contractId)
                .andDrEqualTo(BaseConstants.DR_NO);
        return fncBillManagementMapper.selectByExample(example);
    }

    /**
     * @param subject 科目
     * @return 指定科目的所有账单
     * @author Bob
     * @date 2021/11/15
     * @description 获取指定科目的账单
     */
    @Override
    public List<FncBillManagement> getBySubject(Integer subject) {
        FncBillManagementExample example = new FncBillManagementExample();
        example.createCriteria()
                .andFbmSubjectsEqualTo(subject)
                .andDrEqualTo(BaseConstants.DR_NO);
        return fncBillManagementMapper.selectByExample(example);
    }

    @Override
    public void updateList(List<FncBillManagement> fncBillManagements) {
        for (FncBillManagement fncBillManagement : fncBillManagements) {
            fncBillManagement.setUpdatetime(new Date());
            fncBillManagement.setUpdateuser(JWTUtil.getNikeName());
            fncBillManagementMapper.updateByPrimaryKey(fncBillManagement);
        }
    }

    @Override
    public List<FncBillManagement> getBySubjectAndAmountLT(Integer subject, double billAmount) {
        FncBillManagementExample example = new FncBillManagementExample();
        example.createCriteria()
                .andFbmSubjectsEqualTo(subject)
                .andFbmBillAmountLessThan(billAmount)
                .andDrEqualTo(BaseConstants.DR_NO);
        return fncBillManagementMapper.selectByExample(example);
    }

    /**
     * @param fncBillManagements 待新增的账单集合
     * @author Bob
     * @date 2021/11/17
     * @description 批量新增账单数据
     */
    @Override
    public void batchAdd(List<FncBillManagement> fncBillManagements) {
        fncBillManagementMapper.insertList(fncBillManagements);
    }

    /**
     * @param newState   新状态
     * @param catOffTime 截止时间
     * @param oldState   旧状态集合
     * @description 通过账单截止时间小于且账单状态为旧状态集合时将账单的状态更新为新状态
     * @author Bob
     * @date 2021/11/18
     */
    @Override
    public void updateStateByCatOffTimeLTAndStateIn(Integer newState, Date catOffTime, List<Integer> oldState) {
        FncBillManagement entity = new FncBillManagement();
        entity.setFbmBillState(newState);

        FncBillManagementExample example = new FncBillManagementExample();
        example.createCriteria()
                .andFbmBillCatoffTimeLessThan(catOffTime)
                .andFbmBillStateIn(oldState)
                .andDrEqualTo(BaseConstants.DR_NO);
        fncBillManagementMapper.updateByExampleSelective(entity, example);
    }

    /**
     * @param contractIdList 合同id
     * @param doesNotContain 不包含科目
     * @param catoffStart    截止时间开始
     * @param caroffEnd      截止时间结束
     * @return 符合条件的账单
     * @author Bob
     * @date 2021/11/24
     * @description 根据合同id 不包含科目 截止时间开始和结束时间获取账单
     */
    @Override
    public List<FncBillManagement> getByContractIdAndNoSubjectAndCatoff(List<Long> contractIdList, List<Integer> doesNotContain, Date catoffStart, Date caroffEnd) {
        FncBillManagementExample example = new FncBillManagementExample();
        example.createCriteria()
                .andFbmAssociateContractIdIn(contractIdList)
                .andFbmSubjectsNotIn(doesNotContain)
                .andFbmBillCatoffTimeGreaterThanOrEqualTo(catoffStart)
                .andFbmBillCatoffTimeLessThan(caroffEnd)
                .andDrEqualTo(BaseConstants.DR_NO);
        return fncBillManagementMapper.selectByExample(example);
    }

    /**
     * @param contractIdList 合同id
     * @param subject        科目
     * @param catoffStart    截止时间开始
     * @param caroffEnd      截止时间结束
     * @return 符合条件的账单
     * @author Bob
     * @date 2021/11/24
     * @description 根据合同id 科目 截止时间开始和结束时间获取账单
     */
    @Override
    public List<FncBillManagement> getByContractIdAndSubjectAndCatoff(List<Long> contractIdList, Integer subject, Date catoffStart, Date caroffEnd) {
        FncBillManagementExample example = new FncBillManagementExample();
        example.createCriteria()
                .andFbmAssociateContractIdIn(contractIdList)
                .andFbmSubjectsEqualTo(subject)
                .andFbmBillCatoffTimeGreaterThanOrEqualTo(catoffStart)
                .andFbmBillCatoffTimeLessThan(caroffEnd)
                .andDrEqualTo(BaseConstants.DR_NO);
        return fncBillManagementMapper.selectByExample(example);
    }

    @Override
    public List<FncBillManagement> selectBillOfBwAccurate(Integer loanType, Double amount, Long partyaId, Long partybId) {
        return fncBillManagementMapper.selectBillOfBwAccurate(loanType, amount, partyaId, partybId);
    }

    @Override
    public List<FncBillManagement> selectBillOfBwFuzzy(Integer loanType, Long partybId) {
        return fncBillManagementMapper.selectBillOfBwFuzzy(loanType, partybId);
    }

    @Override
    public List<FncBillManagement> selectBillOfTwAccurate(Long partybId, String agreementNumber, Double amount, Long carId) {
        return fncBillManagementMapper.selectBillOfTwAccurate(partybId, agreementNumber, amount, carId);
    }

    @Override
    public List<FncBillManagement> selectBillOfTwFuzzy(Long partybId, String agreementNumber) {
        return fncBillManagementMapper.selectBillOfTwFuzzy(partybId, agreementNumber);
    }

    @Override
    public List<FncBillManagement> getByContractIdAndSubjectAndNper(Long contractId, Integer subject, String nper) {
        FncBillManagementExample example = new FncBillManagementExample();
        example.createCriteria()
                .andFbmAssociateContractIdEqualTo(contractId)
                .andFbmSubjectsEqualTo(subject)
                .andFbmNperEqualTo(nper)
                .andDrEqualTo(BaseConstants.DR_NO);
        return fncBillManagementMapper.selectByExample(example);
    }

    @Override
    public List<FncBillManagement> selectRentBill() {
        return fncBillManagementMapper.selectRentBill(BillSubjectsEnum.RENT.getValue());
    }

    @Override
    public List<FncBillManagement> selectRentBillLess() {
        return fncBillManagementMapper.selectRentBillLess(BillSubjectsEnum.RENT.getValue());
    }


}
