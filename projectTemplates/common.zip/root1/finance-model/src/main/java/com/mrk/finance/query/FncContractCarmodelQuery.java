package com.mrk.finance.query;
import com.mrk.common.utils.text.CheckUtil;

/**
 * @author 自动生成工具
 * @date   2021/11/10
 */
public class FncContractCarmodelQuery {
	private String updateuserNotLike;
	private java.util.List updateuserNotIn;
	private String updateuserNotEqualTo;
	private String updateuserLike;
	private String updateuserLessThanOrEqualTo;
	private String updateuserLessThan;
	private Boolean updateuserIsNull;
	private Boolean updateuserIsNotNull;
	private java.util.List updateuserIn;
	private String updateuserGreaterThanOrEqualTo;
	private String updateuserGreaterThan;
	private String updateuserEqualTo;
	private java.util.List updatetimeNotIn;
	private java.util.Date updatetimeNotEqualTo;
	private java.util.Date updatetimeLessThanOrEqualTo;
	private java.util.Date updatetimeLessThan;
	private Boolean updatetimeIsNull;
	private Boolean updatetimeIsNotNull;
	private java.util.List updatetimeIn;
	private java.util.Date updatetimeGreaterThanOrEqualTo;
	private java.util.Date updatetimeGreaterThan;
	private java.util.Date updatetimeEqualTo;
	private String remarkNotLike;
	private java.util.List remarkNotIn;
	private String remarkNotEqualTo;
	private String remarkLike;
	private String remarkLessThanOrEqualTo;
	private String remarkLessThan;
	private Boolean remarkIsNull;
	private Boolean remarkIsNotNull;
	private java.util.List remarkIn;
	private String remarkGreaterThanOrEqualTo;
	private String remarkGreaterThan;
	private String remarkEqualTo;
	private java.util.List fccIdNotIn;
	private Long fccIdNotEqualTo;
	private Long fccIdLessThanOrEqualTo;
	private Long fccIdLessThan;
	private Boolean fccIdIsNull;
	private Boolean fccIdIsNotNull;
	private java.util.List fccIdIn;
	private Long fccIdGreaterThanOrEqualTo;
	private Long fccIdGreaterThan;
	private Long fccIdEqualTo;
	private java.util.List fccContractIdNotIn;
	private Long fccContractIdNotEqualTo;
	private Long fccContractIdLessThanOrEqualTo;
	private Long fccContractIdLessThan;
	private Boolean fccContractIdIsNull;
	private Boolean fccContractIdIsNotNull;
	private java.util.List fccContractIdIn;
	private Long fccContractIdGreaterThanOrEqualTo;
	private Long fccContractIdGreaterThan;
	private Long fccContractIdEqualTo;
	private java.util.List fccContractCarmodelIdNotIn;
	private Long fccContractCarmodelIdNotEqualTo;
	private Long fccContractCarmodelIdLessThanOrEqualTo;
	private Long fccContractCarmodelIdLessThan;
	private Boolean fccContractCarmodelIdIsNull;
	private Boolean fccContractCarmodelIdIsNotNull;
	private java.util.List fccContractCarmodelIdIn;
	private Long fccContractCarmodelIdGreaterThanOrEqualTo;
	private Long fccContractCarmodelIdGreaterThan;
	private Long fccContractCarmodelIdEqualTo;
	private java.util.List fccCarnumNotIn;
	private Integer fccCarnumNotEqualTo;
	private Integer fccCarnumLessThanOrEqualTo;
	private Integer fccCarnumLessThan;
	private Boolean fccCarnumIsNull;
	private Boolean fccCarnumIsNotNull;
	private java.util.List fccCarnumIn;
	private Integer fccCarnumGreaterThanOrEqualTo;
	private Integer fccCarnumGreaterThan;
	private Integer fccCarnumEqualTo;
	private java.util.List drNotIn;
	private Integer drNotEqualTo;
	private Integer drLessThanOrEqualTo;
	private Integer drLessThan;
	private Boolean drIsNull;
	private Boolean drIsNotNull;
	private java.util.List drIn;
	private Integer drGreaterThanOrEqualTo;
	private Integer drGreaterThan;
	private Integer drEqualTo;
	private String createuserNotLike;
	private java.util.List createuserNotIn;
	private String createuserNotEqualTo;
	private String createuserLike;
	private String createuserLessThanOrEqualTo;
	private String createuserLessThan;
	private Boolean createuserIsNull;
	private Boolean createuserIsNotNull;
	private java.util.List createuserIn;
	private String createuserGreaterThanOrEqualTo;
	private String createuserGreaterThan;
	private String createuserEqualTo;
	private java.util.List createtimeNotIn;
	private java.util.Date createtimeNotEqualTo;
	private java.util.Date createtimeLessThanOrEqualTo;
	private java.util.Date createtimeLessThan;
	private Boolean createtimeIsNull;
	private Boolean createtimeIsNotNull;
	private java.util.List createtimeIn;
	private java.util.Date createtimeGreaterThanOrEqualTo;
	private java.util.Date createtimeGreaterThan;
	private java.util.Date createtimeEqualTo;
	private String sidx;
	private String sord;
	public String getSidx(){
		if(this.sidx == null){
			return "";
		}
		else if("updateuser".equals(this.sidx)){
			return "updateuser";
		}
		else if("updatetime".equals(this.sidx)){
			return "updatetime";
		}
		else if("remark".equals(this.sidx)){
			return "remark";
		}
		else if("fccId".equals(this.sidx)){
			return "fcc_id";
		}
		else if("fccContractId".equals(this.sidx)){
			return "fcc_contract_id";
		}
		else if("fccContractCarmodelId".equals(this.sidx)){
			return "fcc_contract_carmodel_id";
		}
		else if("fccCarnum".equals(this.sidx)){
			return "fcc_carnum";
		}
		else if("dr".equals(this.sidx)){
			return "dr";
		}
		else if("createuser".equals(this.sidx)){
			return "createuser";
		}
		else if("createtime".equals(this.sidx)){
			return "createtime";
		}
		return this.sidx;
	}

	@com.fasterxml.jackson.annotation.JsonIgnore
	public com.mrk.finance.example.FncContractCarmodelExample getCrieria(){
		com.mrk.finance.example.FncContractCarmodelExample q = new com.mrk.finance.example.FncContractCarmodelExample();
		com.mrk.finance.example.FncContractCarmodelExample.Criteria c = q.createCriteria();
		c.andDrEqualTo(0);
		if(CheckUtil.isNotEmpty(getUpdateuserNotLike())){
			c.andUpdateuserNotLike("%"+this.getUpdateuserNotLike()+"%");
		}
		if(CheckUtil.isNotEmpty(getUpdateuserNotIn())){
			c.andUpdateuserNotIn(this.getUpdateuserNotIn());
		}
		if(CheckUtil.isNotEmpty(getUpdateuserNotEqualTo())){
			c.andUpdateuserNotEqualTo(this.getUpdateuserNotEqualTo());
		}
		if(CheckUtil.isNotEmpty(getUpdateuserLike())){
			c.andUpdateuserLike("%"+this.getUpdateuserLike()+"%");
		}
		if(CheckUtil.isNotEmpty(getUpdateuserLessThanOrEqualTo())){
			c.andUpdateuserLessThanOrEqualTo(this.getUpdateuserLessThanOrEqualTo());
		}
		if(CheckUtil.isNotEmpty(getUpdateuserLessThan())){
			c.andUpdateuserLessThan(this.getUpdateuserLessThan());
		}
		if(CheckUtil.isNotEmpty(getUpdateuserIsNull()) && this.getUpdateuserIsNull()){
			c.andUpdateuserIsNull();
		}
		if(CheckUtil.isNotEmpty(getUpdateuserIsNotNull()) && this.getUpdateuserIsNotNull()){
			c.andUpdateuserIsNotNull();
		}
		if(CheckUtil.isNotEmpty(getUpdateuserIn())){
			c.andUpdateuserIn(this.getUpdateuserIn());
		}
		if(CheckUtil.isNotEmpty(getUpdateuserGreaterThanOrEqualTo())){
			c.andUpdateuserGreaterThanOrEqualTo(this.getUpdateuserGreaterThanOrEqualTo());
		}
		if(CheckUtil.isNotEmpty(getUpdateuserGreaterThan())){
			c.andUpdateuserGreaterThan(this.getUpdateuserGreaterThan());
		}
		if(CheckUtil.isNotEmpty(getUpdateuserEqualTo())){
			c.andUpdateuserEqualTo(this.getUpdateuserEqualTo());
		}
		if(CheckUtil.isNotEmpty(getUpdatetimeNotIn())){
			c.andUpdatetimeNotIn(this.getUpdatetimeNotIn());
		}
		if(CheckUtil.isNotEmpty(getUpdatetimeNotEqualTo())){
			c.andUpdatetimeNotEqualTo(this.getUpdatetimeNotEqualTo());
		}
		if(CheckUtil.isNotEmpty(getUpdatetimeLessThanOrEqualTo())){
			c.andUpdatetimeLessThanOrEqualTo(this.getUpdatetimeLessThanOrEqualTo());
		}
		if(CheckUtil.isNotEmpty(getUpdatetimeLessThan())){
			c.andUpdatetimeLessThan(this.getUpdatetimeLessThan());
		}
		if(CheckUtil.isNotEmpty(getUpdatetimeIsNull()) && this.getUpdatetimeIsNull()){
			c.andUpdatetimeIsNull();
		}
		if(CheckUtil.isNotEmpty(getUpdatetimeIsNotNull()) && this.getUpdatetimeIsNotNull()){
			c.andUpdatetimeIsNotNull();
		}
		if(CheckUtil.isNotEmpty(getUpdatetimeIn())){
			c.andUpdatetimeIn(this.getUpdatetimeIn());
		}
		if(CheckUtil.isNotEmpty(getUpdatetimeGreaterThanOrEqualTo())){
			c.andUpdatetimeGreaterThanOrEqualTo(this.getUpdatetimeGreaterThanOrEqualTo());
		}
		if(CheckUtil.isNotEmpty(getUpdatetimeGreaterThan())){
			c.andUpdatetimeGreaterThan(this.getUpdatetimeGreaterThan());
		}
		if(CheckUtil.isNotEmpty(getUpdatetimeEqualTo())){
			c.andUpdatetimeEqualTo(this.getUpdatetimeEqualTo());
		}
		if(CheckUtil.isNotEmpty(getRemarkNotLike())){
			c.andRemarkNotLike("%"+this.getRemarkNotLike()+"%");
		}
		if(CheckUtil.isNotEmpty(getRemarkNotIn())){
			c.andRemarkNotIn(this.getRemarkNotIn());
		}
		if(CheckUtil.isNotEmpty(getRemarkNotEqualTo())){
			c.andRemarkNotEqualTo(this.getRemarkNotEqualTo());
		}
		if(CheckUtil.isNotEmpty(getRemarkLike())){
			c.andRemarkLike("%"+this.getRemarkLike()+"%");
		}
		if(CheckUtil.isNotEmpty(getRemarkLessThanOrEqualTo())){
			c.andRemarkLessThanOrEqualTo(this.getRemarkLessThanOrEqualTo());
		}
		if(CheckUtil.isNotEmpty(getRemarkLessThan())){
			c.andRemarkLessThan(this.getRemarkLessThan());
		}
		if(CheckUtil.isNotEmpty(getRemarkIsNull()) && this.getRemarkIsNull()){
			c.andRemarkIsNull();
		}
		if(CheckUtil.isNotEmpty(getRemarkIsNotNull()) && this.getRemarkIsNotNull()){
			c.andRemarkIsNotNull();
		}
		if(CheckUtil.isNotEmpty(getRemarkIn())){
			c.andRemarkIn(this.getRemarkIn());
		}
		if(CheckUtil.isNotEmpty(getRemarkGreaterThanOrEqualTo())){
			c.andRemarkGreaterThanOrEqualTo(this.getRemarkGreaterThanOrEqualTo());
		}
		if(CheckUtil.isNotEmpty(getRemarkGreaterThan())){
			c.andRemarkGreaterThan(this.getRemarkGreaterThan());
		}
		if(CheckUtil.isNotEmpty(getRemarkEqualTo())){
			c.andRemarkEqualTo(this.getRemarkEqualTo());
		}
		if(CheckUtil.isNotEmpty(getFccIdNotIn())){
			c.andFccIdNotIn(this.getFccIdNotIn());
		}
		if(CheckUtil.isNotEmpty(getFccIdNotEqualTo())){
			c.andFccIdNotEqualTo(this.getFccIdNotEqualTo());
		}
		if(CheckUtil.isNotEmpty(getFccIdLessThanOrEqualTo())){
			c.andFccIdLessThanOrEqualTo(this.getFccIdLessThanOrEqualTo());
		}
		if(CheckUtil.isNotEmpty(getFccIdLessThan())){
			c.andFccIdLessThan(this.getFccIdLessThan());
		}
		if(CheckUtil.isNotEmpty(getFccIdIsNull()) && this.getFccIdIsNull()){
			c.andFccIdIsNull();
		}
		if(CheckUtil.isNotEmpty(getFccIdIsNotNull()) && this.getFccIdIsNotNull()){
			c.andFccIdIsNotNull();
		}
		if(CheckUtil.isNotEmpty(getFccIdIn())){
			c.andFccIdIn(this.getFccIdIn());
		}
		if(CheckUtil.isNotEmpty(getFccIdGreaterThanOrEqualTo())){
			c.andFccIdGreaterThanOrEqualTo(this.getFccIdGreaterThanOrEqualTo());
		}
		if(CheckUtil.isNotEmpty(getFccIdGreaterThan())){
			c.andFccIdGreaterThan(this.getFccIdGreaterThan());
		}
		if(CheckUtil.isNotEmpty(getFccIdEqualTo())){
			c.andFccIdEqualTo(this.getFccIdEqualTo());
		}
		if(CheckUtil.isNotEmpty(getFccContractIdNotIn())){
			c.andFccContractIdNotIn(this.getFccContractIdNotIn());
		}
		if(CheckUtil.isNotEmpty(getFccContractIdNotEqualTo())){
			c.andFccContractIdNotEqualTo(this.getFccContractIdNotEqualTo());
		}
		if(CheckUtil.isNotEmpty(getFccContractIdLessThanOrEqualTo())){
			c.andFccContractIdLessThanOrEqualTo(this.getFccContractIdLessThanOrEqualTo());
		}
		if(CheckUtil.isNotEmpty(getFccContractIdLessThan())){
			c.andFccContractIdLessThan(this.getFccContractIdLessThan());
		}
		if(CheckUtil.isNotEmpty(getFccContractIdIsNull()) && this.getFccContractIdIsNull()){
			c.andFccContractIdIsNull();
		}
		if(CheckUtil.isNotEmpty(getFccContractIdIsNotNull()) && this.getFccContractIdIsNotNull()){
			c.andFccContractIdIsNotNull();
		}
		if(CheckUtil.isNotEmpty(getFccContractIdIn())){
			c.andFccContractIdIn(this.getFccContractIdIn());
		}
		if(CheckUtil.isNotEmpty(getFccContractIdGreaterThanOrEqualTo())){
			c.andFccContractIdGreaterThanOrEqualTo(this.getFccContractIdGreaterThanOrEqualTo());
		}
		if(CheckUtil.isNotEmpty(getFccContractIdGreaterThan())){
			c.andFccContractIdGreaterThan(this.getFccContractIdGreaterThan());
		}
		if(CheckUtil.isNotEmpty(getFccContractIdEqualTo())){
			c.andFccContractIdEqualTo(this.getFccContractIdEqualTo());
		}
		if(CheckUtil.isNotEmpty(getFccContractCarmodelIdNotIn())){
			c.andFccContractCarmodelIdNotIn(this.getFccContractCarmodelIdNotIn());
		}
		if(CheckUtil.isNotEmpty(getFccContractCarmodelIdNotEqualTo())){
			c.andFccContractCarmodelIdNotEqualTo(this.getFccContractCarmodelIdNotEqualTo());
		}
		if(CheckUtil.isNotEmpty(getFccContractCarmodelIdLessThanOrEqualTo())){
			c.andFccContractCarmodelIdLessThanOrEqualTo(this.getFccContractCarmodelIdLessThanOrEqualTo());
		}
		if(CheckUtil.isNotEmpty(getFccContractCarmodelIdLessThan())){
			c.andFccContractCarmodelIdLessThan(this.getFccContractCarmodelIdLessThan());
		}
		if(CheckUtil.isNotEmpty(getFccContractCarmodelIdIsNull()) && this.getFccContractCarmodelIdIsNull()){
			c.andFccContractCarmodelIdIsNull();
		}
		if(CheckUtil.isNotEmpty(getFccContractCarmodelIdIsNotNull()) && this.getFccContractCarmodelIdIsNotNull()){
			c.andFccContractCarmodelIdIsNotNull();
		}
		if(CheckUtil.isNotEmpty(getFccContractCarmodelIdIn())){
			c.andFccContractCarmodelIdIn(this.getFccContractCarmodelIdIn());
		}
		if(CheckUtil.isNotEmpty(getFccContractCarmodelIdGreaterThanOrEqualTo())){
			c.andFccContractCarmodelIdGreaterThanOrEqualTo(this.getFccContractCarmodelIdGreaterThanOrEqualTo());
		}
		if(CheckUtil.isNotEmpty(getFccContractCarmodelIdGreaterThan())){
			c.andFccContractCarmodelIdGreaterThan(this.getFccContractCarmodelIdGreaterThan());
		}
		if(CheckUtil.isNotEmpty(getFccContractCarmodelIdEqualTo())){
			c.andFccContractCarmodelIdEqualTo(this.getFccContractCarmodelIdEqualTo());
		}
		if(CheckUtil.isNotEmpty(getFccCarnumNotIn())){
			c.andFccCarnumNotIn(this.getFccCarnumNotIn());
		}
		if(CheckUtil.isNotEmpty(getFccCarnumNotEqualTo())){
			c.andFccCarnumNotEqualTo(this.getFccCarnumNotEqualTo());
		}
		if(CheckUtil.isNotEmpty(getFccCarnumLessThanOrEqualTo())){
			c.andFccCarnumLessThanOrEqualTo(this.getFccCarnumLessThanOrEqualTo());
		}
		if(CheckUtil.isNotEmpty(getFccCarnumLessThan())){
			c.andFccCarnumLessThan(this.getFccCarnumLessThan());
		}
		if(CheckUtil.isNotEmpty(getFccCarnumIsNull()) && this.getFccCarnumIsNull()){
			c.andFccCarnumIsNull();
		}
		if(CheckUtil.isNotEmpty(getFccCarnumIsNotNull()) && this.getFccCarnumIsNotNull()){
			c.andFccCarnumIsNotNull();
		}
		if(CheckUtil.isNotEmpty(getFccCarnumIn())){
			c.andFccCarnumIn(this.getFccCarnumIn());
		}
		if(CheckUtil.isNotEmpty(getFccCarnumGreaterThanOrEqualTo())){
			c.andFccCarnumGreaterThanOrEqualTo(this.getFccCarnumGreaterThanOrEqualTo());
		}
		if(CheckUtil.isNotEmpty(getFccCarnumGreaterThan())){
			c.andFccCarnumGreaterThan(this.getFccCarnumGreaterThan());
		}
		if(CheckUtil.isNotEmpty(getFccCarnumEqualTo())){
			c.andFccCarnumEqualTo(this.getFccCarnumEqualTo());
		}
		if(CheckUtil.isNotEmpty(getDrNotIn())){
			c.andDrNotIn(this.getDrNotIn());
		}
		if(CheckUtil.isNotEmpty(getDrNotEqualTo())){
			c.andDrNotEqualTo(this.getDrNotEqualTo());
		}
		if(CheckUtil.isNotEmpty(getDrLessThanOrEqualTo())){
			c.andDrLessThanOrEqualTo(this.getDrLessThanOrEqualTo());
		}
		if(CheckUtil.isNotEmpty(getDrLessThan())){
			c.andDrLessThan(this.getDrLessThan());
		}
		if(CheckUtil.isNotEmpty(getDrIsNull()) && this.getDrIsNull()){
			c.andDrIsNull();
		}
		if(CheckUtil.isNotEmpty(getDrIsNotNull()) && this.getDrIsNotNull()){
			c.andDrIsNotNull();
		}
		if(CheckUtil.isNotEmpty(getDrIn())){
			c.andDrIn(this.getDrIn());
		}
		if(CheckUtil.isNotEmpty(getDrGreaterThanOrEqualTo())){
			c.andDrGreaterThanOrEqualTo(this.getDrGreaterThanOrEqualTo());
		}
		if(CheckUtil.isNotEmpty(getDrGreaterThan())){
			c.andDrGreaterThan(this.getDrGreaterThan());
		}
		if(CheckUtil.isNotEmpty(getDrEqualTo())){
			c.andDrEqualTo(this.getDrEqualTo());
		}
		if(CheckUtil.isNotEmpty(getCreateuserNotLike())){
			c.andCreateuserNotLike("%"+this.getCreateuserNotLike()+"%");
		}
		if(CheckUtil.isNotEmpty(getCreateuserNotIn())){
			c.andCreateuserNotIn(this.getCreateuserNotIn());
		}
		if(CheckUtil.isNotEmpty(getCreateuserNotEqualTo())){
			c.andCreateuserNotEqualTo(this.getCreateuserNotEqualTo());
		}
		if(CheckUtil.isNotEmpty(getCreateuserLike())){
			c.andCreateuserLike("%"+this.getCreateuserLike()+"%");
		}
		if(CheckUtil.isNotEmpty(getCreateuserLessThanOrEqualTo())){
			c.andCreateuserLessThanOrEqualTo(this.getCreateuserLessThanOrEqualTo());
		}
		if(CheckUtil.isNotEmpty(getCreateuserLessThan())){
			c.andCreateuserLessThan(this.getCreateuserLessThan());
		}
		if(CheckUtil.isNotEmpty(getCreateuserIsNull()) && this.getCreateuserIsNull()){
			c.andCreateuserIsNull();
		}
		if(CheckUtil.isNotEmpty(getCreateuserIsNotNull()) && this.getCreateuserIsNotNull()){
			c.andCreateuserIsNotNull();
		}
		if(CheckUtil.isNotEmpty(getCreateuserIn())){
			c.andCreateuserIn(this.getCreateuserIn());
		}
		if(CheckUtil.isNotEmpty(getCreateuserGreaterThanOrEqualTo())){
			c.andCreateuserGreaterThanOrEqualTo(this.getCreateuserGreaterThanOrEqualTo());
		}
		if(CheckUtil.isNotEmpty(getCreateuserGreaterThan())){
			c.andCreateuserGreaterThan(this.getCreateuserGreaterThan());
		}
		if(CheckUtil.isNotEmpty(getCreateuserEqualTo())){
			c.andCreateuserEqualTo(this.getCreateuserEqualTo());
		}
		if(CheckUtil.isNotEmpty(getCreatetimeNotIn())){
			c.andCreatetimeNotIn(this.getCreatetimeNotIn());
		}
		if(CheckUtil.isNotEmpty(getCreatetimeNotEqualTo())){
			c.andCreatetimeNotEqualTo(this.getCreatetimeNotEqualTo());
		}
		if(CheckUtil.isNotEmpty(getCreatetimeLessThanOrEqualTo())){
			c.andCreatetimeLessThanOrEqualTo(this.getCreatetimeLessThanOrEqualTo());
		}
		if(CheckUtil.isNotEmpty(getCreatetimeLessThan())){
			c.andCreatetimeLessThan(this.getCreatetimeLessThan());
		}
		if(CheckUtil.isNotEmpty(getCreatetimeIsNull()) && this.getCreatetimeIsNull()){
			c.andCreatetimeIsNull();
		}
		if(CheckUtil.isNotEmpty(getCreatetimeIsNotNull()) && this.getCreatetimeIsNotNull()){
			c.andCreatetimeIsNotNull();
		}
		if(CheckUtil.isNotEmpty(getCreatetimeIn())){
			c.andCreatetimeIn(this.getCreatetimeIn());
		}
		if(CheckUtil.isNotEmpty(getCreatetimeGreaterThanOrEqualTo())){
			c.andCreatetimeGreaterThanOrEqualTo(this.getCreatetimeGreaterThanOrEqualTo());
		}
		if(CheckUtil.isNotEmpty(getCreatetimeGreaterThan())){
			c.andCreatetimeGreaterThan(this.getCreatetimeGreaterThan());
		}
		if(CheckUtil.isNotEmpty(getCreatetimeEqualTo())){
			c.andCreatetimeEqualTo(this.getCreatetimeEqualTo());
		}
		if((this.getSidx()!=null && !this.getSidx().trim().equals("")) && this.getSord()!=null) {
			q.setOrderByClause(""+ this.getSidx()+" "+this.getSord());
		}
		return q;
	}
	public String getUpdateuserNotLike() {
		return updateuserNotLike;
	}
	public void setUpdateuserNotLike(String updateuserNotLike) {
		this.updateuserNotLike = updateuserNotLike;
	}

	public java.util.List getUpdateuserNotIn() {
		return updateuserNotIn;
	}
	public void setUpdateuserNotIn(java.util.List updateuserNotIn) {
		this.updateuserNotIn = updateuserNotIn;
	}

	public String getUpdateuserNotEqualTo() {
		return updateuserNotEqualTo;
	}
	public void setUpdateuserNotEqualTo(String updateuserNotEqualTo) {
		this.updateuserNotEqualTo = updateuserNotEqualTo;
	}

	public String getUpdateuserLike() {
		return updateuserLike;
	}
	public void setUpdateuserLike(String updateuserLike) {
		this.updateuserLike = updateuserLike;
	}

	public String getUpdateuserLessThanOrEqualTo() {
		return updateuserLessThanOrEqualTo;
	}
	public void setUpdateuserLessThanOrEqualTo(String updateuserLessThanOrEqualTo) {
		this.updateuserLessThanOrEqualTo = updateuserLessThanOrEqualTo;
	}

	public String getUpdateuserLessThan() {
		return updateuserLessThan;
	}
	public void setUpdateuserLessThan(String updateuserLessThan) {
		this.updateuserLessThan = updateuserLessThan;
	}

	public Boolean getUpdateuserIsNull() {
		return updateuserIsNull;
	}
	public void setUpdateuserIsNull(Boolean updateuserIsNull) {
		this.updateuserIsNull = updateuserIsNull;
	}

	public Boolean getUpdateuserIsNotNull() {
		return updateuserIsNotNull;
	}
	public void setUpdateuserIsNotNull(Boolean updateuserIsNotNull) {
		this.updateuserIsNotNull = updateuserIsNotNull;
	}

	public java.util.List getUpdateuserIn() {
		return updateuserIn;
	}
	public void setUpdateuserIn(java.util.List updateuserIn) {
		this.updateuserIn = updateuserIn;
	}

	public String getUpdateuserGreaterThanOrEqualTo() {
		return updateuserGreaterThanOrEqualTo;
	}
	public void setUpdateuserGreaterThanOrEqualTo(String updateuserGreaterThanOrEqualTo) {
		this.updateuserGreaterThanOrEqualTo = updateuserGreaterThanOrEqualTo;
	}

	public String getUpdateuserGreaterThan() {
		return updateuserGreaterThan;
	}
	public void setUpdateuserGreaterThan(String updateuserGreaterThan) {
		this.updateuserGreaterThan = updateuserGreaterThan;
	}

	public String getUpdateuserEqualTo() {
		return updateuserEqualTo;
	}
	public void setUpdateuserEqualTo(String updateuserEqualTo) {
		this.updateuserEqualTo = updateuserEqualTo;
	}

	public java.util.List getUpdatetimeNotIn() {
		return updatetimeNotIn;
	}
	public void setUpdatetimeNotIn(java.util.List updatetimeNotIn) {
		this.updatetimeNotIn = updatetimeNotIn;
	}

	public java.util.Date getUpdatetimeNotEqualTo() {
		return updatetimeNotEqualTo;
	}
	public void setUpdatetimeNotEqualTo(java.util.Date updatetimeNotEqualTo) {
		this.updatetimeNotEqualTo = updatetimeNotEqualTo;
	}

	public java.util.Date getUpdatetimeLessThanOrEqualTo() {
		return updatetimeLessThanOrEqualTo;
	}
	public void setUpdatetimeLessThanOrEqualTo(java.util.Date updatetimeLessThanOrEqualTo) {
		this.updatetimeLessThanOrEqualTo = updatetimeLessThanOrEqualTo;
	}

	public java.util.Date getUpdatetimeLessThan() {
		return updatetimeLessThan;
	}
	public void setUpdatetimeLessThan(java.util.Date updatetimeLessThan) {
		this.updatetimeLessThan = updatetimeLessThan;
	}

	public Boolean getUpdatetimeIsNull() {
		return updatetimeIsNull;
	}
	public void setUpdatetimeIsNull(Boolean updatetimeIsNull) {
		this.updatetimeIsNull = updatetimeIsNull;
	}

	public Boolean getUpdatetimeIsNotNull() {
		return updatetimeIsNotNull;
	}
	public void setUpdatetimeIsNotNull(Boolean updatetimeIsNotNull) {
		this.updatetimeIsNotNull = updatetimeIsNotNull;
	}

	public java.util.List getUpdatetimeIn() {
		return updatetimeIn;
	}
	public void setUpdatetimeIn(java.util.List updatetimeIn) {
		this.updatetimeIn = updatetimeIn;
	}

	public java.util.Date getUpdatetimeGreaterThanOrEqualTo() {
		return updatetimeGreaterThanOrEqualTo;
	}
	public void setUpdatetimeGreaterThanOrEqualTo(java.util.Date updatetimeGreaterThanOrEqualTo) {
		this.updatetimeGreaterThanOrEqualTo = updatetimeGreaterThanOrEqualTo;
	}

	public java.util.Date getUpdatetimeGreaterThan() {
		return updatetimeGreaterThan;
	}
	public void setUpdatetimeGreaterThan(java.util.Date updatetimeGreaterThan) {
		this.updatetimeGreaterThan = updatetimeGreaterThan;
	}

	public java.util.Date getUpdatetimeEqualTo() {
		return updatetimeEqualTo;
	}
	public void setUpdatetimeEqualTo(java.util.Date updatetimeEqualTo) {
		this.updatetimeEqualTo = updatetimeEqualTo;
	}

	public String getRemarkNotLike() {
		return remarkNotLike;
	}
	public void setRemarkNotLike(String remarkNotLike) {
		this.remarkNotLike = remarkNotLike;
	}

	public java.util.List getRemarkNotIn() {
		return remarkNotIn;
	}
	public void setRemarkNotIn(java.util.List remarkNotIn) {
		this.remarkNotIn = remarkNotIn;
	}

	public String getRemarkNotEqualTo() {
		return remarkNotEqualTo;
	}
	public void setRemarkNotEqualTo(String remarkNotEqualTo) {
		this.remarkNotEqualTo = remarkNotEqualTo;
	}

	public String getRemarkLike() {
		return remarkLike;
	}
	public void setRemarkLike(String remarkLike) {
		this.remarkLike = remarkLike;
	}

	public String getRemarkLessThanOrEqualTo() {
		return remarkLessThanOrEqualTo;
	}
	public void setRemarkLessThanOrEqualTo(String remarkLessThanOrEqualTo) {
		this.remarkLessThanOrEqualTo = remarkLessThanOrEqualTo;
	}

	public String getRemarkLessThan() {
		return remarkLessThan;
	}
	public void setRemarkLessThan(String remarkLessThan) {
		this.remarkLessThan = remarkLessThan;
	}

	public Boolean getRemarkIsNull() {
		return remarkIsNull;
	}
	public void setRemarkIsNull(Boolean remarkIsNull) {
		this.remarkIsNull = remarkIsNull;
	}

	public Boolean getRemarkIsNotNull() {
		return remarkIsNotNull;
	}
	public void setRemarkIsNotNull(Boolean remarkIsNotNull) {
		this.remarkIsNotNull = remarkIsNotNull;
	}

	public java.util.List getRemarkIn() {
		return remarkIn;
	}
	public void setRemarkIn(java.util.List remarkIn) {
		this.remarkIn = remarkIn;
	}

	public String getRemarkGreaterThanOrEqualTo() {
		return remarkGreaterThanOrEqualTo;
	}
	public void setRemarkGreaterThanOrEqualTo(String remarkGreaterThanOrEqualTo) {
		this.remarkGreaterThanOrEqualTo = remarkGreaterThanOrEqualTo;
	}

	public String getRemarkGreaterThan() {
		return remarkGreaterThan;
	}
	public void setRemarkGreaterThan(String remarkGreaterThan) {
		this.remarkGreaterThan = remarkGreaterThan;
	}

	public String getRemarkEqualTo() {
		return remarkEqualTo;
	}
	public void setRemarkEqualTo(String remarkEqualTo) {
		this.remarkEqualTo = remarkEqualTo;
	}

	public java.util.List getFccIdNotIn() {
		return fccIdNotIn;
	}
	public void setFccIdNotIn(java.util.List fccIdNotIn) {
		this.fccIdNotIn = fccIdNotIn;
	}

	public Long getFccIdNotEqualTo() {
		return fccIdNotEqualTo;
	}
	public void setFccIdNotEqualTo(Long fccIdNotEqualTo) {
		this.fccIdNotEqualTo = fccIdNotEqualTo;
	}

	public Long getFccIdLessThanOrEqualTo() {
		return fccIdLessThanOrEqualTo;
	}
	public void setFccIdLessThanOrEqualTo(Long fccIdLessThanOrEqualTo) {
		this.fccIdLessThanOrEqualTo = fccIdLessThanOrEqualTo;
	}

	public Long getFccIdLessThan() {
		return fccIdLessThan;
	}
	public void setFccIdLessThan(Long fccIdLessThan) {
		this.fccIdLessThan = fccIdLessThan;
	}

	public Boolean getFccIdIsNull() {
		return fccIdIsNull;
	}
	public void setFccIdIsNull(Boolean fccIdIsNull) {
		this.fccIdIsNull = fccIdIsNull;
	}

	public Boolean getFccIdIsNotNull() {
		return fccIdIsNotNull;
	}
	public void setFccIdIsNotNull(Boolean fccIdIsNotNull) {
		this.fccIdIsNotNull = fccIdIsNotNull;
	}

	public java.util.List getFccIdIn() {
		return fccIdIn;
	}
	public void setFccIdIn(java.util.List fccIdIn) {
		this.fccIdIn = fccIdIn;
	}

	public Long getFccIdGreaterThanOrEqualTo() {
		return fccIdGreaterThanOrEqualTo;
	}
	public void setFccIdGreaterThanOrEqualTo(Long fccIdGreaterThanOrEqualTo) {
		this.fccIdGreaterThanOrEqualTo = fccIdGreaterThanOrEqualTo;
	}

	public Long getFccIdGreaterThan() {
		return fccIdGreaterThan;
	}
	public void setFccIdGreaterThan(Long fccIdGreaterThan) {
		this.fccIdGreaterThan = fccIdGreaterThan;
	}

	public Long getFccIdEqualTo() {
		return fccIdEqualTo;
	}
	public void setFccIdEqualTo(Long fccIdEqualTo) {
		this.fccIdEqualTo = fccIdEqualTo;
	}

	public java.util.List getFccContractIdNotIn() {
		return fccContractIdNotIn;
	}
	public void setFccContractIdNotIn(java.util.List fccContractIdNotIn) {
		this.fccContractIdNotIn = fccContractIdNotIn;
	}

	public Long getFccContractIdNotEqualTo() {
		return fccContractIdNotEqualTo;
	}
	public void setFccContractIdNotEqualTo(Long fccContractIdNotEqualTo) {
		this.fccContractIdNotEqualTo = fccContractIdNotEqualTo;
	}

	public Long getFccContractIdLessThanOrEqualTo() {
		return fccContractIdLessThanOrEqualTo;
	}
	public void setFccContractIdLessThanOrEqualTo(Long fccContractIdLessThanOrEqualTo) {
		this.fccContractIdLessThanOrEqualTo = fccContractIdLessThanOrEqualTo;
	}

	public Long getFccContractIdLessThan() {
		return fccContractIdLessThan;
	}
	public void setFccContractIdLessThan(Long fccContractIdLessThan) {
		this.fccContractIdLessThan = fccContractIdLessThan;
	}

	public Boolean getFccContractIdIsNull() {
		return fccContractIdIsNull;
	}
	public void setFccContractIdIsNull(Boolean fccContractIdIsNull) {
		this.fccContractIdIsNull = fccContractIdIsNull;
	}

	public Boolean getFccContractIdIsNotNull() {
		return fccContractIdIsNotNull;
	}
	public void setFccContractIdIsNotNull(Boolean fccContractIdIsNotNull) {
		this.fccContractIdIsNotNull = fccContractIdIsNotNull;
	}

	public java.util.List getFccContractIdIn() {
		return fccContractIdIn;
	}
	public void setFccContractIdIn(java.util.List fccContractIdIn) {
		this.fccContractIdIn = fccContractIdIn;
	}

	public Long getFccContractIdGreaterThanOrEqualTo() {
		return fccContractIdGreaterThanOrEqualTo;
	}
	public void setFccContractIdGreaterThanOrEqualTo(Long fccContractIdGreaterThanOrEqualTo) {
		this.fccContractIdGreaterThanOrEqualTo = fccContractIdGreaterThanOrEqualTo;
	}

	public Long getFccContractIdGreaterThan() {
		return fccContractIdGreaterThan;
	}
	public void setFccContractIdGreaterThan(Long fccContractIdGreaterThan) {
		this.fccContractIdGreaterThan = fccContractIdGreaterThan;
	}

	public Long getFccContractIdEqualTo() {
		return fccContractIdEqualTo;
	}
	public void setFccContractIdEqualTo(Long fccContractIdEqualTo) {
		this.fccContractIdEqualTo = fccContractIdEqualTo;
	}

	public java.util.List getFccContractCarmodelIdNotIn() {
		return fccContractCarmodelIdNotIn;
	}
	public void setFccContractCarmodelIdNotIn(java.util.List fccContractCarmodelIdNotIn) {
		this.fccContractCarmodelIdNotIn = fccContractCarmodelIdNotIn;
	}

	public Long getFccContractCarmodelIdNotEqualTo() {
		return fccContractCarmodelIdNotEqualTo;
	}
	public void setFccContractCarmodelIdNotEqualTo(Long fccContractCarmodelIdNotEqualTo) {
		this.fccContractCarmodelIdNotEqualTo = fccContractCarmodelIdNotEqualTo;
	}

	public Long getFccContractCarmodelIdLessThanOrEqualTo() {
		return fccContractCarmodelIdLessThanOrEqualTo;
	}
	public void setFccContractCarmodelIdLessThanOrEqualTo(Long fccContractCarmodelIdLessThanOrEqualTo) {
		this.fccContractCarmodelIdLessThanOrEqualTo = fccContractCarmodelIdLessThanOrEqualTo;
	}

	public Long getFccContractCarmodelIdLessThan() {
		return fccContractCarmodelIdLessThan;
	}
	public void setFccContractCarmodelIdLessThan(Long fccContractCarmodelIdLessThan) {
		this.fccContractCarmodelIdLessThan = fccContractCarmodelIdLessThan;
	}

	public Boolean getFccContractCarmodelIdIsNull() {
		return fccContractCarmodelIdIsNull;
	}
	public void setFccContractCarmodelIdIsNull(Boolean fccContractCarmodelIdIsNull) {
		this.fccContractCarmodelIdIsNull = fccContractCarmodelIdIsNull;
	}

	public Boolean getFccContractCarmodelIdIsNotNull() {
		return fccContractCarmodelIdIsNotNull;
	}
	public void setFccContractCarmodelIdIsNotNull(Boolean fccContractCarmodelIdIsNotNull) {
		this.fccContractCarmodelIdIsNotNull = fccContractCarmodelIdIsNotNull;
	}

	public java.util.List getFccContractCarmodelIdIn() {
		return fccContractCarmodelIdIn;
	}
	public void setFccContractCarmodelIdIn(java.util.List fccContractCarmodelIdIn) {
		this.fccContractCarmodelIdIn = fccContractCarmodelIdIn;
	}

	public Long getFccContractCarmodelIdGreaterThanOrEqualTo() {
		return fccContractCarmodelIdGreaterThanOrEqualTo;
	}
	public void setFccContractCarmodelIdGreaterThanOrEqualTo(Long fccContractCarmodelIdGreaterThanOrEqualTo) {
		this.fccContractCarmodelIdGreaterThanOrEqualTo = fccContractCarmodelIdGreaterThanOrEqualTo;
	}

	public Long getFccContractCarmodelIdGreaterThan() {
		return fccContractCarmodelIdGreaterThan;
	}
	public void setFccContractCarmodelIdGreaterThan(Long fccContractCarmodelIdGreaterThan) {
		this.fccContractCarmodelIdGreaterThan = fccContractCarmodelIdGreaterThan;
	}

	public Long getFccContractCarmodelIdEqualTo() {
		return fccContractCarmodelIdEqualTo;
	}
	public void setFccContractCarmodelIdEqualTo(Long fccContractCarmodelIdEqualTo) {
		this.fccContractCarmodelIdEqualTo = fccContractCarmodelIdEqualTo;
	}

	public java.util.List getFccCarnumNotIn() {
		return fccCarnumNotIn;
	}
	public void setFccCarnumNotIn(java.util.List fccCarnumNotIn) {
		this.fccCarnumNotIn = fccCarnumNotIn;
	}

	public Integer getFccCarnumNotEqualTo() {
		return fccCarnumNotEqualTo;
	}
	public void setFccCarnumNotEqualTo(Integer fccCarnumNotEqualTo) {
		this.fccCarnumNotEqualTo = fccCarnumNotEqualTo;
	}

	public Integer getFccCarnumLessThanOrEqualTo() {
		return fccCarnumLessThanOrEqualTo;
	}
	public void setFccCarnumLessThanOrEqualTo(Integer fccCarnumLessThanOrEqualTo) {
		this.fccCarnumLessThanOrEqualTo = fccCarnumLessThanOrEqualTo;
	}

	public Integer getFccCarnumLessThan() {
		return fccCarnumLessThan;
	}
	public void setFccCarnumLessThan(Integer fccCarnumLessThan) {
		this.fccCarnumLessThan = fccCarnumLessThan;
	}

	public Boolean getFccCarnumIsNull() {
		return fccCarnumIsNull;
	}
	public void setFccCarnumIsNull(Boolean fccCarnumIsNull) {
		this.fccCarnumIsNull = fccCarnumIsNull;
	}

	public Boolean getFccCarnumIsNotNull() {
		return fccCarnumIsNotNull;
	}
	public void setFccCarnumIsNotNull(Boolean fccCarnumIsNotNull) {
		this.fccCarnumIsNotNull = fccCarnumIsNotNull;
	}

	public java.util.List getFccCarnumIn() {
		return fccCarnumIn;
	}
	public void setFccCarnumIn(java.util.List fccCarnumIn) {
		this.fccCarnumIn = fccCarnumIn;
	}

	public Integer getFccCarnumGreaterThanOrEqualTo() {
		return fccCarnumGreaterThanOrEqualTo;
	}
	public void setFccCarnumGreaterThanOrEqualTo(Integer fccCarnumGreaterThanOrEqualTo) {
		this.fccCarnumGreaterThanOrEqualTo = fccCarnumGreaterThanOrEqualTo;
	}

	public Integer getFccCarnumGreaterThan() {
		return fccCarnumGreaterThan;
	}
	public void setFccCarnumGreaterThan(Integer fccCarnumGreaterThan) {
		this.fccCarnumGreaterThan = fccCarnumGreaterThan;
	}

	public Integer getFccCarnumEqualTo() {
		return fccCarnumEqualTo;
	}
	public void setFccCarnumEqualTo(Integer fccCarnumEqualTo) {
		this.fccCarnumEqualTo = fccCarnumEqualTo;
	}

	public java.util.List getDrNotIn() {
		return drNotIn;
	}
	public void setDrNotIn(java.util.List drNotIn) {
		this.drNotIn = drNotIn;
	}

	public Integer getDrNotEqualTo() {
		return drNotEqualTo;
	}
	public void setDrNotEqualTo(Integer drNotEqualTo) {
		this.drNotEqualTo = drNotEqualTo;
	}

	public Integer getDrLessThanOrEqualTo() {
		return drLessThanOrEqualTo;
	}
	public void setDrLessThanOrEqualTo(Integer drLessThanOrEqualTo) {
		this.drLessThanOrEqualTo = drLessThanOrEqualTo;
	}

	public Integer getDrLessThan() {
		return drLessThan;
	}
	public void setDrLessThan(Integer drLessThan) {
		this.drLessThan = drLessThan;
	}

	public Boolean getDrIsNull() {
		return drIsNull;
	}
	public void setDrIsNull(Boolean drIsNull) {
		this.drIsNull = drIsNull;
	}

	public Boolean getDrIsNotNull() {
		return drIsNotNull;
	}
	public void setDrIsNotNull(Boolean drIsNotNull) {
		this.drIsNotNull = drIsNotNull;
	}

	public java.util.List getDrIn() {
		return drIn;
	}
	public void setDrIn(java.util.List drIn) {
		this.drIn = drIn;
	}

	public Integer getDrGreaterThanOrEqualTo() {
		return drGreaterThanOrEqualTo;
	}
	public void setDrGreaterThanOrEqualTo(Integer drGreaterThanOrEqualTo) {
		this.drGreaterThanOrEqualTo = drGreaterThanOrEqualTo;
	}

	public Integer getDrGreaterThan() {
		return drGreaterThan;
	}
	public void setDrGreaterThan(Integer drGreaterThan) {
		this.drGreaterThan = drGreaterThan;
	}

	public Integer getDrEqualTo() {
		return drEqualTo;
	}
	public void setDrEqualTo(Integer drEqualTo) {
		this.drEqualTo = drEqualTo;
	}

	public String getCreateuserNotLike() {
		return createuserNotLike;
	}
	public void setCreateuserNotLike(String createuserNotLike) {
		this.createuserNotLike = createuserNotLike;
	}

	public java.util.List getCreateuserNotIn() {
		return createuserNotIn;
	}
	public void setCreateuserNotIn(java.util.List createuserNotIn) {
		this.createuserNotIn = createuserNotIn;
	}

	public String getCreateuserNotEqualTo() {
		return createuserNotEqualTo;
	}
	public void setCreateuserNotEqualTo(String createuserNotEqualTo) {
		this.createuserNotEqualTo = createuserNotEqualTo;
	}

	public String getCreateuserLike() {
		return createuserLike;
	}
	public void setCreateuserLike(String createuserLike) {
		this.createuserLike = createuserLike;
	}

	public String getCreateuserLessThanOrEqualTo() {
		return createuserLessThanOrEqualTo;
	}
	public void setCreateuserLessThanOrEqualTo(String createuserLessThanOrEqualTo) {
		this.createuserLessThanOrEqualTo = createuserLessThanOrEqualTo;
	}

	public String getCreateuserLessThan() {
		return createuserLessThan;
	}
	public void setCreateuserLessThan(String createuserLessThan) {
		this.createuserLessThan = createuserLessThan;
	}

	public Boolean getCreateuserIsNull() {
		return createuserIsNull;
	}
	public void setCreateuserIsNull(Boolean createuserIsNull) {
		this.createuserIsNull = createuserIsNull;
	}

	public Boolean getCreateuserIsNotNull() {
		return createuserIsNotNull;
	}
	public void setCreateuserIsNotNull(Boolean createuserIsNotNull) {
		this.createuserIsNotNull = createuserIsNotNull;
	}

	public java.util.List getCreateuserIn() {
		return createuserIn;
	}
	public void setCreateuserIn(java.util.List createuserIn) {
		this.createuserIn = createuserIn;
	}

	public String getCreateuserGreaterThanOrEqualTo() {
		return createuserGreaterThanOrEqualTo;
	}
	public void setCreateuserGreaterThanOrEqualTo(String createuserGreaterThanOrEqualTo) {
		this.createuserGreaterThanOrEqualTo = createuserGreaterThanOrEqualTo;
	}

	public String getCreateuserGreaterThan() {
		return createuserGreaterThan;
	}
	public void setCreateuserGreaterThan(String createuserGreaterThan) {
		this.createuserGreaterThan = createuserGreaterThan;
	}

	public String getCreateuserEqualTo() {
		return createuserEqualTo;
	}
	public void setCreateuserEqualTo(String createuserEqualTo) {
		this.createuserEqualTo = createuserEqualTo;
	}

	public java.util.List getCreatetimeNotIn() {
		return createtimeNotIn;
	}
	public void setCreatetimeNotIn(java.util.List createtimeNotIn) {
		this.createtimeNotIn = createtimeNotIn;
	}

	public java.util.Date getCreatetimeNotEqualTo() {
		return createtimeNotEqualTo;
	}
	public void setCreatetimeNotEqualTo(java.util.Date createtimeNotEqualTo) {
		this.createtimeNotEqualTo = createtimeNotEqualTo;
	}

	public java.util.Date getCreatetimeLessThanOrEqualTo() {
		return createtimeLessThanOrEqualTo;
	}
	public void setCreatetimeLessThanOrEqualTo(java.util.Date createtimeLessThanOrEqualTo) {
		this.createtimeLessThanOrEqualTo = createtimeLessThanOrEqualTo;
	}

	public java.util.Date getCreatetimeLessThan() {
		return createtimeLessThan;
	}
	public void setCreatetimeLessThan(java.util.Date createtimeLessThan) {
		this.createtimeLessThan = createtimeLessThan;
	}

	public Boolean getCreatetimeIsNull() {
		return createtimeIsNull;
	}
	public void setCreatetimeIsNull(Boolean createtimeIsNull) {
		this.createtimeIsNull = createtimeIsNull;
	}

	public Boolean getCreatetimeIsNotNull() {
		return createtimeIsNotNull;
	}
	public void setCreatetimeIsNotNull(Boolean createtimeIsNotNull) {
		this.createtimeIsNotNull = createtimeIsNotNull;
	}

	public java.util.List getCreatetimeIn() {
		return createtimeIn;
	}
	public void setCreatetimeIn(java.util.List createtimeIn) {
		this.createtimeIn = createtimeIn;
	}

	public java.util.Date getCreatetimeGreaterThanOrEqualTo() {
		return createtimeGreaterThanOrEqualTo;
	}
	public void setCreatetimeGreaterThanOrEqualTo(java.util.Date createtimeGreaterThanOrEqualTo) {
		this.createtimeGreaterThanOrEqualTo = createtimeGreaterThanOrEqualTo;
	}

	public java.util.Date getCreatetimeGreaterThan() {
		return createtimeGreaterThan;
	}
	public void setCreatetimeGreaterThan(java.util.Date createtimeGreaterThan) {
		this.createtimeGreaterThan = createtimeGreaterThan;
	}

	public java.util.Date getCreatetimeEqualTo() {
		return createtimeEqualTo;
	}
	public void setCreatetimeEqualTo(java.util.Date createtimeEqualTo) {
		this.createtimeEqualTo = createtimeEqualTo;
	}

	public void setSidx(String sidx) {
		this.sidx = sidx;
	}
	public String getSord() {
		return sord;
	}
	public void setSord(String sord) {
		 this.sord = sord;
	}
}
