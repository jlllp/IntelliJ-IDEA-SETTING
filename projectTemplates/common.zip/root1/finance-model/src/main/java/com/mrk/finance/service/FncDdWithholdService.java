package com.mrk.finance.service;

import com.github.pagehelper.PageInfo;
import com.mrk.finance.model.FncDdWithhold;
import com.mrk.finance.queryvo.FncDdWithholdQueryVo;

import java.util.List;

/**
 * @Description: FncDdWithhold
 */
public interface FncDdWithholdService {
    /**
     * 分页查询
     *
     * @param queryVo 前端查询对象
     * @return 分页查询数据
     */
    PageInfo<FncDdWithhold> page(FncDdWithholdQueryVo queryVo);

    /**
     * 列表查询
     * @param queryVo 前端查询对象
     * @return 分页查询数据
     */
    List<FncDdWithhold> list(FncDdWithholdQueryVo queryVo);

    /**
     * 新增
     *
     * @param entity
     * @return 结果
     */
    int add(FncDdWithhold entity);

    /**
     * 修改
     *
     * @param entity
     * @return 结果
     */
    int update(FncDdWithhold entity);

    /**
     * 删除
     */
    int delete(Long id);

    /**
     * 通过ID查询
     * @param id
     */
    FncDdWithhold getById(Long id);

    /**
     * 根据ids查询
     * @author Frank.Tang
     * @return *
     */
    List<FncDdWithhold> getByIds(List<Long> ids);

    /**
     * 通过FncDdWithhold批量新增
     * @param fncDdWithholdList
     * @return
     */
    int insertList(List<FncDdWithhold> fncDdWithholdList);

}
