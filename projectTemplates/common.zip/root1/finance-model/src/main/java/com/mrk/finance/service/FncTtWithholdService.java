package com.mrk.finance.service;

import com.github.pagehelper.PageInfo;
import com.mrk.finance.model.FncTtWithhold;
import com.mrk.finance.queryvo.FncTtWithholdQueryVo;

import java.util.List;

/**
 * @Description: FncTtWithhold
 */
public interface FncTtWithholdService {
    /**
     * 分页查询
     *
     * @param queryVo 前端查询对象
     * @return 分页查询数据
     */
    PageInfo<FncTtWithhold> page(FncTtWithholdQueryVo queryVo);

    /**
     * 列表查询
     * @param queryVo 前端查询对象
     * @return 分页查询数据
     */
    List<FncTtWithhold> list(FncTtWithholdQueryVo queryVo);

    /**
     * 新增
     *
     * @param entity
     * @return 结果
     */
    int add(FncTtWithhold entity);

    /**
     * 修改
     *
     * @param entity
     * @return 结果
     */
    int update(FncTtWithhold entity);

    /**
     * 删除
     */
    int delete(Long id);

    /**
     * 通过ID查询
     * @param id
     */
    FncTtWithhold getById(Long id);

    /**
     * 根据ids查询
     * @author Frank.Tang
     * @return *
     */
    List<FncTtWithhold> getByIds(List<Long> ids);

    /**
     * 批量新增
     * @param fncTtWithholdList
     * @return
     */
    int insertList(List<FncTtWithhold> fncTtWithholdList);

}
