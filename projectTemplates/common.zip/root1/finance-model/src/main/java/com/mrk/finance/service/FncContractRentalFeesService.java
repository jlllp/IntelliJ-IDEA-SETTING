package com.mrk.finance.service;

import com.github.pagehelper.PageInfo;
import com.mrk.finance.example.FncContractRentalFeesExample;
import com.mrk.finance.model.FncContractRentalFees;
import com.mrk.finance.queryvo.FncContractRentalFeesQueryVo;

import java.util.List;

/**
 * @Description: FncContractRentalFees
 */
public interface FncContractRentalFeesService {
    /**
     * 分页查询
     *
     * @param queryVo 前端查询对象
     * @return 分页查询数据
     */
    PageInfo<FncContractRentalFees> page(FncContractRentalFeesQueryVo queryVo);

    /**
     * 列表查询
     *
     * @param queryVo 前端查询对象
     * @return 分页查询数据
     */
    List<FncContractRentalFees> list(FncContractRentalFeesQueryVo queryVo);

    /**
     * 新增
     *
     * @param entity
     * @return 结果
     */
    int add(FncContractRentalFees entity);

    /**
     * @return *
     * @author Frank.Tang
     */
    int addList(List<FncContractRentalFees> contractRentalFeesList);

    /**
     * 修改
     *
     * @param entity
     * @return 结果
     */
    int update(FncContractRentalFees entity);

    /**
     * @return *
     * @author Frank.Tang
     */
    int updateSelective(FncContractRentalFees entity);

    /**
     * @return *
     * @author Frank.Tang
     */
    int updateByExampleSelective(FncContractRentalFees entity, FncContractRentalFeesExample example);

    /**
     * 删除
     */
    int delete(Long id);

    /**
     * 通过ID查询
     *
     * @param id
     */
    FncContractRentalFees getById(Long id);

    /**
     * 根据合同获取租金包含费用明细
     *
     * @param contractId 合同id
     * @return 租金包含费用明细
     */
    List<FncContractRentalFees> getByContractId(Long contractId);
}
