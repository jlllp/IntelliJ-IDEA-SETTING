package com.mrk.finance.service;

import com.github.pagehelper.PageInfo;
import com.mrk.finance.example.FncContractRentExample;
import com.mrk.finance.model.FncContractRent;
import com.mrk.finance.queryvo.FncContractRentQueryVo;

import java.util.List;

/**
 * @Description: FncContractRent
 */
public interface FncContractRentService {
    /**
     * 分页查询
     *
     * @param queryVo 前端查询对象
     * @return 分页查询数据
     */
    PageInfo<FncContractRent> page(FncContractRentQueryVo queryVo);

    /**
     * 列表查询
     * @param queryVo 前端查询对象
     * @return 分页查询数据
     */
    List<FncContractRent> list(FncContractRentQueryVo queryVo);

    /**
     * 新增
     *
     * @param entity
     * @return 结果
     */
    int add(FncContractRent entity);

    /**
     * 批量新增
     * @author Frank.Tang
     * @return *
     */
    int addList(List<FncContractRent> rents);

    /**
     * 修改
     *
     * @param entity
     * @return 结果
     */
    int update(FncContractRent entity);

    /**
     * 修改
     *
     * @param entity
     * @return 结果
     */
    int updateByExampleSelective(FncContractRent entity, FncContractRentExample example);

    /**
     * 删除
     */
    int delete(Long id);

    /**
    * 通过ID查询
    * @param id
    */
    FncContractRent getById(Long id);

    /**
     * @author Bob
     * @date 2021/11/22
     * @description 通过合同id获取合同租金
     * @param contractId 合同Id
     * @return 合同对应的租金
     */
    List<FncContractRent> getByContractId(Long contractId);
}
