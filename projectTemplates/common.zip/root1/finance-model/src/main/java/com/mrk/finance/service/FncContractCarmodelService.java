package com.mrk.finance.service;

import com.github.pagehelper.PageInfo;
import com.mrk.finance.model.FncContractCarmodel;
import com.mrk.finance.queryvo.FncContractCarmodelQueryVo;

import java.util.List;

/**
 * @Description: FncContractCarmodel
 */
public interface FncContractCarmodelService {
    /**
     * 分页查询
     *
     * @param queryVo 前端查询对象
     * @return 分页查询数据
     */
    PageInfo<FncContractCarmodel> page(FncContractCarmodelQueryVo queryVo);

    /**
     * 列表查询
     * @param queryVo 前端查询对象
     * @return 分页查询数据
     */
    List<FncContractCarmodel> list(FncContractCarmodelQueryVo queryVo);

    /**
     * 批量查询, 根据合同ids, 并分组
     * @author Frank.Tang
     * @return 分页查询数据
     */
    List<FncContractCarmodel> batchSelectByContractIds(List<Long> ids);

    /**
     * 新增
     *
     * @param entity
     * @return 结果
     */
    int add(FncContractCarmodel entity);

    /**
     * 批量新增
     * @author Frank.Tang
     * @return *
     */
    int addList(List<FncContractCarmodel> carmodels);

    /**
     * 修改
     *
     * @param entity
     * @return 结果
     */
    int update(FncContractCarmodel entity);

    /**
     * @author Frank.Tang
     * @return *
     */
    int updateSelective(FncContractCarmodel entity);

    /**
     * 删除
     */
    int delete(Long id);

    /**
     * 通过ID查询
     * @param id
     */
    FncContractCarmodel getById(Long id);

    /**
     * 通过合同ID查询
     * @param fncContractManagementId
     */
    List<FncContractCarmodel> selectByFncContractManagementId(Long fncContractManagementId);

}
