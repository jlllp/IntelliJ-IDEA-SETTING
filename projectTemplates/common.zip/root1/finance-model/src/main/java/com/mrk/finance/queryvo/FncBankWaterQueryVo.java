package com.mrk.finance.queryvo;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.mrk.common.base.BaseQueryVo;
import io.swagger.annotations.ApiModelProperty;
import lombok.Getter;
import lombok.Setter;
import org.springframework.format.annotation.DateTimeFormat;

import java.util.List;

@Setter
@Getter
public class FncBankWaterQueryVo extends BaseQueryVo {



    @ApiModelProperty(value = "主键 精确匹配")
    private Long fbwIdEqualTo;

    @ApiModelProperty(value = "主键 模糊匹配")
    private Long fbwIdLike;


    @ApiModelProperty(value = "凭证号 精确匹配")
    private String fbwVoucherNoEqualTo;

    @ApiModelProperty(value = "凭证号 模糊匹配")
    private String fbwVoucherNoLike;


    @ApiModelProperty(value = "本方账号 精确匹配")
    private String fbwOwnAccountEqualTo;

    @ApiModelProperty(value = "本方账号 模糊匹配")
    private String fbwOwnAccountLike;


    @ApiModelProperty(value = "对方账号 精确匹配")
    private String fbwOtherAccountEqualTo;

    @ApiModelProperty(value = "对方账号 模糊匹配")
    private String fbwOtherAccountLike;


    @ApiModelProperty(value = "对方单位名称 精确匹配")
    private String fbwOtherUnitNameEqualTo;

    @ApiModelProperty(value = "对方单位名称 模糊匹配")
    private String fbwOtherUnitNameLike;


    @ApiModelProperty(value = "借/贷 精确匹配")
    private Integer fbwLoanTypeEqualTo;

    @ApiModelProperty(value = "借/贷 模糊匹配")
    private Integer fbwLoanTypeLike;


    @ApiModelProperty(value = "交易时间 大于或等于")
    @DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss", timezone = "GMT+8")
    private java.util.Date fbwDealTimeGreaterThanOrEqualTo;

    @DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss", timezone = "GMT+8")
    @ApiModelProperty(value = "交易时间 小于或等于")
    private java.util.Date fbwDealTimeLessThanOrEqualTo;
    @ApiModelProperty(value = "交易时间 精确匹配")
    private java.util.Date fbwDealTimeEqualTo;

    @ApiModelProperty(value = "交易时间 模糊匹配")
    private java.util.Date fbwDealTimeLike;


    @ApiModelProperty(value = "借方发生额 精确匹配")
    private Double fbwBorrowAmountEqualTo;

    @ApiModelProperty(value = "借方发生额 模糊匹配")
    private Double fbwBorrowAmountLike;


    @ApiModelProperty(value = "贷方发生额 精确匹配")
    private Double fbwCreditAmountEqualTo;

    @ApiModelProperty(value = "贷方发生额 模糊匹配")
    private Double fbwCreditAmountLike;


    @ApiModelProperty(value = "用途 精确匹配")
    private String fbwUseEqualTo;

    @ApiModelProperty(value = "用途 模糊匹配")
    private String fbwUseLike;


    @ApiModelProperty(value = "摘要 精确匹配")
    private String fbwDigestEqualTo;

    @ApiModelProperty(value = "摘要 模糊匹配")
    private String fbwDigestLike;


    @ApiModelProperty(value = "个性化信息 精确匹配")
    private String fbwPersonalizedInformationEqualTo;

    @ApiModelProperty(value = "个性化信息 模糊匹配")
    private String fbwPersonalizedInformationLike;


    @ApiModelProperty(value = "匹配状态 精确匹配")
    private Integer fbwMatchStateEqualTo;
    private List<Integer> fbwMatchStateIn;

    @ApiModelProperty(value = "匹配状态 模糊匹配")
    private Integer fbwMatchStateLike;


    @ApiModelProperty(value = "匹配账单 精确匹配")
    private String fbwMatchBillEqualTo;

    @ApiModelProperty(value = "匹配账单 模糊匹配")
    private String fbwMatchBillLike;


    @ApiModelProperty(value = "匹配方式 精确匹配")
    private Integer fbwMatchTypeEqualTo;

    @ApiModelProperty(value = "匹配方式 模糊匹配")
    private Integer fbwMatchTypeLike;


    @ApiModelProperty(value = "已匹配金额 精确匹配")
    private Double fbwMatchedAmountEqualTo;

    @ApiModelProperty(value = "已匹配金额 模糊匹配")
    private Double fbwMatchedAmountLike;


    @ApiModelProperty(value = "未匹配金额 精确匹配")
    private Double fbwNotMatchAmountEqualTo;

    @ApiModelProperty(value = "未匹配金额 模糊匹配")
    private Double fbwNotMatchAmountLike;
    }
