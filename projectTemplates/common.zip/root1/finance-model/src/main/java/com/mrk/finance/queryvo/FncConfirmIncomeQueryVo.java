package com.mrk.finance.queryvo;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.mrk.common.base.BaseQueryVo;
import io.swagger.annotations.ApiModelProperty;
import lombok.Getter;
import lombok.Setter;
import org.springframework.format.annotation.DateTimeFormat;

@Setter
@Getter
public class FncConfirmIncomeQueryVo extends BaseQueryVo {



    @ApiModelProperty(value = "主键 精确匹配")
    private Long fciIdEqualTo;

    @ApiModelProperty(value = "主键 模糊匹配")
    private Long fciIdLike;


    @ApiModelProperty(value = "资产所有者 精确匹配")
    private Long fciDeptIdEqualTo;

    @ApiModelProperty(value = "资产所有者 模糊匹配")
    private Long fciDeptIdLike;


    @ApiModelProperty(value = "收入时间 大于或等于")
    @DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss", timezone = "GMT+8")
    private java.util.Date fciIncomeMonthGreaterThanOrEqualTo;

    @DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss", timezone = "GMT+8")
    @ApiModelProperty(value = "收入时间 小于或等于")
    private java.util.Date fciIncomeMonthLessThanOrEqualTo;
    @DateTimeFormat(pattern = "yyyy-MM")
    @JsonFormat(pattern = "yyyy-MM", timezone = "GMT+8")
    @ApiModelProperty(value = "收入时间 精确匹配")
    private java.util.Date fciIncomeMonthEqualTo;

    @ApiModelProperty(value = "收入时间 模糊匹配")
    private java.util.Date fciIncomeMonthLike;


    @ApiModelProperty(value = "租金收入 精确匹配")
    private Double fciRentIncomeEqualTo;

    @ApiModelProperty(value = "租金收入 模糊匹配")
    private Double fciRentIncomeLike;

    @ApiModelProperty(value = "租金收入 小于或等于")
    private Double fciRentIncomeLessThanOrEqualTo;

    @ApiModelProperty(value = "租金收入 大于或等于")
    private Double fciRentIncomeGreaterThanOrEqualTo;


    @ApiModelProperty(value = "违约金收入 精确匹配")
    private Double fciPenaltyIncomeEqualTo;

    @ApiModelProperty(value = "违约金收入 模糊匹配")
    private Double fciPenaltyIncomeLike;

    @ApiModelProperty(value = "违约金收入 小于或等于")
    private Double fciPenaltyIncomeLessThanOrEqualTo;

    @ApiModelProperty(value = "违约金收入 大于或等于")
    private Double fciPenaltyIncomeGreaterThanOrEqualTo;


    @ApiModelProperty(value = "购车尾款收入 精确匹配")
    private Double fciCarPurchaseIncomeEqualTo;

    @ApiModelProperty(value = "购车尾款收入 模糊匹配")
    private Double fciCarPurchaseIncomeLike;

    @ApiModelProperty(value = "购车尾款收入 小于或等于")
    private Double fciCarPurchaseIncomeLessThanOrEqualTo;

    @ApiModelProperty(value = "购车尾款收入 大于或等于")
    private Double fciCarPurchaseIncomeGreaterThanOrEqualTo;


    @ApiModelProperty(value = "合计收入 精确匹配")
    private Double fciTotalIncomeEqualTo;

    @ApiModelProperty(value = "合计收入 模糊匹配")
    private Double fciTotalIncomeLike;

    @ApiModelProperty(value = "合计收入 小于或等于")
    private Double fciTotalIncomeLessThanOrEqualTo;

    @ApiModelProperty(value = "合计收入 大于或等于")
    private Double fciTotalIncomeGreaterThanOrEqualTo;
    }
