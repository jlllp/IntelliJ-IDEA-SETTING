package com.mrk.finance.query;
import com.mrk.common.utils.text.CheckUtil;

/**
 * @author 自动生成工具
 * @date   2021/11/10
 */
public class FncContractRentalFeesQuery {
	private String updateuserNotLike;
	private java.util.List updateuserNotIn;
	private String updateuserNotEqualTo;
	private String updateuserLike;
	private String updateuserLessThanOrEqualTo;
	private String updateuserLessThan;
	private Boolean updateuserIsNull;
	private Boolean updateuserIsNotNull;
	private java.util.List updateuserIn;
	private String updateuserGreaterThanOrEqualTo;
	private String updateuserGreaterThan;
	private String updateuserEqualTo;
	private java.util.List updatetimeNotIn;
	private java.util.Date updatetimeNotEqualTo;
	private java.util.Date updatetimeLessThanOrEqualTo;
	private java.util.Date updatetimeLessThan;
	private Boolean updatetimeIsNull;
	private Boolean updatetimeIsNotNull;
	private java.util.List updatetimeIn;
	private java.util.Date updatetimeGreaterThanOrEqualTo;
	private java.util.Date updatetimeGreaterThan;
	private java.util.Date updatetimeEqualTo;
	private String remarkNotLike;
	private java.util.List remarkNotIn;
	private String remarkNotEqualTo;
	private String remarkLike;
	private String remarkLessThanOrEqualTo;
	private String remarkLessThan;
	private Boolean remarkIsNull;
	private Boolean remarkIsNotNull;
	private java.util.List remarkIn;
	private String remarkGreaterThanOrEqualTo;
	private String remarkGreaterThan;
	private String remarkEqualTo;
	private java.util.List fcrfWriteNotIn;
	private Integer fcrfWriteNotEqualTo;
	private Integer fcrfWriteLessThanOrEqualTo;
	private Integer fcrfWriteLessThan;
	private Boolean fcrfWriteIsNull;
	private Boolean fcrfWriteIsNotNull;
	private java.util.List fcrfWriteIn;
	private Integer fcrfWriteGreaterThanOrEqualTo;
	private Integer fcrfWriteGreaterThan;
	private Integer fcrfWriteEqualTo;
	private String fcrfValueNotLike;
	private java.util.List fcrfValueNotIn;
	private String fcrfValueNotEqualTo;
	private String fcrfValueLike;
	private String fcrfValueLessThanOrEqualTo;
	private String fcrfValueLessThan;
	private Boolean fcrfValueIsNull;
	private Boolean fcrfValueIsNotNull;
	private java.util.List fcrfValueIn;
	private String fcrfValueGreaterThanOrEqualTo;
	private String fcrfValueGreaterThan;
	private String fcrfValueEqualTo;
	private java.util.List fcrfRentFeesIdNotIn;
	private Long fcrfRentFeesIdNotEqualTo;
	private Long fcrfRentFeesIdLessThanOrEqualTo;
	private Long fcrfRentFeesIdLessThan;
	private Boolean fcrfRentFeesIdIsNull;
	private Boolean fcrfRentFeesIdIsNotNull;
	private java.util.List fcrfRentFeesIdIn;
	private Long fcrfRentFeesIdGreaterThanOrEqualTo;
	private Long fcrfRentFeesIdGreaterThan;
	private Long fcrfRentFeesIdEqualTo;
	private java.util.List fcrfIdNotIn;
	private Long fcrfIdNotEqualTo;
	private Long fcrfIdLessThanOrEqualTo;
	private Long fcrfIdLessThan;
	private Boolean fcrfIdIsNull;
	private Boolean fcrfIdIsNotNull;
	private java.util.List fcrfIdIn;
	private Long fcrfIdGreaterThanOrEqualTo;
	private Long fcrfIdGreaterThan;
	private Long fcrfIdEqualTo;
	private java.util.List fcrfContractIdNotIn;
	private Long fcrfContractIdNotEqualTo;
	private Long fcrfContractIdLessThanOrEqualTo;
	private Long fcrfContractIdLessThan;
	private Boolean fcrfContractIdIsNull;
	private Boolean fcrfContractIdIsNotNull;
	private java.util.List fcrfContractIdIn;
	private Long fcrfContractIdGreaterThanOrEqualTo;
	private Long fcrfContractIdGreaterThan;
	private Long fcrfContractIdEqualTo;
	private java.util.List drNotIn;
	private Integer drNotEqualTo;
	private Integer drLessThanOrEqualTo;
	private Integer drLessThan;
	private Boolean drIsNull;
	private Boolean drIsNotNull;
	private java.util.List drIn;
	private Integer drGreaterThanOrEqualTo;
	private Integer drGreaterThan;
	private Integer drEqualTo;
	private String createuserNotLike;
	private java.util.List createuserNotIn;
	private String createuserNotEqualTo;
	private String createuserLike;
	private String createuserLessThanOrEqualTo;
	private String createuserLessThan;
	private Boolean createuserIsNull;
	private Boolean createuserIsNotNull;
	private java.util.List createuserIn;
	private String createuserGreaterThanOrEqualTo;
	private String createuserGreaterThan;
	private String createuserEqualTo;
	private java.util.List createtimeNotIn;
	private java.util.Date createtimeNotEqualTo;
	private java.util.Date createtimeLessThanOrEqualTo;
	private java.util.Date createtimeLessThan;
	private Boolean createtimeIsNull;
	private Boolean createtimeIsNotNull;
	private java.util.List createtimeIn;
	private java.util.Date createtimeGreaterThanOrEqualTo;
	private java.util.Date createtimeGreaterThan;
	private java.util.Date createtimeEqualTo;
	private String sidx;
	private String sord;
	public String getSidx(){
		if(this.sidx == null){
			return "";
		}
		else if("updateuser".equals(this.sidx)){
			return "updateuser";
		}
		else if("updatetime".equals(this.sidx)){
			return "updatetime";
		}
		else if("remark".equals(this.sidx)){
			return "remark";
		}
		else if("fcrfWrite".equals(this.sidx)){
			return "fcrf_write";
		}
		else if("fcrfValue".equals(this.sidx)){
			return "fcrf_value";
		}
		else if("fcrfRentFeesId".equals(this.sidx)){
			return "fcrf_rent_fees_id";
		}
		else if("fcrfId".equals(this.sidx)){
			return "fcrf_id";
		}
		else if("fcrfContractId".equals(this.sidx)){
			return "fcrf_contract_id";
		}
		else if("dr".equals(this.sidx)){
			return "dr";
		}
		else if("createuser".equals(this.sidx)){
			return "createuser";
		}
		else if("createtime".equals(this.sidx)){
			return "createtime";
		}
		return this.sidx;
	}

	@com.fasterxml.jackson.annotation.JsonIgnore
	public com.mrk.finance.example.FncContractRentalFeesExample getCrieria(){
		com.mrk.finance.example.FncContractRentalFeesExample q = new com.mrk.finance.example.FncContractRentalFeesExample();
		com.mrk.finance.example.FncContractRentalFeesExample.Criteria c = q.createCriteria();
		c.andDrEqualTo(0);
		if(CheckUtil.isNotEmpty(getUpdateuserNotLike())){
			c.andUpdateuserNotLike("%"+this.getUpdateuserNotLike()+"%");
		}
		if(CheckUtil.isNotEmpty(getUpdateuserNotIn())){
			c.andUpdateuserNotIn(this.getUpdateuserNotIn());
		}
		if(CheckUtil.isNotEmpty(getUpdateuserNotEqualTo())){
			c.andUpdateuserNotEqualTo(this.getUpdateuserNotEqualTo());
		}
		if(CheckUtil.isNotEmpty(getUpdateuserLike())){
			c.andUpdateuserLike("%"+this.getUpdateuserLike()+"%");
		}
		if(CheckUtil.isNotEmpty(getUpdateuserLessThanOrEqualTo())){
			c.andUpdateuserLessThanOrEqualTo(this.getUpdateuserLessThanOrEqualTo());
		}
		if(CheckUtil.isNotEmpty(getUpdateuserLessThan())){
			c.andUpdateuserLessThan(this.getUpdateuserLessThan());
		}
		if(CheckUtil.isNotEmpty(getUpdateuserIsNull()) && this.getUpdateuserIsNull()){
			c.andUpdateuserIsNull();
		}
		if(CheckUtil.isNotEmpty(getUpdateuserIsNotNull()) && this.getUpdateuserIsNotNull()){
			c.andUpdateuserIsNotNull();
		}
		if(CheckUtil.isNotEmpty(getUpdateuserIn())){
			c.andUpdateuserIn(this.getUpdateuserIn());
		}
		if(CheckUtil.isNotEmpty(getUpdateuserGreaterThanOrEqualTo())){
			c.andUpdateuserGreaterThanOrEqualTo(this.getUpdateuserGreaterThanOrEqualTo());
		}
		if(CheckUtil.isNotEmpty(getUpdateuserGreaterThan())){
			c.andUpdateuserGreaterThan(this.getUpdateuserGreaterThan());
		}
		if(CheckUtil.isNotEmpty(getUpdateuserEqualTo())){
			c.andUpdateuserEqualTo(this.getUpdateuserEqualTo());
		}
		if(CheckUtil.isNotEmpty(getUpdatetimeNotIn())){
			c.andUpdatetimeNotIn(this.getUpdatetimeNotIn());
		}
		if(CheckUtil.isNotEmpty(getUpdatetimeNotEqualTo())){
			c.andUpdatetimeNotEqualTo(this.getUpdatetimeNotEqualTo());
		}
		if(CheckUtil.isNotEmpty(getUpdatetimeLessThanOrEqualTo())){
			c.andUpdatetimeLessThanOrEqualTo(this.getUpdatetimeLessThanOrEqualTo());
		}
		if(CheckUtil.isNotEmpty(getUpdatetimeLessThan())){
			c.andUpdatetimeLessThan(this.getUpdatetimeLessThan());
		}
		if(CheckUtil.isNotEmpty(getUpdatetimeIsNull()) && this.getUpdatetimeIsNull()){
			c.andUpdatetimeIsNull();
		}
		if(CheckUtil.isNotEmpty(getUpdatetimeIsNotNull()) && this.getUpdatetimeIsNotNull()){
			c.andUpdatetimeIsNotNull();
		}
		if(CheckUtil.isNotEmpty(getUpdatetimeIn())){
			c.andUpdatetimeIn(this.getUpdatetimeIn());
		}
		if(CheckUtil.isNotEmpty(getUpdatetimeGreaterThanOrEqualTo())){
			c.andUpdatetimeGreaterThanOrEqualTo(this.getUpdatetimeGreaterThanOrEqualTo());
		}
		if(CheckUtil.isNotEmpty(getUpdatetimeGreaterThan())){
			c.andUpdatetimeGreaterThan(this.getUpdatetimeGreaterThan());
		}
		if(CheckUtil.isNotEmpty(getUpdatetimeEqualTo())){
			c.andUpdatetimeEqualTo(this.getUpdatetimeEqualTo());
		}
		if(CheckUtil.isNotEmpty(getRemarkNotLike())){
			c.andRemarkNotLike("%"+this.getRemarkNotLike()+"%");
		}
		if(CheckUtil.isNotEmpty(getRemarkNotIn())){
			c.andRemarkNotIn(this.getRemarkNotIn());
		}
		if(CheckUtil.isNotEmpty(getRemarkNotEqualTo())){
			c.andRemarkNotEqualTo(this.getRemarkNotEqualTo());
		}
		if(CheckUtil.isNotEmpty(getRemarkLike())){
			c.andRemarkLike("%"+this.getRemarkLike()+"%");
		}
		if(CheckUtil.isNotEmpty(getRemarkLessThanOrEqualTo())){
			c.andRemarkLessThanOrEqualTo(this.getRemarkLessThanOrEqualTo());
		}
		if(CheckUtil.isNotEmpty(getRemarkLessThan())){
			c.andRemarkLessThan(this.getRemarkLessThan());
		}
		if(CheckUtil.isNotEmpty(getRemarkIsNull()) && this.getRemarkIsNull()){
			c.andRemarkIsNull();
		}
		if(CheckUtil.isNotEmpty(getRemarkIsNotNull()) && this.getRemarkIsNotNull()){
			c.andRemarkIsNotNull();
		}
		if(CheckUtil.isNotEmpty(getRemarkIn())){
			c.andRemarkIn(this.getRemarkIn());
		}
		if(CheckUtil.isNotEmpty(getRemarkGreaterThanOrEqualTo())){
			c.andRemarkGreaterThanOrEqualTo(this.getRemarkGreaterThanOrEqualTo());
		}
		if(CheckUtil.isNotEmpty(getRemarkGreaterThan())){
			c.andRemarkGreaterThan(this.getRemarkGreaterThan());
		}
		if(CheckUtil.isNotEmpty(getRemarkEqualTo())){
			c.andRemarkEqualTo(this.getRemarkEqualTo());
		}
		if(CheckUtil.isNotEmpty(getFcrfWriteNotIn())){
			c.andFcrfWriteNotIn(this.getFcrfWriteNotIn());
		}
		if(CheckUtil.isNotEmpty(getFcrfWriteNotEqualTo())){
			c.andFcrfWriteNotEqualTo(this.getFcrfWriteNotEqualTo());
		}
		if(CheckUtil.isNotEmpty(getFcrfWriteLessThanOrEqualTo())){
			c.andFcrfWriteLessThanOrEqualTo(this.getFcrfWriteLessThanOrEqualTo());
		}
		if(CheckUtil.isNotEmpty(getFcrfWriteLessThan())){
			c.andFcrfWriteLessThan(this.getFcrfWriteLessThan());
		}
		if(CheckUtil.isNotEmpty(getFcrfWriteIsNull()) && this.getFcrfWriteIsNull()){
			c.andFcrfWriteIsNull();
		}
		if(CheckUtil.isNotEmpty(getFcrfWriteIsNotNull()) && this.getFcrfWriteIsNotNull()){
			c.andFcrfWriteIsNotNull();
		}
		if(CheckUtil.isNotEmpty(getFcrfWriteIn())){
			c.andFcrfWriteIn(this.getFcrfWriteIn());
		}
		if(CheckUtil.isNotEmpty(getFcrfWriteGreaterThanOrEqualTo())){
			c.andFcrfWriteGreaterThanOrEqualTo(this.getFcrfWriteGreaterThanOrEqualTo());
		}
		if(CheckUtil.isNotEmpty(getFcrfWriteGreaterThan())){
			c.andFcrfWriteGreaterThan(this.getFcrfWriteGreaterThan());
		}
		if(CheckUtil.isNotEmpty(getFcrfWriteEqualTo())){
			c.andFcrfWriteEqualTo(this.getFcrfWriteEqualTo());
		}
		if(CheckUtil.isNotEmpty(getFcrfValueNotLike())){
			c.andFcrfValueNotLike("%"+this.getFcrfValueNotLike()+"%");
		}
		if(CheckUtil.isNotEmpty(getFcrfValueNotIn())){
			c.andFcrfValueNotIn(this.getFcrfValueNotIn());
		}
		if(CheckUtil.isNotEmpty(getFcrfValueNotEqualTo())){
			c.andFcrfValueNotEqualTo(this.getFcrfValueNotEqualTo());
		}
		if(CheckUtil.isNotEmpty(getFcrfValueLike())){
			c.andFcrfValueLike("%"+this.getFcrfValueLike()+"%");
		}
		if(CheckUtil.isNotEmpty(getFcrfValueLessThanOrEqualTo())){
			c.andFcrfValueLessThanOrEqualTo(this.getFcrfValueLessThanOrEqualTo());
		}
		if(CheckUtil.isNotEmpty(getFcrfValueLessThan())){
			c.andFcrfValueLessThan(this.getFcrfValueLessThan());
		}
		if(CheckUtil.isNotEmpty(getFcrfValueIsNull()) && this.getFcrfValueIsNull()){
			c.andFcrfValueIsNull();
		}
		if(CheckUtil.isNotEmpty(getFcrfValueIsNotNull()) && this.getFcrfValueIsNotNull()){
			c.andFcrfValueIsNotNull();
		}
		if(CheckUtil.isNotEmpty(getFcrfValueIn())){
			c.andFcrfValueIn(this.getFcrfValueIn());
		}
		if(CheckUtil.isNotEmpty(getFcrfValueGreaterThanOrEqualTo())){
			c.andFcrfValueGreaterThanOrEqualTo(this.getFcrfValueGreaterThanOrEqualTo());
		}
		if(CheckUtil.isNotEmpty(getFcrfValueGreaterThan())){
			c.andFcrfValueGreaterThan(this.getFcrfValueGreaterThan());
		}
		if(CheckUtil.isNotEmpty(getFcrfValueEqualTo())){
			c.andFcrfValueEqualTo(this.getFcrfValueEqualTo());
		}
		if(CheckUtil.isNotEmpty(getFcrfRentFeesIdNotIn())){
			c.andFcrfRentFeesIdNotIn(this.getFcrfRentFeesIdNotIn());
		}
		if(CheckUtil.isNotEmpty(getFcrfRentFeesIdNotEqualTo())){
			c.andFcrfRentFeesIdNotEqualTo(this.getFcrfRentFeesIdNotEqualTo());
		}
		if(CheckUtil.isNotEmpty(getFcrfRentFeesIdLessThanOrEqualTo())){
			c.andFcrfRentFeesIdLessThanOrEqualTo(this.getFcrfRentFeesIdLessThanOrEqualTo());
		}
		if(CheckUtil.isNotEmpty(getFcrfRentFeesIdLessThan())){
			c.andFcrfRentFeesIdLessThan(this.getFcrfRentFeesIdLessThan());
		}
		if(CheckUtil.isNotEmpty(getFcrfRentFeesIdIsNull()) && this.getFcrfRentFeesIdIsNull()){
			c.andFcrfRentFeesIdIsNull();
		}
		if(CheckUtil.isNotEmpty(getFcrfRentFeesIdIsNotNull()) && this.getFcrfRentFeesIdIsNotNull()){
			c.andFcrfRentFeesIdIsNotNull();
		}
		if(CheckUtil.isNotEmpty(getFcrfRentFeesIdIn())){
			c.andFcrfRentFeesIdIn(this.getFcrfRentFeesIdIn());
		}
		if(CheckUtil.isNotEmpty(getFcrfRentFeesIdGreaterThanOrEqualTo())){
			c.andFcrfRentFeesIdGreaterThanOrEqualTo(this.getFcrfRentFeesIdGreaterThanOrEqualTo());
		}
		if(CheckUtil.isNotEmpty(getFcrfRentFeesIdGreaterThan())){
			c.andFcrfRentFeesIdGreaterThan(this.getFcrfRentFeesIdGreaterThan());
		}
		if(CheckUtil.isNotEmpty(getFcrfRentFeesIdEqualTo())){
			c.andFcrfRentFeesIdEqualTo(this.getFcrfRentFeesIdEqualTo());
		}
		if(CheckUtil.isNotEmpty(getFcrfIdNotIn())){
			c.andFcrfIdNotIn(this.getFcrfIdNotIn());
		}
		if(CheckUtil.isNotEmpty(getFcrfIdNotEqualTo())){
			c.andFcrfIdNotEqualTo(this.getFcrfIdNotEqualTo());
		}
		if(CheckUtil.isNotEmpty(getFcrfIdLessThanOrEqualTo())){
			c.andFcrfIdLessThanOrEqualTo(this.getFcrfIdLessThanOrEqualTo());
		}
		if(CheckUtil.isNotEmpty(getFcrfIdLessThan())){
			c.andFcrfIdLessThan(this.getFcrfIdLessThan());
		}
		if(CheckUtil.isNotEmpty(getFcrfIdIsNull()) && this.getFcrfIdIsNull()){
			c.andFcrfIdIsNull();
		}
		if(CheckUtil.isNotEmpty(getFcrfIdIsNotNull()) && this.getFcrfIdIsNotNull()){
			c.andFcrfIdIsNotNull();
		}
		if(CheckUtil.isNotEmpty(getFcrfIdIn())){
			c.andFcrfIdIn(this.getFcrfIdIn());
		}
		if(CheckUtil.isNotEmpty(getFcrfIdGreaterThanOrEqualTo())){
			c.andFcrfIdGreaterThanOrEqualTo(this.getFcrfIdGreaterThanOrEqualTo());
		}
		if(CheckUtil.isNotEmpty(getFcrfIdGreaterThan())){
			c.andFcrfIdGreaterThan(this.getFcrfIdGreaterThan());
		}
		if(CheckUtil.isNotEmpty(getFcrfIdEqualTo())){
			c.andFcrfIdEqualTo(this.getFcrfIdEqualTo());
		}
		if(CheckUtil.isNotEmpty(getFcrfContractIdNotIn())){
			c.andFcrfContractIdNotIn(this.getFcrfContractIdNotIn());
		}
		if(CheckUtil.isNotEmpty(getFcrfContractIdNotEqualTo())){
			c.andFcrfContractIdNotEqualTo(this.getFcrfContractIdNotEqualTo());
		}
		if(CheckUtil.isNotEmpty(getFcrfContractIdLessThanOrEqualTo())){
			c.andFcrfContractIdLessThanOrEqualTo(this.getFcrfContractIdLessThanOrEqualTo());
		}
		if(CheckUtil.isNotEmpty(getFcrfContractIdLessThan())){
			c.andFcrfContractIdLessThan(this.getFcrfContractIdLessThan());
		}
		if(CheckUtil.isNotEmpty(getFcrfContractIdIsNull()) && this.getFcrfContractIdIsNull()){
			c.andFcrfContractIdIsNull();
		}
		if(CheckUtil.isNotEmpty(getFcrfContractIdIsNotNull()) && this.getFcrfContractIdIsNotNull()){
			c.andFcrfContractIdIsNotNull();
		}
		if(CheckUtil.isNotEmpty(getFcrfContractIdIn())){
			c.andFcrfContractIdIn(this.getFcrfContractIdIn());
		}
		if(CheckUtil.isNotEmpty(getFcrfContractIdGreaterThanOrEqualTo())){
			c.andFcrfContractIdGreaterThanOrEqualTo(this.getFcrfContractIdGreaterThanOrEqualTo());
		}
		if(CheckUtil.isNotEmpty(getFcrfContractIdGreaterThan())){
			c.andFcrfContractIdGreaterThan(this.getFcrfContractIdGreaterThan());
		}
		if(CheckUtil.isNotEmpty(getFcrfContractIdEqualTo())){
			c.andFcrfContractIdEqualTo(this.getFcrfContractIdEqualTo());
		}
		if(CheckUtil.isNotEmpty(getDrNotIn())){
			c.andDrNotIn(this.getDrNotIn());
		}
		if(CheckUtil.isNotEmpty(getDrNotEqualTo())){
			c.andDrNotEqualTo(this.getDrNotEqualTo());
		}
		if(CheckUtil.isNotEmpty(getDrLessThanOrEqualTo())){
			c.andDrLessThanOrEqualTo(this.getDrLessThanOrEqualTo());
		}
		if(CheckUtil.isNotEmpty(getDrLessThan())){
			c.andDrLessThan(this.getDrLessThan());
		}
		if(CheckUtil.isNotEmpty(getDrIsNull()) && this.getDrIsNull()){
			c.andDrIsNull();
		}
		if(CheckUtil.isNotEmpty(getDrIsNotNull()) && this.getDrIsNotNull()){
			c.andDrIsNotNull();
		}
		if(CheckUtil.isNotEmpty(getDrIn())){
			c.andDrIn(this.getDrIn());
		}
		if(CheckUtil.isNotEmpty(getDrGreaterThanOrEqualTo())){
			c.andDrGreaterThanOrEqualTo(this.getDrGreaterThanOrEqualTo());
		}
		if(CheckUtil.isNotEmpty(getDrGreaterThan())){
			c.andDrGreaterThan(this.getDrGreaterThan());
		}
		if(CheckUtil.isNotEmpty(getDrEqualTo())){
			c.andDrEqualTo(this.getDrEqualTo());
		}
		if(CheckUtil.isNotEmpty(getCreateuserNotLike())){
			c.andCreateuserNotLike("%"+this.getCreateuserNotLike()+"%");
		}
		if(CheckUtil.isNotEmpty(getCreateuserNotIn())){
			c.andCreateuserNotIn(this.getCreateuserNotIn());
		}
		if(CheckUtil.isNotEmpty(getCreateuserNotEqualTo())){
			c.andCreateuserNotEqualTo(this.getCreateuserNotEqualTo());
		}
		if(CheckUtil.isNotEmpty(getCreateuserLike())){
			c.andCreateuserLike("%"+this.getCreateuserLike()+"%");
		}
		if(CheckUtil.isNotEmpty(getCreateuserLessThanOrEqualTo())){
			c.andCreateuserLessThanOrEqualTo(this.getCreateuserLessThanOrEqualTo());
		}
		if(CheckUtil.isNotEmpty(getCreateuserLessThan())){
			c.andCreateuserLessThan(this.getCreateuserLessThan());
		}
		if(CheckUtil.isNotEmpty(getCreateuserIsNull()) && this.getCreateuserIsNull()){
			c.andCreateuserIsNull();
		}
		if(CheckUtil.isNotEmpty(getCreateuserIsNotNull()) && this.getCreateuserIsNotNull()){
			c.andCreateuserIsNotNull();
		}
		if(CheckUtil.isNotEmpty(getCreateuserIn())){
			c.andCreateuserIn(this.getCreateuserIn());
		}
		if(CheckUtil.isNotEmpty(getCreateuserGreaterThanOrEqualTo())){
			c.andCreateuserGreaterThanOrEqualTo(this.getCreateuserGreaterThanOrEqualTo());
		}
		if(CheckUtil.isNotEmpty(getCreateuserGreaterThan())){
			c.andCreateuserGreaterThan(this.getCreateuserGreaterThan());
		}
		if(CheckUtil.isNotEmpty(getCreateuserEqualTo())){
			c.andCreateuserEqualTo(this.getCreateuserEqualTo());
		}
		if(CheckUtil.isNotEmpty(getCreatetimeNotIn())){
			c.andCreatetimeNotIn(this.getCreatetimeNotIn());
		}
		if(CheckUtil.isNotEmpty(getCreatetimeNotEqualTo())){
			c.andCreatetimeNotEqualTo(this.getCreatetimeNotEqualTo());
		}
		if(CheckUtil.isNotEmpty(getCreatetimeLessThanOrEqualTo())){
			c.andCreatetimeLessThanOrEqualTo(this.getCreatetimeLessThanOrEqualTo());
		}
		if(CheckUtil.isNotEmpty(getCreatetimeLessThan())){
			c.andCreatetimeLessThan(this.getCreatetimeLessThan());
		}
		if(CheckUtil.isNotEmpty(getCreatetimeIsNull()) && this.getCreatetimeIsNull()){
			c.andCreatetimeIsNull();
		}
		if(CheckUtil.isNotEmpty(getCreatetimeIsNotNull()) && this.getCreatetimeIsNotNull()){
			c.andCreatetimeIsNotNull();
		}
		if(CheckUtil.isNotEmpty(getCreatetimeIn())){
			c.andCreatetimeIn(this.getCreatetimeIn());
		}
		if(CheckUtil.isNotEmpty(getCreatetimeGreaterThanOrEqualTo())){
			c.andCreatetimeGreaterThanOrEqualTo(this.getCreatetimeGreaterThanOrEqualTo());
		}
		if(CheckUtil.isNotEmpty(getCreatetimeGreaterThan())){
			c.andCreatetimeGreaterThan(this.getCreatetimeGreaterThan());
		}
		if(CheckUtil.isNotEmpty(getCreatetimeEqualTo())){
			c.andCreatetimeEqualTo(this.getCreatetimeEqualTo());
		}
		if((this.getSidx()!=null && !this.getSidx().trim().equals("")) && this.getSord()!=null) {
			q.setOrderByClause(""+ this.getSidx()+" "+this.getSord());
		}
		return q;
	}
	public String getUpdateuserNotLike() {
		return updateuserNotLike;
	}
	public void setUpdateuserNotLike(String updateuserNotLike) {
		this.updateuserNotLike = updateuserNotLike;
	}

	public java.util.List getUpdateuserNotIn() {
		return updateuserNotIn;
	}
	public void setUpdateuserNotIn(java.util.List updateuserNotIn) {
		this.updateuserNotIn = updateuserNotIn;
	}

	public String getUpdateuserNotEqualTo() {
		return updateuserNotEqualTo;
	}
	public void setUpdateuserNotEqualTo(String updateuserNotEqualTo) {
		this.updateuserNotEqualTo = updateuserNotEqualTo;
	}

	public String getUpdateuserLike() {
		return updateuserLike;
	}
	public void setUpdateuserLike(String updateuserLike) {
		this.updateuserLike = updateuserLike;
	}

	public String getUpdateuserLessThanOrEqualTo() {
		return updateuserLessThanOrEqualTo;
	}
	public void setUpdateuserLessThanOrEqualTo(String updateuserLessThanOrEqualTo) {
		this.updateuserLessThanOrEqualTo = updateuserLessThanOrEqualTo;
	}

	public String getUpdateuserLessThan() {
		return updateuserLessThan;
	}
	public void setUpdateuserLessThan(String updateuserLessThan) {
		this.updateuserLessThan = updateuserLessThan;
	}

	public Boolean getUpdateuserIsNull() {
		return updateuserIsNull;
	}
	public void setUpdateuserIsNull(Boolean updateuserIsNull) {
		this.updateuserIsNull = updateuserIsNull;
	}

	public Boolean getUpdateuserIsNotNull() {
		return updateuserIsNotNull;
	}
	public void setUpdateuserIsNotNull(Boolean updateuserIsNotNull) {
		this.updateuserIsNotNull = updateuserIsNotNull;
	}

	public java.util.List getUpdateuserIn() {
		return updateuserIn;
	}
	public void setUpdateuserIn(java.util.List updateuserIn) {
		this.updateuserIn = updateuserIn;
	}

	public String getUpdateuserGreaterThanOrEqualTo() {
		return updateuserGreaterThanOrEqualTo;
	}
	public void setUpdateuserGreaterThanOrEqualTo(String updateuserGreaterThanOrEqualTo) {
		this.updateuserGreaterThanOrEqualTo = updateuserGreaterThanOrEqualTo;
	}

	public String getUpdateuserGreaterThan() {
		return updateuserGreaterThan;
	}
	public void setUpdateuserGreaterThan(String updateuserGreaterThan) {
		this.updateuserGreaterThan = updateuserGreaterThan;
	}

	public String getUpdateuserEqualTo() {
		return updateuserEqualTo;
	}
	public void setUpdateuserEqualTo(String updateuserEqualTo) {
		this.updateuserEqualTo = updateuserEqualTo;
	}

	public java.util.List getUpdatetimeNotIn() {
		return updatetimeNotIn;
	}
	public void setUpdatetimeNotIn(java.util.List updatetimeNotIn) {
		this.updatetimeNotIn = updatetimeNotIn;
	}

	public java.util.Date getUpdatetimeNotEqualTo() {
		return updatetimeNotEqualTo;
	}
	public void setUpdatetimeNotEqualTo(java.util.Date updatetimeNotEqualTo) {
		this.updatetimeNotEqualTo = updatetimeNotEqualTo;
	}

	public java.util.Date getUpdatetimeLessThanOrEqualTo() {
		return updatetimeLessThanOrEqualTo;
	}
	public void setUpdatetimeLessThanOrEqualTo(java.util.Date updatetimeLessThanOrEqualTo) {
		this.updatetimeLessThanOrEqualTo = updatetimeLessThanOrEqualTo;
	}

	public java.util.Date getUpdatetimeLessThan() {
		return updatetimeLessThan;
	}
	public void setUpdatetimeLessThan(java.util.Date updatetimeLessThan) {
		this.updatetimeLessThan = updatetimeLessThan;
	}

	public Boolean getUpdatetimeIsNull() {
		return updatetimeIsNull;
	}
	public void setUpdatetimeIsNull(Boolean updatetimeIsNull) {
		this.updatetimeIsNull = updatetimeIsNull;
	}

	public Boolean getUpdatetimeIsNotNull() {
		return updatetimeIsNotNull;
	}
	public void setUpdatetimeIsNotNull(Boolean updatetimeIsNotNull) {
		this.updatetimeIsNotNull = updatetimeIsNotNull;
	}

	public java.util.List getUpdatetimeIn() {
		return updatetimeIn;
	}
	public void setUpdatetimeIn(java.util.List updatetimeIn) {
		this.updatetimeIn = updatetimeIn;
	}

	public java.util.Date getUpdatetimeGreaterThanOrEqualTo() {
		return updatetimeGreaterThanOrEqualTo;
	}
	public void setUpdatetimeGreaterThanOrEqualTo(java.util.Date updatetimeGreaterThanOrEqualTo) {
		this.updatetimeGreaterThanOrEqualTo = updatetimeGreaterThanOrEqualTo;
	}

	public java.util.Date getUpdatetimeGreaterThan() {
		return updatetimeGreaterThan;
	}
	public void setUpdatetimeGreaterThan(java.util.Date updatetimeGreaterThan) {
		this.updatetimeGreaterThan = updatetimeGreaterThan;
	}

	public java.util.Date getUpdatetimeEqualTo() {
		return updatetimeEqualTo;
	}
	public void setUpdatetimeEqualTo(java.util.Date updatetimeEqualTo) {
		this.updatetimeEqualTo = updatetimeEqualTo;
	}

	public String getRemarkNotLike() {
		return remarkNotLike;
	}
	public void setRemarkNotLike(String remarkNotLike) {
		this.remarkNotLike = remarkNotLike;
	}

	public java.util.List getRemarkNotIn() {
		return remarkNotIn;
	}
	public void setRemarkNotIn(java.util.List remarkNotIn) {
		this.remarkNotIn = remarkNotIn;
	}

	public String getRemarkNotEqualTo() {
		return remarkNotEqualTo;
	}
	public void setRemarkNotEqualTo(String remarkNotEqualTo) {
		this.remarkNotEqualTo = remarkNotEqualTo;
	}

	public String getRemarkLike() {
		return remarkLike;
	}
	public void setRemarkLike(String remarkLike) {
		this.remarkLike = remarkLike;
	}

	public String getRemarkLessThanOrEqualTo() {
		return remarkLessThanOrEqualTo;
	}
	public void setRemarkLessThanOrEqualTo(String remarkLessThanOrEqualTo) {
		this.remarkLessThanOrEqualTo = remarkLessThanOrEqualTo;
	}

	public String getRemarkLessThan() {
		return remarkLessThan;
	}
	public void setRemarkLessThan(String remarkLessThan) {
		this.remarkLessThan = remarkLessThan;
	}

	public Boolean getRemarkIsNull() {
		return remarkIsNull;
	}
	public void setRemarkIsNull(Boolean remarkIsNull) {
		this.remarkIsNull = remarkIsNull;
	}

	public Boolean getRemarkIsNotNull() {
		return remarkIsNotNull;
	}
	public void setRemarkIsNotNull(Boolean remarkIsNotNull) {
		this.remarkIsNotNull = remarkIsNotNull;
	}

	public java.util.List getRemarkIn() {
		return remarkIn;
	}
	public void setRemarkIn(java.util.List remarkIn) {
		this.remarkIn = remarkIn;
	}

	public String getRemarkGreaterThanOrEqualTo() {
		return remarkGreaterThanOrEqualTo;
	}
	public void setRemarkGreaterThanOrEqualTo(String remarkGreaterThanOrEqualTo) {
		this.remarkGreaterThanOrEqualTo = remarkGreaterThanOrEqualTo;
	}

	public String getRemarkGreaterThan() {
		return remarkGreaterThan;
	}
	public void setRemarkGreaterThan(String remarkGreaterThan) {
		this.remarkGreaterThan = remarkGreaterThan;
	}

	public String getRemarkEqualTo() {
		return remarkEqualTo;
	}
	public void setRemarkEqualTo(String remarkEqualTo) {
		this.remarkEqualTo = remarkEqualTo;
	}

	public java.util.List getFcrfWriteNotIn() {
		return fcrfWriteNotIn;
	}
	public void setFcrfWriteNotIn(java.util.List fcrfWriteNotIn) {
		this.fcrfWriteNotIn = fcrfWriteNotIn;
	}

	public Integer getFcrfWriteNotEqualTo() {
		return fcrfWriteNotEqualTo;
	}
	public void setFcrfWriteNotEqualTo(Integer fcrfWriteNotEqualTo) {
		this.fcrfWriteNotEqualTo = fcrfWriteNotEqualTo;
	}

	public Integer getFcrfWriteLessThanOrEqualTo() {
		return fcrfWriteLessThanOrEqualTo;
	}
	public void setFcrfWriteLessThanOrEqualTo(Integer fcrfWriteLessThanOrEqualTo) {
		this.fcrfWriteLessThanOrEqualTo = fcrfWriteLessThanOrEqualTo;
	}

	public Integer getFcrfWriteLessThan() {
		return fcrfWriteLessThan;
	}
	public void setFcrfWriteLessThan(Integer fcrfWriteLessThan) {
		this.fcrfWriteLessThan = fcrfWriteLessThan;
	}

	public Boolean getFcrfWriteIsNull() {
		return fcrfWriteIsNull;
	}
	public void setFcrfWriteIsNull(Boolean fcrfWriteIsNull) {
		this.fcrfWriteIsNull = fcrfWriteIsNull;
	}

	public Boolean getFcrfWriteIsNotNull() {
		return fcrfWriteIsNotNull;
	}
	public void setFcrfWriteIsNotNull(Boolean fcrfWriteIsNotNull) {
		this.fcrfWriteIsNotNull = fcrfWriteIsNotNull;
	}

	public java.util.List getFcrfWriteIn() {
		return fcrfWriteIn;
	}
	public void setFcrfWriteIn(java.util.List fcrfWriteIn) {
		this.fcrfWriteIn = fcrfWriteIn;
	}

	public Integer getFcrfWriteGreaterThanOrEqualTo() {
		return fcrfWriteGreaterThanOrEqualTo;
	}
	public void setFcrfWriteGreaterThanOrEqualTo(Integer fcrfWriteGreaterThanOrEqualTo) {
		this.fcrfWriteGreaterThanOrEqualTo = fcrfWriteGreaterThanOrEqualTo;
	}

	public Integer getFcrfWriteGreaterThan() {
		return fcrfWriteGreaterThan;
	}
	public void setFcrfWriteGreaterThan(Integer fcrfWriteGreaterThan) {
		this.fcrfWriteGreaterThan = fcrfWriteGreaterThan;
	}

	public Integer getFcrfWriteEqualTo() {
		return fcrfWriteEqualTo;
	}
	public void setFcrfWriteEqualTo(Integer fcrfWriteEqualTo) {
		this.fcrfWriteEqualTo = fcrfWriteEqualTo;
	}

	public String getFcrfValueNotLike() {
		return fcrfValueNotLike;
	}
	public void setFcrfValueNotLike(String fcrfValueNotLike) {
		this.fcrfValueNotLike = fcrfValueNotLike;
	}

	public java.util.List getFcrfValueNotIn() {
		return fcrfValueNotIn;
	}
	public void setFcrfValueNotIn(java.util.List fcrfValueNotIn) {
		this.fcrfValueNotIn = fcrfValueNotIn;
	}

	public String getFcrfValueNotEqualTo() {
		return fcrfValueNotEqualTo;
	}
	public void setFcrfValueNotEqualTo(String fcrfValueNotEqualTo) {
		this.fcrfValueNotEqualTo = fcrfValueNotEqualTo;
	}

	public String getFcrfValueLike() {
		return fcrfValueLike;
	}
	public void setFcrfValueLike(String fcrfValueLike) {
		this.fcrfValueLike = fcrfValueLike;
	}

	public String getFcrfValueLessThanOrEqualTo() {
		return fcrfValueLessThanOrEqualTo;
	}
	public void setFcrfValueLessThanOrEqualTo(String fcrfValueLessThanOrEqualTo) {
		this.fcrfValueLessThanOrEqualTo = fcrfValueLessThanOrEqualTo;
	}

	public String getFcrfValueLessThan() {
		return fcrfValueLessThan;
	}
	public void setFcrfValueLessThan(String fcrfValueLessThan) {
		this.fcrfValueLessThan = fcrfValueLessThan;
	}

	public Boolean getFcrfValueIsNull() {
		return fcrfValueIsNull;
	}
	public void setFcrfValueIsNull(Boolean fcrfValueIsNull) {
		this.fcrfValueIsNull = fcrfValueIsNull;
	}

	public Boolean getFcrfValueIsNotNull() {
		return fcrfValueIsNotNull;
	}
	public void setFcrfValueIsNotNull(Boolean fcrfValueIsNotNull) {
		this.fcrfValueIsNotNull = fcrfValueIsNotNull;
	}

	public java.util.List getFcrfValueIn() {
		return fcrfValueIn;
	}
	public void setFcrfValueIn(java.util.List fcrfValueIn) {
		this.fcrfValueIn = fcrfValueIn;
	}

	public String getFcrfValueGreaterThanOrEqualTo() {
		return fcrfValueGreaterThanOrEqualTo;
	}
	public void setFcrfValueGreaterThanOrEqualTo(String fcrfValueGreaterThanOrEqualTo) {
		this.fcrfValueGreaterThanOrEqualTo = fcrfValueGreaterThanOrEqualTo;
	}

	public String getFcrfValueGreaterThan() {
		return fcrfValueGreaterThan;
	}
	public void setFcrfValueGreaterThan(String fcrfValueGreaterThan) {
		this.fcrfValueGreaterThan = fcrfValueGreaterThan;
	}

	public String getFcrfValueEqualTo() {
		return fcrfValueEqualTo;
	}
	public void setFcrfValueEqualTo(String fcrfValueEqualTo) {
		this.fcrfValueEqualTo = fcrfValueEqualTo;
	}

	public java.util.List getFcrfRentFeesIdNotIn() {
		return fcrfRentFeesIdNotIn;
	}
	public void setFcrfRentFeesIdNotIn(java.util.List fcrfRentFeesIdNotIn) {
		this.fcrfRentFeesIdNotIn = fcrfRentFeesIdNotIn;
	}

	public Long getFcrfRentFeesIdNotEqualTo() {
		return fcrfRentFeesIdNotEqualTo;
	}
	public void setFcrfRentFeesIdNotEqualTo(Long fcrfRentFeesIdNotEqualTo) {
		this.fcrfRentFeesIdNotEqualTo = fcrfRentFeesIdNotEqualTo;
	}

	public Long getFcrfRentFeesIdLessThanOrEqualTo() {
		return fcrfRentFeesIdLessThanOrEqualTo;
	}
	public void setFcrfRentFeesIdLessThanOrEqualTo(Long fcrfRentFeesIdLessThanOrEqualTo) {
		this.fcrfRentFeesIdLessThanOrEqualTo = fcrfRentFeesIdLessThanOrEqualTo;
	}

	public Long getFcrfRentFeesIdLessThan() {
		return fcrfRentFeesIdLessThan;
	}
	public void setFcrfRentFeesIdLessThan(Long fcrfRentFeesIdLessThan) {
		this.fcrfRentFeesIdLessThan = fcrfRentFeesIdLessThan;
	}

	public Boolean getFcrfRentFeesIdIsNull() {
		return fcrfRentFeesIdIsNull;
	}
	public void setFcrfRentFeesIdIsNull(Boolean fcrfRentFeesIdIsNull) {
		this.fcrfRentFeesIdIsNull = fcrfRentFeesIdIsNull;
	}

	public Boolean getFcrfRentFeesIdIsNotNull() {
		return fcrfRentFeesIdIsNotNull;
	}
	public void setFcrfRentFeesIdIsNotNull(Boolean fcrfRentFeesIdIsNotNull) {
		this.fcrfRentFeesIdIsNotNull = fcrfRentFeesIdIsNotNull;
	}

	public java.util.List getFcrfRentFeesIdIn() {
		return fcrfRentFeesIdIn;
	}
	public void setFcrfRentFeesIdIn(java.util.List fcrfRentFeesIdIn) {
		this.fcrfRentFeesIdIn = fcrfRentFeesIdIn;
	}

	public Long getFcrfRentFeesIdGreaterThanOrEqualTo() {
		return fcrfRentFeesIdGreaterThanOrEqualTo;
	}
	public void setFcrfRentFeesIdGreaterThanOrEqualTo(Long fcrfRentFeesIdGreaterThanOrEqualTo) {
		this.fcrfRentFeesIdGreaterThanOrEqualTo = fcrfRentFeesIdGreaterThanOrEqualTo;
	}

	public Long getFcrfRentFeesIdGreaterThan() {
		return fcrfRentFeesIdGreaterThan;
	}
	public void setFcrfRentFeesIdGreaterThan(Long fcrfRentFeesIdGreaterThan) {
		this.fcrfRentFeesIdGreaterThan = fcrfRentFeesIdGreaterThan;
	}

	public Long getFcrfRentFeesIdEqualTo() {
		return fcrfRentFeesIdEqualTo;
	}
	public void setFcrfRentFeesIdEqualTo(Long fcrfRentFeesIdEqualTo) {
		this.fcrfRentFeesIdEqualTo = fcrfRentFeesIdEqualTo;
	}

	public java.util.List getFcrfIdNotIn() {
		return fcrfIdNotIn;
	}
	public void setFcrfIdNotIn(java.util.List fcrfIdNotIn) {
		this.fcrfIdNotIn = fcrfIdNotIn;
	}

	public Long getFcrfIdNotEqualTo() {
		return fcrfIdNotEqualTo;
	}
	public void setFcrfIdNotEqualTo(Long fcrfIdNotEqualTo) {
		this.fcrfIdNotEqualTo = fcrfIdNotEqualTo;
	}

	public Long getFcrfIdLessThanOrEqualTo() {
		return fcrfIdLessThanOrEqualTo;
	}
	public void setFcrfIdLessThanOrEqualTo(Long fcrfIdLessThanOrEqualTo) {
		this.fcrfIdLessThanOrEqualTo = fcrfIdLessThanOrEqualTo;
	}

	public Long getFcrfIdLessThan() {
		return fcrfIdLessThan;
	}
	public void setFcrfIdLessThan(Long fcrfIdLessThan) {
		this.fcrfIdLessThan = fcrfIdLessThan;
	}

	public Boolean getFcrfIdIsNull() {
		return fcrfIdIsNull;
	}
	public void setFcrfIdIsNull(Boolean fcrfIdIsNull) {
		this.fcrfIdIsNull = fcrfIdIsNull;
	}

	public Boolean getFcrfIdIsNotNull() {
		return fcrfIdIsNotNull;
	}
	public void setFcrfIdIsNotNull(Boolean fcrfIdIsNotNull) {
		this.fcrfIdIsNotNull = fcrfIdIsNotNull;
	}

	public java.util.List getFcrfIdIn() {
		return fcrfIdIn;
	}
	public void setFcrfIdIn(java.util.List fcrfIdIn) {
		this.fcrfIdIn = fcrfIdIn;
	}

	public Long getFcrfIdGreaterThanOrEqualTo() {
		return fcrfIdGreaterThanOrEqualTo;
	}
	public void setFcrfIdGreaterThanOrEqualTo(Long fcrfIdGreaterThanOrEqualTo) {
		this.fcrfIdGreaterThanOrEqualTo = fcrfIdGreaterThanOrEqualTo;
	}

	public Long getFcrfIdGreaterThan() {
		return fcrfIdGreaterThan;
	}
	public void setFcrfIdGreaterThan(Long fcrfIdGreaterThan) {
		this.fcrfIdGreaterThan = fcrfIdGreaterThan;
	}

	public Long getFcrfIdEqualTo() {
		return fcrfIdEqualTo;
	}
	public void setFcrfIdEqualTo(Long fcrfIdEqualTo) {
		this.fcrfIdEqualTo = fcrfIdEqualTo;
	}

	public java.util.List getFcrfContractIdNotIn() {
		return fcrfContractIdNotIn;
	}
	public void setFcrfContractIdNotIn(java.util.List fcrfContractIdNotIn) {
		this.fcrfContractIdNotIn = fcrfContractIdNotIn;
	}

	public Long getFcrfContractIdNotEqualTo() {
		return fcrfContractIdNotEqualTo;
	}
	public void setFcrfContractIdNotEqualTo(Long fcrfContractIdNotEqualTo) {
		this.fcrfContractIdNotEqualTo = fcrfContractIdNotEqualTo;
	}

	public Long getFcrfContractIdLessThanOrEqualTo() {
		return fcrfContractIdLessThanOrEqualTo;
	}
	public void setFcrfContractIdLessThanOrEqualTo(Long fcrfContractIdLessThanOrEqualTo) {
		this.fcrfContractIdLessThanOrEqualTo = fcrfContractIdLessThanOrEqualTo;
	}

	public Long getFcrfContractIdLessThan() {
		return fcrfContractIdLessThan;
	}
	public void setFcrfContractIdLessThan(Long fcrfContractIdLessThan) {
		this.fcrfContractIdLessThan = fcrfContractIdLessThan;
	}

	public Boolean getFcrfContractIdIsNull() {
		return fcrfContractIdIsNull;
	}
	public void setFcrfContractIdIsNull(Boolean fcrfContractIdIsNull) {
		this.fcrfContractIdIsNull = fcrfContractIdIsNull;
	}

	public Boolean getFcrfContractIdIsNotNull() {
		return fcrfContractIdIsNotNull;
	}
	public void setFcrfContractIdIsNotNull(Boolean fcrfContractIdIsNotNull) {
		this.fcrfContractIdIsNotNull = fcrfContractIdIsNotNull;
	}

	public java.util.List getFcrfContractIdIn() {
		return fcrfContractIdIn;
	}
	public void setFcrfContractIdIn(java.util.List fcrfContractIdIn) {
		this.fcrfContractIdIn = fcrfContractIdIn;
	}

	public Long getFcrfContractIdGreaterThanOrEqualTo() {
		return fcrfContractIdGreaterThanOrEqualTo;
	}
	public void setFcrfContractIdGreaterThanOrEqualTo(Long fcrfContractIdGreaterThanOrEqualTo) {
		this.fcrfContractIdGreaterThanOrEqualTo = fcrfContractIdGreaterThanOrEqualTo;
	}

	public Long getFcrfContractIdGreaterThan() {
		return fcrfContractIdGreaterThan;
	}
	public void setFcrfContractIdGreaterThan(Long fcrfContractIdGreaterThan) {
		this.fcrfContractIdGreaterThan = fcrfContractIdGreaterThan;
	}

	public Long getFcrfContractIdEqualTo() {
		return fcrfContractIdEqualTo;
	}
	public void setFcrfContractIdEqualTo(Long fcrfContractIdEqualTo) {
		this.fcrfContractIdEqualTo = fcrfContractIdEqualTo;
	}

	public java.util.List getDrNotIn() {
		return drNotIn;
	}
	public void setDrNotIn(java.util.List drNotIn) {
		this.drNotIn = drNotIn;
	}

	public Integer getDrNotEqualTo() {
		return drNotEqualTo;
	}
	public void setDrNotEqualTo(Integer drNotEqualTo) {
		this.drNotEqualTo = drNotEqualTo;
	}

	public Integer getDrLessThanOrEqualTo() {
		return drLessThanOrEqualTo;
	}
	public void setDrLessThanOrEqualTo(Integer drLessThanOrEqualTo) {
		this.drLessThanOrEqualTo = drLessThanOrEqualTo;
	}

	public Integer getDrLessThan() {
		return drLessThan;
	}
	public void setDrLessThan(Integer drLessThan) {
		this.drLessThan = drLessThan;
	}

	public Boolean getDrIsNull() {
		return drIsNull;
	}
	public void setDrIsNull(Boolean drIsNull) {
		this.drIsNull = drIsNull;
	}

	public Boolean getDrIsNotNull() {
		return drIsNotNull;
	}
	public void setDrIsNotNull(Boolean drIsNotNull) {
		this.drIsNotNull = drIsNotNull;
	}

	public java.util.List getDrIn() {
		return drIn;
	}
	public void setDrIn(java.util.List drIn) {
		this.drIn = drIn;
	}

	public Integer getDrGreaterThanOrEqualTo() {
		return drGreaterThanOrEqualTo;
	}
	public void setDrGreaterThanOrEqualTo(Integer drGreaterThanOrEqualTo) {
		this.drGreaterThanOrEqualTo = drGreaterThanOrEqualTo;
	}

	public Integer getDrGreaterThan() {
		return drGreaterThan;
	}
	public void setDrGreaterThan(Integer drGreaterThan) {
		this.drGreaterThan = drGreaterThan;
	}

	public Integer getDrEqualTo() {
		return drEqualTo;
	}
	public void setDrEqualTo(Integer drEqualTo) {
		this.drEqualTo = drEqualTo;
	}

	public String getCreateuserNotLike() {
		return createuserNotLike;
	}
	public void setCreateuserNotLike(String createuserNotLike) {
		this.createuserNotLike = createuserNotLike;
	}

	public java.util.List getCreateuserNotIn() {
		return createuserNotIn;
	}
	public void setCreateuserNotIn(java.util.List createuserNotIn) {
		this.createuserNotIn = createuserNotIn;
	}

	public String getCreateuserNotEqualTo() {
		return createuserNotEqualTo;
	}
	public void setCreateuserNotEqualTo(String createuserNotEqualTo) {
		this.createuserNotEqualTo = createuserNotEqualTo;
	}

	public String getCreateuserLike() {
		return createuserLike;
	}
	public void setCreateuserLike(String createuserLike) {
		this.createuserLike = createuserLike;
	}

	public String getCreateuserLessThanOrEqualTo() {
		return createuserLessThanOrEqualTo;
	}
	public void setCreateuserLessThanOrEqualTo(String createuserLessThanOrEqualTo) {
		this.createuserLessThanOrEqualTo = createuserLessThanOrEqualTo;
	}

	public String getCreateuserLessThan() {
		return createuserLessThan;
	}
	public void setCreateuserLessThan(String createuserLessThan) {
		this.createuserLessThan = createuserLessThan;
	}

	public Boolean getCreateuserIsNull() {
		return createuserIsNull;
	}
	public void setCreateuserIsNull(Boolean createuserIsNull) {
		this.createuserIsNull = createuserIsNull;
	}

	public Boolean getCreateuserIsNotNull() {
		return createuserIsNotNull;
	}
	public void setCreateuserIsNotNull(Boolean createuserIsNotNull) {
		this.createuserIsNotNull = createuserIsNotNull;
	}

	public java.util.List getCreateuserIn() {
		return createuserIn;
	}
	public void setCreateuserIn(java.util.List createuserIn) {
		this.createuserIn = createuserIn;
	}

	public String getCreateuserGreaterThanOrEqualTo() {
		return createuserGreaterThanOrEqualTo;
	}
	public void setCreateuserGreaterThanOrEqualTo(String createuserGreaterThanOrEqualTo) {
		this.createuserGreaterThanOrEqualTo = createuserGreaterThanOrEqualTo;
	}

	public String getCreateuserGreaterThan() {
		return createuserGreaterThan;
	}
	public void setCreateuserGreaterThan(String createuserGreaterThan) {
		this.createuserGreaterThan = createuserGreaterThan;
	}

	public String getCreateuserEqualTo() {
		return createuserEqualTo;
	}
	public void setCreateuserEqualTo(String createuserEqualTo) {
		this.createuserEqualTo = createuserEqualTo;
	}

	public java.util.List getCreatetimeNotIn() {
		return createtimeNotIn;
	}
	public void setCreatetimeNotIn(java.util.List createtimeNotIn) {
		this.createtimeNotIn = createtimeNotIn;
	}

	public java.util.Date getCreatetimeNotEqualTo() {
		return createtimeNotEqualTo;
	}
	public void setCreatetimeNotEqualTo(java.util.Date createtimeNotEqualTo) {
		this.createtimeNotEqualTo = createtimeNotEqualTo;
	}

	public java.util.Date getCreatetimeLessThanOrEqualTo() {
		return createtimeLessThanOrEqualTo;
	}
	public void setCreatetimeLessThanOrEqualTo(java.util.Date createtimeLessThanOrEqualTo) {
		this.createtimeLessThanOrEqualTo = createtimeLessThanOrEqualTo;
	}

	public java.util.Date getCreatetimeLessThan() {
		return createtimeLessThan;
	}
	public void setCreatetimeLessThan(java.util.Date createtimeLessThan) {
		this.createtimeLessThan = createtimeLessThan;
	}

	public Boolean getCreatetimeIsNull() {
		return createtimeIsNull;
	}
	public void setCreatetimeIsNull(Boolean createtimeIsNull) {
		this.createtimeIsNull = createtimeIsNull;
	}

	public Boolean getCreatetimeIsNotNull() {
		return createtimeIsNotNull;
	}
	public void setCreatetimeIsNotNull(Boolean createtimeIsNotNull) {
		this.createtimeIsNotNull = createtimeIsNotNull;
	}

	public java.util.List getCreatetimeIn() {
		return createtimeIn;
	}
	public void setCreatetimeIn(java.util.List createtimeIn) {
		this.createtimeIn = createtimeIn;
	}

	public java.util.Date getCreatetimeGreaterThanOrEqualTo() {
		return createtimeGreaterThanOrEqualTo;
	}
	public void setCreatetimeGreaterThanOrEqualTo(java.util.Date createtimeGreaterThanOrEqualTo) {
		this.createtimeGreaterThanOrEqualTo = createtimeGreaterThanOrEqualTo;
	}

	public java.util.Date getCreatetimeGreaterThan() {
		return createtimeGreaterThan;
	}
	public void setCreatetimeGreaterThan(java.util.Date createtimeGreaterThan) {
		this.createtimeGreaterThan = createtimeGreaterThan;
	}

	public java.util.Date getCreatetimeEqualTo() {
		return createtimeEqualTo;
	}
	public void setCreatetimeEqualTo(java.util.Date createtimeEqualTo) {
		this.createtimeEqualTo = createtimeEqualTo;
	}

	public void setSidx(String sidx) {
		this.sidx = sidx;
	}
	public String getSord() {
		return sord;
	}
	public void setSord(String sord) {
		 this.sord = sord;
	}
}
