package com.mrk.finance.model;

import com.mrk.common.base.BaseEntity;
import io.swagger.annotations.ApiModelProperty;
import lombok.Getter;
import lombok.Setter;

import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import java.io.Serializable;

@Setter
@Getter
public class FncBillMatchRecord extends BaseEntity implements Serializable {
    private static final long serialVersionUID = 1L;


    /**
     * 主键
     */
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @ApiModelProperty(value = "主键")
    private Long fbmrId;

    /**
     * 账单id
     */
    @ApiModelProperty(value = "账单id")
    private Long fbmrBillId;

    /**
     * 匹配金额
     */
    @ApiModelProperty(value = "匹配金额")
    private Double fbmrMatchMoney;

    /**
     * 流水id
     */
    @ApiModelProperty(value = "流水id")
    private Long fbmrWaterId;

    /**
     * 流水类型 0无 1银行流水 2T3 3滴滴
     */
    @ApiModelProperty(value = "流水类型 0无 1银行流水 2T3 3滴滴")
    private Integer fbmrWaterType;
}
