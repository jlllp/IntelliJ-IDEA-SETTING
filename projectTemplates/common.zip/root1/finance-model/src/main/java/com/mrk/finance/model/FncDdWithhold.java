package com.mrk.finance.model;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.mrk.common.base.BaseEntity;
import io.swagger.annotations.ApiModelProperty;
import lombok.Getter;
import lombok.Setter;
import org.springframework.format.annotation.DateTimeFormat;

import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import java.io.Serializable;

@Setter
@Getter
public class FncDdWithhold extends BaseEntity implements Serializable {
private static final long serialVersionUID=1L;


    /**主键 */
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @ApiModelProperty(value = "主键")
    private Long fdwId;

    /**交易名目 */
    @ApiModelProperty(value = "交易名目")
    private String fdwTradeNames;

    /**账户交易流水 */
    @ApiModelProperty(value = "账户交易流水")
    private String fdwAccountDealFlow;

    /**交易时间 */
    @DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss", timezone = "GMT+8")
    @ApiModelProperty(value = "交易时间")
    private java.util.Date fdwTradeTime;

    /**交易方 */
    @ApiModelProperty(value = "交易方")
    private String fdwTradeParty;

    /**交易金额 */
    @ApiModelProperty(value = "交易金额")
    private Double fdwTradeAmount;

    /**订单号 */
    @ApiModelProperty(value = "订单号")
    private String fdwOrderNo;

    /**账单号（滴滴） */
    @ApiModelProperty(value = "账单号（滴滴）")
    private String fdwAccountNo;

    /**车辆VIN码 */
    @ApiModelProperty(value = "车辆VIN码")
    private String fdwCarVin;

    /**匹配状态 */
    @ApiModelProperty(value = "匹配状态")
    private Integer fdwMatchState;

    /**匹配账单 */
    @ApiModelProperty(value = "匹配账单")
    private String fdwMatchBill;

    /**匹配方式 */
    @ApiModelProperty(value = "匹配方式")
    private Integer fdwMatchWay;

    /**已匹配金额 */
    @ApiModelProperty(value = "已匹配金额")
    private Double fdwMatchedAmount;

    /**未匹配金额 */
    @ApiModelProperty(value = "未匹配金额")
    private Double fdwNotMatchAmount;
    }
