package com.mrk.finance.query;
import com.mrk.common.utils.text.CheckUtil;

/**
 * @author 自动生成工具
 * @date   2022/06/02 
 */
public class FncRentalFeesQuery {
	private String updateuserNotLike;
	private java.util.List updateuserNotIn;
	private String updateuserNotEqualTo;
	private String updateuserLike;
	private String updateuserLessThanOrEqualTo;
	private String updateuserLessThan;
	private Boolean updateuserIsNull;
	private Boolean updateuserIsNotNull;
	private java.util.List updateuserIn;
	private String updateuserGreaterThanOrEqualTo;
	private String updateuserGreaterThan;
	private String updateuserEqualTo;
	private java.util.List updatetimeNotIn;
	private java.util.Date updatetimeNotEqualTo;
	private java.util.Date updatetimeLessThanOrEqualTo;
	private java.util.Date updatetimeLessThan;
	private Boolean updatetimeIsNull;
	private Boolean updatetimeIsNotNull;
	private java.util.List updatetimeIn;
	private java.util.Date updatetimeGreaterThanOrEqualTo;
	private java.util.Date updatetimeGreaterThan;
	private java.util.Date updatetimeEqualTo;
	private String remarkNotLike;
	private java.util.List remarkNotIn;
	private String remarkNotEqualTo;
	private String remarkLike;
	private String remarkLessThanOrEqualTo;
	private String remarkLessThan;
	private Boolean remarkIsNull;
	private Boolean remarkIsNotNull;
	private java.util.List remarkIn;
	private String remarkGreaterThanOrEqualTo;
	private String remarkGreaterThan;
	private String remarkEqualTo;
	private java.util.List frfWriteNotIn;
	private Integer frfWriteNotEqualTo;
	private Integer frfWriteLessThanOrEqualTo;
	private Integer frfWriteLessThan;
	private Boolean frfWriteIsNull;
	private Boolean frfWriteIsNotNull;
	private java.util.List frfWriteIn;
	private Integer frfWriteGreaterThanOrEqualTo;
	private Integer frfWriteGreaterThan;
	private Integer frfWriteEqualTo;
	private String frfNameNotLike;
	private java.util.List frfNameNotIn;
	private String frfNameNotEqualTo;
	private String frfNameLike;
	private String frfNameLessThanOrEqualTo;
	private String frfNameLessThan;
	private Boolean frfNameIsNull;
	private Boolean frfNameIsNotNull;
	private java.util.List frfNameIn;
	private String frfNameGreaterThanOrEqualTo;
	private String frfNameGreaterThan;
	private String frfNameEqualTo;
	private String frfMarkNotLike;
	private java.util.List frfMarkNotIn;
	private String frfMarkNotEqualTo;
	private String frfMarkLike;
	private String frfMarkLessThanOrEqualTo;
	private String frfMarkLessThan;
	private Boolean frfMarkIsNull;
	private Boolean frfMarkIsNotNull;
	private java.util.List frfMarkIn;
	private String frfMarkGreaterThanOrEqualTo;
	private String frfMarkGreaterThan;
	private String frfMarkEqualTo;
	private java.util.List frfIdNotIn;
	private Long frfIdNotEqualTo;
	private Long frfIdLessThanOrEqualTo;
	private Long frfIdLessThan;
	private Boolean frfIdIsNull;
	private Boolean frfIdIsNotNull;
	private java.util.List frfIdIn;
	private Long frfIdGreaterThanOrEqualTo;
	private Long frfIdGreaterThan;
	private Long frfIdEqualTo;
	private java.util.List drNotIn;
	private Integer drNotEqualTo;
	private Integer drLessThanOrEqualTo;
	private Integer drLessThan;
	private Boolean drIsNull;
	private Boolean drIsNotNull;
	private java.util.List drIn;
	private Integer drGreaterThanOrEqualTo;
	private Integer drGreaterThan;
	private Integer drEqualTo;
	private String createuserNotLike;
	private java.util.List createuserNotIn;
	private String createuserNotEqualTo;
	private String createuserLike;
	private String createuserLessThanOrEqualTo;
	private String createuserLessThan;
	private Boolean createuserIsNull;
	private Boolean createuserIsNotNull;
	private java.util.List createuserIn;
	private String createuserGreaterThanOrEqualTo;
	private String createuserGreaterThan;
	private String createuserEqualTo;
	private java.util.List createtimeNotIn;
	private java.util.Date createtimeNotEqualTo;
	private java.util.Date createtimeLessThanOrEqualTo;
	private java.util.Date createtimeLessThan;
	private Boolean createtimeIsNull;
	private Boolean createtimeIsNotNull;
	private java.util.List createtimeIn;
	private java.util.Date createtimeGreaterThanOrEqualTo;
	private java.util.Date createtimeGreaterThan;
	private java.util.Date createtimeEqualTo;
	private String sidx;
	private String sord;
	public String getSidx(){
		if(this.sidx == null){
			return "";
		}
		else if("updateuser".equals(this.sidx)){
			return "updateuser";
		}
		else if("updatetime".equals(this.sidx)){
			return "updatetime";
		}
		else if("remark".equals(this.sidx)){
			return "remark";
		}
		else if("frfWrite".equals(this.sidx)){
			return "frf_write";
		}
		else if("frfName".equals(this.sidx)){
			return "frf_name";
		}
		else if("frfMark".equals(this.sidx)){
			return "frf_mark";
		}
		else if("frfId".equals(this.sidx)){
			return "frf_id";
		}
		else if("dr".equals(this.sidx)){
			return "dr";
		}
		else if("createuser".equals(this.sidx)){
			return "createuser";
		}
		else if("createtime".equals(this.sidx)){
			return "createtime";
		}
		return this.sidx;
	}

	@com.fasterxml.jackson.annotation.JsonIgnore
	public com.mrk.finance.example.FncRentalFeesExample getCrieria(){
		com.mrk.finance.example.FncRentalFeesExample q = new com.mrk.finance.example.FncRentalFeesExample();
		com.mrk.finance.example.FncRentalFeesExample.Criteria c = q.createCriteria();
		c.andDrEqualTo(0);
		if(CheckUtil.isNotEmpty(getUpdateuserNotLike())){
			c.andUpdateuserNotLike("%"+this.getUpdateuserNotLike()+"%");
		}
		if(CheckUtil.isNotEmpty(getUpdateuserNotIn())){
			c.andUpdateuserNotIn(this.getUpdateuserNotIn());
		}
		if(CheckUtil.isNotEmpty(getUpdateuserNotEqualTo())){
			c.andUpdateuserNotEqualTo(this.getUpdateuserNotEqualTo());
		}
		if(CheckUtil.isNotEmpty(getUpdateuserLike())){
			c.andUpdateuserLike("%"+this.getUpdateuserLike()+"%");
		}
		if(CheckUtil.isNotEmpty(getUpdateuserLessThanOrEqualTo())){
			c.andUpdateuserLessThanOrEqualTo(this.getUpdateuserLessThanOrEqualTo());
		}
		if(CheckUtil.isNotEmpty(getUpdateuserLessThan())){
			c.andUpdateuserLessThan(this.getUpdateuserLessThan());
		}
		if(CheckUtil.isNotEmpty(getUpdateuserIsNull()) && this.getUpdateuserIsNull()){
			c.andUpdateuserIsNull();
		}
		if(CheckUtil.isNotEmpty(getUpdateuserIsNotNull()) && this.getUpdateuserIsNotNull()){
			c.andUpdateuserIsNotNull();
		}
		if(CheckUtil.isNotEmpty(getUpdateuserIn())){
			c.andUpdateuserIn(this.getUpdateuserIn());
		}
		if(CheckUtil.isNotEmpty(getUpdateuserGreaterThanOrEqualTo())){
			c.andUpdateuserGreaterThanOrEqualTo(this.getUpdateuserGreaterThanOrEqualTo());
		}
		if(CheckUtil.isNotEmpty(getUpdateuserGreaterThan())){
			c.andUpdateuserGreaterThan(this.getUpdateuserGreaterThan());
		}
		if(CheckUtil.isNotEmpty(getUpdateuserEqualTo())){
			c.andUpdateuserEqualTo(this.getUpdateuserEqualTo());
		}
		if(CheckUtil.isNotEmpty(getUpdatetimeNotIn())){
			c.andUpdatetimeNotIn(this.getUpdatetimeNotIn());
		}
		if(CheckUtil.isNotEmpty(getUpdatetimeNotEqualTo())){
			c.andUpdatetimeNotEqualTo(this.getUpdatetimeNotEqualTo());
		}
		if(CheckUtil.isNotEmpty(getUpdatetimeLessThanOrEqualTo())){
			c.andUpdatetimeLessThanOrEqualTo(this.getUpdatetimeLessThanOrEqualTo());
		}
		if(CheckUtil.isNotEmpty(getUpdatetimeLessThan())){
			c.andUpdatetimeLessThan(this.getUpdatetimeLessThan());
		}
		if(CheckUtil.isNotEmpty(getUpdatetimeIsNull()) && this.getUpdatetimeIsNull()){
			c.andUpdatetimeIsNull();
		}
		if(CheckUtil.isNotEmpty(getUpdatetimeIsNotNull()) && this.getUpdatetimeIsNotNull()){
			c.andUpdatetimeIsNotNull();
		}
		if(CheckUtil.isNotEmpty(getUpdatetimeIn())){
			c.andUpdatetimeIn(this.getUpdatetimeIn());
		}
		if(CheckUtil.isNotEmpty(getUpdatetimeGreaterThanOrEqualTo())){
			c.andUpdatetimeGreaterThanOrEqualTo(this.getUpdatetimeGreaterThanOrEqualTo());
		}
		if(CheckUtil.isNotEmpty(getUpdatetimeGreaterThan())){
			c.andUpdatetimeGreaterThan(this.getUpdatetimeGreaterThan());
		}
		if(CheckUtil.isNotEmpty(getUpdatetimeEqualTo())){
			c.andUpdatetimeEqualTo(this.getUpdatetimeEqualTo());
		}
		if(CheckUtil.isNotEmpty(getRemarkNotLike())){
			c.andRemarkNotLike("%"+this.getRemarkNotLike()+"%");
		}
		if(CheckUtil.isNotEmpty(getRemarkNotIn())){
			c.andRemarkNotIn(this.getRemarkNotIn());
		}
		if(CheckUtil.isNotEmpty(getRemarkNotEqualTo())){
			c.andRemarkNotEqualTo(this.getRemarkNotEqualTo());
		}
		if(CheckUtil.isNotEmpty(getRemarkLike())){
			c.andRemarkLike("%"+this.getRemarkLike()+"%");
		}
		if(CheckUtil.isNotEmpty(getRemarkLessThanOrEqualTo())){
			c.andRemarkLessThanOrEqualTo(this.getRemarkLessThanOrEqualTo());
		}
		if(CheckUtil.isNotEmpty(getRemarkLessThan())){
			c.andRemarkLessThan(this.getRemarkLessThan());
		}
		if(CheckUtil.isNotEmpty(getRemarkIsNull()) && this.getRemarkIsNull()){
			c.andRemarkIsNull();
		}
		if(CheckUtil.isNotEmpty(getRemarkIsNotNull()) && this.getRemarkIsNotNull()){
			c.andRemarkIsNotNull();
		}
		if(CheckUtil.isNotEmpty(getRemarkIn())){
			c.andRemarkIn(this.getRemarkIn());
		}
		if(CheckUtil.isNotEmpty(getRemarkGreaterThanOrEqualTo())){
			c.andRemarkGreaterThanOrEqualTo(this.getRemarkGreaterThanOrEqualTo());
		}
		if(CheckUtil.isNotEmpty(getRemarkGreaterThan())){
			c.andRemarkGreaterThan(this.getRemarkGreaterThan());
		}
		if(CheckUtil.isNotEmpty(getRemarkEqualTo())){
			c.andRemarkEqualTo(this.getRemarkEqualTo());
		}
		if(CheckUtil.isNotEmpty(getFrfWriteNotIn())){
			c.andFrfWriteNotIn(this.getFrfWriteNotIn());
		}
		if(CheckUtil.isNotEmpty(getFrfWriteNotEqualTo())){
			c.andFrfWriteNotEqualTo(this.getFrfWriteNotEqualTo());
		}
		if(CheckUtil.isNotEmpty(getFrfWriteLessThanOrEqualTo())){
			c.andFrfWriteLessThanOrEqualTo(this.getFrfWriteLessThanOrEqualTo());
		}
		if(CheckUtil.isNotEmpty(getFrfWriteLessThan())){
			c.andFrfWriteLessThan(this.getFrfWriteLessThan());
		}
		if(CheckUtil.isNotEmpty(getFrfWriteIsNull()) && this.getFrfWriteIsNull()){
			c.andFrfWriteIsNull();
		}
		if(CheckUtil.isNotEmpty(getFrfWriteIsNotNull()) && this.getFrfWriteIsNotNull()){
			c.andFrfWriteIsNotNull();
		}
		if(CheckUtil.isNotEmpty(getFrfWriteIn())){
			c.andFrfWriteIn(this.getFrfWriteIn());
		}
		if(CheckUtil.isNotEmpty(getFrfWriteGreaterThanOrEqualTo())){
			c.andFrfWriteGreaterThanOrEqualTo(this.getFrfWriteGreaterThanOrEqualTo());
		}
		if(CheckUtil.isNotEmpty(getFrfWriteGreaterThan())){
			c.andFrfWriteGreaterThan(this.getFrfWriteGreaterThan());
		}
		if(CheckUtil.isNotEmpty(getFrfWriteEqualTo())){
			c.andFrfWriteEqualTo(this.getFrfWriteEqualTo());
		}
		if(CheckUtil.isNotEmpty(getFrfNameNotLike())){
			c.andFrfNameNotLike("%"+this.getFrfNameNotLike()+"%");
		}
		if(CheckUtil.isNotEmpty(getFrfNameNotIn())){
			c.andFrfNameNotIn(this.getFrfNameNotIn());
		}
		if(CheckUtil.isNotEmpty(getFrfNameNotEqualTo())){
			c.andFrfNameNotEqualTo(this.getFrfNameNotEqualTo());
		}
		if(CheckUtil.isNotEmpty(getFrfNameLike())){
			c.andFrfNameLike("%"+this.getFrfNameLike()+"%");
		}
		if(CheckUtil.isNotEmpty(getFrfNameLessThanOrEqualTo())){
			c.andFrfNameLessThanOrEqualTo(this.getFrfNameLessThanOrEqualTo());
		}
		if(CheckUtil.isNotEmpty(getFrfNameLessThan())){
			c.andFrfNameLessThan(this.getFrfNameLessThan());
		}
		if(CheckUtil.isNotEmpty(getFrfNameIsNull()) && this.getFrfNameIsNull()){
			c.andFrfNameIsNull();
		}
		if(CheckUtil.isNotEmpty(getFrfNameIsNotNull()) && this.getFrfNameIsNotNull()){
			c.andFrfNameIsNotNull();
		}
		if(CheckUtil.isNotEmpty(getFrfNameIn())){
			c.andFrfNameIn(this.getFrfNameIn());
		}
		if(CheckUtil.isNotEmpty(getFrfNameGreaterThanOrEqualTo())){
			c.andFrfNameGreaterThanOrEqualTo(this.getFrfNameGreaterThanOrEqualTo());
		}
		if(CheckUtil.isNotEmpty(getFrfNameGreaterThan())){
			c.andFrfNameGreaterThan(this.getFrfNameGreaterThan());
		}
		if(CheckUtil.isNotEmpty(getFrfNameEqualTo())){
			c.andFrfNameEqualTo(this.getFrfNameEqualTo());
		}
		if(CheckUtil.isNotEmpty(getFrfMarkNotLike())){
			c.andFrfMarkNotLike("%"+this.getFrfMarkNotLike()+"%");
		}
		if(CheckUtil.isNotEmpty(getFrfMarkNotIn())){
			c.andFrfMarkNotIn(this.getFrfMarkNotIn());
		}
		if(CheckUtil.isNotEmpty(getFrfMarkNotEqualTo())){
			c.andFrfMarkNotEqualTo(this.getFrfMarkNotEqualTo());
		}
		if(CheckUtil.isNotEmpty(getFrfMarkLike())){
			c.andFrfMarkLike("%"+this.getFrfMarkLike()+"%");
		}
		if(CheckUtil.isNotEmpty(getFrfMarkLessThanOrEqualTo())){
			c.andFrfMarkLessThanOrEqualTo(this.getFrfMarkLessThanOrEqualTo());
		}
		if(CheckUtil.isNotEmpty(getFrfMarkLessThan())){
			c.andFrfMarkLessThan(this.getFrfMarkLessThan());
		}
		if(CheckUtil.isNotEmpty(getFrfMarkIsNull()) && this.getFrfMarkIsNull()){
			c.andFrfMarkIsNull();
		}
		if(CheckUtil.isNotEmpty(getFrfMarkIsNotNull()) && this.getFrfMarkIsNotNull()){
			c.andFrfMarkIsNotNull();
		}
		if(CheckUtil.isNotEmpty(getFrfMarkIn())){
			c.andFrfMarkIn(this.getFrfMarkIn());
		}
		if(CheckUtil.isNotEmpty(getFrfMarkGreaterThanOrEqualTo())){
			c.andFrfMarkGreaterThanOrEqualTo(this.getFrfMarkGreaterThanOrEqualTo());
		}
		if(CheckUtil.isNotEmpty(getFrfMarkGreaterThan())){
			c.andFrfMarkGreaterThan(this.getFrfMarkGreaterThan());
		}
		if(CheckUtil.isNotEmpty(getFrfMarkEqualTo())){
			c.andFrfMarkEqualTo(this.getFrfMarkEqualTo());
		}
		if(CheckUtil.isNotEmpty(getFrfIdNotIn())){
			c.andFrfIdNotIn(this.getFrfIdNotIn());
		}
		if(CheckUtil.isNotEmpty(getFrfIdNotEqualTo())){
			c.andFrfIdNotEqualTo(this.getFrfIdNotEqualTo());
		}
		if(CheckUtil.isNotEmpty(getFrfIdLessThanOrEqualTo())){
			c.andFrfIdLessThanOrEqualTo(this.getFrfIdLessThanOrEqualTo());
		}
		if(CheckUtil.isNotEmpty(getFrfIdLessThan())){
			c.andFrfIdLessThan(this.getFrfIdLessThan());
		}
		if(CheckUtil.isNotEmpty(getFrfIdIsNull()) && this.getFrfIdIsNull()){
			c.andFrfIdIsNull();
		}
		if(CheckUtil.isNotEmpty(getFrfIdIsNotNull()) && this.getFrfIdIsNotNull()){
			c.andFrfIdIsNotNull();
		}
		if(CheckUtil.isNotEmpty(getFrfIdIn())){
			c.andFrfIdIn(this.getFrfIdIn());
		}
		if(CheckUtil.isNotEmpty(getFrfIdGreaterThanOrEqualTo())){
			c.andFrfIdGreaterThanOrEqualTo(this.getFrfIdGreaterThanOrEqualTo());
		}
		if(CheckUtil.isNotEmpty(getFrfIdGreaterThan())){
			c.andFrfIdGreaterThan(this.getFrfIdGreaterThan());
		}
		if(CheckUtil.isNotEmpty(getFrfIdEqualTo())){
			c.andFrfIdEqualTo(this.getFrfIdEqualTo());
		}
		if(CheckUtil.isNotEmpty(getDrNotIn())){
			c.andDrNotIn(this.getDrNotIn());
		}
		if(CheckUtil.isNotEmpty(getDrNotEqualTo())){
			c.andDrNotEqualTo(this.getDrNotEqualTo());
		}
		if(CheckUtil.isNotEmpty(getDrLessThanOrEqualTo())){
			c.andDrLessThanOrEqualTo(this.getDrLessThanOrEqualTo());
		}
		if(CheckUtil.isNotEmpty(getDrLessThan())){
			c.andDrLessThan(this.getDrLessThan());
		}
		if(CheckUtil.isNotEmpty(getDrIsNull()) && this.getDrIsNull()){
			c.andDrIsNull();
		}
		if(CheckUtil.isNotEmpty(getDrIsNotNull()) && this.getDrIsNotNull()){
			c.andDrIsNotNull();
		}
		if(CheckUtil.isNotEmpty(getDrIn())){
			c.andDrIn(this.getDrIn());
		}
		if(CheckUtil.isNotEmpty(getDrGreaterThanOrEqualTo())){
			c.andDrGreaterThanOrEqualTo(this.getDrGreaterThanOrEqualTo());
		}
		if(CheckUtil.isNotEmpty(getDrGreaterThan())){
			c.andDrGreaterThan(this.getDrGreaterThan());
		}
		if(CheckUtil.isNotEmpty(getDrEqualTo())){
			c.andDrEqualTo(this.getDrEqualTo());
		}
		if(CheckUtil.isNotEmpty(getCreateuserNotLike())){
			c.andCreateuserNotLike("%"+this.getCreateuserNotLike()+"%");
		}
		if(CheckUtil.isNotEmpty(getCreateuserNotIn())){
			c.andCreateuserNotIn(this.getCreateuserNotIn());
		}
		if(CheckUtil.isNotEmpty(getCreateuserNotEqualTo())){
			c.andCreateuserNotEqualTo(this.getCreateuserNotEqualTo());
		}
		if(CheckUtil.isNotEmpty(getCreateuserLike())){
			c.andCreateuserLike("%"+this.getCreateuserLike()+"%");
		}
		if(CheckUtil.isNotEmpty(getCreateuserLessThanOrEqualTo())){
			c.andCreateuserLessThanOrEqualTo(this.getCreateuserLessThanOrEqualTo());
		}
		if(CheckUtil.isNotEmpty(getCreateuserLessThan())){
			c.andCreateuserLessThan(this.getCreateuserLessThan());
		}
		if(CheckUtil.isNotEmpty(getCreateuserIsNull()) && this.getCreateuserIsNull()){
			c.andCreateuserIsNull();
		}
		if(CheckUtil.isNotEmpty(getCreateuserIsNotNull()) && this.getCreateuserIsNotNull()){
			c.andCreateuserIsNotNull();
		}
		if(CheckUtil.isNotEmpty(getCreateuserIn())){
			c.andCreateuserIn(this.getCreateuserIn());
		}
		if(CheckUtil.isNotEmpty(getCreateuserGreaterThanOrEqualTo())){
			c.andCreateuserGreaterThanOrEqualTo(this.getCreateuserGreaterThanOrEqualTo());
		}
		if(CheckUtil.isNotEmpty(getCreateuserGreaterThan())){
			c.andCreateuserGreaterThan(this.getCreateuserGreaterThan());
		}
		if(CheckUtil.isNotEmpty(getCreateuserEqualTo())){
			c.andCreateuserEqualTo(this.getCreateuserEqualTo());
		}
		if(CheckUtil.isNotEmpty(getCreatetimeNotIn())){
			c.andCreatetimeNotIn(this.getCreatetimeNotIn());
		}
		if(CheckUtil.isNotEmpty(getCreatetimeNotEqualTo())){
			c.andCreatetimeNotEqualTo(this.getCreatetimeNotEqualTo());
		}
		if(CheckUtil.isNotEmpty(getCreatetimeLessThanOrEqualTo())){
			c.andCreatetimeLessThanOrEqualTo(this.getCreatetimeLessThanOrEqualTo());
		}
		if(CheckUtil.isNotEmpty(getCreatetimeLessThan())){
			c.andCreatetimeLessThan(this.getCreatetimeLessThan());
		}
		if(CheckUtil.isNotEmpty(getCreatetimeIsNull()) && this.getCreatetimeIsNull()){
			c.andCreatetimeIsNull();
		}
		if(CheckUtil.isNotEmpty(getCreatetimeIsNotNull()) && this.getCreatetimeIsNotNull()){
			c.andCreatetimeIsNotNull();
		}
		if(CheckUtil.isNotEmpty(getCreatetimeIn())){
			c.andCreatetimeIn(this.getCreatetimeIn());
		}
		if(CheckUtil.isNotEmpty(getCreatetimeGreaterThanOrEqualTo())){
			c.andCreatetimeGreaterThanOrEqualTo(this.getCreatetimeGreaterThanOrEqualTo());
		}
		if(CheckUtil.isNotEmpty(getCreatetimeGreaterThan())){
			c.andCreatetimeGreaterThan(this.getCreatetimeGreaterThan());
		}
		if(CheckUtil.isNotEmpty(getCreatetimeEqualTo())){
			c.andCreatetimeEqualTo(this.getCreatetimeEqualTo());
		}
		if((this.getSidx()!=null && !this.getSidx().trim().equals("")) && this.getSord()!=null) {
			q.setOrderByClause(""+ this.getSidx()+" "+this.getSord());
		}
		return q;
	}
	public String getUpdateuserNotLike() {
		return updateuserNotLike;
	}
	public void setUpdateuserNotLike(String updateuserNotLike) {
		this.updateuserNotLike = updateuserNotLike;
	}

	public java.util.List getUpdateuserNotIn() {
		return updateuserNotIn;
	}
	public void setUpdateuserNotIn(java.util.List updateuserNotIn) {
		this.updateuserNotIn = updateuserNotIn;
	}

	public String getUpdateuserNotEqualTo() {
		return updateuserNotEqualTo;
	}
	public void setUpdateuserNotEqualTo(String updateuserNotEqualTo) {
		this.updateuserNotEqualTo = updateuserNotEqualTo;
	}

	public String getUpdateuserLike() {
		return updateuserLike;
	}
	public void setUpdateuserLike(String updateuserLike) {
		this.updateuserLike = updateuserLike;
	}

	public String getUpdateuserLessThanOrEqualTo() {
		return updateuserLessThanOrEqualTo;
	}
	public void setUpdateuserLessThanOrEqualTo(String updateuserLessThanOrEqualTo) {
		this.updateuserLessThanOrEqualTo = updateuserLessThanOrEqualTo;
	}

	public String getUpdateuserLessThan() {
		return updateuserLessThan;
	}
	public void setUpdateuserLessThan(String updateuserLessThan) {
		this.updateuserLessThan = updateuserLessThan;
	}

	public Boolean getUpdateuserIsNull() {
		return updateuserIsNull;
	}
	public void setUpdateuserIsNull(Boolean updateuserIsNull) {
		this.updateuserIsNull = updateuserIsNull;
	}

	public Boolean getUpdateuserIsNotNull() {
		return updateuserIsNotNull;
	}
	public void setUpdateuserIsNotNull(Boolean updateuserIsNotNull) {
		this.updateuserIsNotNull = updateuserIsNotNull;
	}

	public java.util.List getUpdateuserIn() {
		return updateuserIn;
	}
	public void setUpdateuserIn(java.util.List updateuserIn) {
		this.updateuserIn = updateuserIn;
	}

	public String getUpdateuserGreaterThanOrEqualTo() {
		return updateuserGreaterThanOrEqualTo;
	}
	public void setUpdateuserGreaterThanOrEqualTo(String updateuserGreaterThanOrEqualTo) {
		this.updateuserGreaterThanOrEqualTo = updateuserGreaterThanOrEqualTo;
	}

	public String getUpdateuserGreaterThan() {
		return updateuserGreaterThan;
	}
	public void setUpdateuserGreaterThan(String updateuserGreaterThan) {
		this.updateuserGreaterThan = updateuserGreaterThan;
	}

	public String getUpdateuserEqualTo() {
		return updateuserEqualTo;
	}
	public void setUpdateuserEqualTo(String updateuserEqualTo) {
		this.updateuserEqualTo = updateuserEqualTo;
	}

	public java.util.List getUpdatetimeNotIn() {
		return updatetimeNotIn;
	}
	public void setUpdatetimeNotIn(java.util.List updatetimeNotIn) {
		this.updatetimeNotIn = updatetimeNotIn;
	}

	public java.util.Date getUpdatetimeNotEqualTo() {
		return updatetimeNotEqualTo;
	}
	public void setUpdatetimeNotEqualTo(java.util.Date updatetimeNotEqualTo) {
		this.updatetimeNotEqualTo = updatetimeNotEqualTo;
	}

	public java.util.Date getUpdatetimeLessThanOrEqualTo() {
		return updatetimeLessThanOrEqualTo;
	}
	public void setUpdatetimeLessThanOrEqualTo(java.util.Date updatetimeLessThanOrEqualTo) {
		this.updatetimeLessThanOrEqualTo = updatetimeLessThanOrEqualTo;
	}

	public java.util.Date getUpdatetimeLessThan() {
		return updatetimeLessThan;
	}
	public void setUpdatetimeLessThan(java.util.Date updatetimeLessThan) {
		this.updatetimeLessThan = updatetimeLessThan;
	}

	public Boolean getUpdatetimeIsNull() {
		return updatetimeIsNull;
	}
	public void setUpdatetimeIsNull(Boolean updatetimeIsNull) {
		this.updatetimeIsNull = updatetimeIsNull;
	}

	public Boolean getUpdatetimeIsNotNull() {
		return updatetimeIsNotNull;
	}
	public void setUpdatetimeIsNotNull(Boolean updatetimeIsNotNull) {
		this.updatetimeIsNotNull = updatetimeIsNotNull;
	}

	public java.util.List getUpdatetimeIn() {
		return updatetimeIn;
	}
	public void setUpdatetimeIn(java.util.List updatetimeIn) {
		this.updatetimeIn = updatetimeIn;
	}

	public java.util.Date getUpdatetimeGreaterThanOrEqualTo() {
		return updatetimeGreaterThanOrEqualTo;
	}
	public void setUpdatetimeGreaterThanOrEqualTo(java.util.Date updatetimeGreaterThanOrEqualTo) {
		this.updatetimeGreaterThanOrEqualTo = updatetimeGreaterThanOrEqualTo;
	}

	public java.util.Date getUpdatetimeGreaterThan() {
		return updatetimeGreaterThan;
	}
	public void setUpdatetimeGreaterThan(java.util.Date updatetimeGreaterThan) {
		this.updatetimeGreaterThan = updatetimeGreaterThan;
	}

	public java.util.Date getUpdatetimeEqualTo() {
		return updatetimeEqualTo;
	}
	public void setUpdatetimeEqualTo(java.util.Date updatetimeEqualTo) {
		this.updatetimeEqualTo = updatetimeEqualTo;
	}

	public String getRemarkNotLike() {
		return remarkNotLike;
	}
	public void setRemarkNotLike(String remarkNotLike) {
		this.remarkNotLike = remarkNotLike;
	}

	public java.util.List getRemarkNotIn() {
		return remarkNotIn;
	}
	public void setRemarkNotIn(java.util.List remarkNotIn) {
		this.remarkNotIn = remarkNotIn;
	}

	public String getRemarkNotEqualTo() {
		return remarkNotEqualTo;
	}
	public void setRemarkNotEqualTo(String remarkNotEqualTo) {
		this.remarkNotEqualTo = remarkNotEqualTo;
	}

	public String getRemarkLike() {
		return remarkLike;
	}
	public void setRemarkLike(String remarkLike) {
		this.remarkLike = remarkLike;
	}

	public String getRemarkLessThanOrEqualTo() {
		return remarkLessThanOrEqualTo;
	}
	public void setRemarkLessThanOrEqualTo(String remarkLessThanOrEqualTo) {
		this.remarkLessThanOrEqualTo = remarkLessThanOrEqualTo;
	}

	public String getRemarkLessThan() {
		return remarkLessThan;
	}
	public void setRemarkLessThan(String remarkLessThan) {
		this.remarkLessThan = remarkLessThan;
	}

	public Boolean getRemarkIsNull() {
		return remarkIsNull;
	}
	public void setRemarkIsNull(Boolean remarkIsNull) {
		this.remarkIsNull = remarkIsNull;
	}

	public Boolean getRemarkIsNotNull() {
		return remarkIsNotNull;
	}
	public void setRemarkIsNotNull(Boolean remarkIsNotNull) {
		this.remarkIsNotNull = remarkIsNotNull;
	}

	public java.util.List getRemarkIn() {
		return remarkIn;
	}
	public void setRemarkIn(java.util.List remarkIn) {
		this.remarkIn = remarkIn;
	}

	public String getRemarkGreaterThanOrEqualTo() {
		return remarkGreaterThanOrEqualTo;
	}
	public void setRemarkGreaterThanOrEqualTo(String remarkGreaterThanOrEqualTo) {
		this.remarkGreaterThanOrEqualTo = remarkGreaterThanOrEqualTo;
	}

	public String getRemarkGreaterThan() {
		return remarkGreaterThan;
	}
	public void setRemarkGreaterThan(String remarkGreaterThan) {
		this.remarkGreaterThan = remarkGreaterThan;
	}

	public String getRemarkEqualTo() {
		return remarkEqualTo;
	}
	public void setRemarkEqualTo(String remarkEqualTo) {
		this.remarkEqualTo = remarkEqualTo;
	}

	public java.util.List getFrfWriteNotIn() {
		return frfWriteNotIn;
	}
	public void setFrfWriteNotIn(java.util.List frfWriteNotIn) {
		this.frfWriteNotIn = frfWriteNotIn;
	}

	public Integer getFrfWriteNotEqualTo() {
		return frfWriteNotEqualTo;
	}
	public void setFrfWriteNotEqualTo(Integer frfWriteNotEqualTo) {
		this.frfWriteNotEqualTo = frfWriteNotEqualTo;
	}

	public Integer getFrfWriteLessThanOrEqualTo() {
		return frfWriteLessThanOrEqualTo;
	}
	public void setFrfWriteLessThanOrEqualTo(Integer frfWriteLessThanOrEqualTo) {
		this.frfWriteLessThanOrEqualTo = frfWriteLessThanOrEqualTo;
	}

	public Integer getFrfWriteLessThan() {
		return frfWriteLessThan;
	}
	public void setFrfWriteLessThan(Integer frfWriteLessThan) {
		this.frfWriteLessThan = frfWriteLessThan;
	}

	public Boolean getFrfWriteIsNull() {
		return frfWriteIsNull;
	}
	public void setFrfWriteIsNull(Boolean frfWriteIsNull) {
		this.frfWriteIsNull = frfWriteIsNull;
	}

	public Boolean getFrfWriteIsNotNull() {
		return frfWriteIsNotNull;
	}
	public void setFrfWriteIsNotNull(Boolean frfWriteIsNotNull) {
		this.frfWriteIsNotNull = frfWriteIsNotNull;
	}

	public java.util.List getFrfWriteIn() {
		return frfWriteIn;
	}
	public void setFrfWriteIn(java.util.List frfWriteIn) {
		this.frfWriteIn = frfWriteIn;
	}

	public Integer getFrfWriteGreaterThanOrEqualTo() {
		return frfWriteGreaterThanOrEqualTo;
	}
	public void setFrfWriteGreaterThanOrEqualTo(Integer frfWriteGreaterThanOrEqualTo) {
		this.frfWriteGreaterThanOrEqualTo = frfWriteGreaterThanOrEqualTo;
	}

	public Integer getFrfWriteGreaterThan() {
		return frfWriteGreaterThan;
	}
	public void setFrfWriteGreaterThan(Integer frfWriteGreaterThan) {
		this.frfWriteGreaterThan = frfWriteGreaterThan;
	}

	public Integer getFrfWriteEqualTo() {
		return frfWriteEqualTo;
	}
	public void setFrfWriteEqualTo(Integer frfWriteEqualTo) {
		this.frfWriteEqualTo = frfWriteEqualTo;
	}

	public String getFrfNameNotLike() {
		return frfNameNotLike;
	}
	public void setFrfNameNotLike(String frfNameNotLike) {
		this.frfNameNotLike = frfNameNotLike;
	}

	public java.util.List getFrfNameNotIn() {
		return frfNameNotIn;
	}
	public void setFrfNameNotIn(java.util.List frfNameNotIn) {
		this.frfNameNotIn = frfNameNotIn;
	}

	public String getFrfNameNotEqualTo() {
		return frfNameNotEqualTo;
	}
	public void setFrfNameNotEqualTo(String frfNameNotEqualTo) {
		this.frfNameNotEqualTo = frfNameNotEqualTo;
	}

	public String getFrfNameLike() {
		return frfNameLike;
	}
	public void setFrfNameLike(String frfNameLike) {
		this.frfNameLike = frfNameLike;
	}

	public String getFrfNameLessThanOrEqualTo() {
		return frfNameLessThanOrEqualTo;
	}
	public void setFrfNameLessThanOrEqualTo(String frfNameLessThanOrEqualTo) {
		this.frfNameLessThanOrEqualTo = frfNameLessThanOrEqualTo;
	}

	public String getFrfNameLessThan() {
		return frfNameLessThan;
	}
	public void setFrfNameLessThan(String frfNameLessThan) {
		this.frfNameLessThan = frfNameLessThan;
	}

	public Boolean getFrfNameIsNull() {
		return frfNameIsNull;
	}
	public void setFrfNameIsNull(Boolean frfNameIsNull) {
		this.frfNameIsNull = frfNameIsNull;
	}

	public Boolean getFrfNameIsNotNull() {
		return frfNameIsNotNull;
	}
	public void setFrfNameIsNotNull(Boolean frfNameIsNotNull) {
		this.frfNameIsNotNull = frfNameIsNotNull;
	}

	public java.util.List getFrfNameIn() {
		return frfNameIn;
	}
	public void setFrfNameIn(java.util.List frfNameIn) {
		this.frfNameIn = frfNameIn;
	}

	public String getFrfNameGreaterThanOrEqualTo() {
		return frfNameGreaterThanOrEqualTo;
	}
	public void setFrfNameGreaterThanOrEqualTo(String frfNameGreaterThanOrEqualTo) {
		this.frfNameGreaterThanOrEqualTo = frfNameGreaterThanOrEqualTo;
	}

	public String getFrfNameGreaterThan() {
		return frfNameGreaterThan;
	}
	public void setFrfNameGreaterThan(String frfNameGreaterThan) {
		this.frfNameGreaterThan = frfNameGreaterThan;
	}

	public String getFrfNameEqualTo() {
		return frfNameEqualTo;
	}
	public void setFrfNameEqualTo(String frfNameEqualTo) {
		this.frfNameEqualTo = frfNameEqualTo;
	}

	public String getFrfMarkNotLike() {
		return frfMarkNotLike;
	}
	public void setFrfMarkNotLike(String frfMarkNotLike) {
		this.frfMarkNotLike = frfMarkNotLike;
	}

	public java.util.List getFrfMarkNotIn() {
		return frfMarkNotIn;
	}
	public void setFrfMarkNotIn(java.util.List frfMarkNotIn) {
		this.frfMarkNotIn = frfMarkNotIn;
	}

	public String getFrfMarkNotEqualTo() {
		return frfMarkNotEqualTo;
	}
	public void setFrfMarkNotEqualTo(String frfMarkNotEqualTo) {
		this.frfMarkNotEqualTo = frfMarkNotEqualTo;
	}

	public String getFrfMarkLike() {
		return frfMarkLike;
	}
	public void setFrfMarkLike(String frfMarkLike) {
		this.frfMarkLike = frfMarkLike;
	}

	public String getFrfMarkLessThanOrEqualTo() {
		return frfMarkLessThanOrEqualTo;
	}
	public void setFrfMarkLessThanOrEqualTo(String frfMarkLessThanOrEqualTo) {
		this.frfMarkLessThanOrEqualTo = frfMarkLessThanOrEqualTo;
	}

	public String getFrfMarkLessThan() {
		return frfMarkLessThan;
	}
	public void setFrfMarkLessThan(String frfMarkLessThan) {
		this.frfMarkLessThan = frfMarkLessThan;
	}

	public Boolean getFrfMarkIsNull() {
		return frfMarkIsNull;
	}
	public void setFrfMarkIsNull(Boolean frfMarkIsNull) {
		this.frfMarkIsNull = frfMarkIsNull;
	}

	public Boolean getFrfMarkIsNotNull() {
		return frfMarkIsNotNull;
	}
	public void setFrfMarkIsNotNull(Boolean frfMarkIsNotNull) {
		this.frfMarkIsNotNull = frfMarkIsNotNull;
	}

	public java.util.List getFrfMarkIn() {
		return frfMarkIn;
	}
	public void setFrfMarkIn(java.util.List frfMarkIn) {
		this.frfMarkIn = frfMarkIn;
	}

	public String getFrfMarkGreaterThanOrEqualTo() {
		return frfMarkGreaterThanOrEqualTo;
	}
	public void setFrfMarkGreaterThanOrEqualTo(String frfMarkGreaterThanOrEqualTo) {
		this.frfMarkGreaterThanOrEqualTo = frfMarkGreaterThanOrEqualTo;
	}

	public String getFrfMarkGreaterThan() {
		return frfMarkGreaterThan;
	}
	public void setFrfMarkGreaterThan(String frfMarkGreaterThan) {
		this.frfMarkGreaterThan = frfMarkGreaterThan;
	}

	public String getFrfMarkEqualTo() {
		return frfMarkEqualTo;
	}
	public void setFrfMarkEqualTo(String frfMarkEqualTo) {
		this.frfMarkEqualTo = frfMarkEqualTo;
	}

	public java.util.List getFrfIdNotIn() {
		return frfIdNotIn;
	}
	public void setFrfIdNotIn(java.util.List frfIdNotIn) {
		this.frfIdNotIn = frfIdNotIn;
	}

	public Long getFrfIdNotEqualTo() {
		return frfIdNotEqualTo;
	}
	public void setFrfIdNotEqualTo(Long frfIdNotEqualTo) {
		this.frfIdNotEqualTo = frfIdNotEqualTo;
	}

	public Long getFrfIdLessThanOrEqualTo() {
		return frfIdLessThanOrEqualTo;
	}
	public void setFrfIdLessThanOrEqualTo(Long frfIdLessThanOrEqualTo) {
		this.frfIdLessThanOrEqualTo = frfIdLessThanOrEqualTo;
	}

	public Long getFrfIdLessThan() {
		return frfIdLessThan;
	}
	public void setFrfIdLessThan(Long frfIdLessThan) {
		this.frfIdLessThan = frfIdLessThan;
	}

	public Boolean getFrfIdIsNull() {
		return frfIdIsNull;
	}
	public void setFrfIdIsNull(Boolean frfIdIsNull) {
		this.frfIdIsNull = frfIdIsNull;
	}

	public Boolean getFrfIdIsNotNull() {
		return frfIdIsNotNull;
	}
	public void setFrfIdIsNotNull(Boolean frfIdIsNotNull) {
		this.frfIdIsNotNull = frfIdIsNotNull;
	}

	public java.util.List getFrfIdIn() {
		return frfIdIn;
	}
	public void setFrfIdIn(java.util.List frfIdIn) {
		this.frfIdIn = frfIdIn;
	}

	public Long getFrfIdGreaterThanOrEqualTo() {
		return frfIdGreaterThanOrEqualTo;
	}
	public void setFrfIdGreaterThanOrEqualTo(Long frfIdGreaterThanOrEqualTo) {
		this.frfIdGreaterThanOrEqualTo = frfIdGreaterThanOrEqualTo;
	}

	public Long getFrfIdGreaterThan() {
		return frfIdGreaterThan;
	}
	public void setFrfIdGreaterThan(Long frfIdGreaterThan) {
		this.frfIdGreaterThan = frfIdGreaterThan;
	}

	public Long getFrfIdEqualTo() {
		return frfIdEqualTo;
	}
	public void setFrfIdEqualTo(Long frfIdEqualTo) {
		this.frfIdEqualTo = frfIdEqualTo;
	}

	public java.util.List getDrNotIn() {
		return drNotIn;
	}
	public void setDrNotIn(java.util.List drNotIn) {
		this.drNotIn = drNotIn;
	}

	public Integer getDrNotEqualTo() {
		return drNotEqualTo;
	}
	public void setDrNotEqualTo(Integer drNotEqualTo) {
		this.drNotEqualTo = drNotEqualTo;
	}

	public Integer getDrLessThanOrEqualTo() {
		return drLessThanOrEqualTo;
	}
	public void setDrLessThanOrEqualTo(Integer drLessThanOrEqualTo) {
		this.drLessThanOrEqualTo = drLessThanOrEqualTo;
	}

	public Integer getDrLessThan() {
		return drLessThan;
	}
	public void setDrLessThan(Integer drLessThan) {
		this.drLessThan = drLessThan;
	}

	public Boolean getDrIsNull() {
		return drIsNull;
	}
	public void setDrIsNull(Boolean drIsNull) {
		this.drIsNull = drIsNull;
	}

	public Boolean getDrIsNotNull() {
		return drIsNotNull;
	}
	public void setDrIsNotNull(Boolean drIsNotNull) {
		this.drIsNotNull = drIsNotNull;
	}

	public java.util.List getDrIn() {
		return drIn;
	}
	public void setDrIn(java.util.List drIn) {
		this.drIn = drIn;
	}

	public Integer getDrGreaterThanOrEqualTo() {
		return drGreaterThanOrEqualTo;
	}
	public void setDrGreaterThanOrEqualTo(Integer drGreaterThanOrEqualTo) {
		this.drGreaterThanOrEqualTo = drGreaterThanOrEqualTo;
	}

	public Integer getDrGreaterThan() {
		return drGreaterThan;
	}
	public void setDrGreaterThan(Integer drGreaterThan) {
		this.drGreaterThan = drGreaterThan;
	}

	public Integer getDrEqualTo() {
		return drEqualTo;
	}
	public void setDrEqualTo(Integer drEqualTo) {
		this.drEqualTo = drEqualTo;
	}

	public String getCreateuserNotLike() {
		return createuserNotLike;
	}
	public void setCreateuserNotLike(String createuserNotLike) {
		this.createuserNotLike = createuserNotLike;
	}

	public java.util.List getCreateuserNotIn() {
		return createuserNotIn;
	}
	public void setCreateuserNotIn(java.util.List createuserNotIn) {
		this.createuserNotIn = createuserNotIn;
	}

	public String getCreateuserNotEqualTo() {
		return createuserNotEqualTo;
	}
	public void setCreateuserNotEqualTo(String createuserNotEqualTo) {
		this.createuserNotEqualTo = createuserNotEqualTo;
	}

	public String getCreateuserLike() {
		return createuserLike;
	}
	public void setCreateuserLike(String createuserLike) {
		this.createuserLike = createuserLike;
	}

	public String getCreateuserLessThanOrEqualTo() {
		return createuserLessThanOrEqualTo;
	}
	public void setCreateuserLessThanOrEqualTo(String createuserLessThanOrEqualTo) {
		this.createuserLessThanOrEqualTo = createuserLessThanOrEqualTo;
	}

	public String getCreateuserLessThan() {
		return createuserLessThan;
	}
	public void setCreateuserLessThan(String createuserLessThan) {
		this.createuserLessThan = createuserLessThan;
	}

	public Boolean getCreateuserIsNull() {
		return createuserIsNull;
	}
	public void setCreateuserIsNull(Boolean createuserIsNull) {
		this.createuserIsNull = createuserIsNull;
	}

	public Boolean getCreateuserIsNotNull() {
		return createuserIsNotNull;
	}
	public void setCreateuserIsNotNull(Boolean createuserIsNotNull) {
		this.createuserIsNotNull = createuserIsNotNull;
	}

	public java.util.List getCreateuserIn() {
		return createuserIn;
	}
	public void setCreateuserIn(java.util.List createuserIn) {
		this.createuserIn = createuserIn;
	}

	public String getCreateuserGreaterThanOrEqualTo() {
		return createuserGreaterThanOrEqualTo;
	}
	public void setCreateuserGreaterThanOrEqualTo(String createuserGreaterThanOrEqualTo) {
		this.createuserGreaterThanOrEqualTo = createuserGreaterThanOrEqualTo;
	}

	public String getCreateuserGreaterThan() {
		return createuserGreaterThan;
	}
	public void setCreateuserGreaterThan(String createuserGreaterThan) {
		this.createuserGreaterThan = createuserGreaterThan;
	}

	public String getCreateuserEqualTo() {
		return createuserEqualTo;
	}
	public void setCreateuserEqualTo(String createuserEqualTo) {
		this.createuserEqualTo = createuserEqualTo;
	}

	public java.util.List getCreatetimeNotIn() {
		return createtimeNotIn;
	}
	public void setCreatetimeNotIn(java.util.List createtimeNotIn) {
		this.createtimeNotIn = createtimeNotIn;
	}

	public java.util.Date getCreatetimeNotEqualTo() {
		return createtimeNotEqualTo;
	}
	public void setCreatetimeNotEqualTo(java.util.Date createtimeNotEqualTo) {
		this.createtimeNotEqualTo = createtimeNotEqualTo;
	}

	public java.util.Date getCreatetimeLessThanOrEqualTo() {
		return createtimeLessThanOrEqualTo;
	}
	public void setCreatetimeLessThanOrEqualTo(java.util.Date createtimeLessThanOrEqualTo) {
		this.createtimeLessThanOrEqualTo = createtimeLessThanOrEqualTo;
	}

	public java.util.Date getCreatetimeLessThan() {
		return createtimeLessThan;
	}
	public void setCreatetimeLessThan(java.util.Date createtimeLessThan) {
		this.createtimeLessThan = createtimeLessThan;
	}

	public Boolean getCreatetimeIsNull() {
		return createtimeIsNull;
	}
	public void setCreatetimeIsNull(Boolean createtimeIsNull) {
		this.createtimeIsNull = createtimeIsNull;
	}

	public Boolean getCreatetimeIsNotNull() {
		return createtimeIsNotNull;
	}
	public void setCreatetimeIsNotNull(Boolean createtimeIsNotNull) {
		this.createtimeIsNotNull = createtimeIsNotNull;
	}

	public java.util.List getCreatetimeIn() {
		return createtimeIn;
	}
	public void setCreatetimeIn(java.util.List createtimeIn) {
		this.createtimeIn = createtimeIn;
	}

	public java.util.Date getCreatetimeGreaterThanOrEqualTo() {
		return createtimeGreaterThanOrEqualTo;
	}
	public void setCreatetimeGreaterThanOrEqualTo(java.util.Date createtimeGreaterThanOrEqualTo) {
		this.createtimeGreaterThanOrEqualTo = createtimeGreaterThanOrEqualTo;
	}

	public java.util.Date getCreatetimeGreaterThan() {
		return createtimeGreaterThan;
	}
	public void setCreatetimeGreaterThan(java.util.Date createtimeGreaterThan) {
		this.createtimeGreaterThan = createtimeGreaterThan;
	}

	public java.util.Date getCreatetimeEqualTo() {
		return createtimeEqualTo;
	}
	public void setCreatetimeEqualTo(java.util.Date createtimeEqualTo) {
		this.createtimeEqualTo = createtimeEqualTo;
	}

	public void setSidx(String sidx) {
		this.sidx = sidx;
	}
	public String getSord() {
		return sord;
	}
	public void setSord(String sord) {
		 this.sord = sord;
	}
}
