package com.mrk.finance.model;

import com.mrk.common.base.BaseEntity;
import io.swagger.annotations.ApiModelProperty;
import lombok.Getter;
import lombok.Setter;

import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import java.io.Serializable;

@Setter
@Getter
public class FncRevenueWaterRecord extends BaseEntity implements Serializable {
private static final long serialVersionUID=1L;


    /**主键 */
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @ApiModelProperty(value = "主键")
    private Long frwrId;

    /**账单ID */
    @ApiModelProperty(value = "账单ID")
    private Long frwrBillId;

    /**收支流水类型 */
    @ApiModelProperty(value = "收支流水类型")
    private Integer frwrRevenueType;

    /**收支流水ID */
    @ApiModelProperty(value = "收支流水ID")
    private Long frwrRevenueId;

    /**匹配方式 */
    @ApiModelProperty(value = "匹配方式")
    private Integer frwrMatchState;

    /**描述 */
    @ApiModelProperty(value = "描述")
    private String frwrDescribe;
    }
