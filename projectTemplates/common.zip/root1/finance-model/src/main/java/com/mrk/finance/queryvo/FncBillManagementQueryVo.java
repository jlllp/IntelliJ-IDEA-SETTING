package com.mrk.finance.queryvo;

import com.mrk.common.base.BaseQueryVo;
import io.swagger.annotations.ApiModelProperty;
import lombok.Getter;
import lombok.Setter;
import com.fasterxml.jackson.annotation.JsonFormat;
import org.springframework.format.annotation.DateTimeFormat;

import java.util.List;

@Setter
@Getter
public class FncBillManagementQueryVo extends BaseQueryVo {


    @ApiModelProperty(value = "主键 精确匹配")
    private Long fbmIdEqualTo;

    @ApiModelProperty(value = "主键 模糊匹配")
    private Long fbmIdLike;


    @ApiModelProperty(value = "城市 精确匹配")
    private Long fbmCityIdEqualTo;

    @ApiModelProperty(value = "城市 模糊匹配")
    private Long fbmCityIdLike;


    @ApiModelProperty(value = "科目（类型）0, 租金)1, 滞纳金)2, 违约金(3, 购车尾款)4, 保证金); 精确匹配")
    private Integer fbmSubjectsEqualTo;

    @ApiModelProperty(value = "科目（类型）0, 租金)1, 滞纳金)2, 违约金(3, 购车尾款)4, 保证金); 模糊匹配")
    private Integer fbmSubjectsLike;


    @ApiModelProperty(value = "账单金额 精确匹配")
    private Double fbmBillAmountEqualTo;

    @ApiModelProperty(value = "账单金额 模糊匹配")
    private Double fbmBillAmountLike;


    @ApiModelProperty(value = "期数 精确匹配")
    private String fbmNperEqualTo;

    @ApiModelProperty(value = "期数 模糊匹配")
    private String fbmNperLike;


    @ApiModelProperty(value = "账单生成时间 大于或等于")
    @DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss", timezone = "GMT+8")
    private java.util.Date fbmBillGenerateTimeGreaterThanOrEqualTo;

    @DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss", timezone = "GMT+8")
    @ApiModelProperty(value = "账单生成时间 小于或等于")
    private java.util.Date fbmBillGenerateTimeLessThanOrEqualTo;
    @ApiModelProperty(value = "账单生成时间 精确匹配")
    private java.util.Date fbmBillGenerateTimeEqualTo;

    @ApiModelProperty(value = "账单生成时间 模糊匹配")
    private java.util.Date fbmBillGenerateTimeLike;


    @ApiModelProperty(value = "账单生成方式（0, 手动生成)1, 自动生成 精确匹配")
    private Integer fbmBillGenerateWayEqualTo;

    @ApiModelProperty(value = "账单生成方式（0, 手动生成)1, 自动生成 模糊匹配")
    private Integer fbmBillGenerateWayLike;


    @ApiModelProperty(value = "账单截止时间 大于或等于")
    @DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss", timezone = "GMT+8")
    private java.util.Date fbmBillCatoffTimeGreaterThanOrEqualTo;

    @DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss", timezone = "GMT+8")
    @ApiModelProperty(value = "账单截止时间 小于或等于")
    private java.util.Date fbmBillCatoffTimeLessThanOrEqualTo;
    @ApiModelProperty(value = "账单截止时间 精确匹配")
    private java.util.Date fbmBillCatoffTimeEqualTo;

    @ApiModelProperty(value = "账单截止时间 模糊匹配")
    private java.util.Date fbmBillCatoffTimeLike;


    @ApiModelProperty(value = "关联车辆ID 精确匹配")
    private Long fbmAssociateCarIdEqualTo;

    @ApiModelProperty(value = "关联车辆ID 模糊匹配")
    private Long fbmAssociateCarIdLike;


    @ApiModelProperty(value = "关联合同ID 精确匹配")
    private Long fbmAssociateContractIdEqualTo;

    @ApiModelProperty(value = "关联合同ID 模糊匹配")
    private Long fbmAssociateContractIdLike;


    @ApiModelProperty(value = "账单状态(账单状态 0无 1审批中 2已驳回 3未支付 4部分支付 5已支付 6已作废 7开票中 8已开票 9退还中 10部分退还 11已退还 精确匹配")
    private Integer fbmBillStateEqualTo;

    @ApiModelProperty(value = "账单状态(账单状态 0无 1审批中 2已驳回 3未支付 4部分支付 5已支付 6已作废 7开票中 8已开票 9退还中 10部分退还 11已退还 模糊匹配")
    private Integer fbmBillStateLike;


    @ApiModelProperty(value = "匹配方式 精确匹配")
    private Integer fbmMatchWayEqualTo;

    @ApiModelProperty(value = "匹配方式 模糊匹配")
    private Integer fbmMatchWayLike;


    @ApiModelProperty(value = "匹配人ID 精确匹配")
    private Long fbmMatchUserIdEqualTo;

    @ApiModelProperty(value = "匹配人ID 模糊匹配")
    private Long fbmMatchUserIdLike;


    @ApiModelProperty(value = "匹配时间 大于或等于")
    @DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss", timezone = "GMT+8")
    private java.util.Date fbmMatchTimeGreaterThanOrEqualTo;

    @DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss", timezone = "GMT+8")
    @ApiModelProperty(value = "匹配时间 小于或等于")
    private java.util.Date fbmMatchTimeLessThanOrEqualTo;
    @ApiModelProperty(value = "匹配时间 精确匹配")
    private java.util.Date fbmMatchTimeEqualTo;

    @ApiModelProperty(value = "匹配时间 模糊匹配")
    private java.util.Date fbmMatchTimeLike;


    @ApiModelProperty(value = "匹配流水号 精确匹配")
    private String fbmMatchSerialNumberEqualTo;

    @ApiModelProperty(value = "匹配流水号 模糊匹配")
    private String fbmMatchSerialNumberLike;


    @ApiModelProperty(value = "支付时间 大于或等于")
    @DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss", timezone = "GMT+8")
    private java.util.Date fbmPayTimeGreaterThanOrEqualTo;

    @DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss", timezone = "GMT+8")
    @ApiModelProperty(value = "支付时间 小于或等于")
    private java.util.Date fbmPayTimeLessThanOrEqualTo;
    @ApiModelProperty(value = "支付时间 精确匹配")
    private java.util.Date fbmPayTimeEqualTo;

    @ApiModelProperty(value = "支付时间 模糊匹配")
    private java.util.Date fbmPayTimeLike;


    @ApiModelProperty(value = "已匹配金额 精确匹配")
    private Double fbmMatchedAmountEqualTo;

    @ApiModelProperty(value = "已匹配金额 模糊匹配")
    private Double fbmMatchedAmountLike;


    @ApiModelProperty(value = "未匹配金额 精确匹配")
    private Double fbmNotMatchAmountEqualTo;

    @ApiModelProperty(value = "未匹配金额 模糊匹配")
    private Double fbmNotMatchAmountLike;


    @ApiModelProperty(value = "账单生成原因 精确匹配")
    private String fbmBillGenerateReasonEqualTo;

    @ApiModelProperty(value = "账单生成原因 模糊匹配")
    private String fbmBillGenerateReasonLike;


    @ApiModelProperty(value = "账单凭证 精确匹配")
    private String fbmBillVoucherEqualTo;

    @ApiModelProperty(value = "账单凭证 模糊匹配")
    private String fbmBillVoucherLike;


    @ApiModelProperty(value = "收车工单是否处理标识（0未处理，1已处理） 精确匹配")
    private Integer fbmTurnerDealEqualTo;

    @ApiModelProperty(value = "收车工单是否处理标识（0未处理，1已处理） 模糊匹配")
    private Integer fbmTurnerDealLike;


    @ApiModelProperty(value = "车辆ID 精确匹配")
    private Long fbmCarIdEqualTo;

    @ApiModelProperty(value = "车辆ID 模糊匹配")
    private Long fbmCarIdLike;


    @ApiModelProperty(value = "合同id 精确匹配")
    private Long fbmContractIdEqualTo;

    @ApiModelProperty(value = "合同id 模糊匹配")
    private Long fbmContractIdLike;


    @ApiModelProperty(value = "计租日期 大于或等于")
    @DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss", timezone = "GMT+8")
    private java.util.Date fbmLeasePeriodGreaterThanOrEqualTo;

    @DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss", timezone = "GMT+8")
    @ApiModelProperty(value = "计租日期 小于或等于")
    private java.util.Date fbmLeasePeriodLessThanOrEqualTo;
    @ApiModelProperty(value = "计租日期 精确匹配")
    private java.util.Date fbmLeasePeriodEqualTo;

    @ApiModelProperty(value = "计租日期 模糊匹配")
    private java.util.Date fbmLeasePeriodLike;


    @ApiModelProperty(value = "减免金额 精确匹配")
    private Double fbmBreaksAmountEqualTo;

    @ApiModelProperty(value = "减免金额 模糊匹配")
    private Double fbmBreaksAmountLike;


    @ApiModelProperty(value = "减免类型 精确匹配")
    private Integer fbmBreaksTypeEqualTo;

    @ApiModelProperty(value = "减免类型 模糊匹配")
    private Integer fbmBreaksTypeLike;


    @ApiModelProperty(value = "减免凭证 精确匹配")
    private String fbmBreaksCredentialsEqualTo;

    @ApiModelProperty(value = "减免凭证 模糊匹配")
    private String fbmBreaksCredentialsLike;


    @ApiModelProperty(value = "减免备注 精确匹配")
    private String fbmBreaksRemarkEqualTo;

    @ApiModelProperty(value = "减免备注 模糊匹配")
    private String fbmBreaksRemarkLike;


    @ApiModelProperty(value = "减免后金额 精确匹配")
    private Double fbmBreaksAfterAmountEqualTo;

    @ApiModelProperty(value = "减免后金额 模糊匹配")
    private Double fbmBreaksAfterAmountLike;

    private List<Integer> fbmBillStateIn;

    @ApiModelProperty(value = "减免操作人手机号 精确匹配")
    private String fbmBreaksPhoneEqualTo;

    @ApiModelProperty(value = "减免操作人手机号 模糊匹配")
    private String fbmBreaksPhoneLike;


    @ApiModelProperty(value = "减免操作时间 大于或等于")
    @DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss", timezone = "GMT+8")
    private java.util.Date fbmBreaksTimeGreaterThanOrEqualTo;

    @DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss", timezone = "GMT+8")
    @ApiModelProperty(value = "减免操作时间 小于或等于")
    private java.util.Date fbmBreaksTimeLessThanOrEqualTo;
    @ApiModelProperty(value = "减免操作时间 精确匹配")
    private java.util.Date fbmBreaksTimeEqualTo;

    @ApiModelProperty(value = "减免操作时间 模糊匹配")
    private java.util.Date fbmBreaksTimeLike;


    @ApiModelProperty(value = "逾期状态 0无 1未逾期 2已逾期 精确匹配")
    private Integer fbmOverdueStateEqualTo;

    @ApiModelProperty(value = "逾期状态 0无 1未逾期 2已逾期 模糊匹配")
    private Integer fbmOverdueStateLike;


    @ApiModelProperty(value = "批量方式 精确匹配")
    private String fbmMatchTypeEqualTo;

    @ApiModelProperty(value = "批量方式 模糊匹配")
    private String fbmMatchTypeLike;


    @ApiModelProperty(value = "匹配人手机号 精确匹配")
    private String fbmMatchPhoneEqualTo;

    @ApiModelProperty(value = "匹配人手机号 模糊匹配")
    private String fbmMatchPhoneLike;


    @ApiModelProperty(value = "已支付金额 精确匹配")
    private Double fbmPayAmonutEqualTo;

    @ApiModelProperty(value = "已支付金额 模糊匹配")
    private Double fbmPayAmonutLike;


    @ApiModelProperty(value = "未支付金额 精确匹配")
    private Double fbmUnpayAmountEqualTo;

    @ApiModelProperty(value = "未支付金额 模糊匹配")
    private Double fbmUnpayAmountLike;


    @ApiModelProperty(value = "应退还金额 精确匹配")
    private Double fbmRefundAmountEqualTo;

    @ApiModelProperty(value = "应退还金额 模糊匹配")
    private Double fbmRefundAmountLike;


    @ApiModelProperty(value = "未退还金额 精确匹配")
    private Double fbmUnRefundAmountEqualTo;

    @ApiModelProperty(value = "未退还金额 模糊匹配")
    private Double fbmUnRefundAmountLike;


    @ApiModelProperty(value = "已退还金额 精确匹配")
    private Double fbmAlreadyRefundAmountEqualTo;

    @ApiModelProperty(value = "已退还金额 模糊匹配")
    private Double fbmAlreadyRefundAmountLike;
}
