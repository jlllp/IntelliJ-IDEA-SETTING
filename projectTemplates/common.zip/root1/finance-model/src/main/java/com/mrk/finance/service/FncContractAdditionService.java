package com.mrk.finance.service;

import com.github.pagehelper.PageInfo;
import com.mrk.finance.model.FncContractAddition;
import com.mrk.finance.queryvo.FncContractAdditionQueryVo;

import java.util.Date;
import java.util.List;

/**
 * @Description: FncContractAddition
 */
public interface FncContractAdditionService {
    /**
     * 分页查询
     *
     * @param queryVo 前端查询对象
     * @return 分页查询数据
     */
    PageInfo<FncContractAddition> page(FncContractAdditionQueryVo queryVo);

    /**
     * 列表查询
     * @param queryVo 前端查询对象
     * @return 分页查询数据
     */
    List<FncContractAddition> list(FncContractAdditionQueryVo queryVo);

    /**
     * 根据合同id,批量查询
     * @author Frank.Tang
     * @return *
     */
    List<FncContractAddition> selectByContractIds(List<Long> ids);

    /**
     * 新增
     *
     * @param entity
     * @return 结果
     */
    int add(FncContractAddition entity);

    /**
     * 修改
     *
     * @param entity
     * @return 结果
     */
    int update(FncContractAddition entity);

    /**
     * 修改非空
     * @author Frank.Tang
     * @return *
     */
    int updateSelective(FncContractAddition entity);

    /**
     * 删除
     */
    int delete(Long id);

    /**
     * 通过ID查询
     * @param id
     */
    FncContractAddition getById(Long id);

    /**
     * @author Bob
     * @date 2021/12/24
     * @description 获取提前还车合同
     * @param start 开始时间
     * @param end 结束时间
     * @return 对应的补充合同
     */
    List<FncContractAddition> getByLeaseEnd(Date start, Date end);

    /**
     * @author Bob
     * @date 2021/12/24
     * @description 获取解除租赁合同
     * @param start 开始时间
     * @param end 结束时间
     * @return 对应的补充合同
     */
    List<FncContractAddition> getByTerminate(Date start, Date end);
}
