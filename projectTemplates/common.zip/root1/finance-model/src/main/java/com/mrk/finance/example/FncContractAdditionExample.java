package com.mrk.finance.example;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

public class FncContractAdditionExample {
    protected String orderByClause;

    protected boolean distinct;

    protected List<Criteria> oredCriteria;

    public FncContractAdditionExample() {
        oredCriteria = new ArrayList<Criteria>();
    }

    public void setOrderByClause(String orderByClause) {
        this.orderByClause = orderByClause;
    }

    public String getOrderByClause() {
        return orderByClause;
    }

    public void setDistinct(boolean distinct) {
        this.distinct = distinct;
    }

    public boolean isDistinct() {
        return distinct;
    }

    public List<Criteria> getOredCriteria() {
        return oredCriteria;
    }

    public void or(Criteria criteria) {
        oredCriteria.add(criteria);
    }

    public Criteria or() {
        Criteria criteria = createCriteriaInternal();
        oredCriteria.add(criteria);
        return criteria;
    }

    public Criteria createCriteria() {
        Criteria criteria = createCriteriaInternal();
        if (oredCriteria.size() == 0) {
            oredCriteria.add(criteria);
        }
        return criteria;
    }

    protected Criteria createCriteriaInternal() {
        Criteria criteria = new Criteria();
        return criteria;
    }

    public void clear() {
        oredCriteria.clear();
        orderByClause = null;
        distinct = false;
    }

    protected abstract static class GeneratedCriteria {
        protected List<Criterion> criteria;

        protected GeneratedCriteria() {
            super();
            criteria = new ArrayList<Criterion>();
        }

        public boolean isValid() {
            return criteria.size() > 0;
        }

        public List<Criterion> getAllCriteria() {
            return criteria;
        }

        public List<Criterion> getCriteria() {
            return criteria;
        }

        protected void addCriterion(String condition) {
            if (condition == null) {
                throw new RuntimeException("Value for condition cannot be null");
            }
            criteria.add(new Criterion(condition));
        }

        protected void addCriterion(String condition, Object value, String property) {
            if (value == null) {
                throw new RuntimeException("Value for " + property + " cannot be null");
            }
            criteria.add(new Criterion(condition, value));
        }

        protected void addCriterion(String condition, Object value1, Object value2, String property) {
            if (value1 == null || value2 == null) {
                throw new RuntimeException("Between values for " + property + " cannot be null");
            }
            criteria.add(new Criterion(condition, value1, value2));
        }

        public Criteria andFcaIdIsNull() {
            addCriterion("fca_id is null");
            return (Criteria) this;
        }

        public Criteria andFcaIdIsNotNull() {
            addCriterion("fca_id is not null");
            return (Criteria) this;
        }

        public Criteria andFcaIdEqualTo(Long value) {
            addCriterion("fca_id =", value, "fcaId");
            return (Criteria) this;
        }

        public Criteria andFcaIdNotEqualTo(Long value) {
            addCriterion("fca_id <>", value, "fcaId");
            return (Criteria) this;
        }

        public Criteria andFcaIdGreaterThan(Long value) {
            addCriterion("fca_id >", value, "fcaId");
            return (Criteria) this;
        }

        public Criteria andFcaIdGreaterThanOrEqualTo(Long value) {
            addCriterion("fca_id >=", value, "fcaId");
            return (Criteria) this;
        }

        public Criteria andFcaIdLessThan(Long value) {
            addCriterion("fca_id <", value, "fcaId");
            return (Criteria) this;
        }

        public Criteria andFcaIdLessThanOrEqualTo(Long value) {
            addCriterion("fca_id <=", value, "fcaId");
            return (Criteria) this;
        }

        public Criteria andFcaIdIn(List<Long> values) {
            addCriterion("fca_id in", values, "fcaId");
            return (Criteria) this;
        }

        public Criteria andFcaIdNotIn(List<Long> values) {
            addCriterion("fca_id not in", values, "fcaId");
            return (Criteria) this;
        }

        public Criteria andFcaIdBetween(Long value1, Long value2) {
            addCriterion("fca_id between", value1, value2, "fcaId");
            return (Criteria) this;
        }

        public Criteria andFcaIdNotBetween(Long value1, Long value2) {
            addCriterion("fca_id not between", value1, value2, "fcaId");
            return (Criteria) this;
        }

        public Criteria andFcaTypeIsNull() {
            addCriterion("fca_type is null");
            return (Criteria) this;
        }

        public Criteria andFcaTypeIsNotNull() {
            addCriterion("fca_type is not null");
            return (Criteria) this;
        }

        public Criteria andFcaTypeEqualTo(Integer value) {
            addCriterion("fca_type =", value, "fcaType");
            return (Criteria) this;
        }

        public Criteria andFcaTypeNotEqualTo(Integer value) {
            addCriterion("fca_type <>", value, "fcaType");
            return (Criteria) this;
        }

        public Criteria andFcaTypeGreaterThan(Integer value) {
            addCriterion("fca_type >", value, "fcaType");
            return (Criteria) this;
        }

        public Criteria andFcaTypeGreaterThanOrEqualTo(Integer value) {
            addCriterion("fca_type >=", value, "fcaType");
            return (Criteria) this;
        }

        public Criteria andFcaTypeLessThan(Integer value) {
            addCriterion("fca_type <", value, "fcaType");
            return (Criteria) this;
        }

        public Criteria andFcaTypeLessThanOrEqualTo(Integer value) {
            addCriterion("fca_type <=", value, "fcaType");
            return (Criteria) this;
        }

        public Criteria andFcaTypeIn(List<Integer> values) {
            addCriterion("fca_type in", values, "fcaType");
            return (Criteria) this;
        }

        public Criteria andFcaTypeNotIn(List<Integer> values) {
            addCriterion("fca_type not in", values, "fcaType");
            return (Criteria) this;
        }

        public Criteria andFcaTypeBetween(Integer value1, Integer value2) {
            addCriterion("fca_type between", value1, value2, "fcaType");
            return (Criteria) this;
        }

        public Criteria andFcaTypeNotBetween(Integer value1, Integer value2) {
            addCriterion("fca_type not between", value1, value2, "fcaType");
            return (Criteria) this;
        }

        public Criteria andFcaContractIdIsNull() {
            addCriterion("fca_contract_id is null");
            return (Criteria) this;
        }

        public Criteria andFcaContractIdIsNotNull() {
            addCriterion("fca_contract_id is not null");
            return (Criteria) this;
        }

        public Criteria andFcaContractIdEqualTo(Long value) {
            addCriterion("fca_contract_id =", value, "fcaContractId");
            return (Criteria) this;
        }

        public Criteria andFcaContractIdNotEqualTo(Long value) {
            addCriterion("fca_contract_id <>", value, "fcaContractId");
            return (Criteria) this;
        }

        public Criteria andFcaContractIdGreaterThan(Long value) {
            addCriterion("fca_contract_id >", value, "fcaContractId");
            return (Criteria) this;
        }

        public Criteria andFcaContractIdGreaterThanOrEqualTo(Long value) {
            addCriterion("fca_contract_id >=", value, "fcaContractId");
            return (Criteria) this;
        }

        public Criteria andFcaContractIdLessThan(Long value) {
            addCriterion("fca_contract_id <", value, "fcaContractId");
            return (Criteria) this;
        }

        public Criteria andFcaContractIdLessThanOrEqualTo(Long value) {
            addCriterion("fca_contract_id <=", value, "fcaContractId");
            return (Criteria) this;
        }

        public Criteria andFcaContractIdIn(List<Long> values) {
            addCriterion("fca_contract_id in", values, "fcaContractId");
            return (Criteria) this;
        }

        public Criteria andFcaContractIdNotIn(List<Long> values) {
            addCriterion("fca_contract_id not in", values, "fcaContractId");
            return (Criteria) this;
        }

        public Criteria andFcaContractIdBetween(Long value1, Long value2) {
            addCriterion("fca_contract_id between", value1, value2, "fcaContractId");
            return (Criteria) this;
        }

        public Criteria andFcaContractIdNotBetween(Long value1, Long value2) {
            addCriterion("fca_contract_id not between", value1, value2, "fcaContractId");
            return (Criteria) this;
        }

        public Criteria andFcaContractNoIsNull() {
            addCriterion("fca_contract_no is null");
            return (Criteria) this;
        }

        public Criteria andFcaContractNoIsNotNull() {
            addCriterion("fca_contract_no is not null");
            return (Criteria) this;
        }

        public Criteria andFcaContractNoEqualTo(String value) {
            addCriterion("fca_contract_no =", value, "fcaContractNo");
            return (Criteria) this;
        }

        public Criteria andFcaContractNoNotEqualTo(String value) {
            addCriterion("fca_contract_no <>", value, "fcaContractNo");
            return (Criteria) this;
        }

        public Criteria andFcaContractNoGreaterThan(String value) {
            addCriterion("fca_contract_no >", value, "fcaContractNo");
            return (Criteria) this;
        }

        public Criteria andFcaContractNoGreaterThanOrEqualTo(String value) {
            addCriterion("fca_contract_no >=", value, "fcaContractNo");
            return (Criteria) this;
        }

        public Criteria andFcaContractNoLessThan(String value) {
            addCriterion("fca_contract_no <", value, "fcaContractNo");
            return (Criteria) this;
        }

        public Criteria andFcaContractNoLessThanOrEqualTo(String value) {
            addCriterion("fca_contract_no <=", value, "fcaContractNo");
            return (Criteria) this;
        }

        public Criteria andFcaContractNoLike(String value) {
            addCriterion("fca_contract_no like", value, "fcaContractNo");
            return (Criteria) this;
        }

        public Criteria andFcaContractNoNotLike(String value) {
            addCriterion("fca_contract_no not like", value, "fcaContractNo");
            return (Criteria) this;
        }

        public Criteria andFcaContractNoIn(List<String> values) {
            addCriterion("fca_contract_no in", values, "fcaContractNo");
            return (Criteria) this;
        }

        public Criteria andFcaContractNoNotIn(List<String> values) {
            addCriterion("fca_contract_no not in", values, "fcaContractNo");
            return (Criteria) this;
        }

        public Criteria andFcaContractNoBetween(String value1, String value2) {
            addCriterion("fca_contract_no between", value1, value2, "fcaContractNo");
            return (Criteria) this;
        }

        public Criteria andFcaContractNoNotBetween(String value1, String value2) {
            addCriterion("fca_contract_no not between", value1, value2, "fcaContractNo");
            return (Criteria) this;
        }

        public Criteria andFcaAssociateContractNoIsNull() {
            addCriterion("fca_associate_contract_no is null");
            return (Criteria) this;
        }

        public Criteria andFcaAssociateContractNoIsNotNull() {
            addCriterion("fca_associate_contract_no is not null");
            return (Criteria) this;
        }

        public Criteria andFcaAssociateContractNoEqualTo(String value) {
            addCriterion("fca_associate_contract_no =", value, "fcaAssociateContractNo");
            return (Criteria) this;
        }

        public Criteria andFcaAssociateContractNoNotEqualTo(String value) {
            addCriterion("fca_associate_contract_no <>", value, "fcaAssociateContractNo");
            return (Criteria) this;
        }

        public Criteria andFcaAssociateContractNoGreaterThan(String value) {
            addCriterion("fca_associate_contract_no >", value, "fcaAssociateContractNo");
            return (Criteria) this;
        }

        public Criteria andFcaAssociateContractNoGreaterThanOrEqualTo(String value) {
            addCriterion("fca_associate_contract_no >=", value, "fcaAssociateContractNo");
            return (Criteria) this;
        }

        public Criteria andFcaAssociateContractNoLessThan(String value) {
            addCriterion("fca_associate_contract_no <", value, "fcaAssociateContractNo");
            return (Criteria) this;
        }

        public Criteria andFcaAssociateContractNoLessThanOrEqualTo(String value) {
            addCriterion("fca_associate_contract_no <=", value, "fcaAssociateContractNo");
            return (Criteria) this;
        }

        public Criteria andFcaAssociateContractNoLike(String value) {
            addCriterion("fca_associate_contract_no like", value, "fcaAssociateContractNo");
            return (Criteria) this;
        }

        public Criteria andFcaAssociateContractNoNotLike(String value) {
            addCriterion("fca_associate_contract_no not like", value, "fcaAssociateContractNo");
            return (Criteria) this;
        }

        public Criteria andFcaAssociateContractNoIn(List<String> values) {
            addCriterion("fca_associate_contract_no in", values, "fcaAssociateContractNo");
            return (Criteria) this;
        }

        public Criteria andFcaAssociateContractNoNotIn(List<String> values) {
            addCriterion("fca_associate_contract_no not in", values, "fcaAssociateContractNo");
            return (Criteria) this;
        }

        public Criteria andFcaAssociateContractNoBetween(String value1, String value2) {
            addCriterion("fca_associate_contract_no between", value1, value2, "fcaAssociateContractNo");
            return (Criteria) this;
        }

        public Criteria andFcaAssociateContractNoNotBetween(String value1, String value2) {
            addCriterion("fca_associate_contract_no not between", value1, value2, "fcaAssociateContractNo");
            return (Criteria) this;
        }

        public Criteria andFcaLeaseEndDateIsNull() {
            addCriterion("fca_lease_end_date is null");
            return (Criteria) this;
        }

        public Criteria andFcaLeaseEndDateIsNotNull() {
            addCriterion("fca_lease_end_date is not null");
            return (Criteria) this;
        }

        public Criteria andFcaLeaseEndDateEqualTo(Date value) {
            addCriterion("fca_lease_end_date =", value, "fcaLeaseEndDate");
            return (Criteria) this;
        }

        public Criteria andFcaLeaseEndDateNotEqualTo(Date value) {
            addCriterion("fca_lease_end_date <>", value, "fcaLeaseEndDate");
            return (Criteria) this;
        }

        public Criteria andFcaLeaseEndDateGreaterThan(Date value) {
            addCriterion("fca_lease_end_date >", value, "fcaLeaseEndDate");
            return (Criteria) this;
        }

        public Criteria andFcaLeaseEndDateGreaterThanOrEqualTo(Date value) {
            addCriterion("fca_lease_end_date >=", value, "fcaLeaseEndDate");
            return (Criteria) this;
        }

        public Criteria andFcaLeaseEndDateLessThan(Date value) {
            addCriterion("fca_lease_end_date <", value, "fcaLeaseEndDate");
            return (Criteria) this;
        }

        public Criteria andFcaLeaseEndDateLessThanOrEqualTo(Date value) {
            addCriterion("fca_lease_end_date <=", value, "fcaLeaseEndDate");
            return (Criteria) this;
        }

        public Criteria andFcaLeaseEndDateIn(List<Date> values) {
            addCriterion("fca_lease_end_date in", values, "fcaLeaseEndDate");
            return (Criteria) this;
        }

        public Criteria andFcaLeaseEndDateNotIn(List<Date> values) {
            addCriterion("fca_lease_end_date not in", values, "fcaLeaseEndDate");
            return (Criteria) this;
        }

        public Criteria andFcaLeaseEndDateBetween(Date value1, Date value2) {
            addCriterion("fca_lease_end_date between", value1, value2, "fcaLeaseEndDate");
            return (Criteria) this;
        }

        public Criteria andFcaLeaseEndDateNotBetween(Date value1, Date value2) {
            addCriterion("fca_lease_end_date not between", value1, value2, "fcaLeaseEndDate");
            return (Criteria) this;
        }

        public Criteria andFcaNewCarPlateNumIsNull() {
            addCriterion("fca_new_car_plate_num is null");
            return (Criteria) this;
        }

        public Criteria andFcaNewCarPlateNumIsNotNull() {
            addCriterion("fca_new_car_plate_num is not null");
            return (Criteria) this;
        }

        public Criteria andFcaNewCarPlateNumEqualTo(String value) {
            addCriterion("fca_new_car_plate_num =", value, "fcaNewCarPlateNum");
            return (Criteria) this;
        }

        public Criteria andFcaNewCarPlateNumNotEqualTo(String value) {
            addCriterion("fca_new_car_plate_num <>", value, "fcaNewCarPlateNum");
            return (Criteria) this;
        }

        public Criteria andFcaNewCarPlateNumGreaterThan(String value) {
            addCriterion("fca_new_car_plate_num >", value, "fcaNewCarPlateNum");
            return (Criteria) this;
        }

        public Criteria andFcaNewCarPlateNumGreaterThanOrEqualTo(String value) {
            addCriterion("fca_new_car_plate_num >=", value, "fcaNewCarPlateNum");
            return (Criteria) this;
        }

        public Criteria andFcaNewCarPlateNumLessThan(String value) {
            addCriterion("fca_new_car_plate_num <", value, "fcaNewCarPlateNum");
            return (Criteria) this;
        }

        public Criteria andFcaNewCarPlateNumLessThanOrEqualTo(String value) {
            addCriterion("fca_new_car_plate_num <=", value, "fcaNewCarPlateNum");
            return (Criteria) this;
        }

        public Criteria andFcaNewCarPlateNumLike(String value) {
            addCriterion("fca_new_car_plate_num like", value, "fcaNewCarPlateNum");
            return (Criteria) this;
        }

        public Criteria andFcaNewCarPlateNumNotLike(String value) {
            addCriterion("fca_new_car_plate_num not like", value, "fcaNewCarPlateNum");
            return (Criteria) this;
        }

        public Criteria andFcaNewCarPlateNumIn(List<String> values) {
            addCriterion("fca_new_car_plate_num in", values, "fcaNewCarPlateNum");
            return (Criteria) this;
        }

        public Criteria andFcaNewCarPlateNumNotIn(List<String> values) {
            addCriterion("fca_new_car_plate_num not in", values, "fcaNewCarPlateNum");
            return (Criteria) this;
        }

        public Criteria andFcaNewCarPlateNumBetween(String value1, String value2) {
            addCriterion("fca_new_car_plate_num between", value1, value2, "fcaNewCarPlateNum");
            return (Criteria) this;
        }

        public Criteria andFcaNewCarPlateNumNotBetween(String value1, String value2) {
            addCriterion("fca_new_car_plate_num not between", value1, value2, "fcaNewCarPlateNum");
            return (Criteria) this;
        }

        public Criteria andFcaNewHandoverDateIsNull() {
            addCriterion("fca_new_handover_date is null");
            return (Criteria) this;
        }

        public Criteria andFcaNewHandoverDateIsNotNull() {
            addCriterion("fca_new_handover_date is not null");
            return (Criteria) this;
        }

        public Criteria andFcaNewHandoverDateEqualTo(Date value) {
            addCriterion("fca_new_handover_date =", value, "fcaNewHandoverDate");
            return (Criteria) this;
        }

        public Criteria andFcaNewHandoverDateNotEqualTo(Date value) {
            addCriterion("fca_new_handover_date <>", value, "fcaNewHandoverDate");
            return (Criteria) this;
        }

        public Criteria andFcaNewHandoverDateGreaterThan(Date value) {
            addCriterion("fca_new_handover_date >", value, "fcaNewHandoverDate");
            return (Criteria) this;
        }

        public Criteria andFcaNewHandoverDateGreaterThanOrEqualTo(Date value) {
            addCriterion("fca_new_handover_date >=", value, "fcaNewHandoverDate");
            return (Criteria) this;
        }

        public Criteria andFcaNewHandoverDateLessThan(Date value) {
            addCriterion("fca_new_handover_date <", value, "fcaNewHandoverDate");
            return (Criteria) this;
        }

        public Criteria andFcaNewHandoverDateLessThanOrEqualTo(Date value) {
            addCriterion("fca_new_handover_date <=", value, "fcaNewHandoverDate");
            return (Criteria) this;
        }

        public Criteria andFcaNewHandoverDateIn(List<Date> values) {
            addCriterion("fca_new_handover_date in", values, "fcaNewHandoverDate");
            return (Criteria) this;
        }

        public Criteria andFcaNewHandoverDateNotIn(List<Date> values) {
            addCriterion("fca_new_handover_date not in", values, "fcaNewHandoverDate");
            return (Criteria) this;
        }

        public Criteria andFcaNewHandoverDateBetween(Date value1, Date value2) {
            addCriterion("fca_new_handover_date between", value1, value2, "fcaNewHandoverDate");
            return (Criteria) this;
        }

        public Criteria andFcaNewHandoverDateNotBetween(Date value1, Date value2) {
            addCriterion("fca_new_handover_date not between", value1, value2, "fcaNewHandoverDate");
            return (Criteria) this;
        }

        public Criteria andFcaOldCarReturnDateIsNull() {
            addCriterion("fca_old_car_return_date is null");
            return (Criteria) this;
        }

        public Criteria andFcaOldCarReturnDateIsNotNull() {
            addCriterion("fca_old_car_return_date is not null");
            return (Criteria) this;
        }

        public Criteria andFcaOldCarReturnDateEqualTo(Date value) {
            addCriterion("fca_old_car_return_date =", value, "fcaOldCarReturnDate");
            return (Criteria) this;
        }

        public Criteria andFcaOldCarReturnDateNotEqualTo(Date value) {
            addCriterion("fca_old_car_return_date <>", value, "fcaOldCarReturnDate");
            return (Criteria) this;
        }

        public Criteria andFcaOldCarReturnDateGreaterThan(Date value) {
            addCriterion("fca_old_car_return_date >", value, "fcaOldCarReturnDate");
            return (Criteria) this;
        }

        public Criteria andFcaOldCarReturnDateGreaterThanOrEqualTo(Date value) {
            addCriterion("fca_old_car_return_date >=", value, "fcaOldCarReturnDate");
            return (Criteria) this;
        }

        public Criteria andFcaOldCarReturnDateLessThan(Date value) {
            addCriterion("fca_old_car_return_date <", value, "fcaOldCarReturnDate");
            return (Criteria) this;
        }

        public Criteria andFcaOldCarReturnDateLessThanOrEqualTo(Date value) {
            addCriterion("fca_old_car_return_date <=", value, "fcaOldCarReturnDate");
            return (Criteria) this;
        }

        public Criteria andFcaOldCarReturnDateIn(List<Date> values) {
            addCriterion("fca_old_car_return_date in", values, "fcaOldCarReturnDate");
            return (Criteria) this;
        }

        public Criteria andFcaOldCarReturnDateNotIn(List<Date> values) {
            addCriterion("fca_old_car_return_date not in", values, "fcaOldCarReturnDate");
            return (Criteria) this;
        }

        public Criteria andFcaOldCarReturnDateBetween(Date value1, Date value2) {
            addCriterion("fca_old_car_return_date between", value1, value2, "fcaOldCarReturnDate");
            return (Criteria) this;
        }

        public Criteria andFcaOldCarReturnDateNotBetween(Date value1, Date value2) {
            addCriterion("fca_old_car_return_date not between", value1, value2, "fcaOldCarReturnDate");
            return (Criteria) this;
        }

        public Criteria andFcaContractTerminateDateIsNull() {
            addCriterion("fca_contract_terminate_date is null");
            return (Criteria) this;
        }

        public Criteria andFcaContractTerminateDateIsNotNull() {
            addCriterion("fca_contract_terminate_date is not null");
            return (Criteria) this;
        }

        public Criteria andFcaContractTerminateDateEqualTo(Date value) {
            addCriterion("fca_contract_terminate_date =", value, "fcaContractTerminateDate");
            return (Criteria) this;
        }

        public Criteria andFcaContractTerminateDateNotEqualTo(Date value) {
            addCriterion("fca_contract_terminate_date <>", value, "fcaContractTerminateDate");
            return (Criteria) this;
        }

        public Criteria andFcaContractTerminateDateGreaterThan(Date value) {
            addCriterion("fca_contract_terminate_date >", value, "fcaContractTerminateDate");
            return (Criteria) this;
        }

        public Criteria andFcaContractTerminateDateGreaterThanOrEqualTo(Date value) {
            addCriterion("fca_contract_terminate_date >=", value, "fcaContractTerminateDate");
            return (Criteria) this;
        }

        public Criteria andFcaContractTerminateDateLessThan(Date value) {
            addCriterion("fca_contract_terminate_date <", value, "fcaContractTerminateDate");
            return (Criteria) this;
        }

        public Criteria andFcaContractTerminateDateLessThanOrEqualTo(Date value) {
            addCriterion("fca_contract_terminate_date <=", value, "fcaContractTerminateDate");
            return (Criteria) this;
        }

        public Criteria andFcaContractTerminateDateIn(List<Date> values) {
            addCriterion("fca_contract_terminate_date in", values, "fcaContractTerminateDate");
            return (Criteria) this;
        }

        public Criteria andFcaContractTerminateDateNotIn(List<Date> values) {
            addCriterion("fca_contract_terminate_date not in", values, "fcaContractTerminateDate");
            return (Criteria) this;
        }

        public Criteria andFcaContractTerminateDateBetween(Date value1, Date value2) {
            addCriterion("fca_contract_terminate_date between", value1, value2, "fcaContractTerminateDate");
            return (Criteria) this;
        }

        public Criteria andFcaContractTerminateDateNotBetween(Date value1, Date value2) {
            addCriterion("fca_contract_terminate_date not between", value1, value2, "fcaContractTerminateDate");
            return (Criteria) this;
        }

        public Criteria andFcaInformationFeeIsNull() {
            addCriterion("fca_information_fee is null");
            return (Criteria) this;
        }

        public Criteria andFcaInformationFeeIsNotNull() {
            addCriterion("fca_information_fee is not null");
            return (Criteria) this;
        }

        public Criteria andFcaInformationFeeEqualTo(Double value) {
            addCriterion("fca_information_fee =", value, "fcaInformationFee");
            return (Criteria) this;
        }

        public Criteria andFcaInformationFeeNotEqualTo(Double value) {
            addCriterion("fca_information_fee <>", value, "fcaInformationFee");
            return (Criteria) this;
        }

        public Criteria andFcaInformationFeeGreaterThan(Double value) {
            addCriterion("fca_information_fee >", value, "fcaInformationFee");
            return (Criteria) this;
        }

        public Criteria andFcaInformationFeeGreaterThanOrEqualTo(Double value) {
            addCriterion("fca_information_fee >=", value, "fcaInformationFee");
            return (Criteria) this;
        }

        public Criteria andFcaInformationFeeLessThan(Double value) {
            addCriterion("fca_information_fee <", value, "fcaInformationFee");
            return (Criteria) this;
        }

        public Criteria andFcaInformationFeeLessThanOrEqualTo(Double value) {
            addCriterion("fca_information_fee <=", value, "fcaInformationFee");
            return (Criteria) this;
        }

        public Criteria andFcaInformationFeeIn(List<Double> values) {
            addCriterion("fca_information_fee in", values, "fcaInformationFee");
            return (Criteria) this;
        }

        public Criteria andFcaInformationFeeNotIn(List<Double> values) {
            addCriterion("fca_information_fee not in", values, "fcaInformationFee");
            return (Criteria) this;
        }

        public Criteria andFcaInformationFeeBetween(Double value1, Double value2) {
            addCriterion("fca_information_fee between", value1, value2, "fcaInformationFee");
            return (Criteria) this;
        }

        public Criteria andFcaInformationFeeNotBetween(Double value1, Double value2) {
            addCriterion("fca_information_fee not between", value1, value2, "fcaInformationFee");
            return (Criteria) this;
        }

        public Criteria andFcaPayTypeIsNull() {
            addCriterion("fca_pay_type is null");
            return (Criteria) this;
        }

        public Criteria andFcaPayTypeIsNotNull() {
            addCriterion("fca_pay_type is not null");
            return (Criteria) this;
        }

        public Criteria andFcaPayTypeEqualTo(Integer value) {
            addCriterion("fca_pay_type =", value, "fcaPayType");
            return (Criteria) this;
        }

        public Criteria andFcaPayTypeNotEqualTo(Integer value) {
            addCriterion("fca_pay_type <>", value, "fcaPayType");
            return (Criteria) this;
        }

        public Criteria andFcaPayTypeGreaterThan(Integer value) {
            addCriterion("fca_pay_type >", value, "fcaPayType");
            return (Criteria) this;
        }

        public Criteria andFcaPayTypeGreaterThanOrEqualTo(Integer value) {
            addCriterion("fca_pay_type >=", value, "fcaPayType");
            return (Criteria) this;
        }

        public Criteria andFcaPayTypeLessThan(Integer value) {
            addCriterion("fca_pay_type <", value, "fcaPayType");
            return (Criteria) this;
        }

        public Criteria andFcaPayTypeLessThanOrEqualTo(Integer value) {
            addCriterion("fca_pay_type <=", value, "fcaPayType");
            return (Criteria) this;
        }

        public Criteria andFcaPayTypeIn(List<Integer> values) {
            addCriterion("fca_pay_type in", values, "fcaPayType");
            return (Criteria) this;
        }

        public Criteria andFcaPayTypeNotIn(List<Integer> values) {
            addCriterion("fca_pay_type not in", values, "fcaPayType");
            return (Criteria) this;
        }

        public Criteria andFcaPayTypeBetween(Integer value1, Integer value2) {
            addCriterion("fca_pay_type between", value1, value2, "fcaPayType");
            return (Criteria) this;
        }

        public Criteria andFcaPayTypeNotBetween(Integer value1, Integer value2) {
            addCriterion("fca_pay_type not between", value1, value2, "fcaPayType");
            return (Criteria) this;
        }

        public Criteria andRemarkIsNull() {
            addCriterion("remark is null");
            return (Criteria) this;
        }

        public Criteria andRemarkIsNotNull() {
            addCriterion("remark is not null");
            return (Criteria) this;
        }

        public Criteria andRemarkEqualTo(String value) {
            addCriterion("remark =", value, "remark");
            return (Criteria) this;
        }

        public Criteria andRemarkNotEqualTo(String value) {
            addCriterion("remark <>", value, "remark");
            return (Criteria) this;
        }

        public Criteria andRemarkGreaterThan(String value) {
            addCriterion("remark >", value, "remark");
            return (Criteria) this;
        }

        public Criteria andRemarkGreaterThanOrEqualTo(String value) {
            addCriterion("remark >=", value, "remark");
            return (Criteria) this;
        }

        public Criteria andRemarkLessThan(String value) {
            addCriterion("remark <", value, "remark");
            return (Criteria) this;
        }

        public Criteria andRemarkLessThanOrEqualTo(String value) {
            addCriterion("remark <=", value, "remark");
            return (Criteria) this;
        }

        public Criteria andRemarkLike(String value) {
            addCriterion("remark like", value, "remark");
            return (Criteria) this;
        }

        public Criteria andRemarkNotLike(String value) {
            addCriterion("remark not like", value, "remark");
            return (Criteria) this;
        }

        public Criteria andRemarkIn(List<String> values) {
            addCriterion("remark in", values, "remark");
            return (Criteria) this;
        }

        public Criteria andRemarkNotIn(List<String> values) {
            addCriterion("remark not in", values, "remark");
            return (Criteria) this;
        }

        public Criteria andRemarkBetween(String value1, String value2) {
            addCriterion("remark between", value1, value2, "remark");
            return (Criteria) this;
        }

        public Criteria andRemarkNotBetween(String value1, String value2) {
            addCriterion("remark not between", value1, value2, "remark");
            return (Criteria) this;
        }

        public Criteria andCreateuserIsNull() {
            addCriterion("createuser is null");
            return (Criteria) this;
        }

        public Criteria andCreateuserIsNotNull() {
            addCriterion("createuser is not null");
            return (Criteria) this;
        }

        public Criteria andCreateuserEqualTo(String value) {
            addCriterion("createuser =", value, "createuser");
            return (Criteria) this;
        }

        public Criteria andCreateuserNotEqualTo(String value) {
            addCriterion("createuser <>", value, "createuser");
            return (Criteria) this;
        }

        public Criteria andCreateuserGreaterThan(String value) {
            addCriterion("createuser >", value, "createuser");
            return (Criteria) this;
        }

        public Criteria andCreateuserGreaterThanOrEqualTo(String value) {
            addCriterion("createuser >=", value, "createuser");
            return (Criteria) this;
        }

        public Criteria andCreateuserLessThan(String value) {
            addCriterion("createuser <", value, "createuser");
            return (Criteria) this;
        }

        public Criteria andCreateuserLessThanOrEqualTo(String value) {
            addCriterion("createuser <=", value, "createuser");
            return (Criteria) this;
        }

        public Criteria andCreateuserLike(String value) {
            addCriterion("createuser like", value, "createuser");
            return (Criteria) this;
        }

        public Criteria andCreateuserNotLike(String value) {
            addCriterion("createuser not like", value, "createuser");
            return (Criteria) this;
        }

        public Criteria andCreateuserIn(List<String> values) {
            addCriterion("createuser in", values, "createuser");
            return (Criteria) this;
        }

        public Criteria andCreateuserNotIn(List<String> values) {
            addCriterion("createuser not in", values, "createuser");
            return (Criteria) this;
        }

        public Criteria andCreateuserBetween(String value1, String value2) {
            addCriterion("createuser between", value1, value2, "createuser");
            return (Criteria) this;
        }

        public Criteria andCreateuserNotBetween(String value1, String value2) {
            addCriterion("createuser not between", value1, value2, "createuser");
            return (Criteria) this;
        }

        public Criteria andCreatetimeIsNull() {
            addCriterion("createtime is null");
            return (Criteria) this;
        }

        public Criteria andCreatetimeIsNotNull() {
            addCriterion("createtime is not null");
            return (Criteria) this;
        }

        public Criteria andCreatetimeEqualTo(Date value) {
            addCriterion("createtime =", value, "createtime");
            return (Criteria) this;
        }

        public Criteria andCreatetimeNotEqualTo(Date value) {
            addCriterion("createtime <>", value, "createtime");
            return (Criteria) this;
        }

        public Criteria andCreatetimeGreaterThan(Date value) {
            addCriterion("createtime >", value, "createtime");
            return (Criteria) this;
        }

        public Criteria andCreatetimeGreaterThanOrEqualTo(Date value) {
            addCriterion("createtime >=", value, "createtime");
            return (Criteria) this;
        }

        public Criteria andCreatetimeLessThan(Date value) {
            addCriterion("createtime <", value, "createtime");
            return (Criteria) this;
        }

        public Criteria andCreatetimeLessThanOrEqualTo(Date value) {
            addCriterion("createtime <=", value, "createtime");
            return (Criteria) this;
        }

        public Criteria andCreatetimeIn(List<Date> values) {
            addCriterion("createtime in", values, "createtime");
            return (Criteria) this;
        }

        public Criteria andCreatetimeNotIn(List<Date> values) {
            addCriterion("createtime not in", values, "createtime");
            return (Criteria) this;
        }

        public Criteria andCreatetimeBetween(Date value1, Date value2) {
            addCriterion("createtime between", value1, value2, "createtime");
            return (Criteria) this;
        }

        public Criteria andCreatetimeNotBetween(Date value1, Date value2) {
            addCriterion("createtime not between", value1, value2, "createtime");
            return (Criteria) this;
        }

        public Criteria andUpdateuserIsNull() {
            addCriterion("updateuser is null");
            return (Criteria) this;
        }

        public Criteria andUpdateuserIsNotNull() {
            addCriterion("updateuser is not null");
            return (Criteria) this;
        }

        public Criteria andUpdateuserEqualTo(String value) {
            addCriterion("updateuser =", value, "updateuser");
            return (Criteria) this;
        }

        public Criteria andUpdateuserNotEqualTo(String value) {
            addCriterion("updateuser <>", value, "updateuser");
            return (Criteria) this;
        }

        public Criteria andUpdateuserGreaterThan(String value) {
            addCriterion("updateuser >", value, "updateuser");
            return (Criteria) this;
        }

        public Criteria andUpdateuserGreaterThanOrEqualTo(String value) {
            addCriterion("updateuser >=", value, "updateuser");
            return (Criteria) this;
        }

        public Criteria andUpdateuserLessThan(String value) {
            addCriterion("updateuser <", value, "updateuser");
            return (Criteria) this;
        }

        public Criteria andUpdateuserLessThanOrEqualTo(String value) {
            addCriterion("updateuser <=", value, "updateuser");
            return (Criteria) this;
        }

        public Criteria andUpdateuserLike(String value) {
            addCriterion("updateuser like", value, "updateuser");
            return (Criteria) this;
        }

        public Criteria andUpdateuserNotLike(String value) {
            addCriterion("updateuser not like", value, "updateuser");
            return (Criteria) this;
        }

        public Criteria andUpdateuserIn(List<String> values) {
            addCriterion("updateuser in", values, "updateuser");
            return (Criteria) this;
        }

        public Criteria andUpdateuserNotIn(List<String> values) {
            addCriterion("updateuser not in", values, "updateuser");
            return (Criteria) this;
        }

        public Criteria andUpdateuserBetween(String value1, String value2) {
            addCriterion("updateuser between", value1, value2, "updateuser");
            return (Criteria) this;
        }

        public Criteria andUpdateuserNotBetween(String value1, String value2) {
            addCriterion("updateuser not between", value1, value2, "updateuser");
            return (Criteria) this;
        }

        public Criteria andUpdatetimeIsNull() {
            addCriterion("updatetime is null");
            return (Criteria) this;
        }

        public Criteria andUpdatetimeIsNotNull() {
            addCriterion("updatetime is not null");
            return (Criteria) this;
        }

        public Criteria andUpdatetimeEqualTo(Date value) {
            addCriterion("updatetime =", value, "updatetime");
            return (Criteria) this;
        }

        public Criteria andUpdatetimeNotEqualTo(Date value) {
            addCriterion("updatetime <>", value, "updatetime");
            return (Criteria) this;
        }

        public Criteria andUpdatetimeGreaterThan(Date value) {
            addCriterion("updatetime >", value, "updatetime");
            return (Criteria) this;
        }

        public Criteria andUpdatetimeGreaterThanOrEqualTo(Date value) {
            addCriterion("updatetime >=", value, "updatetime");
            return (Criteria) this;
        }

        public Criteria andUpdatetimeLessThan(Date value) {
            addCriterion("updatetime <", value, "updatetime");
            return (Criteria) this;
        }

        public Criteria andUpdatetimeLessThanOrEqualTo(Date value) {
            addCriterion("updatetime <=", value, "updatetime");
            return (Criteria) this;
        }

        public Criteria andUpdatetimeIn(List<Date> values) {
            addCriterion("updatetime in", values, "updatetime");
            return (Criteria) this;
        }

        public Criteria andUpdatetimeNotIn(List<Date> values) {
            addCriterion("updatetime not in", values, "updatetime");
            return (Criteria) this;
        }

        public Criteria andUpdatetimeBetween(Date value1, Date value2) {
            addCriterion("updatetime between", value1, value2, "updatetime");
            return (Criteria) this;
        }

        public Criteria andUpdatetimeNotBetween(Date value1, Date value2) {
            addCriterion("updatetime not between", value1, value2, "updatetime");
            return (Criteria) this;
        }

        public Criteria andDrIsNull() {
            addCriterion("dr is null");
            return (Criteria) this;
        }

        public Criteria andDrIsNotNull() {
            addCriterion("dr is not null");
            return (Criteria) this;
        }

        public Criteria andDrEqualTo(Integer value) {
            addCriterion("dr =", value, "dr");
            return (Criteria) this;
        }

        public Criteria andDrNotEqualTo(Integer value) {
            addCriterion("dr <>", value, "dr");
            return (Criteria) this;
        }

        public Criteria andDrGreaterThan(Integer value) {
            addCriterion("dr >", value, "dr");
            return (Criteria) this;
        }

        public Criteria andDrGreaterThanOrEqualTo(Integer value) {
            addCriterion("dr >=", value, "dr");
            return (Criteria) this;
        }

        public Criteria andDrLessThan(Integer value) {
            addCriterion("dr <", value, "dr");
            return (Criteria) this;
        }

        public Criteria andDrLessThanOrEqualTo(Integer value) {
            addCriterion("dr <=", value, "dr");
            return (Criteria) this;
        }

        public Criteria andDrIn(List<Integer> values) {
            addCriterion("dr in", values, "dr");
            return (Criteria) this;
        }

        public Criteria andDrNotIn(List<Integer> values) {
            addCriterion("dr not in", values, "dr");
            return (Criteria) this;
        }

        public Criteria andDrBetween(Integer value1, Integer value2) {
            addCriterion("dr between", value1, value2, "dr");
            return (Criteria) this;
        }

        public Criteria andDrNotBetween(Integer value1, Integer value2) {
            addCriterion("dr not between", value1, value2, "dr");
            return (Criteria) this;
        }
    }

    public static class Criteria extends GeneratedCriteria {

        protected Criteria() {
            super();
        }
    }

    public static class Criterion {
        private String condition;

        private Object value;

        private Object secondValue;

        private boolean noValue;

        private boolean singleValue;

        private boolean betweenValue;

        private boolean listValue;

        private String typeHandler;

        public String getCondition() {
            return condition;
        }

        public Object getValue() {
            return value;
        }

        public Object getSecondValue() {
            return secondValue;
        }

        public boolean isNoValue() {
            return noValue;
        }

        public boolean isSingleValue() {
            return singleValue;
        }

        public boolean isBetweenValue() {
            return betweenValue;
        }

        public boolean isListValue() {
            return listValue;
        }

        public String getTypeHandler() {
            return typeHandler;
        }

        protected Criterion(String condition) {
            super();
            this.condition = condition;
            this.typeHandler = null;
            this.noValue = true;
        }

        protected Criterion(String condition, Object value, String typeHandler) {
            super();
            this.condition = condition;
            this.value = value;
            this.typeHandler = typeHandler;
            if (value instanceof List<?>) {
                this.listValue = true;
            } else {
                this.singleValue = true;
            }
        }

        protected Criterion(String condition, Object value) {
            this(condition, value, null);
        }

        protected Criterion(String condition, Object value, Object secondValue, String typeHandler) {
            super();
            this.condition = condition;
            this.value = value;
            this.secondValue = secondValue;
            this.typeHandler = typeHandler;
            this.betweenValue = true;
        }

        protected Criterion(String condition, Object value, Object secondValue) {
            this(condition, value, secondValue, null);
        }
    }
}
