package com.mrk.finance.model;

import com.mrk.common.base.BaseEntity;
import io.swagger.annotations.ApiModelProperty;
import lombok.Getter;
import lombok.Setter;

import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import java.io.Serializable;

@Setter
@Getter
public class FncRentalFees extends BaseEntity implements Serializable {
    private static final long serialVersionUID = 1L;


    /**
     * 主键
     */
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @ApiModelProperty(value = "主键")
    private Long frfId;

    /**
     * 租金包含费用明细
     */
    @ApiModelProperty(value = "租金包含费用明细")
    private String frfName;

    /**
     * 租金包含费用标识
     */
    @ApiModelProperty(value = "租金包含费用标识")
    private String frfMark;

    /**
     * 是否可填写
     */
    @ApiModelProperty(value = "是否可填写")
    private Integer frfWrite;
}
