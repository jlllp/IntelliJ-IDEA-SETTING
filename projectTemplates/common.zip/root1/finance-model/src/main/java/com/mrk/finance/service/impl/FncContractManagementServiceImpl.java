package com.mrk.finance.service.impl;

import com.github.pagehelper.PageInfo;
import com.mrk.common.constant.BaseConstants;
import com.mrk.common.utils.bean.BeanUtils;
import com.mrk.common.utils.jwt.JWTUtil;
import com.mrk.common.utils.page.PageUtils;
import com.mrk.common.utils.text.StringUtils;
import com.mrk.finance.client.dto.ContractAnalysisDto;
import com.mrk.finance.dao.FncContractManagementMapper;
import com.mrk.finance.dto.ManagementRiskDto;
import com.mrk.finance.example.FncContractManagementExample;
import com.mrk.finance.model.FncContractManagement;
import com.mrk.finance.query.FncContractManagementQuery;
import com.mrk.finance.queryvo.FncContractManagementQueryVo;
import com.mrk.finance.service.FncContractManagementService;
import com.mrk.universal.enums.contract.ContractPartyTypeEnum;
import com.mrk.universal.enums.contract.ContractStateEnum;
import com.mrk.universal.enums.contract.ContractTypeEnum;
import com.mrk.universal.enums.turner.TurnerSingleOverTimeEnum;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import javax.annotation.Resource;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.List;


/**
 * @Description: FncContractManagementServiceImpl
 */
@Service
@Slf4j
public class FncContractManagementServiceImpl implements FncContractManagementService {
    @Resource
    private FncContractManagementMapper fncContractManagementMapper;

    @Override
    public PageInfo<FncContractManagement> page(FncContractManagementQueryVo queryVo) {
        PageUtils.startPage();
        List<FncContractManagement> list = this.list(queryVo);
        return new PageInfo<>(list);
    }

    @Override
    public PageInfo<FncContractManagement> pageWithTableJoin(FncContractManagementQueryVo queryVo) {
        PageUtils.startPage();
        List<FncContractManagement> list = fncContractManagementMapper.selectWithTableJoin(queryVo);
        return new PageInfo<>(list);
    }

    @Override
    public List<FncContractManagement> list(FncContractManagementQueryVo queryVo) {
        FncContractManagementQuery query = new FncContractManagementQuery();
        BeanUtils.copyBeanProp(queryVo, query);
        query.setSidx(StringUtils.camelToUnderlineAndFilterText(query.getSidx()));
        return fncContractManagementMapper.selectByExample(query.getCrieria());
    }

    @Override
    @Transactional(rollbackFor = Exception.class)
    public int add(FncContractManagement entity) {
        entity.setCreatetime(new Date());
        entity.setCreateuser(JWTUtil.getNikeName());
        entity.setDr(BaseConstants.DR_NO);
        return fncContractManagementMapper.insert(entity);
    }

    @Override
    @Transactional(rollbackFor = Exception.class)
    public int update(FncContractManagement entity) {
        entity.setUpdatetime(new Date());
        entity.setUpdateuser(JWTUtil.getNikeName());
        return fncContractManagementMapper.updateByPrimaryKey(entity);
    }

    @Override
    @Transactional(rollbackFor = Exception.class)
    public int updateSelective(FncContractManagement entity) {
        entity.setUpdatetime(new Date());
        entity.setUpdateuser(JWTUtil.getNikeName());
        return fncContractManagementMapper.updateByPrimaryKeySelective(entity);
    }

    @Override
    @Transactional(rollbackFor = Exception.class)
    public int delete(Long id) {
        return fncContractManagementMapper.deleteByPrimaryKey(id);
    }

    @Override
    public FncContractManagement getById(Long id) {
        return fncContractManagementMapper.selectByPrimaryKey(id);
    }

    @Override
    public List<FncContractManagement> getByIds(List<Long> ids) {
        if (ids == null || ids.isEmpty()) {
            return new ArrayList<>();
        }
        FncContractManagementExample example = new FncContractManagementExample();
        example.createCriteria()
                .andFcmIdIn(ids)
                .andDrEqualTo(BaseConstants.DR_NO);
        return fncContractManagementMapper.selectByExample(example);
    }

    @Override
    public List<FncContractManagement> getByCode(String code) {
        FncContractManagementQueryVo queryVo = new FncContractManagementQueryVo();
        queryVo.setFcmContractNoEqualTo(code);
        queryVo.setDrEqualTo(BaseConstants.DR_NO);
        return this.list(queryVo);
    }

    /**
     * @author Bob
     * @date 2021/11/12
     * @description 获取指定状态下租赁和小于等于指定租赁起始日期的合同
     * @param state 指定状态
     * @param nowDate 指定时间
     * @return 今天开始租赁的合同
     */
    @Override
    public List<FncContractManagement> getStateAndStartDate(Integer state, Date nowDate) {
        FncContractManagementExample example = new FncContractManagementExample();
        example.createCriteria()
                .andFcmContractStateEqualTo(state)
                .andFcmLeaseStartDateLessThanOrEqualTo(nowDate);
        return fncContractManagementMapper.selectByExample(example);
    }

    /**
     * @param state          状态
     * @param contractIdList 待更新状态的合同
     * @return 影响的行数
     * @author Bob
     * @date 2021/11/12
     * @description 根据主键批量更新状态
     */
    @Override
    public int updateStateByIdList(Integer state, List<Long> contractIdList) {
        FncContractManagement entity = new FncContractManagement();
        entity.setFcmContractState(state);
        FncContractManagementExample example = new FncContractManagementExample();
        example.createCriteria()
                .andFcmIdIn(contractIdList)
                .andDrEqualTo(BaseConstants.DR_NO);
        return fncContractManagementMapper.updateByExampleSelective(entity, example);
    }

    /**
     * @param state   指定状态
     * @param nowDate 指定时间
     * @return 今天结束租赁的合同
     * @author Bob
     * @date 2021/11/12
     * @description 获取指定状态下租赁和小于等于指定租赁结束日期的合同
     */
    @Override
    public List<FncContractManagement> getStateAndEndDate(Integer state, Date nowDate) {
        FncContractManagementExample example = new FncContractManagementExample();
        example.createCriteria()
                .andDrEqualTo(BaseConstants.DR_NO)
                .andFcmContractStateEqualTo(state)
                .andFcmLeaseEndDateLessThanOrEqualTo(nowDate);
        return fncContractManagementMapper.selectByExample(example);
    }

    /**
     * @param stateIn         状态集合
     * @param settlementState 结算状态
     * @param endDate 合同结束时间
     * @return 符合条件的合同
     * @author Bob
     * @date 2021/11/12
     * @description 获取指定合同状态和指定计算状态下的合同
     */
    @Override
    public List<FncContractManagement> getStateInAndSettlementAndEndLTOE(List<Integer> stateIn, Integer settlementState, Date endDate) {
        FncContractManagementExample example = new FncContractManagementExample();
        example.createCriteria()
                .andDrEqualTo(BaseConstants.DR_NO)
                .andFcmContractStateIn(stateIn)
                .andFcmLeaseEndDateLessThanOrEqualTo(endDate)
                .andFcmSettlementStateEqualTo(settlementState);
        return fncContractManagementMapper.selectByExample(example);
    }

    /**
     * @param state 合同状态
     * @param type 合同类型
     * @return 符合条件的合同
     * @author Bob
     * @date 2021/11/15
     * @description 获取合同状态和合同类型下的所有合同
     */
    @Override
    public List<FncContractManagement> getByStateAndType(Integer state, Integer type) {
        FncContractManagementExample example = new FncContractManagementExample();
        example.createCriteria()
                .andDrEqualTo(BaseConstants.DR_NO)
                .andFcmContractTypeEqualTo(type)
                .andFcmContractStateEqualTo(state);
        return fncContractManagementMapper.selectByExample(example);
    }

    /**
     * @param state       合同状态
     * @param type        合同类型
     * @param contractIds 除掉指定的合同
     * @return 符合条件的合同
     * @author Bob
     * @date 2021/11/15
     * @description 获取合同状态下的所有合同 并 排除掉指定的合同
     */
    @Override
    public List<FncContractManagement> getByStateAndTypeAndIdNotIn(Integer state, Integer type, List<Long> contractIds) {
        FncContractManagementExample example = new FncContractManagementExample();
        example.createCriteria()
                .andDrEqualTo(BaseConstants.DR_NO)
                .andFcmIdNotIn(contractIds)
                .andFcmContractTypeEqualTo(type)
                .andFcmContractStateEqualTo(state);
        return fncContractManagementMapper.selectByExample(example);
    }

    @Override
    public List<FncContractManagement> getByStateAndEndDateLTOE(Integer state, Date endDay) {
        FncContractManagementExample example = new FncContractManagementExample();
        example.createCriteria()
                .andDrEqualTo(BaseConstants.DR_NO)
                .andFcmContractStateEqualTo(state)
                .andFcmLeaseEndDateLessThanOrEqualTo(endDay);
        return fncContractManagementMapper.selectByExample(example);
    }

    /**
     * @param state       合同状态
     * @param endDay   结束时间
     * @param contractIds 排除的合同id
     * @return 符合条件的合同
     * @author Bob
     * @date 2021/11/17
     * @description 获取指定状态和结束时间小于等于的合同
     */
    @Override
    public List<FncContractManagement> getByStateAndEndDateLTOEAndIdNotIn(Integer state, Date endDay, List<Long> contractIds) {
        FncContractManagementExample example = new FncContractManagementExample();
        example.createCriteria()
                .andDrEqualTo(BaseConstants.DR_NO)
                .andFcmContractStateEqualTo(state)
                .andFcmLeaseEndDateLessThanOrEqualTo(endDay)
                .andFcmIdNotIn(contractIds);
        return fncContractManagementMapper.selectByExample(example);
    }

    /**
     * @param state 合同状态
     * @return 符合条件的合同
     * @author Bob
     * @date 2021/11/22
     * @description 获取指定状态下的合同
     */
    @Override
    public List<FncContractManagement> getByState(Integer state) {
        FncContractManagementExample example = new FncContractManagementExample();
        example.createCriteria()
                .andDrEqualTo(BaseConstants.DR_NO)
                .andFcmContractStateEqualTo(state);
        return fncContractManagementMapper.selectByExample(example);
    }

    /**
     * @param state  合同状态
     * @param endDay 结束日期
     * @return 符合条件的合同
     * @author Bob
     * @date 2021/11/22
     * @description 获取指定状态和结束时间大于等于的合同
     */
    @Override
    public List<FncContractManagement> getByStateAndEndDateGTOE(Integer state, Date endDay) {
        FncContractManagementExample example = new FncContractManagementExample();
        example.createCriteria()
                .andDrEqualTo(BaseConstants.DR_NO)
                .andFcmContractStateEqualTo(state)
                .andFcmLeaseEndDateGreaterThanOrEqualTo(endDay);
        return fncContractManagementMapper.selectByExample(example);
    }

    /**
     * @param id 甲方id
     * @return 符合条件的合同
     * @author Bob
     * @date 2021/11/24
     * @description 根据甲方id获取合同
     */
    @Override
    public List<FncContractManagement> getByPartyA(Long id) {
        FncContractManagementExample example = new FncContractManagementExample();
        example.createCriteria()
                .andDrEqualTo(BaseConstants.DR_NO)
                .andFcmPartyaIdEqualTo(id);
        return fncContractManagementMapper.selectByExample(example);
    }

    @Override
    @Transactional(rollbackFor = Exception.class)
    public void updateStateByStateAndIds(Integer state, List<Long> contractIds) {
        FncContractManagement entity = new FncContractManagement();
        entity.setFcmContractState(state);
        FncContractManagementExample example = new FncContractManagementExample();
        example.createCriteria()
                .andFcmContractStateNotEqualTo(state)
                .andFcmIdIn(contractIds);
        fncContractManagementMapper.updateByExampleSelective(entity, example);
    }

    @Override
    public List<FncContractManagement> selectContractByContractIdList(List<Long> contractIdList) {
        FncContractManagementExample example = new FncContractManagementExample();
        example.createCriteria()
            .andDrEqualTo(BaseConstants.DR_NO)
            .andFcmContractStateEqualTo(ContractStateEnum.LEASED.getState())
            .andFcmIdIn(contractIdList);
        return fncContractManagementMapper.selectByExample(example);
    }

    @Override
    public List<FncContractManagement> selectRentTimeAndTurnerNo(Integer day) {
        return fncContractManagementMapper.selectRentTimeAndTurnerNo(TurnerSingleOverTimeEnum.NO.getState(),day);
    }

    @Override
    public List<FncContractManagement> getAll() {
        FncContractManagementExample example = new FncContractManagementExample();
        example.createCriteria()
            .andDrEqualTo(BaseConstants.DR_NO)
            .andFcmPartybTypeEqualTo(ContractPartyTypeEnum.PERSONAL.getValue())
            .andFcmContractStateEqualTo(ContractStateEnum.LEASED.getState());
        return fncContractManagementMapper.selectByExample(example);
    }

    @Override
    public List<FncContractManagement> getAllByType() {
        FncContractManagementExample example = new FncContractManagementExample();
        example.createCriteria()
            .andDrEqualTo(BaseConstants.DR_NO)
            .andFcmPartybTypeEqualTo(ContractPartyTypeEnum.PERSONAL.getValue())
            .andFcmContractStateEqualTo(ContractStateEnum.LEASED.getState())
            .andFcmContractTypeIn(Arrays.asList(ContractTypeEnum.NEW_LEASE.getType(),ContractTypeEnum.LEASE_RENEWAL.getType()));
        return fncContractManagementMapper.selectByExample(example);
    }

    /**
     * 根据逾期天数获取账单
     */
    @Override
    public List<ManagementRiskDto> getOverdue(Integer day) {
        return fncContractManagementMapper.getOverdue(day);
    }

    @Override
    public List<ContractAnalysisDto> selectAllStartedContractWithRentAmount() {
        return fncContractManagementMapper.selectAllStartedContractWithRentAmount();
    }

    @Override
    public List<ContractAnalysisDto> selectAllContractWithRentAmountTest(int start, int size) {
        return fncContractManagementMapper.selectAllStartedContractWithRentAmountTest(start, size);
    }

    @Override
    public PageInfo<FncContractManagement> getPage(FncContractManagementQueryVo queryVo) {
        PageUtils.startPage();
        List<FncContractManagement> list = fncContractManagementMapper.getPage(queryVo);
        return new PageInfo<>(list);
    }


    @Override
    public List<FncContractManagement> leasePage(FncContractManagementQueryVo queryVo) {
        return fncContractManagementMapper.leasePage(queryVo);
    }
}
