package com.mrk.finance.example;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

public class FncTempExample {
    protected String orderByClause;

    protected boolean distinct;

    protected List<Criteria> oredCriteria;

    public FncTempExample() {
        oredCriteria = new ArrayList<Criteria>();
    }

    public void setOrderByClause(String orderByClause) {
        this.orderByClause = orderByClause;
    }

    public String getOrderByClause() {
        return orderByClause;
    }

    public void setDistinct(boolean distinct) {
        this.distinct = distinct;
    }

    public boolean isDistinct() {
        return distinct;
    }

    public List<Criteria> getOredCriteria() {
        return oredCriteria;
    }

    public void or(Criteria criteria) {
        oredCriteria.add(criteria);
    }

    public Criteria or() {
        Criteria criteria = createCriteriaInternal();
        oredCriteria.add(criteria);
        return criteria;
    }

    public Criteria createCriteria() {
        Criteria criteria = createCriteriaInternal();
        if (oredCriteria.size() == 0) {
            oredCriteria.add(criteria);
        }
        return criteria;
    }

    protected Criteria createCriteriaInternal() {
        Criteria criteria = new Criteria();
        return criteria;
    }

    public void clear() {
        oredCriteria.clear();
        orderByClause = null;
        distinct = false;
    }

    protected abstract static class GeneratedCriteria {
        protected List<Criterion> criteria;

        protected GeneratedCriteria() {
            super();
            criteria = new ArrayList<Criterion>();
        }

        public boolean isValid() {
            return criteria.size() > 0;
        }

        public List<Criterion> getAllCriteria() {
            return criteria;
        }

        public List<Criterion> getCriteria() {
            return criteria;
        }

        protected void addCriterion(String condition) {
            if (condition == null) {
                throw new RuntimeException("Value for condition cannot be null");
            }
            criteria.add(new Criterion(condition));
        }

        protected void addCriterion(String condition, Object value, String property) {
            if (value == null) {
                throw new RuntimeException("Value for " + property + " cannot be null");
            }
            criteria.add(new Criterion(condition, value));
        }

        protected void addCriterion(String condition, Object value1, Object value2, String property) {
            if (value1 == null || value2 == null) {
                throw new RuntimeException("Between values for " + property + " cannot be null");
            }
            criteria.add(new Criterion(condition, value1, value2));
        }

        public Criteria andFncIdIsNull() {
            addCriterion("fnc_id is null");
            return (Criteria) this;
        }

        public Criteria andFncIdIsNotNull() {
            addCriterion("fnc_id is not null");
            return (Criteria) this;
        }

        public Criteria andFncIdEqualTo(Long value) {
            addCriterion("fnc_id =", value, "fncId");
            return (Criteria) this;
        }

        public Criteria andFncIdNotEqualTo(Long value) {
            addCriterion("fnc_id <>", value, "fncId");
            return (Criteria) this;
        }

        public Criteria andFncIdGreaterThan(Long value) {
            addCriterion("fnc_id >", value, "fncId");
            return (Criteria) this;
        }

        public Criteria andFncIdGreaterThanOrEqualTo(Long value) {
            addCriterion("fnc_id >=", value, "fncId");
            return (Criteria) this;
        }

        public Criteria andFncIdLessThan(Long value) {
            addCriterion("fnc_id <", value, "fncId");
            return (Criteria) this;
        }

        public Criteria andFncIdLessThanOrEqualTo(Long value) {
            addCriterion("fnc_id <=", value, "fncId");
            return (Criteria) this;
        }

        public Criteria andFncIdIn(List<Long> values) {
            addCriterion("fnc_id in", values, "fncId");
            return (Criteria) this;
        }

        public Criteria andFncIdNotIn(List<Long> values) {
            addCriterion("fnc_id not in", values, "fncId");
            return (Criteria) this;
        }

        public Criteria andFncIdBetween(Long value1, Long value2) {
            addCriterion("fnc_id between", value1, value2, "fncId");
            return (Criteria) this;
        }

        public Criteria andFncIdNotBetween(Long value1, Long value2) {
            addCriterion("fnc_id not between", value1, value2, "fncId");
            return (Criteria) this;
        }

        public Criteria andFncCityIsNull() {
            addCriterion("fnc_city is null");
            return (Criteria) this;
        }

        public Criteria andFncCityIsNotNull() {
            addCriterion("fnc_city is not null");
            return (Criteria) this;
        }

        public Criteria andFncCityEqualTo(String value) {
            addCriterion("fnc_city =", value, "fncCity");
            return (Criteria) this;
        }

        public Criteria andFncCityNotEqualTo(String value) {
            addCriterion("fnc_city <>", value, "fncCity");
            return (Criteria) this;
        }

        public Criteria andFncCityGreaterThan(String value) {
            addCriterion("fnc_city >", value, "fncCity");
            return (Criteria) this;
        }

        public Criteria andFncCityGreaterThanOrEqualTo(String value) {
            addCriterion("fnc_city >=", value, "fncCity");
            return (Criteria) this;
        }

        public Criteria andFncCityLessThan(String value) {
            addCriterion("fnc_city <", value, "fncCity");
            return (Criteria) this;
        }

        public Criteria andFncCityLessThanOrEqualTo(String value) {
            addCriterion("fnc_city <=", value, "fncCity");
            return (Criteria) this;
        }

        public Criteria andFncCityLike(String value) {
            addCriterion("fnc_city like", value, "fncCity");
            return (Criteria) this;
        }

        public Criteria andFncCityNotLike(String value) {
            addCriterion("fnc_city not like", value, "fncCity");
            return (Criteria) this;
        }

        public Criteria andFncCityIn(List<String> values) {
            addCriterion("fnc_city in", values, "fncCity");
            return (Criteria) this;
        }

        public Criteria andFncCityNotIn(List<String> values) {
            addCriterion("fnc_city not in", values, "fncCity");
            return (Criteria) this;
        }

        public Criteria andFncCityBetween(String value1, String value2) {
            addCriterion("fnc_city between", value1, value2, "fncCity");
            return (Criteria) this;
        }

        public Criteria andFncCityNotBetween(String value1, String value2) {
            addCriterion("fnc_city not between", value1, value2, "fncCity");
            return (Criteria) this;
        }

        public Criteria andFncMemberIdIsNull() {
            addCriterion("fnc_member_id is null");
            return (Criteria) this;
        }

        public Criteria andFncMemberIdIsNotNull() {
            addCriterion("fnc_member_id is not null");
            return (Criteria) this;
        }

        public Criteria andFncMemberIdEqualTo(Long value) {
            addCriterion("fnc_member_id =", value, "fncMemberId");
            return (Criteria) this;
        }

        public Criteria andFncMemberIdNotEqualTo(Long value) {
            addCriterion("fnc_member_id <>", value, "fncMemberId");
            return (Criteria) this;
        }

        public Criteria andFncMemberIdGreaterThan(Long value) {
            addCriterion("fnc_member_id >", value, "fncMemberId");
            return (Criteria) this;
        }

        public Criteria andFncMemberIdGreaterThanOrEqualTo(Long value) {
            addCriterion("fnc_member_id >=", value, "fncMemberId");
            return (Criteria) this;
        }

        public Criteria andFncMemberIdLessThan(Long value) {
            addCriterion("fnc_member_id <", value, "fncMemberId");
            return (Criteria) this;
        }

        public Criteria andFncMemberIdLessThanOrEqualTo(Long value) {
            addCriterion("fnc_member_id <=", value, "fncMemberId");
            return (Criteria) this;
        }

        public Criteria andFncMemberIdIn(List<Long> values) {
            addCriterion("fnc_member_id in", values, "fncMemberId");
            return (Criteria) this;
        }

        public Criteria andFncMemberIdNotIn(List<Long> values) {
            addCriterion("fnc_member_id not in", values, "fncMemberId");
            return (Criteria) this;
        }

        public Criteria andFncMemberIdBetween(Long value1, Long value2) {
            addCriterion("fnc_member_id between", value1, value2, "fncMemberId");
            return (Criteria) this;
        }

        public Criteria andFncMemberIdNotBetween(Long value1, Long value2) {
            addCriterion("fnc_member_id not between", value1, value2, "fncMemberId");
            return (Criteria) this;
        }

        public Criteria andFncNameIsNull() {
            addCriterion("fnc_name is null");
            return (Criteria) this;
        }

        public Criteria andFncNameIsNotNull() {
            addCriterion("fnc_name is not null");
            return (Criteria) this;
        }

        public Criteria andFncNameEqualTo(String value) {
            addCriterion("fnc_name =", value, "fncName");
            return (Criteria) this;
        }

        public Criteria andFncNameNotEqualTo(String value) {
            addCriterion("fnc_name <>", value, "fncName");
            return (Criteria) this;
        }

        public Criteria andFncNameGreaterThan(String value) {
            addCriterion("fnc_name >", value, "fncName");
            return (Criteria) this;
        }

        public Criteria andFncNameGreaterThanOrEqualTo(String value) {
            addCriterion("fnc_name >=", value, "fncName");
            return (Criteria) this;
        }

        public Criteria andFncNameLessThan(String value) {
            addCriterion("fnc_name <", value, "fncName");
            return (Criteria) this;
        }

        public Criteria andFncNameLessThanOrEqualTo(String value) {
            addCriterion("fnc_name <=", value, "fncName");
            return (Criteria) this;
        }

        public Criteria andFncNameLike(String value) {
            addCriterion("fnc_name like", value, "fncName");
            return (Criteria) this;
        }

        public Criteria andFncNameNotLike(String value) {
            addCriterion("fnc_name not like", value, "fncName");
            return (Criteria) this;
        }

        public Criteria andFncNameIn(List<String> values) {
            addCriterion("fnc_name in", values, "fncName");
            return (Criteria) this;
        }

        public Criteria andFncNameNotIn(List<String> values) {
            addCriterion("fnc_name not in", values, "fncName");
            return (Criteria) this;
        }

        public Criteria andFncNameBetween(String value1, String value2) {
            addCriterion("fnc_name between", value1, value2, "fncName");
            return (Criteria) this;
        }

        public Criteria andFncNameNotBetween(String value1, String value2) {
            addCriterion("fnc_name not between", value1, value2, "fncName");
            return (Criteria) this;
        }

        public Criteria andFncIdnumberIsNull() {
            addCriterion("fnc_idnumber is null");
            return (Criteria) this;
        }

        public Criteria andFncIdnumberIsNotNull() {
            addCriterion("fnc_idnumber is not null");
            return (Criteria) this;
        }

        public Criteria andFncIdnumberEqualTo(String value) {
            addCriterion("fnc_idnumber =", value, "fncIdnumber");
            return (Criteria) this;
        }

        public Criteria andFncIdnumberNotEqualTo(String value) {
            addCriterion("fnc_idnumber <>", value, "fncIdnumber");
            return (Criteria) this;
        }

        public Criteria andFncIdnumberGreaterThan(String value) {
            addCriterion("fnc_idnumber >", value, "fncIdnumber");
            return (Criteria) this;
        }

        public Criteria andFncIdnumberGreaterThanOrEqualTo(String value) {
            addCriterion("fnc_idnumber >=", value, "fncIdnumber");
            return (Criteria) this;
        }

        public Criteria andFncIdnumberLessThan(String value) {
            addCriterion("fnc_idnumber <", value, "fncIdnumber");
            return (Criteria) this;
        }

        public Criteria andFncIdnumberLessThanOrEqualTo(String value) {
            addCriterion("fnc_idnumber <=", value, "fncIdnumber");
            return (Criteria) this;
        }

        public Criteria andFncIdnumberLike(String value) {
            addCriterion("fnc_idnumber like", value, "fncIdnumber");
            return (Criteria) this;
        }

        public Criteria andFncIdnumberNotLike(String value) {
            addCriterion("fnc_idnumber not like", value, "fncIdnumber");
            return (Criteria) this;
        }

        public Criteria andFncIdnumberIn(List<String> values) {
            addCriterion("fnc_idnumber in", values, "fncIdnumber");
            return (Criteria) this;
        }

        public Criteria andFncIdnumberNotIn(List<String> values) {
            addCriterion("fnc_idnumber not in", values, "fncIdnumber");
            return (Criteria) this;
        }

        public Criteria andFncIdnumberBetween(String value1, String value2) {
            addCriterion("fnc_idnumber between", value1, value2, "fncIdnumber");
            return (Criteria) this;
        }

        public Criteria andFncIdnumberNotBetween(String value1, String value2) {
            addCriterion("fnc_idnumber not between", value1, value2, "fncIdnumber");
            return (Criteria) this;
        }

        public Criteria andFncCarVinIsNull() {
            addCriterion("fnc_car_vin is null");
            return (Criteria) this;
        }

        public Criteria andFncCarVinIsNotNull() {
            addCriterion("fnc_car_vin is not null");
            return (Criteria) this;
        }

        public Criteria andFncCarVinEqualTo(String value) {
            addCriterion("fnc_car_vin =", value, "fncCarVin");
            return (Criteria) this;
        }

        public Criteria andFncCarVinNotEqualTo(String value) {
            addCriterion("fnc_car_vin <>", value, "fncCarVin");
            return (Criteria) this;
        }

        public Criteria andFncCarVinGreaterThan(String value) {
            addCriterion("fnc_car_vin >", value, "fncCarVin");
            return (Criteria) this;
        }

        public Criteria andFncCarVinGreaterThanOrEqualTo(String value) {
            addCriterion("fnc_car_vin >=", value, "fncCarVin");
            return (Criteria) this;
        }

        public Criteria andFncCarVinLessThan(String value) {
            addCriterion("fnc_car_vin <", value, "fncCarVin");
            return (Criteria) this;
        }

        public Criteria andFncCarVinLessThanOrEqualTo(String value) {
            addCriterion("fnc_car_vin <=", value, "fncCarVin");
            return (Criteria) this;
        }

        public Criteria andFncCarVinLike(String value) {
            addCriterion("fnc_car_vin like", value, "fncCarVin");
            return (Criteria) this;
        }

        public Criteria andFncCarVinNotLike(String value) {
            addCriterion("fnc_car_vin not like", value, "fncCarVin");
            return (Criteria) this;
        }

        public Criteria andFncCarVinIn(List<String> values) {
            addCriterion("fnc_car_vin in", values, "fncCarVin");
            return (Criteria) this;
        }

        public Criteria andFncCarVinNotIn(List<String> values) {
            addCriterion("fnc_car_vin not in", values, "fncCarVin");
            return (Criteria) this;
        }

        public Criteria andFncCarVinBetween(String value1, String value2) {
            addCriterion("fnc_car_vin between", value1, value2, "fncCarVin");
            return (Criteria) this;
        }

        public Criteria andFncCarVinNotBetween(String value1, String value2) {
            addCriterion("fnc_car_vin not between", value1, value2, "fncCarVin");
            return (Criteria) this;
        }

        public Criteria andFncAgreementNumberIsNull() {
            addCriterion("fnc_agreement_number is null");
            return (Criteria) this;
        }

        public Criteria andFncAgreementNumberIsNotNull() {
            addCriterion("fnc_agreement_number is not null");
            return (Criteria) this;
        }

        public Criteria andFncAgreementNumberEqualTo(String value) {
            addCriterion("fnc_agreement_number =", value, "fncAgreementNumber");
            return (Criteria) this;
        }

        public Criteria andFncAgreementNumberNotEqualTo(String value) {
            addCriterion("fnc_agreement_number <>", value, "fncAgreementNumber");
            return (Criteria) this;
        }

        public Criteria andFncAgreementNumberGreaterThan(String value) {
            addCriterion("fnc_agreement_number >", value, "fncAgreementNumber");
            return (Criteria) this;
        }

        public Criteria andFncAgreementNumberGreaterThanOrEqualTo(String value) {
            addCriterion("fnc_agreement_number >=", value, "fncAgreementNumber");
            return (Criteria) this;
        }

        public Criteria andFncAgreementNumberLessThan(String value) {
            addCriterion("fnc_agreement_number <", value, "fncAgreementNumber");
            return (Criteria) this;
        }

        public Criteria andFncAgreementNumberLessThanOrEqualTo(String value) {
            addCriterion("fnc_agreement_number <=", value, "fncAgreementNumber");
            return (Criteria) this;
        }

        public Criteria andFncAgreementNumberLike(String value) {
            addCriterion("fnc_agreement_number like", value, "fncAgreementNumber");
            return (Criteria) this;
        }

        public Criteria andFncAgreementNumberNotLike(String value) {
            addCriterion("fnc_agreement_number not like", value, "fncAgreementNumber");
            return (Criteria) this;
        }

        public Criteria andFncAgreementNumberIn(List<String> values) {
            addCriterion("fnc_agreement_number in", values, "fncAgreementNumber");
            return (Criteria) this;
        }

        public Criteria andFncAgreementNumberNotIn(List<String> values) {
            addCriterion("fnc_agreement_number not in", values, "fncAgreementNumber");
            return (Criteria) this;
        }

        public Criteria andFncAgreementNumberBetween(String value1, String value2) {
            addCriterion("fnc_agreement_number between", value1, value2, "fncAgreementNumber");
            return (Criteria) this;
        }

        public Criteria andFncAgreementNumberNotBetween(String value1, String value2) {
            addCriterion("fnc_agreement_number not between", value1, value2, "fncAgreementNumber");
            return (Criteria) this;
        }

        public Criteria andFncRentDateIsNull() {
            addCriterion("fnc_rent_date is null");
            return (Criteria) this;
        }

        public Criteria andFncRentDateIsNotNull() {
            addCriterion("fnc_rent_date is not null");
            return (Criteria) this;
        }

        public Criteria andFncRentDateEqualTo(Date value) {
            addCriterion("fnc_rent_date =", value, "fncRentDate");
            return (Criteria) this;
        }

        public Criteria andFncRentDateNotEqualTo(Date value) {
            addCriterion("fnc_rent_date <>", value, "fncRentDate");
            return (Criteria) this;
        }

        public Criteria andFncRentDateGreaterThan(Date value) {
            addCriterion("fnc_rent_date >", value, "fncRentDate");
            return (Criteria) this;
        }

        public Criteria andFncRentDateGreaterThanOrEqualTo(Date value) {
            addCriterion("fnc_rent_date >=", value, "fncRentDate");
            return (Criteria) this;
        }

        public Criteria andFncRentDateLessThan(Date value) {
            addCriterion("fnc_rent_date <", value, "fncRentDate");
            return (Criteria) this;
        }

        public Criteria andFncRentDateLessThanOrEqualTo(Date value) {
            addCriterion("fnc_rent_date <=", value, "fncRentDate");
            return (Criteria) this;
        }

        public Criteria andFncRentDateIn(List<Date> values) {
            addCriterion("fnc_rent_date in", values, "fncRentDate");
            return (Criteria) this;
        }

        public Criteria andFncRentDateNotIn(List<Date> values) {
            addCriterion("fnc_rent_date not in", values, "fncRentDate");
            return (Criteria) this;
        }

        public Criteria andFncRentDateBetween(Date value1, Date value2) {
            addCriterion("fnc_rent_date between", value1, value2, "fncRentDate");
            return (Criteria) this;
        }

        public Criteria andFncRentDateNotBetween(Date value1, Date value2) {
            addCriterion("fnc_rent_date not between", value1, value2, "fncRentDate");
            return (Criteria) this;
        }

        public Criteria andFncLeaseCountIsNull() {
            addCriterion("fnc_lease_count is null");
            return (Criteria) this;
        }

        public Criteria andFncLeaseCountIsNotNull() {
            addCriterion("fnc_lease_count is not null");
            return (Criteria) this;
        }

        public Criteria andFncLeaseCountEqualTo(Integer value) {
            addCriterion("fnc_lease_count =", value, "fncLeaseCount");
            return (Criteria) this;
        }

        public Criteria andFncLeaseCountNotEqualTo(Integer value) {
            addCriterion("fnc_lease_count <>", value, "fncLeaseCount");
            return (Criteria) this;
        }

        public Criteria andFncLeaseCountGreaterThan(Integer value) {
            addCriterion("fnc_lease_count >", value, "fncLeaseCount");
            return (Criteria) this;
        }

        public Criteria andFncLeaseCountGreaterThanOrEqualTo(Integer value) {
            addCriterion("fnc_lease_count >=", value, "fncLeaseCount");
            return (Criteria) this;
        }

        public Criteria andFncLeaseCountLessThan(Integer value) {
            addCriterion("fnc_lease_count <", value, "fncLeaseCount");
            return (Criteria) this;
        }

        public Criteria andFncLeaseCountLessThanOrEqualTo(Integer value) {
            addCriterion("fnc_lease_count <=", value, "fncLeaseCount");
            return (Criteria) this;
        }

        public Criteria andFncLeaseCountIn(List<Integer> values) {
            addCriterion("fnc_lease_count in", values, "fncLeaseCount");
            return (Criteria) this;
        }

        public Criteria andFncLeaseCountNotIn(List<Integer> values) {
            addCriterion("fnc_lease_count not in", values, "fncLeaseCount");
            return (Criteria) this;
        }

        public Criteria andFncLeaseCountBetween(Integer value1, Integer value2) {
            addCriterion("fnc_lease_count between", value1, value2, "fncLeaseCount");
            return (Criteria) this;
        }

        public Criteria andFncLeaseCountNotBetween(Integer value1, Integer value2) {
            addCriterion("fnc_lease_count not between", value1, value2, "fncLeaseCount");
            return (Criteria) this;
        }

        public Criteria andFncMonthIsNull() {
            addCriterion("fnc_month is null");
            return (Criteria) this;
        }

        public Criteria andFncMonthIsNotNull() {
            addCriterion("fnc_month is not null");
            return (Criteria) this;
        }

        public Criteria andFncMonthEqualTo(Date value) {
            addCriterion("fnc_month =", value, "fncMonth");
            return (Criteria) this;
        }

        public Criteria andFncMonthNotEqualTo(Date value) {
            addCriterion("fnc_month <>", value, "fncMonth");
            return (Criteria) this;
        }

        public Criteria andFncMonthGreaterThan(Date value) {
            addCriterion("fnc_month >", value, "fncMonth");
            return (Criteria) this;
        }

        public Criteria andFncMonthGreaterThanOrEqualTo(Date value) {
            addCriterion("fnc_month >=", value, "fncMonth");
            return (Criteria) this;
        }

        public Criteria andFncMonthLessThan(Date value) {
            addCriterion("fnc_month <", value, "fncMonth");
            return (Criteria) this;
        }

        public Criteria andFncMonthLessThanOrEqualTo(Date value) {
            addCriterion("fnc_month <=", value, "fncMonth");
            return (Criteria) this;
        }

        public Criteria andFncMonthIn(List<Date> values) {
            addCriterion("fnc_month in", values, "fncMonth");
            return (Criteria) this;
        }

        public Criteria andFncMonthNotIn(List<Date> values) {
            addCriterion("fnc_month not in", values, "fncMonth");
            return (Criteria) this;
        }

        public Criteria andFncMonthBetween(Date value1, Date value2) {
            addCriterion("fnc_month between", value1, value2, "fncMonth");
            return (Criteria) this;
        }

        public Criteria andFncMonthNotBetween(Date value1, Date value2) {
            addCriterion("fnc_month not between", value1, value2, "fncMonth");
            return (Criteria) this;
        }

        public Criteria andFncMonthRentIsNull() {
            addCriterion("fnc_month_rent is null");
            return (Criteria) this;
        }

        public Criteria andFncMonthRentIsNotNull() {
            addCriterion("fnc_month_rent is not null");
            return (Criteria) this;
        }

        public Criteria andFncMonthRentEqualTo(Double value) {
            addCriterion("fnc_month_rent =", value, "fncMonthRent");
            return (Criteria) this;
        }

        public Criteria andFncMonthRentNotEqualTo(Double value) {
            addCriterion("fnc_month_rent <>", value, "fncMonthRent");
            return (Criteria) this;
        }

        public Criteria andFncMonthRentGreaterThan(Double value) {
            addCriterion("fnc_month_rent >", value, "fncMonthRent");
            return (Criteria) this;
        }

        public Criteria andFncMonthRentGreaterThanOrEqualTo(Double value) {
            addCriterion("fnc_month_rent >=", value, "fncMonthRent");
            return (Criteria) this;
        }

        public Criteria andFncMonthRentLessThan(Double value) {
            addCriterion("fnc_month_rent <", value, "fncMonthRent");
            return (Criteria) this;
        }

        public Criteria andFncMonthRentLessThanOrEqualTo(Double value) {
            addCriterion("fnc_month_rent <=", value, "fncMonthRent");
            return (Criteria) this;
        }

        public Criteria andFncMonthRentIn(List<Double> values) {
            addCriterion("fnc_month_rent in", values, "fncMonthRent");
            return (Criteria) this;
        }

        public Criteria andFncMonthRentNotIn(List<Double> values) {
            addCriterion("fnc_month_rent not in", values, "fncMonthRent");
            return (Criteria) this;
        }

        public Criteria andFncMonthRentBetween(Double value1, Double value2) {
            addCriterion("fnc_month_rent between", value1, value2, "fncMonthRent");
            return (Criteria) this;
        }

        public Criteria andFncMonthRentNotBetween(Double value1, Double value2) {
            addCriterion("fnc_month_rent not between", value1, value2, "fncMonthRent");
            return (Criteria) this;
        }

        public Criteria andFncMonthWithholdIsNull() {
            addCriterion("fnc_month_withhold is null");
            return (Criteria) this;
        }

        public Criteria andFncMonthWithholdIsNotNull() {
            addCriterion("fnc_month_withhold is not null");
            return (Criteria) this;
        }

        public Criteria andFncMonthWithholdEqualTo(Double value) {
            addCriterion("fnc_month_withhold =", value, "fncMonthWithhold");
            return (Criteria) this;
        }

        public Criteria andFncMonthWithholdNotEqualTo(Double value) {
            addCriterion("fnc_month_withhold <>", value, "fncMonthWithhold");
            return (Criteria) this;
        }

        public Criteria andFncMonthWithholdGreaterThan(Double value) {
            addCriterion("fnc_month_withhold >", value, "fncMonthWithhold");
            return (Criteria) this;
        }

        public Criteria andFncMonthWithholdGreaterThanOrEqualTo(Double value) {
            addCriterion("fnc_month_withhold >=", value, "fncMonthWithhold");
            return (Criteria) this;
        }

        public Criteria andFncMonthWithholdLessThan(Double value) {
            addCriterion("fnc_month_withhold <", value, "fncMonthWithhold");
            return (Criteria) this;
        }

        public Criteria andFncMonthWithholdLessThanOrEqualTo(Double value) {
            addCriterion("fnc_month_withhold <=", value, "fncMonthWithhold");
            return (Criteria) this;
        }

        public Criteria andFncMonthWithholdIn(List<Double> values) {
            addCriterion("fnc_month_withhold in", values, "fncMonthWithhold");
            return (Criteria) this;
        }

        public Criteria andFncMonthWithholdNotIn(List<Double> values) {
            addCriterion("fnc_month_withhold not in", values, "fncMonthWithhold");
            return (Criteria) this;
        }

        public Criteria andFncMonthWithholdBetween(Double value1, Double value2) {
            addCriterion("fnc_month_withhold between", value1, value2, "fncMonthWithhold");
            return (Criteria) this;
        }

        public Criteria andFncMonthWithholdNotBetween(Double value1, Double value2) {
            addCriterion("fnc_month_withhold not between", value1, value2, "fncMonthWithhold");
            return (Criteria) this;
        }

        public Criteria andFncErrorMsgIsNull() {
            addCriterion("fnc_error_msg is null");
            return (Criteria) this;
        }

        public Criteria andFncErrorMsgIsNotNull() {
            addCriterion("fnc_error_msg is not null");
            return (Criteria) this;
        }

        public Criteria andFncErrorMsgEqualTo(String value) {
            addCriterion("fnc_error_msg =", value, "fncErrorMsg");
            return (Criteria) this;
        }

        public Criteria andFncErrorMsgNotEqualTo(String value) {
            addCriterion("fnc_error_msg <>", value, "fncErrorMsg");
            return (Criteria) this;
        }

        public Criteria andFncErrorMsgGreaterThan(String value) {
            addCriterion("fnc_error_msg >", value, "fncErrorMsg");
            return (Criteria) this;
        }

        public Criteria andFncErrorMsgGreaterThanOrEqualTo(String value) {
            addCriterion("fnc_error_msg >=", value, "fncErrorMsg");
            return (Criteria) this;
        }

        public Criteria andFncErrorMsgLessThan(String value) {
            addCriterion("fnc_error_msg <", value, "fncErrorMsg");
            return (Criteria) this;
        }

        public Criteria andFncErrorMsgLessThanOrEqualTo(String value) {
            addCriterion("fnc_error_msg <=", value, "fncErrorMsg");
            return (Criteria) this;
        }

        public Criteria andFncErrorMsgLike(String value) {
            addCriterion("fnc_error_msg like", value, "fncErrorMsg");
            return (Criteria) this;
        }

        public Criteria andFncErrorMsgNotLike(String value) {
            addCriterion("fnc_error_msg not like", value, "fncErrorMsg");
            return (Criteria) this;
        }

        public Criteria andFncErrorMsgIn(List<String> values) {
            addCriterion("fnc_error_msg in", values, "fncErrorMsg");
            return (Criteria) this;
        }

        public Criteria andFncErrorMsgNotIn(List<String> values) {
            addCriterion("fnc_error_msg not in", values, "fncErrorMsg");
            return (Criteria) this;
        }

        public Criteria andFncErrorMsgBetween(String value1, String value2) {
            addCriterion("fnc_error_msg between", value1, value2, "fncErrorMsg");
            return (Criteria) this;
        }

        public Criteria andFncErrorMsgNotBetween(String value1, String value2) {
            addCriterion("fnc_error_msg not between", value1, value2, "fncErrorMsg");
            return (Criteria) this;
        }

        public Criteria andFncErrorIsNull() {
            addCriterion("fnc_error is null");
            return (Criteria) this;
        }

        public Criteria andFncErrorIsNotNull() {
            addCriterion("fnc_error is not null");
            return (Criteria) this;
        }

        public Criteria andFncErrorEqualTo(Integer value) {
            addCriterion("fnc_error =", value, "fncError");
            return (Criteria) this;
        }

        public Criteria andFncErrorNotEqualTo(Integer value) {
            addCriterion("fnc_error <>", value, "fncError");
            return (Criteria) this;
        }

        public Criteria andFncErrorGreaterThan(Integer value) {
            addCriterion("fnc_error >", value, "fncError");
            return (Criteria) this;
        }

        public Criteria andFncErrorGreaterThanOrEqualTo(Integer value) {
            addCriterion("fnc_error >=", value, "fncError");
            return (Criteria) this;
        }

        public Criteria andFncErrorLessThan(Integer value) {
            addCriterion("fnc_error <", value, "fncError");
            return (Criteria) this;
        }

        public Criteria andFncErrorLessThanOrEqualTo(Integer value) {
            addCriterion("fnc_error <=", value, "fncError");
            return (Criteria) this;
        }

        public Criteria andFncErrorIn(List<Integer> values) {
            addCriterion("fnc_error in", values, "fncError");
            return (Criteria) this;
        }

        public Criteria andFncErrorNotIn(List<Integer> values) {
            addCriterion("fnc_error not in", values, "fncError");
            return (Criteria) this;
        }

        public Criteria andFncErrorBetween(Integer value1, Integer value2) {
            addCriterion("fnc_error between", value1, value2, "fncError");
            return (Criteria) this;
        }

        public Criteria andFncErrorNotBetween(Integer value1, Integer value2) {
            addCriterion("fnc_error not between", value1, value2, "fncError");
            return (Criteria) this;
        }

        public Criteria andFncAccountNoIsNull() {
            addCriterion("fnc_account_no is null");
            return (Criteria) this;
        }

        public Criteria andFncAccountNoIsNotNull() {
            addCriterion("fnc_account_no is not null");
            return (Criteria) this;
        }

        public Criteria andFncAccountNoEqualTo(String value) {
            addCriterion("fnc_account_no =", value, "fncAccountNo");
            return (Criteria) this;
        }

        public Criteria andFncAccountNoNotEqualTo(String value) {
            addCriterion("fnc_account_no <>", value, "fncAccountNo");
            return (Criteria) this;
        }

        public Criteria andFncAccountNoGreaterThan(String value) {
            addCriterion("fnc_account_no >", value, "fncAccountNo");
            return (Criteria) this;
        }

        public Criteria andFncAccountNoGreaterThanOrEqualTo(String value) {
            addCriterion("fnc_account_no >=", value, "fncAccountNo");
            return (Criteria) this;
        }

        public Criteria andFncAccountNoLessThan(String value) {
            addCriterion("fnc_account_no <", value, "fncAccountNo");
            return (Criteria) this;
        }

        public Criteria andFncAccountNoLessThanOrEqualTo(String value) {
            addCriterion("fnc_account_no <=", value, "fncAccountNo");
            return (Criteria) this;
        }

        public Criteria andFncAccountNoLike(String value) {
            addCriterion("fnc_account_no like", value, "fncAccountNo");
            return (Criteria) this;
        }

        public Criteria andFncAccountNoNotLike(String value) {
            addCriterion("fnc_account_no not like", value, "fncAccountNo");
            return (Criteria) this;
        }

        public Criteria andFncAccountNoIn(List<String> values) {
            addCriterion("fnc_account_no in", values, "fncAccountNo");
            return (Criteria) this;
        }

        public Criteria andFncAccountNoNotIn(List<String> values) {
            addCriterion("fnc_account_no not in", values, "fncAccountNo");
            return (Criteria) this;
        }

        public Criteria andFncAccountNoBetween(String value1, String value2) {
            addCriterion("fnc_account_no between", value1, value2, "fncAccountNo");
            return (Criteria) this;
        }

        public Criteria andFncAccountNoNotBetween(String value1, String value2) {
            addCriterion("fnc_account_no not between", value1, value2, "fncAccountNo");
            return (Criteria) this;
        }

        public Criteria andFncOperateCodeIsNull() {
            addCriterion("fnc_operate_code is null");
            return (Criteria) this;
        }

        public Criteria andFncOperateCodeIsNotNull() {
            addCriterion("fnc_operate_code is not null");
            return (Criteria) this;
        }

        public Criteria andFncOperateCodeEqualTo(String value) {
            addCriterion("fnc_operate_code =", value, "fncOperateCode");
            return (Criteria) this;
        }

        public Criteria andFncOperateCodeNotEqualTo(String value) {
            addCriterion("fnc_operate_code <>", value, "fncOperateCode");
            return (Criteria) this;
        }

        public Criteria andFncOperateCodeGreaterThan(String value) {
            addCriterion("fnc_operate_code >", value, "fncOperateCode");
            return (Criteria) this;
        }

        public Criteria andFncOperateCodeGreaterThanOrEqualTo(String value) {
            addCriterion("fnc_operate_code >=", value, "fncOperateCode");
            return (Criteria) this;
        }

        public Criteria andFncOperateCodeLessThan(String value) {
            addCriterion("fnc_operate_code <", value, "fncOperateCode");
            return (Criteria) this;
        }

        public Criteria andFncOperateCodeLessThanOrEqualTo(String value) {
            addCriterion("fnc_operate_code <=", value, "fncOperateCode");
            return (Criteria) this;
        }

        public Criteria andFncOperateCodeLike(String value) {
            addCriterion("fnc_operate_code like", value, "fncOperateCode");
            return (Criteria) this;
        }

        public Criteria andFncOperateCodeNotLike(String value) {
            addCriterion("fnc_operate_code not like", value, "fncOperateCode");
            return (Criteria) this;
        }

        public Criteria andFncOperateCodeIn(List<String> values) {
            addCriterion("fnc_operate_code in", values, "fncOperateCode");
            return (Criteria) this;
        }

        public Criteria andFncOperateCodeNotIn(List<String> values) {
            addCriterion("fnc_operate_code not in", values, "fncOperateCode");
            return (Criteria) this;
        }

        public Criteria andFncOperateCodeBetween(String value1, String value2) {
            addCriterion("fnc_operate_code between", value1, value2, "fncOperateCode");
            return (Criteria) this;
        }

        public Criteria andFncOperateCodeNotBetween(String value1, String value2) {
            addCriterion("fnc_operate_code not between", value1, value2, "fncOperateCode");
            return (Criteria) this;
        }

        public Criteria andFncTradeTimeIsNull() {
            addCriterion("fnc_trade_time is null");
            return (Criteria) this;
        }

        public Criteria andFncTradeTimeIsNotNull() {
            addCriterion("fnc_trade_time is not null");
            return (Criteria) this;
        }

        public Criteria andFncTradeTimeEqualTo(Date value) {
            addCriterion("fnc_trade_time =", value, "fncTradeTime");
            return (Criteria) this;
        }

        public Criteria andFncTradeTimeNotEqualTo(Date value) {
            addCriterion("fnc_trade_time <>", value, "fncTradeTime");
            return (Criteria) this;
        }

        public Criteria andFncTradeTimeGreaterThan(Date value) {
            addCriterion("fnc_trade_time >", value, "fncTradeTime");
            return (Criteria) this;
        }

        public Criteria andFncTradeTimeGreaterThanOrEqualTo(Date value) {
            addCriterion("fnc_trade_time >=", value, "fncTradeTime");
            return (Criteria) this;
        }

        public Criteria andFncTradeTimeLessThan(Date value) {
            addCriterion("fnc_trade_time <", value, "fncTradeTime");
            return (Criteria) this;
        }

        public Criteria andFncTradeTimeLessThanOrEqualTo(Date value) {
            addCriterion("fnc_trade_time <=", value, "fncTradeTime");
            return (Criteria) this;
        }

        public Criteria andFncTradeTimeIn(List<Date> values) {
            addCriterion("fnc_trade_time in", values, "fncTradeTime");
            return (Criteria) this;
        }

        public Criteria andFncTradeTimeNotIn(List<Date> values) {
            addCriterion("fnc_trade_time not in", values, "fncTradeTime");
            return (Criteria) this;
        }

        public Criteria andFncTradeTimeBetween(Date value1, Date value2) {
            addCriterion("fnc_trade_time between", value1, value2, "fncTradeTime");
            return (Criteria) this;
        }

        public Criteria andFncTradeTimeNotBetween(Date value1, Date value2) {
            addCriterion("fnc_trade_time not between", value1, value2, "fncTradeTime");
            return (Criteria) this;
        }

        public Criteria andFncTradeAmountIsNull() {
            addCriterion("fnc_trade_amount is null");
            return (Criteria) this;
        }

        public Criteria andFncTradeAmountIsNotNull() {
            addCriterion("fnc_trade_amount is not null");
            return (Criteria) this;
        }

        public Criteria andFncTradeAmountEqualTo(Double value) {
            addCriterion("fnc_trade_amount =", value, "fncTradeAmount");
            return (Criteria) this;
        }

        public Criteria andFncTradeAmountNotEqualTo(Double value) {
            addCriterion("fnc_trade_amount <>", value, "fncTradeAmount");
            return (Criteria) this;
        }

        public Criteria andFncTradeAmountGreaterThan(Double value) {
            addCriterion("fnc_trade_amount >", value, "fncTradeAmount");
            return (Criteria) this;
        }

        public Criteria andFncTradeAmountGreaterThanOrEqualTo(Double value) {
            addCriterion("fnc_trade_amount >=", value, "fncTradeAmount");
            return (Criteria) this;
        }

        public Criteria andFncTradeAmountLessThan(Double value) {
            addCriterion("fnc_trade_amount <", value, "fncTradeAmount");
            return (Criteria) this;
        }

        public Criteria andFncTradeAmountLessThanOrEqualTo(Double value) {
            addCriterion("fnc_trade_amount <=", value, "fncTradeAmount");
            return (Criteria) this;
        }

        public Criteria andFncTradeAmountIn(List<Double> values) {
            addCriterion("fnc_trade_amount in", values, "fncTradeAmount");
            return (Criteria) this;
        }

        public Criteria andFncTradeAmountNotIn(List<Double> values) {
            addCriterion("fnc_trade_amount not in", values, "fncTradeAmount");
            return (Criteria) this;
        }

        public Criteria andFncTradeAmountBetween(Double value1, Double value2) {
            addCriterion("fnc_trade_amount between", value1, value2, "fncTradeAmount");
            return (Criteria) this;
        }

        public Criteria andFncTradeAmountNotBetween(Double value1, Double value2) {
            addCriterion("fnc_trade_amount not between", value1, value2, "fncTradeAmount");
            return (Criteria) this;
        }

        public Criteria andFncTradeNamesIsNull() {
            addCriterion("fnc_trade_names is null");
            return (Criteria) this;
        }

        public Criteria andFncTradeNamesIsNotNull() {
            addCriterion("fnc_trade_names is not null");
            return (Criteria) this;
        }

        public Criteria andFncTradeNamesEqualTo(String value) {
            addCriterion("fnc_trade_names =", value, "fncTradeNames");
            return (Criteria) this;
        }

        public Criteria andFncTradeNamesNotEqualTo(String value) {
            addCriterion("fnc_trade_names <>", value, "fncTradeNames");
            return (Criteria) this;
        }

        public Criteria andFncTradeNamesGreaterThan(String value) {
            addCriterion("fnc_trade_names >", value, "fncTradeNames");
            return (Criteria) this;
        }

        public Criteria andFncTradeNamesGreaterThanOrEqualTo(String value) {
            addCriterion("fnc_trade_names >=", value, "fncTradeNames");
            return (Criteria) this;
        }

        public Criteria andFncTradeNamesLessThan(String value) {
            addCriterion("fnc_trade_names <", value, "fncTradeNames");
            return (Criteria) this;
        }

        public Criteria andFncTradeNamesLessThanOrEqualTo(String value) {
            addCriterion("fnc_trade_names <=", value, "fncTradeNames");
            return (Criteria) this;
        }

        public Criteria andFncTradeNamesLike(String value) {
            addCriterion("fnc_trade_names like", value, "fncTradeNames");
            return (Criteria) this;
        }

        public Criteria andFncTradeNamesNotLike(String value) {
            addCriterion("fnc_trade_names not like", value, "fncTradeNames");
            return (Criteria) this;
        }

        public Criteria andFncTradeNamesIn(List<String> values) {
            addCriterion("fnc_trade_names in", values, "fncTradeNames");
            return (Criteria) this;
        }

        public Criteria andFncTradeNamesNotIn(List<String> values) {
            addCriterion("fnc_trade_names not in", values, "fncTradeNames");
            return (Criteria) this;
        }

        public Criteria andFncTradeNamesBetween(String value1, String value2) {
            addCriterion("fnc_trade_names between", value1, value2, "fncTradeNames");
            return (Criteria) this;
        }

        public Criteria andFncTradeNamesNotBetween(String value1, String value2) {
            addCriterion("fnc_trade_names not between", value1, value2, "fncTradeNames");
            return (Criteria) this;
        }

        public Criteria andFncAccountDealFlowIsNull() {
            addCriterion("fnc_account_deal_flow is null");
            return (Criteria) this;
        }

        public Criteria andFncAccountDealFlowIsNotNull() {
            addCriterion("fnc_account_deal_flow is not null");
            return (Criteria) this;
        }

        public Criteria andFncAccountDealFlowEqualTo(String value) {
            addCriterion("fnc_account_deal_flow =", value, "fncAccountDealFlow");
            return (Criteria) this;
        }

        public Criteria andFncAccountDealFlowNotEqualTo(String value) {
            addCriterion("fnc_account_deal_flow <>", value, "fncAccountDealFlow");
            return (Criteria) this;
        }

        public Criteria andFncAccountDealFlowGreaterThan(String value) {
            addCriterion("fnc_account_deal_flow >", value, "fncAccountDealFlow");
            return (Criteria) this;
        }

        public Criteria andFncAccountDealFlowGreaterThanOrEqualTo(String value) {
            addCriterion("fnc_account_deal_flow >=", value, "fncAccountDealFlow");
            return (Criteria) this;
        }

        public Criteria andFncAccountDealFlowLessThan(String value) {
            addCriterion("fnc_account_deal_flow <", value, "fncAccountDealFlow");
            return (Criteria) this;
        }

        public Criteria andFncAccountDealFlowLessThanOrEqualTo(String value) {
            addCriterion("fnc_account_deal_flow <=", value, "fncAccountDealFlow");
            return (Criteria) this;
        }

        public Criteria andFncAccountDealFlowLike(String value) {
            addCriterion("fnc_account_deal_flow like", value, "fncAccountDealFlow");
            return (Criteria) this;
        }

        public Criteria andFncAccountDealFlowNotLike(String value) {
            addCriterion("fnc_account_deal_flow not like", value, "fncAccountDealFlow");
            return (Criteria) this;
        }

        public Criteria andFncAccountDealFlowIn(List<String> values) {
            addCriterion("fnc_account_deal_flow in", values, "fncAccountDealFlow");
            return (Criteria) this;
        }

        public Criteria andFncAccountDealFlowNotIn(List<String> values) {
            addCriterion("fnc_account_deal_flow not in", values, "fncAccountDealFlow");
            return (Criteria) this;
        }

        public Criteria andFncAccountDealFlowBetween(String value1, String value2) {
            addCriterion("fnc_account_deal_flow between", value1, value2, "fncAccountDealFlow");
            return (Criteria) this;
        }

        public Criteria andFncAccountDealFlowNotBetween(String value1, String value2) {
            addCriterion("fnc_account_deal_flow not between", value1, value2, "fncAccountDealFlow");
            return (Criteria) this;
        }

        public Criteria andFncTradePartyIsNull() {
            addCriterion("fnc_trade_party is null");
            return (Criteria) this;
        }

        public Criteria andFncTradePartyIsNotNull() {
            addCriterion("fnc_trade_party is not null");
            return (Criteria) this;
        }

        public Criteria andFncTradePartyEqualTo(String value) {
            addCriterion("fnc_trade_party =", value, "fncTradeParty");
            return (Criteria) this;
        }

        public Criteria andFncTradePartyNotEqualTo(String value) {
            addCriterion("fnc_trade_party <>", value, "fncTradeParty");
            return (Criteria) this;
        }

        public Criteria andFncTradePartyGreaterThan(String value) {
            addCriterion("fnc_trade_party >", value, "fncTradeParty");
            return (Criteria) this;
        }

        public Criteria andFncTradePartyGreaterThanOrEqualTo(String value) {
            addCriterion("fnc_trade_party >=", value, "fncTradeParty");
            return (Criteria) this;
        }

        public Criteria andFncTradePartyLessThan(String value) {
            addCriterion("fnc_trade_party <", value, "fncTradeParty");
            return (Criteria) this;
        }

        public Criteria andFncTradePartyLessThanOrEqualTo(String value) {
            addCriterion("fnc_trade_party <=", value, "fncTradeParty");
            return (Criteria) this;
        }

        public Criteria andFncTradePartyLike(String value) {
            addCriterion("fnc_trade_party like", value, "fncTradeParty");
            return (Criteria) this;
        }

        public Criteria andFncTradePartyNotLike(String value) {
            addCriterion("fnc_trade_party not like", value, "fncTradeParty");
            return (Criteria) this;
        }

        public Criteria andFncTradePartyIn(List<String> values) {
            addCriterion("fnc_trade_party in", values, "fncTradeParty");
            return (Criteria) this;
        }

        public Criteria andFncTradePartyNotIn(List<String> values) {
            addCriterion("fnc_trade_party not in", values, "fncTradeParty");
            return (Criteria) this;
        }

        public Criteria andFncTradePartyBetween(String value1, String value2) {
            addCriterion("fnc_trade_party between", value1, value2, "fncTradeParty");
            return (Criteria) this;
        }

        public Criteria andFncTradePartyNotBetween(String value1, String value2) {
            addCriterion("fnc_trade_party not between", value1, value2, "fncTradeParty");
            return (Criteria) this;
        }

        public Criteria andFncOrderNoIsNull() {
            addCriterion("fnc_order_no is null");
            return (Criteria) this;
        }

        public Criteria andFncOrderNoIsNotNull() {
            addCriterion("fnc_order_no is not null");
            return (Criteria) this;
        }

        public Criteria andFncOrderNoEqualTo(String value) {
            addCriterion("fnc_order_no =", value, "fncOrderNo");
            return (Criteria) this;
        }

        public Criteria andFncOrderNoNotEqualTo(String value) {
            addCriterion("fnc_order_no <>", value, "fncOrderNo");
            return (Criteria) this;
        }

        public Criteria andFncOrderNoGreaterThan(String value) {
            addCriterion("fnc_order_no >", value, "fncOrderNo");
            return (Criteria) this;
        }

        public Criteria andFncOrderNoGreaterThanOrEqualTo(String value) {
            addCriterion("fnc_order_no >=", value, "fncOrderNo");
            return (Criteria) this;
        }

        public Criteria andFncOrderNoLessThan(String value) {
            addCriterion("fnc_order_no <", value, "fncOrderNo");
            return (Criteria) this;
        }

        public Criteria andFncOrderNoLessThanOrEqualTo(String value) {
            addCriterion("fnc_order_no <=", value, "fncOrderNo");
            return (Criteria) this;
        }

        public Criteria andFncOrderNoLike(String value) {
            addCriterion("fnc_order_no like", value, "fncOrderNo");
            return (Criteria) this;
        }

        public Criteria andFncOrderNoNotLike(String value) {
            addCriterion("fnc_order_no not like", value, "fncOrderNo");
            return (Criteria) this;
        }

        public Criteria andFncOrderNoIn(List<String> values) {
            addCriterion("fnc_order_no in", values, "fncOrderNo");
            return (Criteria) this;
        }

        public Criteria andFncOrderNoNotIn(List<String> values) {
            addCriterion("fnc_order_no not in", values, "fncOrderNo");
            return (Criteria) this;
        }

        public Criteria andFncOrderNoBetween(String value1, String value2) {
            addCriterion("fnc_order_no between", value1, value2, "fncOrderNo");
            return (Criteria) this;
        }

        public Criteria andFncOrderNoNotBetween(String value1, String value2) {
            addCriterion("fnc_order_no not between", value1, value2, "fncOrderNo");
            return (Criteria) this;
        }

        public Criteria andFncVoucherNoIsNull() {
            addCriterion("fnc_voucher_no is null");
            return (Criteria) this;
        }

        public Criteria andFncVoucherNoIsNotNull() {
            addCriterion("fnc_voucher_no is not null");
            return (Criteria) this;
        }

        public Criteria andFncVoucherNoEqualTo(String value) {
            addCriterion("fnc_voucher_no =", value, "fncVoucherNo");
            return (Criteria) this;
        }

        public Criteria andFncVoucherNoNotEqualTo(String value) {
            addCriterion("fnc_voucher_no <>", value, "fncVoucherNo");
            return (Criteria) this;
        }

        public Criteria andFncVoucherNoGreaterThan(String value) {
            addCriterion("fnc_voucher_no >", value, "fncVoucherNo");
            return (Criteria) this;
        }

        public Criteria andFncVoucherNoGreaterThanOrEqualTo(String value) {
            addCriterion("fnc_voucher_no >=", value, "fncVoucherNo");
            return (Criteria) this;
        }

        public Criteria andFncVoucherNoLessThan(String value) {
            addCriterion("fnc_voucher_no <", value, "fncVoucherNo");
            return (Criteria) this;
        }

        public Criteria andFncVoucherNoLessThanOrEqualTo(String value) {
            addCriterion("fnc_voucher_no <=", value, "fncVoucherNo");
            return (Criteria) this;
        }

        public Criteria andFncVoucherNoLike(String value) {
            addCriterion("fnc_voucher_no like", value, "fncVoucherNo");
            return (Criteria) this;
        }

        public Criteria andFncVoucherNoNotLike(String value) {
            addCriterion("fnc_voucher_no not like", value, "fncVoucherNo");
            return (Criteria) this;
        }

        public Criteria andFncVoucherNoIn(List<String> values) {
            addCriterion("fnc_voucher_no in", values, "fncVoucherNo");
            return (Criteria) this;
        }

        public Criteria andFncVoucherNoNotIn(List<String> values) {
            addCriterion("fnc_voucher_no not in", values, "fncVoucherNo");
            return (Criteria) this;
        }

        public Criteria andFncVoucherNoBetween(String value1, String value2) {
            addCriterion("fnc_voucher_no between", value1, value2, "fncVoucherNo");
            return (Criteria) this;
        }

        public Criteria andFncVoucherNoNotBetween(String value1, String value2) {
            addCriterion("fnc_voucher_no not between", value1, value2, "fncVoucherNo");
            return (Criteria) this;
        }

        public Criteria andFncOwnAccountIsNull() {
            addCriterion("fnc_own_account is null");
            return (Criteria) this;
        }

        public Criteria andFncOwnAccountIsNotNull() {
            addCriterion("fnc_own_account is not null");
            return (Criteria) this;
        }

        public Criteria andFncOwnAccountEqualTo(String value) {
            addCriterion("fnc_own_account =", value, "fncOwnAccount");
            return (Criteria) this;
        }

        public Criteria andFncOwnAccountNotEqualTo(String value) {
            addCriterion("fnc_own_account <>", value, "fncOwnAccount");
            return (Criteria) this;
        }

        public Criteria andFncOwnAccountGreaterThan(String value) {
            addCriterion("fnc_own_account >", value, "fncOwnAccount");
            return (Criteria) this;
        }

        public Criteria andFncOwnAccountGreaterThanOrEqualTo(String value) {
            addCriterion("fnc_own_account >=", value, "fncOwnAccount");
            return (Criteria) this;
        }

        public Criteria andFncOwnAccountLessThan(String value) {
            addCriterion("fnc_own_account <", value, "fncOwnAccount");
            return (Criteria) this;
        }

        public Criteria andFncOwnAccountLessThanOrEqualTo(String value) {
            addCriterion("fnc_own_account <=", value, "fncOwnAccount");
            return (Criteria) this;
        }

        public Criteria andFncOwnAccountLike(String value) {
            addCriterion("fnc_own_account like", value, "fncOwnAccount");
            return (Criteria) this;
        }

        public Criteria andFncOwnAccountNotLike(String value) {
            addCriterion("fnc_own_account not like", value, "fncOwnAccount");
            return (Criteria) this;
        }

        public Criteria andFncOwnAccountIn(List<String> values) {
            addCriterion("fnc_own_account in", values, "fncOwnAccount");
            return (Criteria) this;
        }

        public Criteria andFncOwnAccountNotIn(List<String> values) {
            addCriterion("fnc_own_account not in", values, "fncOwnAccount");
            return (Criteria) this;
        }

        public Criteria andFncOwnAccountBetween(String value1, String value2) {
            addCriterion("fnc_own_account between", value1, value2, "fncOwnAccount");
            return (Criteria) this;
        }

        public Criteria andFncOwnAccountNotBetween(String value1, String value2) {
            addCriterion("fnc_own_account not between", value1, value2, "fncOwnAccount");
            return (Criteria) this;
        }

        public Criteria andFncMonthRentBalanceIsNull() {
            addCriterion("fnc_month_rent_balance is null");
            return (Criteria) this;
        }

        public Criteria andFncMonthRentBalanceIsNotNull() {
            addCriterion("fnc_month_rent_balance is not null");
            return (Criteria) this;
        }

        public Criteria andFncMonthRentBalanceEqualTo(Double value) {
            addCriterion("fnc_month_rent_balance =", value, "fncMonthRentBalance");
            return (Criteria) this;
        }

        public Criteria andFncMonthRentBalanceNotEqualTo(Double value) {
            addCriterion("fnc_month_rent_balance <>", value, "fncMonthRentBalance");
            return (Criteria) this;
        }

        public Criteria andFncMonthRentBalanceGreaterThan(Double value) {
            addCriterion("fnc_month_rent_balance >", value, "fncMonthRentBalance");
            return (Criteria) this;
        }

        public Criteria andFncMonthRentBalanceGreaterThanOrEqualTo(Double value) {
            addCriterion("fnc_month_rent_balance >=", value, "fncMonthRentBalance");
            return (Criteria) this;
        }

        public Criteria andFncMonthRentBalanceLessThan(Double value) {
            addCriterion("fnc_month_rent_balance <", value, "fncMonthRentBalance");
            return (Criteria) this;
        }

        public Criteria andFncMonthRentBalanceLessThanOrEqualTo(Double value) {
            addCriterion("fnc_month_rent_balance <=", value, "fncMonthRentBalance");
            return (Criteria) this;
        }

        public Criteria andFncMonthRentBalanceIn(List<Double> values) {
            addCriterion("fnc_month_rent_balance in", values, "fncMonthRentBalance");
            return (Criteria) this;
        }

        public Criteria andFncMonthRentBalanceNotIn(List<Double> values) {
            addCriterion("fnc_month_rent_balance not in", values, "fncMonthRentBalance");
            return (Criteria) this;
        }

        public Criteria andFncMonthRentBalanceBetween(Double value1, Double value2) {
            addCriterion("fnc_month_rent_balance between", value1, value2, "fncMonthRentBalance");
            return (Criteria) this;
        }

        public Criteria andFncMonthRentBalanceNotBetween(Double value1, Double value2) {
            addCriterion("fnc_month_rent_balance not between", value1, value2, "fncMonthRentBalance");
            return (Criteria) this;
        }

        public Criteria andFncDigestIsNull() {
            addCriterion("fnc_digest is null");
            return (Criteria) this;
        }

        public Criteria andFncDigestIsNotNull() {
            addCriterion("fnc_digest is not null");
            return (Criteria) this;
        }

        public Criteria andFncDigestEqualTo(String value) {
            addCriterion("fnc_digest =", value, "fncDigest");
            return (Criteria) this;
        }

        public Criteria andFncDigestNotEqualTo(String value) {
            addCriterion("fnc_digest <>", value, "fncDigest");
            return (Criteria) this;
        }

        public Criteria andFncDigestGreaterThan(String value) {
            addCriterion("fnc_digest >", value, "fncDigest");
            return (Criteria) this;
        }

        public Criteria andFncDigestGreaterThanOrEqualTo(String value) {
            addCriterion("fnc_digest >=", value, "fncDigest");
            return (Criteria) this;
        }

        public Criteria andFncDigestLessThan(String value) {
            addCriterion("fnc_digest <", value, "fncDigest");
            return (Criteria) this;
        }

        public Criteria andFncDigestLessThanOrEqualTo(String value) {
            addCriterion("fnc_digest <=", value, "fncDigest");
            return (Criteria) this;
        }

        public Criteria andFncDigestLike(String value) {
            addCriterion("fnc_digest like", value, "fncDigest");
            return (Criteria) this;
        }

        public Criteria andFncDigestNotLike(String value) {
            addCriterion("fnc_digest not like", value, "fncDigest");
            return (Criteria) this;
        }

        public Criteria andFncDigestIn(List<String> values) {
            addCriterion("fnc_digest in", values, "fncDigest");
            return (Criteria) this;
        }

        public Criteria andFncDigestNotIn(List<String> values) {
            addCriterion("fnc_digest not in", values, "fncDigest");
            return (Criteria) this;
        }

        public Criteria andFncDigestBetween(String value1, String value2) {
            addCriterion("fnc_digest between", value1, value2, "fncDigest");
            return (Criteria) this;
        }

        public Criteria andFncDigestNotBetween(String value1, String value2) {
            addCriterion("fnc_digest not between", value1, value2, "fncDigest");
            return (Criteria) this;
        }

        public Criteria andFncOtherAccountIsNull() {
            addCriterion("fnc_other_account is null");
            return (Criteria) this;
        }

        public Criteria andFncOtherAccountIsNotNull() {
            addCriterion("fnc_other_account is not null");
            return (Criteria) this;
        }

        public Criteria andFncOtherAccountEqualTo(String value) {
            addCriterion("fnc_other_account =", value, "fncOtherAccount");
            return (Criteria) this;
        }

        public Criteria andFncOtherAccountNotEqualTo(String value) {
            addCriterion("fnc_other_account <>", value, "fncOtherAccount");
            return (Criteria) this;
        }

        public Criteria andFncOtherAccountGreaterThan(String value) {
            addCriterion("fnc_other_account >", value, "fncOtherAccount");
            return (Criteria) this;
        }

        public Criteria andFncOtherAccountGreaterThanOrEqualTo(String value) {
            addCriterion("fnc_other_account >=", value, "fncOtherAccount");
            return (Criteria) this;
        }

        public Criteria andFncOtherAccountLessThan(String value) {
            addCriterion("fnc_other_account <", value, "fncOtherAccount");
            return (Criteria) this;
        }

        public Criteria andFncOtherAccountLessThanOrEqualTo(String value) {
            addCriterion("fnc_other_account <=", value, "fncOtherAccount");
            return (Criteria) this;
        }

        public Criteria andFncOtherAccountLike(String value) {
            addCriterion("fnc_other_account like", value, "fncOtherAccount");
            return (Criteria) this;
        }

        public Criteria andFncOtherAccountNotLike(String value) {
            addCriterion("fnc_other_account not like", value, "fncOtherAccount");
            return (Criteria) this;
        }

        public Criteria andFncOtherAccountIn(List<String> values) {
            addCriterion("fnc_other_account in", values, "fncOtherAccount");
            return (Criteria) this;
        }

        public Criteria andFncOtherAccountNotIn(List<String> values) {
            addCriterion("fnc_other_account not in", values, "fncOtherAccount");
            return (Criteria) this;
        }

        public Criteria andFncOtherAccountBetween(String value1, String value2) {
            addCriterion("fnc_other_account between", value1, value2, "fncOtherAccount");
            return (Criteria) this;
        }

        public Criteria andFncOtherAccountNotBetween(String value1, String value2) {
            addCriterion("fnc_other_account not between", value1, value2, "fncOtherAccount");
            return (Criteria) this;
        }

        public Criteria andFncOtherUnitNameIsNull() {
            addCriterion("fnc_other_unit_name is null");
            return (Criteria) this;
        }

        public Criteria andFncOtherUnitNameIsNotNull() {
            addCriterion("fnc_other_unit_name is not null");
            return (Criteria) this;
        }

        public Criteria andFncOtherUnitNameEqualTo(String value) {
            addCriterion("fnc_other_unit_name =", value, "fncOtherUnitName");
            return (Criteria) this;
        }

        public Criteria andFncOtherUnitNameNotEqualTo(String value) {
            addCriterion("fnc_other_unit_name <>", value, "fncOtherUnitName");
            return (Criteria) this;
        }

        public Criteria andFncOtherUnitNameGreaterThan(String value) {
            addCriterion("fnc_other_unit_name >", value, "fncOtherUnitName");
            return (Criteria) this;
        }

        public Criteria andFncOtherUnitNameGreaterThanOrEqualTo(String value) {
            addCriterion("fnc_other_unit_name >=", value, "fncOtherUnitName");
            return (Criteria) this;
        }

        public Criteria andFncOtherUnitNameLessThan(String value) {
            addCriterion("fnc_other_unit_name <", value, "fncOtherUnitName");
            return (Criteria) this;
        }

        public Criteria andFncOtherUnitNameLessThanOrEqualTo(String value) {
            addCriterion("fnc_other_unit_name <=", value, "fncOtherUnitName");
            return (Criteria) this;
        }

        public Criteria andFncOtherUnitNameLike(String value) {
            addCriterion("fnc_other_unit_name like", value, "fncOtherUnitName");
            return (Criteria) this;
        }

        public Criteria andFncOtherUnitNameNotLike(String value) {
            addCriterion("fnc_other_unit_name not like", value, "fncOtherUnitName");
            return (Criteria) this;
        }

        public Criteria andFncOtherUnitNameIn(List<String> values) {
            addCriterion("fnc_other_unit_name in", values, "fncOtherUnitName");
            return (Criteria) this;
        }

        public Criteria andFncOtherUnitNameNotIn(List<String> values) {
            addCriterion("fnc_other_unit_name not in", values, "fncOtherUnitName");
            return (Criteria) this;
        }

        public Criteria andFncOtherUnitNameBetween(String value1, String value2) {
            addCriterion("fnc_other_unit_name between", value1, value2, "fncOtherUnitName");
            return (Criteria) this;
        }

        public Criteria andFncOtherUnitNameNotBetween(String value1, String value2) {
            addCriterion("fnc_other_unit_name not between", value1, value2, "fncOtherUnitName");
            return (Criteria) this;
        }

        public Criteria andFncLoanTypeIsNull() {
            addCriterion("fnc_loan_type is null");
            return (Criteria) this;
        }

        public Criteria andFncLoanTypeIsNotNull() {
            addCriterion("fnc_loan_type is not null");
            return (Criteria) this;
        }

        public Criteria andFncLoanTypeEqualTo(String value) {
            addCriterion("fnc_loan_type =", value, "fncLoanType");
            return (Criteria) this;
        }

        public Criteria andFncLoanTypeNotEqualTo(String value) {
            addCriterion("fnc_loan_type <>", value, "fncLoanType");
            return (Criteria) this;
        }

        public Criteria andFncLoanTypeGreaterThan(String value) {
            addCriterion("fnc_loan_type >", value, "fncLoanType");
            return (Criteria) this;
        }

        public Criteria andFncLoanTypeGreaterThanOrEqualTo(String value) {
            addCriterion("fnc_loan_type >=", value, "fncLoanType");
            return (Criteria) this;
        }

        public Criteria andFncLoanTypeLessThan(String value) {
            addCriterion("fnc_loan_type <", value, "fncLoanType");
            return (Criteria) this;
        }

        public Criteria andFncLoanTypeLessThanOrEqualTo(String value) {
            addCriterion("fnc_loan_type <=", value, "fncLoanType");
            return (Criteria) this;
        }

        public Criteria andFncLoanTypeLike(String value) {
            addCriterion("fnc_loan_type like", value, "fncLoanType");
            return (Criteria) this;
        }

        public Criteria andFncLoanTypeNotLike(String value) {
            addCriterion("fnc_loan_type not like", value, "fncLoanType");
            return (Criteria) this;
        }

        public Criteria andFncLoanTypeIn(List<String> values) {
            addCriterion("fnc_loan_type in", values, "fncLoanType");
            return (Criteria) this;
        }

        public Criteria andFncLoanTypeNotIn(List<String> values) {
            addCriterion("fnc_loan_type not in", values, "fncLoanType");
            return (Criteria) this;
        }

        public Criteria andFncLoanTypeBetween(String value1, String value2) {
            addCriterion("fnc_loan_type between", value1, value2, "fncLoanType");
            return (Criteria) this;
        }

        public Criteria andFncLoanTypeNotBetween(String value1, String value2) {
            addCriterion("fnc_loan_type not between", value1, value2, "fncLoanType");
            return (Criteria) this;
        }

        public Criteria andFncDealTimeIsNull() {
            addCriterion("fnc_deal_time is null");
            return (Criteria) this;
        }

        public Criteria andFncDealTimeIsNotNull() {
            addCriterion("fnc_deal_time is not null");
            return (Criteria) this;
        }

        public Criteria andFncDealTimeEqualTo(Date value) {
            addCriterion("fnc_deal_time =", value, "fncDealTime");
            return (Criteria) this;
        }

        public Criteria andFncDealTimeNotEqualTo(Date value) {
            addCriterion("fnc_deal_time <>", value, "fncDealTime");
            return (Criteria) this;
        }

        public Criteria andFncDealTimeGreaterThan(Date value) {
            addCriterion("fnc_deal_time >", value, "fncDealTime");
            return (Criteria) this;
        }

        public Criteria andFncDealTimeGreaterThanOrEqualTo(Date value) {
            addCriterion("fnc_deal_time >=", value, "fncDealTime");
            return (Criteria) this;
        }

        public Criteria andFncDealTimeLessThan(Date value) {
            addCriterion("fnc_deal_time <", value, "fncDealTime");
            return (Criteria) this;
        }

        public Criteria andFncDealTimeLessThanOrEqualTo(Date value) {
            addCriterion("fnc_deal_time <=", value, "fncDealTime");
            return (Criteria) this;
        }

        public Criteria andFncDealTimeIn(List<Date> values) {
            addCriterion("fnc_deal_time in", values, "fncDealTime");
            return (Criteria) this;
        }

        public Criteria andFncDealTimeNotIn(List<Date> values) {
            addCriterion("fnc_deal_time not in", values, "fncDealTime");
            return (Criteria) this;
        }

        public Criteria andFncDealTimeBetween(Date value1, Date value2) {
            addCriterion("fnc_deal_time between", value1, value2, "fncDealTime");
            return (Criteria) this;
        }

        public Criteria andFncDealTimeNotBetween(Date value1, Date value2) {
            addCriterion("fnc_deal_time not between", value1, value2, "fncDealTime");
            return (Criteria) this;
        }

        public Criteria andFncBorrowAmountIsNull() {
            addCriterion("fnc_borrow_amount is null");
            return (Criteria) this;
        }

        public Criteria andFncBorrowAmountIsNotNull() {
            addCriterion("fnc_borrow_amount is not null");
            return (Criteria) this;
        }

        public Criteria andFncBorrowAmountEqualTo(Double value) {
            addCriterion("fnc_borrow_amount =", value, "fncBorrowAmount");
            return (Criteria) this;
        }

        public Criteria andFncBorrowAmountNotEqualTo(Double value) {
            addCriterion("fnc_borrow_amount <>", value, "fncBorrowAmount");
            return (Criteria) this;
        }

        public Criteria andFncBorrowAmountGreaterThan(Double value) {
            addCriterion("fnc_borrow_amount >", value, "fncBorrowAmount");
            return (Criteria) this;
        }

        public Criteria andFncBorrowAmountGreaterThanOrEqualTo(Double value) {
            addCriterion("fnc_borrow_amount >=", value, "fncBorrowAmount");
            return (Criteria) this;
        }

        public Criteria andFncBorrowAmountLessThan(Double value) {
            addCriterion("fnc_borrow_amount <", value, "fncBorrowAmount");
            return (Criteria) this;
        }

        public Criteria andFncBorrowAmountLessThanOrEqualTo(Double value) {
            addCriterion("fnc_borrow_amount <=", value, "fncBorrowAmount");
            return (Criteria) this;
        }

        public Criteria andFncBorrowAmountIn(List<Double> values) {
            addCriterion("fnc_borrow_amount in", values, "fncBorrowAmount");
            return (Criteria) this;
        }

        public Criteria andFncBorrowAmountNotIn(List<Double> values) {
            addCriterion("fnc_borrow_amount not in", values, "fncBorrowAmount");
            return (Criteria) this;
        }

        public Criteria andFncBorrowAmountBetween(Double value1, Double value2) {
            addCriterion("fnc_borrow_amount between", value1, value2, "fncBorrowAmount");
            return (Criteria) this;
        }

        public Criteria andFncBorrowAmountNotBetween(Double value1, Double value2) {
            addCriterion("fnc_borrow_amount not between", value1, value2, "fncBorrowAmount");
            return (Criteria) this;
        }

        public Criteria andFncCreditAmountIsNull() {
            addCriterion("fnc_credit_amount is null");
            return (Criteria) this;
        }

        public Criteria andFncCreditAmountIsNotNull() {
            addCriterion("fnc_credit_amount is not null");
            return (Criteria) this;
        }

        public Criteria andFncCreditAmountEqualTo(Double value) {
            addCriterion("fnc_credit_amount =", value, "fncCreditAmount");
            return (Criteria) this;
        }

        public Criteria andFncCreditAmountNotEqualTo(Double value) {
            addCriterion("fnc_credit_amount <>", value, "fncCreditAmount");
            return (Criteria) this;
        }

        public Criteria andFncCreditAmountGreaterThan(Double value) {
            addCriterion("fnc_credit_amount >", value, "fncCreditAmount");
            return (Criteria) this;
        }

        public Criteria andFncCreditAmountGreaterThanOrEqualTo(Double value) {
            addCriterion("fnc_credit_amount >=", value, "fncCreditAmount");
            return (Criteria) this;
        }

        public Criteria andFncCreditAmountLessThan(Double value) {
            addCriterion("fnc_credit_amount <", value, "fncCreditAmount");
            return (Criteria) this;
        }

        public Criteria andFncCreditAmountLessThanOrEqualTo(Double value) {
            addCriterion("fnc_credit_amount <=", value, "fncCreditAmount");
            return (Criteria) this;
        }

        public Criteria andFncCreditAmountIn(List<Double> values) {
            addCriterion("fnc_credit_amount in", values, "fncCreditAmount");
            return (Criteria) this;
        }

        public Criteria andFncCreditAmountNotIn(List<Double> values) {
            addCriterion("fnc_credit_amount not in", values, "fncCreditAmount");
            return (Criteria) this;
        }

        public Criteria andFncCreditAmountBetween(Double value1, Double value2) {
            addCriterion("fnc_credit_amount between", value1, value2, "fncCreditAmount");
            return (Criteria) this;
        }

        public Criteria andFncCreditAmountNotBetween(Double value1, Double value2) {
            addCriterion("fnc_credit_amount not between", value1, value2, "fncCreditAmount");
            return (Criteria) this;
        }

        public Criteria andFncUseIsNull() {
            addCriterion("fnc_use is null");
            return (Criteria) this;
        }

        public Criteria andFncUseIsNotNull() {
            addCriterion("fnc_use is not null");
            return (Criteria) this;
        }

        public Criteria andFncUseEqualTo(String value) {
            addCriterion("fnc_use =", value, "fncUse");
            return (Criteria) this;
        }

        public Criteria andFncUseNotEqualTo(String value) {
            addCriterion("fnc_use <>", value, "fncUse");
            return (Criteria) this;
        }

        public Criteria andFncUseGreaterThan(String value) {
            addCriterion("fnc_use >", value, "fncUse");
            return (Criteria) this;
        }

        public Criteria andFncUseGreaterThanOrEqualTo(String value) {
            addCriterion("fnc_use >=", value, "fncUse");
            return (Criteria) this;
        }

        public Criteria andFncUseLessThan(String value) {
            addCriterion("fnc_use <", value, "fncUse");
            return (Criteria) this;
        }

        public Criteria andFncUseLessThanOrEqualTo(String value) {
            addCriterion("fnc_use <=", value, "fncUse");
            return (Criteria) this;
        }

        public Criteria andFncUseLike(String value) {
            addCriterion("fnc_use like", value, "fncUse");
            return (Criteria) this;
        }

        public Criteria andFncUseNotLike(String value) {
            addCriterion("fnc_use not like", value, "fncUse");
            return (Criteria) this;
        }

        public Criteria andFncUseIn(List<String> values) {
            addCriterion("fnc_use in", values, "fncUse");
            return (Criteria) this;
        }

        public Criteria andFncUseNotIn(List<String> values) {
            addCriterion("fnc_use not in", values, "fncUse");
            return (Criteria) this;
        }

        public Criteria andFncUseBetween(String value1, String value2) {
            addCriterion("fnc_use between", value1, value2, "fncUse");
            return (Criteria) this;
        }

        public Criteria andFncUseNotBetween(String value1, String value2) {
            addCriterion("fnc_use not between", value1, value2, "fncUse");
            return (Criteria) this;
        }

        public Criteria andCreateuserIsNull() {
            addCriterion("createuser is null");
            return (Criteria) this;
        }

        public Criteria andCreateuserIsNotNull() {
            addCriterion("createuser is not null");
            return (Criteria) this;
        }

        public Criteria andCreateuserEqualTo(String value) {
            addCriterion("createuser =", value, "createuser");
            return (Criteria) this;
        }

        public Criteria andCreateuserNotEqualTo(String value) {
            addCriterion("createuser <>", value, "createuser");
            return (Criteria) this;
        }

        public Criteria andCreateuserGreaterThan(String value) {
            addCriterion("createuser >", value, "createuser");
            return (Criteria) this;
        }

        public Criteria andCreateuserGreaterThanOrEqualTo(String value) {
            addCriterion("createuser >=", value, "createuser");
            return (Criteria) this;
        }

        public Criteria andCreateuserLessThan(String value) {
            addCriterion("createuser <", value, "createuser");
            return (Criteria) this;
        }

        public Criteria andCreateuserLessThanOrEqualTo(String value) {
            addCriterion("createuser <=", value, "createuser");
            return (Criteria) this;
        }

        public Criteria andCreateuserLike(String value) {
            addCriterion("createuser like", value, "createuser");
            return (Criteria) this;
        }

        public Criteria andCreateuserNotLike(String value) {
            addCriterion("createuser not like", value, "createuser");
            return (Criteria) this;
        }

        public Criteria andCreateuserIn(List<String> values) {
            addCriterion("createuser in", values, "createuser");
            return (Criteria) this;
        }

        public Criteria andCreateuserNotIn(List<String> values) {
            addCriterion("createuser not in", values, "createuser");
            return (Criteria) this;
        }

        public Criteria andCreateuserBetween(String value1, String value2) {
            addCriterion("createuser between", value1, value2, "createuser");
            return (Criteria) this;
        }

        public Criteria andCreateuserNotBetween(String value1, String value2) {
            addCriterion("createuser not between", value1, value2, "createuser");
            return (Criteria) this;
        }

        public Criteria andCreatetimeIsNull() {
            addCriterion("createtime is null");
            return (Criteria) this;
        }

        public Criteria andCreatetimeIsNotNull() {
            addCriterion("createtime is not null");
            return (Criteria) this;
        }

        public Criteria andCreatetimeEqualTo(Date value) {
            addCriterion("createtime =", value, "createtime");
            return (Criteria) this;
        }

        public Criteria andCreatetimeNotEqualTo(Date value) {
            addCriterion("createtime <>", value, "createtime");
            return (Criteria) this;
        }

        public Criteria andCreatetimeGreaterThan(Date value) {
            addCriterion("createtime >", value, "createtime");
            return (Criteria) this;
        }

        public Criteria andCreatetimeGreaterThanOrEqualTo(Date value) {
            addCriterion("createtime >=", value, "createtime");
            return (Criteria) this;
        }

        public Criteria andCreatetimeLessThan(Date value) {
            addCriterion("createtime <", value, "createtime");
            return (Criteria) this;
        }

        public Criteria andCreatetimeLessThanOrEqualTo(Date value) {
            addCriterion("createtime <=", value, "createtime");
            return (Criteria) this;
        }

        public Criteria andCreatetimeIn(List<Date> values) {
            addCriterion("createtime in", values, "createtime");
            return (Criteria) this;
        }

        public Criteria andCreatetimeNotIn(List<Date> values) {
            addCriterion("createtime not in", values, "createtime");
            return (Criteria) this;
        }

        public Criteria andCreatetimeBetween(Date value1, Date value2) {
            addCriterion("createtime between", value1, value2, "createtime");
            return (Criteria) this;
        }

        public Criteria andCreatetimeNotBetween(Date value1, Date value2) {
            addCriterion("createtime not between", value1, value2, "createtime");
            return (Criteria) this;
        }

        public Criteria andUpdateuserIsNull() {
            addCriterion("updateuser is null");
            return (Criteria) this;
        }

        public Criteria andUpdateuserIsNotNull() {
            addCriterion("updateuser is not null");
            return (Criteria) this;
        }

        public Criteria andUpdateuserEqualTo(String value) {
            addCriterion("updateuser =", value, "updateuser");
            return (Criteria) this;
        }

        public Criteria andUpdateuserNotEqualTo(String value) {
            addCriterion("updateuser <>", value, "updateuser");
            return (Criteria) this;
        }

        public Criteria andUpdateuserGreaterThan(String value) {
            addCriterion("updateuser >", value, "updateuser");
            return (Criteria) this;
        }

        public Criteria andUpdateuserGreaterThanOrEqualTo(String value) {
            addCriterion("updateuser >=", value, "updateuser");
            return (Criteria) this;
        }

        public Criteria andUpdateuserLessThan(String value) {
            addCriterion("updateuser <", value, "updateuser");
            return (Criteria) this;
        }

        public Criteria andUpdateuserLessThanOrEqualTo(String value) {
            addCriterion("updateuser <=", value, "updateuser");
            return (Criteria) this;
        }

        public Criteria andUpdateuserLike(String value) {
            addCriterion("updateuser like", value, "updateuser");
            return (Criteria) this;
        }

        public Criteria andUpdateuserNotLike(String value) {
            addCriterion("updateuser not like", value, "updateuser");
            return (Criteria) this;
        }

        public Criteria andUpdateuserIn(List<String> values) {
            addCriterion("updateuser in", values, "updateuser");
            return (Criteria) this;
        }

        public Criteria andUpdateuserNotIn(List<String> values) {
            addCriterion("updateuser not in", values, "updateuser");
            return (Criteria) this;
        }

        public Criteria andUpdateuserBetween(String value1, String value2) {
            addCriterion("updateuser between", value1, value2, "updateuser");
            return (Criteria) this;
        }

        public Criteria andUpdateuserNotBetween(String value1, String value2) {
            addCriterion("updateuser not between", value1, value2, "updateuser");
            return (Criteria) this;
        }

        public Criteria andUpdatetimeIsNull() {
            addCriterion("updatetime is null");
            return (Criteria) this;
        }

        public Criteria andUpdatetimeIsNotNull() {
            addCriterion("updatetime is not null");
            return (Criteria) this;
        }

        public Criteria andUpdatetimeEqualTo(Date value) {
            addCriterion("updatetime =", value, "updatetime");
            return (Criteria) this;
        }

        public Criteria andUpdatetimeNotEqualTo(Date value) {
            addCriterion("updatetime <>", value, "updatetime");
            return (Criteria) this;
        }

        public Criteria andUpdatetimeGreaterThan(Date value) {
            addCriterion("updatetime >", value, "updatetime");
            return (Criteria) this;
        }

        public Criteria andUpdatetimeGreaterThanOrEqualTo(Date value) {
            addCriterion("updatetime >=", value, "updatetime");
            return (Criteria) this;
        }

        public Criteria andUpdatetimeLessThan(Date value) {
            addCriterion("updatetime <", value, "updatetime");
            return (Criteria) this;
        }

        public Criteria andUpdatetimeLessThanOrEqualTo(Date value) {
            addCriterion("updatetime <=", value, "updatetime");
            return (Criteria) this;
        }

        public Criteria andUpdatetimeIn(List<Date> values) {
            addCriterion("updatetime in", values, "updatetime");
            return (Criteria) this;
        }

        public Criteria andUpdatetimeNotIn(List<Date> values) {
            addCriterion("updatetime not in", values, "updatetime");
            return (Criteria) this;
        }

        public Criteria andUpdatetimeBetween(Date value1, Date value2) {
            addCriterion("updatetime between", value1, value2, "updatetime");
            return (Criteria) this;
        }

        public Criteria andUpdatetimeNotBetween(Date value1, Date value2) {
            addCriterion("updatetime not between", value1, value2, "updatetime");
            return (Criteria) this;
        }

        public Criteria andRemarkIsNull() {
            addCriterion("remark is null");
            return (Criteria) this;
        }

        public Criteria andRemarkIsNotNull() {
            addCriterion("remark is not null");
            return (Criteria) this;
        }

        public Criteria andRemarkEqualTo(String value) {
            addCriterion("remark =", value, "remark");
            return (Criteria) this;
        }

        public Criteria andRemarkNotEqualTo(String value) {
            addCriterion("remark <>", value, "remark");
            return (Criteria) this;
        }

        public Criteria andRemarkGreaterThan(String value) {
            addCriterion("remark >", value, "remark");
            return (Criteria) this;
        }

        public Criteria andRemarkGreaterThanOrEqualTo(String value) {
            addCriterion("remark >=", value, "remark");
            return (Criteria) this;
        }

        public Criteria andRemarkLessThan(String value) {
            addCriterion("remark <", value, "remark");
            return (Criteria) this;
        }

        public Criteria andRemarkLessThanOrEqualTo(String value) {
            addCriterion("remark <=", value, "remark");
            return (Criteria) this;
        }

        public Criteria andRemarkLike(String value) {
            addCriterion("remark like", value, "remark");
            return (Criteria) this;
        }

        public Criteria andRemarkNotLike(String value) {
            addCriterion("remark not like", value, "remark");
            return (Criteria) this;
        }

        public Criteria andRemarkIn(List<String> values) {
            addCriterion("remark in", values, "remark");
            return (Criteria) this;
        }

        public Criteria andRemarkNotIn(List<String> values) {
            addCriterion("remark not in", values, "remark");
            return (Criteria) this;
        }

        public Criteria andRemarkBetween(String value1, String value2) {
            addCriterion("remark between", value1, value2, "remark");
            return (Criteria) this;
        }

        public Criteria andRemarkNotBetween(String value1, String value2) {
            addCriterion("remark not between", value1, value2, "remark");
            return (Criteria) this;
        }

        public Criteria andDrIsNull() {
            addCriterion("dr is null");
            return (Criteria) this;
        }

        public Criteria andDrIsNotNull() {
            addCriterion("dr is not null");
            return (Criteria) this;
        }

        public Criteria andDrEqualTo(Integer value) {
            addCriterion("dr =", value, "dr");
            return (Criteria) this;
        }

        public Criteria andDrNotEqualTo(Integer value) {
            addCriterion("dr <>", value, "dr");
            return (Criteria) this;
        }

        public Criteria andDrGreaterThan(Integer value) {
            addCriterion("dr >", value, "dr");
            return (Criteria) this;
        }

        public Criteria andDrGreaterThanOrEqualTo(Integer value) {
            addCriterion("dr >=", value, "dr");
            return (Criteria) this;
        }

        public Criteria andDrLessThan(Integer value) {
            addCriterion("dr <", value, "dr");
            return (Criteria) this;
        }

        public Criteria andDrLessThanOrEqualTo(Integer value) {
            addCriterion("dr <=", value, "dr");
            return (Criteria) this;
        }

        public Criteria andDrIn(List<Integer> values) {
            addCriterion("dr in", values, "dr");
            return (Criteria) this;
        }

        public Criteria andDrNotIn(List<Integer> values) {
            addCriterion("dr not in", values, "dr");
            return (Criteria) this;
        }

        public Criteria andDrBetween(Integer value1, Integer value2) {
            addCriterion("dr between", value1, value2, "dr");
            return (Criteria) this;
        }

        public Criteria andDrNotBetween(Integer value1, Integer value2) {
            addCriterion("dr not between", value1, value2, "dr");
            return (Criteria) this;
        }
    }

    public static class Criteria extends GeneratedCriteria {

        protected Criteria() {
            super();
        }
    }

    public static class Criterion {
        private String condition;

        private Object value;

        private Object secondValue;

        private boolean noValue;

        private boolean singleValue;

        private boolean betweenValue;

        private boolean listValue;

        private String typeHandler;

        public String getCondition() {
            return condition;
        }

        public Object getValue() {
            return value;
        }

        public Object getSecondValue() {
            return secondValue;
        }

        public boolean isNoValue() {
            return noValue;
        }

        public boolean isSingleValue() {
            return singleValue;
        }

        public boolean isBetweenValue() {
            return betweenValue;
        }

        public boolean isListValue() {
            return listValue;
        }

        public String getTypeHandler() {
            return typeHandler;
        }

        protected Criterion(String condition) {
            super();
            this.condition = condition;
            this.typeHandler = null;
            this.noValue = true;
        }

        protected Criterion(String condition, Object value, String typeHandler) {
            super();
            this.condition = condition;
            this.value = value;
            this.typeHandler = typeHandler;
            if (value instanceof List<?>) {
                this.listValue = true;
            } else {
                this.singleValue = true;
            }
        }

        protected Criterion(String condition, Object value) {
            this(condition, value, null);
        }

        protected Criterion(String condition, Object value, Object secondValue, String typeHandler) {
            super();
            this.condition = condition;
            this.value = value;
            this.secondValue = secondValue;
            this.typeHandler = typeHandler;
            this.betweenValue = true;
        }

        protected Criterion(String condition, Object value, Object secondValue) {
            this(condition, value, secondValue, null);
        }
    }
}
