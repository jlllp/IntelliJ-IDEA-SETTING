package com.mrk.finance.query;
import com.mrk.common.utils.text.CheckUtil;

/**
 * @author 自动生成工具
 * @date   2022/06/02 
 */
public class FncBillManagementQuery {
	private String updateuserNotLike;
	private java.util.List updateuserNotIn;
	private String updateuserNotEqualTo;
	private String updateuserLike;
	private String updateuserLessThanOrEqualTo;
	private String updateuserLessThan;
	private Boolean updateuserIsNull;
	private Boolean updateuserIsNotNull;
	private java.util.List updateuserIn;
	private String updateuserGreaterThanOrEqualTo;
	private String updateuserGreaterThan;
	private String updateuserEqualTo;
	private java.util.List updatetimeNotIn;
	private java.util.Date updatetimeNotEqualTo;
	private java.util.Date updatetimeLessThanOrEqualTo;
	private java.util.Date updatetimeLessThan;
	private Boolean updatetimeIsNull;
	private Boolean updatetimeIsNotNull;
	private java.util.List updatetimeIn;
	private java.util.Date updatetimeGreaterThanOrEqualTo;
	private java.util.Date updatetimeGreaterThan;
	private java.util.Date updatetimeEqualTo;
	private String remarkNotLike;
	private java.util.List remarkNotIn;
	private String remarkNotEqualTo;
	private String remarkLike;
	private String remarkLessThanOrEqualTo;
	private String remarkLessThan;
	private Boolean remarkIsNull;
	private Boolean remarkIsNotNull;
	private java.util.List remarkIn;
	private String remarkGreaterThanOrEqualTo;
	private String remarkGreaterThan;
	private String remarkEqualTo;
	private java.util.List fbmUnpayAmountNotIn;
	private Double fbmUnpayAmountNotEqualTo;
	private Double fbmUnpayAmountLessThanOrEqualTo;
	private Double fbmUnpayAmountLessThan;
	private Boolean fbmUnpayAmountIsNull;
	private Boolean fbmUnpayAmountIsNotNull;
	private java.util.List fbmUnpayAmountIn;
	private Double fbmUnpayAmountGreaterThanOrEqualTo;
	private Double fbmUnpayAmountGreaterThan;
	private Double fbmUnpayAmountEqualTo;
	private java.util.List fbmUnRefundAmountNotIn;
	private Double fbmUnRefundAmountNotEqualTo;
	private Double fbmUnRefundAmountLessThanOrEqualTo;
	private Double fbmUnRefundAmountLessThan;
	private Boolean fbmUnRefundAmountIsNull;
	private Boolean fbmUnRefundAmountIsNotNull;
	private java.util.List fbmUnRefundAmountIn;
	private Double fbmUnRefundAmountGreaterThanOrEqualTo;
	private Double fbmUnRefundAmountGreaterThan;
	private Double fbmUnRefundAmountEqualTo;
	private java.util.List fbmTurnerDealNotIn;
	private Integer fbmTurnerDealNotEqualTo;
	private Integer fbmTurnerDealLessThanOrEqualTo;
	private Integer fbmTurnerDealLessThan;
	private Boolean fbmTurnerDealIsNull;
	private Boolean fbmTurnerDealIsNotNull;
	private java.util.List fbmTurnerDealIn;
	private Integer fbmTurnerDealGreaterThanOrEqualTo;
	private Integer fbmTurnerDealGreaterThan;
	private Integer fbmTurnerDealEqualTo;
	private java.util.List fbmSubjectsNotIn;
	private Integer fbmSubjectsNotEqualTo;
	private Integer fbmSubjectsLessThanOrEqualTo;
	private Integer fbmSubjectsLessThan;
	private Boolean fbmSubjectsIsNull;
	private Boolean fbmSubjectsIsNotNull;
	private java.util.List fbmSubjectsIn;
	private Integer fbmSubjectsGreaterThanOrEqualTo;
	private Integer fbmSubjectsGreaterThan;
	private Integer fbmSubjectsEqualTo;
	private java.util.List fbmRefundAmountNotIn;
	private Double fbmRefundAmountNotEqualTo;
	private Double fbmRefundAmountLessThanOrEqualTo;
	private Double fbmRefundAmountLessThan;
	private Boolean fbmRefundAmountIsNull;
	private Boolean fbmRefundAmountIsNotNull;
	private java.util.List fbmRefundAmountIn;
	private Double fbmRefundAmountGreaterThanOrEqualTo;
	private Double fbmRefundAmountGreaterThan;
	private Double fbmRefundAmountEqualTo;
	private java.util.List fbmPayTimeNotIn;
	private java.util.Date fbmPayTimeNotEqualTo;
	private java.util.Date fbmPayTimeLessThanOrEqualTo;
	private java.util.Date fbmPayTimeLessThan;
	private Boolean fbmPayTimeIsNull;
	private Boolean fbmPayTimeIsNotNull;
	private java.util.List fbmPayTimeIn;
	private java.util.Date fbmPayTimeGreaterThanOrEqualTo;
	private java.util.Date fbmPayTimeGreaterThan;
	private java.util.Date fbmPayTimeEqualTo;
	private java.util.List fbmPayAmonutNotIn;
	private Double fbmPayAmonutNotEqualTo;
	private Double fbmPayAmonutLessThanOrEqualTo;
	private Double fbmPayAmonutLessThan;
	private Boolean fbmPayAmonutIsNull;
	private Boolean fbmPayAmonutIsNotNull;
	private java.util.List fbmPayAmonutIn;
	private Double fbmPayAmonutGreaterThanOrEqualTo;
	private Double fbmPayAmonutGreaterThan;
	private Double fbmPayAmonutEqualTo;
	private java.util.List fbmOverdueStateNotIn;
	private Integer fbmOverdueStateNotEqualTo;
	private Integer fbmOverdueStateLessThanOrEqualTo;
	private Integer fbmOverdueStateLessThan;
	private Boolean fbmOverdueStateIsNull;
	private Boolean fbmOverdueStateIsNotNull;
	private java.util.List fbmOverdueStateIn;
	private Integer fbmOverdueStateGreaterThanOrEqualTo;
	private Integer fbmOverdueStateGreaterThan;
	private Integer fbmOverdueStateEqualTo;
	private String fbmNperNotLike;
	private java.util.List fbmNperNotIn;
	private String fbmNperNotEqualTo;
	private String fbmNperLike;
	private String fbmNperLessThanOrEqualTo;
	private String fbmNperLessThan;
	private Boolean fbmNperIsNull;
	private Boolean fbmNperIsNotNull;
	private java.util.List fbmNperIn;
	private String fbmNperGreaterThanOrEqualTo;
	private String fbmNperGreaterThan;
	private String fbmNperEqualTo;
	private java.util.List fbmNotMatchAmountNotIn;
	private Double fbmNotMatchAmountNotEqualTo;
	private Double fbmNotMatchAmountLessThanOrEqualTo;
	private Double fbmNotMatchAmountLessThan;
	private Boolean fbmNotMatchAmountIsNull;
	private Boolean fbmNotMatchAmountIsNotNull;
	private java.util.List fbmNotMatchAmountIn;
	private Double fbmNotMatchAmountGreaterThanOrEqualTo;
	private Double fbmNotMatchAmountGreaterThan;
	private Double fbmNotMatchAmountEqualTo;
	private java.util.List fbmMatchedAmountNotIn;
	private Double fbmMatchedAmountNotEqualTo;
	private Double fbmMatchedAmountLessThanOrEqualTo;
	private Double fbmMatchedAmountLessThan;
	private Boolean fbmMatchedAmountIsNull;
	private Boolean fbmMatchedAmountIsNotNull;
	private java.util.List fbmMatchedAmountIn;
	private Double fbmMatchedAmountGreaterThanOrEqualTo;
	private Double fbmMatchedAmountGreaterThan;
	private Double fbmMatchedAmountEqualTo;
	private java.util.List fbmMatchWayNotIn;
	private Integer fbmMatchWayNotEqualTo;
	private Integer fbmMatchWayLessThanOrEqualTo;
	private Integer fbmMatchWayLessThan;
	private Boolean fbmMatchWayIsNull;
	private Boolean fbmMatchWayIsNotNull;
	private java.util.List fbmMatchWayIn;
	private Integer fbmMatchWayGreaterThanOrEqualTo;
	private Integer fbmMatchWayGreaterThan;
	private Integer fbmMatchWayEqualTo;
	private java.util.List fbmMatchUserIdNotIn;
	private Long fbmMatchUserIdNotEqualTo;
	private Long fbmMatchUserIdLessThanOrEqualTo;
	private Long fbmMatchUserIdLessThan;
	private Boolean fbmMatchUserIdIsNull;
	private Boolean fbmMatchUserIdIsNotNull;
	private java.util.List fbmMatchUserIdIn;
	private Long fbmMatchUserIdGreaterThanOrEqualTo;
	private Long fbmMatchUserIdGreaterThan;
	private Long fbmMatchUserIdEqualTo;
	private String fbmMatchTypeNotLike;
	private java.util.List fbmMatchTypeNotIn;
	private String fbmMatchTypeNotEqualTo;
	private String fbmMatchTypeLike;
	private String fbmMatchTypeLessThanOrEqualTo;
	private String fbmMatchTypeLessThan;
	private Boolean fbmMatchTypeIsNull;
	private Boolean fbmMatchTypeIsNotNull;
	private java.util.List fbmMatchTypeIn;
	private String fbmMatchTypeGreaterThanOrEqualTo;
	private String fbmMatchTypeGreaterThan;
	private String fbmMatchTypeEqualTo;
	private java.util.List fbmMatchTimeNotIn;
	private java.util.Date fbmMatchTimeNotEqualTo;
	private java.util.Date fbmMatchTimeLessThanOrEqualTo;
	private java.util.Date fbmMatchTimeLessThan;
	private Boolean fbmMatchTimeIsNull;
	private Boolean fbmMatchTimeIsNotNull;
	private java.util.List fbmMatchTimeIn;
	private java.util.Date fbmMatchTimeGreaterThanOrEqualTo;
	private java.util.Date fbmMatchTimeGreaterThan;
	private java.util.Date fbmMatchTimeEqualTo;
	private String fbmMatchSerialNumberNotLike;
	private java.util.List fbmMatchSerialNumberNotIn;
	private String fbmMatchSerialNumberNotEqualTo;
	private String fbmMatchSerialNumberLike;
	private String fbmMatchSerialNumberLessThanOrEqualTo;
	private String fbmMatchSerialNumberLessThan;
	private Boolean fbmMatchSerialNumberIsNull;
	private Boolean fbmMatchSerialNumberIsNotNull;
	private java.util.List fbmMatchSerialNumberIn;
	private String fbmMatchSerialNumberGreaterThanOrEqualTo;
	private String fbmMatchSerialNumberGreaterThan;
	private String fbmMatchSerialNumberEqualTo;
	private String fbmMatchPhoneNotLike;
	private java.util.List fbmMatchPhoneNotIn;
	private String fbmMatchPhoneNotEqualTo;
	private String fbmMatchPhoneLike;
	private String fbmMatchPhoneLessThanOrEqualTo;
	private String fbmMatchPhoneLessThan;
	private Boolean fbmMatchPhoneIsNull;
	private Boolean fbmMatchPhoneIsNotNull;
	private java.util.List fbmMatchPhoneIn;
	private String fbmMatchPhoneGreaterThanOrEqualTo;
	private String fbmMatchPhoneGreaterThan;
	private String fbmMatchPhoneEqualTo;
	private java.util.List fbmLeasePeriodNotIn;
	private java.util.Date fbmLeasePeriodNotEqualTo;
	private java.util.Date fbmLeasePeriodLessThanOrEqualTo;
	private java.util.Date fbmLeasePeriodLessThan;
	private Boolean fbmLeasePeriodIsNull;
	private Boolean fbmLeasePeriodIsNotNull;
	private java.util.List fbmLeasePeriodIn;
	private java.util.Date fbmLeasePeriodGreaterThanOrEqualTo;
	private java.util.Date fbmLeasePeriodGreaterThan;
	private java.util.Date fbmLeasePeriodEqualTo;
	private java.util.List fbmIdNotIn;
	private Long fbmIdNotEqualTo;
	private Long fbmIdLessThanOrEqualTo;
	private Long fbmIdLessThan;
	private Boolean fbmIdIsNull;
	private Boolean fbmIdIsNotNull;
	private java.util.List fbmIdIn;
	private Long fbmIdGreaterThanOrEqualTo;
	private Long fbmIdGreaterThan;
	private Long fbmIdEqualTo;
	private java.util.List fbmContractIdNotIn;
	private Long fbmContractIdNotEqualTo;
	private Long fbmContractIdLessThanOrEqualTo;
	private Long fbmContractIdLessThan;
	private Boolean fbmContractIdIsNull;
	private Boolean fbmContractIdIsNotNull;
	private java.util.List fbmContractIdIn;
	private Long fbmContractIdGreaterThanOrEqualTo;
	private Long fbmContractIdGreaterThan;
	private Long fbmContractIdEqualTo;
	private java.util.List fbmCityIdNotIn;
	private Long fbmCityIdNotEqualTo;
	private Long fbmCityIdLessThanOrEqualTo;
	private Long fbmCityIdLessThan;
	private Boolean fbmCityIdIsNull;
	private Boolean fbmCityIdIsNotNull;
	private java.util.List fbmCityIdIn;
	private Long fbmCityIdGreaterThanOrEqualTo;
	private Long fbmCityIdGreaterThan;
	private Long fbmCityIdEqualTo;
	private java.util.List fbmCarIdNotIn;
	private Long fbmCarIdNotEqualTo;
	private Long fbmCarIdLessThanOrEqualTo;
	private Long fbmCarIdLessThan;
	private Boolean fbmCarIdIsNull;
	private Boolean fbmCarIdIsNotNull;
	private java.util.List fbmCarIdIn;
	private Long fbmCarIdGreaterThanOrEqualTo;
	private Long fbmCarIdGreaterThan;
	private Long fbmCarIdEqualTo;
	private java.util.List fbmBreaksTypeNotIn;
	private Integer fbmBreaksTypeNotEqualTo;
	private Integer fbmBreaksTypeLessThanOrEqualTo;
	private Integer fbmBreaksTypeLessThan;
	private Boolean fbmBreaksTypeIsNull;
	private Boolean fbmBreaksTypeIsNotNull;
	private java.util.List fbmBreaksTypeIn;
	private Integer fbmBreaksTypeGreaterThanOrEqualTo;
	private Integer fbmBreaksTypeGreaterThan;
	private Integer fbmBreaksTypeEqualTo;
	private java.util.List fbmBreaksTimeNotIn;
	private java.util.Date fbmBreaksTimeNotEqualTo;
	private java.util.Date fbmBreaksTimeLessThanOrEqualTo;
	private java.util.Date fbmBreaksTimeLessThan;
	private Boolean fbmBreaksTimeIsNull;
	private Boolean fbmBreaksTimeIsNotNull;
	private java.util.List fbmBreaksTimeIn;
	private java.util.Date fbmBreaksTimeGreaterThanOrEqualTo;
	private java.util.Date fbmBreaksTimeGreaterThan;
	private java.util.Date fbmBreaksTimeEqualTo;
	private String fbmBreaksRemarkNotLike;
	private java.util.List fbmBreaksRemarkNotIn;
	private String fbmBreaksRemarkNotEqualTo;
	private String fbmBreaksRemarkLike;
	private String fbmBreaksRemarkLessThanOrEqualTo;
	private String fbmBreaksRemarkLessThan;
	private Boolean fbmBreaksRemarkIsNull;
	private Boolean fbmBreaksRemarkIsNotNull;
	private java.util.List fbmBreaksRemarkIn;
	private String fbmBreaksRemarkGreaterThanOrEqualTo;
	private String fbmBreaksRemarkGreaterThan;
	private String fbmBreaksRemarkEqualTo;
	private String fbmBreaksPhoneNotLike;
	private java.util.List fbmBreaksPhoneNotIn;
	private String fbmBreaksPhoneNotEqualTo;
	private String fbmBreaksPhoneLike;
	private String fbmBreaksPhoneLessThanOrEqualTo;
	private String fbmBreaksPhoneLessThan;
	private Boolean fbmBreaksPhoneIsNull;
	private Boolean fbmBreaksPhoneIsNotNull;
	private java.util.List fbmBreaksPhoneIn;
	private String fbmBreaksPhoneGreaterThanOrEqualTo;
	private String fbmBreaksPhoneGreaterThan;
	private String fbmBreaksPhoneEqualTo;
	private java.util.List fbmBreaksAmountNotIn;
	private Double fbmBreaksAmountNotEqualTo;
	private Double fbmBreaksAmountLessThanOrEqualTo;
	private Double fbmBreaksAmountLessThan;
	private Boolean fbmBreaksAmountIsNull;
	private Boolean fbmBreaksAmountIsNotNull;
	private java.util.List fbmBreaksAmountIn;
	private Double fbmBreaksAmountGreaterThanOrEqualTo;
	private Double fbmBreaksAmountGreaterThan;
	private Double fbmBreaksAmountEqualTo;
	private java.util.List fbmBreaksAfterAmountNotIn;
	private Double fbmBreaksAfterAmountNotEqualTo;
	private Double fbmBreaksAfterAmountLessThanOrEqualTo;
	private Double fbmBreaksAfterAmountLessThan;
	private Boolean fbmBreaksAfterAmountIsNull;
	private Boolean fbmBreaksAfterAmountIsNotNull;
	private java.util.List fbmBreaksAfterAmountIn;
	private Double fbmBreaksAfterAmountGreaterThanOrEqualTo;
	private Double fbmBreaksAfterAmountGreaterThan;
	private Double fbmBreaksAfterAmountEqualTo;
	private String fbmBillVoucherNotLike;
	private java.util.List fbmBillVoucherNotIn;
	private String fbmBillVoucherNotEqualTo;
	private String fbmBillVoucherLike;
	private String fbmBillVoucherLessThanOrEqualTo;
	private String fbmBillVoucherLessThan;
	private Boolean fbmBillVoucherIsNull;
	private Boolean fbmBillVoucherIsNotNull;
	private java.util.List fbmBillVoucherIn;
	private String fbmBillVoucherGreaterThanOrEqualTo;
	private String fbmBillVoucherGreaterThan;
	private String fbmBillVoucherEqualTo;
	private java.util.List fbmBillStateNotIn;
	private Integer fbmBillStateNotEqualTo;
	private Integer fbmBillStateLessThanOrEqualTo;
	private Integer fbmBillStateLessThan;
	private Boolean fbmBillStateIsNull;
	private Boolean fbmBillStateIsNotNull;
	private java.util.List fbmBillStateIn;
	private Integer fbmBillStateGreaterThanOrEqualTo;
	private Integer fbmBillStateGreaterThan;
	private Integer fbmBillStateEqualTo;
	private java.util.List fbmBillGenerateWayNotIn;
	private Integer fbmBillGenerateWayNotEqualTo;
	private Integer fbmBillGenerateWayLessThanOrEqualTo;
	private Integer fbmBillGenerateWayLessThan;
	private Boolean fbmBillGenerateWayIsNull;
	private Boolean fbmBillGenerateWayIsNotNull;
	private java.util.List fbmBillGenerateWayIn;
	private Integer fbmBillGenerateWayGreaterThanOrEqualTo;
	private Integer fbmBillGenerateWayGreaterThan;
	private Integer fbmBillGenerateWayEqualTo;
	private java.util.List fbmBillGenerateTimeNotIn;
	private java.util.Date fbmBillGenerateTimeNotEqualTo;
	private java.util.Date fbmBillGenerateTimeLessThanOrEqualTo;
	private java.util.Date fbmBillGenerateTimeLessThan;
	private Boolean fbmBillGenerateTimeIsNull;
	private Boolean fbmBillGenerateTimeIsNotNull;
	private java.util.List fbmBillGenerateTimeIn;
	private java.util.Date fbmBillGenerateTimeGreaterThanOrEqualTo;
	private java.util.Date fbmBillGenerateTimeGreaterThan;
	private java.util.Date fbmBillGenerateTimeEqualTo;
	private String fbmBillGenerateReasonNotLike;
	private java.util.List fbmBillGenerateReasonNotIn;
	private String fbmBillGenerateReasonNotEqualTo;
	private String fbmBillGenerateReasonLike;
	private String fbmBillGenerateReasonLessThanOrEqualTo;
	private String fbmBillGenerateReasonLessThan;
	private Boolean fbmBillGenerateReasonIsNull;
	private Boolean fbmBillGenerateReasonIsNotNull;
	private java.util.List fbmBillGenerateReasonIn;
	private String fbmBillGenerateReasonGreaterThanOrEqualTo;
	private String fbmBillGenerateReasonGreaterThan;
	private String fbmBillGenerateReasonEqualTo;
	private java.util.List fbmBillCatoffTimeNotIn;
	private java.util.Date fbmBillCatoffTimeNotEqualTo;
	private java.util.Date fbmBillCatoffTimeLessThanOrEqualTo;
	private java.util.Date fbmBillCatoffTimeLessThan;
	private Boolean fbmBillCatoffTimeIsNull;
	private Boolean fbmBillCatoffTimeIsNotNull;
	private java.util.List fbmBillCatoffTimeIn;
	private java.util.Date fbmBillCatoffTimeGreaterThanOrEqualTo;
	private java.util.Date fbmBillCatoffTimeGreaterThan;
	private java.util.Date fbmBillCatoffTimeEqualTo;
	private java.util.List fbmBillAmountNotIn;
	private Double fbmBillAmountNotEqualTo;
	private Double fbmBillAmountLessThanOrEqualTo;
	private Double fbmBillAmountLessThan;
	private Boolean fbmBillAmountIsNull;
	private Boolean fbmBillAmountIsNotNull;
	private java.util.List fbmBillAmountIn;
	private Double fbmBillAmountGreaterThanOrEqualTo;
	private Double fbmBillAmountGreaterThan;
	private Double fbmBillAmountEqualTo;
	private java.util.List fbmAssociateContractIdNotIn;
	private Long fbmAssociateContractIdNotEqualTo;
	private Long fbmAssociateContractIdLessThanOrEqualTo;
	private Long fbmAssociateContractIdLessThan;
	private Boolean fbmAssociateContractIdIsNull;
	private Boolean fbmAssociateContractIdIsNotNull;
	private java.util.List fbmAssociateContractIdIn;
	private Long fbmAssociateContractIdGreaterThanOrEqualTo;
	private Long fbmAssociateContractIdGreaterThan;
	private Long fbmAssociateContractIdEqualTo;
	private java.util.List fbmAssociateCarIdNotIn;
	private Long fbmAssociateCarIdNotEqualTo;
	private Long fbmAssociateCarIdLessThanOrEqualTo;
	private Long fbmAssociateCarIdLessThan;
	private Boolean fbmAssociateCarIdIsNull;
	private Boolean fbmAssociateCarIdIsNotNull;
	private java.util.List fbmAssociateCarIdIn;
	private Long fbmAssociateCarIdGreaterThanOrEqualTo;
	private Long fbmAssociateCarIdGreaterThan;
	private Long fbmAssociateCarIdEqualTo;
	private java.util.List fbmAlreadyRefundAmountNotIn;
	private Double fbmAlreadyRefundAmountNotEqualTo;
	private Double fbmAlreadyRefundAmountLessThanOrEqualTo;
	private Double fbmAlreadyRefundAmountLessThan;
	private Boolean fbmAlreadyRefundAmountIsNull;
	private Boolean fbmAlreadyRefundAmountIsNotNull;
	private java.util.List fbmAlreadyRefundAmountIn;
	private Double fbmAlreadyRefundAmountGreaterThanOrEqualTo;
	private Double fbmAlreadyRefundAmountGreaterThan;
	private Double fbmAlreadyRefundAmountEqualTo;
	private java.util.List drNotIn;
	private Integer drNotEqualTo;
	private Integer drLessThanOrEqualTo;
	private Integer drLessThan;
	private Boolean drIsNull;
	private Boolean drIsNotNull;
	private java.util.List drIn;
	private Integer drGreaterThanOrEqualTo;
	private Integer drGreaterThan;
	private Integer drEqualTo;
	private String createuserNotLike;
	private java.util.List createuserNotIn;
	private String createuserNotEqualTo;
	private String createuserLike;
	private String createuserLessThanOrEqualTo;
	private String createuserLessThan;
	private Boolean createuserIsNull;
	private Boolean createuserIsNotNull;
	private java.util.List createuserIn;
	private String createuserGreaterThanOrEqualTo;
	private String createuserGreaterThan;
	private String createuserEqualTo;
	private java.util.List createtimeNotIn;
	private java.util.Date createtimeNotEqualTo;
	private java.util.Date createtimeLessThanOrEqualTo;
	private java.util.Date createtimeLessThan;
	private Boolean createtimeIsNull;
	private Boolean createtimeIsNotNull;
	private java.util.List createtimeIn;
	private java.util.Date createtimeGreaterThanOrEqualTo;
	private java.util.Date createtimeGreaterThan;
	private java.util.Date createtimeEqualTo;
	private String sidx;
	private String sord;
	public String getSidx(){
		if(this.sidx == null){
			return "";
		}
		else if("updateuser".equals(this.sidx)){
			return "updateuser";
		}
		else if("updatetime".equals(this.sidx)){
			return "updatetime";
		}
		else if("remark".equals(this.sidx)){
			return "remark";
		}
		else if("fbmUnpayAmount".equals(this.sidx)){
			return "fbm_unpay_amount";
		}
		else if("fbmUnRefundAmount".equals(this.sidx)){
			return "fbm_un_refund_amount";
		}
		else if("fbmTurnerDeal".equals(this.sidx)){
			return "fbm_turner_deal";
		}
		else if("fbmSubjects".equals(this.sidx)){
			return "fbm_subjects";
		}
		else if("fbmRefundAmount".equals(this.sidx)){
			return "fbm_refund_amount";
		}
		else if("fbmPayTime".equals(this.sidx)){
			return "fbm_pay_time";
		}
		else if("fbmPayAmonut".equals(this.sidx)){
			return "fbm_pay_amonut";
		}
		else if("fbmOverdueState".equals(this.sidx)){
			return "fbm_overdue_state";
		}
		else if("fbmNper".equals(this.sidx)){
			return "fbm_nper";
		}
		else if("fbmMatchAmountNot".equals(this.sidx)){
			return "fbm_match_amount_not";
		}
		else if("fbmMatchAmount".equals(this.sidx)){
			return "fbm_match_amount";
		}
		else if("fbmMatchedAmount".equals(this.sidx)){
			return "fbm_matched_amount";
		}
		else if("fbmMatchWay".equals(this.sidx)){
			return "fbm_match_way";
		}
		else if("fbmMatchUserId".equals(this.sidx)){
			return "fbm_match_user_id";
		}
		else if("fbmMatchType".equals(this.sidx)){
			return "fbm_match_type";
		}
		else if("fbmMatchTime".equals(this.sidx)){
			return "fbm_match_time";
		}
		else if("fbmMatchSerialNumber".equals(this.sidx)){
			return "fbm_match_serial_number";
		}
		else if("fbmMatchPhone".equals(this.sidx)){
			return "fbm_match_phone";
		}
		else if("fbmLeasePeriod".equals(this.sidx)){
			return "fbm_lease_period";
		}
		else if("fbmId".equals(this.sidx)){
			return "fbm_id";
		}
		else if("fbmContractId".equals(this.sidx)){
			return "fbm_contract_id";
		}
		else if("fbmCityId".equals(this.sidx)){
			return "fbm_city_id";
		}
		else if("fbmCarId".equals(this.sidx)){
			return "fbm_car_id";
		}
		else if("fbmBreaksType".equals(this.sidx)){
			return "fbm_breaks_type";
		}
		else if("fbmBreaksTime".equals(this.sidx)){
			return "fbm_breaks_time";
		}
		else if("fbmBreaksRemark".equals(this.sidx)){
			return "fbm_breaks_remark";
		}
		else if("fbmBreaksPhone".equals(this.sidx)){
			return "fbm_breaks_phone";
		}
		else if("fbmBreaksAmount".equals(this.sidx)){
			return "fbm_breaks_amount";
		}
		else if("fbmBreaksAfterAmount".equals(this.sidx)){
			return "fbm_breaks_after_amount";
		}
		else if("fbmBillVoucher".equals(this.sidx)){
			return "fbm_bill_voucher";
		}
		else if("fbmBillState".equals(this.sidx)){
			return "fbm_bill_state";
		}
		else if("fbmBillGenerateWay".equals(this.sidx)){
			return "fbm_bill_generate_way";
		}
		else if("fbmBillGenerateTime".equals(this.sidx)){
			return "fbm_bill_generate_time";
		}
		else if("fbmBillGenerateReason".equals(this.sidx)){
			return "fbm_bill_generate_reason";
		}
		else if("fbmBillCatoffTime".equals(this.sidx)){
			return "fbm_bill_catoff_time";
		}
		else if("fbmBillAmount".equals(this.sidx)){
			return "fbm_bill_amount";
		}
		else if("fbmAssociateContractId".equals(this.sidx)){
			return "fbm_associate_contract_id";
		}
		else if("fbmAssociateCarId".equals(this.sidx)){
			return "fbm_associate_car_id";
		}
		else if("fbmAlreadyRefundAmount".equals(this.sidx)){
			return "fbm_already_refund_amount";
		}
		else if("dr".equals(this.sidx)){
			return "dr";
		}
		else if("createuser".equals(this.sidx)){
			return "createuser";
		}
		else if("createtime".equals(this.sidx)){
			return "createtime";
		}
		return this.sidx;
	}

	@com.fasterxml.jackson.annotation.JsonIgnore
	public com.mrk.finance.example.FncBillManagementExample getCrieria(){
		com.mrk.finance.example.FncBillManagementExample q = new com.mrk.finance.example.FncBillManagementExample();
		com.mrk.finance.example.FncBillManagementExample.Criteria c = q.createCriteria();
		c.andDrEqualTo(0);
		if(CheckUtil.isNotEmpty(getUpdateuserNotLike())){
			c.andUpdateuserNotLike("%"+this.getUpdateuserNotLike()+"%");
		}
		if(CheckUtil.isNotEmpty(getUpdateuserNotIn())){
			c.andUpdateuserNotIn(this.getUpdateuserNotIn());
		}
		if(CheckUtil.isNotEmpty(getUpdateuserNotEqualTo())){
			c.andUpdateuserNotEqualTo(this.getUpdateuserNotEqualTo());
		}
		if(CheckUtil.isNotEmpty(getUpdateuserLike())){
			c.andUpdateuserLike("%"+this.getUpdateuserLike()+"%");
		}
		if(CheckUtil.isNotEmpty(getUpdateuserLessThanOrEqualTo())){
			c.andUpdateuserLessThanOrEqualTo(this.getUpdateuserLessThanOrEqualTo());
		}
		if(CheckUtil.isNotEmpty(getUpdateuserLessThan())){
			c.andUpdateuserLessThan(this.getUpdateuserLessThan());
		}
		if(CheckUtil.isNotEmpty(getUpdateuserIsNull()) && this.getUpdateuserIsNull()){
			c.andUpdateuserIsNull();
		}
		if(CheckUtil.isNotEmpty(getUpdateuserIsNotNull()) && this.getUpdateuserIsNotNull()){
			c.andUpdateuserIsNotNull();
		}
		if(CheckUtil.isNotEmpty(getUpdateuserIn())){
			c.andUpdateuserIn(this.getUpdateuserIn());
		}
		if(CheckUtil.isNotEmpty(getUpdateuserGreaterThanOrEqualTo())){
			c.andUpdateuserGreaterThanOrEqualTo(this.getUpdateuserGreaterThanOrEqualTo());
		}
		if(CheckUtil.isNotEmpty(getUpdateuserGreaterThan())){
			c.andUpdateuserGreaterThan(this.getUpdateuserGreaterThan());
		}
		if(CheckUtil.isNotEmpty(getUpdateuserEqualTo())){
			c.andUpdateuserEqualTo(this.getUpdateuserEqualTo());
		}
		if(CheckUtil.isNotEmpty(getUpdatetimeNotIn())){
			c.andUpdatetimeNotIn(this.getUpdatetimeNotIn());
		}
		if(CheckUtil.isNotEmpty(getUpdatetimeNotEqualTo())){
			c.andUpdatetimeNotEqualTo(this.getUpdatetimeNotEqualTo());
		}
		if(CheckUtil.isNotEmpty(getUpdatetimeLessThanOrEqualTo())){
			c.andUpdatetimeLessThanOrEqualTo(this.getUpdatetimeLessThanOrEqualTo());
		}
		if(CheckUtil.isNotEmpty(getUpdatetimeLessThan())){
			c.andUpdatetimeLessThan(this.getUpdatetimeLessThan());
		}
		if(CheckUtil.isNotEmpty(getUpdatetimeIsNull()) && this.getUpdatetimeIsNull()){
			c.andUpdatetimeIsNull();
		}
		if(CheckUtil.isNotEmpty(getUpdatetimeIsNotNull()) && this.getUpdatetimeIsNotNull()){
			c.andUpdatetimeIsNotNull();
		}
		if(CheckUtil.isNotEmpty(getUpdatetimeIn())){
			c.andUpdatetimeIn(this.getUpdatetimeIn());
		}
		if(CheckUtil.isNotEmpty(getUpdatetimeGreaterThanOrEqualTo())){
			c.andUpdatetimeGreaterThanOrEqualTo(this.getUpdatetimeGreaterThanOrEqualTo());
		}
		if(CheckUtil.isNotEmpty(getUpdatetimeGreaterThan())){
			c.andUpdatetimeGreaterThan(this.getUpdatetimeGreaterThan());
		}
		if(CheckUtil.isNotEmpty(getUpdatetimeEqualTo())){
			c.andUpdatetimeEqualTo(this.getUpdatetimeEqualTo());
		}
		if(CheckUtil.isNotEmpty(getRemarkNotLike())){
			c.andRemarkNotLike("%"+this.getRemarkNotLike()+"%");
		}
		if(CheckUtil.isNotEmpty(getRemarkNotIn())){
			c.andRemarkNotIn(this.getRemarkNotIn());
		}
		if(CheckUtil.isNotEmpty(getRemarkNotEqualTo())){
			c.andRemarkNotEqualTo(this.getRemarkNotEqualTo());
		}
		if(CheckUtil.isNotEmpty(getRemarkLike())){
			c.andRemarkLike("%"+this.getRemarkLike()+"%");
		}
		if(CheckUtil.isNotEmpty(getRemarkLessThanOrEqualTo())){
			c.andRemarkLessThanOrEqualTo(this.getRemarkLessThanOrEqualTo());
		}
		if(CheckUtil.isNotEmpty(getRemarkLessThan())){
			c.andRemarkLessThan(this.getRemarkLessThan());
		}
		if(CheckUtil.isNotEmpty(getRemarkIsNull()) && this.getRemarkIsNull()){
			c.andRemarkIsNull();
		}
		if(CheckUtil.isNotEmpty(getRemarkIsNotNull()) && this.getRemarkIsNotNull()){
			c.andRemarkIsNotNull();
		}
		if(CheckUtil.isNotEmpty(getRemarkIn())){
			c.andRemarkIn(this.getRemarkIn());
		}
		if(CheckUtil.isNotEmpty(getRemarkGreaterThanOrEqualTo())){
			c.andRemarkGreaterThanOrEqualTo(this.getRemarkGreaterThanOrEqualTo());
		}
		if(CheckUtil.isNotEmpty(getRemarkGreaterThan())){
			c.andRemarkGreaterThan(this.getRemarkGreaterThan());
		}
		if(CheckUtil.isNotEmpty(getRemarkEqualTo())){
			c.andRemarkEqualTo(this.getRemarkEqualTo());
		}
		if(CheckUtil.isNotEmpty(getFbmUnpayAmountNotIn())){
			c.andFbmUnpayAmountNotIn(this.getFbmUnpayAmountNotIn());
		}
		if(CheckUtil.isNotEmpty(getFbmUnpayAmountNotEqualTo())){
			c.andFbmUnpayAmountNotEqualTo(this.getFbmUnpayAmountNotEqualTo());
		}
		if(CheckUtil.isNotEmpty(getFbmUnpayAmountLessThanOrEqualTo())){
			c.andFbmUnpayAmountLessThanOrEqualTo(this.getFbmUnpayAmountLessThanOrEqualTo());
		}
		if(CheckUtil.isNotEmpty(getFbmUnpayAmountLessThan())){
			c.andFbmUnpayAmountLessThan(this.getFbmUnpayAmountLessThan());
		}
		if(CheckUtil.isNotEmpty(getFbmUnpayAmountIsNull()) && this.getFbmUnpayAmountIsNull()){
			c.andFbmUnpayAmountIsNull();
		}
		if(CheckUtil.isNotEmpty(getFbmUnpayAmountIsNotNull()) && this.getFbmUnpayAmountIsNotNull()){
			c.andFbmUnpayAmountIsNotNull();
		}
		if(CheckUtil.isNotEmpty(getFbmUnpayAmountIn())){
			c.andFbmUnpayAmountIn(this.getFbmUnpayAmountIn());
		}
		if(CheckUtil.isNotEmpty(getFbmUnpayAmountGreaterThanOrEqualTo())){
			c.andFbmUnpayAmountGreaterThanOrEqualTo(this.getFbmUnpayAmountGreaterThanOrEqualTo());
		}
		if(CheckUtil.isNotEmpty(getFbmUnpayAmountGreaterThan())){
			c.andFbmUnpayAmountGreaterThan(this.getFbmUnpayAmountGreaterThan());
		}
		if(CheckUtil.isNotEmpty(getFbmUnpayAmountEqualTo())){
			c.andFbmUnpayAmountEqualTo(this.getFbmUnpayAmountEqualTo());
		}
		if(CheckUtil.isNotEmpty(getFbmUnRefundAmountNotIn())){
			c.andFbmUnRefundAmountNotIn(this.getFbmUnRefundAmountNotIn());
		}
		if(CheckUtil.isNotEmpty(getFbmUnRefundAmountNotEqualTo())){
			c.andFbmUnRefundAmountNotEqualTo(this.getFbmUnRefundAmountNotEqualTo());
		}
		if(CheckUtil.isNotEmpty(getFbmUnRefundAmountLessThanOrEqualTo())){
			c.andFbmUnRefundAmountLessThanOrEqualTo(this.getFbmUnRefundAmountLessThanOrEqualTo());
		}
		if(CheckUtil.isNotEmpty(getFbmUnRefundAmountLessThan())){
			c.andFbmUnRefundAmountLessThan(this.getFbmUnRefundAmountLessThan());
		}
		if(CheckUtil.isNotEmpty(getFbmUnRefundAmountIsNull()) && this.getFbmUnRefundAmountIsNull()){
			c.andFbmUnRefundAmountIsNull();
		}
		if(CheckUtil.isNotEmpty(getFbmUnRefundAmountIsNotNull()) && this.getFbmUnRefundAmountIsNotNull()){
			c.andFbmUnRefundAmountIsNotNull();
		}
		if(CheckUtil.isNotEmpty(getFbmUnRefundAmountIn())){
			c.andFbmUnRefundAmountIn(this.getFbmUnRefundAmountIn());
		}
		if(CheckUtil.isNotEmpty(getFbmUnRefundAmountGreaterThanOrEqualTo())){
			c.andFbmUnRefundAmountGreaterThanOrEqualTo(this.getFbmUnRefundAmountGreaterThanOrEqualTo());
		}
		if(CheckUtil.isNotEmpty(getFbmUnRefundAmountGreaterThan())){
			c.andFbmUnRefundAmountGreaterThan(this.getFbmUnRefundAmountGreaterThan());
		}
		if(CheckUtil.isNotEmpty(getFbmUnRefundAmountEqualTo())){
			c.andFbmUnRefundAmountEqualTo(this.getFbmUnRefundAmountEqualTo());
		}
		if(CheckUtil.isNotEmpty(getFbmTurnerDealNotIn())){
			c.andFbmTurnerDealNotIn(this.getFbmTurnerDealNotIn());
		}
		if(CheckUtil.isNotEmpty(getFbmTurnerDealNotEqualTo())){
			c.andFbmTurnerDealNotEqualTo(this.getFbmTurnerDealNotEqualTo());
		}
		if(CheckUtil.isNotEmpty(getFbmTurnerDealLessThanOrEqualTo())){
			c.andFbmTurnerDealLessThanOrEqualTo(this.getFbmTurnerDealLessThanOrEqualTo());
		}
		if(CheckUtil.isNotEmpty(getFbmTurnerDealLessThan())){
			c.andFbmTurnerDealLessThan(this.getFbmTurnerDealLessThan());
		}
		if(CheckUtil.isNotEmpty(getFbmTurnerDealIsNull()) && this.getFbmTurnerDealIsNull()){
			c.andFbmTurnerDealIsNull();
		}
		if(CheckUtil.isNotEmpty(getFbmTurnerDealIsNotNull()) && this.getFbmTurnerDealIsNotNull()){
			c.andFbmTurnerDealIsNotNull();
		}
		if(CheckUtil.isNotEmpty(getFbmTurnerDealIn())){
			c.andFbmTurnerDealIn(this.getFbmTurnerDealIn());
		}
		if(CheckUtil.isNotEmpty(getFbmTurnerDealGreaterThanOrEqualTo())){
			c.andFbmTurnerDealGreaterThanOrEqualTo(this.getFbmTurnerDealGreaterThanOrEqualTo());
		}
		if(CheckUtil.isNotEmpty(getFbmTurnerDealGreaterThan())){
			c.andFbmTurnerDealGreaterThan(this.getFbmTurnerDealGreaterThan());
		}
		if(CheckUtil.isNotEmpty(getFbmTurnerDealEqualTo())){
			c.andFbmTurnerDealEqualTo(this.getFbmTurnerDealEqualTo());
		}
		if(CheckUtil.isNotEmpty(getFbmSubjectsNotIn())){
			c.andFbmSubjectsNotIn(this.getFbmSubjectsNotIn());
		}
		if(CheckUtil.isNotEmpty(getFbmSubjectsNotEqualTo())){
			c.andFbmSubjectsNotEqualTo(this.getFbmSubjectsNotEqualTo());
		}
		if(CheckUtil.isNotEmpty(getFbmSubjectsLessThanOrEqualTo())){
			c.andFbmSubjectsLessThanOrEqualTo(this.getFbmSubjectsLessThanOrEqualTo());
		}
		if(CheckUtil.isNotEmpty(getFbmSubjectsLessThan())){
			c.andFbmSubjectsLessThan(this.getFbmSubjectsLessThan());
		}
		if(CheckUtil.isNotEmpty(getFbmSubjectsIsNull()) && this.getFbmSubjectsIsNull()){
			c.andFbmSubjectsIsNull();
		}
		if(CheckUtil.isNotEmpty(getFbmSubjectsIsNotNull()) && this.getFbmSubjectsIsNotNull()){
			c.andFbmSubjectsIsNotNull();
		}
		if(CheckUtil.isNotEmpty(getFbmSubjectsIn())){
			c.andFbmSubjectsIn(this.getFbmSubjectsIn());
		}
		if(CheckUtil.isNotEmpty(getFbmSubjectsGreaterThanOrEqualTo())){
			c.andFbmSubjectsGreaterThanOrEqualTo(this.getFbmSubjectsGreaterThanOrEqualTo());
		}
		if(CheckUtil.isNotEmpty(getFbmSubjectsGreaterThan())){
			c.andFbmSubjectsGreaterThan(this.getFbmSubjectsGreaterThan());
		}
		if(CheckUtil.isNotEmpty(getFbmSubjectsEqualTo())){
			c.andFbmSubjectsEqualTo(this.getFbmSubjectsEqualTo());
		}
		if(CheckUtil.isNotEmpty(getFbmRefundAmountNotIn())){
			c.andFbmRefundAmountNotIn(this.getFbmRefundAmountNotIn());
		}
		if(CheckUtil.isNotEmpty(getFbmRefundAmountNotEqualTo())){
			c.andFbmRefundAmountNotEqualTo(this.getFbmRefundAmountNotEqualTo());
		}
		if(CheckUtil.isNotEmpty(getFbmRefundAmountLessThanOrEqualTo())){
			c.andFbmRefundAmountLessThanOrEqualTo(this.getFbmRefundAmountLessThanOrEqualTo());
		}
		if(CheckUtil.isNotEmpty(getFbmRefundAmountLessThan())){
			c.andFbmRefundAmountLessThan(this.getFbmRefundAmountLessThan());
		}
		if(CheckUtil.isNotEmpty(getFbmRefundAmountIsNull()) && this.getFbmRefundAmountIsNull()){
			c.andFbmRefundAmountIsNull();
		}
		if(CheckUtil.isNotEmpty(getFbmRefundAmountIsNotNull()) && this.getFbmRefundAmountIsNotNull()){
			c.andFbmRefundAmountIsNotNull();
		}
		if(CheckUtil.isNotEmpty(getFbmRefundAmountIn())){
			c.andFbmRefundAmountIn(this.getFbmRefundAmountIn());
		}
		if(CheckUtil.isNotEmpty(getFbmRefundAmountGreaterThanOrEqualTo())){
			c.andFbmRefundAmountGreaterThanOrEqualTo(this.getFbmRefundAmountGreaterThanOrEqualTo());
		}
		if(CheckUtil.isNotEmpty(getFbmRefundAmountGreaterThan())){
			c.andFbmRefundAmountGreaterThan(this.getFbmRefundAmountGreaterThan());
		}
		if(CheckUtil.isNotEmpty(getFbmRefundAmountEqualTo())){
			c.andFbmRefundAmountEqualTo(this.getFbmRefundAmountEqualTo());
		}
		if(CheckUtil.isNotEmpty(getFbmPayTimeNotIn())){
			c.andFbmPayTimeNotIn(this.getFbmPayTimeNotIn());
		}
		if(CheckUtil.isNotEmpty(getFbmPayTimeNotEqualTo())){
			c.andFbmPayTimeNotEqualTo(this.getFbmPayTimeNotEqualTo());
		}
		if(CheckUtil.isNotEmpty(getFbmPayTimeLessThanOrEqualTo())){
			c.andFbmPayTimeLessThanOrEqualTo(this.getFbmPayTimeLessThanOrEqualTo());
		}
		if(CheckUtil.isNotEmpty(getFbmPayTimeLessThan())){
			c.andFbmPayTimeLessThan(this.getFbmPayTimeLessThan());
		}
		if(CheckUtil.isNotEmpty(getFbmPayTimeIsNull()) && this.getFbmPayTimeIsNull()){
			c.andFbmPayTimeIsNull();
		}
		if(CheckUtil.isNotEmpty(getFbmPayTimeIsNotNull()) && this.getFbmPayTimeIsNotNull()){
			c.andFbmPayTimeIsNotNull();
		}
		if(CheckUtil.isNotEmpty(getFbmPayTimeIn())){
			c.andFbmPayTimeIn(this.getFbmPayTimeIn());
		}
		if(CheckUtil.isNotEmpty(getFbmPayTimeGreaterThanOrEqualTo())){
			c.andFbmPayTimeGreaterThanOrEqualTo(this.getFbmPayTimeGreaterThanOrEqualTo());
		}
		if(CheckUtil.isNotEmpty(getFbmPayTimeGreaterThan())){
			c.andFbmPayTimeGreaterThan(this.getFbmPayTimeGreaterThan());
		}
		if(CheckUtil.isNotEmpty(getFbmPayTimeEqualTo())){
			c.andFbmPayTimeEqualTo(this.getFbmPayTimeEqualTo());
		}
		if(CheckUtil.isNotEmpty(getFbmPayAmonutNotIn())){
			c.andFbmPayAmonutNotIn(this.getFbmPayAmonutNotIn());
		}
		if(CheckUtil.isNotEmpty(getFbmPayAmonutNotEqualTo())){
			c.andFbmPayAmonutNotEqualTo(this.getFbmPayAmonutNotEqualTo());
		}
		if(CheckUtil.isNotEmpty(getFbmPayAmonutLessThanOrEqualTo())){
			c.andFbmPayAmonutLessThanOrEqualTo(this.getFbmPayAmonutLessThanOrEqualTo());
		}
		if(CheckUtil.isNotEmpty(getFbmPayAmonutLessThan())){
			c.andFbmPayAmonutLessThan(this.getFbmPayAmonutLessThan());
		}
		if(CheckUtil.isNotEmpty(getFbmPayAmonutIsNull()) && this.getFbmPayAmonutIsNull()){
			c.andFbmPayAmonutIsNull();
		}
		if(CheckUtil.isNotEmpty(getFbmPayAmonutIsNotNull()) && this.getFbmPayAmonutIsNotNull()){
			c.andFbmPayAmonutIsNotNull();
		}
		if(CheckUtil.isNotEmpty(getFbmPayAmonutIn())){
			c.andFbmPayAmonutIn(this.getFbmPayAmonutIn());
		}
		if(CheckUtil.isNotEmpty(getFbmPayAmonutGreaterThanOrEqualTo())){
			c.andFbmPayAmonutGreaterThanOrEqualTo(this.getFbmPayAmonutGreaterThanOrEqualTo());
		}
		if(CheckUtil.isNotEmpty(getFbmPayAmonutGreaterThan())){
			c.andFbmPayAmonutGreaterThan(this.getFbmPayAmonutGreaterThan());
		}
		if(CheckUtil.isNotEmpty(getFbmPayAmonutEqualTo())){
			c.andFbmPayAmonutEqualTo(this.getFbmPayAmonutEqualTo());
		}
		if(CheckUtil.isNotEmpty(getFbmOverdueStateNotIn())){
			c.andFbmOverdueStateNotIn(this.getFbmOverdueStateNotIn());
		}
		if(CheckUtil.isNotEmpty(getFbmOverdueStateNotEqualTo())){
			c.andFbmOverdueStateNotEqualTo(this.getFbmOverdueStateNotEqualTo());
		}
		if(CheckUtil.isNotEmpty(getFbmOverdueStateLessThanOrEqualTo())){
			c.andFbmOverdueStateLessThanOrEqualTo(this.getFbmOverdueStateLessThanOrEqualTo());
		}
		if(CheckUtil.isNotEmpty(getFbmOverdueStateLessThan())){
			c.andFbmOverdueStateLessThan(this.getFbmOverdueStateLessThan());
		}
		if(CheckUtil.isNotEmpty(getFbmOverdueStateIsNull()) && this.getFbmOverdueStateIsNull()){
			c.andFbmOverdueStateIsNull();
		}
		if(CheckUtil.isNotEmpty(getFbmOverdueStateIsNotNull()) && this.getFbmOverdueStateIsNotNull()){
			c.andFbmOverdueStateIsNotNull();
		}
		if(CheckUtil.isNotEmpty(getFbmOverdueStateIn())){
			c.andFbmOverdueStateIn(this.getFbmOverdueStateIn());
		}
		if(CheckUtil.isNotEmpty(getFbmOverdueStateGreaterThanOrEqualTo())){
			c.andFbmOverdueStateGreaterThanOrEqualTo(this.getFbmOverdueStateGreaterThanOrEqualTo());
		}
		if(CheckUtil.isNotEmpty(getFbmOverdueStateGreaterThan())){
			c.andFbmOverdueStateGreaterThan(this.getFbmOverdueStateGreaterThan());
		}
		if(CheckUtil.isNotEmpty(getFbmOverdueStateEqualTo())){
			c.andFbmOverdueStateEqualTo(this.getFbmOverdueStateEqualTo());
		}
		if(CheckUtil.isNotEmpty(getFbmNperNotLike())){
			c.andFbmNperNotLike("%"+this.getFbmNperNotLike()+"%");
		}
		if(CheckUtil.isNotEmpty(getFbmNperNotIn())){
			c.andFbmNperNotIn(this.getFbmNperNotIn());
		}
		if(CheckUtil.isNotEmpty(getFbmNperNotEqualTo())){
			c.andFbmNperNotEqualTo(this.getFbmNperNotEqualTo());
		}
		if(CheckUtil.isNotEmpty(getFbmNperLike())){
			c.andFbmNperLike("%"+this.getFbmNperLike()+"%");
		}
		if(CheckUtil.isNotEmpty(getFbmNperLessThanOrEqualTo())){
			c.andFbmNperLessThanOrEqualTo(this.getFbmNperLessThanOrEqualTo());
		}
		if(CheckUtil.isNotEmpty(getFbmNperLessThan())){
			c.andFbmNperLessThan(this.getFbmNperLessThan());
		}
		if(CheckUtil.isNotEmpty(getFbmNperIsNull()) && this.getFbmNperIsNull()){
			c.andFbmNperIsNull();
		}
		if(CheckUtil.isNotEmpty(getFbmNperIsNotNull()) && this.getFbmNperIsNotNull()){
			c.andFbmNperIsNotNull();
		}
		if(CheckUtil.isNotEmpty(getFbmNperIn())){
			c.andFbmNperIn(this.getFbmNperIn());
		}
		if(CheckUtil.isNotEmpty(getFbmNperGreaterThanOrEqualTo())){
			c.andFbmNperGreaterThanOrEqualTo(this.getFbmNperGreaterThanOrEqualTo());
		}
		if(CheckUtil.isNotEmpty(getFbmNperGreaterThan())){
			c.andFbmNperGreaterThan(this.getFbmNperGreaterThan());
		}
		if(CheckUtil.isNotEmpty(getFbmNperEqualTo())){
			c.andFbmNperEqualTo(this.getFbmNperEqualTo());
		}
		if(CheckUtil.isNotEmpty(getFbmNotMatchAmountNotIn())){
			c.andFbmNotMatchAmountNotIn(this.getFbmNotMatchAmountNotIn());
		}
		if(CheckUtil.isNotEmpty(getFbmNotMatchAmountNotEqualTo())){
			c.andFbmNotMatchAmountNotEqualTo(this.getFbmNotMatchAmountNotEqualTo());
		}
		if(CheckUtil.isNotEmpty(getFbmNotMatchAmountLessThanOrEqualTo())){
			c.andFbmNotMatchAmountLessThanOrEqualTo(this.getFbmNotMatchAmountLessThanOrEqualTo());
		}
		if(CheckUtil.isNotEmpty(getFbmNotMatchAmountLessThan())){
			c.andFbmNotMatchAmountLessThan(this.getFbmNotMatchAmountLessThan());
		}
		if(CheckUtil.isNotEmpty(getFbmNotMatchAmountIsNull()) && this.getFbmNotMatchAmountIsNull()){
			c.andFbmNotMatchAmountIsNull();
		}
		if(CheckUtil.isNotEmpty(getFbmNotMatchAmountIsNotNull()) && this.getFbmNotMatchAmountIsNotNull()){
			c.andFbmNotMatchAmountIsNotNull();
		}
		if(CheckUtil.isNotEmpty(getFbmNotMatchAmountIn())){
			c.andFbmNotMatchAmountIn(this.getFbmNotMatchAmountIn());
		}
		if(CheckUtil.isNotEmpty(getFbmNotMatchAmountGreaterThanOrEqualTo())){
			c.andFbmNotMatchAmountGreaterThanOrEqualTo(this.getFbmNotMatchAmountGreaterThanOrEqualTo());
		}
		if(CheckUtil.isNotEmpty(getFbmNotMatchAmountGreaterThan())){
			c.andFbmNotMatchAmountGreaterThan(this.getFbmNotMatchAmountGreaterThan());
		}
		if(CheckUtil.isNotEmpty(getFbmNotMatchAmountEqualTo())){
			c.andFbmNotMatchAmountEqualTo(this.getFbmNotMatchAmountEqualTo());
		}
		if(CheckUtil.isNotEmpty(getFbmMatchedAmountNotIn())){
			c.andFbmMatchedAmountNotIn(this.getFbmMatchedAmountNotIn());
		}
		if(CheckUtil.isNotEmpty(getFbmMatchedAmountNotEqualTo())){
			c.andFbmMatchedAmountNotEqualTo(this.getFbmMatchedAmountNotEqualTo());
		}
		if(CheckUtil.isNotEmpty(getFbmMatchedAmountLessThanOrEqualTo())){
			c.andFbmMatchedAmountLessThanOrEqualTo(this.getFbmMatchedAmountLessThanOrEqualTo());
		}
		if(CheckUtil.isNotEmpty(getFbmMatchedAmountLessThan())){
			c.andFbmMatchedAmountLessThan(this.getFbmMatchedAmountLessThan());
		}
		if(CheckUtil.isNotEmpty(getFbmMatchedAmountIsNull()) && this.getFbmMatchedAmountIsNull()){
			c.andFbmMatchedAmountIsNull();
		}
		if(CheckUtil.isNotEmpty(getFbmMatchedAmountIsNotNull()) && this.getFbmMatchedAmountIsNotNull()){
			c.andFbmMatchedAmountIsNotNull();
		}
		if(CheckUtil.isNotEmpty(getFbmMatchedAmountIn())){
			c.andFbmMatchedAmountIn(this.getFbmMatchedAmountIn());
		}
		if(CheckUtil.isNotEmpty(getFbmMatchedAmountGreaterThanOrEqualTo())){
			c.andFbmMatchedAmountGreaterThanOrEqualTo(this.getFbmMatchedAmountGreaterThanOrEqualTo());
		}
		if(CheckUtil.isNotEmpty(getFbmMatchedAmountGreaterThan())){
			c.andFbmMatchedAmountGreaterThan(this.getFbmMatchedAmountGreaterThan());
		}
		if(CheckUtil.isNotEmpty(getFbmMatchedAmountEqualTo())){
			c.andFbmMatchedAmountEqualTo(this.getFbmMatchedAmountEqualTo());
		}
		if(CheckUtil.isNotEmpty(getFbmMatchWayNotIn())){
			c.andFbmMatchWayNotIn(this.getFbmMatchWayNotIn());
		}
		if(CheckUtil.isNotEmpty(getFbmMatchWayNotEqualTo())){
			c.andFbmMatchWayNotEqualTo(this.getFbmMatchWayNotEqualTo());
		}
		if(CheckUtil.isNotEmpty(getFbmMatchWayLessThanOrEqualTo())){
			c.andFbmMatchWayLessThanOrEqualTo(this.getFbmMatchWayLessThanOrEqualTo());
		}
		if(CheckUtil.isNotEmpty(getFbmMatchWayLessThan())){
			c.andFbmMatchWayLessThan(this.getFbmMatchWayLessThan());
		}
		if(CheckUtil.isNotEmpty(getFbmMatchWayIsNull()) && this.getFbmMatchWayIsNull()){
			c.andFbmMatchWayIsNull();
		}
		if(CheckUtil.isNotEmpty(getFbmMatchWayIsNotNull()) && this.getFbmMatchWayIsNotNull()){
			c.andFbmMatchWayIsNotNull();
		}
		if(CheckUtil.isNotEmpty(getFbmMatchWayIn())){
			c.andFbmMatchWayIn(this.getFbmMatchWayIn());
		}
		if(CheckUtil.isNotEmpty(getFbmMatchWayGreaterThanOrEqualTo())){
			c.andFbmMatchWayGreaterThanOrEqualTo(this.getFbmMatchWayGreaterThanOrEqualTo());
		}
		if(CheckUtil.isNotEmpty(getFbmMatchWayGreaterThan())){
			c.andFbmMatchWayGreaterThan(this.getFbmMatchWayGreaterThan());
		}
		if(CheckUtil.isNotEmpty(getFbmMatchWayEqualTo())){
			c.andFbmMatchWayEqualTo(this.getFbmMatchWayEqualTo());
		}
		if(CheckUtil.isNotEmpty(getFbmMatchUserIdNotIn())){
			c.andFbmMatchUserIdNotIn(this.getFbmMatchUserIdNotIn());
		}
		if(CheckUtil.isNotEmpty(getFbmMatchUserIdNotEqualTo())){
			c.andFbmMatchUserIdNotEqualTo(this.getFbmMatchUserIdNotEqualTo());
		}
		if(CheckUtil.isNotEmpty(getFbmMatchUserIdLessThanOrEqualTo())){
			c.andFbmMatchUserIdLessThanOrEqualTo(this.getFbmMatchUserIdLessThanOrEqualTo());
		}
		if(CheckUtil.isNotEmpty(getFbmMatchUserIdLessThan())){
			c.andFbmMatchUserIdLessThan(this.getFbmMatchUserIdLessThan());
		}
		if(CheckUtil.isNotEmpty(getFbmMatchUserIdIsNull()) && this.getFbmMatchUserIdIsNull()){
			c.andFbmMatchUserIdIsNull();
		}
		if(CheckUtil.isNotEmpty(getFbmMatchUserIdIsNotNull()) && this.getFbmMatchUserIdIsNotNull()){
			c.andFbmMatchUserIdIsNotNull();
		}
		if(CheckUtil.isNotEmpty(getFbmMatchUserIdIn())){
			c.andFbmMatchUserIdIn(this.getFbmMatchUserIdIn());
		}
		if(CheckUtil.isNotEmpty(getFbmMatchUserIdGreaterThanOrEqualTo())){
			c.andFbmMatchUserIdGreaterThanOrEqualTo(this.getFbmMatchUserIdGreaterThanOrEqualTo());
		}
		if(CheckUtil.isNotEmpty(getFbmMatchUserIdGreaterThan())){
			c.andFbmMatchUserIdGreaterThan(this.getFbmMatchUserIdGreaterThan());
		}
		if(CheckUtil.isNotEmpty(getFbmMatchUserIdEqualTo())){
			c.andFbmMatchUserIdEqualTo(this.getFbmMatchUserIdEqualTo());
		}
		if(CheckUtil.isNotEmpty(getFbmMatchTypeNotLike())){
			c.andFbmMatchTypeNotLike("%"+this.getFbmMatchTypeNotLike()+"%");
		}
		if(CheckUtil.isNotEmpty(getFbmMatchTypeNotIn())){
			c.andFbmMatchTypeNotIn(this.getFbmMatchTypeNotIn());
		}
		if(CheckUtil.isNotEmpty(getFbmMatchTypeNotEqualTo())){
			c.andFbmMatchTypeNotEqualTo(this.getFbmMatchTypeNotEqualTo());
		}
		if(CheckUtil.isNotEmpty(getFbmMatchTypeLike())){
			c.andFbmMatchTypeLike("%"+this.getFbmMatchTypeLike()+"%");
		}
		if(CheckUtil.isNotEmpty(getFbmMatchTypeLessThanOrEqualTo())){
			c.andFbmMatchTypeLessThanOrEqualTo(this.getFbmMatchTypeLessThanOrEqualTo());
		}
		if(CheckUtil.isNotEmpty(getFbmMatchTypeLessThan())){
			c.andFbmMatchTypeLessThan(this.getFbmMatchTypeLessThan());
		}
		if(CheckUtil.isNotEmpty(getFbmMatchTypeIsNull()) && this.getFbmMatchTypeIsNull()){
			c.andFbmMatchTypeIsNull();
		}
		if(CheckUtil.isNotEmpty(getFbmMatchTypeIsNotNull()) && this.getFbmMatchTypeIsNotNull()){
			c.andFbmMatchTypeIsNotNull();
		}
		if(CheckUtil.isNotEmpty(getFbmMatchTypeIn())){
			c.andFbmMatchTypeIn(this.getFbmMatchTypeIn());
		}
		if(CheckUtil.isNotEmpty(getFbmMatchTypeGreaterThanOrEqualTo())){
			c.andFbmMatchTypeGreaterThanOrEqualTo(this.getFbmMatchTypeGreaterThanOrEqualTo());
		}
		if(CheckUtil.isNotEmpty(getFbmMatchTypeGreaterThan())){
			c.andFbmMatchTypeGreaterThan(this.getFbmMatchTypeGreaterThan());
		}
		if(CheckUtil.isNotEmpty(getFbmMatchTypeEqualTo())){
			c.andFbmMatchTypeEqualTo(this.getFbmMatchTypeEqualTo());
		}
		if(CheckUtil.isNotEmpty(getFbmMatchTimeNotIn())){
			c.andFbmMatchTimeNotIn(this.getFbmMatchTimeNotIn());
		}
		if(CheckUtil.isNotEmpty(getFbmMatchTimeNotEqualTo())){
			c.andFbmMatchTimeNotEqualTo(this.getFbmMatchTimeNotEqualTo());
		}
		if(CheckUtil.isNotEmpty(getFbmMatchTimeLessThanOrEqualTo())){
			c.andFbmMatchTimeLessThanOrEqualTo(this.getFbmMatchTimeLessThanOrEqualTo());
		}
		if(CheckUtil.isNotEmpty(getFbmMatchTimeLessThan())){
			c.andFbmMatchTimeLessThan(this.getFbmMatchTimeLessThan());
		}
		if(CheckUtil.isNotEmpty(getFbmMatchTimeIsNull()) && this.getFbmMatchTimeIsNull()){
			c.andFbmMatchTimeIsNull();
		}
		if(CheckUtil.isNotEmpty(getFbmMatchTimeIsNotNull()) && this.getFbmMatchTimeIsNotNull()){
			c.andFbmMatchTimeIsNotNull();
		}
		if(CheckUtil.isNotEmpty(getFbmMatchTimeIn())){
			c.andFbmMatchTimeIn(this.getFbmMatchTimeIn());
		}
		if(CheckUtil.isNotEmpty(getFbmMatchTimeGreaterThanOrEqualTo())){
			c.andFbmMatchTimeGreaterThanOrEqualTo(this.getFbmMatchTimeGreaterThanOrEqualTo());
		}
		if(CheckUtil.isNotEmpty(getFbmMatchTimeGreaterThan())){
			c.andFbmMatchTimeGreaterThan(this.getFbmMatchTimeGreaterThan());
		}
		if(CheckUtil.isNotEmpty(getFbmMatchTimeEqualTo())){
			c.andFbmMatchTimeEqualTo(this.getFbmMatchTimeEqualTo());
		}
		if(CheckUtil.isNotEmpty(getFbmMatchSerialNumberNotLike())){
			c.andFbmMatchSerialNumberNotLike("%"+this.getFbmMatchSerialNumberNotLike()+"%");
		}
		if(CheckUtil.isNotEmpty(getFbmMatchSerialNumberNotIn())){
			c.andFbmMatchSerialNumberNotIn(this.getFbmMatchSerialNumberNotIn());
		}
		if(CheckUtil.isNotEmpty(getFbmMatchSerialNumberNotEqualTo())){
			c.andFbmMatchSerialNumberNotEqualTo(this.getFbmMatchSerialNumberNotEqualTo());
		}
		if(CheckUtil.isNotEmpty(getFbmMatchSerialNumberLike())){
			c.andFbmMatchSerialNumberLike("%"+this.getFbmMatchSerialNumberLike()+"%");
		}
		if(CheckUtil.isNotEmpty(getFbmMatchSerialNumberLessThanOrEqualTo())){
			c.andFbmMatchSerialNumberLessThanOrEqualTo(this.getFbmMatchSerialNumberLessThanOrEqualTo());
		}
		if(CheckUtil.isNotEmpty(getFbmMatchSerialNumberLessThan())){
			c.andFbmMatchSerialNumberLessThan(this.getFbmMatchSerialNumberLessThan());
		}
		if(CheckUtil.isNotEmpty(getFbmMatchSerialNumberIsNull()) && this.getFbmMatchSerialNumberIsNull()){
			c.andFbmMatchSerialNumberIsNull();
		}
		if(CheckUtil.isNotEmpty(getFbmMatchSerialNumberIsNotNull()) && this.getFbmMatchSerialNumberIsNotNull()){
			c.andFbmMatchSerialNumberIsNotNull();
		}
		if(CheckUtil.isNotEmpty(getFbmMatchSerialNumberIn())){
			c.andFbmMatchSerialNumberIn(this.getFbmMatchSerialNumberIn());
		}
		if(CheckUtil.isNotEmpty(getFbmMatchSerialNumberGreaterThanOrEqualTo())){
			c.andFbmMatchSerialNumberGreaterThanOrEqualTo(this.getFbmMatchSerialNumberGreaterThanOrEqualTo());
		}
		if(CheckUtil.isNotEmpty(getFbmMatchSerialNumberGreaterThan())){
			c.andFbmMatchSerialNumberGreaterThan(this.getFbmMatchSerialNumberGreaterThan());
		}
		if(CheckUtil.isNotEmpty(getFbmMatchSerialNumberEqualTo())){
			c.andFbmMatchSerialNumberEqualTo(this.getFbmMatchSerialNumberEqualTo());
		}
		if(CheckUtil.isNotEmpty(getFbmMatchPhoneNotLike())){
			c.andFbmMatchPhoneNotLike("%"+this.getFbmMatchPhoneNotLike()+"%");
		}
		if(CheckUtil.isNotEmpty(getFbmMatchPhoneNotIn())){
			c.andFbmMatchPhoneNotIn(this.getFbmMatchPhoneNotIn());
		}
		if(CheckUtil.isNotEmpty(getFbmMatchPhoneNotEqualTo())){
			c.andFbmMatchPhoneNotEqualTo(this.getFbmMatchPhoneNotEqualTo());
		}
		if(CheckUtil.isNotEmpty(getFbmMatchPhoneLike())){
			c.andFbmMatchPhoneLike("%"+this.getFbmMatchPhoneLike()+"%");
		}
		if(CheckUtil.isNotEmpty(getFbmMatchPhoneLessThanOrEqualTo())){
			c.andFbmMatchPhoneLessThanOrEqualTo(this.getFbmMatchPhoneLessThanOrEqualTo());
		}
		if(CheckUtil.isNotEmpty(getFbmMatchPhoneLessThan())){
			c.andFbmMatchPhoneLessThan(this.getFbmMatchPhoneLessThan());
		}
		if(CheckUtil.isNotEmpty(getFbmMatchPhoneIsNull()) && this.getFbmMatchPhoneIsNull()){
			c.andFbmMatchPhoneIsNull();
		}
		if(CheckUtil.isNotEmpty(getFbmMatchPhoneIsNotNull()) && this.getFbmMatchPhoneIsNotNull()){
			c.andFbmMatchPhoneIsNotNull();
		}
		if(CheckUtil.isNotEmpty(getFbmMatchPhoneIn())){
			c.andFbmMatchPhoneIn(this.getFbmMatchPhoneIn());
		}
		if(CheckUtil.isNotEmpty(getFbmMatchPhoneGreaterThanOrEqualTo())){
			c.andFbmMatchPhoneGreaterThanOrEqualTo(this.getFbmMatchPhoneGreaterThanOrEqualTo());
		}
		if(CheckUtil.isNotEmpty(getFbmMatchPhoneGreaterThan())){
			c.andFbmMatchPhoneGreaterThan(this.getFbmMatchPhoneGreaterThan());
		}
		if(CheckUtil.isNotEmpty(getFbmMatchPhoneEqualTo())){
			c.andFbmMatchPhoneEqualTo(this.getFbmMatchPhoneEqualTo());
		}
		if(CheckUtil.isNotEmpty(getFbmLeasePeriodNotIn())){
			c.andFbmLeasePeriodNotIn(this.getFbmLeasePeriodNotIn());
		}
		if(CheckUtil.isNotEmpty(getFbmLeasePeriodNotEqualTo())){
			c.andFbmLeasePeriodNotEqualTo(this.getFbmLeasePeriodNotEqualTo());
		}
		if(CheckUtil.isNotEmpty(getFbmLeasePeriodLessThanOrEqualTo())){
			c.andFbmLeasePeriodLessThanOrEqualTo(this.getFbmLeasePeriodLessThanOrEqualTo());
		}
		if(CheckUtil.isNotEmpty(getFbmLeasePeriodLessThan())){
			c.andFbmLeasePeriodLessThan(this.getFbmLeasePeriodLessThan());
		}
		if(CheckUtil.isNotEmpty(getFbmLeasePeriodIsNull()) && this.getFbmLeasePeriodIsNull()){
			c.andFbmLeasePeriodIsNull();
		}
		if(CheckUtil.isNotEmpty(getFbmLeasePeriodIsNotNull()) && this.getFbmLeasePeriodIsNotNull()){
			c.andFbmLeasePeriodIsNotNull();
		}
		if(CheckUtil.isNotEmpty(getFbmLeasePeriodIn())){
			c.andFbmLeasePeriodIn(this.getFbmLeasePeriodIn());
		}
		if(CheckUtil.isNotEmpty(getFbmLeasePeriodGreaterThanOrEqualTo())){
			c.andFbmLeasePeriodGreaterThanOrEqualTo(this.getFbmLeasePeriodGreaterThanOrEqualTo());
		}
		if(CheckUtil.isNotEmpty(getFbmLeasePeriodGreaterThan())){
			c.andFbmLeasePeriodGreaterThan(this.getFbmLeasePeriodGreaterThan());
		}
		if(CheckUtil.isNotEmpty(getFbmLeasePeriodEqualTo())){
			c.andFbmLeasePeriodEqualTo(this.getFbmLeasePeriodEqualTo());
		}
		if(CheckUtil.isNotEmpty(getFbmIdNotIn())){
			c.andFbmIdNotIn(this.getFbmIdNotIn());
		}
		if(CheckUtil.isNotEmpty(getFbmIdNotEqualTo())){
			c.andFbmIdNotEqualTo(this.getFbmIdNotEqualTo());
		}
		if(CheckUtil.isNotEmpty(getFbmIdLessThanOrEqualTo())){
			c.andFbmIdLessThanOrEqualTo(this.getFbmIdLessThanOrEqualTo());
		}
		if(CheckUtil.isNotEmpty(getFbmIdLessThan())){
			c.andFbmIdLessThan(this.getFbmIdLessThan());
		}
		if(CheckUtil.isNotEmpty(getFbmIdIsNull()) && this.getFbmIdIsNull()){
			c.andFbmIdIsNull();
		}
		if(CheckUtil.isNotEmpty(getFbmIdIsNotNull()) && this.getFbmIdIsNotNull()){
			c.andFbmIdIsNotNull();
		}
		if(CheckUtil.isNotEmpty(getFbmIdIn())){
			c.andFbmIdIn(this.getFbmIdIn());
		}
		if(CheckUtil.isNotEmpty(getFbmIdGreaterThanOrEqualTo())){
			c.andFbmIdGreaterThanOrEqualTo(this.getFbmIdGreaterThanOrEqualTo());
		}
		if(CheckUtil.isNotEmpty(getFbmIdGreaterThan())){
			c.andFbmIdGreaterThan(this.getFbmIdGreaterThan());
		}
		if(CheckUtil.isNotEmpty(getFbmIdEqualTo())){
			c.andFbmIdEqualTo(this.getFbmIdEqualTo());
		}
		if(CheckUtil.isNotEmpty(getFbmContractIdNotIn())){
			c.andFbmContractIdNotIn(this.getFbmContractIdNotIn());
		}
		if(CheckUtil.isNotEmpty(getFbmContractIdNotEqualTo())){
			c.andFbmContractIdNotEqualTo(this.getFbmContractIdNotEqualTo());
		}
		if(CheckUtil.isNotEmpty(getFbmContractIdLessThanOrEqualTo())){
			c.andFbmContractIdLessThanOrEqualTo(this.getFbmContractIdLessThanOrEqualTo());
		}
		if(CheckUtil.isNotEmpty(getFbmContractIdLessThan())){
			c.andFbmContractIdLessThan(this.getFbmContractIdLessThan());
		}
		if(CheckUtil.isNotEmpty(getFbmContractIdIsNull()) && this.getFbmContractIdIsNull()){
			c.andFbmContractIdIsNull();
		}
		if(CheckUtil.isNotEmpty(getFbmContractIdIsNotNull()) && this.getFbmContractIdIsNotNull()){
			c.andFbmContractIdIsNotNull();
		}
		if(CheckUtil.isNotEmpty(getFbmContractIdIn())){
			c.andFbmContractIdIn(this.getFbmContractIdIn());
		}
		if(CheckUtil.isNotEmpty(getFbmContractIdGreaterThanOrEqualTo())){
			c.andFbmContractIdGreaterThanOrEqualTo(this.getFbmContractIdGreaterThanOrEqualTo());
		}
		if(CheckUtil.isNotEmpty(getFbmContractIdGreaterThan())){
			c.andFbmContractIdGreaterThan(this.getFbmContractIdGreaterThan());
		}
		if(CheckUtil.isNotEmpty(getFbmContractIdEqualTo())){
			c.andFbmContractIdEqualTo(this.getFbmContractIdEqualTo());
		}
		if(CheckUtil.isNotEmpty(getFbmCityIdNotIn())){
			c.andFbmCityIdNotIn(this.getFbmCityIdNotIn());
		}
		if(CheckUtil.isNotEmpty(getFbmCityIdNotEqualTo())){
			c.andFbmCityIdNotEqualTo(this.getFbmCityIdNotEqualTo());
		}
		if(CheckUtil.isNotEmpty(getFbmCityIdLessThanOrEqualTo())){
			c.andFbmCityIdLessThanOrEqualTo(this.getFbmCityIdLessThanOrEqualTo());
		}
		if(CheckUtil.isNotEmpty(getFbmCityIdLessThan())){
			c.andFbmCityIdLessThan(this.getFbmCityIdLessThan());
		}
		if(CheckUtil.isNotEmpty(getFbmCityIdIsNull()) && this.getFbmCityIdIsNull()){
			c.andFbmCityIdIsNull();
		}
		if(CheckUtil.isNotEmpty(getFbmCityIdIsNotNull()) && this.getFbmCityIdIsNotNull()){
			c.andFbmCityIdIsNotNull();
		}
		if(CheckUtil.isNotEmpty(getFbmCityIdIn())){
			c.andFbmCityIdIn(this.getFbmCityIdIn());
		}
		if(CheckUtil.isNotEmpty(getFbmCityIdGreaterThanOrEqualTo())){
			c.andFbmCityIdGreaterThanOrEqualTo(this.getFbmCityIdGreaterThanOrEqualTo());
		}
		if(CheckUtil.isNotEmpty(getFbmCityIdGreaterThan())){
			c.andFbmCityIdGreaterThan(this.getFbmCityIdGreaterThan());
		}
		if(CheckUtil.isNotEmpty(getFbmCityIdEqualTo())){
			c.andFbmCityIdEqualTo(this.getFbmCityIdEqualTo());
		}
		if(CheckUtil.isNotEmpty(getFbmCarIdNotIn())){
			c.andFbmCarIdNotIn(this.getFbmCarIdNotIn());
		}
		if(CheckUtil.isNotEmpty(getFbmCarIdNotEqualTo())){
			c.andFbmCarIdNotEqualTo(this.getFbmCarIdNotEqualTo());
		}
		if(CheckUtil.isNotEmpty(getFbmCarIdLessThanOrEqualTo())){
			c.andFbmCarIdLessThanOrEqualTo(this.getFbmCarIdLessThanOrEqualTo());
		}
		if(CheckUtil.isNotEmpty(getFbmCarIdLessThan())){
			c.andFbmCarIdLessThan(this.getFbmCarIdLessThan());
		}
		if(CheckUtil.isNotEmpty(getFbmCarIdIsNull()) && this.getFbmCarIdIsNull()){
			c.andFbmCarIdIsNull();
		}
		if(CheckUtil.isNotEmpty(getFbmCarIdIsNotNull()) && this.getFbmCarIdIsNotNull()){
			c.andFbmCarIdIsNotNull();
		}
		if(CheckUtil.isNotEmpty(getFbmCarIdIn())){
			c.andFbmCarIdIn(this.getFbmCarIdIn());
		}
		if(CheckUtil.isNotEmpty(getFbmCarIdGreaterThanOrEqualTo())){
			c.andFbmCarIdGreaterThanOrEqualTo(this.getFbmCarIdGreaterThanOrEqualTo());
		}
		if(CheckUtil.isNotEmpty(getFbmCarIdGreaterThan())){
			c.andFbmCarIdGreaterThan(this.getFbmCarIdGreaterThan());
		}
		if(CheckUtil.isNotEmpty(getFbmCarIdEqualTo())){
			c.andFbmCarIdEqualTo(this.getFbmCarIdEqualTo());
		}
		if(CheckUtil.isNotEmpty(getFbmBreaksTypeNotIn())){
			c.andFbmBreaksTypeNotIn(this.getFbmBreaksTypeNotIn());
		}
		if(CheckUtil.isNotEmpty(getFbmBreaksTypeNotEqualTo())){
			c.andFbmBreaksTypeNotEqualTo(this.getFbmBreaksTypeNotEqualTo());
		}
		if(CheckUtil.isNotEmpty(getFbmBreaksTypeLessThanOrEqualTo())){
			c.andFbmBreaksTypeLessThanOrEqualTo(this.getFbmBreaksTypeLessThanOrEqualTo());
		}
		if(CheckUtil.isNotEmpty(getFbmBreaksTypeLessThan())){
			c.andFbmBreaksTypeLessThan(this.getFbmBreaksTypeLessThan());
		}
		if(CheckUtil.isNotEmpty(getFbmBreaksTypeIsNull()) && this.getFbmBreaksTypeIsNull()){
			c.andFbmBreaksTypeIsNull();
		}
		if(CheckUtil.isNotEmpty(getFbmBreaksTypeIsNotNull()) && this.getFbmBreaksTypeIsNotNull()){
			c.andFbmBreaksTypeIsNotNull();
		}
		if(CheckUtil.isNotEmpty(getFbmBreaksTypeIn())){
			c.andFbmBreaksTypeIn(this.getFbmBreaksTypeIn());
		}
		if(CheckUtil.isNotEmpty(getFbmBreaksTypeGreaterThanOrEqualTo())){
			c.andFbmBreaksTypeGreaterThanOrEqualTo(this.getFbmBreaksTypeGreaterThanOrEqualTo());
		}
		if(CheckUtil.isNotEmpty(getFbmBreaksTypeGreaterThan())){
			c.andFbmBreaksTypeGreaterThan(this.getFbmBreaksTypeGreaterThan());
		}
		if(CheckUtil.isNotEmpty(getFbmBreaksTypeEqualTo())){
			c.andFbmBreaksTypeEqualTo(this.getFbmBreaksTypeEqualTo());
		}
		if(CheckUtil.isNotEmpty(getFbmBreaksTimeNotIn())){
			c.andFbmBreaksTimeNotIn(this.getFbmBreaksTimeNotIn());
		}
		if(CheckUtil.isNotEmpty(getFbmBreaksTimeNotEqualTo())){
			c.andFbmBreaksTimeNotEqualTo(this.getFbmBreaksTimeNotEqualTo());
		}
		if(CheckUtil.isNotEmpty(getFbmBreaksTimeLessThanOrEqualTo())){
			c.andFbmBreaksTimeLessThanOrEqualTo(this.getFbmBreaksTimeLessThanOrEqualTo());
		}
		if(CheckUtil.isNotEmpty(getFbmBreaksTimeLessThan())){
			c.andFbmBreaksTimeLessThan(this.getFbmBreaksTimeLessThan());
		}
		if(CheckUtil.isNotEmpty(getFbmBreaksTimeIsNull()) && this.getFbmBreaksTimeIsNull()){
			c.andFbmBreaksTimeIsNull();
		}
		if(CheckUtil.isNotEmpty(getFbmBreaksTimeIsNotNull()) && this.getFbmBreaksTimeIsNotNull()){
			c.andFbmBreaksTimeIsNotNull();
		}
		if(CheckUtil.isNotEmpty(getFbmBreaksTimeIn())){
			c.andFbmBreaksTimeIn(this.getFbmBreaksTimeIn());
		}
		if(CheckUtil.isNotEmpty(getFbmBreaksTimeGreaterThanOrEqualTo())){
			c.andFbmBreaksTimeGreaterThanOrEqualTo(this.getFbmBreaksTimeGreaterThanOrEqualTo());
		}
		if(CheckUtil.isNotEmpty(getFbmBreaksTimeGreaterThan())){
			c.andFbmBreaksTimeGreaterThan(this.getFbmBreaksTimeGreaterThan());
		}
		if(CheckUtil.isNotEmpty(getFbmBreaksTimeEqualTo())){
			c.andFbmBreaksTimeEqualTo(this.getFbmBreaksTimeEqualTo());
		}
		if(CheckUtil.isNotEmpty(getFbmBreaksRemarkNotLike())){
			c.andFbmBreaksRemarkNotLike("%"+this.getFbmBreaksRemarkNotLike()+"%");
		}
		if(CheckUtil.isNotEmpty(getFbmBreaksRemarkNotIn())){
			c.andFbmBreaksRemarkNotIn(this.getFbmBreaksRemarkNotIn());
		}
		if(CheckUtil.isNotEmpty(getFbmBreaksRemarkNotEqualTo())){
			c.andFbmBreaksRemarkNotEqualTo(this.getFbmBreaksRemarkNotEqualTo());
		}
		if(CheckUtil.isNotEmpty(getFbmBreaksRemarkLike())){
			c.andFbmBreaksRemarkLike("%"+this.getFbmBreaksRemarkLike()+"%");
		}
		if(CheckUtil.isNotEmpty(getFbmBreaksRemarkLessThanOrEqualTo())){
			c.andFbmBreaksRemarkLessThanOrEqualTo(this.getFbmBreaksRemarkLessThanOrEqualTo());
		}
		if(CheckUtil.isNotEmpty(getFbmBreaksRemarkLessThan())){
			c.andFbmBreaksRemarkLessThan(this.getFbmBreaksRemarkLessThan());
		}
		if(CheckUtil.isNotEmpty(getFbmBreaksRemarkIsNull()) && this.getFbmBreaksRemarkIsNull()){
			c.andFbmBreaksRemarkIsNull();
		}
		if(CheckUtil.isNotEmpty(getFbmBreaksRemarkIsNotNull()) && this.getFbmBreaksRemarkIsNotNull()){
			c.andFbmBreaksRemarkIsNotNull();
		}
		if(CheckUtil.isNotEmpty(getFbmBreaksRemarkIn())){
			c.andFbmBreaksRemarkIn(this.getFbmBreaksRemarkIn());
		}
		if(CheckUtil.isNotEmpty(getFbmBreaksRemarkGreaterThanOrEqualTo())){
			c.andFbmBreaksRemarkGreaterThanOrEqualTo(this.getFbmBreaksRemarkGreaterThanOrEqualTo());
		}
		if(CheckUtil.isNotEmpty(getFbmBreaksRemarkGreaterThan())){
			c.andFbmBreaksRemarkGreaterThan(this.getFbmBreaksRemarkGreaterThan());
		}
		if(CheckUtil.isNotEmpty(getFbmBreaksRemarkEqualTo())){
			c.andFbmBreaksRemarkEqualTo(this.getFbmBreaksRemarkEqualTo());
		}
		if(CheckUtil.isNotEmpty(getFbmBreaksPhoneNotLike())){
			c.andFbmBreaksPhoneNotLike("%"+this.getFbmBreaksPhoneNotLike()+"%");
		}
		if(CheckUtil.isNotEmpty(getFbmBreaksPhoneNotIn())){
			c.andFbmBreaksPhoneNotIn(this.getFbmBreaksPhoneNotIn());
		}
		if(CheckUtil.isNotEmpty(getFbmBreaksPhoneNotEqualTo())){
			c.andFbmBreaksPhoneNotEqualTo(this.getFbmBreaksPhoneNotEqualTo());
		}
		if(CheckUtil.isNotEmpty(getFbmBreaksPhoneLike())){
			c.andFbmBreaksPhoneLike("%"+this.getFbmBreaksPhoneLike()+"%");
		}
		if(CheckUtil.isNotEmpty(getFbmBreaksPhoneLessThanOrEqualTo())){
			c.andFbmBreaksPhoneLessThanOrEqualTo(this.getFbmBreaksPhoneLessThanOrEqualTo());
		}
		if(CheckUtil.isNotEmpty(getFbmBreaksPhoneLessThan())){
			c.andFbmBreaksPhoneLessThan(this.getFbmBreaksPhoneLessThan());
		}
		if(CheckUtil.isNotEmpty(getFbmBreaksPhoneIsNull()) && this.getFbmBreaksPhoneIsNull()){
			c.andFbmBreaksPhoneIsNull();
		}
		if(CheckUtil.isNotEmpty(getFbmBreaksPhoneIsNotNull()) && this.getFbmBreaksPhoneIsNotNull()){
			c.andFbmBreaksPhoneIsNotNull();
		}
		if(CheckUtil.isNotEmpty(getFbmBreaksPhoneIn())){
			c.andFbmBreaksPhoneIn(this.getFbmBreaksPhoneIn());
		}
		if(CheckUtil.isNotEmpty(getFbmBreaksPhoneGreaterThanOrEqualTo())){
			c.andFbmBreaksPhoneGreaterThanOrEqualTo(this.getFbmBreaksPhoneGreaterThanOrEqualTo());
		}
		if(CheckUtil.isNotEmpty(getFbmBreaksPhoneGreaterThan())){
			c.andFbmBreaksPhoneGreaterThan(this.getFbmBreaksPhoneGreaterThan());
		}
		if(CheckUtil.isNotEmpty(getFbmBreaksPhoneEqualTo())){
			c.andFbmBreaksPhoneEqualTo(this.getFbmBreaksPhoneEqualTo());
		}
		if(CheckUtil.isNotEmpty(getFbmBreaksAmountNotIn())){
			c.andFbmBreaksAmountNotIn(this.getFbmBreaksAmountNotIn());
		}
		if(CheckUtil.isNotEmpty(getFbmBreaksAmountNotEqualTo())){
			c.andFbmBreaksAmountNotEqualTo(this.getFbmBreaksAmountNotEqualTo());
		}
		if(CheckUtil.isNotEmpty(getFbmBreaksAmountLessThanOrEqualTo())){
			c.andFbmBreaksAmountLessThanOrEqualTo(this.getFbmBreaksAmountLessThanOrEqualTo());
		}
		if(CheckUtil.isNotEmpty(getFbmBreaksAmountLessThan())){
			c.andFbmBreaksAmountLessThan(this.getFbmBreaksAmountLessThan());
		}
		if(CheckUtil.isNotEmpty(getFbmBreaksAmountIsNull()) && this.getFbmBreaksAmountIsNull()){
			c.andFbmBreaksAmountIsNull();
		}
		if(CheckUtil.isNotEmpty(getFbmBreaksAmountIsNotNull()) && this.getFbmBreaksAmountIsNotNull()){
			c.andFbmBreaksAmountIsNotNull();
		}
		if(CheckUtil.isNotEmpty(getFbmBreaksAmountIn())){
			c.andFbmBreaksAmountIn(this.getFbmBreaksAmountIn());
		}
		if(CheckUtil.isNotEmpty(getFbmBreaksAmountGreaterThanOrEqualTo())){
			c.andFbmBreaksAmountGreaterThanOrEqualTo(this.getFbmBreaksAmountGreaterThanOrEqualTo());
		}
		if(CheckUtil.isNotEmpty(getFbmBreaksAmountGreaterThan())){
			c.andFbmBreaksAmountGreaterThan(this.getFbmBreaksAmountGreaterThan());
		}
		if(CheckUtil.isNotEmpty(getFbmBreaksAmountEqualTo())){
			c.andFbmBreaksAmountEqualTo(this.getFbmBreaksAmountEqualTo());
		}
		if(CheckUtil.isNotEmpty(getFbmBreaksAfterAmountNotIn())){
			c.andFbmBreaksAfterAmountNotIn(this.getFbmBreaksAfterAmountNotIn());
		}
		if(CheckUtil.isNotEmpty(getFbmBreaksAfterAmountNotEqualTo())){
			c.andFbmBreaksAfterAmountNotEqualTo(this.getFbmBreaksAfterAmountNotEqualTo());
		}
		if(CheckUtil.isNotEmpty(getFbmBreaksAfterAmountLessThanOrEqualTo())){
			c.andFbmBreaksAfterAmountLessThanOrEqualTo(this.getFbmBreaksAfterAmountLessThanOrEqualTo());
		}
		if(CheckUtil.isNotEmpty(getFbmBreaksAfterAmountLessThan())){
			c.andFbmBreaksAfterAmountLessThan(this.getFbmBreaksAfterAmountLessThan());
		}
		if(CheckUtil.isNotEmpty(getFbmBreaksAfterAmountIsNull()) && this.getFbmBreaksAfterAmountIsNull()){
			c.andFbmBreaksAfterAmountIsNull();
		}
		if(CheckUtil.isNotEmpty(getFbmBreaksAfterAmountIsNotNull()) && this.getFbmBreaksAfterAmountIsNotNull()){
			c.andFbmBreaksAfterAmountIsNotNull();
		}
		if(CheckUtil.isNotEmpty(getFbmBreaksAfterAmountIn())){
			c.andFbmBreaksAfterAmountIn(this.getFbmBreaksAfterAmountIn());
		}
		if(CheckUtil.isNotEmpty(getFbmBreaksAfterAmountGreaterThanOrEqualTo())){
			c.andFbmBreaksAfterAmountGreaterThanOrEqualTo(this.getFbmBreaksAfterAmountGreaterThanOrEqualTo());
		}
		if(CheckUtil.isNotEmpty(getFbmBreaksAfterAmountGreaterThan())){
			c.andFbmBreaksAfterAmountGreaterThan(this.getFbmBreaksAfterAmountGreaterThan());
		}
		if(CheckUtil.isNotEmpty(getFbmBreaksAfterAmountEqualTo())){
			c.andFbmBreaksAfterAmountEqualTo(this.getFbmBreaksAfterAmountEqualTo());
		}
		if(CheckUtil.isNotEmpty(getFbmBillVoucherNotLike())){
			c.andFbmBillVoucherNotLike("%"+this.getFbmBillVoucherNotLike()+"%");
		}
		if(CheckUtil.isNotEmpty(getFbmBillVoucherNotIn())){
			c.andFbmBillVoucherNotIn(this.getFbmBillVoucherNotIn());
		}
		if(CheckUtil.isNotEmpty(getFbmBillVoucherNotEqualTo())){
			c.andFbmBillVoucherNotEqualTo(this.getFbmBillVoucherNotEqualTo());
		}
		if(CheckUtil.isNotEmpty(getFbmBillVoucherLike())){
			c.andFbmBillVoucherLike("%"+this.getFbmBillVoucherLike()+"%");
		}
		if(CheckUtil.isNotEmpty(getFbmBillVoucherLessThanOrEqualTo())){
			c.andFbmBillVoucherLessThanOrEqualTo(this.getFbmBillVoucherLessThanOrEqualTo());
		}
		if(CheckUtil.isNotEmpty(getFbmBillVoucherLessThan())){
			c.andFbmBillVoucherLessThan(this.getFbmBillVoucherLessThan());
		}
		if(CheckUtil.isNotEmpty(getFbmBillVoucherIsNull()) && this.getFbmBillVoucherIsNull()){
			c.andFbmBillVoucherIsNull();
		}
		if(CheckUtil.isNotEmpty(getFbmBillVoucherIsNotNull()) && this.getFbmBillVoucherIsNotNull()){
			c.andFbmBillVoucherIsNotNull();
		}
		if(CheckUtil.isNotEmpty(getFbmBillVoucherIn())){
			c.andFbmBillVoucherIn(this.getFbmBillVoucherIn());
		}
		if(CheckUtil.isNotEmpty(getFbmBillVoucherGreaterThanOrEqualTo())){
			c.andFbmBillVoucherGreaterThanOrEqualTo(this.getFbmBillVoucherGreaterThanOrEqualTo());
		}
		if(CheckUtil.isNotEmpty(getFbmBillVoucherGreaterThan())){
			c.andFbmBillVoucherGreaterThan(this.getFbmBillVoucherGreaterThan());
		}
		if(CheckUtil.isNotEmpty(getFbmBillVoucherEqualTo())){
			c.andFbmBillVoucherEqualTo(this.getFbmBillVoucherEqualTo());
		}
		if(CheckUtil.isNotEmpty(getFbmBillStateNotIn())){
			c.andFbmBillStateNotIn(this.getFbmBillStateNotIn());
		}
		if(CheckUtil.isNotEmpty(getFbmBillStateNotEqualTo())){
			c.andFbmBillStateNotEqualTo(this.getFbmBillStateNotEqualTo());
		}
		if(CheckUtil.isNotEmpty(getFbmBillStateLessThanOrEqualTo())){
			c.andFbmBillStateLessThanOrEqualTo(this.getFbmBillStateLessThanOrEqualTo());
		}
		if(CheckUtil.isNotEmpty(getFbmBillStateLessThan())){
			c.andFbmBillStateLessThan(this.getFbmBillStateLessThan());
		}
		if(CheckUtil.isNotEmpty(getFbmBillStateIsNull()) && this.getFbmBillStateIsNull()){
			c.andFbmBillStateIsNull();
		}
		if(CheckUtil.isNotEmpty(getFbmBillStateIsNotNull()) && this.getFbmBillStateIsNotNull()){
			c.andFbmBillStateIsNotNull();
		}
		if(CheckUtil.isNotEmpty(getFbmBillStateIn())){
			c.andFbmBillStateIn(this.getFbmBillStateIn());
		}
		if(CheckUtil.isNotEmpty(getFbmBillStateGreaterThanOrEqualTo())){
			c.andFbmBillStateGreaterThanOrEqualTo(this.getFbmBillStateGreaterThanOrEqualTo());
		}
		if(CheckUtil.isNotEmpty(getFbmBillStateGreaterThan())){
			c.andFbmBillStateGreaterThan(this.getFbmBillStateGreaterThan());
		}
		if(CheckUtil.isNotEmpty(getFbmBillStateEqualTo())){
			c.andFbmBillStateEqualTo(this.getFbmBillStateEqualTo());
		}
		if(CheckUtil.isNotEmpty(getFbmBillGenerateWayNotIn())){
			c.andFbmBillGenerateWayNotIn(this.getFbmBillGenerateWayNotIn());
		}
		if(CheckUtil.isNotEmpty(getFbmBillGenerateWayNotEqualTo())){
			c.andFbmBillGenerateWayNotEqualTo(this.getFbmBillGenerateWayNotEqualTo());
		}
		if(CheckUtil.isNotEmpty(getFbmBillGenerateWayLessThanOrEqualTo())){
			c.andFbmBillGenerateWayLessThanOrEqualTo(this.getFbmBillGenerateWayLessThanOrEqualTo());
		}
		if(CheckUtil.isNotEmpty(getFbmBillGenerateWayLessThan())){
			c.andFbmBillGenerateWayLessThan(this.getFbmBillGenerateWayLessThan());
		}
		if(CheckUtil.isNotEmpty(getFbmBillGenerateWayIsNull()) && this.getFbmBillGenerateWayIsNull()){
			c.andFbmBillGenerateWayIsNull();
		}
		if(CheckUtil.isNotEmpty(getFbmBillGenerateWayIsNotNull()) && this.getFbmBillGenerateWayIsNotNull()){
			c.andFbmBillGenerateWayIsNotNull();
		}
		if(CheckUtil.isNotEmpty(getFbmBillGenerateWayIn())){
			c.andFbmBillGenerateWayIn(this.getFbmBillGenerateWayIn());
		}
		if(CheckUtil.isNotEmpty(getFbmBillGenerateWayGreaterThanOrEqualTo())){
			c.andFbmBillGenerateWayGreaterThanOrEqualTo(this.getFbmBillGenerateWayGreaterThanOrEqualTo());
		}
		if(CheckUtil.isNotEmpty(getFbmBillGenerateWayGreaterThan())){
			c.andFbmBillGenerateWayGreaterThan(this.getFbmBillGenerateWayGreaterThan());
		}
		if(CheckUtil.isNotEmpty(getFbmBillGenerateWayEqualTo())){
			c.andFbmBillGenerateWayEqualTo(this.getFbmBillGenerateWayEqualTo());
		}
		if(CheckUtil.isNotEmpty(getFbmBillGenerateTimeNotIn())){
			c.andFbmBillGenerateTimeNotIn(this.getFbmBillGenerateTimeNotIn());
		}
		if(CheckUtil.isNotEmpty(getFbmBillGenerateTimeNotEqualTo())){
			c.andFbmBillGenerateTimeNotEqualTo(this.getFbmBillGenerateTimeNotEqualTo());
		}
		if(CheckUtil.isNotEmpty(getFbmBillGenerateTimeLessThanOrEqualTo())){
			c.andFbmBillGenerateTimeLessThanOrEqualTo(this.getFbmBillGenerateTimeLessThanOrEqualTo());
		}
		if(CheckUtil.isNotEmpty(getFbmBillGenerateTimeLessThan())){
			c.andFbmBillGenerateTimeLessThan(this.getFbmBillGenerateTimeLessThan());
		}
		if(CheckUtil.isNotEmpty(getFbmBillGenerateTimeIsNull()) && this.getFbmBillGenerateTimeIsNull()){
			c.andFbmBillGenerateTimeIsNull();
		}
		if(CheckUtil.isNotEmpty(getFbmBillGenerateTimeIsNotNull()) && this.getFbmBillGenerateTimeIsNotNull()){
			c.andFbmBillGenerateTimeIsNotNull();
		}
		if(CheckUtil.isNotEmpty(getFbmBillGenerateTimeIn())){
			c.andFbmBillGenerateTimeIn(this.getFbmBillGenerateTimeIn());
		}
		if(CheckUtil.isNotEmpty(getFbmBillGenerateTimeGreaterThanOrEqualTo())){
			c.andFbmBillGenerateTimeGreaterThanOrEqualTo(this.getFbmBillGenerateTimeGreaterThanOrEqualTo());
		}
		if(CheckUtil.isNotEmpty(getFbmBillGenerateTimeGreaterThan())){
			c.andFbmBillGenerateTimeGreaterThan(this.getFbmBillGenerateTimeGreaterThan());
		}
		if(CheckUtil.isNotEmpty(getFbmBillGenerateTimeEqualTo())){
			c.andFbmBillGenerateTimeEqualTo(this.getFbmBillGenerateTimeEqualTo());
		}
		if(CheckUtil.isNotEmpty(getFbmBillGenerateReasonNotLike())){
			c.andFbmBillGenerateReasonNotLike("%"+this.getFbmBillGenerateReasonNotLike()+"%");
		}
		if(CheckUtil.isNotEmpty(getFbmBillGenerateReasonNotIn())){
			c.andFbmBillGenerateReasonNotIn(this.getFbmBillGenerateReasonNotIn());
		}
		if(CheckUtil.isNotEmpty(getFbmBillGenerateReasonNotEqualTo())){
			c.andFbmBillGenerateReasonNotEqualTo(this.getFbmBillGenerateReasonNotEqualTo());
		}
		if(CheckUtil.isNotEmpty(getFbmBillGenerateReasonLike())){
			c.andFbmBillGenerateReasonLike("%"+this.getFbmBillGenerateReasonLike()+"%");
		}
		if(CheckUtil.isNotEmpty(getFbmBillGenerateReasonLessThanOrEqualTo())){
			c.andFbmBillGenerateReasonLessThanOrEqualTo(this.getFbmBillGenerateReasonLessThanOrEqualTo());
		}
		if(CheckUtil.isNotEmpty(getFbmBillGenerateReasonLessThan())){
			c.andFbmBillGenerateReasonLessThan(this.getFbmBillGenerateReasonLessThan());
		}
		if(CheckUtil.isNotEmpty(getFbmBillGenerateReasonIsNull()) && this.getFbmBillGenerateReasonIsNull()){
			c.andFbmBillGenerateReasonIsNull();
		}
		if(CheckUtil.isNotEmpty(getFbmBillGenerateReasonIsNotNull()) && this.getFbmBillGenerateReasonIsNotNull()){
			c.andFbmBillGenerateReasonIsNotNull();
		}
		if(CheckUtil.isNotEmpty(getFbmBillGenerateReasonIn())){
			c.andFbmBillGenerateReasonIn(this.getFbmBillGenerateReasonIn());
		}
		if(CheckUtil.isNotEmpty(getFbmBillGenerateReasonGreaterThanOrEqualTo())){
			c.andFbmBillGenerateReasonGreaterThanOrEqualTo(this.getFbmBillGenerateReasonGreaterThanOrEqualTo());
		}
		if(CheckUtil.isNotEmpty(getFbmBillGenerateReasonGreaterThan())){
			c.andFbmBillGenerateReasonGreaterThan(this.getFbmBillGenerateReasonGreaterThan());
		}
		if(CheckUtil.isNotEmpty(getFbmBillGenerateReasonEqualTo())){
			c.andFbmBillGenerateReasonEqualTo(this.getFbmBillGenerateReasonEqualTo());
		}
		if(CheckUtil.isNotEmpty(getFbmBillCatoffTimeNotIn())){
			c.andFbmBillCatoffTimeNotIn(this.getFbmBillCatoffTimeNotIn());
		}
		if(CheckUtil.isNotEmpty(getFbmBillCatoffTimeNotEqualTo())){
			c.andFbmBillCatoffTimeNotEqualTo(this.getFbmBillCatoffTimeNotEqualTo());
		}
		if(CheckUtil.isNotEmpty(getFbmBillCatoffTimeLessThanOrEqualTo())){
			c.andFbmBillCatoffTimeLessThanOrEqualTo(this.getFbmBillCatoffTimeLessThanOrEqualTo());
		}
		if(CheckUtil.isNotEmpty(getFbmBillCatoffTimeLessThan())){
			c.andFbmBillCatoffTimeLessThan(this.getFbmBillCatoffTimeLessThan());
		}
		if(CheckUtil.isNotEmpty(getFbmBillCatoffTimeIsNull()) && this.getFbmBillCatoffTimeIsNull()){
			c.andFbmBillCatoffTimeIsNull();
		}
		if(CheckUtil.isNotEmpty(getFbmBillCatoffTimeIsNotNull()) && this.getFbmBillCatoffTimeIsNotNull()){
			c.andFbmBillCatoffTimeIsNotNull();
		}
		if(CheckUtil.isNotEmpty(getFbmBillCatoffTimeIn())){
			c.andFbmBillCatoffTimeIn(this.getFbmBillCatoffTimeIn());
		}
		if(CheckUtil.isNotEmpty(getFbmBillCatoffTimeGreaterThanOrEqualTo())){
			c.andFbmBillCatoffTimeGreaterThanOrEqualTo(this.getFbmBillCatoffTimeGreaterThanOrEqualTo());
		}
		if(CheckUtil.isNotEmpty(getFbmBillCatoffTimeGreaterThan())){
			c.andFbmBillCatoffTimeGreaterThan(this.getFbmBillCatoffTimeGreaterThan());
		}
		if(CheckUtil.isNotEmpty(getFbmBillCatoffTimeEqualTo())){
			c.andFbmBillCatoffTimeEqualTo(this.getFbmBillCatoffTimeEqualTo());
		}
		if(CheckUtil.isNotEmpty(getFbmBillAmountNotIn())){
			c.andFbmBillAmountNotIn(this.getFbmBillAmountNotIn());
		}
		if(CheckUtil.isNotEmpty(getFbmBillAmountNotEqualTo())){
			c.andFbmBillAmountNotEqualTo(this.getFbmBillAmountNotEqualTo());
		}
		if(CheckUtil.isNotEmpty(getFbmBillAmountLessThanOrEqualTo())){
			c.andFbmBillAmountLessThanOrEqualTo(this.getFbmBillAmountLessThanOrEqualTo());
		}
		if(CheckUtil.isNotEmpty(getFbmBillAmountLessThan())){
			c.andFbmBillAmountLessThan(this.getFbmBillAmountLessThan());
		}
		if(CheckUtil.isNotEmpty(getFbmBillAmountIsNull()) && this.getFbmBillAmountIsNull()){
			c.andFbmBillAmountIsNull();
		}
		if(CheckUtil.isNotEmpty(getFbmBillAmountIsNotNull()) && this.getFbmBillAmountIsNotNull()){
			c.andFbmBillAmountIsNotNull();
		}
		if(CheckUtil.isNotEmpty(getFbmBillAmountIn())){
			c.andFbmBillAmountIn(this.getFbmBillAmountIn());
		}
		if(CheckUtil.isNotEmpty(getFbmBillAmountGreaterThanOrEqualTo())){
			c.andFbmBillAmountGreaterThanOrEqualTo(this.getFbmBillAmountGreaterThanOrEqualTo());
		}
		if(CheckUtil.isNotEmpty(getFbmBillAmountGreaterThan())){
			c.andFbmBillAmountGreaterThan(this.getFbmBillAmountGreaterThan());
		}
		if(CheckUtil.isNotEmpty(getFbmBillAmountEqualTo())){
			c.andFbmBillAmountEqualTo(this.getFbmBillAmountEqualTo());
		}
		if(CheckUtil.isNotEmpty(getFbmAssociateContractIdNotIn())){
			c.andFbmAssociateContractIdNotIn(this.getFbmAssociateContractIdNotIn());
		}
		if(CheckUtil.isNotEmpty(getFbmAssociateContractIdNotEqualTo())){
			c.andFbmAssociateContractIdNotEqualTo(this.getFbmAssociateContractIdNotEqualTo());
		}
		if(CheckUtil.isNotEmpty(getFbmAssociateContractIdLessThanOrEqualTo())){
			c.andFbmAssociateContractIdLessThanOrEqualTo(this.getFbmAssociateContractIdLessThanOrEqualTo());
		}
		if(CheckUtil.isNotEmpty(getFbmAssociateContractIdLessThan())){
			c.andFbmAssociateContractIdLessThan(this.getFbmAssociateContractIdLessThan());
		}
		if(CheckUtil.isNotEmpty(getFbmAssociateContractIdIsNull()) && this.getFbmAssociateContractIdIsNull()){
			c.andFbmAssociateContractIdIsNull();
		}
		if(CheckUtil.isNotEmpty(getFbmAssociateContractIdIsNotNull()) && this.getFbmAssociateContractIdIsNotNull()){
			c.andFbmAssociateContractIdIsNotNull();
		}
		if(CheckUtil.isNotEmpty(getFbmAssociateContractIdIn())){
			c.andFbmAssociateContractIdIn(this.getFbmAssociateContractIdIn());
		}
		if(CheckUtil.isNotEmpty(getFbmAssociateContractIdGreaterThanOrEqualTo())){
			c.andFbmAssociateContractIdGreaterThanOrEqualTo(this.getFbmAssociateContractIdGreaterThanOrEqualTo());
		}
		if(CheckUtil.isNotEmpty(getFbmAssociateContractIdGreaterThan())){
			c.andFbmAssociateContractIdGreaterThan(this.getFbmAssociateContractIdGreaterThan());
		}
		if(CheckUtil.isNotEmpty(getFbmAssociateContractIdEqualTo())){
			c.andFbmAssociateContractIdEqualTo(this.getFbmAssociateContractIdEqualTo());
		}
		if(CheckUtil.isNotEmpty(getFbmAssociateCarIdNotIn())){
			c.andFbmAssociateCarIdNotIn(this.getFbmAssociateCarIdNotIn());
		}
		if(CheckUtil.isNotEmpty(getFbmAssociateCarIdNotEqualTo())){
			c.andFbmAssociateCarIdNotEqualTo(this.getFbmAssociateCarIdNotEqualTo());
		}
		if(CheckUtil.isNotEmpty(getFbmAssociateCarIdLessThanOrEqualTo())){
			c.andFbmAssociateCarIdLessThanOrEqualTo(this.getFbmAssociateCarIdLessThanOrEqualTo());
		}
		if(CheckUtil.isNotEmpty(getFbmAssociateCarIdLessThan())){
			c.andFbmAssociateCarIdLessThan(this.getFbmAssociateCarIdLessThan());
		}
		if(CheckUtil.isNotEmpty(getFbmAssociateCarIdIsNull()) && this.getFbmAssociateCarIdIsNull()){
			c.andFbmAssociateCarIdIsNull();
		}
		if(CheckUtil.isNotEmpty(getFbmAssociateCarIdIsNotNull()) && this.getFbmAssociateCarIdIsNotNull()){
			c.andFbmAssociateCarIdIsNotNull();
		}
		if(CheckUtil.isNotEmpty(getFbmAssociateCarIdIn())){
			c.andFbmAssociateCarIdIn(this.getFbmAssociateCarIdIn());
		}
		if(CheckUtil.isNotEmpty(getFbmAssociateCarIdGreaterThanOrEqualTo())){
			c.andFbmAssociateCarIdGreaterThanOrEqualTo(this.getFbmAssociateCarIdGreaterThanOrEqualTo());
		}
		if(CheckUtil.isNotEmpty(getFbmAssociateCarIdGreaterThan())){
			c.andFbmAssociateCarIdGreaterThan(this.getFbmAssociateCarIdGreaterThan());
		}
		if(CheckUtil.isNotEmpty(getFbmAssociateCarIdEqualTo())){
			c.andFbmAssociateCarIdEqualTo(this.getFbmAssociateCarIdEqualTo());
		}
		if(CheckUtil.isNotEmpty(getFbmAlreadyRefundAmountNotIn())){
			c.andFbmAlreadyRefundAmountNotIn(this.getFbmAlreadyRefundAmountNotIn());
		}
		if(CheckUtil.isNotEmpty(getFbmAlreadyRefundAmountNotEqualTo())){
			c.andFbmAlreadyRefundAmountNotEqualTo(this.getFbmAlreadyRefundAmountNotEqualTo());
		}
		if(CheckUtil.isNotEmpty(getFbmAlreadyRefundAmountLessThanOrEqualTo())){
			c.andFbmAlreadyRefundAmountLessThanOrEqualTo(this.getFbmAlreadyRefundAmountLessThanOrEqualTo());
		}
		if(CheckUtil.isNotEmpty(getFbmAlreadyRefundAmountLessThan())){
			c.andFbmAlreadyRefundAmountLessThan(this.getFbmAlreadyRefundAmountLessThan());
		}
		if(CheckUtil.isNotEmpty(getFbmAlreadyRefundAmountIsNull()) && this.getFbmAlreadyRefundAmountIsNull()){
			c.andFbmAlreadyRefundAmountIsNull();
		}
		if(CheckUtil.isNotEmpty(getFbmAlreadyRefundAmountIsNotNull()) && this.getFbmAlreadyRefundAmountIsNotNull()){
			c.andFbmAlreadyRefundAmountIsNotNull();
		}
		if(CheckUtil.isNotEmpty(getFbmAlreadyRefundAmountIn())){
			c.andFbmAlreadyRefundAmountIn(this.getFbmAlreadyRefundAmountIn());
		}
		if(CheckUtil.isNotEmpty(getFbmAlreadyRefundAmountGreaterThanOrEqualTo())){
			c.andFbmAlreadyRefundAmountGreaterThanOrEqualTo(this.getFbmAlreadyRefundAmountGreaterThanOrEqualTo());
		}
		if(CheckUtil.isNotEmpty(getFbmAlreadyRefundAmountGreaterThan())){
			c.andFbmAlreadyRefundAmountGreaterThan(this.getFbmAlreadyRefundAmountGreaterThan());
		}
		if(CheckUtil.isNotEmpty(getFbmAlreadyRefundAmountEqualTo())){
			c.andFbmAlreadyRefundAmountEqualTo(this.getFbmAlreadyRefundAmountEqualTo());
		}
		if(CheckUtil.isNotEmpty(getDrNotIn())){
			c.andDrNotIn(this.getDrNotIn());
		}
		if(CheckUtil.isNotEmpty(getDrNotEqualTo())){
			c.andDrNotEqualTo(this.getDrNotEqualTo());
		}
		if(CheckUtil.isNotEmpty(getDrLessThanOrEqualTo())){
			c.andDrLessThanOrEqualTo(this.getDrLessThanOrEqualTo());
		}
		if(CheckUtil.isNotEmpty(getDrLessThan())){
			c.andDrLessThan(this.getDrLessThan());
		}
		if(CheckUtil.isNotEmpty(getDrIsNull()) && this.getDrIsNull()){
			c.andDrIsNull();
		}
		if(CheckUtil.isNotEmpty(getDrIsNotNull()) && this.getDrIsNotNull()){
			c.andDrIsNotNull();
		}
		if(CheckUtil.isNotEmpty(getDrIn())){
			c.andDrIn(this.getDrIn());
		}
		if(CheckUtil.isNotEmpty(getDrGreaterThanOrEqualTo())){
			c.andDrGreaterThanOrEqualTo(this.getDrGreaterThanOrEqualTo());
		}
		if(CheckUtil.isNotEmpty(getDrGreaterThan())){
			c.andDrGreaterThan(this.getDrGreaterThan());
		}
		if(CheckUtil.isNotEmpty(getDrEqualTo())){
			c.andDrEqualTo(this.getDrEqualTo());
		}
		if(CheckUtil.isNotEmpty(getCreateuserNotLike())){
			c.andCreateuserNotLike("%"+this.getCreateuserNotLike()+"%");
		}
		if(CheckUtil.isNotEmpty(getCreateuserNotIn())){
			c.andCreateuserNotIn(this.getCreateuserNotIn());
		}
		if(CheckUtil.isNotEmpty(getCreateuserNotEqualTo())){
			c.andCreateuserNotEqualTo(this.getCreateuserNotEqualTo());
		}
		if(CheckUtil.isNotEmpty(getCreateuserLike())){
			c.andCreateuserLike("%"+this.getCreateuserLike()+"%");
		}
		if(CheckUtil.isNotEmpty(getCreateuserLessThanOrEqualTo())){
			c.andCreateuserLessThanOrEqualTo(this.getCreateuserLessThanOrEqualTo());
		}
		if(CheckUtil.isNotEmpty(getCreateuserLessThan())){
			c.andCreateuserLessThan(this.getCreateuserLessThan());
		}
		if(CheckUtil.isNotEmpty(getCreateuserIsNull()) && this.getCreateuserIsNull()){
			c.andCreateuserIsNull();
		}
		if(CheckUtil.isNotEmpty(getCreateuserIsNotNull()) && this.getCreateuserIsNotNull()){
			c.andCreateuserIsNotNull();
		}
		if(CheckUtil.isNotEmpty(getCreateuserIn())){
			c.andCreateuserIn(this.getCreateuserIn());
		}
		if(CheckUtil.isNotEmpty(getCreateuserGreaterThanOrEqualTo())){
			c.andCreateuserGreaterThanOrEqualTo(this.getCreateuserGreaterThanOrEqualTo());
		}
		if(CheckUtil.isNotEmpty(getCreateuserGreaterThan())){
			c.andCreateuserGreaterThan(this.getCreateuserGreaterThan());
		}
		if(CheckUtil.isNotEmpty(getCreateuserEqualTo())){
			c.andCreateuserEqualTo(this.getCreateuserEqualTo());
		}
		if(CheckUtil.isNotEmpty(getCreatetimeNotIn())){
			c.andCreatetimeNotIn(this.getCreatetimeNotIn());
		}
		if(CheckUtil.isNotEmpty(getCreatetimeNotEqualTo())){
			c.andCreatetimeNotEqualTo(this.getCreatetimeNotEqualTo());
		}
		if(CheckUtil.isNotEmpty(getCreatetimeLessThanOrEqualTo())){
			c.andCreatetimeLessThanOrEqualTo(this.getCreatetimeLessThanOrEqualTo());
		}
		if(CheckUtil.isNotEmpty(getCreatetimeLessThan())){
			c.andCreatetimeLessThan(this.getCreatetimeLessThan());
		}
		if(CheckUtil.isNotEmpty(getCreatetimeIsNull()) && this.getCreatetimeIsNull()){
			c.andCreatetimeIsNull();
		}
		if(CheckUtil.isNotEmpty(getCreatetimeIsNotNull()) && this.getCreatetimeIsNotNull()){
			c.andCreatetimeIsNotNull();
		}
		if(CheckUtil.isNotEmpty(getCreatetimeIn())){
			c.andCreatetimeIn(this.getCreatetimeIn());
		}
		if(CheckUtil.isNotEmpty(getCreatetimeGreaterThanOrEqualTo())){
			c.andCreatetimeGreaterThanOrEqualTo(this.getCreatetimeGreaterThanOrEqualTo());
		}
		if(CheckUtil.isNotEmpty(getCreatetimeGreaterThan())){
			c.andCreatetimeGreaterThan(this.getCreatetimeGreaterThan());
		}
		if(CheckUtil.isNotEmpty(getCreatetimeEqualTo())){
			c.andCreatetimeEqualTo(this.getCreatetimeEqualTo());
		}
		if((this.getSidx()!=null && !this.getSidx().trim().equals("")) && this.getSord()!=null) {
			q.setOrderByClause(""+ this.getSidx()+" "+this.getSord());
		}
		return q;
	}
	public String getUpdateuserNotLike() {
		return updateuserNotLike;
	}
	public void setUpdateuserNotLike(String updateuserNotLike) {
		this.updateuserNotLike = updateuserNotLike;
	}

	public java.util.List getUpdateuserNotIn() {
		return updateuserNotIn;
	}
	public void setUpdateuserNotIn(java.util.List updateuserNotIn) {
		this.updateuserNotIn = updateuserNotIn;
	}

	public String getUpdateuserNotEqualTo() {
		return updateuserNotEqualTo;
	}
	public void setUpdateuserNotEqualTo(String updateuserNotEqualTo) {
		this.updateuserNotEqualTo = updateuserNotEqualTo;
	}

	public String getUpdateuserLike() {
		return updateuserLike;
	}
	public void setUpdateuserLike(String updateuserLike) {
		this.updateuserLike = updateuserLike;
	}

	public String getUpdateuserLessThanOrEqualTo() {
		return updateuserLessThanOrEqualTo;
	}
	public void setUpdateuserLessThanOrEqualTo(String updateuserLessThanOrEqualTo) {
		this.updateuserLessThanOrEqualTo = updateuserLessThanOrEqualTo;
	}

	public String getUpdateuserLessThan() {
		return updateuserLessThan;
	}
	public void setUpdateuserLessThan(String updateuserLessThan) {
		this.updateuserLessThan = updateuserLessThan;
	}

	public Boolean getUpdateuserIsNull() {
		return updateuserIsNull;
	}
	public void setUpdateuserIsNull(Boolean updateuserIsNull) {
		this.updateuserIsNull = updateuserIsNull;
	}

	public Boolean getUpdateuserIsNotNull() {
		return updateuserIsNotNull;
	}
	public void setUpdateuserIsNotNull(Boolean updateuserIsNotNull) {
		this.updateuserIsNotNull = updateuserIsNotNull;
	}

	public java.util.List getUpdateuserIn() {
		return updateuserIn;
	}
	public void setUpdateuserIn(java.util.List updateuserIn) {
		this.updateuserIn = updateuserIn;
	}

	public String getUpdateuserGreaterThanOrEqualTo() {
		return updateuserGreaterThanOrEqualTo;
	}
	public void setUpdateuserGreaterThanOrEqualTo(String updateuserGreaterThanOrEqualTo) {
		this.updateuserGreaterThanOrEqualTo = updateuserGreaterThanOrEqualTo;
	}

	public String getUpdateuserGreaterThan() {
		return updateuserGreaterThan;
	}
	public void setUpdateuserGreaterThan(String updateuserGreaterThan) {
		this.updateuserGreaterThan = updateuserGreaterThan;
	}

	public String getUpdateuserEqualTo() {
		return updateuserEqualTo;
	}
	public void setUpdateuserEqualTo(String updateuserEqualTo) {
		this.updateuserEqualTo = updateuserEqualTo;
	}

	public java.util.List getUpdatetimeNotIn() {
		return updatetimeNotIn;
	}
	public void setUpdatetimeNotIn(java.util.List updatetimeNotIn) {
		this.updatetimeNotIn = updatetimeNotIn;
	}

	public java.util.Date getUpdatetimeNotEqualTo() {
		return updatetimeNotEqualTo;
	}
	public void setUpdatetimeNotEqualTo(java.util.Date updatetimeNotEqualTo) {
		this.updatetimeNotEqualTo = updatetimeNotEqualTo;
	}

	public java.util.Date getUpdatetimeLessThanOrEqualTo() {
		return updatetimeLessThanOrEqualTo;
	}
	public void setUpdatetimeLessThanOrEqualTo(java.util.Date updatetimeLessThanOrEqualTo) {
		this.updatetimeLessThanOrEqualTo = updatetimeLessThanOrEqualTo;
	}

	public java.util.Date getUpdatetimeLessThan() {
		return updatetimeLessThan;
	}
	public void setUpdatetimeLessThan(java.util.Date updatetimeLessThan) {
		this.updatetimeLessThan = updatetimeLessThan;
	}

	public Boolean getUpdatetimeIsNull() {
		return updatetimeIsNull;
	}
	public void setUpdatetimeIsNull(Boolean updatetimeIsNull) {
		this.updatetimeIsNull = updatetimeIsNull;
	}

	public Boolean getUpdatetimeIsNotNull() {
		return updatetimeIsNotNull;
	}
	public void setUpdatetimeIsNotNull(Boolean updatetimeIsNotNull) {
		this.updatetimeIsNotNull = updatetimeIsNotNull;
	}

	public java.util.List getUpdatetimeIn() {
		return updatetimeIn;
	}
	public void setUpdatetimeIn(java.util.List updatetimeIn) {
		this.updatetimeIn = updatetimeIn;
	}

	public java.util.Date getUpdatetimeGreaterThanOrEqualTo() {
		return updatetimeGreaterThanOrEqualTo;
	}
	public void setUpdatetimeGreaterThanOrEqualTo(java.util.Date updatetimeGreaterThanOrEqualTo) {
		this.updatetimeGreaterThanOrEqualTo = updatetimeGreaterThanOrEqualTo;
	}

	public java.util.Date getUpdatetimeGreaterThan() {
		return updatetimeGreaterThan;
	}
	public void setUpdatetimeGreaterThan(java.util.Date updatetimeGreaterThan) {
		this.updatetimeGreaterThan = updatetimeGreaterThan;
	}

	public java.util.Date getUpdatetimeEqualTo() {
		return updatetimeEqualTo;
	}
	public void setUpdatetimeEqualTo(java.util.Date updatetimeEqualTo) {
		this.updatetimeEqualTo = updatetimeEqualTo;
	}

	public String getRemarkNotLike() {
		return remarkNotLike;
	}
	public void setRemarkNotLike(String remarkNotLike) {
		this.remarkNotLike = remarkNotLike;
	}

	public java.util.List getRemarkNotIn() {
		return remarkNotIn;
	}
	public void setRemarkNotIn(java.util.List remarkNotIn) {
		this.remarkNotIn = remarkNotIn;
	}

	public String getRemarkNotEqualTo() {
		return remarkNotEqualTo;
	}
	public void setRemarkNotEqualTo(String remarkNotEqualTo) {
		this.remarkNotEqualTo = remarkNotEqualTo;
	}

	public String getRemarkLike() {
		return remarkLike;
	}
	public void setRemarkLike(String remarkLike) {
		this.remarkLike = remarkLike;
	}

	public String getRemarkLessThanOrEqualTo() {
		return remarkLessThanOrEqualTo;
	}
	public void setRemarkLessThanOrEqualTo(String remarkLessThanOrEqualTo) {
		this.remarkLessThanOrEqualTo = remarkLessThanOrEqualTo;
	}

	public String getRemarkLessThan() {
		return remarkLessThan;
	}
	public void setRemarkLessThan(String remarkLessThan) {
		this.remarkLessThan = remarkLessThan;
	}

	public Boolean getRemarkIsNull() {
		return remarkIsNull;
	}
	public void setRemarkIsNull(Boolean remarkIsNull) {
		this.remarkIsNull = remarkIsNull;
	}

	public Boolean getRemarkIsNotNull() {
		return remarkIsNotNull;
	}
	public void setRemarkIsNotNull(Boolean remarkIsNotNull) {
		this.remarkIsNotNull = remarkIsNotNull;
	}

	public java.util.List getRemarkIn() {
		return remarkIn;
	}
	public void setRemarkIn(java.util.List remarkIn) {
		this.remarkIn = remarkIn;
	}

	public String getRemarkGreaterThanOrEqualTo() {
		return remarkGreaterThanOrEqualTo;
	}
	public void setRemarkGreaterThanOrEqualTo(String remarkGreaterThanOrEqualTo) {
		this.remarkGreaterThanOrEqualTo = remarkGreaterThanOrEqualTo;
	}

	public String getRemarkGreaterThan() {
		return remarkGreaterThan;
	}
	public void setRemarkGreaterThan(String remarkGreaterThan) {
		this.remarkGreaterThan = remarkGreaterThan;
	}

	public String getRemarkEqualTo() {
		return remarkEqualTo;
	}
	public void setRemarkEqualTo(String remarkEqualTo) {
		this.remarkEqualTo = remarkEqualTo;
	}

	public java.util.List getFbmUnpayAmountNotIn() {
		return fbmUnpayAmountNotIn;
	}
	public void setFbmUnpayAmountNotIn(java.util.List fbmUnpayAmountNotIn) {
		this.fbmUnpayAmountNotIn = fbmUnpayAmountNotIn;
	}

	public Double getFbmUnpayAmountNotEqualTo() {
		return fbmUnpayAmountNotEqualTo;
	}
	public void setFbmUnpayAmountNotEqualTo(Double fbmUnpayAmountNotEqualTo) {
		this.fbmUnpayAmountNotEqualTo = fbmUnpayAmountNotEqualTo;
	}

	public Double getFbmUnpayAmountLessThanOrEqualTo() {
		return fbmUnpayAmountLessThanOrEqualTo;
	}
	public void setFbmUnpayAmountLessThanOrEqualTo(Double fbmUnpayAmountLessThanOrEqualTo) {
		this.fbmUnpayAmountLessThanOrEqualTo = fbmUnpayAmountLessThanOrEqualTo;
	}

	public Double getFbmUnpayAmountLessThan() {
		return fbmUnpayAmountLessThan;
	}
	public void setFbmUnpayAmountLessThan(Double fbmUnpayAmountLessThan) {
		this.fbmUnpayAmountLessThan = fbmUnpayAmountLessThan;
	}

	public Boolean getFbmUnpayAmountIsNull() {
		return fbmUnpayAmountIsNull;
	}
	public void setFbmUnpayAmountIsNull(Boolean fbmUnpayAmountIsNull) {
		this.fbmUnpayAmountIsNull = fbmUnpayAmountIsNull;
	}

	public Boolean getFbmUnpayAmountIsNotNull() {
		return fbmUnpayAmountIsNotNull;
	}
	public void setFbmUnpayAmountIsNotNull(Boolean fbmUnpayAmountIsNotNull) {
		this.fbmUnpayAmountIsNotNull = fbmUnpayAmountIsNotNull;
	}

	public java.util.List getFbmUnpayAmountIn() {
		return fbmUnpayAmountIn;
	}
	public void setFbmUnpayAmountIn(java.util.List fbmUnpayAmountIn) {
		this.fbmUnpayAmountIn = fbmUnpayAmountIn;
	}

	public Double getFbmUnpayAmountGreaterThanOrEqualTo() {
		return fbmUnpayAmountGreaterThanOrEqualTo;
	}
	public void setFbmUnpayAmountGreaterThanOrEqualTo(Double fbmUnpayAmountGreaterThanOrEqualTo) {
		this.fbmUnpayAmountGreaterThanOrEqualTo = fbmUnpayAmountGreaterThanOrEqualTo;
	}

	public Double getFbmUnpayAmountGreaterThan() {
		return fbmUnpayAmountGreaterThan;
	}
	public void setFbmUnpayAmountGreaterThan(Double fbmUnpayAmountGreaterThan) {
		this.fbmUnpayAmountGreaterThan = fbmUnpayAmountGreaterThan;
	}

	public Double getFbmUnpayAmountEqualTo() {
		return fbmUnpayAmountEqualTo;
	}
	public void setFbmUnpayAmountEqualTo(Double fbmUnpayAmountEqualTo) {
		this.fbmUnpayAmountEqualTo = fbmUnpayAmountEqualTo;
	}

	public java.util.List getFbmUnRefundAmountNotIn() {
		return fbmUnRefundAmountNotIn;
	}
	public void setFbmUnRefundAmountNotIn(java.util.List fbmUnRefundAmountNotIn) {
		this.fbmUnRefundAmountNotIn = fbmUnRefundAmountNotIn;
	}

	public Double getFbmUnRefundAmountNotEqualTo() {
		return fbmUnRefundAmountNotEqualTo;
	}
	public void setFbmUnRefundAmountNotEqualTo(Double fbmUnRefundAmountNotEqualTo) {
		this.fbmUnRefundAmountNotEqualTo = fbmUnRefundAmountNotEqualTo;
	}

	public Double getFbmUnRefundAmountLessThanOrEqualTo() {
		return fbmUnRefundAmountLessThanOrEqualTo;
	}
	public void setFbmUnRefundAmountLessThanOrEqualTo(Double fbmUnRefundAmountLessThanOrEqualTo) {
		this.fbmUnRefundAmountLessThanOrEqualTo = fbmUnRefundAmountLessThanOrEqualTo;
	}

	public Double getFbmUnRefundAmountLessThan() {
		return fbmUnRefundAmountLessThan;
	}
	public void setFbmUnRefundAmountLessThan(Double fbmUnRefundAmountLessThan) {
		this.fbmUnRefundAmountLessThan = fbmUnRefundAmountLessThan;
	}

	public Boolean getFbmUnRefundAmountIsNull() {
		return fbmUnRefundAmountIsNull;
	}
	public void setFbmUnRefundAmountIsNull(Boolean fbmUnRefundAmountIsNull) {
		this.fbmUnRefundAmountIsNull = fbmUnRefundAmountIsNull;
	}

	public Boolean getFbmUnRefundAmountIsNotNull() {
		return fbmUnRefundAmountIsNotNull;
	}
	public void setFbmUnRefundAmountIsNotNull(Boolean fbmUnRefundAmountIsNotNull) {
		this.fbmUnRefundAmountIsNotNull = fbmUnRefundAmountIsNotNull;
	}

	public java.util.List getFbmUnRefundAmountIn() {
		return fbmUnRefundAmountIn;
	}
	public void setFbmUnRefundAmountIn(java.util.List fbmUnRefundAmountIn) {
		this.fbmUnRefundAmountIn = fbmUnRefundAmountIn;
	}

	public Double getFbmUnRefundAmountGreaterThanOrEqualTo() {
		return fbmUnRefundAmountGreaterThanOrEqualTo;
	}
	public void setFbmUnRefundAmountGreaterThanOrEqualTo(Double fbmUnRefundAmountGreaterThanOrEqualTo) {
		this.fbmUnRefundAmountGreaterThanOrEqualTo = fbmUnRefundAmountGreaterThanOrEqualTo;
	}

	public Double getFbmUnRefundAmountGreaterThan() {
		return fbmUnRefundAmountGreaterThan;
	}
	public void setFbmUnRefundAmountGreaterThan(Double fbmUnRefundAmountGreaterThan) {
		this.fbmUnRefundAmountGreaterThan = fbmUnRefundAmountGreaterThan;
	}

	public Double getFbmUnRefundAmountEqualTo() {
		return fbmUnRefundAmountEqualTo;
	}
	public void setFbmUnRefundAmountEqualTo(Double fbmUnRefundAmountEqualTo) {
		this.fbmUnRefundAmountEqualTo = fbmUnRefundAmountEqualTo;
	}

	public java.util.List getFbmTurnerDealNotIn() {
		return fbmTurnerDealNotIn;
	}
	public void setFbmTurnerDealNotIn(java.util.List fbmTurnerDealNotIn) {
		this.fbmTurnerDealNotIn = fbmTurnerDealNotIn;
	}

	public Integer getFbmTurnerDealNotEqualTo() {
		return fbmTurnerDealNotEqualTo;
	}
	public void setFbmTurnerDealNotEqualTo(Integer fbmTurnerDealNotEqualTo) {
		this.fbmTurnerDealNotEqualTo = fbmTurnerDealNotEqualTo;
	}

	public Integer getFbmTurnerDealLessThanOrEqualTo() {
		return fbmTurnerDealLessThanOrEqualTo;
	}
	public void setFbmTurnerDealLessThanOrEqualTo(Integer fbmTurnerDealLessThanOrEqualTo) {
		this.fbmTurnerDealLessThanOrEqualTo = fbmTurnerDealLessThanOrEqualTo;
	}

	public Integer getFbmTurnerDealLessThan() {
		return fbmTurnerDealLessThan;
	}
	public void setFbmTurnerDealLessThan(Integer fbmTurnerDealLessThan) {
		this.fbmTurnerDealLessThan = fbmTurnerDealLessThan;
	}

	public Boolean getFbmTurnerDealIsNull() {
		return fbmTurnerDealIsNull;
	}
	public void setFbmTurnerDealIsNull(Boolean fbmTurnerDealIsNull) {
		this.fbmTurnerDealIsNull = fbmTurnerDealIsNull;
	}

	public Boolean getFbmTurnerDealIsNotNull() {
		return fbmTurnerDealIsNotNull;
	}
	public void setFbmTurnerDealIsNotNull(Boolean fbmTurnerDealIsNotNull) {
		this.fbmTurnerDealIsNotNull = fbmTurnerDealIsNotNull;
	}

	public java.util.List getFbmTurnerDealIn() {
		return fbmTurnerDealIn;
	}
	public void setFbmTurnerDealIn(java.util.List fbmTurnerDealIn) {
		this.fbmTurnerDealIn = fbmTurnerDealIn;
	}

	public Integer getFbmTurnerDealGreaterThanOrEqualTo() {
		return fbmTurnerDealGreaterThanOrEqualTo;
	}
	public void setFbmTurnerDealGreaterThanOrEqualTo(Integer fbmTurnerDealGreaterThanOrEqualTo) {
		this.fbmTurnerDealGreaterThanOrEqualTo = fbmTurnerDealGreaterThanOrEqualTo;
	}

	public Integer getFbmTurnerDealGreaterThan() {
		return fbmTurnerDealGreaterThan;
	}
	public void setFbmTurnerDealGreaterThan(Integer fbmTurnerDealGreaterThan) {
		this.fbmTurnerDealGreaterThan = fbmTurnerDealGreaterThan;
	}

	public Integer getFbmTurnerDealEqualTo() {
		return fbmTurnerDealEqualTo;
	}
	public void setFbmTurnerDealEqualTo(Integer fbmTurnerDealEqualTo) {
		this.fbmTurnerDealEqualTo = fbmTurnerDealEqualTo;
	}

	public java.util.List getFbmSubjectsNotIn() {
		return fbmSubjectsNotIn;
	}
	public void setFbmSubjectsNotIn(java.util.List fbmSubjectsNotIn) {
		this.fbmSubjectsNotIn = fbmSubjectsNotIn;
	}

	public Integer getFbmSubjectsNotEqualTo() {
		return fbmSubjectsNotEqualTo;
	}
	public void setFbmSubjectsNotEqualTo(Integer fbmSubjectsNotEqualTo) {
		this.fbmSubjectsNotEqualTo = fbmSubjectsNotEqualTo;
	}

	public Integer getFbmSubjectsLessThanOrEqualTo() {
		return fbmSubjectsLessThanOrEqualTo;
	}
	public void setFbmSubjectsLessThanOrEqualTo(Integer fbmSubjectsLessThanOrEqualTo) {
		this.fbmSubjectsLessThanOrEqualTo = fbmSubjectsLessThanOrEqualTo;
	}

	public Integer getFbmSubjectsLessThan() {
		return fbmSubjectsLessThan;
	}
	public void setFbmSubjectsLessThan(Integer fbmSubjectsLessThan) {
		this.fbmSubjectsLessThan = fbmSubjectsLessThan;
	}

	public Boolean getFbmSubjectsIsNull() {
		return fbmSubjectsIsNull;
	}
	public void setFbmSubjectsIsNull(Boolean fbmSubjectsIsNull) {
		this.fbmSubjectsIsNull = fbmSubjectsIsNull;
	}

	public Boolean getFbmSubjectsIsNotNull() {
		return fbmSubjectsIsNotNull;
	}
	public void setFbmSubjectsIsNotNull(Boolean fbmSubjectsIsNotNull) {
		this.fbmSubjectsIsNotNull = fbmSubjectsIsNotNull;
	}

	public java.util.List getFbmSubjectsIn() {
		return fbmSubjectsIn;
	}
	public void setFbmSubjectsIn(java.util.List fbmSubjectsIn) {
		this.fbmSubjectsIn = fbmSubjectsIn;
	}

	public Integer getFbmSubjectsGreaterThanOrEqualTo() {
		return fbmSubjectsGreaterThanOrEqualTo;
	}
	public void setFbmSubjectsGreaterThanOrEqualTo(Integer fbmSubjectsGreaterThanOrEqualTo) {
		this.fbmSubjectsGreaterThanOrEqualTo = fbmSubjectsGreaterThanOrEqualTo;
	}

	public Integer getFbmSubjectsGreaterThan() {
		return fbmSubjectsGreaterThan;
	}
	public void setFbmSubjectsGreaterThan(Integer fbmSubjectsGreaterThan) {
		this.fbmSubjectsGreaterThan = fbmSubjectsGreaterThan;
	}

	public Integer getFbmSubjectsEqualTo() {
		return fbmSubjectsEqualTo;
	}
	public void setFbmSubjectsEqualTo(Integer fbmSubjectsEqualTo) {
		this.fbmSubjectsEqualTo = fbmSubjectsEqualTo;
	}

	public java.util.List getFbmRefundAmountNotIn() {
		return fbmRefundAmountNotIn;
	}
	public void setFbmRefundAmountNotIn(java.util.List fbmRefundAmountNotIn) {
		this.fbmRefundAmountNotIn = fbmRefundAmountNotIn;
	}

	public Double getFbmRefundAmountNotEqualTo() {
		return fbmRefundAmountNotEqualTo;
	}
	public void setFbmRefundAmountNotEqualTo(Double fbmRefundAmountNotEqualTo) {
		this.fbmRefundAmountNotEqualTo = fbmRefundAmountNotEqualTo;
	}

	public Double getFbmRefundAmountLessThanOrEqualTo() {
		return fbmRefundAmountLessThanOrEqualTo;
	}
	public void setFbmRefundAmountLessThanOrEqualTo(Double fbmRefundAmountLessThanOrEqualTo) {
		this.fbmRefundAmountLessThanOrEqualTo = fbmRefundAmountLessThanOrEqualTo;
	}

	public Double getFbmRefundAmountLessThan() {
		return fbmRefundAmountLessThan;
	}
	public void setFbmRefundAmountLessThan(Double fbmRefundAmountLessThan) {
		this.fbmRefundAmountLessThan = fbmRefundAmountLessThan;
	}

	public Boolean getFbmRefundAmountIsNull() {
		return fbmRefundAmountIsNull;
	}
	public void setFbmRefundAmountIsNull(Boolean fbmRefundAmountIsNull) {
		this.fbmRefundAmountIsNull = fbmRefundAmountIsNull;
	}

	public Boolean getFbmRefundAmountIsNotNull() {
		return fbmRefundAmountIsNotNull;
	}
	public void setFbmRefundAmountIsNotNull(Boolean fbmRefundAmountIsNotNull) {
		this.fbmRefundAmountIsNotNull = fbmRefundAmountIsNotNull;
	}

	public java.util.List getFbmRefundAmountIn() {
		return fbmRefundAmountIn;
	}
	public void setFbmRefundAmountIn(java.util.List fbmRefundAmountIn) {
		this.fbmRefundAmountIn = fbmRefundAmountIn;
	}

	public Double getFbmRefundAmountGreaterThanOrEqualTo() {
		return fbmRefundAmountGreaterThanOrEqualTo;
	}
	public void setFbmRefundAmountGreaterThanOrEqualTo(Double fbmRefundAmountGreaterThanOrEqualTo) {
		this.fbmRefundAmountGreaterThanOrEqualTo = fbmRefundAmountGreaterThanOrEqualTo;
	}

	public Double getFbmRefundAmountGreaterThan() {
		return fbmRefundAmountGreaterThan;
	}
	public void setFbmRefundAmountGreaterThan(Double fbmRefundAmountGreaterThan) {
		this.fbmRefundAmountGreaterThan = fbmRefundAmountGreaterThan;
	}

	public Double getFbmRefundAmountEqualTo() {
		return fbmRefundAmountEqualTo;
	}
	public void setFbmRefundAmountEqualTo(Double fbmRefundAmountEqualTo) {
		this.fbmRefundAmountEqualTo = fbmRefundAmountEqualTo;
	}

	public java.util.List getFbmPayTimeNotIn() {
		return fbmPayTimeNotIn;
	}
	public void setFbmPayTimeNotIn(java.util.List fbmPayTimeNotIn) {
		this.fbmPayTimeNotIn = fbmPayTimeNotIn;
	}

	public java.util.Date getFbmPayTimeNotEqualTo() {
		return fbmPayTimeNotEqualTo;
	}
	public void setFbmPayTimeNotEqualTo(java.util.Date fbmPayTimeNotEqualTo) {
		this.fbmPayTimeNotEqualTo = fbmPayTimeNotEqualTo;
	}

	public java.util.Date getFbmPayTimeLessThanOrEqualTo() {
		return fbmPayTimeLessThanOrEqualTo;
	}
	public void setFbmPayTimeLessThanOrEqualTo(java.util.Date fbmPayTimeLessThanOrEqualTo) {
		this.fbmPayTimeLessThanOrEqualTo = fbmPayTimeLessThanOrEqualTo;
	}

	public java.util.Date getFbmPayTimeLessThan() {
		return fbmPayTimeLessThan;
	}
	public void setFbmPayTimeLessThan(java.util.Date fbmPayTimeLessThan) {
		this.fbmPayTimeLessThan = fbmPayTimeLessThan;
	}

	public Boolean getFbmPayTimeIsNull() {
		return fbmPayTimeIsNull;
	}
	public void setFbmPayTimeIsNull(Boolean fbmPayTimeIsNull) {
		this.fbmPayTimeIsNull = fbmPayTimeIsNull;
	}

	public Boolean getFbmPayTimeIsNotNull() {
		return fbmPayTimeIsNotNull;
	}
	public void setFbmPayTimeIsNotNull(Boolean fbmPayTimeIsNotNull) {
		this.fbmPayTimeIsNotNull = fbmPayTimeIsNotNull;
	}

	public java.util.List getFbmPayTimeIn() {
		return fbmPayTimeIn;
	}
	public void setFbmPayTimeIn(java.util.List fbmPayTimeIn) {
		this.fbmPayTimeIn = fbmPayTimeIn;
	}

	public java.util.Date getFbmPayTimeGreaterThanOrEqualTo() {
		return fbmPayTimeGreaterThanOrEqualTo;
	}
	public void setFbmPayTimeGreaterThanOrEqualTo(java.util.Date fbmPayTimeGreaterThanOrEqualTo) {
		this.fbmPayTimeGreaterThanOrEqualTo = fbmPayTimeGreaterThanOrEqualTo;
	}

	public java.util.Date getFbmPayTimeGreaterThan() {
		return fbmPayTimeGreaterThan;
	}
	public void setFbmPayTimeGreaterThan(java.util.Date fbmPayTimeGreaterThan) {
		this.fbmPayTimeGreaterThan = fbmPayTimeGreaterThan;
	}

	public java.util.Date getFbmPayTimeEqualTo() {
		return fbmPayTimeEqualTo;
	}
	public void setFbmPayTimeEqualTo(java.util.Date fbmPayTimeEqualTo) {
		this.fbmPayTimeEqualTo = fbmPayTimeEqualTo;
	}

	public java.util.List getFbmPayAmonutNotIn() {
		return fbmPayAmonutNotIn;
	}
	public void setFbmPayAmonutNotIn(java.util.List fbmPayAmonutNotIn) {
		this.fbmPayAmonutNotIn = fbmPayAmonutNotIn;
	}

	public Double getFbmPayAmonutNotEqualTo() {
		return fbmPayAmonutNotEqualTo;
	}
	public void setFbmPayAmonutNotEqualTo(Double fbmPayAmonutNotEqualTo) {
		this.fbmPayAmonutNotEqualTo = fbmPayAmonutNotEqualTo;
	}

	public Double getFbmPayAmonutLessThanOrEqualTo() {
		return fbmPayAmonutLessThanOrEqualTo;
	}
	public void setFbmPayAmonutLessThanOrEqualTo(Double fbmPayAmonutLessThanOrEqualTo) {
		this.fbmPayAmonutLessThanOrEqualTo = fbmPayAmonutLessThanOrEqualTo;
	}

	public Double getFbmPayAmonutLessThan() {
		return fbmPayAmonutLessThan;
	}
	public void setFbmPayAmonutLessThan(Double fbmPayAmonutLessThan) {
		this.fbmPayAmonutLessThan = fbmPayAmonutLessThan;
	}

	public Boolean getFbmPayAmonutIsNull() {
		return fbmPayAmonutIsNull;
	}
	public void setFbmPayAmonutIsNull(Boolean fbmPayAmonutIsNull) {
		this.fbmPayAmonutIsNull = fbmPayAmonutIsNull;
	}

	public Boolean getFbmPayAmonutIsNotNull() {
		return fbmPayAmonutIsNotNull;
	}
	public void setFbmPayAmonutIsNotNull(Boolean fbmPayAmonutIsNotNull) {
		this.fbmPayAmonutIsNotNull = fbmPayAmonutIsNotNull;
	}

	public java.util.List getFbmPayAmonutIn() {
		return fbmPayAmonutIn;
	}
	public void setFbmPayAmonutIn(java.util.List fbmPayAmonutIn) {
		this.fbmPayAmonutIn = fbmPayAmonutIn;
	}

	public Double getFbmPayAmonutGreaterThanOrEqualTo() {
		return fbmPayAmonutGreaterThanOrEqualTo;
	}
	public void setFbmPayAmonutGreaterThanOrEqualTo(Double fbmPayAmonutGreaterThanOrEqualTo) {
		this.fbmPayAmonutGreaterThanOrEqualTo = fbmPayAmonutGreaterThanOrEqualTo;
	}

	public Double getFbmPayAmonutGreaterThan() {
		return fbmPayAmonutGreaterThan;
	}
	public void setFbmPayAmonutGreaterThan(Double fbmPayAmonutGreaterThan) {
		this.fbmPayAmonutGreaterThan = fbmPayAmonutGreaterThan;
	}

	public Double getFbmPayAmonutEqualTo() {
		return fbmPayAmonutEqualTo;
	}
	public void setFbmPayAmonutEqualTo(Double fbmPayAmonutEqualTo) {
		this.fbmPayAmonutEqualTo = fbmPayAmonutEqualTo;
	}

	public java.util.List getFbmOverdueStateNotIn() {
		return fbmOverdueStateNotIn;
	}
	public void setFbmOverdueStateNotIn(java.util.List fbmOverdueStateNotIn) {
		this.fbmOverdueStateNotIn = fbmOverdueStateNotIn;
	}

	public Integer getFbmOverdueStateNotEqualTo() {
		return fbmOverdueStateNotEqualTo;
	}
	public void setFbmOverdueStateNotEqualTo(Integer fbmOverdueStateNotEqualTo) {
		this.fbmOverdueStateNotEqualTo = fbmOverdueStateNotEqualTo;
	}

	public Integer getFbmOverdueStateLessThanOrEqualTo() {
		return fbmOverdueStateLessThanOrEqualTo;
	}
	public void setFbmOverdueStateLessThanOrEqualTo(Integer fbmOverdueStateLessThanOrEqualTo) {
		this.fbmOverdueStateLessThanOrEqualTo = fbmOverdueStateLessThanOrEqualTo;
	}

	public Integer getFbmOverdueStateLessThan() {
		return fbmOverdueStateLessThan;
	}
	public void setFbmOverdueStateLessThan(Integer fbmOverdueStateLessThan) {
		this.fbmOverdueStateLessThan = fbmOverdueStateLessThan;
	}

	public Boolean getFbmOverdueStateIsNull() {
		return fbmOverdueStateIsNull;
	}
	public void setFbmOverdueStateIsNull(Boolean fbmOverdueStateIsNull) {
		this.fbmOverdueStateIsNull = fbmOverdueStateIsNull;
	}

	public Boolean getFbmOverdueStateIsNotNull() {
		return fbmOverdueStateIsNotNull;
	}
	public void setFbmOverdueStateIsNotNull(Boolean fbmOverdueStateIsNotNull) {
		this.fbmOverdueStateIsNotNull = fbmOverdueStateIsNotNull;
	}

	public java.util.List getFbmOverdueStateIn() {
		return fbmOverdueStateIn;
	}
	public void setFbmOverdueStateIn(java.util.List fbmOverdueStateIn) {
		this.fbmOverdueStateIn = fbmOverdueStateIn;
	}

	public Integer getFbmOverdueStateGreaterThanOrEqualTo() {
		return fbmOverdueStateGreaterThanOrEqualTo;
	}
	public void setFbmOverdueStateGreaterThanOrEqualTo(Integer fbmOverdueStateGreaterThanOrEqualTo) {
		this.fbmOverdueStateGreaterThanOrEqualTo = fbmOverdueStateGreaterThanOrEqualTo;
	}

	public Integer getFbmOverdueStateGreaterThan() {
		return fbmOverdueStateGreaterThan;
	}
	public void setFbmOverdueStateGreaterThan(Integer fbmOverdueStateGreaterThan) {
		this.fbmOverdueStateGreaterThan = fbmOverdueStateGreaterThan;
	}

	public Integer getFbmOverdueStateEqualTo() {
		return fbmOverdueStateEqualTo;
	}
	public void setFbmOverdueStateEqualTo(Integer fbmOverdueStateEqualTo) {
		this.fbmOverdueStateEqualTo = fbmOverdueStateEqualTo;
	}

	public String getFbmNperNotLike() {
		return fbmNperNotLike;
	}
	public void setFbmNperNotLike(String fbmNperNotLike) {
		this.fbmNperNotLike = fbmNperNotLike;
	}

	public java.util.List getFbmNperNotIn() {
		return fbmNperNotIn;
	}
	public void setFbmNperNotIn(java.util.List fbmNperNotIn) {
		this.fbmNperNotIn = fbmNperNotIn;
	}

	public String getFbmNperNotEqualTo() {
		return fbmNperNotEqualTo;
	}
	public void setFbmNperNotEqualTo(String fbmNperNotEqualTo) {
		this.fbmNperNotEqualTo = fbmNperNotEqualTo;
	}

	public String getFbmNperLike() {
		return fbmNperLike;
	}
	public void setFbmNperLike(String fbmNperLike) {
		this.fbmNperLike = fbmNperLike;
	}

	public String getFbmNperLessThanOrEqualTo() {
		return fbmNperLessThanOrEqualTo;
	}
	public void setFbmNperLessThanOrEqualTo(String fbmNperLessThanOrEqualTo) {
		this.fbmNperLessThanOrEqualTo = fbmNperLessThanOrEqualTo;
	}

	public String getFbmNperLessThan() {
		return fbmNperLessThan;
	}
	public void setFbmNperLessThan(String fbmNperLessThan) {
		this.fbmNperLessThan = fbmNperLessThan;
	}

	public Boolean getFbmNperIsNull() {
		return fbmNperIsNull;
	}
	public void setFbmNperIsNull(Boolean fbmNperIsNull) {
		this.fbmNperIsNull = fbmNperIsNull;
	}

	public Boolean getFbmNperIsNotNull() {
		return fbmNperIsNotNull;
	}
	public void setFbmNperIsNotNull(Boolean fbmNperIsNotNull) {
		this.fbmNperIsNotNull = fbmNperIsNotNull;
	}

	public java.util.List getFbmNperIn() {
		return fbmNperIn;
	}
	public void setFbmNperIn(java.util.List fbmNperIn) {
		this.fbmNperIn = fbmNperIn;
	}

	public String getFbmNperGreaterThanOrEqualTo() {
		return fbmNperGreaterThanOrEqualTo;
	}
	public void setFbmNperGreaterThanOrEqualTo(String fbmNperGreaterThanOrEqualTo) {
		this.fbmNperGreaterThanOrEqualTo = fbmNperGreaterThanOrEqualTo;
	}

	public String getFbmNperGreaterThan() {
		return fbmNperGreaterThan;
	}
	public void setFbmNperGreaterThan(String fbmNperGreaterThan) {
		this.fbmNperGreaterThan = fbmNperGreaterThan;
	}

	public String getFbmNperEqualTo() {
		return fbmNperEqualTo;
	}
	public void setFbmNperEqualTo(String fbmNperEqualTo) {
		this.fbmNperEqualTo = fbmNperEqualTo;
	}

	public java.util.List getFbmNotMatchAmountNotIn() {
		return fbmNotMatchAmountNotIn;
	}
	public void setFbmNotMatchAmountNotIn(java.util.List fbmNotMatchAmountNotIn) {
		this.fbmNotMatchAmountNotIn = fbmNotMatchAmountNotIn;
	}

	public Double getFbmNotMatchAmountNotEqualTo() {
		return fbmNotMatchAmountNotEqualTo;
	}
	public void setFbmNotMatchAmountNotEqualTo(Double fbmNotMatchAmountNotEqualTo) {
		this.fbmNotMatchAmountNotEqualTo = fbmNotMatchAmountNotEqualTo;
	}

	public Double getFbmNotMatchAmountLessThanOrEqualTo() {
		return fbmNotMatchAmountLessThanOrEqualTo;
	}
	public void setFbmNotMatchAmountLessThanOrEqualTo(Double fbmNotMatchAmountLessThanOrEqualTo) {
		this.fbmNotMatchAmountLessThanOrEqualTo = fbmNotMatchAmountLessThanOrEqualTo;
	}

	public Double getFbmNotMatchAmountLessThan() {
		return fbmNotMatchAmountLessThan;
	}
	public void setFbmNotMatchAmountLessThan(Double fbmNotMatchAmountLessThan) {
		this.fbmNotMatchAmountLessThan = fbmNotMatchAmountLessThan;
	}

	public Boolean getFbmNotMatchAmountIsNull() {
		return fbmNotMatchAmountIsNull;
	}
	public void setFbmNotMatchAmountIsNull(Boolean fbmNotMatchAmountIsNull) {
		this.fbmNotMatchAmountIsNull = fbmNotMatchAmountIsNull;
	}

	public Boolean getFbmNotMatchAmountIsNotNull() {
		return fbmNotMatchAmountIsNotNull;
	}
	public void setFbmNotMatchAmountIsNotNull(Boolean fbmNotMatchAmountIsNotNull) {
		this.fbmNotMatchAmountIsNotNull = fbmNotMatchAmountIsNotNull;
	}

	public java.util.List getFbmNotMatchAmountIn() {
		return fbmNotMatchAmountIn;
	}
	public void setFbmNotMatchAmountIn(java.util.List fbmNotMatchAmountIn) {
		this.fbmNotMatchAmountIn = fbmNotMatchAmountIn;
	}

	public Double getFbmNotMatchAmountGreaterThanOrEqualTo() {
		return fbmNotMatchAmountGreaterThanOrEqualTo;
	}
	public void setFbmNotMatchAmountGreaterThanOrEqualTo(Double fbmNotMatchAmountGreaterThanOrEqualTo) {
		this.fbmNotMatchAmountGreaterThanOrEqualTo = fbmNotMatchAmountGreaterThanOrEqualTo;
	}

	public Double getFbmNotMatchAmountGreaterThan() {
		return fbmNotMatchAmountGreaterThan;
	}
	public void setFbmNotMatchAmountGreaterThan(Double fbmNotMatchAmountGreaterThan) {
		this.fbmNotMatchAmountGreaterThan = fbmNotMatchAmountGreaterThan;
	}

	public Double getFbmNotMatchAmountEqualTo() {
		return fbmNotMatchAmountEqualTo;
	}
	public void setFbmNotMatchAmountEqualTo(Double fbmNotMatchAmountEqualTo) {
		this.fbmNotMatchAmountEqualTo = fbmNotMatchAmountEqualTo;
	}

	public java.util.List getFbmMatchedAmountNotIn() {
		return fbmMatchedAmountNotIn;
	}
	public void setFbmMatchedAmountNotIn(java.util.List fbmMatchedAmountNotIn) {
		this.fbmMatchedAmountNotIn = fbmMatchedAmountNotIn;
	}

	public Double getFbmMatchedAmountNotEqualTo() {
		return fbmMatchedAmountNotEqualTo;
	}
	public void setFbmMatchedAmountNotEqualTo(Double fbmMatchedAmountNotEqualTo) {
		this.fbmMatchedAmountNotEqualTo = fbmMatchedAmountNotEqualTo;
	}

	public Double getFbmMatchedAmountLessThanOrEqualTo() {
		return fbmMatchedAmountLessThanOrEqualTo;
	}
	public void setFbmMatchedAmountLessThanOrEqualTo(Double fbmMatchedAmountLessThanOrEqualTo) {
		this.fbmMatchedAmountLessThanOrEqualTo = fbmMatchedAmountLessThanOrEqualTo;
	}

	public Double getFbmMatchedAmountLessThan() {
		return fbmMatchedAmountLessThan;
	}
	public void setFbmMatchedAmountLessThan(Double fbmMatchedAmountLessThan) {
		this.fbmMatchedAmountLessThan = fbmMatchedAmountLessThan;
	}

	public Boolean getFbmMatchedAmountIsNull() {
		return fbmMatchedAmountIsNull;
	}
	public void setFbmMatchedAmountIsNull(Boolean fbmMatchedAmountIsNull) {
		this.fbmMatchedAmountIsNull = fbmMatchedAmountIsNull;
	}

	public Boolean getFbmMatchedAmountIsNotNull() {
		return fbmMatchedAmountIsNotNull;
	}
	public void setFbmMatchedAmountIsNotNull(Boolean fbmMatchedAmountIsNotNull) {
		this.fbmMatchedAmountIsNotNull = fbmMatchedAmountIsNotNull;
	}

	public java.util.List getFbmMatchedAmountIn() {
		return fbmMatchedAmountIn;
	}
	public void setFbmMatchedAmountIn(java.util.List fbmMatchedAmountIn) {
		this.fbmMatchedAmountIn = fbmMatchedAmountIn;
	}

	public Double getFbmMatchedAmountGreaterThanOrEqualTo() {
		return fbmMatchedAmountGreaterThanOrEqualTo;
	}
	public void setFbmMatchedAmountGreaterThanOrEqualTo(Double fbmMatchedAmountGreaterThanOrEqualTo) {
		this.fbmMatchedAmountGreaterThanOrEqualTo = fbmMatchedAmountGreaterThanOrEqualTo;
	}

	public Double getFbmMatchedAmountGreaterThan() {
		return fbmMatchedAmountGreaterThan;
	}
	public void setFbmMatchedAmountGreaterThan(Double fbmMatchedAmountGreaterThan) {
		this.fbmMatchedAmountGreaterThan = fbmMatchedAmountGreaterThan;
	}

	public Double getFbmMatchedAmountEqualTo() {
		return fbmMatchedAmountEqualTo;
	}
	public void setFbmMatchedAmountEqualTo(Double fbmMatchedAmountEqualTo) {
		this.fbmMatchedAmountEqualTo = fbmMatchedAmountEqualTo;
	}

	public java.util.List getFbmMatchWayNotIn() {
		return fbmMatchWayNotIn;
	}
	public void setFbmMatchWayNotIn(java.util.List fbmMatchWayNotIn) {
		this.fbmMatchWayNotIn = fbmMatchWayNotIn;
	}

	public Integer getFbmMatchWayNotEqualTo() {
		return fbmMatchWayNotEqualTo;
	}
	public void setFbmMatchWayNotEqualTo(Integer fbmMatchWayNotEqualTo) {
		this.fbmMatchWayNotEqualTo = fbmMatchWayNotEqualTo;
	}

	public Integer getFbmMatchWayLessThanOrEqualTo() {
		return fbmMatchWayLessThanOrEqualTo;
	}
	public void setFbmMatchWayLessThanOrEqualTo(Integer fbmMatchWayLessThanOrEqualTo) {
		this.fbmMatchWayLessThanOrEqualTo = fbmMatchWayLessThanOrEqualTo;
	}

	public Integer getFbmMatchWayLessThan() {
		return fbmMatchWayLessThan;
	}
	public void setFbmMatchWayLessThan(Integer fbmMatchWayLessThan) {
		this.fbmMatchWayLessThan = fbmMatchWayLessThan;
	}

	public Boolean getFbmMatchWayIsNull() {
		return fbmMatchWayIsNull;
	}
	public void setFbmMatchWayIsNull(Boolean fbmMatchWayIsNull) {
		this.fbmMatchWayIsNull = fbmMatchWayIsNull;
	}

	public Boolean getFbmMatchWayIsNotNull() {
		return fbmMatchWayIsNotNull;
	}
	public void setFbmMatchWayIsNotNull(Boolean fbmMatchWayIsNotNull) {
		this.fbmMatchWayIsNotNull = fbmMatchWayIsNotNull;
	}

	public java.util.List getFbmMatchWayIn() {
		return fbmMatchWayIn;
	}
	public void setFbmMatchWayIn(java.util.List fbmMatchWayIn) {
		this.fbmMatchWayIn = fbmMatchWayIn;
	}

	public Integer getFbmMatchWayGreaterThanOrEqualTo() {
		return fbmMatchWayGreaterThanOrEqualTo;
	}
	public void setFbmMatchWayGreaterThanOrEqualTo(Integer fbmMatchWayGreaterThanOrEqualTo) {
		this.fbmMatchWayGreaterThanOrEqualTo = fbmMatchWayGreaterThanOrEqualTo;
	}

	public Integer getFbmMatchWayGreaterThan() {
		return fbmMatchWayGreaterThan;
	}
	public void setFbmMatchWayGreaterThan(Integer fbmMatchWayGreaterThan) {
		this.fbmMatchWayGreaterThan = fbmMatchWayGreaterThan;
	}

	public Integer getFbmMatchWayEqualTo() {
		return fbmMatchWayEqualTo;
	}
	public void setFbmMatchWayEqualTo(Integer fbmMatchWayEqualTo) {
		this.fbmMatchWayEqualTo = fbmMatchWayEqualTo;
	}

	public java.util.List getFbmMatchUserIdNotIn() {
		return fbmMatchUserIdNotIn;
	}
	public void setFbmMatchUserIdNotIn(java.util.List fbmMatchUserIdNotIn) {
		this.fbmMatchUserIdNotIn = fbmMatchUserIdNotIn;
	}

	public Long getFbmMatchUserIdNotEqualTo() {
		return fbmMatchUserIdNotEqualTo;
	}
	public void setFbmMatchUserIdNotEqualTo(Long fbmMatchUserIdNotEqualTo) {
		this.fbmMatchUserIdNotEqualTo = fbmMatchUserIdNotEqualTo;
	}

	public Long getFbmMatchUserIdLessThanOrEqualTo() {
		return fbmMatchUserIdLessThanOrEqualTo;
	}
	public void setFbmMatchUserIdLessThanOrEqualTo(Long fbmMatchUserIdLessThanOrEqualTo) {
		this.fbmMatchUserIdLessThanOrEqualTo = fbmMatchUserIdLessThanOrEqualTo;
	}

	public Long getFbmMatchUserIdLessThan() {
		return fbmMatchUserIdLessThan;
	}
	public void setFbmMatchUserIdLessThan(Long fbmMatchUserIdLessThan) {
		this.fbmMatchUserIdLessThan = fbmMatchUserIdLessThan;
	}

	public Boolean getFbmMatchUserIdIsNull() {
		return fbmMatchUserIdIsNull;
	}
	public void setFbmMatchUserIdIsNull(Boolean fbmMatchUserIdIsNull) {
		this.fbmMatchUserIdIsNull = fbmMatchUserIdIsNull;
	}

	public Boolean getFbmMatchUserIdIsNotNull() {
		return fbmMatchUserIdIsNotNull;
	}
	public void setFbmMatchUserIdIsNotNull(Boolean fbmMatchUserIdIsNotNull) {
		this.fbmMatchUserIdIsNotNull = fbmMatchUserIdIsNotNull;
	}

	public java.util.List getFbmMatchUserIdIn() {
		return fbmMatchUserIdIn;
	}
	public void setFbmMatchUserIdIn(java.util.List fbmMatchUserIdIn) {
		this.fbmMatchUserIdIn = fbmMatchUserIdIn;
	}

	public Long getFbmMatchUserIdGreaterThanOrEqualTo() {
		return fbmMatchUserIdGreaterThanOrEqualTo;
	}
	public void setFbmMatchUserIdGreaterThanOrEqualTo(Long fbmMatchUserIdGreaterThanOrEqualTo) {
		this.fbmMatchUserIdGreaterThanOrEqualTo = fbmMatchUserIdGreaterThanOrEqualTo;
	}

	public Long getFbmMatchUserIdGreaterThan() {
		return fbmMatchUserIdGreaterThan;
	}
	public void setFbmMatchUserIdGreaterThan(Long fbmMatchUserIdGreaterThan) {
		this.fbmMatchUserIdGreaterThan = fbmMatchUserIdGreaterThan;
	}

	public Long getFbmMatchUserIdEqualTo() {
		return fbmMatchUserIdEqualTo;
	}
	public void setFbmMatchUserIdEqualTo(Long fbmMatchUserIdEqualTo) {
		this.fbmMatchUserIdEqualTo = fbmMatchUserIdEqualTo;
	}

	public String getFbmMatchTypeNotLike() {
		return fbmMatchTypeNotLike;
	}
	public void setFbmMatchTypeNotLike(String fbmMatchTypeNotLike) {
		this.fbmMatchTypeNotLike = fbmMatchTypeNotLike;
	}

	public java.util.List getFbmMatchTypeNotIn() {
		return fbmMatchTypeNotIn;
	}
	public void setFbmMatchTypeNotIn(java.util.List fbmMatchTypeNotIn) {
		this.fbmMatchTypeNotIn = fbmMatchTypeNotIn;
	}

	public String getFbmMatchTypeNotEqualTo() {
		return fbmMatchTypeNotEqualTo;
	}
	public void setFbmMatchTypeNotEqualTo(String fbmMatchTypeNotEqualTo) {
		this.fbmMatchTypeNotEqualTo = fbmMatchTypeNotEqualTo;
	}

	public String getFbmMatchTypeLike() {
		return fbmMatchTypeLike;
	}
	public void setFbmMatchTypeLike(String fbmMatchTypeLike) {
		this.fbmMatchTypeLike = fbmMatchTypeLike;
	}

	public String getFbmMatchTypeLessThanOrEqualTo() {
		return fbmMatchTypeLessThanOrEqualTo;
	}
	public void setFbmMatchTypeLessThanOrEqualTo(String fbmMatchTypeLessThanOrEqualTo) {
		this.fbmMatchTypeLessThanOrEqualTo = fbmMatchTypeLessThanOrEqualTo;
	}

	public String getFbmMatchTypeLessThan() {
		return fbmMatchTypeLessThan;
	}
	public void setFbmMatchTypeLessThan(String fbmMatchTypeLessThan) {
		this.fbmMatchTypeLessThan = fbmMatchTypeLessThan;
	}

	public Boolean getFbmMatchTypeIsNull() {
		return fbmMatchTypeIsNull;
	}
	public void setFbmMatchTypeIsNull(Boolean fbmMatchTypeIsNull) {
		this.fbmMatchTypeIsNull = fbmMatchTypeIsNull;
	}

	public Boolean getFbmMatchTypeIsNotNull() {
		return fbmMatchTypeIsNotNull;
	}
	public void setFbmMatchTypeIsNotNull(Boolean fbmMatchTypeIsNotNull) {
		this.fbmMatchTypeIsNotNull = fbmMatchTypeIsNotNull;
	}

	public java.util.List getFbmMatchTypeIn() {
		return fbmMatchTypeIn;
	}
	public void setFbmMatchTypeIn(java.util.List fbmMatchTypeIn) {
		this.fbmMatchTypeIn = fbmMatchTypeIn;
	}

	public String getFbmMatchTypeGreaterThanOrEqualTo() {
		return fbmMatchTypeGreaterThanOrEqualTo;
	}
	public void setFbmMatchTypeGreaterThanOrEqualTo(String fbmMatchTypeGreaterThanOrEqualTo) {
		this.fbmMatchTypeGreaterThanOrEqualTo = fbmMatchTypeGreaterThanOrEqualTo;
	}

	public String getFbmMatchTypeGreaterThan() {
		return fbmMatchTypeGreaterThan;
	}
	public void setFbmMatchTypeGreaterThan(String fbmMatchTypeGreaterThan) {
		this.fbmMatchTypeGreaterThan = fbmMatchTypeGreaterThan;
	}

	public String getFbmMatchTypeEqualTo() {
		return fbmMatchTypeEqualTo;
	}
	public void setFbmMatchTypeEqualTo(String fbmMatchTypeEqualTo) {
		this.fbmMatchTypeEqualTo = fbmMatchTypeEqualTo;
	}

	public java.util.List getFbmMatchTimeNotIn() {
		return fbmMatchTimeNotIn;
	}
	public void setFbmMatchTimeNotIn(java.util.List fbmMatchTimeNotIn) {
		this.fbmMatchTimeNotIn = fbmMatchTimeNotIn;
	}

	public java.util.Date getFbmMatchTimeNotEqualTo() {
		return fbmMatchTimeNotEqualTo;
	}
	public void setFbmMatchTimeNotEqualTo(java.util.Date fbmMatchTimeNotEqualTo) {
		this.fbmMatchTimeNotEqualTo = fbmMatchTimeNotEqualTo;
	}

	public java.util.Date getFbmMatchTimeLessThanOrEqualTo() {
		return fbmMatchTimeLessThanOrEqualTo;
	}
	public void setFbmMatchTimeLessThanOrEqualTo(java.util.Date fbmMatchTimeLessThanOrEqualTo) {
		this.fbmMatchTimeLessThanOrEqualTo = fbmMatchTimeLessThanOrEqualTo;
	}

	public java.util.Date getFbmMatchTimeLessThan() {
		return fbmMatchTimeLessThan;
	}
	public void setFbmMatchTimeLessThan(java.util.Date fbmMatchTimeLessThan) {
		this.fbmMatchTimeLessThan = fbmMatchTimeLessThan;
	}

	public Boolean getFbmMatchTimeIsNull() {
		return fbmMatchTimeIsNull;
	}
	public void setFbmMatchTimeIsNull(Boolean fbmMatchTimeIsNull) {
		this.fbmMatchTimeIsNull = fbmMatchTimeIsNull;
	}

	public Boolean getFbmMatchTimeIsNotNull() {
		return fbmMatchTimeIsNotNull;
	}
	public void setFbmMatchTimeIsNotNull(Boolean fbmMatchTimeIsNotNull) {
		this.fbmMatchTimeIsNotNull = fbmMatchTimeIsNotNull;
	}

	public java.util.List getFbmMatchTimeIn() {
		return fbmMatchTimeIn;
	}
	public void setFbmMatchTimeIn(java.util.List fbmMatchTimeIn) {
		this.fbmMatchTimeIn = fbmMatchTimeIn;
	}

	public java.util.Date getFbmMatchTimeGreaterThanOrEqualTo() {
		return fbmMatchTimeGreaterThanOrEqualTo;
	}
	public void setFbmMatchTimeGreaterThanOrEqualTo(java.util.Date fbmMatchTimeGreaterThanOrEqualTo) {
		this.fbmMatchTimeGreaterThanOrEqualTo = fbmMatchTimeGreaterThanOrEqualTo;
	}

	public java.util.Date getFbmMatchTimeGreaterThan() {
		return fbmMatchTimeGreaterThan;
	}
	public void setFbmMatchTimeGreaterThan(java.util.Date fbmMatchTimeGreaterThan) {
		this.fbmMatchTimeGreaterThan = fbmMatchTimeGreaterThan;
	}

	public java.util.Date getFbmMatchTimeEqualTo() {
		return fbmMatchTimeEqualTo;
	}
	public void setFbmMatchTimeEqualTo(java.util.Date fbmMatchTimeEqualTo) {
		this.fbmMatchTimeEqualTo = fbmMatchTimeEqualTo;
	}

	public String getFbmMatchSerialNumberNotLike() {
		return fbmMatchSerialNumberNotLike;
	}
	public void setFbmMatchSerialNumberNotLike(String fbmMatchSerialNumberNotLike) {
		this.fbmMatchSerialNumberNotLike = fbmMatchSerialNumberNotLike;
	}

	public java.util.List getFbmMatchSerialNumberNotIn() {
		return fbmMatchSerialNumberNotIn;
	}
	public void setFbmMatchSerialNumberNotIn(java.util.List fbmMatchSerialNumberNotIn) {
		this.fbmMatchSerialNumberNotIn = fbmMatchSerialNumberNotIn;
	}

	public String getFbmMatchSerialNumberNotEqualTo() {
		return fbmMatchSerialNumberNotEqualTo;
	}
	public void setFbmMatchSerialNumberNotEqualTo(String fbmMatchSerialNumberNotEqualTo) {
		this.fbmMatchSerialNumberNotEqualTo = fbmMatchSerialNumberNotEqualTo;
	}

	public String getFbmMatchSerialNumberLike() {
		return fbmMatchSerialNumberLike;
	}
	public void setFbmMatchSerialNumberLike(String fbmMatchSerialNumberLike) {
		this.fbmMatchSerialNumberLike = fbmMatchSerialNumberLike;
	}

	public String getFbmMatchSerialNumberLessThanOrEqualTo() {
		return fbmMatchSerialNumberLessThanOrEqualTo;
	}
	public void setFbmMatchSerialNumberLessThanOrEqualTo(String fbmMatchSerialNumberLessThanOrEqualTo) {
		this.fbmMatchSerialNumberLessThanOrEqualTo = fbmMatchSerialNumberLessThanOrEqualTo;
	}

	public String getFbmMatchSerialNumberLessThan() {
		return fbmMatchSerialNumberLessThan;
	}
	public void setFbmMatchSerialNumberLessThan(String fbmMatchSerialNumberLessThan) {
		this.fbmMatchSerialNumberLessThan = fbmMatchSerialNumberLessThan;
	}

	public Boolean getFbmMatchSerialNumberIsNull() {
		return fbmMatchSerialNumberIsNull;
	}
	public void setFbmMatchSerialNumberIsNull(Boolean fbmMatchSerialNumberIsNull) {
		this.fbmMatchSerialNumberIsNull = fbmMatchSerialNumberIsNull;
	}

	public Boolean getFbmMatchSerialNumberIsNotNull() {
		return fbmMatchSerialNumberIsNotNull;
	}
	public void setFbmMatchSerialNumberIsNotNull(Boolean fbmMatchSerialNumberIsNotNull) {
		this.fbmMatchSerialNumberIsNotNull = fbmMatchSerialNumberIsNotNull;
	}

	public java.util.List getFbmMatchSerialNumberIn() {
		return fbmMatchSerialNumberIn;
	}
	public void setFbmMatchSerialNumberIn(java.util.List fbmMatchSerialNumberIn) {
		this.fbmMatchSerialNumberIn = fbmMatchSerialNumberIn;
	}

	public String getFbmMatchSerialNumberGreaterThanOrEqualTo() {
		return fbmMatchSerialNumberGreaterThanOrEqualTo;
	}
	public void setFbmMatchSerialNumberGreaterThanOrEqualTo(String fbmMatchSerialNumberGreaterThanOrEqualTo) {
		this.fbmMatchSerialNumberGreaterThanOrEqualTo = fbmMatchSerialNumberGreaterThanOrEqualTo;
	}

	public String getFbmMatchSerialNumberGreaterThan() {
		return fbmMatchSerialNumberGreaterThan;
	}
	public void setFbmMatchSerialNumberGreaterThan(String fbmMatchSerialNumberGreaterThan) {
		this.fbmMatchSerialNumberGreaterThan = fbmMatchSerialNumberGreaterThan;
	}

	public String getFbmMatchSerialNumberEqualTo() {
		return fbmMatchSerialNumberEqualTo;
	}
	public void setFbmMatchSerialNumberEqualTo(String fbmMatchSerialNumberEqualTo) {
		this.fbmMatchSerialNumberEqualTo = fbmMatchSerialNumberEqualTo;
	}

	public String getFbmMatchPhoneNotLike() {
		return fbmMatchPhoneNotLike;
	}
	public void setFbmMatchPhoneNotLike(String fbmMatchPhoneNotLike) {
		this.fbmMatchPhoneNotLike = fbmMatchPhoneNotLike;
	}

	public java.util.List getFbmMatchPhoneNotIn() {
		return fbmMatchPhoneNotIn;
	}
	public void setFbmMatchPhoneNotIn(java.util.List fbmMatchPhoneNotIn) {
		this.fbmMatchPhoneNotIn = fbmMatchPhoneNotIn;
	}

	public String getFbmMatchPhoneNotEqualTo() {
		return fbmMatchPhoneNotEqualTo;
	}
	public void setFbmMatchPhoneNotEqualTo(String fbmMatchPhoneNotEqualTo) {
		this.fbmMatchPhoneNotEqualTo = fbmMatchPhoneNotEqualTo;
	}

	public String getFbmMatchPhoneLike() {
		return fbmMatchPhoneLike;
	}
	public void setFbmMatchPhoneLike(String fbmMatchPhoneLike) {
		this.fbmMatchPhoneLike = fbmMatchPhoneLike;
	}

	public String getFbmMatchPhoneLessThanOrEqualTo() {
		return fbmMatchPhoneLessThanOrEqualTo;
	}
	public void setFbmMatchPhoneLessThanOrEqualTo(String fbmMatchPhoneLessThanOrEqualTo) {
		this.fbmMatchPhoneLessThanOrEqualTo = fbmMatchPhoneLessThanOrEqualTo;
	}

	public String getFbmMatchPhoneLessThan() {
		return fbmMatchPhoneLessThan;
	}
	public void setFbmMatchPhoneLessThan(String fbmMatchPhoneLessThan) {
		this.fbmMatchPhoneLessThan = fbmMatchPhoneLessThan;
	}

	public Boolean getFbmMatchPhoneIsNull() {
		return fbmMatchPhoneIsNull;
	}
	public void setFbmMatchPhoneIsNull(Boolean fbmMatchPhoneIsNull) {
		this.fbmMatchPhoneIsNull = fbmMatchPhoneIsNull;
	}

	public Boolean getFbmMatchPhoneIsNotNull() {
		return fbmMatchPhoneIsNotNull;
	}
	public void setFbmMatchPhoneIsNotNull(Boolean fbmMatchPhoneIsNotNull) {
		this.fbmMatchPhoneIsNotNull = fbmMatchPhoneIsNotNull;
	}

	public java.util.List getFbmMatchPhoneIn() {
		return fbmMatchPhoneIn;
	}
	public void setFbmMatchPhoneIn(java.util.List fbmMatchPhoneIn) {
		this.fbmMatchPhoneIn = fbmMatchPhoneIn;
	}

	public String getFbmMatchPhoneGreaterThanOrEqualTo() {
		return fbmMatchPhoneGreaterThanOrEqualTo;
	}
	public void setFbmMatchPhoneGreaterThanOrEqualTo(String fbmMatchPhoneGreaterThanOrEqualTo) {
		this.fbmMatchPhoneGreaterThanOrEqualTo = fbmMatchPhoneGreaterThanOrEqualTo;
	}

	public String getFbmMatchPhoneGreaterThan() {
		return fbmMatchPhoneGreaterThan;
	}
	public void setFbmMatchPhoneGreaterThan(String fbmMatchPhoneGreaterThan) {
		this.fbmMatchPhoneGreaterThan = fbmMatchPhoneGreaterThan;
	}

	public String getFbmMatchPhoneEqualTo() {
		return fbmMatchPhoneEqualTo;
	}
	public void setFbmMatchPhoneEqualTo(String fbmMatchPhoneEqualTo) {
		this.fbmMatchPhoneEqualTo = fbmMatchPhoneEqualTo;
	}

	public java.util.List getFbmLeasePeriodNotIn() {
		return fbmLeasePeriodNotIn;
	}
	public void setFbmLeasePeriodNotIn(java.util.List fbmLeasePeriodNotIn) {
		this.fbmLeasePeriodNotIn = fbmLeasePeriodNotIn;
	}

	public java.util.Date getFbmLeasePeriodNotEqualTo() {
		return fbmLeasePeriodNotEqualTo;
	}
	public void setFbmLeasePeriodNotEqualTo(java.util.Date fbmLeasePeriodNotEqualTo) {
		this.fbmLeasePeriodNotEqualTo = fbmLeasePeriodNotEqualTo;
	}

	public java.util.Date getFbmLeasePeriodLessThanOrEqualTo() {
		return fbmLeasePeriodLessThanOrEqualTo;
	}
	public void setFbmLeasePeriodLessThanOrEqualTo(java.util.Date fbmLeasePeriodLessThanOrEqualTo) {
		this.fbmLeasePeriodLessThanOrEqualTo = fbmLeasePeriodLessThanOrEqualTo;
	}

	public java.util.Date getFbmLeasePeriodLessThan() {
		return fbmLeasePeriodLessThan;
	}
	public void setFbmLeasePeriodLessThan(java.util.Date fbmLeasePeriodLessThan) {
		this.fbmLeasePeriodLessThan = fbmLeasePeriodLessThan;
	}

	public Boolean getFbmLeasePeriodIsNull() {
		return fbmLeasePeriodIsNull;
	}
	public void setFbmLeasePeriodIsNull(Boolean fbmLeasePeriodIsNull) {
		this.fbmLeasePeriodIsNull = fbmLeasePeriodIsNull;
	}

	public Boolean getFbmLeasePeriodIsNotNull() {
		return fbmLeasePeriodIsNotNull;
	}
	public void setFbmLeasePeriodIsNotNull(Boolean fbmLeasePeriodIsNotNull) {
		this.fbmLeasePeriodIsNotNull = fbmLeasePeriodIsNotNull;
	}

	public java.util.List getFbmLeasePeriodIn() {
		return fbmLeasePeriodIn;
	}
	public void setFbmLeasePeriodIn(java.util.List fbmLeasePeriodIn) {
		this.fbmLeasePeriodIn = fbmLeasePeriodIn;
	}

	public java.util.Date getFbmLeasePeriodGreaterThanOrEqualTo() {
		return fbmLeasePeriodGreaterThanOrEqualTo;
	}
	public void setFbmLeasePeriodGreaterThanOrEqualTo(java.util.Date fbmLeasePeriodGreaterThanOrEqualTo) {
		this.fbmLeasePeriodGreaterThanOrEqualTo = fbmLeasePeriodGreaterThanOrEqualTo;
	}

	public java.util.Date getFbmLeasePeriodGreaterThan() {
		return fbmLeasePeriodGreaterThan;
	}
	public void setFbmLeasePeriodGreaterThan(java.util.Date fbmLeasePeriodGreaterThan) {
		this.fbmLeasePeriodGreaterThan = fbmLeasePeriodGreaterThan;
	}

	public java.util.Date getFbmLeasePeriodEqualTo() {
		return fbmLeasePeriodEqualTo;
	}
	public void setFbmLeasePeriodEqualTo(java.util.Date fbmLeasePeriodEqualTo) {
		this.fbmLeasePeriodEqualTo = fbmLeasePeriodEqualTo;
	}

	public java.util.List getFbmIdNotIn() {
		return fbmIdNotIn;
	}
	public void setFbmIdNotIn(java.util.List fbmIdNotIn) {
		this.fbmIdNotIn = fbmIdNotIn;
	}

	public Long getFbmIdNotEqualTo() {
		return fbmIdNotEqualTo;
	}
	public void setFbmIdNotEqualTo(Long fbmIdNotEqualTo) {
		this.fbmIdNotEqualTo = fbmIdNotEqualTo;
	}

	public Long getFbmIdLessThanOrEqualTo() {
		return fbmIdLessThanOrEqualTo;
	}
	public void setFbmIdLessThanOrEqualTo(Long fbmIdLessThanOrEqualTo) {
		this.fbmIdLessThanOrEqualTo = fbmIdLessThanOrEqualTo;
	}

	public Long getFbmIdLessThan() {
		return fbmIdLessThan;
	}
	public void setFbmIdLessThan(Long fbmIdLessThan) {
		this.fbmIdLessThan = fbmIdLessThan;
	}

	public Boolean getFbmIdIsNull() {
		return fbmIdIsNull;
	}
	public void setFbmIdIsNull(Boolean fbmIdIsNull) {
		this.fbmIdIsNull = fbmIdIsNull;
	}

	public Boolean getFbmIdIsNotNull() {
		return fbmIdIsNotNull;
	}
	public void setFbmIdIsNotNull(Boolean fbmIdIsNotNull) {
		this.fbmIdIsNotNull = fbmIdIsNotNull;
	}

	public java.util.List getFbmIdIn() {
		return fbmIdIn;
	}
	public void setFbmIdIn(java.util.List fbmIdIn) {
		this.fbmIdIn = fbmIdIn;
	}

	public Long getFbmIdGreaterThanOrEqualTo() {
		return fbmIdGreaterThanOrEqualTo;
	}
	public void setFbmIdGreaterThanOrEqualTo(Long fbmIdGreaterThanOrEqualTo) {
		this.fbmIdGreaterThanOrEqualTo = fbmIdGreaterThanOrEqualTo;
	}

	public Long getFbmIdGreaterThan() {
		return fbmIdGreaterThan;
	}
	public void setFbmIdGreaterThan(Long fbmIdGreaterThan) {
		this.fbmIdGreaterThan = fbmIdGreaterThan;
	}

	public Long getFbmIdEqualTo() {
		return fbmIdEqualTo;
	}
	public void setFbmIdEqualTo(Long fbmIdEqualTo) {
		this.fbmIdEqualTo = fbmIdEqualTo;
	}

	public java.util.List getFbmContractIdNotIn() {
		return fbmContractIdNotIn;
	}
	public void setFbmContractIdNotIn(java.util.List fbmContractIdNotIn) {
		this.fbmContractIdNotIn = fbmContractIdNotIn;
	}

	public Long getFbmContractIdNotEqualTo() {
		return fbmContractIdNotEqualTo;
	}
	public void setFbmContractIdNotEqualTo(Long fbmContractIdNotEqualTo) {
		this.fbmContractIdNotEqualTo = fbmContractIdNotEqualTo;
	}

	public Long getFbmContractIdLessThanOrEqualTo() {
		return fbmContractIdLessThanOrEqualTo;
	}
	public void setFbmContractIdLessThanOrEqualTo(Long fbmContractIdLessThanOrEqualTo) {
		this.fbmContractIdLessThanOrEqualTo = fbmContractIdLessThanOrEqualTo;
	}

	public Long getFbmContractIdLessThan() {
		return fbmContractIdLessThan;
	}
	public void setFbmContractIdLessThan(Long fbmContractIdLessThan) {
		this.fbmContractIdLessThan = fbmContractIdLessThan;
	}

	public Boolean getFbmContractIdIsNull() {
		return fbmContractIdIsNull;
	}
	public void setFbmContractIdIsNull(Boolean fbmContractIdIsNull) {
		this.fbmContractIdIsNull = fbmContractIdIsNull;
	}

	public Boolean getFbmContractIdIsNotNull() {
		return fbmContractIdIsNotNull;
	}
	public void setFbmContractIdIsNotNull(Boolean fbmContractIdIsNotNull) {
		this.fbmContractIdIsNotNull = fbmContractIdIsNotNull;
	}

	public java.util.List getFbmContractIdIn() {
		return fbmContractIdIn;
	}
	public void setFbmContractIdIn(java.util.List fbmContractIdIn) {
		this.fbmContractIdIn = fbmContractIdIn;
	}

	public Long getFbmContractIdGreaterThanOrEqualTo() {
		return fbmContractIdGreaterThanOrEqualTo;
	}
	public void setFbmContractIdGreaterThanOrEqualTo(Long fbmContractIdGreaterThanOrEqualTo) {
		this.fbmContractIdGreaterThanOrEqualTo = fbmContractIdGreaterThanOrEqualTo;
	}

	public Long getFbmContractIdGreaterThan() {
		return fbmContractIdGreaterThan;
	}
	public void setFbmContractIdGreaterThan(Long fbmContractIdGreaterThan) {
		this.fbmContractIdGreaterThan = fbmContractIdGreaterThan;
	}

	public Long getFbmContractIdEqualTo() {
		return fbmContractIdEqualTo;
	}
	public void setFbmContractIdEqualTo(Long fbmContractIdEqualTo) {
		this.fbmContractIdEqualTo = fbmContractIdEqualTo;
	}

	public java.util.List getFbmCityIdNotIn() {
		return fbmCityIdNotIn;
	}
	public void setFbmCityIdNotIn(java.util.List fbmCityIdNotIn) {
		this.fbmCityIdNotIn = fbmCityIdNotIn;
	}

	public Long getFbmCityIdNotEqualTo() {
		return fbmCityIdNotEqualTo;
	}
	public void setFbmCityIdNotEqualTo(Long fbmCityIdNotEqualTo) {
		this.fbmCityIdNotEqualTo = fbmCityIdNotEqualTo;
	}

	public Long getFbmCityIdLessThanOrEqualTo() {
		return fbmCityIdLessThanOrEqualTo;
	}
	public void setFbmCityIdLessThanOrEqualTo(Long fbmCityIdLessThanOrEqualTo) {
		this.fbmCityIdLessThanOrEqualTo = fbmCityIdLessThanOrEqualTo;
	}

	public Long getFbmCityIdLessThan() {
		return fbmCityIdLessThan;
	}
	public void setFbmCityIdLessThan(Long fbmCityIdLessThan) {
		this.fbmCityIdLessThan = fbmCityIdLessThan;
	}

	public Boolean getFbmCityIdIsNull() {
		return fbmCityIdIsNull;
	}
	public void setFbmCityIdIsNull(Boolean fbmCityIdIsNull) {
		this.fbmCityIdIsNull = fbmCityIdIsNull;
	}

	public Boolean getFbmCityIdIsNotNull() {
		return fbmCityIdIsNotNull;
	}
	public void setFbmCityIdIsNotNull(Boolean fbmCityIdIsNotNull) {
		this.fbmCityIdIsNotNull = fbmCityIdIsNotNull;
	}

	public java.util.List getFbmCityIdIn() {
		return fbmCityIdIn;
	}
	public void setFbmCityIdIn(java.util.List fbmCityIdIn) {
		this.fbmCityIdIn = fbmCityIdIn;
	}

	public Long getFbmCityIdGreaterThanOrEqualTo() {
		return fbmCityIdGreaterThanOrEqualTo;
	}
	public void setFbmCityIdGreaterThanOrEqualTo(Long fbmCityIdGreaterThanOrEqualTo) {
		this.fbmCityIdGreaterThanOrEqualTo = fbmCityIdGreaterThanOrEqualTo;
	}

	public Long getFbmCityIdGreaterThan() {
		return fbmCityIdGreaterThan;
	}
	public void setFbmCityIdGreaterThan(Long fbmCityIdGreaterThan) {
		this.fbmCityIdGreaterThan = fbmCityIdGreaterThan;
	}

	public Long getFbmCityIdEqualTo() {
		return fbmCityIdEqualTo;
	}
	public void setFbmCityIdEqualTo(Long fbmCityIdEqualTo) {
		this.fbmCityIdEqualTo = fbmCityIdEqualTo;
	}

	public java.util.List getFbmCarIdNotIn() {
		return fbmCarIdNotIn;
	}
	public void setFbmCarIdNotIn(java.util.List fbmCarIdNotIn) {
		this.fbmCarIdNotIn = fbmCarIdNotIn;
	}

	public Long getFbmCarIdNotEqualTo() {
		return fbmCarIdNotEqualTo;
	}
	public void setFbmCarIdNotEqualTo(Long fbmCarIdNotEqualTo) {
		this.fbmCarIdNotEqualTo = fbmCarIdNotEqualTo;
	}

	public Long getFbmCarIdLessThanOrEqualTo() {
		return fbmCarIdLessThanOrEqualTo;
	}
	public void setFbmCarIdLessThanOrEqualTo(Long fbmCarIdLessThanOrEqualTo) {
		this.fbmCarIdLessThanOrEqualTo = fbmCarIdLessThanOrEqualTo;
	}

	public Long getFbmCarIdLessThan() {
		return fbmCarIdLessThan;
	}
	public void setFbmCarIdLessThan(Long fbmCarIdLessThan) {
		this.fbmCarIdLessThan = fbmCarIdLessThan;
	}

	public Boolean getFbmCarIdIsNull() {
		return fbmCarIdIsNull;
	}
	public void setFbmCarIdIsNull(Boolean fbmCarIdIsNull) {
		this.fbmCarIdIsNull = fbmCarIdIsNull;
	}

	public Boolean getFbmCarIdIsNotNull() {
		return fbmCarIdIsNotNull;
	}
	public void setFbmCarIdIsNotNull(Boolean fbmCarIdIsNotNull) {
		this.fbmCarIdIsNotNull = fbmCarIdIsNotNull;
	}

	public java.util.List getFbmCarIdIn() {
		return fbmCarIdIn;
	}
	public void setFbmCarIdIn(java.util.List fbmCarIdIn) {
		this.fbmCarIdIn = fbmCarIdIn;
	}

	public Long getFbmCarIdGreaterThanOrEqualTo() {
		return fbmCarIdGreaterThanOrEqualTo;
	}
	public void setFbmCarIdGreaterThanOrEqualTo(Long fbmCarIdGreaterThanOrEqualTo) {
		this.fbmCarIdGreaterThanOrEqualTo = fbmCarIdGreaterThanOrEqualTo;
	}

	public Long getFbmCarIdGreaterThan() {
		return fbmCarIdGreaterThan;
	}
	public void setFbmCarIdGreaterThan(Long fbmCarIdGreaterThan) {
		this.fbmCarIdGreaterThan = fbmCarIdGreaterThan;
	}

	public Long getFbmCarIdEqualTo() {
		return fbmCarIdEqualTo;
	}
	public void setFbmCarIdEqualTo(Long fbmCarIdEqualTo) {
		this.fbmCarIdEqualTo = fbmCarIdEqualTo;
	}

	public java.util.List getFbmBreaksTypeNotIn() {
		return fbmBreaksTypeNotIn;
	}
	public void setFbmBreaksTypeNotIn(java.util.List fbmBreaksTypeNotIn) {
		this.fbmBreaksTypeNotIn = fbmBreaksTypeNotIn;
	}

	public Integer getFbmBreaksTypeNotEqualTo() {
		return fbmBreaksTypeNotEqualTo;
	}
	public void setFbmBreaksTypeNotEqualTo(Integer fbmBreaksTypeNotEqualTo) {
		this.fbmBreaksTypeNotEqualTo = fbmBreaksTypeNotEqualTo;
	}

	public Integer getFbmBreaksTypeLessThanOrEqualTo() {
		return fbmBreaksTypeLessThanOrEqualTo;
	}
	public void setFbmBreaksTypeLessThanOrEqualTo(Integer fbmBreaksTypeLessThanOrEqualTo) {
		this.fbmBreaksTypeLessThanOrEqualTo = fbmBreaksTypeLessThanOrEqualTo;
	}

	public Integer getFbmBreaksTypeLessThan() {
		return fbmBreaksTypeLessThan;
	}
	public void setFbmBreaksTypeLessThan(Integer fbmBreaksTypeLessThan) {
		this.fbmBreaksTypeLessThan = fbmBreaksTypeLessThan;
	}

	public Boolean getFbmBreaksTypeIsNull() {
		return fbmBreaksTypeIsNull;
	}
	public void setFbmBreaksTypeIsNull(Boolean fbmBreaksTypeIsNull) {
		this.fbmBreaksTypeIsNull = fbmBreaksTypeIsNull;
	}

	public Boolean getFbmBreaksTypeIsNotNull() {
		return fbmBreaksTypeIsNotNull;
	}
	public void setFbmBreaksTypeIsNotNull(Boolean fbmBreaksTypeIsNotNull) {
		this.fbmBreaksTypeIsNotNull = fbmBreaksTypeIsNotNull;
	}

	public java.util.List getFbmBreaksTypeIn() {
		return fbmBreaksTypeIn;
	}
	public void setFbmBreaksTypeIn(java.util.List fbmBreaksTypeIn) {
		this.fbmBreaksTypeIn = fbmBreaksTypeIn;
	}

	public Integer getFbmBreaksTypeGreaterThanOrEqualTo() {
		return fbmBreaksTypeGreaterThanOrEqualTo;
	}
	public void setFbmBreaksTypeGreaterThanOrEqualTo(Integer fbmBreaksTypeGreaterThanOrEqualTo) {
		this.fbmBreaksTypeGreaterThanOrEqualTo = fbmBreaksTypeGreaterThanOrEqualTo;
	}

	public Integer getFbmBreaksTypeGreaterThan() {
		return fbmBreaksTypeGreaterThan;
	}
	public void setFbmBreaksTypeGreaterThan(Integer fbmBreaksTypeGreaterThan) {
		this.fbmBreaksTypeGreaterThan = fbmBreaksTypeGreaterThan;
	}

	public Integer getFbmBreaksTypeEqualTo() {
		return fbmBreaksTypeEqualTo;
	}
	public void setFbmBreaksTypeEqualTo(Integer fbmBreaksTypeEqualTo) {
		this.fbmBreaksTypeEqualTo = fbmBreaksTypeEqualTo;
	}

	public java.util.List getFbmBreaksTimeNotIn() {
		return fbmBreaksTimeNotIn;
	}
	public void setFbmBreaksTimeNotIn(java.util.List fbmBreaksTimeNotIn) {
		this.fbmBreaksTimeNotIn = fbmBreaksTimeNotIn;
	}

	public java.util.Date getFbmBreaksTimeNotEqualTo() {
		return fbmBreaksTimeNotEqualTo;
	}
	public void setFbmBreaksTimeNotEqualTo(java.util.Date fbmBreaksTimeNotEqualTo) {
		this.fbmBreaksTimeNotEqualTo = fbmBreaksTimeNotEqualTo;
	}

	public java.util.Date getFbmBreaksTimeLessThanOrEqualTo() {
		return fbmBreaksTimeLessThanOrEqualTo;
	}
	public void setFbmBreaksTimeLessThanOrEqualTo(java.util.Date fbmBreaksTimeLessThanOrEqualTo) {
		this.fbmBreaksTimeLessThanOrEqualTo = fbmBreaksTimeLessThanOrEqualTo;
	}

	public java.util.Date getFbmBreaksTimeLessThan() {
		return fbmBreaksTimeLessThan;
	}
	public void setFbmBreaksTimeLessThan(java.util.Date fbmBreaksTimeLessThan) {
		this.fbmBreaksTimeLessThan = fbmBreaksTimeLessThan;
	}

	public Boolean getFbmBreaksTimeIsNull() {
		return fbmBreaksTimeIsNull;
	}
	public void setFbmBreaksTimeIsNull(Boolean fbmBreaksTimeIsNull) {
		this.fbmBreaksTimeIsNull = fbmBreaksTimeIsNull;
	}

	public Boolean getFbmBreaksTimeIsNotNull() {
		return fbmBreaksTimeIsNotNull;
	}
	public void setFbmBreaksTimeIsNotNull(Boolean fbmBreaksTimeIsNotNull) {
		this.fbmBreaksTimeIsNotNull = fbmBreaksTimeIsNotNull;
	}

	public java.util.List getFbmBreaksTimeIn() {
		return fbmBreaksTimeIn;
	}
	public void setFbmBreaksTimeIn(java.util.List fbmBreaksTimeIn) {
		this.fbmBreaksTimeIn = fbmBreaksTimeIn;
	}

	public java.util.Date getFbmBreaksTimeGreaterThanOrEqualTo() {
		return fbmBreaksTimeGreaterThanOrEqualTo;
	}
	public void setFbmBreaksTimeGreaterThanOrEqualTo(java.util.Date fbmBreaksTimeGreaterThanOrEqualTo) {
		this.fbmBreaksTimeGreaterThanOrEqualTo = fbmBreaksTimeGreaterThanOrEqualTo;
	}

	public java.util.Date getFbmBreaksTimeGreaterThan() {
		return fbmBreaksTimeGreaterThan;
	}
	public void setFbmBreaksTimeGreaterThan(java.util.Date fbmBreaksTimeGreaterThan) {
		this.fbmBreaksTimeGreaterThan = fbmBreaksTimeGreaterThan;
	}

	public java.util.Date getFbmBreaksTimeEqualTo() {
		return fbmBreaksTimeEqualTo;
	}
	public void setFbmBreaksTimeEqualTo(java.util.Date fbmBreaksTimeEqualTo) {
		this.fbmBreaksTimeEqualTo = fbmBreaksTimeEqualTo;
	}

	public String getFbmBreaksRemarkNotLike() {
		return fbmBreaksRemarkNotLike;
	}
	public void setFbmBreaksRemarkNotLike(String fbmBreaksRemarkNotLike) {
		this.fbmBreaksRemarkNotLike = fbmBreaksRemarkNotLike;
	}

	public java.util.List getFbmBreaksRemarkNotIn() {
		return fbmBreaksRemarkNotIn;
	}
	public void setFbmBreaksRemarkNotIn(java.util.List fbmBreaksRemarkNotIn) {
		this.fbmBreaksRemarkNotIn = fbmBreaksRemarkNotIn;
	}

	public String getFbmBreaksRemarkNotEqualTo() {
		return fbmBreaksRemarkNotEqualTo;
	}
	public void setFbmBreaksRemarkNotEqualTo(String fbmBreaksRemarkNotEqualTo) {
		this.fbmBreaksRemarkNotEqualTo = fbmBreaksRemarkNotEqualTo;
	}

	public String getFbmBreaksRemarkLike() {
		return fbmBreaksRemarkLike;
	}
	public void setFbmBreaksRemarkLike(String fbmBreaksRemarkLike) {
		this.fbmBreaksRemarkLike = fbmBreaksRemarkLike;
	}

	public String getFbmBreaksRemarkLessThanOrEqualTo() {
		return fbmBreaksRemarkLessThanOrEqualTo;
	}
	public void setFbmBreaksRemarkLessThanOrEqualTo(String fbmBreaksRemarkLessThanOrEqualTo) {
		this.fbmBreaksRemarkLessThanOrEqualTo = fbmBreaksRemarkLessThanOrEqualTo;
	}

	public String getFbmBreaksRemarkLessThan() {
		return fbmBreaksRemarkLessThan;
	}
	public void setFbmBreaksRemarkLessThan(String fbmBreaksRemarkLessThan) {
		this.fbmBreaksRemarkLessThan = fbmBreaksRemarkLessThan;
	}

	public Boolean getFbmBreaksRemarkIsNull() {
		return fbmBreaksRemarkIsNull;
	}
	public void setFbmBreaksRemarkIsNull(Boolean fbmBreaksRemarkIsNull) {
		this.fbmBreaksRemarkIsNull = fbmBreaksRemarkIsNull;
	}

	public Boolean getFbmBreaksRemarkIsNotNull() {
		return fbmBreaksRemarkIsNotNull;
	}
	public void setFbmBreaksRemarkIsNotNull(Boolean fbmBreaksRemarkIsNotNull) {
		this.fbmBreaksRemarkIsNotNull = fbmBreaksRemarkIsNotNull;
	}

	public java.util.List getFbmBreaksRemarkIn() {
		return fbmBreaksRemarkIn;
	}
	public void setFbmBreaksRemarkIn(java.util.List fbmBreaksRemarkIn) {
		this.fbmBreaksRemarkIn = fbmBreaksRemarkIn;
	}

	public String getFbmBreaksRemarkGreaterThanOrEqualTo() {
		return fbmBreaksRemarkGreaterThanOrEqualTo;
	}
	public void setFbmBreaksRemarkGreaterThanOrEqualTo(String fbmBreaksRemarkGreaterThanOrEqualTo) {
		this.fbmBreaksRemarkGreaterThanOrEqualTo = fbmBreaksRemarkGreaterThanOrEqualTo;
	}

	public String getFbmBreaksRemarkGreaterThan() {
		return fbmBreaksRemarkGreaterThan;
	}
	public void setFbmBreaksRemarkGreaterThan(String fbmBreaksRemarkGreaterThan) {
		this.fbmBreaksRemarkGreaterThan = fbmBreaksRemarkGreaterThan;
	}

	public String getFbmBreaksRemarkEqualTo() {
		return fbmBreaksRemarkEqualTo;
	}
	public void setFbmBreaksRemarkEqualTo(String fbmBreaksRemarkEqualTo) {
		this.fbmBreaksRemarkEqualTo = fbmBreaksRemarkEqualTo;
	}

	public String getFbmBreaksPhoneNotLike() {
		return fbmBreaksPhoneNotLike;
	}
	public void setFbmBreaksPhoneNotLike(String fbmBreaksPhoneNotLike) {
		this.fbmBreaksPhoneNotLike = fbmBreaksPhoneNotLike;
	}

	public java.util.List getFbmBreaksPhoneNotIn() {
		return fbmBreaksPhoneNotIn;
	}
	public void setFbmBreaksPhoneNotIn(java.util.List fbmBreaksPhoneNotIn) {
		this.fbmBreaksPhoneNotIn = fbmBreaksPhoneNotIn;
	}

	public String getFbmBreaksPhoneNotEqualTo() {
		return fbmBreaksPhoneNotEqualTo;
	}
	public void setFbmBreaksPhoneNotEqualTo(String fbmBreaksPhoneNotEqualTo) {
		this.fbmBreaksPhoneNotEqualTo = fbmBreaksPhoneNotEqualTo;
	}

	public String getFbmBreaksPhoneLike() {
		return fbmBreaksPhoneLike;
	}
	public void setFbmBreaksPhoneLike(String fbmBreaksPhoneLike) {
		this.fbmBreaksPhoneLike = fbmBreaksPhoneLike;
	}

	public String getFbmBreaksPhoneLessThanOrEqualTo() {
		return fbmBreaksPhoneLessThanOrEqualTo;
	}
	public void setFbmBreaksPhoneLessThanOrEqualTo(String fbmBreaksPhoneLessThanOrEqualTo) {
		this.fbmBreaksPhoneLessThanOrEqualTo = fbmBreaksPhoneLessThanOrEqualTo;
	}

	public String getFbmBreaksPhoneLessThan() {
		return fbmBreaksPhoneLessThan;
	}
	public void setFbmBreaksPhoneLessThan(String fbmBreaksPhoneLessThan) {
		this.fbmBreaksPhoneLessThan = fbmBreaksPhoneLessThan;
	}

	public Boolean getFbmBreaksPhoneIsNull() {
		return fbmBreaksPhoneIsNull;
	}
	public void setFbmBreaksPhoneIsNull(Boolean fbmBreaksPhoneIsNull) {
		this.fbmBreaksPhoneIsNull = fbmBreaksPhoneIsNull;
	}

	public Boolean getFbmBreaksPhoneIsNotNull() {
		return fbmBreaksPhoneIsNotNull;
	}
	public void setFbmBreaksPhoneIsNotNull(Boolean fbmBreaksPhoneIsNotNull) {
		this.fbmBreaksPhoneIsNotNull = fbmBreaksPhoneIsNotNull;
	}

	public java.util.List getFbmBreaksPhoneIn() {
		return fbmBreaksPhoneIn;
	}
	public void setFbmBreaksPhoneIn(java.util.List fbmBreaksPhoneIn) {
		this.fbmBreaksPhoneIn = fbmBreaksPhoneIn;
	}

	public String getFbmBreaksPhoneGreaterThanOrEqualTo() {
		return fbmBreaksPhoneGreaterThanOrEqualTo;
	}
	public void setFbmBreaksPhoneGreaterThanOrEqualTo(String fbmBreaksPhoneGreaterThanOrEqualTo) {
		this.fbmBreaksPhoneGreaterThanOrEqualTo = fbmBreaksPhoneGreaterThanOrEqualTo;
	}

	public String getFbmBreaksPhoneGreaterThan() {
		return fbmBreaksPhoneGreaterThan;
	}
	public void setFbmBreaksPhoneGreaterThan(String fbmBreaksPhoneGreaterThan) {
		this.fbmBreaksPhoneGreaterThan = fbmBreaksPhoneGreaterThan;
	}

	public String getFbmBreaksPhoneEqualTo() {
		return fbmBreaksPhoneEqualTo;
	}
	public void setFbmBreaksPhoneEqualTo(String fbmBreaksPhoneEqualTo) {
		this.fbmBreaksPhoneEqualTo = fbmBreaksPhoneEqualTo;
	}

	public java.util.List getFbmBreaksAmountNotIn() {
		return fbmBreaksAmountNotIn;
	}
	public void setFbmBreaksAmountNotIn(java.util.List fbmBreaksAmountNotIn) {
		this.fbmBreaksAmountNotIn = fbmBreaksAmountNotIn;
	}

	public Double getFbmBreaksAmountNotEqualTo() {
		return fbmBreaksAmountNotEqualTo;
	}
	public void setFbmBreaksAmountNotEqualTo(Double fbmBreaksAmountNotEqualTo) {
		this.fbmBreaksAmountNotEqualTo = fbmBreaksAmountNotEqualTo;
	}

	public Double getFbmBreaksAmountLessThanOrEqualTo() {
		return fbmBreaksAmountLessThanOrEqualTo;
	}
	public void setFbmBreaksAmountLessThanOrEqualTo(Double fbmBreaksAmountLessThanOrEqualTo) {
		this.fbmBreaksAmountLessThanOrEqualTo = fbmBreaksAmountLessThanOrEqualTo;
	}

	public Double getFbmBreaksAmountLessThan() {
		return fbmBreaksAmountLessThan;
	}
	public void setFbmBreaksAmountLessThan(Double fbmBreaksAmountLessThan) {
		this.fbmBreaksAmountLessThan = fbmBreaksAmountLessThan;
	}

	public Boolean getFbmBreaksAmountIsNull() {
		return fbmBreaksAmountIsNull;
	}
	public void setFbmBreaksAmountIsNull(Boolean fbmBreaksAmountIsNull) {
		this.fbmBreaksAmountIsNull = fbmBreaksAmountIsNull;
	}

	public Boolean getFbmBreaksAmountIsNotNull() {
		return fbmBreaksAmountIsNotNull;
	}
	public void setFbmBreaksAmountIsNotNull(Boolean fbmBreaksAmountIsNotNull) {
		this.fbmBreaksAmountIsNotNull = fbmBreaksAmountIsNotNull;
	}

	public java.util.List getFbmBreaksAmountIn() {
		return fbmBreaksAmountIn;
	}
	public void setFbmBreaksAmountIn(java.util.List fbmBreaksAmountIn) {
		this.fbmBreaksAmountIn = fbmBreaksAmountIn;
	}

	public Double getFbmBreaksAmountGreaterThanOrEqualTo() {
		return fbmBreaksAmountGreaterThanOrEqualTo;
	}
	public void setFbmBreaksAmountGreaterThanOrEqualTo(Double fbmBreaksAmountGreaterThanOrEqualTo) {
		this.fbmBreaksAmountGreaterThanOrEqualTo = fbmBreaksAmountGreaterThanOrEqualTo;
	}

	public Double getFbmBreaksAmountGreaterThan() {
		return fbmBreaksAmountGreaterThan;
	}
	public void setFbmBreaksAmountGreaterThan(Double fbmBreaksAmountGreaterThan) {
		this.fbmBreaksAmountGreaterThan = fbmBreaksAmountGreaterThan;
	}

	public Double getFbmBreaksAmountEqualTo() {
		return fbmBreaksAmountEqualTo;
	}
	public void setFbmBreaksAmountEqualTo(Double fbmBreaksAmountEqualTo) {
		this.fbmBreaksAmountEqualTo = fbmBreaksAmountEqualTo;
	}

	public java.util.List getFbmBreaksAfterAmountNotIn() {
		return fbmBreaksAfterAmountNotIn;
	}
	public void setFbmBreaksAfterAmountNotIn(java.util.List fbmBreaksAfterAmountNotIn) {
		this.fbmBreaksAfterAmountNotIn = fbmBreaksAfterAmountNotIn;
	}

	public Double getFbmBreaksAfterAmountNotEqualTo() {
		return fbmBreaksAfterAmountNotEqualTo;
	}
	public void setFbmBreaksAfterAmountNotEqualTo(Double fbmBreaksAfterAmountNotEqualTo) {
		this.fbmBreaksAfterAmountNotEqualTo = fbmBreaksAfterAmountNotEqualTo;
	}

	public Double getFbmBreaksAfterAmountLessThanOrEqualTo() {
		return fbmBreaksAfterAmountLessThanOrEqualTo;
	}
	public void setFbmBreaksAfterAmountLessThanOrEqualTo(Double fbmBreaksAfterAmountLessThanOrEqualTo) {
		this.fbmBreaksAfterAmountLessThanOrEqualTo = fbmBreaksAfterAmountLessThanOrEqualTo;
	}

	public Double getFbmBreaksAfterAmountLessThan() {
		return fbmBreaksAfterAmountLessThan;
	}
	public void setFbmBreaksAfterAmountLessThan(Double fbmBreaksAfterAmountLessThan) {
		this.fbmBreaksAfterAmountLessThan = fbmBreaksAfterAmountLessThan;
	}

	public Boolean getFbmBreaksAfterAmountIsNull() {
		return fbmBreaksAfterAmountIsNull;
	}
	public void setFbmBreaksAfterAmountIsNull(Boolean fbmBreaksAfterAmountIsNull) {
		this.fbmBreaksAfterAmountIsNull = fbmBreaksAfterAmountIsNull;
	}

	public Boolean getFbmBreaksAfterAmountIsNotNull() {
		return fbmBreaksAfterAmountIsNotNull;
	}
	public void setFbmBreaksAfterAmountIsNotNull(Boolean fbmBreaksAfterAmountIsNotNull) {
		this.fbmBreaksAfterAmountIsNotNull = fbmBreaksAfterAmountIsNotNull;
	}

	public java.util.List getFbmBreaksAfterAmountIn() {
		return fbmBreaksAfterAmountIn;
	}
	public void setFbmBreaksAfterAmountIn(java.util.List fbmBreaksAfterAmountIn) {
		this.fbmBreaksAfterAmountIn = fbmBreaksAfterAmountIn;
	}

	public Double getFbmBreaksAfterAmountGreaterThanOrEqualTo() {
		return fbmBreaksAfterAmountGreaterThanOrEqualTo;
	}
	public void setFbmBreaksAfterAmountGreaterThanOrEqualTo(Double fbmBreaksAfterAmountGreaterThanOrEqualTo) {
		this.fbmBreaksAfterAmountGreaterThanOrEqualTo = fbmBreaksAfterAmountGreaterThanOrEqualTo;
	}

	public Double getFbmBreaksAfterAmountGreaterThan() {
		return fbmBreaksAfterAmountGreaterThan;
	}
	public void setFbmBreaksAfterAmountGreaterThan(Double fbmBreaksAfterAmountGreaterThan) {
		this.fbmBreaksAfterAmountGreaterThan = fbmBreaksAfterAmountGreaterThan;
	}

	public Double getFbmBreaksAfterAmountEqualTo() {
		return fbmBreaksAfterAmountEqualTo;
	}
	public void setFbmBreaksAfterAmountEqualTo(Double fbmBreaksAfterAmountEqualTo) {
		this.fbmBreaksAfterAmountEqualTo = fbmBreaksAfterAmountEqualTo;
	}

	public String getFbmBillVoucherNotLike() {
		return fbmBillVoucherNotLike;
	}
	public void setFbmBillVoucherNotLike(String fbmBillVoucherNotLike) {
		this.fbmBillVoucherNotLike = fbmBillVoucherNotLike;
	}

	public java.util.List getFbmBillVoucherNotIn() {
		return fbmBillVoucherNotIn;
	}
	public void setFbmBillVoucherNotIn(java.util.List fbmBillVoucherNotIn) {
		this.fbmBillVoucherNotIn = fbmBillVoucherNotIn;
	}

	public String getFbmBillVoucherNotEqualTo() {
		return fbmBillVoucherNotEqualTo;
	}
	public void setFbmBillVoucherNotEqualTo(String fbmBillVoucherNotEqualTo) {
		this.fbmBillVoucherNotEqualTo = fbmBillVoucherNotEqualTo;
	}

	public String getFbmBillVoucherLike() {
		return fbmBillVoucherLike;
	}
	public void setFbmBillVoucherLike(String fbmBillVoucherLike) {
		this.fbmBillVoucherLike = fbmBillVoucherLike;
	}

	public String getFbmBillVoucherLessThanOrEqualTo() {
		return fbmBillVoucherLessThanOrEqualTo;
	}
	public void setFbmBillVoucherLessThanOrEqualTo(String fbmBillVoucherLessThanOrEqualTo) {
		this.fbmBillVoucherLessThanOrEqualTo = fbmBillVoucherLessThanOrEqualTo;
	}

	public String getFbmBillVoucherLessThan() {
		return fbmBillVoucherLessThan;
	}
	public void setFbmBillVoucherLessThan(String fbmBillVoucherLessThan) {
		this.fbmBillVoucherLessThan = fbmBillVoucherLessThan;
	}

	public Boolean getFbmBillVoucherIsNull() {
		return fbmBillVoucherIsNull;
	}
	public void setFbmBillVoucherIsNull(Boolean fbmBillVoucherIsNull) {
		this.fbmBillVoucherIsNull = fbmBillVoucherIsNull;
	}

	public Boolean getFbmBillVoucherIsNotNull() {
		return fbmBillVoucherIsNotNull;
	}
	public void setFbmBillVoucherIsNotNull(Boolean fbmBillVoucherIsNotNull) {
		this.fbmBillVoucherIsNotNull = fbmBillVoucherIsNotNull;
	}

	public java.util.List getFbmBillVoucherIn() {
		return fbmBillVoucherIn;
	}
	public void setFbmBillVoucherIn(java.util.List fbmBillVoucherIn) {
		this.fbmBillVoucherIn = fbmBillVoucherIn;
	}

	public String getFbmBillVoucherGreaterThanOrEqualTo() {
		return fbmBillVoucherGreaterThanOrEqualTo;
	}
	public void setFbmBillVoucherGreaterThanOrEqualTo(String fbmBillVoucherGreaterThanOrEqualTo) {
		this.fbmBillVoucherGreaterThanOrEqualTo = fbmBillVoucherGreaterThanOrEqualTo;
	}

	public String getFbmBillVoucherGreaterThan() {
		return fbmBillVoucherGreaterThan;
	}
	public void setFbmBillVoucherGreaterThan(String fbmBillVoucherGreaterThan) {
		this.fbmBillVoucherGreaterThan = fbmBillVoucherGreaterThan;
	}

	public String getFbmBillVoucherEqualTo() {
		return fbmBillVoucherEqualTo;
	}
	public void setFbmBillVoucherEqualTo(String fbmBillVoucherEqualTo) {
		this.fbmBillVoucherEqualTo = fbmBillVoucherEqualTo;
	}

	public java.util.List getFbmBillStateNotIn() {
		return fbmBillStateNotIn;
	}
	public void setFbmBillStateNotIn(java.util.List fbmBillStateNotIn) {
		this.fbmBillStateNotIn = fbmBillStateNotIn;
	}

	public Integer getFbmBillStateNotEqualTo() {
		return fbmBillStateNotEqualTo;
	}
	public void setFbmBillStateNotEqualTo(Integer fbmBillStateNotEqualTo) {
		this.fbmBillStateNotEqualTo = fbmBillStateNotEqualTo;
	}

	public Integer getFbmBillStateLessThanOrEqualTo() {
		return fbmBillStateLessThanOrEqualTo;
	}
	public void setFbmBillStateLessThanOrEqualTo(Integer fbmBillStateLessThanOrEqualTo) {
		this.fbmBillStateLessThanOrEqualTo = fbmBillStateLessThanOrEqualTo;
	}

	public Integer getFbmBillStateLessThan() {
		return fbmBillStateLessThan;
	}
	public void setFbmBillStateLessThan(Integer fbmBillStateLessThan) {
		this.fbmBillStateLessThan = fbmBillStateLessThan;
	}

	public Boolean getFbmBillStateIsNull() {
		return fbmBillStateIsNull;
	}
	public void setFbmBillStateIsNull(Boolean fbmBillStateIsNull) {
		this.fbmBillStateIsNull = fbmBillStateIsNull;
	}

	public Boolean getFbmBillStateIsNotNull() {
		return fbmBillStateIsNotNull;
	}
	public void setFbmBillStateIsNotNull(Boolean fbmBillStateIsNotNull) {
		this.fbmBillStateIsNotNull = fbmBillStateIsNotNull;
	}

	public java.util.List getFbmBillStateIn() {
		return fbmBillStateIn;
	}
	public void setFbmBillStateIn(java.util.List fbmBillStateIn) {
		this.fbmBillStateIn = fbmBillStateIn;
	}

	public Integer getFbmBillStateGreaterThanOrEqualTo() {
		return fbmBillStateGreaterThanOrEqualTo;
	}
	public void setFbmBillStateGreaterThanOrEqualTo(Integer fbmBillStateGreaterThanOrEqualTo) {
		this.fbmBillStateGreaterThanOrEqualTo = fbmBillStateGreaterThanOrEqualTo;
	}

	public Integer getFbmBillStateGreaterThan() {
		return fbmBillStateGreaterThan;
	}
	public void setFbmBillStateGreaterThan(Integer fbmBillStateGreaterThan) {
		this.fbmBillStateGreaterThan = fbmBillStateGreaterThan;
	}

	public Integer getFbmBillStateEqualTo() {
		return fbmBillStateEqualTo;
	}
	public void setFbmBillStateEqualTo(Integer fbmBillStateEqualTo) {
		this.fbmBillStateEqualTo = fbmBillStateEqualTo;
	}

	public java.util.List getFbmBillGenerateWayNotIn() {
		return fbmBillGenerateWayNotIn;
	}
	public void setFbmBillGenerateWayNotIn(java.util.List fbmBillGenerateWayNotIn) {
		this.fbmBillGenerateWayNotIn = fbmBillGenerateWayNotIn;
	}

	public Integer getFbmBillGenerateWayNotEqualTo() {
		return fbmBillGenerateWayNotEqualTo;
	}
	public void setFbmBillGenerateWayNotEqualTo(Integer fbmBillGenerateWayNotEqualTo) {
		this.fbmBillGenerateWayNotEqualTo = fbmBillGenerateWayNotEqualTo;
	}

	public Integer getFbmBillGenerateWayLessThanOrEqualTo() {
		return fbmBillGenerateWayLessThanOrEqualTo;
	}
	public void setFbmBillGenerateWayLessThanOrEqualTo(Integer fbmBillGenerateWayLessThanOrEqualTo) {
		this.fbmBillGenerateWayLessThanOrEqualTo = fbmBillGenerateWayLessThanOrEqualTo;
	}

	public Integer getFbmBillGenerateWayLessThan() {
		return fbmBillGenerateWayLessThan;
	}
	public void setFbmBillGenerateWayLessThan(Integer fbmBillGenerateWayLessThan) {
		this.fbmBillGenerateWayLessThan = fbmBillGenerateWayLessThan;
	}

	public Boolean getFbmBillGenerateWayIsNull() {
		return fbmBillGenerateWayIsNull;
	}
	public void setFbmBillGenerateWayIsNull(Boolean fbmBillGenerateWayIsNull) {
		this.fbmBillGenerateWayIsNull = fbmBillGenerateWayIsNull;
	}

	public Boolean getFbmBillGenerateWayIsNotNull() {
		return fbmBillGenerateWayIsNotNull;
	}
	public void setFbmBillGenerateWayIsNotNull(Boolean fbmBillGenerateWayIsNotNull) {
		this.fbmBillGenerateWayIsNotNull = fbmBillGenerateWayIsNotNull;
	}

	public java.util.List getFbmBillGenerateWayIn() {
		return fbmBillGenerateWayIn;
	}
	public void setFbmBillGenerateWayIn(java.util.List fbmBillGenerateWayIn) {
		this.fbmBillGenerateWayIn = fbmBillGenerateWayIn;
	}

	public Integer getFbmBillGenerateWayGreaterThanOrEqualTo() {
		return fbmBillGenerateWayGreaterThanOrEqualTo;
	}
	public void setFbmBillGenerateWayGreaterThanOrEqualTo(Integer fbmBillGenerateWayGreaterThanOrEqualTo) {
		this.fbmBillGenerateWayGreaterThanOrEqualTo = fbmBillGenerateWayGreaterThanOrEqualTo;
	}

	public Integer getFbmBillGenerateWayGreaterThan() {
		return fbmBillGenerateWayGreaterThan;
	}
	public void setFbmBillGenerateWayGreaterThan(Integer fbmBillGenerateWayGreaterThan) {
		this.fbmBillGenerateWayGreaterThan = fbmBillGenerateWayGreaterThan;
	}

	public Integer getFbmBillGenerateWayEqualTo() {
		return fbmBillGenerateWayEqualTo;
	}
	public void setFbmBillGenerateWayEqualTo(Integer fbmBillGenerateWayEqualTo) {
		this.fbmBillGenerateWayEqualTo = fbmBillGenerateWayEqualTo;
	}

	public java.util.List getFbmBillGenerateTimeNotIn() {
		return fbmBillGenerateTimeNotIn;
	}
	public void setFbmBillGenerateTimeNotIn(java.util.List fbmBillGenerateTimeNotIn) {
		this.fbmBillGenerateTimeNotIn = fbmBillGenerateTimeNotIn;
	}

	public java.util.Date getFbmBillGenerateTimeNotEqualTo() {
		return fbmBillGenerateTimeNotEqualTo;
	}
	public void setFbmBillGenerateTimeNotEqualTo(java.util.Date fbmBillGenerateTimeNotEqualTo) {
		this.fbmBillGenerateTimeNotEqualTo = fbmBillGenerateTimeNotEqualTo;
	}

	public java.util.Date getFbmBillGenerateTimeLessThanOrEqualTo() {
		return fbmBillGenerateTimeLessThanOrEqualTo;
	}
	public void setFbmBillGenerateTimeLessThanOrEqualTo(java.util.Date fbmBillGenerateTimeLessThanOrEqualTo) {
		this.fbmBillGenerateTimeLessThanOrEqualTo = fbmBillGenerateTimeLessThanOrEqualTo;
	}

	public java.util.Date getFbmBillGenerateTimeLessThan() {
		return fbmBillGenerateTimeLessThan;
	}
	public void setFbmBillGenerateTimeLessThan(java.util.Date fbmBillGenerateTimeLessThan) {
		this.fbmBillGenerateTimeLessThan = fbmBillGenerateTimeLessThan;
	}

	public Boolean getFbmBillGenerateTimeIsNull() {
		return fbmBillGenerateTimeIsNull;
	}
	public void setFbmBillGenerateTimeIsNull(Boolean fbmBillGenerateTimeIsNull) {
		this.fbmBillGenerateTimeIsNull = fbmBillGenerateTimeIsNull;
	}

	public Boolean getFbmBillGenerateTimeIsNotNull() {
		return fbmBillGenerateTimeIsNotNull;
	}
	public void setFbmBillGenerateTimeIsNotNull(Boolean fbmBillGenerateTimeIsNotNull) {
		this.fbmBillGenerateTimeIsNotNull = fbmBillGenerateTimeIsNotNull;
	}

	public java.util.List getFbmBillGenerateTimeIn() {
		return fbmBillGenerateTimeIn;
	}
	public void setFbmBillGenerateTimeIn(java.util.List fbmBillGenerateTimeIn) {
		this.fbmBillGenerateTimeIn = fbmBillGenerateTimeIn;
	}

	public java.util.Date getFbmBillGenerateTimeGreaterThanOrEqualTo() {
		return fbmBillGenerateTimeGreaterThanOrEqualTo;
	}
	public void setFbmBillGenerateTimeGreaterThanOrEqualTo(java.util.Date fbmBillGenerateTimeGreaterThanOrEqualTo) {
		this.fbmBillGenerateTimeGreaterThanOrEqualTo = fbmBillGenerateTimeGreaterThanOrEqualTo;
	}

	public java.util.Date getFbmBillGenerateTimeGreaterThan() {
		return fbmBillGenerateTimeGreaterThan;
	}
	public void setFbmBillGenerateTimeGreaterThan(java.util.Date fbmBillGenerateTimeGreaterThan) {
		this.fbmBillGenerateTimeGreaterThan = fbmBillGenerateTimeGreaterThan;
	}

	public java.util.Date getFbmBillGenerateTimeEqualTo() {
		return fbmBillGenerateTimeEqualTo;
	}
	public void setFbmBillGenerateTimeEqualTo(java.util.Date fbmBillGenerateTimeEqualTo) {
		this.fbmBillGenerateTimeEqualTo = fbmBillGenerateTimeEqualTo;
	}

	public String getFbmBillGenerateReasonNotLike() {
		return fbmBillGenerateReasonNotLike;
	}
	public void setFbmBillGenerateReasonNotLike(String fbmBillGenerateReasonNotLike) {
		this.fbmBillGenerateReasonNotLike = fbmBillGenerateReasonNotLike;
	}

	public java.util.List getFbmBillGenerateReasonNotIn() {
		return fbmBillGenerateReasonNotIn;
	}
	public void setFbmBillGenerateReasonNotIn(java.util.List fbmBillGenerateReasonNotIn) {
		this.fbmBillGenerateReasonNotIn = fbmBillGenerateReasonNotIn;
	}

	public String getFbmBillGenerateReasonNotEqualTo() {
		return fbmBillGenerateReasonNotEqualTo;
	}
	public void setFbmBillGenerateReasonNotEqualTo(String fbmBillGenerateReasonNotEqualTo) {
		this.fbmBillGenerateReasonNotEqualTo = fbmBillGenerateReasonNotEqualTo;
	}

	public String getFbmBillGenerateReasonLike() {
		return fbmBillGenerateReasonLike;
	}
	public void setFbmBillGenerateReasonLike(String fbmBillGenerateReasonLike) {
		this.fbmBillGenerateReasonLike = fbmBillGenerateReasonLike;
	}

	public String getFbmBillGenerateReasonLessThanOrEqualTo() {
		return fbmBillGenerateReasonLessThanOrEqualTo;
	}
	public void setFbmBillGenerateReasonLessThanOrEqualTo(String fbmBillGenerateReasonLessThanOrEqualTo) {
		this.fbmBillGenerateReasonLessThanOrEqualTo = fbmBillGenerateReasonLessThanOrEqualTo;
	}

	public String getFbmBillGenerateReasonLessThan() {
		return fbmBillGenerateReasonLessThan;
	}
	public void setFbmBillGenerateReasonLessThan(String fbmBillGenerateReasonLessThan) {
		this.fbmBillGenerateReasonLessThan = fbmBillGenerateReasonLessThan;
	}

	public Boolean getFbmBillGenerateReasonIsNull() {
		return fbmBillGenerateReasonIsNull;
	}
	public void setFbmBillGenerateReasonIsNull(Boolean fbmBillGenerateReasonIsNull) {
		this.fbmBillGenerateReasonIsNull = fbmBillGenerateReasonIsNull;
	}

	public Boolean getFbmBillGenerateReasonIsNotNull() {
		return fbmBillGenerateReasonIsNotNull;
	}
	public void setFbmBillGenerateReasonIsNotNull(Boolean fbmBillGenerateReasonIsNotNull) {
		this.fbmBillGenerateReasonIsNotNull = fbmBillGenerateReasonIsNotNull;
	}

	public java.util.List getFbmBillGenerateReasonIn() {
		return fbmBillGenerateReasonIn;
	}
	public void setFbmBillGenerateReasonIn(java.util.List fbmBillGenerateReasonIn) {
		this.fbmBillGenerateReasonIn = fbmBillGenerateReasonIn;
	}

	public String getFbmBillGenerateReasonGreaterThanOrEqualTo() {
		return fbmBillGenerateReasonGreaterThanOrEqualTo;
	}
	public void setFbmBillGenerateReasonGreaterThanOrEqualTo(String fbmBillGenerateReasonGreaterThanOrEqualTo) {
		this.fbmBillGenerateReasonGreaterThanOrEqualTo = fbmBillGenerateReasonGreaterThanOrEqualTo;
	}

	public String getFbmBillGenerateReasonGreaterThan() {
		return fbmBillGenerateReasonGreaterThan;
	}
	public void setFbmBillGenerateReasonGreaterThan(String fbmBillGenerateReasonGreaterThan) {
		this.fbmBillGenerateReasonGreaterThan = fbmBillGenerateReasonGreaterThan;
	}

	public String getFbmBillGenerateReasonEqualTo() {
		return fbmBillGenerateReasonEqualTo;
	}
	public void setFbmBillGenerateReasonEqualTo(String fbmBillGenerateReasonEqualTo) {
		this.fbmBillGenerateReasonEqualTo = fbmBillGenerateReasonEqualTo;
	}

	public java.util.List getFbmBillCatoffTimeNotIn() {
		return fbmBillCatoffTimeNotIn;
	}
	public void setFbmBillCatoffTimeNotIn(java.util.List fbmBillCatoffTimeNotIn) {
		this.fbmBillCatoffTimeNotIn = fbmBillCatoffTimeNotIn;
	}

	public java.util.Date getFbmBillCatoffTimeNotEqualTo() {
		return fbmBillCatoffTimeNotEqualTo;
	}
	public void setFbmBillCatoffTimeNotEqualTo(java.util.Date fbmBillCatoffTimeNotEqualTo) {
		this.fbmBillCatoffTimeNotEqualTo = fbmBillCatoffTimeNotEqualTo;
	}

	public java.util.Date getFbmBillCatoffTimeLessThanOrEqualTo() {
		return fbmBillCatoffTimeLessThanOrEqualTo;
	}
	public void setFbmBillCatoffTimeLessThanOrEqualTo(java.util.Date fbmBillCatoffTimeLessThanOrEqualTo) {
		this.fbmBillCatoffTimeLessThanOrEqualTo = fbmBillCatoffTimeLessThanOrEqualTo;
	}

	public java.util.Date getFbmBillCatoffTimeLessThan() {
		return fbmBillCatoffTimeLessThan;
	}
	public void setFbmBillCatoffTimeLessThan(java.util.Date fbmBillCatoffTimeLessThan) {
		this.fbmBillCatoffTimeLessThan = fbmBillCatoffTimeLessThan;
	}

	public Boolean getFbmBillCatoffTimeIsNull() {
		return fbmBillCatoffTimeIsNull;
	}
	public void setFbmBillCatoffTimeIsNull(Boolean fbmBillCatoffTimeIsNull) {
		this.fbmBillCatoffTimeIsNull = fbmBillCatoffTimeIsNull;
	}

	public Boolean getFbmBillCatoffTimeIsNotNull() {
		return fbmBillCatoffTimeIsNotNull;
	}
	public void setFbmBillCatoffTimeIsNotNull(Boolean fbmBillCatoffTimeIsNotNull) {
		this.fbmBillCatoffTimeIsNotNull = fbmBillCatoffTimeIsNotNull;
	}

	public java.util.List getFbmBillCatoffTimeIn() {
		return fbmBillCatoffTimeIn;
	}
	public void setFbmBillCatoffTimeIn(java.util.List fbmBillCatoffTimeIn) {
		this.fbmBillCatoffTimeIn = fbmBillCatoffTimeIn;
	}

	public java.util.Date getFbmBillCatoffTimeGreaterThanOrEqualTo() {
		return fbmBillCatoffTimeGreaterThanOrEqualTo;
	}
	public void setFbmBillCatoffTimeGreaterThanOrEqualTo(java.util.Date fbmBillCatoffTimeGreaterThanOrEqualTo) {
		this.fbmBillCatoffTimeGreaterThanOrEqualTo = fbmBillCatoffTimeGreaterThanOrEqualTo;
	}

	public java.util.Date getFbmBillCatoffTimeGreaterThan() {
		return fbmBillCatoffTimeGreaterThan;
	}
	public void setFbmBillCatoffTimeGreaterThan(java.util.Date fbmBillCatoffTimeGreaterThan) {
		this.fbmBillCatoffTimeGreaterThan = fbmBillCatoffTimeGreaterThan;
	}

	public java.util.Date getFbmBillCatoffTimeEqualTo() {
		return fbmBillCatoffTimeEqualTo;
	}
	public void setFbmBillCatoffTimeEqualTo(java.util.Date fbmBillCatoffTimeEqualTo) {
		this.fbmBillCatoffTimeEqualTo = fbmBillCatoffTimeEqualTo;
	}

	public java.util.List getFbmBillAmountNotIn() {
		return fbmBillAmountNotIn;
	}
	public void setFbmBillAmountNotIn(java.util.List fbmBillAmountNotIn) {
		this.fbmBillAmountNotIn = fbmBillAmountNotIn;
	}

	public Double getFbmBillAmountNotEqualTo() {
		return fbmBillAmountNotEqualTo;
	}
	public void setFbmBillAmountNotEqualTo(Double fbmBillAmountNotEqualTo) {
		this.fbmBillAmountNotEqualTo = fbmBillAmountNotEqualTo;
	}

	public Double getFbmBillAmountLessThanOrEqualTo() {
		return fbmBillAmountLessThanOrEqualTo;
	}
	public void setFbmBillAmountLessThanOrEqualTo(Double fbmBillAmountLessThanOrEqualTo) {
		this.fbmBillAmountLessThanOrEqualTo = fbmBillAmountLessThanOrEqualTo;
	}

	public Double getFbmBillAmountLessThan() {
		return fbmBillAmountLessThan;
	}
	public void setFbmBillAmountLessThan(Double fbmBillAmountLessThan) {
		this.fbmBillAmountLessThan = fbmBillAmountLessThan;
	}

	public Boolean getFbmBillAmountIsNull() {
		return fbmBillAmountIsNull;
	}
	public void setFbmBillAmountIsNull(Boolean fbmBillAmountIsNull) {
		this.fbmBillAmountIsNull = fbmBillAmountIsNull;
	}

	public Boolean getFbmBillAmountIsNotNull() {
		return fbmBillAmountIsNotNull;
	}
	public void setFbmBillAmountIsNotNull(Boolean fbmBillAmountIsNotNull) {
		this.fbmBillAmountIsNotNull = fbmBillAmountIsNotNull;
	}

	public java.util.List getFbmBillAmountIn() {
		return fbmBillAmountIn;
	}
	public void setFbmBillAmountIn(java.util.List fbmBillAmountIn) {
		this.fbmBillAmountIn = fbmBillAmountIn;
	}

	public Double getFbmBillAmountGreaterThanOrEqualTo() {
		return fbmBillAmountGreaterThanOrEqualTo;
	}
	public void setFbmBillAmountGreaterThanOrEqualTo(Double fbmBillAmountGreaterThanOrEqualTo) {
		this.fbmBillAmountGreaterThanOrEqualTo = fbmBillAmountGreaterThanOrEqualTo;
	}

	public Double getFbmBillAmountGreaterThan() {
		return fbmBillAmountGreaterThan;
	}
	public void setFbmBillAmountGreaterThan(Double fbmBillAmountGreaterThan) {
		this.fbmBillAmountGreaterThan = fbmBillAmountGreaterThan;
	}

	public Double getFbmBillAmountEqualTo() {
		return fbmBillAmountEqualTo;
	}
	public void setFbmBillAmountEqualTo(Double fbmBillAmountEqualTo) {
		this.fbmBillAmountEqualTo = fbmBillAmountEqualTo;
	}

	public java.util.List getFbmAssociateContractIdNotIn() {
		return fbmAssociateContractIdNotIn;
	}
	public void setFbmAssociateContractIdNotIn(java.util.List fbmAssociateContractIdNotIn) {
		this.fbmAssociateContractIdNotIn = fbmAssociateContractIdNotIn;
	}

	public Long getFbmAssociateContractIdNotEqualTo() {
		return fbmAssociateContractIdNotEqualTo;
	}
	public void setFbmAssociateContractIdNotEqualTo(Long fbmAssociateContractIdNotEqualTo) {
		this.fbmAssociateContractIdNotEqualTo = fbmAssociateContractIdNotEqualTo;
	}

	public Long getFbmAssociateContractIdLessThanOrEqualTo() {
		return fbmAssociateContractIdLessThanOrEqualTo;
	}
	public void setFbmAssociateContractIdLessThanOrEqualTo(Long fbmAssociateContractIdLessThanOrEqualTo) {
		this.fbmAssociateContractIdLessThanOrEqualTo = fbmAssociateContractIdLessThanOrEqualTo;
	}

	public Long getFbmAssociateContractIdLessThan() {
		return fbmAssociateContractIdLessThan;
	}
	public void setFbmAssociateContractIdLessThan(Long fbmAssociateContractIdLessThan) {
		this.fbmAssociateContractIdLessThan = fbmAssociateContractIdLessThan;
	}

	public Boolean getFbmAssociateContractIdIsNull() {
		return fbmAssociateContractIdIsNull;
	}
	public void setFbmAssociateContractIdIsNull(Boolean fbmAssociateContractIdIsNull) {
		this.fbmAssociateContractIdIsNull = fbmAssociateContractIdIsNull;
	}

	public Boolean getFbmAssociateContractIdIsNotNull() {
		return fbmAssociateContractIdIsNotNull;
	}
	public void setFbmAssociateContractIdIsNotNull(Boolean fbmAssociateContractIdIsNotNull) {
		this.fbmAssociateContractIdIsNotNull = fbmAssociateContractIdIsNotNull;
	}

	public java.util.List getFbmAssociateContractIdIn() {
		return fbmAssociateContractIdIn;
	}
	public void setFbmAssociateContractIdIn(java.util.List fbmAssociateContractIdIn) {
		this.fbmAssociateContractIdIn = fbmAssociateContractIdIn;
	}

	public Long getFbmAssociateContractIdGreaterThanOrEqualTo() {
		return fbmAssociateContractIdGreaterThanOrEqualTo;
	}
	public void setFbmAssociateContractIdGreaterThanOrEqualTo(Long fbmAssociateContractIdGreaterThanOrEqualTo) {
		this.fbmAssociateContractIdGreaterThanOrEqualTo = fbmAssociateContractIdGreaterThanOrEqualTo;
	}

	public Long getFbmAssociateContractIdGreaterThan() {
		return fbmAssociateContractIdGreaterThan;
	}
	public void setFbmAssociateContractIdGreaterThan(Long fbmAssociateContractIdGreaterThan) {
		this.fbmAssociateContractIdGreaterThan = fbmAssociateContractIdGreaterThan;
	}

	public Long getFbmAssociateContractIdEqualTo() {
		return fbmAssociateContractIdEqualTo;
	}
	public void setFbmAssociateContractIdEqualTo(Long fbmAssociateContractIdEqualTo) {
		this.fbmAssociateContractIdEqualTo = fbmAssociateContractIdEqualTo;
	}

	public java.util.List getFbmAssociateCarIdNotIn() {
		return fbmAssociateCarIdNotIn;
	}
	public void setFbmAssociateCarIdNotIn(java.util.List fbmAssociateCarIdNotIn) {
		this.fbmAssociateCarIdNotIn = fbmAssociateCarIdNotIn;
	}

	public Long getFbmAssociateCarIdNotEqualTo() {
		return fbmAssociateCarIdNotEqualTo;
	}
	public void setFbmAssociateCarIdNotEqualTo(Long fbmAssociateCarIdNotEqualTo) {
		this.fbmAssociateCarIdNotEqualTo = fbmAssociateCarIdNotEqualTo;
	}

	public Long getFbmAssociateCarIdLessThanOrEqualTo() {
		return fbmAssociateCarIdLessThanOrEqualTo;
	}
	public void setFbmAssociateCarIdLessThanOrEqualTo(Long fbmAssociateCarIdLessThanOrEqualTo) {
		this.fbmAssociateCarIdLessThanOrEqualTo = fbmAssociateCarIdLessThanOrEqualTo;
	}

	public Long getFbmAssociateCarIdLessThan() {
		return fbmAssociateCarIdLessThan;
	}
	public void setFbmAssociateCarIdLessThan(Long fbmAssociateCarIdLessThan) {
		this.fbmAssociateCarIdLessThan = fbmAssociateCarIdLessThan;
	}

	public Boolean getFbmAssociateCarIdIsNull() {
		return fbmAssociateCarIdIsNull;
	}
	public void setFbmAssociateCarIdIsNull(Boolean fbmAssociateCarIdIsNull) {
		this.fbmAssociateCarIdIsNull = fbmAssociateCarIdIsNull;
	}

	public Boolean getFbmAssociateCarIdIsNotNull() {
		return fbmAssociateCarIdIsNotNull;
	}
	public void setFbmAssociateCarIdIsNotNull(Boolean fbmAssociateCarIdIsNotNull) {
		this.fbmAssociateCarIdIsNotNull = fbmAssociateCarIdIsNotNull;
	}

	public java.util.List getFbmAssociateCarIdIn() {
		return fbmAssociateCarIdIn;
	}
	public void setFbmAssociateCarIdIn(java.util.List fbmAssociateCarIdIn) {
		this.fbmAssociateCarIdIn = fbmAssociateCarIdIn;
	}

	public Long getFbmAssociateCarIdGreaterThanOrEqualTo() {
		return fbmAssociateCarIdGreaterThanOrEqualTo;
	}
	public void setFbmAssociateCarIdGreaterThanOrEqualTo(Long fbmAssociateCarIdGreaterThanOrEqualTo) {
		this.fbmAssociateCarIdGreaterThanOrEqualTo = fbmAssociateCarIdGreaterThanOrEqualTo;
	}

	public Long getFbmAssociateCarIdGreaterThan() {
		return fbmAssociateCarIdGreaterThan;
	}
	public void setFbmAssociateCarIdGreaterThan(Long fbmAssociateCarIdGreaterThan) {
		this.fbmAssociateCarIdGreaterThan = fbmAssociateCarIdGreaterThan;
	}

	public Long getFbmAssociateCarIdEqualTo() {
		return fbmAssociateCarIdEqualTo;
	}
	public void setFbmAssociateCarIdEqualTo(Long fbmAssociateCarIdEqualTo) {
		this.fbmAssociateCarIdEqualTo = fbmAssociateCarIdEqualTo;
	}

	public java.util.List getFbmAlreadyRefundAmountNotIn() {
		return fbmAlreadyRefundAmountNotIn;
	}
	public void setFbmAlreadyRefundAmountNotIn(java.util.List fbmAlreadyRefundAmountNotIn) {
		this.fbmAlreadyRefundAmountNotIn = fbmAlreadyRefundAmountNotIn;
	}

	public Double getFbmAlreadyRefundAmountNotEqualTo() {
		return fbmAlreadyRefundAmountNotEqualTo;
	}
	public void setFbmAlreadyRefundAmountNotEqualTo(Double fbmAlreadyRefundAmountNotEqualTo) {
		this.fbmAlreadyRefundAmountNotEqualTo = fbmAlreadyRefundAmountNotEqualTo;
	}

	public Double getFbmAlreadyRefundAmountLessThanOrEqualTo() {
		return fbmAlreadyRefundAmountLessThanOrEqualTo;
	}
	public void setFbmAlreadyRefundAmountLessThanOrEqualTo(Double fbmAlreadyRefundAmountLessThanOrEqualTo) {
		this.fbmAlreadyRefundAmountLessThanOrEqualTo = fbmAlreadyRefundAmountLessThanOrEqualTo;
	}

	public Double getFbmAlreadyRefundAmountLessThan() {
		return fbmAlreadyRefundAmountLessThan;
	}
	public void setFbmAlreadyRefundAmountLessThan(Double fbmAlreadyRefundAmountLessThan) {
		this.fbmAlreadyRefundAmountLessThan = fbmAlreadyRefundAmountLessThan;
	}

	public Boolean getFbmAlreadyRefundAmountIsNull() {
		return fbmAlreadyRefundAmountIsNull;
	}
	public void setFbmAlreadyRefundAmountIsNull(Boolean fbmAlreadyRefundAmountIsNull) {
		this.fbmAlreadyRefundAmountIsNull = fbmAlreadyRefundAmountIsNull;
	}

	public Boolean getFbmAlreadyRefundAmountIsNotNull() {
		return fbmAlreadyRefundAmountIsNotNull;
	}
	public void setFbmAlreadyRefundAmountIsNotNull(Boolean fbmAlreadyRefundAmountIsNotNull) {
		this.fbmAlreadyRefundAmountIsNotNull = fbmAlreadyRefundAmountIsNotNull;
	}

	public java.util.List getFbmAlreadyRefundAmountIn() {
		return fbmAlreadyRefundAmountIn;
	}
	public void setFbmAlreadyRefundAmountIn(java.util.List fbmAlreadyRefundAmountIn) {
		this.fbmAlreadyRefundAmountIn = fbmAlreadyRefundAmountIn;
	}

	public Double getFbmAlreadyRefundAmountGreaterThanOrEqualTo() {
		return fbmAlreadyRefundAmountGreaterThanOrEqualTo;
	}
	public void setFbmAlreadyRefundAmountGreaterThanOrEqualTo(Double fbmAlreadyRefundAmountGreaterThanOrEqualTo) {
		this.fbmAlreadyRefundAmountGreaterThanOrEqualTo = fbmAlreadyRefundAmountGreaterThanOrEqualTo;
	}

	public Double getFbmAlreadyRefundAmountGreaterThan() {
		return fbmAlreadyRefundAmountGreaterThan;
	}
	public void setFbmAlreadyRefundAmountGreaterThan(Double fbmAlreadyRefundAmountGreaterThan) {
		this.fbmAlreadyRefundAmountGreaterThan = fbmAlreadyRefundAmountGreaterThan;
	}

	public Double getFbmAlreadyRefundAmountEqualTo() {
		return fbmAlreadyRefundAmountEqualTo;
	}
	public void setFbmAlreadyRefundAmountEqualTo(Double fbmAlreadyRefundAmountEqualTo) {
		this.fbmAlreadyRefundAmountEqualTo = fbmAlreadyRefundAmountEqualTo;
	}

	public java.util.List getDrNotIn() {
		return drNotIn;
	}
	public void setDrNotIn(java.util.List drNotIn) {
		this.drNotIn = drNotIn;
	}

	public Integer getDrNotEqualTo() {
		return drNotEqualTo;
	}
	public void setDrNotEqualTo(Integer drNotEqualTo) {
		this.drNotEqualTo = drNotEqualTo;
	}

	public Integer getDrLessThanOrEqualTo() {
		return drLessThanOrEqualTo;
	}
	public void setDrLessThanOrEqualTo(Integer drLessThanOrEqualTo) {
		this.drLessThanOrEqualTo = drLessThanOrEqualTo;
	}

	public Integer getDrLessThan() {
		return drLessThan;
	}
	public void setDrLessThan(Integer drLessThan) {
		this.drLessThan = drLessThan;
	}

	public Boolean getDrIsNull() {
		return drIsNull;
	}
	public void setDrIsNull(Boolean drIsNull) {
		this.drIsNull = drIsNull;
	}

	public Boolean getDrIsNotNull() {
		return drIsNotNull;
	}
	public void setDrIsNotNull(Boolean drIsNotNull) {
		this.drIsNotNull = drIsNotNull;
	}

	public java.util.List getDrIn() {
		return drIn;
	}
	public void setDrIn(java.util.List drIn) {
		this.drIn = drIn;
	}

	public Integer getDrGreaterThanOrEqualTo() {
		return drGreaterThanOrEqualTo;
	}
	public void setDrGreaterThanOrEqualTo(Integer drGreaterThanOrEqualTo) {
		this.drGreaterThanOrEqualTo = drGreaterThanOrEqualTo;
	}

	public Integer getDrGreaterThan() {
		return drGreaterThan;
	}
	public void setDrGreaterThan(Integer drGreaterThan) {
		this.drGreaterThan = drGreaterThan;
	}

	public Integer getDrEqualTo() {
		return drEqualTo;
	}
	public void setDrEqualTo(Integer drEqualTo) {
		this.drEqualTo = drEqualTo;
	}

	public String getCreateuserNotLike() {
		return createuserNotLike;
	}
	public void setCreateuserNotLike(String createuserNotLike) {
		this.createuserNotLike = createuserNotLike;
	}

	public java.util.List getCreateuserNotIn() {
		return createuserNotIn;
	}
	public void setCreateuserNotIn(java.util.List createuserNotIn) {
		this.createuserNotIn = createuserNotIn;
	}

	public String getCreateuserNotEqualTo() {
		return createuserNotEqualTo;
	}
	public void setCreateuserNotEqualTo(String createuserNotEqualTo) {
		this.createuserNotEqualTo = createuserNotEqualTo;
	}

	public String getCreateuserLike() {
		return createuserLike;
	}
	public void setCreateuserLike(String createuserLike) {
		this.createuserLike = createuserLike;
	}

	public String getCreateuserLessThanOrEqualTo() {
		return createuserLessThanOrEqualTo;
	}
	public void setCreateuserLessThanOrEqualTo(String createuserLessThanOrEqualTo) {
		this.createuserLessThanOrEqualTo = createuserLessThanOrEqualTo;
	}

	public String getCreateuserLessThan() {
		return createuserLessThan;
	}
	public void setCreateuserLessThan(String createuserLessThan) {
		this.createuserLessThan = createuserLessThan;
	}

	public Boolean getCreateuserIsNull() {
		return createuserIsNull;
	}
	public void setCreateuserIsNull(Boolean createuserIsNull) {
		this.createuserIsNull = createuserIsNull;
	}

	public Boolean getCreateuserIsNotNull() {
		return createuserIsNotNull;
	}
	public void setCreateuserIsNotNull(Boolean createuserIsNotNull) {
		this.createuserIsNotNull = createuserIsNotNull;
	}

	public java.util.List getCreateuserIn() {
		return createuserIn;
	}
	public void setCreateuserIn(java.util.List createuserIn) {
		this.createuserIn = createuserIn;
	}

	public String getCreateuserGreaterThanOrEqualTo() {
		return createuserGreaterThanOrEqualTo;
	}
	public void setCreateuserGreaterThanOrEqualTo(String createuserGreaterThanOrEqualTo) {
		this.createuserGreaterThanOrEqualTo = createuserGreaterThanOrEqualTo;
	}

	public String getCreateuserGreaterThan() {
		return createuserGreaterThan;
	}
	public void setCreateuserGreaterThan(String createuserGreaterThan) {
		this.createuserGreaterThan = createuserGreaterThan;
	}

	public String getCreateuserEqualTo() {
		return createuserEqualTo;
	}
	public void setCreateuserEqualTo(String createuserEqualTo) {
		this.createuserEqualTo = createuserEqualTo;
	}

	public java.util.List getCreatetimeNotIn() {
		return createtimeNotIn;
	}
	public void setCreatetimeNotIn(java.util.List createtimeNotIn) {
		this.createtimeNotIn = createtimeNotIn;
	}

	public java.util.Date getCreatetimeNotEqualTo() {
		return createtimeNotEqualTo;
	}
	public void setCreatetimeNotEqualTo(java.util.Date createtimeNotEqualTo) {
		this.createtimeNotEqualTo = createtimeNotEqualTo;
	}

	public java.util.Date getCreatetimeLessThanOrEqualTo() {
		return createtimeLessThanOrEqualTo;
	}
	public void setCreatetimeLessThanOrEqualTo(java.util.Date createtimeLessThanOrEqualTo) {
		this.createtimeLessThanOrEqualTo = createtimeLessThanOrEqualTo;
	}

	public java.util.Date getCreatetimeLessThan() {
		return createtimeLessThan;
	}
	public void setCreatetimeLessThan(java.util.Date createtimeLessThan) {
		this.createtimeLessThan = createtimeLessThan;
	}

	public Boolean getCreatetimeIsNull() {
		return createtimeIsNull;
	}
	public void setCreatetimeIsNull(Boolean createtimeIsNull) {
		this.createtimeIsNull = createtimeIsNull;
	}

	public Boolean getCreatetimeIsNotNull() {
		return createtimeIsNotNull;
	}
	public void setCreatetimeIsNotNull(Boolean createtimeIsNotNull) {
		this.createtimeIsNotNull = createtimeIsNotNull;
	}

	public java.util.List getCreatetimeIn() {
		return createtimeIn;
	}
	public void setCreatetimeIn(java.util.List createtimeIn) {
		this.createtimeIn = createtimeIn;
	}

	public java.util.Date getCreatetimeGreaterThanOrEqualTo() {
		return createtimeGreaterThanOrEqualTo;
	}
	public void setCreatetimeGreaterThanOrEqualTo(java.util.Date createtimeGreaterThanOrEqualTo) {
		this.createtimeGreaterThanOrEqualTo = createtimeGreaterThanOrEqualTo;
	}

	public java.util.Date getCreatetimeGreaterThan() {
		return createtimeGreaterThan;
	}
	public void setCreatetimeGreaterThan(java.util.Date createtimeGreaterThan) {
		this.createtimeGreaterThan = createtimeGreaterThan;
	}

	public java.util.Date getCreatetimeEqualTo() {
		return createtimeEqualTo;
	}
	public void setCreatetimeEqualTo(java.util.Date createtimeEqualTo) {
		this.createtimeEqualTo = createtimeEqualTo;
	}

	public void setSidx(String sidx) {
		this.sidx = sidx;
	}
	public String getSord() {
		return sord;
	}
	public void setSord(String sord) {
		 this.sord = sord;
	}
}
