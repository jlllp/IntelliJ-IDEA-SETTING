package com.mrk.finance.service;

import com.github.pagehelper.PageInfo;
import com.mrk.finance.client.dto.ContractAnalysisDto;
import com.mrk.finance.client.dto.FncContractManagementDto;
import com.mrk.finance.dto.ManagementRiskDto;
import com.mrk.finance.model.FncContractManagement;
import com.mrk.finance.queryvo.FncContractManagementQueryVo;

import java.util.Date;
import java.util.List;
import java.util.Map;

/**
 * @Description: FncContractManagement
 */
public interface FncContractManagementService {
    /**
     * 分页查询
     *
     * @param queryVo 前端查询对象
     * @return 分页查询数据
     */
    PageInfo<FncContractManagement> page(FncContractManagementQueryVo queryVo);

    /**
     * 分页查询(连表)
     *
     * @param queryVo 前端查询对象
     * @return 分页查询数据
     */
    PageInfo<FncContractManagement> pageWithTableJoin(FncContractManagementQueryVo queryVo);

    /**
     * 列表查询
     * @param queryVo 前端查询对象
     * @return 分页查询数据
     */
    List<FncContractManagement> list(FncContractManagementQueryVo queryVo);

    /**
     * 新增
     *
     * @param entity
     * @return 结果
     */
    int add(FncContractManagement entity);

    /**
     * 修改
     *
     * @param entity
     * @return 结果
     */
    int update(FncContractManagement entity);

    /**
     * @author Frank.Tang
     * @return *
     */
    int updateSelective(FncContractManagement entity);

    /**
     * 删除
     */
    int delete(Long id);

    /**
    * 通过ID查询
    * @param id
    */
    FncContractManagement getById(Long id);

    /**
     * 通过ids批量查
     * @author Frank.Tang
     * @return *
     */
    List<FncContractManagement> getByIds(List<Long> ids);

    /**
     * 根据合同号查询
     * @author Frank.Tang
     * @return *
     */
    List<FncContractManagement> getByCode(String code);

    /**
     * @author Bob
     * @date 2021/11/12
     * @description 获取指定状态下租赁和小于等于指定租赁起始日期的合同
     * @param state 指定状态
     * @param nowDate 指定时间
     * @return 今天开始租赁的合同
     */
    List<FncContractManagement> getStateAndStartDate(Integer state, Date nowDate);

    /**
     * @author Bob
     * @date 2021/11/12
     * @description 根据主键批量更新状态
     * @param state 状态
     * @param contractIdList 待更新状态的合同
     * @return 影响的行数
     */
    int updateStateByIdList(Integer state, List<Long> contractIdList);

    /**
     * @author Bob
     * @date 2021/11/12
     * @description 获取指定状态下租赁和小于等于指定租赁结束日期的合同
     * @param state 指定状态
     * @param nowDate 指定时间
     * @return 今天结束租赁的合同
     */
    List<FncContractManagement> getStateAndEndDate(Integer state, Date nowDate);

    /**
     * @author Bob
     * @date 2021/11/12
     * @description 获取指定合同状态和指定计算状态下，合同结束时间小于等于的合同
     * @param stateIn 状态集合
     * @param settlementState 结算状态
     * @param endDate 结束时间
     * @return 符合条件的合同
     */
    List<FncContractManagement> getStateInAndSettlementAndEndLTOE(List<Integer> stateIn, Integer settlementState, Date endDate);

    /**
     * @author Bob
     * @date 2021/11/15
     * @description 获取合同状态和合同类型下的所有合同
     * @param state 合同状态
     * @param type 合同类型
     * @return 符合条件的合同
     */
    List<FncContractManagement> getByStateAndType(Integer state, Integer type);

    /**
     * @author Bob
     * @date 2021/11/15
     * @description 获取合同状态和合同类型下的所有合同 并 排除掉指定的合同
     * @param state 合同状态
     * @param type 合同类型
     * @param contractIds 除掉指定的合同
     * @return 符合条件的合同
     */
    List<FncContractManagement> getByStateAndTypeAndIdNotIn(Integer state, Integer type, List<Long> contractIds);

    /**
     * @author Bob
     * @date 2021/11/17
     * @description 获取指定状态和结束时间小于等于的合同
     * @param state 合同状态
     * @param endDay 结束时间
     * @return 符合条件的合同
     */
    List<FncContractManagement> getByStateAndEndDateLTOE(Integer state, Date endDay);

    /**
     * @author Bob
     * @date 2021/11/17
     * @description 获取指定状态和结束时间小于等于的合同
     * @param state 合同状态
     * @param endDay 结束时间
     * @param contractIds 排除的合同id
     * @return 符合条件的合同
     */
    List<FncContractManagement> getByStateAndEndDateLTOEAndIdNotIn(Integer state, Date endDay, List<Long> contractIds);

    /**
     * @author Bob
     * @date 2021/11/22
     * @description 获取指定状态下的合同
     * @param state 合同状态
     * @return 符合条件的合同
     */
    List<FncContractManagement> getByState(Integer state);

    /**
     * @author Bob
     * @date 2021/11/22
     * @description 获取指定状态和结束时间大于等于的合同
     * @param state 合同状态
     * @param endDay 结束日期
     * @return 符合条件的合同
     */
    List<FncContractManagement> getByStateAndEndDateGTOE(Integer state, Date endDay);

    /**
     * @author Bob
     * @date 2021/11/24
     * @description 根据甲方id获取合同
     * @param id 甲方id
     * @return 符合条件的合同
     */
    List<FncContractManagement> getByPartyA(Long id);

    /**
     * @author Bob
     * @date 2021/12/24
     * @description 将合同状态不是指定状态的合同修改为指定状态
     *              通过合同id
     * @param state 状态
     * @param contractIds 合同id集合
     */
    void updateStateByStateAndIds(Integer state, List<Long> contractIds);

    /**
     * 根据合同Idlist查询合同集合
     * @param contractIdList
     * @return
     */
    List<FncContractManagement> selectContractByContractIdList(List<Long> contractIdList);

    /**
     * 获取租赁结束日期超过三天且没有处理过收车工单的合同
     * @return
     */
    List<FncContractManagement> selectRentTimeAndTurnerNo(Integer day);

    /**
     * 获取租赁中所有合同
     * @return
     */
    List<FncContractManagement> getAll();

    List<FncContractManagement> getAllByType();


    /**
     * 根据逾期天数获取账单
     */
    List<ManagementRiskDto> getOverdue(Integer day);

    /**
     * 天眼1.1, 查询合同对应的租金金额
     * @author Frank.Tang
     * @return <合同id, 金额>
     */
    List<ContractAnalysisDto> selectAllStartedContractWithRentAmount();

    /**测试用*/
    List<ContractAnalysisDto> selectAllContractWithRentAmountTest(int start, int size);

    /**
     * 新合同分页接口
     * @param queryVo
     * @return
     */
    PageInfo<FncContractManagement> getPage(FncContractManagementQueryVo queryVo);

    /**
     * 查询审批中或者执行
     * @param queryVo
     * @return
     */
    List<FncContractManagement> leasePage(FncContractManagementQueryVo queryVo);
}
