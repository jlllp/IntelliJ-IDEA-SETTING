package com.mrk.finance.service;

import com.github.pagehelper.PageInfo;
import com.mrk.finance.model.FncBillMatchRecord;
import com.mrk.finance.queryvo.FncBillMatchRecordQueryVo;

import java.util.List;

/**
 * @Description: FncBillMatchRecord
 */
public interface FncBillMatchRecordService {
    /**
     * 分页查询
     *
     * @param queryVo 前端查询对象
     * @return 分页查询数据
     */
    PageInfo<FncBillMatchRecord> page(FncBillMatchRecordQueryVo queryVo);

    /**
     * 列表查询
     * @param queryVo 前端查询对象
     * @return 分页查询数据
     */
    List<FncBillMatchRecord> list(FncBillMatchRecordQueryVo queryVo);

    /**
     * 新增
     *
     * @param entity
     * @return 结果
     */
    int add(FncBillMatchRecord entity);

    /**
     * 修改
     *
     * @param entity
     * @return 结果
     */
    int update(FncBillMatchRecord entity);

    /**
     * 删除
     */
    int delete(Long id);

    /**
    * 通过ID查询
    * @param id
    */
    FncBillMatchRecord getById(Long id);
}
