package com.mrk.finance.service.impl;

import com.github.pagehelper.PageInfo;
import com.mrk.common.constant.BaseConstants;
import com.mrk.common.utils.bean.BeanUtils;
import com.mrk.common.utils.page.PageUtils;
import com.mrk.finance.dao.FncConfirmIncomeMapper;
import com.mrk.finance.example.FncConfirmIncomeExample;
import com.mrk.finance.model.FncConfirmIncome;
import com.mrk.finance.query.FncConfirmIncomeQuery;
import com.mrk.finance.queryvo.FncConfirmIncomeQueryVo;
import com.mrk.finance.service.FncConfirmIncomeService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import javax.annotation.Resource;
import java.util.Date;
import java.util.List;


/**
 * @Description: FncConfirmIncomeServiceImpl
 */
@Service
@Slf4j
public class FncConfirmIncomeServiceImpl implements FncConfirmIncomeService {
    @Resource
    private FncConfirmIncomeMapper fncConfirmIncomeMapper;

    @Override
    public PageInfo<FncConfirmIncome> page(FncConfirmIncomeQueryVo queryVo){
        PageUtils.startPage();
        List<FncConfirmIncome> list = this.list(queryVo);
        return new PageInfo<>(list);
    }

    @Override
    public List<FncConfirmIncome> list(FncConfirmIncomeQueryVo queryVo){
        FncConfirmIncomeQuery query = new FncConfirmIncomeQuery();
        BeanUtils.copyBeanProp(queryVo, query);
        return fncConfirmIncomeMapper.selectByExample(query.getCrieria());
    }

    @Override
    @Transactional(rollbackFor = Exception.class)
    public int add(FncConfirmIncome entity){
        entity.setCreatetime(new Date());
        entity.setUpdatetime(new Date());
        entity.setDr(BaseConstants.DR_NO);
        return fncConfirmIncomeMapper.insert(entity);
    }

    @Override
    @Transactional(rollbackFor = Exception.class)
    public int update(FncConfirmIncome entity){
        entity.setUpdatetime(new Date());
        return fncConfirmIncomeMapper.updateByPrimaryKey(entity);
    }

    @Override
    @Transactional(rollbackFor = Exception.class)
    public int delete(Long id){
        return fncConfirmIncomeMapper.deleteByPrimaryKey(id);
    }

    @Override
    public FncConfirmIncome getById(Long id){
        return fncConfirmIncomeMapper.selectByPrimaryKey(id);
    }

    @Override
    public List<FncConfirmIncome> getByDept(Long deptId) {
        FncConfirmIncomeExample example = new FncConfirmIncomeExample();
        example.createCriteria()
                .andDrEqualTo(BaseConstants.DR_NO)
                .andFciDeptIdEqualTo(deptId);
        return fncConfirmIncomeMapper.selectByExample(example);
    }
}
