package com.mrk.finance.service.impl;

import com.github.pagehelper.PageInfo;
import com.mrk.common.constant.BaseConstants;
import com.mrk.common.utils.bean.BeanUtils;
import com.mrk.common.utils.jwt.JWTUtil;
import com.mrk.common.utils.page.PageUtils;
import com.mrk.common.utils.text.StringUtils;
import com.mrk.finance.dao.FncBankWaterMapper;
import com.mrk.finance.example.FncBankWaterExample;
import com.mrk.finance.model.FncBankWater;
import com.mrk.finance.query.FncBankWaterQuery;
import com.mrk.finance.queryvo.FncBankWaterQueryVo;
import com.mrk.finance.service.FncBankWaterService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import javax.annotation.Resource;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;


/**
 * @Description: FncBankWaterServiceImpl
 */
@Service
@Slf4j
public class FncBankWaterServiceImpl implements FncBankWaterService {
    @Resource
    private FncBankWaterMapper fncBankWaterMapper;

    @Override
    public PageInfo<FncBankWater> page(FncBankWaterQueryVo queryVo) {
        PageUtils.startPage();
        List<FncBankWater> list = this.list(queryVo);
        return new PageInfo<>(list);
    }

    @Override
    public List<FncBankWater> list(FncBankWaterQueryVo queryVo) {
        FncBankWaterQuery query = new FncBankWaterQuery();
        BeanUtils.copyBeanProp(queryVo, query);
        query.setSidx(StringUtils.camelToUnderlineAndFilterText(query.getSidx()));
        return fncBankWaterMapper.selectByExample(query.getCrieria());
    }

    @Override
    @Transactional(rollbackFor = Exception.class)
    public int add(FncBankWater entity) {
        entity.setCreatetime(new Date());
        entity.setCreateuser(JWTUtil.getNikeName());
        entity.setDr(BaseConstants.DR_NO);
        return fncBankWaterMapper.insert(entity);
    }

    @Override
    public int insertList(List<FncBankWater> waters) {
        if (waters == null || waters.isEmpty()) {
            return 0;
        }
        Date date = new Date();
        String name = JWTUtil.getNikeName();
        Integer drNo = BaseConstants.DR_NO;
        for (FncBankWater water : waters) {
            water.setCreateuser(name);
            water.setCreatetime(date);
            water.setDr(drNo);
        }
        return fncBankWaterMapper.insertList(waters);
    }

    @Override
    @Transactional(rollbackFor = Exception.class)
    public int update(FncBankWater entity) {
        entity.setUpdatetime(new Date());
        entity.setUpdateuser(JWTUtil.getNikeName());
        return fncBankWaterMapper.updateByPrimaryKey(entity);
    }

    @Override
    @Transactional(rollbackFor = Exception.class)
    public int delete(Long id) {
        return fncBankWaterMapper.deleteByPrimaryKey(id);
    }

    @Override
    public FncBankWater getById(Long id) {
        return fncBankWaterMapper.selectByPrimaryKey(id);
    }

    @Override
    public List<FncBankWater> getByIds(List<Long> ids) {
        if (ids == null || ids.isEmpty()) {
            return new ArrayList<>();
        }

        FncBankWaterExample example = new FncBankWaterExample();
        example.createCriteria()
                .andDrEqualTo(BaseConstants.DR_NO)
                .andFbwIdIn(ids);

        return fncBankWaterMapper.selectByExample(example);
    }

    @Override
    public List<FncBankWater> selectByBillId(Long id) {
        FncBankWaterExample example = new FncBankWaterExample();
        example.createCriteria()
                .andDrEqualTo(BaseConstants.DR_NO)
                .andFbwMatchBillLike(String.valueOf(id));
        return fncBankWaterMapper.selectByExample(example);
    }
}
