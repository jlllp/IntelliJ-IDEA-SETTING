package com.mrk.finance.example;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

public class FncDdWithholdExample {
    protected String orderByClause;

    protected boolean distinct;

    protected List<Criteria> oredCriteria;

    public FncDdWithholdExample() {
        oredCriteria = new ArrayList<Criteria>();
    }

    public void setOrderByClause(String orderByClause) {
        this.orderByClause = orderByClause;
    }

    public String getOrderByClause() {
        return orderByClause;
    }

    public void setDistinct(boolean distinct) {
        this.distinct = distinct;
    }

    public boolean isDistinct() {
        return distinct;
    }

    public List<Criteria> getOredCriteria() {
        return oredCriteria;
    }

    public void or(Criteria criteria) {
        oredCriteria.add(criteria);
    }

    public Criteria or() {
        Criteria criteria = createCriteriaInternal();
        oredCriteria.add(criteria);
        return criteria;
    }

    public Criteria createCriteria() {
        Criteria criteria = createCriteriaInternal();
        if (oredCriteria.size() == 0) {
            oredCriteria.add(criteria);
        }
        return criteria;
    }

    protected Criteria createCriteriaInternal() {
        Criteria criteria = new Criteria();
        return criteria;
    }

    public void clear() {
        oredCriteria.clear();
        orderByClause = null;
        distinct = false;
    }

    protected abstract static class GeneratedCriteria {
        protected List<Criterion> criteria;

        protected GeneratedCriteria() {
            super();
            criteria = new ArrayList<Criterion>();
        }

        public boolean isValid() {
            return criteria.size() > 0;
        }

        public List<Criterion> getAllCriteria() {
            return criteria;
        }

        public List<Criterion> getCriteria() {
            return criteria;
        }

        protected void addCriterion(String condition) {
            if (condition == null) {
                throw new RuntimeException("Value for condition cannot be null");
            }
            criteria.add(new Criterion(condition));
        }

        protected void addCriterion(String condition, Object value, String property) {
            if (value == null) {
                throw new RuntimeException("Value for " + property + " cannot be null");
            }
            criteria.add(new Criterion(condition, value));
        }

        protected void addCriterion(String condition, Object value1, Object value2, String property) {
            if (value1 == null || value2 == null) {
                throw new RuntimeException("Between values for " + property + " cannot be null");
            }
            criteria.add(new Criterion(condition, value1, value2));
        }

        public Criteria andFdwIdIsNull() {
            addCriterion("fdw_id is null");
            return (Criteria) this;
        }

        public Criteria andFdwIdIsNotNull() {
            addCriterion("fdw_id is not null");
            return (Criteria) this;
        }

        public Criteria andFdwIdEqualTo(Long value) {
            addCriterion("fdw_id =", value, "fdwId");
            return (Criteria) this;
        }

        public Criteria andFdwIdNotEqualTo(Long value) {
            addCriterion("fdw_id <>", value, "fdwId");
            return (Criteria) this;
        }

        public Criteria andFdwIdGreaterThan(Long value) {
            addCriterion("fdw_id >", value, "fdwId");
            return (Criteria) this;
        }

        public Criteria andFdwIdGreaterThanOrEqualTo(Long value) {
            addCriterion("fdw_id >=", value, "fdwId");
            return (Criteria) this;
        }

        public Criteria andFdwIdLessThan(Long value) {
            addCriterion("fdw_id <", value, "fdwId");
            return (Criteria) this;
        }

        public Criteria andFdwIdLessThanOrEqualTo(Long value) {
            addCriterion("fdw_id <=", value, "fdwId");
            return (Criteria) this;
        }

        public Criteria andFdwIdIn(List<Long> values) {
            addCriterion("fdw_id in", values, "fdwId");
            return (Criteria) this;
        }

        public Criteria andFdwIdNotIn(List<Long> values) {
            addCriterion("fdw_id not in", values, "fdwId");
            return (Criteria) this;
        }

        public Criteria andFdwIdBetween(Long value1, Long value2) {
            addCriterion("fdw_id between", value1, value2, "fdwId");
            return (Criteria) this;
        }

        public Criteria andFdwIdNotBetween(Long value1, Long value2) {
            addCriterion("fdw_id not between", value1, value2, "fdwId");
            return (Criteria) this;
        }

        public Criteria andFdwTradeNamesIsNull() {
            addCriterion("fdw_trade_names is null");
            return (Criteria) this;
        }

        public Criteria andFdwTradeNamesIsNotNull() {
            addCriterion("fdw_trade_names is not null");
            return (Criteria) this;
        }

        public Criteria andFdwTradeNamesEqualTo(String value) {
            addCriterion("fdw_trade_names =", value, "fdwTradeNames");
            return (Criteria) this;
        }

        public Criteria andFdwTradeNamesNotEqualTo(String value) {
            addCriterion("fdw_trade_names <>", value, "fdwTradeNames");
            return (Criteria) this;
        }

        public Criteria andFdwTradeNamesGreaterThan(String value) {
            addCriterion("fdw_trade_names >", value, "fdwTradeNames");
            return (Criteria) this;
        }

        public Criteria andFdwTradeNamesGreaterThanOrEqualTo(String value) {
            addCriterion("fdw_trade_names >=", value, "fdwTradeNames");
            return (Criteria) this;
        }

        public Criteria andFdwTradeNamesLessThan(String value) {
            addCriterion("fdw_trade_names <", value, "fdwTradeNames");
            return (Criteria) this;
        }

        public Criteria andFdwTradeNamesLessThanOrEqualTo(String value) {
            addCriterion("fdw_trade_names <=", value, "fdwTradeNames");
            return (Criteria) this;
        }

        public Criteria andFdwTradeNamesLike(String value) {
            addCriterion("fdw_trade_names like", value, "fdwTradeNames");
            return (Criteria) this;
        }

        public Criteria andFdwTradeNamesNotLike(String value) {
            addCriterion("fdw_trade_names not like", value, "fdwTradeNames");
            return (Criteria) this;
        }

        public Criteria andFdwTradeNamesIn(List<String> values) {
            addCriterion("fdw_trade_names in", values, "fdwTradeNames");
            return (Criteria) this;
        }

        public Criteria andFdwTradeNamesNotIn(List<String> values) {
            addCriterion("fdw_trade_names not in", values, "fdwTradeNames");
            return (Criteria) this;
        }

        public Criteria andFdwTradeNamesBetween(String value1, String value2) {
            addCriterion("fdw_trade_names between", value1, value2, "fdwTradeNames");
            return (Criteria) this;
        }

        public Criteria andFdwTradeNamesNotBetween(String value1, String value2) {
            addCriterion("fdw_trade_names not between", value1, value2, "fdwTradeNames");
            return (Criteria) this;
        }

        public Criteria andFdwAccountDealFlowIsNull() {
            addCriterion("fdw_account_deal_flow is null");
            return (Criteria) this;
        }

        public Criteria andFdwAccountDealFlowIsNotNull() {
            addCriterion("fdw_account_deal_flow is not null");
            return (Criteria) this;
        }

        public Criteria andFdwAccountDealFlowEqualTo(String value) {
            addCriterion("fdw_account_deal_flow =", value, "fdwAccountDealFlow");
            return (Criteria) this;
        }

        public Criteria andFdwAccountDealFlowNotEqualTo(String value) {
            addCriterion("fdw_account_deal_flow <>", value, "fdwAccountDealFlow");
            return (Criteria) this;
        }

        public Criteria andFdwAccountDealFlowGreaterThan(String value) {
            addCriterion("fdw_account_deal_flow >", value, "fdwAccountDealFlow");
            return (Criteria) this;
        }

        public Criteria andFdwAccountDealFlowGreaterThanOrEqualTo(String value) {
            addCriterion("fdw_account_deal_flow >=", value, "fdwAccountDealFlow");
            return (Criteria) this;
        }

        public Criteria andFdwAccountDealFlowLessThan(String value) {
            addCriterion("fdw_account_deal_flow <", value, "fdwAccountDealFlow");
            return (Criteria) this;
        }

        public Criteria andFdwAccountDealFlowLessThanOrEqualTo(String value) {
            addCriterion("fdw_account_deal_flow <=", value, "fdwAccountDealFlow");
            return (Criteria) this;
        }

        public Criteria andFdwAccountDealFlowLike(String value) {
            addCriterion("fdw_account_deal_flow like", value, "fdwAccountDealFlow");
            return (Criteria) this;
        }

        public Criteria andFdwAccountDealFlowNotLike(String value) {
            addCriterion("fdw_account_deal_flow not like", value, "fdwAccountDealFlow");
            return (Criteria) this;
        }

        public Criteria andFdwAccountDealFlowIn(List<String> values) {
            addCriterion("fdw_account_deal_flow in", values, "fdwAccountDealFlow");
            return (Criteria) this;
        }

        public Criteria andFdwAccountDealFlowNotIn(List<String> values) {
            addCriterion("fdw_account_deal_flow not in", values, "fdwAccountDealFlow");
            return (Criteria) this;
        }

        public Criteria andFdwAccountDealFlowBetween(String value1, String value2) {
            addCriterion("fdw_account_deal_flow between", value1, value2, "fdwAccountDealFlow");
            return (Criteria) this;
        }

        public Criteria andFdwAccountDealFlowNotBetween(String value1, String value2) {
            addCriterion("fdw_account_deal_flow not between", value1, value2, "fdwAccountDealFlow");
            return (Criteria) this;
        }

        public Criteria andFdwTradeTimeIsNull() {
            addCriterion("fdw_trade_time is null");
            return (Criteria) this;
        }

        public Criteria andFdwTradeTimeIsNotNull() {
            addCriterion("fdw_trade_time is not null");
            return (Criteria) this;
        }

        public Criteria andFdwTradeTimeEqualTo(Date value) {
            addCriterion("fdw_trade_time =", value, "fdwTradeTime");
            return (Criteria) this;
        }

        public Criteria andFdwTradeTimeNotEqualTo(Date value) {
            addCriterion("fdw_trade_time <>", value, "fdwTradeTime");
            return (Criteria) this;
        }

        public Criteria andFdwTradeTimeGreaterThan(Date value) {
            addCriterion("fdw_trade_time >", value, "fdwTradeTime");
            return (Criteria) this;
        }

        public Criteria andFdwTradeTimeGreaterThanOrEqualTo(Date value) {
            addCriterion("fdw_trade_time >=", value, "fdwTradeTime");
            return (Criteria) this;
        }

        public Criteria andFdwTradeTimeLessThan(Date value) {
            addCriterion("fdw_trade_time <", value, "fdwTradeTime");
            return (Criteria) this;
        }

        public Criteria andFdwTradeTimeLessThanOrEqualTo(Date value) {
            addCriterion("fdw_trade_time <=", value, "fdwTradeTime");
            return (Criteria) this;
        }

        public Criteria andFdwTradeTimeIn(List<Date> values) {
            addCriterion("fdw_trade_time in", values, "fdwTradeTime");
            return (Criteria) this;
        }

        public Criteria andFdwTradeTimeNotIn(List<Date> values) {
            addCriterion("fdw_trade_time not in", values, "fdwTradeTime");
            return (Criteria) this;
        }

        public Criteria andFdwTradeTimeBetween(Date value1, Date value2) {
            addCriterion("fdw_trade_time between", value1, value2, "fdwTradeTime");
            return (Criteria) this;
        }

        public Criteria andFdwTradeTimeNotBetween(Date value1, Date value2) {
            addCriterion("fdw_trade_time not between", value1, value2, "fdwTradeTime");
            return (Criteria) this;
        }

        public Criteria andFdwTradePartyIsNull() {
            addCriterion("fdw_trade_party is null");
            return (Criteria) this;
        }

        public Criteria andFdwTradePartyIsNotNull() {
            addCriterion("fdw_trade_party is not null");
            return (Criteria) this;
        }

        public Criteria andFdwTradePartyEqualTo(String value) {
            addCriterion("fdw_trade_party =", value, "fdwTradeParty");
            return (Criteria) this;
        }

        public Criteria andFdwTradePartyNotEqualTo(String value) {
            addCriterion("fdw_trade_party <>", value, "fdwTradeParty");
            return (Criteria) this;
        }

        public Criteria andFdwTradePartyGreaterThan(String value) {
            addCriterion("fdw_trade_party >", value, "fdwTradeParty");
            return (Criteria) this;
        }

        public Criteria andFdwTradePartyGreaterThanOrEqualTo(String value) {
            addCriterion("fdw_trade_party >=", value, "fdwTradeParty");
            return (Criteria) this;
        }

        public Criteria andFdwTradePartyLessThan(String value) {
            addCriterion("fdw_trade_party <", value, "fdwTradeParty");
            return (Criteria) this;
        }

        public Criteria andFdwTradePartyLessThanOrEqualTo(String value) {
            addCriterion("fdw_trade_party <=", value, "fdwTradeParty");
            return (Criteria) this;
        }

        public Criteria andFdwTradePartyLike(String value) {
            addCriterion("fdw_trade_party like", value, "fdwTradeParty");
            return (Criteria) this;
        }

        public Criteria andFdwTradePartyNotLike(String value) {
            addCriterion("fdw_trade_party not like", value, "fdwTradeParty");
            return (Criteria) this;
        }

        public Criteria andFdwTradePartyIn(List<String> values) {
            addCriterion("fdw_trade_party in", values, "fdwTradeParty");
            return (Criteria) this;
        }

        public Criteria andFdwTradePartyNotIn(List<String> values) {
            addCriterion("fdw_trade_party not in", values, "fdwTradeParty");
            return (Criteria) this;
        }

        public Criteria andFdwTradePartyBetween(String value1, String value2) {
            addCriterion("fdw_trade_party between", value1, value2, "fdwTradeParty");
            return (Criteria) this;
        }

        public Criteria andFdwTradePartyNotBetween(String value1, String value2) {
            addCriterion("fdw_trade_party not between", value1, value2, "fdwTradeParty");
            return (Criteria) this;
        }

        public Criteria andFdwTradeAmountIsNull() {
            addCriterion("fdw_trade_amount is null");
            return (Criteria) this;
        }

        public Criteria andFdwTradeAmountIsNotNull() {
            addCriterion("fdw_trade_amount is not null");
            return (Criteria) this;
        }

        public Criteria andFdwTradeAmountEqualTo(Double value) {
            addCriterion("fdw_trade_amount =", value, "fdwTradeAmount");
            return (Criteria) this;
        }

        public Criteria andFdwTradeAmountNotEqualTo(Double value) {
            addCriterion("fdw_trade_amount <>", value, "fdwTradeAmount");
            return (Criteria) this;
        }

        public Criteria andFdwTradeAmountGreaterThan(Double value) {
            addCriterion("fdw_trade_amount >", value, "fdwTradeAmount");
            return (Criteria) this;
        }

        public Criteria andFdwTradeAmountGreaterThanOrEqualTo(Double value) {
            addCriterion("fdw_trade_amount >=", value, "fdwTradeAmount");
            return (Criteria) this;
        }

        public Criteria andFdwTradeAmountLessThan(Double value) {
            addCriterion("fdw_trade_amount <", value, "fdwTradeAmount");
            return (Criteria) this;
        }

        public Criteria andFdwTradeAmountLessThanOrEqualTo(Double value) {
            addCriterion("fdw_trade_amount <=", value, "fdwTradeAmount");
            return (Criteria) this;
        }

        public Criteria andFdwTradeAmountIn(List<Double> values) {
            addCriterion("fdw_trade_amount in", values, "fdwTradeAmount");
            return (Criteria) this;
        }

        public Criteria andFdwTradeAmountNotIn(List<Double> values) {
            addCriterion("fdw_trade_amount not in", values, "fdwTradeAmount");
            return (Criteria) this;
        }

        public Criteria andFdwTradeAmountBetween(Double value1, Double value2) {
            addCriterion("fdw_trade_amount between", value1, value2, "fdwTradeAmount");
            return (Criteria) this;
        }

        public Criteria andFdwTradeAmountNotBetween(Double value1, Double value2) {
            addCriterion("fdw_trade_amount not between", value1, value2, "fdwTradeAmount");
            return (Criteria) this;
        }

        public Criteria andFdwOrderNoIsNull() {
            addCriterion("fdw_order_no is null");
            return (Criteria) this;
        }

        public Criteria andFdwOrderNoIsNotNull() {
            addCriterion("fdw_order_no is not null");
            return (Criteria) this;
        }

        public Criteria andFdwOrderNoEqualTo(String value) {
            addCriterion("fdw_order_no =", value, "fdwOrderNo");
            return (Criteria) this;
        }

        public Criteria andFdwOrderNoNotEqualTo(String value) {
            addCriterion("fdw_order_no <>", value, "fdwOrderNo");
            return (Criteria) this;
        }

        public Criteria andFdwOrderNoGreaterThan(String value) {
            addCriterion("fdw_order_no >", value, "fdwOrderNo");
            return (Criteria) this;
        }

        public Criteria andFdwOrderNoGreaterThanOrEqualTo(String value) {
            addCriterion("fdw_order_no >=", value, "fdwOrderNo");
            return (Criteria) this;
        }

        public Criteria andFdwOrderNoLessThan(String value) {
            addCriterion("fdw_order_no <", value, "fdwOrderNo");
            return (Criteria) this;
        }

        public Criteria andFdwOrderNoLessThanOrEqualTo(String value) {
            addCriterion("fdw_order_no <=", value, "fdwOrderNo");
            return (Criteria) this;
        }

        public Criteria andFdwOrderNoLike(String value) {
            addCriterion("fdw_order_no like", value, "fdwOrderNo");
            return (Criteria) this;
        }

        public Criteria andFdwOrderNoNotLike(String value) {
            addCriterion("fdw_order_no not like", value, "fdwOrderNo");
            return (Criteria) this;
        }

        public Criteria andFdwOrderNoIn(List<String> values) {
            addCriterion("fdw_order_no in", values, "fdwOrderNo");
            return (Criteria) this;
        }

        public Criteria andFdwOrderNoNotIn(List<String> values) {
            addCriterion("fdw_order_no not in", values, "fdwOrderNo");
            return (Criteria) this;
        }

        public Criteria andFdwOrderNoBetween(String value1, String value2) {
            addCriterion("fdw_order_no between", value1, value2, "fdwOrderNo");
            return (Criteria) this;
        }

        public Criteria andFdwOrderNoNotBetween(String value1, String value2) {
            addCriterion("fdw_order_no not between", value1, value2, "fdwOrderNo");
            return (Criteria) this;
        }

        public Criteria andFdwAccountNoIsNull() {
            addCriterion("fdw_account_no is null");
            return (Criteria) this;
        }

        public Criteria andFdwAccountNoIsNotNull() {
            addCriterion("fdw_account_no is not null");
            return (Criteria) this;
        }

        public Criteria andFdwAccountNoEqualTo(String value) {
            addCriterion("fdw_account_no =", value, "fdwAccountNo");
            return (Criteria) this;
        }

        public Criteria andFdwAccountNoNotEqualTo(String value) {
            addCriterion("fdw_account_no <>", value, "fdwAccountNo");
            return (Criteria) this;
        }

        public Criteria andFdwAccountNoGreaterThan(String value) {
            addCriterion("fdw_account_no >", value, "fdwAccountNo");
            return (Criteria) this;
        }

        public Criteria andFdwAccountNoGreaterThanOrEqualTo(String value) {
            addCriterion("fdw_account_no >=", value, "fdwAccountNo");
            return (Criteria) this;
        }

        public Criteria andFdwAccountNoLessThan(String value) {
            addCriterion("fdw_account_no <", value, "fdwAccountNo");
            return (Criteria) this;
        }

        public Criteria andFdwAccountNoLessThanOrEqualTo(String value) {
            addCriterion("fdw_account_no <=", value, "fdwAccountNo");
            return (Criteria) this;
        }

        public Criteria andFdwAccountNoLike(String value) {
            addCriterion("fdw_account_no like", value, "fdwAccountNo");
            return (Criteria) this;
        }

        public Criteria andFdwAccountNoNotLike(String value) {
            addCriterion("fdw_account_no not like", value, "fdwAccountNo");
            return (Criteria) this;
        }

        public Criteria andFdwAccountNoIn(List<String> values) {
            addCriterion("fdw_account_no in", values, "fdwAccountNo");
            return (Criteria) this;
        }

        public Criteria andFdwAccountNoNotIn(List<String> values) {
            addCriterion("fdw_account_no not in", values, "fdwAccountNo");
            return (Criteria) this;
        }

        public Criteria andFdwAccountNoBetween(String value1, String value2) {
            addCriterion("fdw_account_no between", value1, value2, "fdwAccountNo");
            return (Criteria) this;
        }

        public Criteria andFdwAccountNoNotBetween(String value1, String value2) {
            addCriterion("fdw_account_no not between", value1, value2, "fdwAccountNo");
            return (Criteria) this;
        }

        public Criteria andFdwCarVinIsNull() {
            addCriterion("fdw_car_vin is null");
            return (Criteria) this;
        }

        public Criteria andFdwCarVinIsNotNull() {
            addCriterion("fdw_car_vin is not null");
            return (Criteria) this;
        }

        public Criteria andFdwCarVinEqualTo(String value) {
            addCriterion("fdw_car_vin =", value, "fdwCarVin");
            return (Criteria) this;
        }

        public Criteria andFdwCarVinNotEqualTo(String value) {
            addCriterion("fdw_car_vin <>", value, "fdwCarVin");
            return (Criteria) this;
        }

        public Criteria andFdwCarVinGreaterThan(String value) {
            addCriterion("fdw_car_vin >", value, "fdwCarVin");
            return (Criteria) this;
        }

        public Criteria andFdwCarVinGreaterThanOrEqualTo(String value) {
            addCriterion("fdw_car_vin >=", value, "fdwCarVin");
            return (Criteria) this;
        }

        public Criteria andFdwCarVinLessThan(String value) {
            addCriterion("fdw_car_vin <", value, "fdwCarVin");
            return (Criteria) this;
        }

        public Criteria andFdwCarVinLessThanOrEqualTo(String value) {
            addCriterion("fdw_car_vin <=", value, "fdwCarVin");
            return (Criteria) this;
        }

        public Criteria andFdwCarVinLike(String value) {
            addCriterion("fdw_car_vin like", value, "fdwCarVin");
            return (Criteria) this;
        }

        public Criteria andFdwCarVinNotLike(String value) {
            addCriterion("fdw_car_vin not like", value, "fdwCarVin");
            return (Criteria) this;
        }

        public Criteria andFdwCarVinIn(List<String> values) {
            addCriterion("fdw_car_vin in", values, "fdwCarVin");
            return (Criteria) this;
        }

        public Criteria andFdwCarVinNotIn(List<String> values) {
            addCriterion("fdw_car_vin not in", values, "fdwCarVin");
            return (Criteria) this;
        }

        public Criteria andFdwCarVinBetween(String value1, String value2) {
            addCriterion("fdw_car_vin between", value1, value2, "fdwCarVin");
            return (Criteria) this;
        }

        public Criteria andFdwCarVinNotBetween(String value1, String value2) {
            addCriterion("fdw_car_vin not between", value1, value2, "fdwCarVin");
            return (Criteria) this;
        }

        public Criteria andFdwMatchStateIsNull() {
            addCriterion("fdw_match_state is null");
            return (Criteria) this;
        }

        public Criteria andFdwMatchStateIsNotNull() {
            addCriterion("fdw_match_state is not null");
            return (Criteria) this;
        }

        public Criteria andFdwMatchStateEqualTo(Integer value) {
            addCriterion("fdw_match_state =", value, "fdwMatchState");
            return (Criteria) this;
        }

        public Criteria andFdwMatchStateNotEqualTo(Integer value) {
            addCriterion("fdw_match_state <>", value, "fdwMatchState");
            return (Criteria) this;
        }

        public Criteria andFdwMatchStateGreaterThan(Integer value) {
            addCriterion("fdw_match_state >", value, "fdwMatchState");
            return (Criteria) this;
        }

        public Criteria andFdwMatchStateGreaterThanOrEqualTo(Integer value) {
            addCriterion("fdw_match_state >=", value, "fdwMatchState");
            return (Criteria) this;
        }

        public Criteria andFdwMatchStateLessThan(Integer value) {
            addCriterion("fdw_match_state <", value, "fdwMatchState");
            return (Criteria) this;
        }

        public Criteria andFdwMatchStateLessThanOrEqualTo(Integer value) {
            addCriterion("fdw_match_state <=", value, "fdwMatchState");
            return (Criteria) this;
        }

        public Criteria andFdwMatchStateIn(List<Integer> values) {
            addCriterion("fdw_match_state in", values, "fdwMatchState");
            return (Criteria) this;
        }

        public Criteria andFdwMatchStateNotIn(List<Integer> values) {
            addCriterion("fdw_match_state not in", values, "fdwMatchState");
            return (Criteria) this;
        }

        public Criteria andFdwMatchStateBetween(Integer value1, Integer value2) {
            addCriterion("fdw_match_state between", value1, value2, "fdwMatchState");
            return (Criteria) this;
        }

        public Criteria andFdwMatchStateNotBetween(Integer value1, Integer value2) {
            addCriterion("fdw_match_state not between", value1, value2, "fdwMatchState");
            return (Criteria) this;
        }

        public Criteria andFdwMatchBillIsNull() {
            addCriterion("fdw_match_bill is null");
            return (Criteria) this;
        }

        public Criteria andFdwMatchBillIsNotNull() {
            addCriterion("fdw_match_bill is not null");
            return (Criteria) this;
        }

        public Criteria andFdwMatchBillEqualTo(String value) {
            addCriterion("fdw_match_bill =", value, "fdwMatchBill");
            return (Criteria) this;
        }

        public Criteria andFdwMatchBillNotEqualTo(String value) {
            addCriterion("fdw_match_bill <>", value, "fdwMatchBill");
            return (Criteria) this;
        }

        public Criteria andFdwMatchBillGreaterThan(String value) {
            addCriterion("fdw_match_bill >", value, "fdwMatchBill");
            return (Criteria) this;
        }

        public Criteria andFdwMatchBillGreaterThanOrEqualTo(String value) {
            addCriterion("fdw_match_bill >=", value, "fdwMatchBill");
            return (Criteria) this;
        }

        public Criteria andFdwMatchBillLessThan(String value) {
            addCriterion("fdw_match_bill <", value, "fdwMatchBill");
            return (Criteria) this;
        }

        public Criteria andFdwMatchBillLessThanOrEqualTo(String value) {
            addCriterion("fdw_match_bill <=", value, "fdwMatchBill");
            return (Criteria) this;
        }

        public Criteria andFdwMatchBillLike(String value) {
            addCriterion("fdw_match_bill like", value, "fdwMatchBill");
            return (Criteria) this;
        }

        public Criteria andFdwMatchBillNotLike(String value) {
            addCriterion("fdw_match_bill not like", value, "fdwMatchBill");
            return (Criteria) this;
        }

        public Criteria andFdwMatchBillIn(List<String> values) {
            addCriterion("fdw_match_bill in", values, "fdwMatchBill");
            return (Criteria) this;
        }

        public Criteria andFdwMatchBillNotIn(List<String> values) {
            addCriterion("fdw_match_bill not in", values, "fdwMatchBill");
            return (Criteria) this;
        }

        public Criteria andFdwMatchBillBetween(String value1, String value2) {
            addCriterion("fdw_match_bill between", value1, value2, "fdwMatchBill");
            return (Criteria) this;
        }

        public Criteria andFdwMatchBillNotBetween(String value1, String value2) {
            addCriterion("fdw_match_bill not between", value1, value2, "fdwMatchBill");
            return (Criteria) this;
        }

        public Criteria andFdwMatchWayIsNull() {
            addCriterion("fdw_match_way is null");
            return (Criteria) this;
        }

        public Criteria andFdwMatchWayIsNotNull() {
            addCriterion("fdw_match_way is not null");
            return (Criteria) this;
        }

        public Criteria andFdwMatchWayEqualTo(Integer value) {
            addCriterion("fdw_match_way =", value, "fdwMatchWay");
            return (Criteria) this;
        }

        public Criteria andFdwMatchWayNotEqualTo(Integer value) {
            addCriterion("fdw_match_way <>", value, "fdwMatchWay");
            return (Criteria) this;
        }

        public Criteria andFdwMatchWayGreaterThan(Integer value) {
            addCriterion("fdw_match_way >", value, "fdwMatchWay");
            return (Criteria) this;
        }

        public Criteria andFdwMatchWayGreaterThanOrEqualTo(Integer value) {
            addCriterion("fdw_match_way >=", value, "fdwMatchWay");
            return (Criteria) this;
        }

        public Criteria andFdwMatchWayLessThan(Integer value) {
            addCriterion("fdw_match_way <", value, "fdwMatchWay");
            return (Criteria) this;
        }

        public Criteria andFdwMatchWayLessThanOrEqualTo(Integer value) {
            addCriterion("fdw_match_way <=", value, "fdwMatchWay");
            return (Criteria) this;
        }

        public Criteria andFdwMatchWayIn(List<Integer> values) {
            addCriterion("fdw_match_way in", values, "fdwMatchWay");
            return (Criteria) this;
        }

        public Criteria andFdwMatchWayNotIn(List<Integer> values) {
            addCriterion("fdw_match_way not in", values, "fdwMatchWay");
            return (Criteria) this;
        }

        public Criteria andFdwMatchWayBetween(Integer value1, Integer value2) {
            addCriterion("fdw_match_way between", value1, value2, "fdwMatchWay");
            return (Criteria) this;
        }

        public Criteria andFdwMatchWayNotBetween(Integer value1, Integer value2) {
            addCriterion("fdw_match_way not between", value1, value2, "fdwMatchWay");
            return (Criteria) this;
        }

        public Criteria andFdwMatchedAmountIsNull() {
            addCriterion("fdw_matched_amount is null");
            return (Criteria) this;
        }

        public Criteria andFdwMatchedAmountIsNotNull() {
            addCriterion("fdw_matched_amount is not null");
            return (Criteria) this;
        }

        public Criteria andFdwMatchedAmountEqualTo(Double value) {
            addCriterion("fdw_matched_amount =", value, "fdwMatchedAmount");
            return (Criteria) this;
        }

        public Criteria andFdwMatchedAmountNotEqualTo(Double value) {
            addCriterion("fdw_matched_amount <>", value, "fdwMatchedAmount");
            return (Criteria) this;
        }

        public Criteria andFdwMatchedAmountGreaterThan(Double value) {
            addCriterion("fdw_matched_amount >", value, "fdwMatchedAmount");
            return (Criteria) this;
        }

        public Criteria andFdwMatchedAmountGreaterThanOrEqualTo(Double value) {
            addCriterion("fdw_matched_amount >=", value, "fdwMatchedAmount");
            return (Criteria) this;
        }

        public Criteria andFdwMatchedAmountLessThan(Double value) {
            addCriterion("fdw_matched_amount <", value, "fdwMatchedAmount");
            return (Criteria) this;
        }

        public Criteria andFdwMatchedAmountLessThanOrEqualTo(Double value) {
            addCriterion("fdw_matched_amount <=", value, "fdwMatchedAmount");
            return (Criteria) this;
        }

        public Criteria andFdwMatchedAmountIn(List<Double> values) {
            addCriterion("fdw_matched_amount in", values, "fdwMatchedAmount");
            return (Criteria) this;
        }

        public Criteria andFdwMatchedAmountNotIn(List<Double> values) {
            addCriterion("fdw_matched_amount not in", values, "fdwMatchedAmount");
            return (Criteria) this;
        }

        public Criteria andFdwMatchedAmountBetween(Double value1, Double value2) {
            addCriterion("fdw_matched_amount between", value1, value2, "fdwMatchedAmount");
            return (Criteria) this;
        }

        public Criteria andFdwMatchedAmountNotBetween(Double value1, Double value2) {
            addCriterion("fdw_matched_amount not between", value1, value2, "fdwMatchedAmount");
            return (Criteria) this;
        }

        public Criteria andFdwNotMatchAmountIsNull() {
            addCriterion("fdw_not_match_amount is null");
            return (Criteria) this;
        }

        public Criteria andFdwNotMatchAmountIsNotNull() {
            addCriterion("fdw_not_match_amount is not null");
            return (Criteria) this;
        }

        public Criteria andFdwNotMatchAmountEqualTo(Double value) {
            addCriterion("fdw_not_match_amount =", value, "fdwNotMatchAmount");
            return (Criteria) this;
        }

        public Criteria andFdwNotMatchAmountNotEqualTo(Double value) {
            addCriterion("fdw_not_match_amount <>", value, "fdwNotMatchAmount");
            return (Criteria) this;
        }

        public Criteria andFdwNotMatchAmountGreaterThan(Double value) {
            addCriterion("fdw_not_match_amount >", value, "fdwNotMatchAmount");
            return (Criteria) this;
        }

        public Criteria andFdwNotMatchAmountGreaterThanOrEqualTo(Double value) {
            addCriterion("fdw_not_match_amount >=", value, "fdwNotMatchAmount");
            return (Criteria) this;
        }

        public Criteria andFdwNotMatchAmountLessThan(Double value) {
            addCriterion("fdw_not_match_amount <", value, "fdwNotMatchAmount");
            return (Criteria) this;
        }

        public Criteria andFdwNotMatchAmountLessThanOrEqualTo(Double value) {
            addCriterion("fdw_not_match_amount <=", value, "fdwNotMatchAmount");
            return (Criteria) this;
        }

        public Criteria andFdwNotMatchAmountIn(List<Double> values) {
            addCriterion("fdw_not_match_amount in", values, "fdwNotMatchAmount");
            return (Criteria) this;
        }

        public Criteria andFdwNotMatchAmountNotIn(List<Double> values) {
            addCriterion("fdw_not_match_amount not in", values, "fdwNotMatchAmount");
            return (Criteria) this;
        }

        public Criteria andFdwNotMatchAmountBetween(Double value1, Double value2) {
            addCriterion("fdw_not_match_amount between", value1, value2, "fdwNotMatchAmount");
            return (Criteria) this;
        }

        public Criteria andFdwNotMatchAmountNotBetween(Double value1, Double value2) {
            addCriterion("fdw_not_match_amount not between", value1, value2, "fdwNotMatchAmount");
            return (Criteria) this;
        }

        public Criteria andRemarkIsNull() {
            addCriterion("remark is null");
            return (Criteria) this;
        }

        public Criteria andRemarkIsNotNull() {
            addCriterion("remark is not null");
            return (Criteria) this;
        }

        public Criteria andRemarkEqualTo(String value) {
            addCriterion("remark =", value, "remark");
            return (Criteria) this;
        }

        public Criteria andRemarkNotEqualTo(String value) {
            addCriterion("remark <>", value, "remark");
            return (Criteria) this;
        }

        public Criteria andRemarkGreaterThan(String value) {
            addCriterion("remark >", value, "remark");
            return (Criteria) this;
        }

        public Criteria andRemarkGreaterThanOrEqualTo(String value) {
            addCriterion("remark >=", value, "remark");
            return (Criteria) this;
        }

        public Criteria andRemarkLessThan(String value) {
            addCriterion("remark <", value, "remark");
            return (Criteria) this;
        }

        public Criteria andRemarkLessThanOrEqualTo(String value) {
            addCriterion("remark <=", value, "remark");
            return (Criteria) this;
        }

        public Criteria andRemarkLike(String value) {
            addCriterion("remark like", value, "remark");
            return (Criteria) this;
        }

        public Criteria andRemarkNotLike(String value) {
            addCriterion("remark not like", value, "remark");
            return (Criteria) this;
        }

        public Criteria andRemarkIn(List<String> values) {
            addCriterion("remark in", values, "remark");
            return (Criteria) this;
        }

        public Criteria andRemarkNotIn(List<String> values) {
            addCriterion("remark not in", values, "remark");
            return (Criteria) this;
        }

        public Criteria andRemarkBetween(String value1, String value2) {
            addCriterion("remark between", value1, value2, "remark");
            return (Criteria) this;
        }

        public Criteria andRemarkNotBetween(String value1, String value2) {
            addCriterion("remark not between", value1, value2, "remark");
            return (Criteria) this;
        }

        public Criteria andCreateuserIsNull() {
            addCriterion("createuser is null");
            return (Criteria) this;
        }

        public Criteria andCreateuserIsNotNull() {
            addCriterion("createuser is not null");
            return (Criteria) this;
        }

        public Criteria andCreateuserEqualTo(String value) {
            addCriterion("createuser =", value, "createuser");
            return (Criteria) this;
        }

        public Criteria andCreateuserNotEqualTo(String value) {
            addCriterion("createuser <>", value, "createuser");
            return (Criteria) this;
        }

        public Criteria andCreateuserGreaterThan(String value) {
            addCriterion("createuser >", value, "createuser");
            return (Criteria) this;
        }

        public Criteria andCreateuserGreaterThanOrEqualTo(String value) {
            addCriterion("createuser >=", value, "createuser");
            return (Criteria) this;
        }

        public Criteria andCreateuserLessThan(String value) {
            addCriterion("createuser <", value, "createuser");
            return (Criteria) this;
        }

        public Criteria andCreateuserLessThanOrEqualTo(String value) {
            addCriterion("createuser <=", value, "createuser");
            return (Criteria) this;
        }

        public Criteria andCreateuserLike(String value) {
            addCriterion("createuser like", value, "createuser");
            return (Criteria) this;
        }

        public Criteria andCreateuserNotLike(String value) {
            addCriterion("createuser not like", value, "createuser");
            return (Criteria) this;
        }

        public Criteria andCreateuserIn(List<String> values) {
            addCriterion("createuser in", values, "createuser");
            return (Criteria) this;
        }

        public Criteria andCreateuserNotIn(List<String> values) {
            addCriterion("createuser not in", values, "createuser");
            return (Criteria) this;
        }

        public Criteria andCreateuserBetween(String value1, String value2) {
            addCriterion("createuser between", value1, value2, "createuser");
            return (Criteria) this;
        }

        public Criteria andCreateuserNotBetween(String value1, String value2) {
            addCriterion("createuser not between", value1, value2, "createuser");
            return (Criteria) this;
        }

        public Criteria andCreatetimeIsNull() {
            addCriterion("createtime is null");
            return (Criteria) this;
        }

        public Criteria andCreatetimeIsNotNull() {
            addCriterion("createtime is not null");
            return (Criteria) this;
        }

        public Criteria andCreatetimeEqualTo(Date value) {
            addCriterion("createtime =", value, "createtime");
            return (Criteria) this;
        }

        public Criteria andCreatetimeNotEqualTo(Date value) {
            addCriterion("createtime <>", value, "createtime");
            return (Criteria) this;
        }

        public Criteria andCreatetimeGreaterThan(Date value) {
            addCriterion("createtime >", value, "createtime");
            return (Criteria) this;
        }

        public Criteria andCreatetimeGreaterThanOrEqualTo(Date value) {
            addCriterion("createtime >=", value, "createtime");
            return (Criteria) this;
        }

        public Criteria andCreatetimeLessThan(Date value) {
            addCriterion("createtime <", value, "createtime");
            return (Criteria) this;
        }

        public Criteria andCreatetimeLessThanOrEqualTo(Date value) {
            addCriterion("createtime <=", value, "createtime");
            return (Criteria) this;
        }

        public Criteria andCreatetimeIn(List<Date> values) {
            addCriterion("createtime in", values, "createtime");
            return (Criteria) this;
        }

        public Criteria andCreatetimeNotIn(List<Date> values) {
            addCriterion("createtime not in", values, "createtime");
            return (Criteria) this;
        }

        public Criteria andCreatetimeBetween(Date value1, Date value2) {
            addCriterion("createtime between", value1, value2, "createtime");
            return (Criteria) this;
        }

        public Criteria andCreatetimeNotBetween(Date value1, Date value2) {
            addCriterion("createtime not between", value1, value2, "createtime");
            return (Criteria) this;
        }

        public Criteria andUpdateuserIsNull() {
            addCriterion("updateuser is null");
            return (Criteria) this;
        }

        public Criteria andUpdateuserIsNotNull() {
            addCriterion("updateuser is not null");
            return (Criteria) this;
        }

        public Criteria andUpdateuserEqualTo(String value) {
            addCriterion("updateuser =", value, "updateuser");
            return (Criteria) this;
        }

        public Criteria andUpdateuserNotEqualTo(String value) {
            addCriterion("updateuser <>", value, "updateuser");
            return (Criteria) this;
        }

        public Criteria andUpdateuserGreaterThan(String value) {
            addCriterion("updateuser >", value, "updateuser");
            return (Criteria) this;
        }

        public Criteria andUpdateuserGreaterThanOrEqualTo(String value) {
            addCriterion("updateuser >=", value, "updateuser");
            return (Criteria) this;
        }

        public Criteria andUpdateuserLessThan(String value) {
            addCriterion("updateuser <", value, "updateuser");
            return (Criteria) this;
        }

        public Criteria andUpdateuserLessThanOrEqualTo(String value) {
            addCriterion("updateuser <=", value, "updateuser");
            return (Criteria) this;
        }

        public Criteria andUpdateuserLike(String value) {
            addCriterion("updateuser like", value, "updateuser");
            return (Criteria) this;
        }

        public Criteria andUpdateuserNotLike(String value) {
            addCriterion("updateuser not like", value, "updateuser");
            return (Criteria) this;
        }

        public Criteria andUpdateuserIn(List<String> values) {
            addCriterion("updateuser in", values, "updateuser");
            return (Criteria) this;
        }

        public Criteria andUpdateuserNotIn(List<String> values) {
            addCriterion("updateuser not in", values, "updateuser");
            return (Criteria) this;
        }

        public Criteria andUpdateuserBetween(String value1, String value2) {
            addCriterion("updateuser between", value1, value2, "updateuser");
            return (Criteria) this;
        }

        public Criteria andUpdateuserNotBetween(String value1, String value2) {
            addCriterion("updateuser not between", value1, value2, "updateuser");
            return (Criteria) this;
        }

        public Criteria andUpdatetimeIsNull() {
            addCriterion("updatetime is null");
            return (Criteria) this;
        }

        public Criteria andUpdatetimeIsNotNull() {
            addCriterion("updatetime is not null");
            return (Criteria) this;
        }

        public Criteria andUpdatetimeEqualTo(Date value) {
            addCriterion("updatetime =", value, "updatetime");
            return (Criteria) this;
        }

        public Criteria andUpdatetimeNotEqualTo(Date value) {
            addCriterion("updatetime <>", value, "updatetime");
            return (Criteria) this;
        }

        public Criteria andUpdatetimeGreaterThan(Date value) {
            addCriterion("updatetime >", value, "updatetime");
            return (Criteria) this;
        }

        public Criteria andUpdatetimeGreaterThanOrEqualTo(Date value) {
            addCriterion("updatetime >=", value, "updatetime");
            return (Criteria) this;
        }

        public Criteria andUpdatetimeLessThan(Date value) {
            addCriterion("updatetime <", value, "updatetime");
            return (Criteria) this;
        }

        public Criteria andUpdatetimeLessThanOrEqualTo(Date value) {
            addCriterion("updatetime <=", value, "updatetime");
            return (Criteria) this;
        }

        public Criteria andUpdatetimeIn(List<Date> values) {
            addCriterion("updatetime in", values, "updatetime");
            return (Criteria) this;
        }

        public Criteria andUpdatetimeNotIn(List<Date> values) {
            addCriterion("updatetime not in", values, "updatetime");
            return (Criteria) this;
        }

        public Criteria andUpdatetimeBetween(Date value1, Date value2) {
            addCriterion("updatetime between", value1, value2, "updatetime");
            return (Criteria) this;
        }

        public Criteria andUpdatetimeNotBetween(Date value1, Date value2) {
            addCriterion("updatetime not between", value1, value2, "updatetime");
            return (Criteria) this;
        }

        public Criteria andDrIsNull() {
            addCriterion("dr is null");
            return (Criteria) this;
        }

        public Criteria andDrIsNotNull() {
            addCriterion("dr is not null");
            return (Criteria) this;
        }

        public Criteria andDrEqualTo(Integer value) {
            addCriterion("dr =", value, "dr");
            return (Criteria) this;
        }

        public Criteria andDrNotEqualTo(Integer value) {
            addCriterion("dr <>", value, "dr");
            return (Criteria) this;
        }

        public Criteria andDrGreaterThan(Integer value) {
            addCriterion("dr >", value, "dr");
            return (Criteria) this;
        }

        public Criteria andDrGreaterThanOrEqualTo(Integer value) {
            addCriterion("dr >=", value, "dr");
            return (Criteria) this;
        }

        public Criteria andDrLessThan(Integer value) {
            addCriterion("dr <", value, "dr");
            return (Criteria) this;
        }

        public Criteria andDrLessThanOrEqualTo(Integer value) {
            addCriterion("dr <=", value, "dr");
            return (Criteria) this;
        }

        public Criteria andDrIn(List<Integer> values) {
            addCriterion("dr in", values, "dr");
            return (Criteria) this;
        }

        public Criteria andDrNotIn(List<Integer> values) {
            addCriterion("dr not in", values, "dr");
            return (Criteria) this;
        }

        public Criteria andDrBetween(Integer value1, Integer value2) {
            addCriterion("dr between", value1, value2, "dr");
            return (Criteria) this;
        }

        public Criteria andDrNotBetween(Integer value1, Integer value2) {
            addCriterion("dr not between", value1, value2, "dr");
            return (Criteria) this;
        }
    }

    public static class Criteria extends GeneratedCriteria {

        protected Criteria() {
            super();
        }
    }

    public static class Criterion {
        private String condition;

        private Object value;

        private Object secondValue;

        private boolean noValue;

        private boolean singleValue;

        private boolean betweenValue;

        private boolean listValue;

        private String typeHandler;

        public String getCondition() {
            return condition;
        }

        public Object getValue() {
            return value;
        }

        public Object getSecondValue() {
            return secondValue;
        }

        public boolean isNoValue() {
            return noValue;
        }

        public boolean isSingleValue() {
            return singleValue;
        }

        public boolean isBetweenValue() {
            return betweenValue;
        }

        public boolean isListValue() {
            return listValue;
        }

        public String getTypeHandler() {
            return typeHandler;
        }

        protected Criterion(String condition) {
            super();
            this.condition = condition;
            this.typeHandler = null;
            this.noValue = true;
        }

        protected Criterion(String condition, Object value, String typeHandler) {
            super();
            this.condition = condition;
            this.value = value;
            this.typeHandler = typeHandler;
            if (value instanceof List<?>) {
                this.listValue = true;
            } else {
                this.singleValue = true;
            }
        }

        protected Criterion(String condition, Object value) {
            this(condition, value, null);
        }

        protected Criterion(String condition, Object value, Object secondValue, String typeHandler) {
            super();
            this.condition = condition;
            this.value = value;
            this.secondValue = secondValue;
            this.typeHandler = typeHandler;
            this.betweenValue = true;
        }

        protected Criterion(String condition, Object value, Object secondValue) {
            this(condition, value, secondValue, null);
        }
    }
}
