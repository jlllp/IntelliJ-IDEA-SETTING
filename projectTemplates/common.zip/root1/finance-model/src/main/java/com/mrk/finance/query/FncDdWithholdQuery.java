package com.mrk.finance.query;
import com.mrk.common.utils.text.CheckUtil;

/**
 * @author 自动生成工具
 * @date   2021/11/12
 */
public class FncDdWithholdQuery {
	private String updateuserNotLike;
	private java.util.List updateuserNotIn;
	private String updateuserNotEqualTo;
	private String updateuserLike;
	private String updateuserLessThanOrEqualTo;
	private String updateuserLessThan;
	private Boolean updateuserIsNull;
	private Boolean updateuserIsNotNull;
	private java.util.List updateuserIn;
	private String updateuserGreaterThanOrEqualTo;
	private String updateuserGreaterThan;
	private String updateuserEqualTo;
	private java.util.List updatetimeNotIn;
	private java.util.Date updatetimeNotEqualTo;
	private java.util.Date updatetimeLessThanOrEqualTo;
	private java.util.Date updatetimeLessThan;
	private Boolean updatetimeIsNull;
	private Boolean updatetimeIsNotNull;
	private java.util.List updatetimeIn;
	private java.util.Date updatetimeGreaterThanOrEqualTo;
	private java.util.Date updatetimeGreaterThan;
	private java.util.Date updatetimeEqualTo;
	private String remarkNotLike;
	private java.util.List remarkNotIn;
	private String remarkNotEqualTo;
	private String remarkLike;
	private String remarkLessThanOrEqualTo;
	private String remarkLessThan;
	private Boolean remarkIsNull;
	private Boolean remarkIsNotNull;
	private java.util.List remarkIn;
	private String remarkGreaterThanOrEqualTo;
	private String remarkGreaterThan;
	private String remarkEqualTo;
	private java.util.List fdwTradeTimeNotIn;
	private java.util.Date fdwTradeTimeNotEqualTo;
	private java.util.Date fdwTradeTimeLessThanOrEqualTo;
	private java.util.Date fdwTradeTimeLessThan;
	private Boolean fdwTradeTimeIsNull;
	private Boolean fdwTradeTimeIsNotNull;
	private java.util.List fdwTradeTimeIn;
	private java.util.Date fdwTradeTimeGreaterThanOrEqualTo;
	private java.util.Date fdwTradeTimeGreaterThan;
	private java.util.Date fdwTradeTimeEqualTo;
	private String fdwTradePartyNotLike;
	private java.util.List fdwTradePartyNotIn;
	private String fdwTradePartyNotEqualTo;
	private String fdwTradePartyLike;
	private String fdwTradePartyLessThanOrEqualTo;
	private String fdwTradePartyLessThan;
	private Boolean fdwTradePartyIsNull;
	private Boolean fdwTradePartyIsNotNull;
	private java.util.List fdwTradePartyIn;
	private String fdwTradePartyGreaterThanOrEqualTo;
	private String fdwTradePartyGreaterThan;
	private String fdwTradePartyEqualTo;
	private String fdwTradeNamesNotLike;
	private java.util.List fdwTradeNamesNotIn;
	private String fdwTradeNamesNotEqualTo;
	private String fdwTradeNamesLike;
	private String fdwTradeNamesLessThanOrEqualTo;
	private String fdwTradeNamesLessThan;
	private Boolean fdwTradeNamesIsNull;
	private Boolean fdwTradeNamesIsNotNull;
	private java.util.List fdwTradeNamesIn;
	private String fdwTradeNamesGreaterThanOrEqualTo;
	private String fdwTradeNamesGreaterThan;
	private String fdwTradeNamesEqualTo;
	private java.util.List fdwTradeAmountNotIn;
	private Double fdwTradeAmountNotEqualTo;
	private Double fdwTradeAmountLessThanOrEqualTo;
	private Double fdwTradeAmountLessThan;
	private Boolean fdwTradeAmountIsNull;
	private Boolean fdwTradeAmountIsNotNull;
	private java.util.List fdwTradeAmountIn;
	private Double fdwTradeAmountGreaterThanOrEqualTo;
	private Double fdwTradeAmountGreaterThan;
	private Double fdwTradeAmountEqualTo;
	private String fdwOrderNoNotLike;
	private java.util.List fdwOrderNoNotIn;
	private String fdwOrderNoNotEqualTo;
	private String fdwOrderNoLike;
	private String fdwOrderNoLessThanOrEqualTo;
	private String fdwOrderNoLessThan;
	private Boolean fdwOrderNoIsNull;
	private Boolean fdwOrderNoIsNotNull;
	private java.util.List fdwOrderNoIn;
	private String fdwOrderNoGreaterThanOrEqualTo;
	private String fdwOrderNoGreaterThan;
	private String fdwOrderNoEqualTo;
	private java.util.List fdwNotMatchAmountNotIn;
	private Double fdwNotMatchAmountNotEqualTo;
	private Double fdwNotMatchAmountLessThanOrEqualTo;
	private Double fdwNotMatchAmountLessThan;
	private Boolean fdwNotMatchAmountIsNull;
	private Boolean fdwNotMatchAmountIsNotNull;
	private java.util.List fdwNotMatchAmountIn;
	private Double fdwNotMatchAmountGreaterThanOrEqualTo;
	private Double fdwNotMatchAmountGreaterThan;
	private Double fdwNotMatchAmountEqualTo;
	private java.util.List fdwMatchedAmountNotIn;
	private Double fdwMatchedAmountNotEqualTo;
	private Double fdwMatchedAmountLessThanOrEqualTo;
	private Double fdwMatchedAmountLessThan;
	private Boolean fdwMatchedAmountIsNull;
	private Boolean fdwMatchedAmountIsNotNull;
	private java.util.List fdwMatchedAmountIn;
	private Double fdwMatchedAmountGreaterThanOrEqualTo;
	private Double fdwMatchedAmountGreaterThan;
	private Double fdwMatchedAmountEqualTo;
	private java.util.List fdwMatchWayNotIn;
	private Integer fdwMatchWayNotEqualTo;
	private Integer fdwMatchWayLessThanOrEqualTo;
	private Integer fdwMatchWayLessThan;
	private Boolean fdwMatchWayIsNull;
	private Boolean fdwMatchWayIsNotNull;
	private java.util.List fdwMatchWayIn;
	private Integer fdwMatchWayGreaterThanOrEqualTo;
	private Integer fdwMatchWayGreaterThan;
	private Integer fdwMatchWayEqualTo;
	private java.util.List fdwMatchStateNotIn;
	private Integer fdwMatchStateNotEqualTo;
	private Integer fdwMatchStateLessThanOrEqualTo;
	private Integer fdwMatchStateLessThan;
	private Boolean fdwMatchStateIsNull;
	private Boolean fdwMatchStateIsNotNull;
	private java.util.List fdwMatchStateIn;
	private Integer fdwMatchStateGreaterThanOrEqualTo;
	private Integer fdwMatchStateGreaterThan;
	private Integer fdwMatchStateEqualTo;
	private String fdwMatchBillNotLike;
	private java.util.List fdwMatchBillNotIn;
	private String fdwMatchBillNotEqualTo;
	private String fdwMatchBillLike;
	private String fdwMatchBillLessThanOrEqualTo;
	private String fdwMatchBillLessThan;
	private Boolean fdwMatchBillIsNull;
	private Boolean fdwMatchBillIsNotNull;
	private java.util.List fdwMatchBillIn;
	private String fdwMatchBillGreaterThanOrEqualTo;
	private String fdwMatchBillGreaterThan;
	private String fdwMatchBillEqualTo;
	private java.util.List fdwIdNotIn;
	private Long fdwIdNotEqualTo;
	private Long fdwIdLessThanOrEqualTo;
	private Long fdwIdLessThan;
	private Boolean fdwIdIsNull;
	private Boolean fdwIdIsNotNull;
	private java.util.List fdwIdIn;
	private Long fdwIdGreaterThanOrEqualTo;
	private Long fdwIdGreaterThan;
	private Long fdwIdEqualTo;
	private String fdwCarVinNotLike;
	private java.util.List fdwCarVinNotIn;
	private String fdwCarVinNotEqualTo;
	private String fdwCarVinLike;
	private String fdwCarVinLessThanOrEqualTo;
	private String fdwCarVinLessThan;
	private Boolean fdwCarVinIsNull;
	private Boolean fdwCarVinIsNotNull;
	private java.util.List fdwCarVinIn;
	private String fdwCarVinGreaterThanOrEqualTo;
	private String fdwCarVinGreaterThan;
	private String fdwCarVinEqualTo;
	private String fdwAccountNoNotLike;
	private java.util.List fdwAccountNoNotIn;
	private String fdwAccountNoNotEqualTo;
	private String fdwAccountNoLike;
	private String fdwAccountNoLessThanOrEqualTo;
	private String fdwAccountNoLessThan;
	private Boolean fdwAccountNoIsNull;
	private Boolean fdwAccountNoIsNotNull;
	private java.util.List fdwAccountNoIn;
	private String fdwAccountNoGreaterThanOrEqualTo;
	private String fdwAccountNoGreaterThan;
	private String fdwAccountNoEqualTo;
	private String fdwAccountDealFlowNotLike;
	private java.util.List fdwAccountDealFlowNotIn;
	private String fdwAccountDealFlowNotEqualTo;
	private String fdwAccountDealFlowLike;
	private String fdwAccountDealFlowLessThanOrEqualTo;
	private String fdwAccountDealFlowLessThan;
	private Boolean fdwAccountDealFlowIsNull;
	private Boolean fdwAccountDealFlowIsNotNull;
	private java.util.List fdwAccountDealFlowIn;
	private String fdwAccountDealFlowGreaterThanOrEqualTo;
	private String fdwAccountDealFlowGreaterThan;
	private String fdwAccountDealFlowEqualTo;
	private java.util.List drNotIn;
	private Integer drNotEqualTo;
	private Integer drLessThanOrEqualTo;
	private Integer drLessThan;
	private Boolean drIsNull;
	private Boolean drIsNotNull;
	private java.util.List drIn;
	private Integer drGreaterThanOrEqualTo;
	private Integer drGreaterThan;
	private Integer drEqualTo;
	private String createuserNotLike;
	private java.util.List createuserNotIn;
	private String createuserNotEqualTo;
	private String createuserLike;
	private String createuserLessThanOrEqualTo;
	private String createuserLessThan;
	private Boolean createuserIsNull;
	private Boolean createuserIsNotNull;
	private java.util.List createuserIn;
	private String createuserGreaterThanOrEqualTo;
	private String createuserGreaterThan;
	private String createuserEqualTo;
	private java.util.List createtimeNotIn;
	private java.util.Date createtimeNotEqualTo;
	private java.util.Date createtimeLessThanOrEqualTo;
	private java.util.Date createtimeLessThan;
	private Boolean createtimeIsNull;
	private Boolean createtimeIsNotNull;
	private java.util.List createtimeIn;
	private java.util.Date createtimeGreaterThanOrEqualTo;
	private java.util.Date createtimeGreaterThan;
	private java.util.Date createtimeEqualTo;
	private String sidx;
	private String sord;
	public String getSidx(){
		if(this.sidx == null){
			return "";
		}
		else if("updateuser".equals(this.sidx)){
			return "updateuser";
		}
		else if("updatetime".equals(this.sidx)){
			return "updatetime";
		}
		else if("remark".equals(this.sidx)){
			return "remark";
		}
		else if("fdwTradeTime".equals(this.sidx)){
			return "fdw_trade_time";
		}
		else if("fdwTradeParty".equals(this.sidx)){
			return "fdw_trade_party";
		}
		else if("fdwTradeNames".equals(this.sidx)){
			return "fdw_trade_names";
		}
		else if("fdwTradeAmount".equals(this.sidx)){
			return "fdw_trade_amount";
		}
		else if("fdwderNo".equals(this.sidx)){
			return "fdwder_no";
		}
		else if("fdwderNoOr".equals(this.sidx)){
			return "fdwder_no_or";
		}
		else if("fdwMatchAmountNot".equals(this.sidx)){
			return "fdw_match_amount_not";
		}
		else if("fdwMatchAmount".equals(this.sidx)){
			return "fdw_match_amount";
		}
		else if("fdwMatchedAmount".equals(this.sidx)){
			return "fdw_matched_amount";
		}
		else if("fdwMatchWay".equals(this.sidx)){
			return "fdw_match_way";
		}
		else if("fdwMatchState".equals(this.sidx)){
			return "fdw_match_state";
		}
		else if("fdwMatchBill".equals(this.sidx)){
			return "fdw_match_bill";
		}
		else if("fdwId".equals(this.sidx)){
			return "fdw_id";
		}
		else if("fdwCarVin".equals(this.sidx)){
			return "fdw_car_vin";
		}
		else if("fdwAccountNo".equals(this.sidx)){
			return "fdw_account_no";
		}
		else if("fdwAccountDealFlow".equals(this.sidx)){
			return "fdw_account_deal_flow";
		}
		else if("dr".equals(this.sidx)){
			return "dr";
		}
		else if("createuser".equals(this.sidx)){
			return "createuser";
		}
		else if("createtime".equals(this.sidx)){
			return "createtime";
		}
		return this.sidx;
	}

	@com.fasterxml.jackson.annotation.JsonIgnore
	public com.mrk.finance.example.FncDdWithholdExample getCrieria(){
		com.mrk.finance.example.FncDdWithholdExample q = new com.mrk.finance.example.FncDdWithholdExample();
		com.mrk.finance.example.FncDdWithholdExample.Criteria c = q.createCriteria();
		c.andDrEqualTo(0);
		if(CheckUtil.isNotEmpty(getUpdateuserNotLike())){
			c.andUpdateuserNotLike("%"+this.getUpdateuserNotLike()+"%");
		}
		if(CheckUtil.isNotEmpty(getUpdateuserNotIn())){
			c.andUpdateuserNotIn(this.getUpdateuserNotIn());
		}
		if(CheckUtil.isNotEmpty(getUpdateuserNotEqualTo())){
			c.andUpdateuserNotEqualTo(this.getUpdateuserNotEqualTo());
		}
		if(CheckUtil.isNotEmpty(getUpdateuserLike())){
			c.andUpdateuserLike("%"+this.getUpdateuserLike()+"%");
		}
		if(CheckUtil.isNotEmpty(getUpdateuserLessThanOrEqualTo())){
			c.andUpdateuserLessThanOrEqualTo(this.getUpdateuserLessThanOrEqualTo());
		}
		if(CheckUtil.isNotEmpty(getUpdateuserLessThan())){
			c.andUpdateuserLessThan(this.getUpdateuserLessThan());
		}
		if(CheckUtil.isNotEmpty(getUpdateuserIsNull()) && this.getUpdateuserIsNull()){
			c.andUpdateuserIsNull();
		}
		if(CheckUtil.isNotEmpty(getUpdateuserIsNotNull()) && this.getUpdateuserIsNotNull()){
			c.andUpdateuserIsNotNull();
		}
		if(CheckUtil.isNotEmpty(getUpdateuserIn())){
			c.andUpdateuserIn(this.getUpdateuserIn());
		}
		if(CheckUtil.isNotEmpty(getUpdateuserGreaterThanOrEqualTo())){
			c.andUpdateuserGreaterThanOrEqualTo(this.getUpdateuserGreaterThanOrEqualTo());
		}
		if(CheckUtil.isNotEmpty(getUpdateuserGreaterThan())){
			c.andUpdateuserGreaterThan(this.getUpdateuserGreaterThan());
		}
		if(CheckUtil.isNotEmpty(getUpdateuserEqualTo())){
			c.andUpdateuserEqualTo(this.getUpdateuserEqualTo());
		}
		if(CheckUtil.isNotEmpty(getUpdatetimeNotIn())){
			c.andUpdatetimeNotIn(this.getUpdatetimeNotIn());
		}
		if(CheckUtil.isNotEmpty(getUpdatetimeNotEqualTo())){
			c.andUpdatetimeNotEqualTo(this.getUpdatetimeNotEqualTo());
		}
		if(CheckUtil.isNotEmpty(getUpdatetimeLessThanOrEqualTo())){
			c.andUpdatetimeLessThanOrEqualTo(this.getUpdatetimeLessThanOrEqualTo());
		}
		if(CheckUtil.isNotEmpty(getUpdatetimeLessThan())){
			c.andUpdatetimeLessThan(this.getUpdatetimeLessThan());
		}
		if(CheckUtil.isNotEmpty(getUpdatetimeIsNull()) && this.getUpdatetimeIsNull()){
			c.andUpdatetimeIsNull();
		}
		if(CheckUtil.isNotEmpty(getUpdatetimeIsNotNull()) && this.getUpdatetimeIsNotNull()){
			c.andUpdatetimeIsNotNull();
		}
		if(CheckUtil.isNotEmpty(getUpdatetimeIn())){
			c.andUpdatetimeIn(this.getUpdatetimeIn());
		}
		if(CheckUtil.isNotEmpty(getUpdatetimeGreaterThanOrEqualTo())){
			c.andUpdatetimeGreaterThanOrEqualTo(this.getUpdatetimeGreaterThanOrEqualTo());
		}
		if(CheckUtil.isNotEmpty(getUpdatetimeGreaterThan())){
			c.andUpdatetimeGreaterThan(this.getUpdatetimeGreaterThan());
		}
		if(CheckUtil.isNotEmpty(getUpdatetimeEqualTo())){
			c.andUpdatetimeEqualTo(this.getUpdatetimeEqualTo());
		}
		if(CheckUtil.isNotEmpty(getRemarkNotLike())){
			c.andRemarkNotLike("%"+this.getRemarkNotLike()+"%");
		}
		if(CheckUtil.isNotEmpty(getRemarkNotIn())){
			c.andRemarkNotIn(this.getRemarkNotIn());
		}
		if(CheckUtil.isNotEmpty(getRemarkNotEqualTo())){
			c.andRemarkNotEqualTo(this.getRemarkNotEqualTo());
		}
		if(CheckUtil.isNotEmpty(getRemarkLike())){
			c.andRemarkLike("%"+this.getRemarkLike()+"%");
		}
		if(CheckUtil.isNotEmpty(getRemarkLessThanOrEqualTo())){
			c.andRemarkLessThanOrEqualTo(this.getRemarkLessThanOrEqualTo());
		}
		if(CheckUtil.isNotEmpty(getRemarkLessThan())){
			c.andRemarkLessThan(this.getRemarkLessThan());
		}
		if(CheckUtil.isNotEmpty(getRemarkIsNull()) && this.getRemarkIsNull()){
			c.andRemarkIsNull();
		}
		if(CheckUtil.isNotEmpty(getRemarkIsNotNull()) && this.getRemarkIsNotNull()){
			c.andRemarkIsNotNull();
		}
		if(CheckUtil.isNotEmpty(getRemarkIn())){
			c.andRemarkIn(this.getRemarkIn());
		}
		if(CheckUtil.isNotEmpty(getRemarkGreaterThanOrEqualTo())){
			c.andRemarkGreaterThanOrEqualTo(this.getRemarkGreaterThanOrEqualTo());
		}
		if(CheckUtil.isNotEmpty(getRemarkGreaterThan())){
			c.andRemarkGreaterThan(this.getRemarkGreaterThan());
		}
		if(CheckUtil.isNotEmpty(getRemarkEqualTo())){
			c.andRemarkEqualTo(this.getRemarkEqualTo());
		}
		if(CheckUtil.isNotEmpty(getFdwTradeTimeNotIn())){
			c.andFdwTradeTimeNotIn(this.getFdwTradeTimeNotIn());
		}
		if(CheckUtil.isNotEmpty(getFdwTradeTimeNotEqualTo())){
			c.andFdwTradeTimeNotEqualTo(this.getFdwTradeTimeNotEqualTo());
		}
		if(CheckUtil.isNotEmpty(getFdwTradeTimeLessThanOrEqualTo())){
			c.andFdwTradeTimeLessThanOrEqualTo(this.getFdwTradeTimeLessThanOrEqualTo());
		}
		if(CheckUtil.isNotEmpty(getFdwTradeTimeLessThan())){
			c.andFdwTradeTimeLessThan(this.getFdwTradeTimeLessThan());
		}
		if(CheckUtil.isNotEmpty(getFdwTradeTimeIsNull()) && this.getFdwTradeTimeIsNull()){
			c.andFdwTradeTimeIsNull();
		}
		if(CheckUtil.isNotEmpty(getFdwTradeTimeIsNotNull()) && this.getFdwTradeTimeIsNotNull()){
			c.andFdwTradeTimeIsNotNull();
		}
		if(CheckUtil.isNotEmpty(getFdwTradeTimeIn())){
			c.andFdwTradeTimeIn(this.getFdwTradeTimeIn());
		}
		if(CheckUtil.isNotEmpty(getFdwTradeTimeGreaterThanOrEqualTo())){
			c.andFdwTradeTimeGreaterThanOrEqualTo(this.getFdwTradeTimeGreaterThanOrEqualTo());
		}
		if(CheckUtil.isNotEmpty(getFdwTradeTimeGreaterThan())){
			c.andFdwTradeTimeGreaterThan(this.getFdwTradeTimeGreaterThan());
		}
		if(CheckUtil.isNotEmpty(getFdwTradeTimeEqualTo())){
			c.andFdwTradeTimeEqualTo(this.getFdwTradeTimeEqualTo());
		}
		if(CheckUtil.isNotEmpty(getFdwTradePartyNotLike())){
			c.andFdwTradePartyNotLike("%"+this.getFdwTradePartyNotLike()+"%");
		}
		if(CheckUtil.isNotEmpty(getFdwTradePartyNotIn())){
			c.andFdwTradePartyNotIn(this.getFdwTradePartyNotIn());
		}
		if(CheckUtil.isNotEmpty(getFdwTradePartyNotEqualTo())){
			c.andFdwTradePartyNotEqualTo(this.getFdwTradePartyNotEqualTo());
		}
		if(CheckUtil.isNotEmpty(getFdwTradePartyLike())){
			c.andFdwTradePartyLike("%"+this.getFdwTradePartyLike()+"%");
		}
		if(CheckUtil.isNotEmpty(getFdwTradePartyLessThanOrEqualTo())){
			c.andFdwTradePartyLessThanOrEqualTo(this.getFdwTradePartyLessThanOrEqualTo());
		}
		if(CheckUtil.isNotEmpty(getFdwTradePartyLessThan())){
			c.andFdwTradePartyLessThan(this.getFdwTradePartyLessThan());
		}
		if(CheckUtil.isNotEmpty(getFdwTradePartyIsNull()) && this.getFdwTradePartyIsNull()){
			c.andFdwTradePartyIsNull();
		}
		if(CheckUtil.isNotEmpty(getFdwTradePartyIsNotNull()) && this.getFdwTradePartyIsNotNull()){
			c.andFdwTradePartyIsNotNull();
		}
		if(CheckUtil.isNotEmpty(getFdwTradePartyIn())){
			c.andFdwTradePartyIn(this.getFdwTradePartyIn());
		}
		if(CheckUtil.isNotEmpty(getFdwTradePartyGreaterThanOrEqualTo())){
			c.andFdwTradePartyGreaterThanOrEqualTo(this.getFdwTradePartyGreaterThanOrEqualTo());
		}
		if(CheckUtil.isNotEmpty(getFdwTradePartyGreaterThan())){
			c.andFdwTradePartyGreaterThan(this.getFdwTradePartyGreaterThan());
		}
		if(CheckUtil.isNotEmpty(getFdwTradePartyEqualTo())){
			c.andFdwTradePartyEqualTo(this.getFdwTradePartyEqualTo());
		}
		if(CheckUtil.isNotEmpty(getFdwTradeNamesNotLike())){
			c.andFdwTradeNamesNotLike("%"+this.getFdwTradeNamesNotLike()+"%");
		}
		if(CheckUtil.isNotEmpty(getFdwTradeNamesNotIn())){
			c.andFdwTradeNamesNotIn(this.getFdwTradeNamesNotIn());
		}
		if(CheckUtil.isNotEmpty(getFdwTradeNamesNotEqualTo())){
			c.andFdwTradeNamesNotEqualTo(this.getFdwTradeNamesNotEqualTo());
		}
		if(CheckUtil.isNotEmpty(getFdwTradeNamesLike())){
			c.andFdwTradeNamesLike("%"+this.getFdwTradeNamesLike()+"%");
		}
		if(CheckUtil.isNotEmpty(getFdwTradeNamesLessThanOrEqualTo())){
			c.andFdwTradeNamesLessThanOrEqualTo(this.getFdwTradeNamesLessThanOrEqualTo());
		}
		if(CheckUtil.isNotEmpty(getFdwTradeNamesLessThan())){
			c.andFdwTradeNamesLessThan(this.getFdwTradeNamesLessThan());
		}
		if(CheckUtil.isNotEmpty(getFdwTradeNamesIsNull()) && this.getFdwTradeNamesIsNull()){
			c.andFdwTradeNamesIsNull();
		}
		if(CheckUtil.isNotEmpty(getFdwTradeNamesIsNotNull()) && this.getFdwTradeNamesIsNotNull()){
			c.andFdwTradeNamesIsNotNull();
		}
		if(CheckUtil.isNotEmpty(getFdwTradeNamesIn())){
			c.andFdwTradeNamesIn(this.getFdwTradeNamesIn());
		}
		if(CheckUtil.isNotEmpty(getFdwTradeNamesGreaterThanOrEqualTo())){
			c.andFdwTradeNamesGreaterThanOrEqualTo(this.getFdwTradeNamesGreaterThanOrEqualTo());
		}
		if(CheckUtil.isNotEmpty(getFdwTradeNamesGreaterThan())){
			c.andFdwTradeNamesGreaterThan(this.getFdwTradeNamesGreaterThan());
		}
		if(CheckUtil.isNotEmpty(getFdwTradeNamesEqualTo())){
			c.andFdwTradeNamesEqualTo(this.getFdwTradeNamesEqualTo());
		}
		if(CheckUtil.isNotEmpty(getFdwTradeAmountNotIn())){
			c.andFdwTradeAmountNotIn(this.getFdwTradeAmountNotIn());
		}
		if(CheckUtil.isNotEmpty(getFdwTradeAmountNotEqualTo())){
			c.andFdwTradeAmountNotEqualTo(this.getFdwTradeAmountNotEqualTo());
		}
		if(CheckUtil.isNotEmpty(getFdwTradeAmountLessThanOrEqualTo())){
			c.andFdwTradeAmountLessThanOrEqualTo(this.getFdwTradeAmountLessThanOrEqualTo());
		}
		if(CheckUtil.isNotEmpty(getFdwTradeAmountLessThan())){
			c.andFdwTradeAmountLessThan(this.getFdwTradeAmountLessThan());
		}
		if(CheckUtil.isNotEmpty(getFdwTradeAmountIsNull()) && this.getFdwTradeAmountIsNull()){
			c.andFdwTradeAmountIsNull();
		}
		if(CheckUtil.isNotEmpty(getFdwTradeAmountIsNotNull()) && this.getFdwTradeAmountIsNotNull()){
			c.andFdwTradeAmountIsNotNull();
		}
		if(CheckUtil.isNotEmpty(getFdwTradeAmountIn())){
			c.andFdwTradeAmountIn(this.getFdwTradeAmountIn());
		}
		if(CheckUtil.isNotEmpty(getFdwTradeAmountGreaterThanOrEqualTo())){
			c.andFdwTradeAmountGreaterThanOrEqualTo(this.getFdwTradeAmountGreaterThanOrEqualTo());
		}
		if(CheckUtil.isNotEmpty(getFdwTradeAmountGreaterThan())){
			c.andFdwTradeAmountGreaterThan(this.getFdwTradeAmountGreaterThan());
		}
		if(CheckUtil.isNotEmpty(getFdwTradeAmountEqualTo())){
			c.andFdwTradeAmountEqualTo(this.getFdwTradeAmountEqualTo());
		}
		if(CheckUtil.isNotEmpty(getFdwOrderNoNotLike())){
			c.andFdwOrderNoNotLike("%"+this.getFdwOrderNoNotLike()+"%");
		}
		if(CheckUtil.isNotEmpty(getFdwOrderNoNotIn())){
			c.andFdwOrderNoNotIn(this.getFdwOrderNoNotIn());
		}
		if(CheckUtil.isNotEmpty(getFdwOrderNoNotEqualTo())){
			c.andFdwOrderNoNotEqualTo(this.getFdwOrderNoNotEqualTo());
		}
		if(CheckUtil.isNotEmpty(getFdwOrderNoLike())){
			c.andFdwOrderNoLike("%"+this.getFdwOrderNoLike()+"%");
		}
		if(CheckUtil.isNotEmpty(getFdwOrderNoLessThanOrEqualTo())){
			c.andFdwOrderNoLessThanOrEqualTo(this.getFdwOrderNoLessThanOrEqualTo());
		}
		if(CheckUtil.isNotEmpty(getFdwOrderNoLessThan())){
			c.andFdwOrderNoLessThan(this.getFdwOrderNoLessThan());
		}
		if(CheckUtil.isNotEmpty(getFdwOrderNoIsNull()) && this.getFdwOrderNoIsNull()){
			c.andFdwOrderNoIsNull();
		}
		if(CheckUtil.isNotEmpty(getFdwOrderNoIsNotNull()) && this.getFdwOrderNoIsNotNull()){
			c.andFdwOrderNoIsNotNull();
		}
		if(CheckUtil.isNotEmpty(getFdwOrderNoIn())){
			c.andFdwOrderNoIn(this.getFdwOrderNoIn());
		}
		if(CheckUtil.isNotEmpty(getFdwOrderNoGreaterThanOrEqualTo())){
			c.andFdwOrderNoGreaterThanOrEqualTo(this.getFdwOrderNoGreaterThanOrEqualTo());
		}
		if(CheckUtil.isNotEmpty(getFdwOrderNoGreaterThan())){
			c.andFdwOrderNoGreaterThan(this.getFdwOrderNoGreaterThan());
		}
		if(CheckUtil.isNotEmpty(getFdwOrderNoEqualTo())){
			c.andFdwOrderNoEqualTo(this.getFdwOrderNoEqualTo());
		}
		if(CheckUtil.isNotEmpty(getFdwNotMatchAmountNotIn())){
			c.andFdwNotMatchAmountNotIn(this.getFdwNotMatchAmountNotIn());
		}
		if(CheckUtil.isNotEmpty(getFdwNotMatchAmountNotEqualTo())){
			c.andFdwNotMatchAmountNotEqualTo(this.getFdwNotMatchAmountNotEqualTo());
		}
		if(CheckUtil.isNotEmpty(getFdwNotMatchAmountLessThanOrEqualTo())){
			c.andFdwNotMatchAmountLessThanOrEqualTo(this.getFdwNotMatchAmountLessThanOrEqualTo());
		}
		if(CheckUtil.isNotEmpty(getFdwNotMatchAmountLessThan())){
			c.andFdwNotMatchAmountLessThan(this.getFdwNotMatchAmountLessThan());
		}
		if(CheckUtil.isNotEmpty(getFdwNotMatchAmountIsNull()) && this.getFdwNotMatchAmountIsNull()){
			c.andFdwNotMatchAmountIsNull();
		}
		if(CheckUtil.isNotEmpty(getFdwNotMatchAmountIsNotNull()) && this.getFdwNotMatchAmountIsNotNull()){
			c.andFdwNotMatchAmountIsNotNull();
		}
		if(CheckUtil.isNotEmpty(getFdwNotMatchAmountIn())){
			c.andFdwNotMatchAmountIn(this.getFdwNotMatchAmountIn());
		}
		if(CheckUtil.isNotEmpty(getFdwNotMatchAmountGreaterThanOrEqualTo())){
			c.andFdwNotMatchAmountGreaterThanOrEqualTo(this.getFdwNotMatchAmountGreaterThanOrEqualTo());
		}
		if(CheckUtil.isNotEmpty(getFdwNotMatchAmountGreaterThan())){
			c.andFdwNotMatchAmountGreaterThan(this.getFdwNotMatchAmountGreaterThan());
		}
		if(CheckUtil.isNotEmpty(getFdwNotMatchAmountEqualTo())){
			c.andFdwNotMatchAmountEqualTo(this.getFdwNotMatchAmountEqualTo());
		}
		if(CheckUtil.isNotEmpty(getFdwMatchedAmountNotIn())){
			c.andFdwMatchedAmountNotIn(this.getFdwMatchedAmountNotIn());
		}
		if(CheckUtil.isNotEmpty(getFdwMatchedAmountNotEqualTo())){
			c.andFdwMatchedAmountNotEqualTo(this.getFdwMatchedAmountNotEqualTo());
		}
		if(CheckUtil.isNotEmpty(getFdwMatchedAmountLessThanOrEqualTo())){
			c.andFdwMatchedAmountLessThanOrEqualTo(this.getFdwMatchedAmountLessThanOrEqualTo());
		}
		if(CheckUtil.isNotEmpty(getFdwMatchedAmountLessThan())){
			c.andFdwMatchedAmountLessThan(this.getFdwMatchedAmountLessThan());
		}
		if(CheckUtil.isNotEmpty(getFdwMatchedAmountIsNull()) && this.getFdwMatchedAmountIsNull()){
			c.andFdwMatchedAmountIsNull();
		}
		if(CheckUtil.isNotEmpty(getFdwMatchedAmountIsNotNull()) && this.getFdwMatchedAmountIsNotNull()){
			c.andFdwMatchedAmountIsNotNull();
		}
		if(CheckUtil.isNotEmpty(getFdwMatchedAmountIn())){
			c.andFdwMatchedAmountIn(this.getFdwMatchedAmountIn());
		}
		if(CheckUtil.isNotEmpty(getFdwMatchedAmountGreaterThanOrEqualTo())){
			c.andFdwMatchedAmountGreaterThanOrEqualTo(this.getFdwMatchedAmountGreaterThanOrEqualTo());
		}
		if(CheckUtil.isNotEmpty(getFdwMatchedAmountGreaterThan())){
			c.andFdwMatchedAmountGreaterThan(this.getFdwMatchedAmountGreaterThan());
		}
		if(CheckUtil.isNotEmpty(getFdwMatchedAmountEqualTo())){
			c.andFdwMatchedAmountEqualTo(this.getFdwMatchedAmountEqualTo());
		}
		if(CheckUtil.isNotEmpty(getFdwMatchWayNotIn())){
			c.andFdwMatchWayNotIn(this.getFdwMatchWayNotIn());
		}
		if(CheckUtil.isNotEmpty(getFdwMatchWayNotEqualTo())){
			c.andFdwMatchWayNotEqualTo(this.getFdwMatchWayNotEqualTo());
		}
		if(CheckUtil.isNotEmpty(getFdwMatchWayLessThanOrEqualTo())){
			c.andFdwMatchWayLessThanOrEqualTo(this.getFdwMatchWayLessThanOrEqualTo());
		}
		if(CheckUtil.isNotEmpty(getFdwMatchWayLessThan())){
			c.andFdwMatchWayLessThan(this.getFdwMatchWayLessThan());
		}
		if(CheckUtil.isNotEmpty(getFdwMatchWayIsNull()) && this.getFdwMatchWayIsNull()){
			c.andFdwMatchWayIsNull();
		}
		if(CheckUtil.isNotEmpty(getFdwMatchWayIsNotNull()) && this.getFdwMatchWayIsNotNull()){
			c.andFdwMatchWayIsNotNull();
		}
		if(CheckUtil.isNotEmpty(getFdwMatchWayIn())){
			c.andFdwMatchWayIn(this.getFdwMatchWayIn());
		}
		if(CheckUtil.isNotEmpty(getFdwMatchWayGreaterThanOrEqualTo())){
			c.andFdwMatchWayGreaterThanOrEqualTo(this.getFdwMatchWayGreaterThanOrEqualTo());
		}
		if(CheckUtil.isNotEmpty(getFdwMatchWayGreaterThan())){
			c.andFdwMatchWayGreaterThan(this.getFdwMatchWayGreaterThan());
		}
		if(CheckUtil.isNotEmpty(getFdwMatchWayEqualTo())){
			c.andFdwMatchWayEqualTo(this.getFdwMatchWayEqualTo());
		}
		if(CheckUtil.isNotEmpty(getFdwMatchStateNotIn())){
			c.andFdwMatchStateNotIn(this.getFdwMatchStateNotIn());
		}
		if(CheckUtil.isNotEmpty(getFdwMatchStateNotEqualTo())){
			c.andFdwMatchStateNotEqualTo(this.getFdwMatchStateNotEqualTo());
		}
		if(CheckUtil.isNotEmpty(getFdwMatchStateLessThanOrEqualTo())){
			c.andFdwMatchStateLessThanOrEqualTo(this.getFdwMatchStateLessThanOrEqualTo());
		}
		if(CheckUtil.isNotEmpty(getFdwMatchStateLessThan())){
			c.andFdwMatchStateLessThan(this.getFdwMatchStateLessThan());
		}
		if(CheckUtil.isNotEmpty(getFdwMatchStateIsNull()) && this.getFdwMatchStateIsNull()){
			c.andFdwMatchStateIsNull();
		}
		if(CheckUtil.isNotEmpty(getFdwMatchStateIsNotNull()) && this.getFdwMatchStateIsNotNull()){
			c.andFdwMatchStateIsNotNull();
		}
		if(CheckUtil.isNotEmpty(getFdwMatchStateIn())){
			c.andFdwMatchStateIn(this.getFdwMatchStateIn());
		}
		if(CheckUtil.isNotEmpty(getFdwMatchStateGreaterThanOrEqualTo())){
			c.andFdwMatchStateGreaterThanOrEqualTo(this.getFdwMatchStateGreaterThanOrEqualTo());
		}
		if(CheckUtil.isNotEmpty(getFdwMatchStateGreaterThan())){
			c.andFdwMatchStateGreaterThan(this.getFdwMatchStateGreaterThan());
		}
		if(CheckUtil.isNotEmpty(getFdwMatchStateEqualTo())){
			c.andFdwMatchStateEqualTo(this.getFdwMatchStateEqualTo());
		}
		if(CheckUtil.isNotEmpty(getFdwMatchBillNotLike())){
			c.andFdwMatchBillNotLike("%"+this.getFdwMatchBillNotLike()+"%");
		}
		if(CheckUtil.isNotEmpty(getFdwMatchBillNotIn())){
			c.andFdwMatchBillNotIn(this.getFdwMatchBillNotIn());
		}
		if(CheckUtil.isNotEmpty(getFdwMatchBillNotEqualTo())){
			c.andFdwMatchBillNotEqualTo(this.getFdwMatchBillNotEqualTo());
		}
		if(CheckUtil.isNotEmpty(getFdwMatchBillLike())){
			c.andFdwMatchBillLike("%"+this.getFdwMatchBillLike()+"%");
		}
		if(CheckUtil.isNotEmpty(getFdwMatchBillLessThanOrEqualTo())){
			c.andFdwMatchBillLessThanOrEqualTo(this.getFdwMatchBillLessThanOrEqualTo());
		}
		if(CheckUtil.isNotEmpty(getFdwMatchBillLessThan())){
			c.andFdwMatchBillLessThan(this.getFdwMatchBillLessThan());
		}
		if(CheckUtil.isNotEmpty(getFdwMatchBillIsNull()) && this.getFdwMatchBillIsNull()){
			c.andFdwMatchBillIsNull();
		}
		if(CheckUtil.isNotEmpty(getFdwMatchBillIsNotNull()) && this.getFdwMatchBillIsNotNull()){
			c.andFdwMatchBillIsNotNull();
		}
		if(CheckUtil.isNotEmpty(getFdwMatchBillIn())){
			c.andFdwMatchBillIn(this.getFdwMatchBillIn());
		}
		if(CheckUtil.isNotEmpty(getFdwMatchBillGreaterThanOrEqualTo())){
			c.andFdwMatchBillGreaterThanOrEqualTo(this.getFdwMatchBillGreaterThanOrEqualTo());
		}
		if(CheckUtil.isNotEmpty(getFdwMatchBillGreaterThan())){
			c.andFdwMatchBillGreaterThan(this.getFdwMatchBillGreaterThan());
		}
		if(CheckUtil.isNotEmpty(getFdwMatchBillEqualTo())){
			c.andFdwMatchBillEqualTo(this.getFdwMatchBillEqualTo());
		}
		if(CheckUtil.isNotEmpty(getFdwIdNotIn())){
			c.andFdwIdNotIn(this.getFdwIdNotIn());
		}
		if(CheckUtil.isNotEmpty(getFdwIdNotEqualTo())){
			c.andFdwIdNotEqualTo(this.getFdwIdNotEqualTo());
		}
		if(CheckUtil.isNotEmpty(getFdwIdLessThanOrEqualTo())){
			c.andFdwIdLessThanOrEqualTo(this.getFdwIdLessThanOrEqualTo());
		}
		if(CheckUtil.isNotEmpty(getFdwIdLessThan())){
			c.andFdwIdLessThan(this.getFdwIdLessThan());
		}
		if(CheckUtil.isNotEmpty(getFdwIdIsNull()) && this.getFdwIdIsNull()){
			c.andFdwIdIsNull();
		}
		if(CheckUtil.isNotEmpty(getFdwIdIsNotNull()) && this.getFdwIdIsNotNull()){
			c.andFdwIdIsNotNull();
		}
		if(CheckUtil.isNotEmpty(getFdwIdIn())){
			c.andFdwIdIn(this.getFdwIdIn());
		}
		if(CheckUtil.isNotEmpty(getFdwIdGreaterThanOrEqualTo())){
			c.andFdwIdGreaterThanOrEqualTo(this.getFdwIdGreaterThanOrEqualTo());
		}
		if(CheckUtil.isNotEmpty(getFdwIdGreaterThan())){
			c.andFdwIdGreaterThan(this.getFdwIdGreaterThan());
		}
		if(CheckUtil.isNotEmpty(getFdwIdEqualTo())){
			c.andFdwIdEqualTo(this.getFdwIdEqualTo());
		}
		if(CheckUtil.isNotEmpty(getFdwCarVinNotLike())){
			c.andFdwCarVinNotLike("%"+this.getFdwCarVinNotLike()+"%");
		}
		if(CheckUtil.isNotEmpty(getFdwCarVinNotIn())){
			c.andFdwCarVinNotIn(this.getFdwCarVinNotIn());
		}
		if(CheckUtil.isNotEmpty(getFdwCarVinNotEqualTo())){
			c.andFdwCarVinNotEqualTo(this.getFdwCarVinNotEqualTo());
		}
		if(CheckUtil.isNotEmpty(getFdwCarVinLike())){
			c.andFdwCarVinLike("%"+this.getFdwCarVinLike()+"%");
		}
		if(CheckUtil.isNotEmpty(getFdwCarVinLessThanOrEqualTo())){
			c.andFdwCarVinLessThanOrEqualTo(this.getFdwCarVinLessThanOrEqualTo());
		}
		if(CheckUtil.isNotEmpty(getFdwCarVinLessThan())){
			c.andFdwCarVinLessThan(this.getFdwCarVinLessThan());
		}
		if(CheckUtil.isNotEmpty(getFdwCarVinIsNull()) && this.getFdwCarVinIsNull()){
			c.andFdwCarVinIsNull();
		}
		if(CheckUtil.isNotEmpty(getFdwCarVinIsNotNull()) && this.getFdwCarVinIsNotNull()){
			c.andFdwCarVinIsNotNull();
		}
		if(CheckUtil.isNotEmpty(getFdwCarVinIn())){
			c.andFdwCarVinIn(this.getFdwCarVinIn());
		}
		if(CheckUtil.isNotEmpty(getFdwCarVinGreaterThanOrEqualTo())){
			c.andFdwCarVinGreaterThanOrEqualTo(this.getFdwCarVinGreaterThanOrEqualTo());
		}
		if(CheckUtil.isNotEmpty(getFdwCarVinGreaterThan())){
			c.andFdwCarVinGreaterThan(this.getFdwCarVinGreaterThan());
		}
		if(CheckUtil.isNotEmpty(getFdwCarVinEqualTo())){
			c.andFdwCarVinEqualTo(this.getFdwCarVinEqualTo());
		}
		if(CheckUtil.isNotEmpty(getFdwAccountNoNotLike())){
			c.andFdwAccountNoNotLike("%"+this.getFdwAccountNoNotLike()+"%");
		}
		if(CheckUtil.isNotEmpty(getFdwAccountNoNotIn())){
			c.andFdwAccountNoNotIn(this.getFdwAccountNoNotIn());
		}
		if(CheckUtil.isNotEmpty(getFdwAccountNoNotEqualTo())){
			c.andFdwAccountNoNotEqualTo(this.getFdwAccountNoNotEqualTo());
		}
		if(CheckUtil.isNotEmpty(getFdwAccountNoLike())){
			c.andFdwAccountNoLike("%"+this.getFdwAccountNoLike()+"%");
		}
		if(CheckUtil.isNotEmpty(getFdwAccountNoLessThanOrEqualTo())){
			c.andFdwAccountNoLessThanOrEqualTo(this.getFdwAccountNoLessThanOrEqualTo());
		}
		if(CheckUtil.isNotEmpty(getFdwAccountNoLessThan())){
			c.andFdwAccountNoLessThan(this.getFdwAccountNoLessThan());
		}
		if(CheckUtil.isNotEmpty(getFdwAccountNoIsNull()) && this.getFdwAccountNoIsNull()){
			c.andFdwAccountNoIsNull();
		}
		if(CheckUtil.isNotEmpty(getFdwAccountNoIsNotNull()) && this.getFdwAccountNoIsNotNull()){
			c.andFdwAccountNoIsNotNull();
		}
		if(CheckUtil.isNotEmpty(getFdwAccountNoIn())){
			c.andFdwAccountNoIn(this.getFdwAccountNoIn());
		}
		if(CheckUtil.isNotEmpty(getFdwAccountNoGreaterThanOrEqualTo())){
			c.andFdwAccountNoGreaterThanOrEqualTo(this.getFdwAccountNoGreaterThanOrEqualTo());
		}
		if(CheckUtil.isNotEmpty(getFdwAccountNoGreaterThan())){
			c.andFdwAccountNoGreaterThan(this.getFdwAccountNoGreaterThan());
		}
		if(CheckUtil.isNotEmpty(getFdwAccountNoEqualTo())){
			c.andFdwAccountNoEqualTo(this.getFdwAccountNoEqualTo());
		}
		if(CheckUtil.isNotEmpty(getFdwAccountDealFlowNotLike())){
			c.andFdwAccountDealFlowNotLike("%"+this.getFdwAccountDealFlowNotLike()+"%");
		}
		if(CheckUtil.isNotEmpty(getFdwAccountDealFlowNotIn())){
			c.andFdwAccountDealFlowNotIn(this.getFdwAccountDealFlowNotIn());
		}
		if(CheckUtil.isNotEmpty(getFdwAccountDealFlowNotEqualTo())){
			c.andFdwAccountDealFlowNotEqualTo(this.getFdwAccountDealFlowNotEqualTo());
		}
		if(CheckUtil.isNotEmpty(getFdwAccountDealFlowLike())){
			c.andFdwAccountDealFlowLike("%"+this.getFdwAccountDealFlowLike()+"%");
		}
		if(CheckUtil.isNotEmpty(getFdwAccountDealFlowLessThanOrEqualTo())){
			c.andFdwAccountDealFlowLessThanOrEqualTo(this.getFdwAccountDealFlowLessThanOrEqualTo());
		}
		if(CheckUtil.isNotEmpty(getFdwAccountDealFlowLessThan())){
			c.andFdwAccountDealFlowLessThan(this.getFdwAccountDealFlowLessThan());
		}
		if(CheckUtil.isNotEmpty(getFdwAccountDealFlowIsNull()) && this.getFdwAccountDealFlowIsNull()){
			c.andFdwAccountDealFlowIsNull();
		}
		if(CheckUtil.isNotEmpty(getFdwAccountDealFlowIsNotNull()) && this.getFdwAccountDealFlowIsNotNull()){
			c.andFdwAccountDealFlowIsNotNull();
		}
		if(CheckUtil.isNotEmpty(getFdwAccountDealFlowIn())){
			c.andFdwAccountDealFlowIn(this.getFdwAccountDealFlowIn());
		}
		if(CheckUtil.isNotEmpty(getFdwAccountDealFlowGreaterThanOrEqualTo())){
			c.andFdwAccountDealFlowGreaterThanOrEqualTo(this.getFdwAccountDealFlowGreaterThanOrEqualTo());
		}
		if(CheckUtil.isNotEmpty(getFdwAccountDealFlowGreaterThan())){
			c.andFdwAccountDealFlowGreaterThan(this.getFdwAccountDealFlowGreaterThan());
		}
		if(CheckUtil.isNotEmpty(getFdwAccountDealFlowEqualTo())){
			c.andFdwAccountDealFlowEqualTo(this.getFdwAccountDealFlowEqualTo());
		}
		if(CheckUtil.isNotEmpty(getDrNotIn())){
			c.andDrNotIn(this.getDrNotIn());
		}
		if(CheckUtil.isNotEmpty(getDrNotEqualTo())){
			c.andDrNotEqualTo(this.getDrNotEqualTo());
		}
		if(CheckUtil.isNotEmpty(getDrLessThanOrEqualTo())){
			c.andDrLessThanOrEqualTo(this.getDrLessThanOrEqualTo());
		}
		if(CheckUtil.isNotEmpty(getDrLessThan())){
			c.andDrLessThan(this.getDrLessThan());
		}
		if(CheckUtil.isNotEmpty(getDrIsNull()) && this.getDrIsNull()){
			c.andDrIsNull();
		}
		if(CheckUtil.isNotEmpty(getDrIsNotNull()) && this.getDrIsNotNull()){
			c.andDrIsNotNull();
		}
		if(CheckUtil.isNotEmpty(getDrIn())){
			c.andDrIn(this.getDrIn());
		}
		if(CheckUtil.isNotEmpty(getDrGreaterThanOrEqualTo())){
			c.andDrGreaterThanOrEqualTo(this.getDrGreaterThanOrEqualTo());
		}
		if(CheckUtil.isNotEmpty(getDrGreaterThan())){
			c.andDrGreaterThan(this.getDrGreaterThan());
		}
		if(CheckUtil.isNotEmpty(getDrEqualTo())){
			c.andDrEqualTo(this.getDrEqualTo());
		}
		if(CheckUtil.isNotEmpty(getCreateuserNotLike())){
			c.andCreateuserNotLike("%"+this.getCreateuserNotLike()+"%");
		}
		if(CheckUtil.isNotEmpty(getCreateuserNotIn())){
			c.andCreateuserNotIn(this.getCreateuserNotIn());
		}
		if(CheckUtil.isNotEmpty(getCreateuserNotEqualTo())){
			c.andCreateuserNotEqualTo(this.getCreateuserNotEqualTo());
		}
		if(CheckUtil.isNotEmpty(getCreateuserLike())){
			c.andCreateuserLike("%"+this.getCreateuserLike()+"%");
		}
		if(CheckUtil.isNotEmpty(getCreateuserLessThanOrEqualTo())){
			c.andCreateuserLessThanOrEqualTo(this.getCreateuserLessThanOrEqualTo());
		}
		if(CheckUtil.isNotEmpty(getCreateuserLessThan())){
			c.andCreateuserLessThan(this.getCreateuserLessThan());
		}
		if(CheckUtil.isNotEmpty(getCreateuserIsNull()) && this.getCreateuserIsNull()){
			c.andCreateuserIsNull();
		}
		if(CheckUtil.isNotEmpty(getCreateuserIsNotNull()) && this.getCreateuserIsNotNull()){
			c.andCreateuserIsNotNull();
		}
		if(CheckUtil.isNotEmpty(getCreateuserIn())){
			c.andCreateuserIn(this.getCreateuserIn());
		}
		if(CheckUtil.isNotEmpty(getCreateuserGreaterThanOrEqualTo())){
			c.andCreateuserGreaterThanOrEqualTo(this.getCreateuserGreaterThanOrEqualTo());
		}
		if(CheckUtil.isNotEmpty(getCreateuserGreaterThan())){
			c.andCreateuserGreaterThan(this.getCreateuserGreaterThan());
		}
		if(CheckUtil.isNotEmpty(getCreateuserEqualTo())){
			c.andCreateuserEqualTo(this.getCreateuserEqualTo());
		}
		if(CheckUtil.isNotEmpty(getCreatetimeNotIn())){
			c.andCreatetimeNotIn(this.getCreatetimeNotIn());
		}
		if(CheckUtil.isNotEmpty(getCreatetimeNotEqualTo())){
			c.andCreatetimeNotEqualTo(this.getCreatetimeNotEqualTo());
		}
		if(CheckUtil.isNotEmpty(getCreatetimeLessThanOrEqualTo())){
			c.andCreatetimeLessThanOrEqualTo(this.getCreatetimeLessThanOrEqualTo());
		}
		if(CheckUtil.isNotEmpty(getCreatetimeLessThan())){
			c.andCreatetimeLessThan(this.getCreatetimeLessThan());
		}
		if(CheckUtil.isNotEmpty(getCreatetimeIsNull()) && this.getCreatetimeIsNull()){
			c.andCreatetimeIsNull();
		}
		if(CheckUtil.isNotEmpty(getCreatetimeIsNotNull()) && this.getCreatetimeIsNotNull()){
			c.andCreatetimeIsNotNull();
		}
		if(CheckUtil.isNotEmpty(getCreatetimeIn())){
			c.andCreatetimeIn(this.getCreatetimeIn());
		}
		if(CheckUtil.isNotEmpty(getCreatetimeGreaterThanOrEqualTo())){
			c.andCreatetimeGreaterThanOrEqualTo(this.getCreatetimeGreaterThanOrEqualTo());
		}
		if(CheckUtil.isNotEmpty(getCreatetimeGreaterThan())){
			c.andCreatetimeGreaterThan(this.getCreatetimeGreaterThan());
		}
		if(CheckUtil.isNotEmpty(getCreatetimeEqualTo())){
			c.andCreatetimeEqualTo(this.getCreatetimeEqualTo());
		}
		if((this.getSidx()!=null && !this.getSidx().trim().equals("")) && this.getSord()!=null) {
			q.setOrderByClause(""+ this.getSidx()+" "+this.getSord());
		}
		return q;
	}
	public String getUpdateuserNotLike() {
		return updateuserNotLike;
	}
	public void setUpdateuserNotLike(String updateuserNotLike) {
		this.updateuserNotLike = updateuserNotLike;
	}

	public java.util.List getUpdateuserNotIn() {
		return updateuserNotIn;
	}
	public void setUpdateuserNotIn(java.util.List updateuserNotIn) {
		this.updateuserNotIn = updateuserNotIn;
	}

	public String getUpdateuserNotEqualTo() {
		return updateuserNotEqualTo;
	}
	public void setUpdateuserNotEqualTo(String updateuserNotEqualTo) {
		this.updateuserNotEqualTo = updateuserNotEqualTo;
	}

	public String getUpdateuserLike() {
		return updateuserLike;
	}
	public void setUpdateuserLike(String updateuserLike) {
		this.updateuserLike = updateuserLike;
	}

	public String getUpdateuserLessThanOrEqualTo() {
		return updateuserLessThanOrEqualTo;
	}
	public void setUpdateuserLessThanOrEqualTo(String updateuserLessThanOrEqualTo) {
		this.updateuserLessThanOrEqualTo = updateuserLessThanOrEqualTo;
	}

	public String getUpdateuserLessThan() {
		return updateuserLessThan;
	}
	public void setUpdateuserLessThan(String updateuserLessThan) {
		this.updateuserLessThan = updateuserLessThan;
	}

	public Boolean getUpdateuserIsNull() {
		return updateuserIsNull;
	}
	public void setUpdateuserIsNull(Boolean updateuserIsNull) {
		this.updateuserIsNull = updateuserIsNull;
	}

	public Boolean getUpdateuserIsNotNull() {
		return updateuserIsNotNull;
	}
	public void setUpdateuserIsNotNull(Boolean updateuserIsNotNull) {
		this.updateuserIsNotNull = updateuserIsNotNull;
	}

	public java.util.List getUpdateuserIn() {
		return updateuserIn;
	}
	public void setUpdateuserIn(java.util.List updateuserIn) {
		this.updateuserIn = updateuserIn;
	}

	public String getUpdateuserGreaterThanOrEqualTo() {
		return updateuserGreaterThanOrEqualTo;
	}
	public void setUpdateuserGreaterThanOrEqualTo(String updateuserGreaterThanOrEqualTo) {
		this.updateuserGreaterThanOrEqualTo = updateuserGreaterThanOrEqualTo;
	}

	public String getUpdateuserGreaterThan() {
		return updateuserGreaterThan;
	}
	public void setUpdateuserGreaterThan(String updateuserGreaterThan) {
		this.updateuserGreaterThan = updateuserGreaterThan;
	}

	public String getUpdateuserEqualTo() {
		return updateuserEqualTo;
	}
	public void setUpdateuserEqualTo(String updateuserEqualTo) {
		this.updateuserEqualTo = updateuserEqualTo;
	}

	public java.util.List getUpdatetimeNotIn() {
		return updatetimeNotIn;
	}
	public void setUpdatetimeNotIn(java.util.List updatetimeNotIn) {
		this.updatetimeNotIn = updatetimeNotIn;
	}

	public java.util.Date getUpdatetimeNotEqualTo() {
		return updatetimeNotEqualTo;
	}
	public void setUpdatetimeNotEqualTo(java.util.Date updatetimeNotEqualTo) {
		this.updatetimeNotEqualTo = updatetimeNotEqualTo;
	}

	public java.util.Date getUpdatetimeLessThanOrEqualTo() {
		return updatetimeLessThanOrEqualTo;
	}
	public void setUpdatetimeLessThanOrEqualTo(java.util.Date updatetimeLessThanOrEqualTo) {
		this.updatetimeLessThanOrEqualTo = updatetimeLessThanOrEqualTo;
	}

	public java.util.Date getUpdatetimeLessThan() {
		return updatetimeLessThan;
	}
	public void setUpdatetimeLessThan(java.util.Date updatetimeLessThan) {
		this.updatetimeLessThan = updatetimeLessThan;
	}

	public Boolean getUpdatetimeIsNull() {
		return updatetimeIsNull;
	}
	public void setUpdatetimeIsNull(Boolean updatetimeIsNull) {
		this.updatetimeIsNull = updatetimeIsNull;
	}

	public Boolean getUpdatetimeIsNotNull() {
		return updatetimeIsNotNull;
	}
	public void setUpdatetimeIsNotNull(Boolean updatetimeIsNotNull) {
		this.updatetimeIsNotNull = updatetimeIsNotNull;
	}

	public java.util.List getUpdatetimeIn() {
		return updatetimeIn;
	}
	public void setUpdatetimeIn(java.util.List updatetimeIn) {
		this.updatetimeIn = updatetimeIn;
	}

	public java.util.Date getUpdatetimeGreaterThanOrEqualTo() {
		return updatetimeGreaterThanOrEqualTo;
	}
	public void setUpdatetimeGreaterThanOrEqualTo(java.util.Date updatetimeGreaterThanOrEqualTo) {
		this.updatetimeGreaterThanOrEqualTo = updatetimeGreaterThanOrEqualTo;
	}

	public java.util.Date getUpdatetimeGreaterThan() {
		return updatetimeGreaterThan;
	}
	public void setUpdatetimeGreaterThan(java.util.Date updatetimeGreaterThan) {
		this.updatetimeGreaterThan = updatetimeGreaterThan;
	}

	public java.util.Date getUpdatetimeEqualTo() {
		return updatetimeEqualTo;
	}
	public void setUpdatetimeEqualTo(java.util.Date updatetimeEqualTo) {
		this.updatetimeEqualTo = updatetimeEqualTo;
	}

	public String getRemarkNotLike() {
		return remarkNotLike;
	}
	public void setRemarkNotLike(String remarkNotLike) {
		this.remarkNotLike = remarkNotLike;
	}

	public java.util.List getRemarkNotIn() {
		return remarkNotIn;
	}
	public void setRemarkNotIn(java.util.List remarkNotIn) {
		this.remarkNotIn = remarkNotIn;
	}

	public String getRemarkNotEqualTo() {
		return remarkNotEqualTo;
	}
	public void setRemarkNotEqualTo(String remarkNotEqualTo) {
		this.remarkNotEqualTo = remarkNotEqualTo;
	}

	public String getRemarkLike() {
		return remarkLike;
	}
	public void setRemarkLike(String remarkLike) {
		this.remarkLike = remarkLike;
	}

	public String getRemarkLessThanOrEqualTo() {
		return remarkLessThanOrEqualTo;
	}
	public void setRemarkLessThanOrEqualTo(String remarkLessThanOrEqualTo) {
		this.remarkLessThanOrEqualTo = remarkLessThanOrEqualTo;
	}

	public String getRemarkLessThan() {
		return remarkLessThan;
	}
	public void setRemarkLessThan(String remarkLessThan) {
		this.remarkLessThan = remarkLessThan;
	}

	public Boolean getRemarkIsNull() {
		return remarkIsNull;
	}
	public void setRemarkIsNull(Boolean remarkIsNull) {
		this.remarkIsNull = remarkIsNull;
	}

	public Boolean getRemarkIsNotNull() {
		return remarkIsNotNull;
	}
	public void setRemarkIsNotNull(Boolean remarkIsNotNull) {
		this.remarkIsNotNull = remarkIsNotNull;
	}

	public java.util.List getRemarkIn() {
		return remarkIn;
	}
	public void setRemarkIn(java.util.List remarkIn) {
		this.remarkIn = remarkIn;
	}

	public String getRemarkGreaterThanOrEqualTo() {
		return remarkGreaterThanOrEqualTo;
	}
	public void setRemarkGreaterThanOrEqualTo(String remarkGreaterThanOrEqualTo) {
		this.remarkGreaterThanOrEqualTo = remarkGreaterThanOrEqualTo;
	}

	public String getRemarkGreaterThan() {
		return remarkGreaterThan;
	}
	public void setRemarkGreaterThan(String remarkGreaterThan) {
		this.remarkGreaterThan = remarkGreaterThan;
	}

	public String getRemarkEqualTo() {
		return remarkEqualTo;
	}
	public void setRemarkEqualTo(String remarkEqualTo) {
		this.remarkEqualTo = remarkEqualTo;
	}

	public java.util.List getFdwTradeTimeNotIn() {
		return fdwTradeTimeNotIn;
	}
	public void setFdwTradeTimeNotIn(java.util.List fdwTradeTimeNotIn) {
		this.fdwTradeTimeNotIn = fdwTradeTimeNotIn;
	}

	public java.util.Date getFdwTradeTimeNotEqualTo() {
		return fdwTradeTimeNotEqualTo;
	}
	public void setFdwTradeTimeNotEqualTo(java.util.Date fdwTradeTimeNotEqualTo) {
		this.fdwTradeTimeNotEqualTo = fdwTradeTimeNotEqualTo;
	}

	public java.util.Date getFdwTradeTimeLessThanOrEqualTo() {
		return fdwTradeTimeLessThanOrEqualTo;
	}
	public void setFdwTradeTimeLessThanOrEqualTo(java.util.Date fdwTradeTimeLessThanOrEqualTo) {
		this.fdwTradeTimeLessThanOrEqualTo = fdwTradeTimeLessThanOrEqualTo;
	}

	public java.util.Date getFdwTradeTimeLessThan() {
		return fdwTradeTimeLessThan;
	}
	public void setFdwTradeTimeLessThan(java.util.Date fdwTradeTimeLessThan) {
		this.fdwTradeTimeLessThan = fdwTradeTimeLessThan;
	}

	public Boolean getFdwTradeTimeIsNull() {
		return fdwTradeTimeIsNull;
	}
	public void setFdwTradeTimeIsNull(Boolean fdwTradeTimeIsNull) {
		this.fdwTradeTimeIsNull = fdwTradeTimeIsNull;
	}

	public Boolean getFdwTradeTimeIsNotNull() {
		return fdwTradeTimeIsNotNull;
	}
	public void setFdwTradeTimeIsNotNull(Boolean fdwTradeTimeIsNotNull) {
		this.fdwTradeTimeIsNotNull = fdwTradeTimeIsNotNull;
	}

	public java.util.List getFdwTradeTimeIn() {
		return fdwTradeTimeIn;
	}
	public void setFdwTradeTimeIn(java.util.List fdwTradeTimeIn) {
		this.fdwTradeTimeIn = fdwTradeTimeIn;
	}

	public java.util.Date getFdwTradeTimeGreaterThanOrEqualTo() {
		return fdwTradeTimeGreaterThanOrEqualTo;
	}
	public void setFdwTradeTimeGreaterThanOrEqualTo(java.util.Date fdwTradeTimeGreaterThanOrEqualTo) {
		this.fdwTradeTimeGreaterThanOrEqualTo = fdwTradeTimeGreaterThanOrEqualTo;
	}

	public java.util.Date getFdwTradeTimeGreaterThan() {
		return fdwTradeTimeGreaterThan;
	}
	public void setFdwTradeTimeGreaterThan(java.util.Date fdwTradeTimeGreaterThan) {
		this.fdwTradeTimeGreaterThan = fdwTradeTimeGreaterThan;
	}

	public java.util.Date getFdwTradeTimeEqualTo() {
		return fdwTradeTimeEqualTo;
	}
	public void setFdwTradeTimeEqualTo(java.util.Date fdwTradeTimeEqualTo) {
		this.fdwTradeTimeEqualTo = fdwTradeTimeEqualTo;
	}

	public String getFdwTradePartyNotLike() {
		return fdwTradePartyNotLike;
	}
	public void setFdwTradePartyNotLike(String fdwTradePartyNotLike) {
		this.fdwTradePartyNotLike = fdwTradePartyNotLike;
	}

	public java.util.List getFdwTradePartyNotIn() {
		return fdwTradePartyNotIn;
	}
	public void setFdwTradePartyNotIn(java.util.List fdwTradePartyNotIn) {
		this.fdwTradePartyNotIn = fdwTradePartyNotIn;
	}

	public String getFdwTradePartyNotEqualTo() {
		return fdwTradePartyNotEqualTo;
	}
	public void setFdwTradePartyNotEqualTo(String fdwTradePartyNotEqualTo) {
		this.fdwTradePartyNotEqualTo = fdwTradePartyNotEqualTo;
	}

	public String getFdwTradePartyLike() {
		return fdwTradePartyLike;
	}
	public void setFdwTradePartyLike(String fdwTradePartyLike) {
		this.fdwTradePartyLike = fdwTradePartyLike;
	}

	public String getFdwTradePartyLessThanOrEqualTo() {
		return fdwTradePartyLessThanOrEqualTo;
	}
	public void setFdwTradePartyLessThanOrEqualTo(String fdwTradePartyLessThanOrEqualTo) {
		this.fdwTradePartyLessThanOrEqualTo = fdwTradePartyLessThanOrEqualTo;
	}

	public String getFdwTradePartyLessThan() {
		return fdwTradePartyLessThan;
	}
	public void setFdwTradePartyLessThan(String fdwTradePartyLessThan) {
		this.fdwTradePartyLessThan = fdwTradePartyLessThan;
	}

	public Boolean getFdwTradePartyIsNull() {
		return fdwTradePartyIsNull;
	}
	public void setFdwTradePartyIsNull(Boolean fdwTradePartyIsNull) {
		this.fdwTradePartyIsNull = fdwTradePartyIsNull;
	}

	public Boolean getFdwTradePartyIsNotNull() {
		return fdwTradePartyIsNotNull;
	}
	public void setFdwTradePartyIsNotNull(Boolean fdwTradePartyIsNotNull) {
		this.fdwTradePartyIsNotNull = fdwTradePartyIsNotNull;
	}

	public java.util.List getFdwTradePartyIn() {
		return fdwTradePartyIn;
	}
	public void setFdwTradePartyIn(java.util.List fdwTradePartyIn) {
		this.fdwTradePartyIn = fdwTradePartyIn;
	}

	public String getFdwTradePartyGreaterThanOrEqualTo() {
		return fdwTradePartyGreaterThanOrEqualTo;
	}
	public void setFdwTradePartyGreaterThanOrEqualTo(String fdwTradePartyGreaterThanOrEqualTo) {
		this.fdwTradePartyGreaterThanOrEqualTo = fdwTradePartyGreaterThanOrEqualTo;
	}

	public String getFdwTradePartyGreaterThan() {
		return fdwTradePartyGreaterThan;
	}
	public void setFdwTradePartyGreaterThan(String fdwTradePartyGreaterThan) {
		this.fdwTradePartyGreaterThan = fdwTradePartyGreaterThan;
	}

	public String getFdwTradePartyEqualTo() {
		return fdwTradePartyEqualTo;
	}
	public void setFdwTradePartyEqualTo(String fdwTradePartyEqualTo) {
		this.fdwTradePartyEqualTo = fdwTradePartyEqualTo;
	}

	public String getFdwTradeNamesNotLike() {
		return fdwTradeNamesNotLike;
	}
	public void setFdwTradeNamesNotLike(String fdwTradeNamesNotLike) {
		this.fdwTradeNamesNotLike = fdwTradeNamesNotLike;
	}

	public java.util.List getFdwTradeNamesNotIn() {
		return fdwTradeNamesNotIn;
	}
	public void setFdwTradeNamesNotIn(java.util.List fdwTradeNamesNotIn) {
		this.fdwTradeNamesNotIn = fdwTradeNamesNotIn;
	}

	public String getFdwTradeNamesNotEqualTo() {
		return fdwTradeNamesNotEqualTo;
	}
	public void setFdwTradeNamesNotEqualTo(String fdwTradeNamesNotEqualTo) {
		this.fdwTradeNamesNotEqualTo = fdwTradeNamesNotEqualTo;
	}

	public String getFdwTradeNamesLike() {
		return fdwTradeNamesLike;
	}
	public void setFdwTradeNamesLike(String fdwTradeNamesLike) {
		this.fdwTradeNamesLike = fdwTradeNamesLike;
	}

	public String getFdwTradeNamesLessThanOrEqualTo() {
		return fdwTradeNamesLessThanOrEqualTo;
	}
	public void setFdwTradeNamesLessThanOrEqualTo(String fdwTradeNamesLessThanOrEqualTo) {
		this.fdwTradeNamesLessThanOrEqualTo = fdwTradeNamesLessThanOrEqualTo;
	}

	public String getFdwTradeNamesLessThan() {
		return fdwTradeNamesLessThan;
	}
	public void setFdwTradeNamesLessThan(String fdwTradeNamesLessThan) {
		this.fdwTradeNamesLessThan = fdwTradeNamesLessThan;
	}

	public Boolean getFdwTradeNamesIsNull() {
		return fdwTradeNamesIsNull;
	}
	public void setFdwTradeNamesIsNull(Boolean fdwTradeNamesIsNull) {
		this.fdwTradeNamesIsNull = fdwTradeNamesIsNull;
	}

	public Boolean getFdwTradeNamesIsNotNull() {
		return fdwTradeNamesIsNotNull;
	}
	public void setFdwTradeNamesIsNotNull(Boolean fdwTradeNamesIsNotNull) {
		this.fdwTradeNamesIsNotNull = fdwTradeNamesIsNotNull;
	}

	public java.util.List getFdwTradeNamesIn() {
		return fdwTradeNamesIn;
	}
	public void setFdwTradeNamesIn(java.util.List fdwTradeNamesIn) {
		this.fdwTradeNamesIn = fdwTradeNamesIn;
	}

	public String getFdwTradeNamesGreaterThanOrEqualTo() {
		return fdwTradeNamesGreaterThanOrEqualTo;
	}
	public void setFdwTradeNamesGreaterThanOrEqualTo(String fdwTradeNamesGreaterThanOrEqualTo) {
		this.fdwTradeNamesGreaterThanOrEqualTo = fdwTradeNamesGreaterThanOrEqualTo;
	}

	public String getFdwTradeNamesGreaterThan() {
		return fdwTradeNamesGreaterThan;
	}
	public void setFdwTradeNamesGreaterThan(String fdwTradeNamesGreaterThan) {
		this.fdwTradeNamesGreaterThan = fdwTradeNamesGreaterThan;
	}

	public String getFdwTradeNamesEqualTo() {
		return fdwTradeNamesEqualTo;
	}
	public void setFdwTradeNamesEqualTo(String fdwTradeNamesEqualTo) {
		this.fdwTradeNamesEqualTo = fdwTradeNamesEqualTo;
	}

	public java.util.List getFdwTradeAmountNotIn() {
		return fdwTradeAmountNotIn;
	}
	public void setFdwTradeAmountNotIn(java.util.List fdwTradeAmountNotIn) {
		this.fdwTradeAmountNotIn = fdwTradeAmountNotIn;
	}

	public Double getFdwTradeAmountNotEqualTo() {
		return fdwTradeAmountNotEqualTo;
	}
	public void setFdwTradeAmountNotEqualTo(Double fdwTradeAmountNotEqualTo) {
		this.fdwTradeAmountNotEqualTo = fdwTradeAmountNotEqualTo;
	}

	public Double getFdwTradeAmountLessThanOrEqualTo() {
		return fdwTradeAmountLessThanOrEqualTo;
	}
	public void setFdwTradeAmountLessThanOrEqualTo(Double fdwTradeAmountLessThanOrEqualTo) {
		this.fdwTradeAmountLessThanOrEqualTo = fdwTradeAmountLessThanOrEqualTo;
	}

	public Double getFdwTradeAmountLessThan() {
		return fdwTradeAmountLessThan;
	}
	public void setFdwTradeAmountLessThan(Double fdwTradeAmountLessThan) {
		this.fdwTradeAmountLessThan = fdwTradeAmountLessThan;
	}

	public Boolean getFdwTradeAmountIsNull() {
		return fdwTradeAmountIsNull;
	}
	public void setFdwTradeAmountIsNull(Boolean fdwTradeAmountIsNull) {
		this.fdwTradeAmountIsNull = fdwTradeAmountIsNull;
	}

	public Boolean getFdwTradeAmountIsNotNull() {
		return fdwTradeAmountIsNotNull;
	}
	public void setFdwTradeAmountIsNotNull(Boolean fdwTradeAmountIsNotNull) {
		this.fdwTradeAmountIsNotNull = fdwTradeAmountIsNotNull;
	}

	public java.util.List getFdwTradeAmountIn() {
		return fdwTradeAmountIn;
	}
	public void setFdwTradeAmountIn(java.util.List fdwTradeAmountIn) {
		this.fdwTradeAmountIn = fdwTradeAmountIn;
	}

	public Double getFdwTradeAmountGreaterThanOrEqualTo() {
		return fdwTradeAmountGreaterThanOrEqualTo;
	}
	public void setFdwTradeAmountGreaterThanOrEqualTo(Double fdwTradeAmountGreaterThanOrEqualTo) {
		this.fdwTradeAmountGreaterThanOrEqualTo = fdwTradeAmountGreaterThanOrEqualTo;
	}

	public Double getFdwTradeAmountGreaterThan() {
		return fdwTradeAmountGreaterThan;
	}
	public void setFdwTradeAmountGreaterThan(Double fdwTradeAmountGreaterThan) {
		this.fdwTradeAmountGreaterThan = fdwTradeAmountGreaterThan;
	}

	public Double getFdwTradeAmountEqualTo() {
		return fdwTradeAmountEqualTo;
	}
	public void setFdwTradeAmountEqualTo(Double fdwTradeAmountEqualTo) {
		this.fdwTradeAmountEqualTo = fdwTradeAmountEqualTo;
	}

	public String getFdwOrderNoNotLike() {
		return fdwOrderNoNotLike;
	}
	public void setFdwOrderNoNotLike(String fdwOrderNoNotLike) {
		this.fdwOrderNoNotLike = fdwOrderNoNotLike;
	}

	public java.util.List getFdwOrderNoNotIn() {
		return fdwOrderNoNotIn;
	}
	public void setFdwOrderNoNotIn(java.util.List fdwOrderNoNotIn) {
		this.fdwOrderNoNotIn = fdwOrderNoNotIn;
	}

	public String getFdwOrderNoNotEqualTo() {
		return fdwOrderNoNotEqualTo;
	}
	public void setFdwOrderNoNotEqualTo(String fdwOrderNoNotEqualTo) {
		this.fdwOrderNoNotEqualTo = fdwOrderNoNotEqualTo;
	}

	public String getFdwOrderNoLike() {
		return fdwOrderNoLike;
	}
	public void setFdwOrderNoLike(String fdwOrderNoLike) {
		this.fdwOrderNoLike = fdwOrderNoLike;
	}

	public String getFdwOrderNoLessThanOrEqualTo() {
		return fdwOrderNoLessThanOrEqualTo;
	}
	public void setFdwOrderNoLessThanOrEqualTo(String fdwOrderNoLessThanOrEqualTo) {
		this.fdwOrderNoLessThanOrEqualTo = fdwOrderNoLessThanOrEqualTo;
	}

	public String getFdwOrderNoLessThan() {
		return fdwOrderNoLessThan;
	}
	public void setFdwOrderNoLessThan(String fdwOrderNoLessThan) {
		this.fdwOrderNoLessThan = fdwOrderNoLessThan;
	}

	public Boolean getFdwOrderNoIsNull() {
		return fdwOrderNoIsNull;
	}
	public void setFdwOrderNoIsNull(Boolean fdwOrderNoIsNull) {
		this.fdwOrderNoIsNull = fdwOrderNoIsNull;
	}

	public Boolean getFdwOrderNoIsNotNull() {
		return fdwOrderNoIsNotNull;
	}
	public void setFdwOrderNoIsNotNull(Boolean fdwOrderNoIsNotNull) {
		this.fdwOrderNoIsNotNull = fdwOrderNoIsNotNull;
	}

	public java.util.List getFdwOrderNoIn() {
		return fdwOrderNoIn;
	}
	public void setFdwOrderNoIn(java.util.List fdwOrderNoIn) {
		this.fdwOrderNoIn = fdwOrderNoIn;
	}

	public String getFdwOrderNoGreaterThanOrEqualTo() {
		return fdwOrderNoGreaterThanOrEqualTo;
	}
	public void setFdwOrderNoGreaterThanOrEqualTo(String fdwOrderNoGreaterThanOrEqualTo) {
		this.fdwOrderNoGreaterThanOrEqualTo = fdwOrderNoGreaterThanOrEqualTo;
	}

	public String getFdwOrderNoGreaterThan() {
		return fdwOrderNoGreaterThan;
	}
	public void setFdwOrderNoGreaterThan(String fdwOrderNoGreaterThan) {
		this.fdwOrderNoGreaterThan = fdwOrderNoGreaterThan;
	}

	public String getFdwOrderNoEqualTo() {
		return fdwOrderNoEqualTo;
	}
	public void setFdwOrderNoEqualTo(String fdwOrderNoEqualTo) {
		this.fdwOrderNoEqualTo = fdwOrderNoEqualTo;
	}

	public java.util.List getFdwNotMatchAmountNotIn() {
		return fdwNotMatchAmountNotIn;
	}
	public void setFdwNotMatchAmountNotIn(java.util.List fdwNotMatchAmountNotIn) {
		this.fdwNotMatchAmountNotIn = fdwNotMatchAmountNotIn;
	}

	public Double getFdwNotMatchAmountNotEqualTo() {
		return fdwNotMatchAmountNotEqualTo;
	}
	public void setFdwNotMatchAmountNotEqualTo(Double fdwNotMatchAmountNotEqualTo) {
		this.fdwNotMatchAmountNotEqualTo = fdwNotMatchAmountNotEqualTo;
	}

	public Double getFdwNotMatchAmountLessThanOrEqualTo() {
		return fdwNotMatchAmountLessThanOrEqualTo;
	}
	public void setFdwNotMatchAmountLessThanOrEqualTo(Double fdwNotMatchAmountLessThanOrEqualTo) {
		this.fdwNotMatchAmountLessThanOrEqualTo = fdwNotMatchAmountLessThanOrEqualTo;
	}

	public Double getFdwNotMatchAmountLessThan() {
		return fdwNotMatchAmountLessThan;
	}
	public void setFdwNotMatchAmountLessThan(Double fdwNotMatchAmountLessThan) {
		this.fdwNotMatchAmountLessThan = fdwNotMatchAmountLessThan;
	}

	public Boolean getFdwNotMatchAmountIsNull() {
		return fdwNotMatchAmountIsNull;
	}
	public void setFdwNotMatchAmountIsNull(Boolean fdwNotMatchAmountIsNull) {
		this.fdwNotMatchAmountIsNull = fdwNotMatchAmountIsNull;
	}

	public Boolean getFdwNotMatchAmountIsNotNull() {
		return fdwNotMatchAmountIsNotNull;
	}
	public void setFdwNotMatchAmountIsNotNull(Boolean fdwNotMatchAmountIsNotNull) {
		this.fdwNotMatchAmountIsNotNull = fdwNotMatchAmountIsNotNull;
	}

	public java.util.List getFdwNotMatchAmountIn() {
		return fdwNotMatchAmountIn;
	}
	public void setFdwNotMatchAmountIn(java.util.List fdwNotMatchAmountIn) {
		this.fdwNotMatchAmountIn = fdwNotMatchAmountIn;
	}

	public Double getFdwNotMatchAmountGreaterThanOrEqualTo() {
		return fdwNotMatchAmountGreaterThanOrEqualTo;
	}
	public void setFdwNotMatchAmountGreaterThanOrEqualTo(Double fdwNotMatchAmountGreaterThanOrEqualTo) {
		this.fdwNotMatchAmountGreaterThanOrEqualTo = fdwNotMatchAmountGreaterThanOrEqualTo;
	}

	public Double getFdwNotMatchAmountGreaterThan() {
		return fdwNotMatchAmountGreaterThan;
	}
	public void setFdwNotMatchAmountGreaterThan(Double fdwNotMatchAmountGreaterThan) {
		this.fdwNotMatchAmountGreaterThan = fdwNotMatchAmountGreaterThan;
	}

	public Double getFdwNotMatchAmountEqualTo() {
		return fdwNotMatchAmountEqualTo;
	}
	public void setFdwNotMatchAmountEqualTo(Double fdwNotMatchAmountEqualTo) {
		this.fdwNotMatchAmountEqualTo = fdwNotMatchAmountEqualTo;
	}

	public java.util.List getFdwMatchedAmountNotIn() {
		return fdwMatchedAmountNotIn;
	}
	public void setFdwMatchedAmountNotIn(java.util.List fdwMatchedAmountNotIn) {
		this.fdwMatchedAmountNotIn = fdwMatchedAmountNotIn;
	}

	public Double getFdwMatchedAmountNotEqualTo() {
		return fdwMatchedAmountNotEqualTo;
	}
	public void setFdwMatchedAmountNotEqualTo(Double fdwMatchedAmountNotEqualTo) {
		this.fdwMatchedAmountNotEqualTo = fdwMatchedAmountNotEqualTo;
	}

	public Double getFdwMatchedAmountLessThanOrEqualTo() {
		return fdwMatchedAmountLessThanOrEqualTo;
	}
	public void setFdwMatchedAmountLessThanOrEqualTo(Double fdwMatchedAmountLessThanOrEqualTo) {
		this.fdwMatchedAmountLessThanOrEqualTo = fdwMatchedAmountLessThanOrEqualTo;
	}

	public Double getFdwMatchedAmountLessThan() {
		return fdwMatchedAmountLessThan;
	}
	public void setFdwMatchedAmountLessThan(Double fdwMatchedAmountLessThan) {
		this.fdwMatchedAmountLessThan = fdwMatchedAmountLessThan;
	}

	public Boolean getFdwMatchedAmountIsNull() {
		return fdwMatchedAmountIsNull;
	}
	public void setFdwMatchedAmountIsNull(Boolean fdwMatchedAmountIsNull) {
		this.fdwMatchedAmountIsNull = fdwMatchedAmountIsNull;
	}

	public Boolean getFdwMatchedAmountIsNotNull() {
		return fdwMatchedAmountIsNotNull;
	}
	public void setFdwMatchedAmountIsNotNull(Boolean fdwMatchedAmountIsNotNull) {
		this.fdwMatchedAmountIsNotNull = fdwMatchedAmountIsNotNull;
	}

	public java.util.List getFdwMatchedAmountIn() {
		return fdwMatchedAmountIn;
	}
	public void setFdwMatchedAmountIn(java.util.List fdwMatchedAmountIn) {
		this.fdwMatchedAmountIn = fdwMatchedAmountIn;
	}

	public Double getFdwMatchedAmountGreaterThanOrEqualTo() {
		return fdwMatchedAmountGreaterThanOrEqualTo;
	}
	public void setFdwMatchedAmountGreaterThanOrEqualTo(Double fdwMatchedAmountGreaterThanOrEqualTo) {
		this.fdwMatchedAmountGreaterThanOrEqualTo = fdwMatchedAmountGreaterThanOrEqualTo;
	}

	public Double getFdwMatchedAmountGreaterThan() {
		return fdwMatchedAmountGreaterThan;
	}
	public void setFdwMatchedAmountGreaterThan(Double fdwMatchedAmountGreaterThan) {
		this.fdwMatchedAmountGreaterThan = fdwMatchedAmountGreaterThan;
	}

	public Double getFdwMatchedAmountEqualTo() {
		return fdwMatchedAmountEqualTo;
	}
	public void setFdwMatchedAmountEqualTo(Double fdwMatchedAmountEqualTo) {
		this.fdwMatchedAmountEqualTo = fdwMatchedAmountEqualTo;
	}

	public java.util.List getFdwMatchWayNotIn() {
		return fdwMatchWayNotIn;
	}
	public void setFdwMatchWayNotIn(java.util.List fdwMatchWayNotIn) {
		this.fdwMatchWayNotIn = fdwMatchWayNotIn;
	}

	public Integer getFdwMatchWayNotEqualTo() {
		return fdwMatchWayNotEqualTo;
	}
	public void setFdwMatchWayNotEqualTo(Integer fdwMatchWayNotEqualTo) {
		this.fdwMatchWayNotEqualTo = fdwMatchWayNotEqualTo;
	}

	public Integer getFdwMatchWayLessThanOrEqualTo() {
		return fdwMatchWayLessThanOrEqualTo;
	}
	public void setFdwMatchWayLessThanOrEqualTo(Integer fdwMatchWayLessThanOrEqualTo) {
		this.fdwMatchWayLessThanOrEqualTo = fdwMatchWayLessThanOrEqualTo;
	}

	public Integer getFdwMatchWayLessThan() {
		return fdwMatchWayLessThan;
	}
	public void setFdwMatchWayLessThan(Integer fdwMatchWayLessThan) {
		this.fdwMatchWayLessThan = fdwMatchWayLessThan;
	}

	public Boolean getFdwMatchWayIsNull() {
		return fdwMatchWayIsNull;
	}
	public void setFdwMatchWayIsNull(Boolean fdwMatchWayIsNull) {
		this.fdwMatchWayIsNull = fdwMatchWayIsNull;
	}

	public Boolean getFdwMatchWayIsNotNull() {
		return fdwMatchWayIsNotNull;
	}
	public void setFdwMatchWayIsNotNull(Boolean fdwMatchWayIsNotNull) {
		this.fdwMatchWayIsNotNull = fdwMatchWayIsNotNull;
	}

	public java.util.List getFdwMatchWayIn() {
		return fdwMatchWayIn;
	}
	public void setFdwMatchWayIn(java.util.List fdwMatchWayIn) {
		this.fdwMatchWayIn = fdwMatchWayIn;
	}

	public Integer getFdwMatchWayGreaterThanOrEqualTo() {
		return fdwMatchWayGreaterThanOrEqualTo;
	}
	public void setFdwMatchWayGreaterThanOrEqualTo(Integer fdwMatchWayGreaterThanOrEqualTo) {
		this.fdwMatchWayGreaterThanOrEqualTo = fdwMatchWayGreaterThanOrEqualTo;
	}

	public Integer getFdwMatchWayGreaterThan() {
		return fdwMatchWayGreaterThan;
	}
	public void setFdwMatchWayGreaterThan(Integer fdwMatchWayGreaterThan) {
		this.fdwMatchWayGreaterThan = fdwMatchWayGreaterThan;
	}

	public Integer getFdwMatchWayEqualTo() {
		return fdwMatchWayEqualTo;
	}
	public void setFdwMatchWayEqualTo(Integer fdwMatchWayEqualTo) {
		this.fdwMatchWayEqualTo = fdwMatchWayEqualTo;
	}

	public java.util.List getFdwMatchStateNotIn() {
		return fdwMatchStateNotIn;
	}
	public void setFdwMatchStateNotIn(java.util.List fdwMatchStateNotIn) {
		this.fdwMatchStateNotIn = fdwMatchStateNotIn;
	}

	public Integer getFdwMatchStateNotEqualTo() {
		return fdwMatchStateNotEqualTo;
	}
	public void setFdwMatchStateNotEqualTo(Integer fdwMatchStateNotEqualTo) {
		this.fdwMatchStateNotEqualTo = fdwMatchStateNotEqualTo;
	}

	public Integer getFdwMatchStateLessThanOrEqualTo() {
		return fdwMatchStateLessThanOrEqualTo;
	}
	public void setFdwMatchStateLessThanOrEqualTo(Integer fdwMatchStateLessThanOrEqualTo) {
		this.fdwMatchStateLessThanOrEqualTo = fdwMatchStateLessThanOrEqualTo;
	}

	public Integer getFdwMatchStateLessThan() {
		return fdwMatchStateLessThan;
	}
	public void setFdwMatchStateLessThan(Integer fdwMatchStateLessThan) {
		this.fdwMatchStateLessThan = fdwMatchStateLessThan;
	}

	public Boolean getFdwMatchStateIsNull() {
		return fdwMatchStateIsNull;
	}
	public void setFdwMatchStateIsNull(Boolean fdwMatchStateIsNull) {
		this.fdwMatchStateIsNull = fdwMatchStateIsNull;
	}

	public Boolean getFdwMatchStateIsNotNull() {
		return fdwMatchStateIsNotNull;
	}
	public void setFdwMatchStateIsNotNull(Boolean fdwMatchStateIsNotNull) {
		this.fdwMatchStateIsNotNull = fdwMatchStateIsNotNull;
	}

	public java.util.List getFdwMatchStateIn() {
		return fdwMatchStateIn;
	}
	public void setFdwMatchStateIn(java.util.List fdwMatchStateIn) {
		this.fdwMatchStateIn = fdwMatchStateIn;
	}

	public Integer getFdwMatchStateGreaterThanOrEqualTo() {
		return fdwMatchStateGreaterThanOrEqualTo;
	}
	public void setFdwMatchStateGreaterThanOrEqualTo(Integer fdwMatchStateGreaterThanOrEqualTo) {
		this.fdwMatchStateGreaterThanOrEqualTo = fdwMatchStateGreaterThanOrEqualTo;
	}

	public Integer getFdwMatchStateGreaterThan() {
		return fdwMatchStateGreaterThan;
	}
	public void setFdwMatchStateGreaterThan(Integer fdwMatchStateGreaterThan) {
		this.fdwMatchStateGreaterThan = fdwMatchStateGreaterThan;
	}

	public Integer getFdwMatchStateEqualTo() {
		return fdwMatchStateEqualTo;
	}
	public void setFdwMatchStateEqualTo(Integer fdwMatchStateEqualTo) {
		this.fdwMatchStateEqualTo = fdwMatchStateEqualTo;
	}

	public String getFdwMatchBillNotLike() {
		return fdwMatchBillNotLike;
	}
	public void setFdwMatchBillNotLike(String fdwMatchBillNotLike) {
		this.fdwMatchBillNotLike = fdwMatchBillNotLike;
	}

	public java.util.List getFdwMatchBillNotIn() {
		return fdwMatchBillNotIn;
	}
	public void setFdwMatchBillNotIn(java.util.List fdwMatchBillNotIn) {
		this.fdwMatchBillNotIn = fdwMatchBillNotIn;
	}

	public String getFdwMatchBillNotEqualTo() {
		return fdwMatchBillNotEqualTo;
	}
	public void setFdwMatchBillNotEqualTo(String fdwMatchBillNotEqualTo) {
		this.fdwMatchBillNotEqualTo = fdwMatchBillNotEqualTo;
	}

	public String getFdwMatchBillLike() {
		return fdwMatchBillLike;
	}
	public void setFdwMatchBillLike(String fdwMatchBillLike) {
		this.fdwMatchBillLike = fdwMatchBillLike;
	}

	public String getFdwMatchBillLessThanOrEqualTo() {
		return fdwMatchBillLessThanOrEqualTo;
	}
	public void setFdwMatchBillLessThanOrEqualTo(String fdwMatchBillLessThanOrEqualTo) {
		this.fdwMatchBillLessThanOrEqualTo = fdwMatchBillLessThanOrEqualTo;
	}

	public String getFdwMatchBillLessThan() {
		return fdwMatchBillLessThan;
	}
	public void setFdwMatchBillLessThan(String fdwMatchBillLessThan) {
		this.fdwMatchBillLessThan = fdwMatchBillLessThan;
	}

	public Boolean getFdwMatchBillIsNull() {
		return fdwMatchBillIsNull;
	}
	public void setFdwMatchBillIsNull(Boolean fdwMatchBillIsNull) {
		this.fdwMatchBillIsNull = fdwMatchBillIsNull;
	}

	public Boolean getFdwMatchBillIsNotNull() {
		return fdwMatchBillIsNotNull;
	}
	public void setFdwMatchBillIsNotNull(Boolean fdwMatchBillIsNotNull) {
		this.fdwMatchBillIsNotNull = fdwMatchBillIsNotNull;
	}

	public java.util.List getFdwMatchBillIn() {
		return fdwMatchBillIn;
	}
	public void setFdwMatchBillIn(java.util.List fdwMatchBillIn) {
		this.fdwMatchBillIn = fdwMatchBillIn;
	}

	public String getFdwMatchBillGreaterThanOrEqualTo() {
		return fdwMatchBillGreaterThanOrEqualTo;
	}
	public void setFdwMatchBillGreaterThanOrEqualTo(String fdwMatchBillGreaterThanOrEqualTo) {
		this.fdwMatchBillGreaterThanOrEqualTo = fdwMatchBillGreaterThanOrEqualTo;
	}

	public String getFdwMatchBillGreaterThan() {
		return fdwMatchBillGreaterThan;
	}
	public void setFdwMatchBillGreaterThan(String fdwMatchBillGreaterThan) {
		this.fdwMatchBillGreaterThan = fdwMatchBillGreaterThan;
	}

	public String getFdwMatchBillEqualTo() {
		return fdwMatchBillEqualTo;
	}
	public void setFdwMatchBillEqualTo(String fdwMatchBillEqualTo) {
		this.fdwMatchBillEqualTo = fdwMatchBillEqualTo;
	}

	public java.util.List getFdwIdNotIn() {
		return fdwIdNotIn;
	}
	public void setFdwIdNotIn(java.util.List fdwIdNotIn) {
		this.fdwIdNotIn = fdwIdNotIn;
	}

	public Long getFdwIdNotEqualTo() {
		return fdwIdNotEqualTo;
	}
	public void setFdwIdNotEqualTo(Long fdwIdNotEqualTo) {
		this.fdwIdNotEqualTo = fdwIdNotEqualTo;
	}

	public Long getFdwIdLessThanOrEqualTo() {
		return fdwIdLessThanOrEqualTo;
	}
	public void setFdwIdLessThanOrEqualTo(Long fdwIdLessThanOrEqualTo) {
		this.fdwIdLessThanOrEqualTo = fdwIdLessThanOrEqualTo;
	}

	public Long getFdwIdLessThan() {
		return fdwIdLessThan;
	}
	public void setFdwIdLessThan(Long fdwIdLessThan) {
		this.fdwIdLessThan = fdwIdLessThan;
	}

	public Boolean getFdwIdIsNull() {
		return fdwIdIsNull;
	}
	public void setFdwIdIsNull(Boolean fdwIdIsNull) {
		this.fdwIdIsNull = fdwIdIsNull;
	}

	public Boolean getFdwIdIsNotNull() {
		return fdwIdIsNotNull;
	}
	public void setFdwIdIsNotNull(Boolean fdwIdIsNotNull) {
		this.fdwIdIsNotNull = fdwIdIsNotNull;
	}

	public java.util.List getFdwIdIn() {
		return fdwIdIn;
	}
	public void setFdwIdIn(java.util.List fdwIdIn) {
		this.fdwIdIn = fdwIdIn;
	}

	public Long getFdwIdGreaterThanOrEqualTo() {
		return fdwIdGreaterThanOrEqualTo;
	}
	public void setFdwIdGreaterThanOrEqualTo(Long fdwIdGreaterThanOrEqualTo) {
		this.fdwIdGreaterThanOrEqualTo = fdwIdGreaterThanOrEqualTo;
	}

	public Long getFdwIdGreaterThan() {
		return fdwIdGreaterThan;
	}
	public void setFdwIdGreaterThan(Long fdwIdGreaterThan) {
		this.fdwIdGreaterThan = fdwIdGreaterThan;
	}

	public Long getFdwIdEqualTo() {
		return fdwIdEqualTo;
	}
	public void setFdwIdEqualTo(Long fdwIdEqualTo) {
		this.fdwIdEqualTo = fdwIdEqualTo;
	}

	public String getFdwCarVinNotLike() {
		return fdwCarVinNotLike;
	}
	public void setFdwCarVinNotLike(String fdwCarVinNotLike) {
		this.fdwCarVinNotLike = fdwCarVinNotLike;
	}

	public java.util.List getFdwCarVinNotIn() {
		return fdwCarVinNotIn;
	}
	public void setFdwCarVinNotIn(java.util.List fdwCarVinNotIn) {
		this.fdwCarVinNotIn = fdwCarVinNotIn;
	}

	public String getFdwCarVinNotEqualTo() {
		return fdwCarVinNotEqualTo;
	}
	public void setFdwCarVinNotEqualTo(String fdwCarVinNotEqualTo) {
		this.fdwCarVinNotEqualTo = fdwCarVinNotEqualTo;
	}

	public String getFdwCarVinLike() {
		return fdwCarVinLike;
	}
	public void setFdwCarVinLike(String fdwCarVinLike) {
		this.fdwCarVinLike = fdwCarVinLike;
	}

	public String getFdwCarVinLessThanOrEqualTo() {
		return fdwCarVinLessThanOrEqualTo;
	}
	public void setFdwCarVinLessThanOrEqualTo(String fdwCarVinLessThanOrEqualTo) {
		this.fdwCarVinLessThanOrEqualTo = fdwCarVinLessThanOrEqualTo;
	}

	public String getFdwCarVinLessThan() {
		return fdwCarVinLessThan;
	}
	public void setFdwCarVinLessThan(String fdwCarVinLessThan) {
		this.fdwCarVinLessThan = fdwCarVinLessThan;
	}

	public Boolean getFdwCarVinIsNull() {
		return fdwCarVinIsNull;
	}
	public void setFdwCarVinIsNull(Boolean fdwCarVinIsNull) {
		this.fdwCarVinIsNull = fdwCarVinIsNull;
	}

	public Boolean getFdwCarVinIsNotNull() {
		return fdwCarVinIsNotNull;
	}
	public void setFdwCarVinIsNotNull(Boolean fdwCarVinIsNotNull) {
		this.fdwCarVinIsNotNull = fdwCarVinIsNotNull;
	}

	public java.util.List getFdwCarVinIn() {
		return fdwCarVinIn;
	}
	public void setFdwCarVinIn(java.util.List fdwCarVinIn) {
		this.fdwCarVinIn = fdwCarVinIn;
	}

	public String getFdwCarVinGreaterThanOrEqualTo() {
		return fdwCarVinGreaterThanOrEqualTo;
	}
	public void setFdwCarVinGreaterThanOrEqualTo(String fdwCarVinGreaterThanOrEqualTo) {
		this.fdwCarVinGreaterThanOrEqualTo = fdwCarVinGreaterThanOrEqualTo;
	}

	public String getFdwCarVinGreaterThan() {
		return fdwCarVinGreaterThan;
	}
	public void setFdwCarVinGreaterThan(String fdwCarVinGreaterThan) {
		this.fdwCarVinGreaterThan = fdwCarVinGreaterThan;
	}

	public String getFdwCarVinEqualTo() {
		return fdwCarVinEqualTo;
	}
	public void setFdwCarVinEqualTo(String fdwCarVinEqualTo) {
		this.fdwCarVinEqualTo = fdwCarVinEqualTo;
	}

	public String getFdwAccountNoNotLike() {
		return fdwAccountNoNotLike;
	}
	public void setFdwAccountNoNotLike(String fdwAccountNoNotLike) {
		this.fdwAccountNoNotLike = fdwAccountNoNotLike;
	}

	public java.util.List getFdwAccountNoNotIn() {
		return fdwAccountNoNotIn;
	}
	public void setFdwAccountNoNotIn(java.util.List fdwAccountNoNotIn) {
		this.fdwAccountNoNotIn = fdwAccountNoNotIn;
	}

	public String getFdwAccountNoNotEqualTo() {
		return fdwAccountNoNotEqualTo;
	}
	public void setFdwAccountNoNotEqualTo(String fdwAccountNoNotEqualTo) {
		this.fdwAccountNoNotEqualTo = fdwAccountNoNotEqualTo;
	}

	public String getFdwAccountNoLike() {
		return fdwAccountNoLike;
	}
	public void setFdwAccountNoLike(String fdwAccountNoLike) {
		this.fdwAccountNoLike = fdwAccountNoLike;
	}

	public String getFdwAccountNoLessThanOrEqualTo() {
		return fdwAccountNoLessThanOrEqualTo;
	}
	public void setFdwAccountNoLessThanOrEqualTo(String fdwAccountNoLessThanOrEqualTo) {
		this.fdwAccountNoLessThanOrEqualTo = fdwAccountNoLessThanOrEqualTo;
	}

	public String getFdwAccountNoLessThan() {
		return fdwAccountNoLessThan;
	}
	public void setFdwAccountNoLessThan(String fdwAccountNoLessThan) {
		this.fdwAccountNoLessThan = fdwAccountNoLessThan;
	}

	public Boolean getFdwAccountNoIsNull() {
		return fdwAccountNoIsNull;
	}
	public void setFdwAccountNoIsNull(Boolean fdwAccountNoIsNull) {
		this.fdwAccountNoIsNull = fdwAccountNoIsNull;
	}

	public Boolean getFdwAccountNoIsNotNull() {
		return fdwAccountNoIsNotNull;
	}
	public void setFdwAccountNoIsNotNull(Boolean fdwAccountNoIsNotNull) {
		this.fdwAccountNoIsNotNull = fdwAccountNoIsNotNull;
	}

	public java.util.List getFdwAccountNoIn() {
		return fdwAccountNoIn;
	}
	public void setFdwAccountNoIn(java.util.List fdwAccountNoIn) {
		this.fdwAccountNoIn = fdwAccountNoIn;
	}

	public String getFdwAccountNoGreaterThanOrEqualTo() {
		return fdwAccountNoGreaterThanOrEqualTo;
	}
	public void setFdwAccountNoGreaterThanOrEqualTo(String fdwAccountNoGreaterThanOrEqualTo) {
		this.fdwAccountNoGreaterThanOrEqualTo = fdwAccountNoGreaterThanOrEqualTo;
	}

	public String getFdwAccountNoGreaterThan() {
		return fdwAccountNoGreaterThan;
	}
	public void setFdwAccountNoGreaterThan(String fdwAccountNoGreaterThan) {
		this.fdwAccountNoGreaterThan = fdwAccountNoGreaterThan;
	}

	public String getFdwAccountNoEqualTo() {
		return fdwAccountNoEqualTo;
	}
	public void setFdwAccountNoEqualTo(String fdwAccountNoEqualTo) {
		this.fdwAccountNoEqualTo = fdwAccountNoEqualTo;
	}

	public String getFdwAccountDealFlowNotLike() {
		return fdwAccountDealFlowNotLike;
	}
	public void setFdwAccountDealFlowNotLike(String fdwAccountDealFlowNotLike) {
		this.fdwAccountDealFlowNotLike = fdwAccountDealFlowNotLike;
	}

	public java.util.List getFdwAccountDealFlowNotIn() {
		return fdwAccountDealFlowNotIn;
	}
	public void setFdwAccountDealFlowNotIn(java.util.List fdwAccountDealFlowNotIn) {
		this.fdwAccountDealFlowNotIn = fdwAccountDealFlowNotIn;
	}

	public String getFdwAccountDealFlowNotEqualTo() {
		return fdwAccountDealFlowNotEqualTo;
	}
	public void setFdwAccountDealFlowNotEqualTo(String fdwAccountDealFlowNotEqualTo) {
		this.fdwAccountDealFlowNotEqualTo = fdwAccountDealFlowNotEqualTo;
	}

	public String getFdwAccountDealFlowLike() {
		return fdwAccountDealFlowLike;
	}
	public void setFdwAccountDealFlowLike(String fdwAccountDealFlowLike) {
		this.fdwAccountDealFlowLike = fdwAccountDealFlowLike;
	}

	public String getFdwAccountDealFlowLessThanOrEqualTo() {
		return fdwAccountDealFlowLessThanOrEqualTo;
	}
	public void setFdwAccountDealFlowLessThanOrEqualTo(String fdwAccountDealFlowLessThanOrEqualTo) {
		this.fdwAccountDealFlowLessThanOrEqualTo = fdwAccountDealFlowLessThanOrEqualTo;
	}

	public String getFdwAccountDealFlowLessThan() {
		return fdwAccountDealFlowLessThan;
	}
	public void setFdwAccountDealFlowLessThan(String fdwAccountDealFlowLessThan) {
		this.fdwAccountDealFlowLessThan = fdwAccountDealFlowLessThan;
	}

	public Boolean getFdwAccountDealFlowIsNull() {
		return fdwAccountDealFlowIsNull;
	}
	public void setFdwAccountDealFlowIsNull(Boolean fdwAccountDealFlowIsNull) {
		this.fdwAccountDealFlowIsNull = fdwAccountDealFlowIsNull;
	}

	public Boolean getFdwAccountDealFlowIsNotNull() {
		return fdwAccountDealFlowIsNotNull;
	}
	public void setFdwAccountDealFlowIsNotNull(Boolean fdwAccountDealFlowIsNotNull) {
		this.fdwAccountDealFlowIsNotNull = fdwAccountDealFlowIsNotNull;
	}

	public java.util.List getFdwAccountDealFlowIn() {
		return fdwAccountDealFlowIn;
	}
	public void setFdwAccountDealFlowIn(java.util.List fdwAccountDealFlowIn) {
		this.fdwAccountDealFlowIn = fdwAccountDealFlowIn;
	}

	public String getFdwAccountDealFlowGreaterThanOrEqualTo() {
		return fdwAccountDealFlowGreaterThanOrEqualTo;
	}
	public void setFdwAccountDealFlowGreaterThanOrEqualTo(String fdwAccountDealFlowGreaterThanOrEqualTo) {
		this.fdwAccountDealFlowGreaterThanOrEqualTo = fdwAccountDealFlowGreaterThanOrEqualTo;
	}

	public String getFdwAccountDealFlowGreaterThan() {
		return fdwAccountDealFlowGreaterThan;
	}
	public void setFdwAccountDealFlowGreaterThan(String fdwAccountDealFlowGreaterThan) {
		this.fdwAccountDealFlowGreaterThan = fdwAccountDealFlowGreaterThan;
	}

	public String getFdwAccountDealFlowEqualTo() {
		return fdwAccountDealFlowEqualTo;
	}
	public void setFdwAccountDealFlowEqualTo(String fdwAccountDealFlowEqualTo) {
		this.fdwAccountDealFlowEqualTo = fdwAccountDealFlowEqualTo;
	}

	public java.util.List getDrNotIn() {
		return drNotIn;
	}
	public void setDrNotIn(java.util.List drNotIn) {
		this.drNotIn = drNotIn;
	}

	public Integer getDrNotEqualTo() {
		return drNotEqualTo;
	}
	public void setDrNotEqualTo(Integer drNotEqualTo) {
		this.drNotEqualTo = drNotEqualTo;
	}

	public Integer getDrLessThanOrEqualTo() {
		return drLessThanOrEqualTo;
	}
	public void setDrLessThanOrEqualTo(Integer drLessThanOrEqualTo) {
		this.drLessThanOrEqualTo = drLessThanOrEqualTo;
	}

	public Integer getDrLessThan() {
		return drLessThan;
	}
	public void setDrLessThan(Integer drLessThan) {
		this.drLessThan = drLessThan;
	}

	public Boolean getDrIsNull() {
		return drIsNull;
	}
	public void setDrIsNull(Boolean drIsNull) {
		this.drIsNull = drIsNull;
	}

	public Boolean getDrIsNotNull() {
		return drIsNotNull;
	}
	public void setDrIsNotNull(Boolean drIsNotNull) {
		this.drIsNotNull = drIsNotNull;
	}

	public java.util.List getDrIn() {
		return drIn;
	}
	public void setDrIn(java.util.List drIn) {
		this.drIn = drIn;
	}

	public Integer getDrGreaterThanOrEqualTo() {
		return drGreaterThanOrEqualTo;
	}
	public void setDrGreaterThanOrEqualTo(Integer drGreaterThanOrEqualTo) {
		this.drGreaterThanOrEqualTo = drGreaterThanOrEqualTo;
	}

	public Integer getDrGreaterThan() {
		return drGreaterThan;
	}
	public void setDrGreaterThan(Integer drGreaterThan) {
		this.drGreaterThan = drGreaterThan;
	}

	public Integer getDrEqualTo() {
		return drEqualTo;
	}
	public void setDrEqualTo(Integer drEqualTo) {
		this.drEqualTo = drEqualTo;
	}

	public String getCreateuserNotLike() {
		return createuserNotLike;
	}
	public void setCreateuserNotLike(String createuserNotLike) {
		this.createuserNotLike = createuserNotLike;
	}

	public java.util.List getCreateuserNotIn() {
		return createuserNotIn;
	}
	public void setCreateuserNotIn(java.util.List createuserNotIn) {
		this.createuserNotIn = createuserNotIn;
	}

	public String getCreateuserNotEqualTo() {
		return createuserNotEqualTo;
	}
	public void setCreateuserNotEqualTo(String createuserNotEqualTo) {
		this.createuserNotEqualTo = createuserNotEqualTo;
	}

	public String getCreateuserLike() {
		return createuserLike;
	}
	public void setCreateuserLike(String createuserLike) {
		this.createuserLike = createuserLike;
	}

	public String getCreateuserLessThanOrEqualTo() {
		return createuserLessThanOrEqualTo;
	}
	public void setCreateuserLessThanOrEqualTo(String createuserLessThanOrEqualTo) {
		this.createuserLessThanOrEqualTo = createuserLessThanOrEqualTo;
	}

	public String getCreateuserLessThan() {
		return createuserLessThan;
	}
	public void setCreateuserLessThan(String createuserLessThan) {
		this.createuserLessThan = createuserLessThan;
	}

	public Boolean getCreateuserIsNull() {
		return createuserIsNull;
	}
	public void setCreateuserIsNull(Boolean createuserIsNull) {
		this.createuserIsNull = createuserIsNull;
	}

	public Boolean getCreateuserIsNotNull() {
		return createuserIsNotNull;
	}
	public void setCreateuserIsNotNull(Boolean createuserIsNotNull) {
		this.createuserIsNotNull = createuserIsNotNull;
	}

	public java.util.List getCreateuserIn() {
		return createuserIn;
	}
	public void setCreateuserIn(java.util.List createuserIn) {
		this.createuserIn = createuserIn;
	}

	public String getCreateuserGreaterThanOrEqualTo() {
		return createuserGreaterThanOrEqualTo;
	}
	public void setCreateuserGreaterThanOrEqualTo(String createuserGreaterThanOrEqualTo) {
		this.createuserGreaterThanOrEqualTo = createuserGreaterThanOrEqualTo;
	}

	public String getCreateuserGreaterThan() {
		return createuserGreaterThan;
	}
	public void setCreateuserGreaterThan(String createuserGreaterThan) {
		this.createuserGreaterThan = createuserGreaterThan;
	}

	public String getCreateuserEqualTo() {
		return createuserEqualTo;
	}
	public void setCreateuserEqualTo(String createuserEqualTo) {
		this.createuserEqualTo = createuserEqualTo;
	}

	public java.util.List getCreatetimeNotIn() {
		return createtimeNotIn;
	}
	public void setCreatetimeNotIn(java.util.List createtimeNotIn) {
		this.createtimeNotIn = createtimeNotIn;
	}

	public java.util.Date getCreatetimeNotEqualTo() {
		return createtimeNotEqualTo;
	}
	public void setCreatetimeNotEqualTo(java.util.Date createtimeNotEqualTo) {
		this.createtimeNotEqualTo = createtimeNotEqualTo;
	}

	public java.util.Date getCreatetimeLessThanOrEqualTo() {
		return createtimeLessThanOrEqualTo;
	}
	public void setCreatetimeLessThanOrEqualTo(java.util.Date createtimeLessThanOrEqualTo) {
		this.createtimeLessThanOrEqualTo = createtimeLessThanOrEqualTo;
	}

	public java.util.Date getCreatetimeLessThan() {
		return createtimeLessThan;
	}
	public void setCreatetimeLessThan(java.util.Date createtimeLessThan) {
		this.createtimeLessThan = createtimeLessThan;
	}

	public Boolean getCreatetimeIsNull() {
		return createtimeIsNull;
	}
	public void setCreatetimeIsNull(Boolean createtimeIsNull) {
		this.createtimeIsNull = createtimeIsNull;
	}

	public Boolean getCreatetimeIsNotNull() {
		return createtimeIsNotNull;
	}
	public void setCreatetimeIsNotNull(Boolean createtimeIsNotNull) {
		this.createtimeIsNotNull = createtimeIsNotNull;
	}

	public java.util.List getCreatetimeIn() {
		return createtimeIn;
	}
	public void setCreatetimeIn(java.util.List createtimeIn) {
		this.createtimeIn = createtimeIn;
	}

	public java.util.Date getCreatetimeGreaterThanOrEqualTo() {
		return createtimeGreaterThanOrEqualTo;
	}
	public void setCreatetimeGreaterThanOrEqualTo(java.util.Date createtimeGreaterThanOrEqualTo) {
		this.createtimeGreaterThanOrEqualTo = createtimeGreaterThanOrEqualTo;
	}

	public java.util.Date getCreatetimeGreaterThan() {
		return createtimeGreaterThan;
	}
	public void setCreatetimeGreaterThan(java.util.Date createtimeGreaterThan) {
		this.createtimeGreaterThan = createtimeGreaterThan;
	}

	public java.util.Date getCreatetimeEqualTo() {
		return createtimeEqualTo;
	}
	public void setCreatetimeEqualTo(java.util.Date createtimeEqualTo) {
		this.createtimeEqualTo = createtimeEqualTo;
	}

	public void setSidx(String sidx) {
		this.sidx = sidx;
	}
	public String getSord() {
		return sord;
	}
	public void setSord(String sord) {
		 this.sord = sord;
	}
}
