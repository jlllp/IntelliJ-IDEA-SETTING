package com.mrk.finance.example;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

public class FncContractManagementExample {
    protected String orderByClause;

    protected boolean distinct;

    protected List<Criteria> oredCriteria;

    public FncContractManagementExample() {
        oredCriteria = new ArrayList<Criteria>();
    }

    public void setOrderByClause(String orderByClause) {
        this.orderByClause = orderByClause;
    }

    public String getOrderByClause() {
        return orderByClause;
    }

    public void setDistinct(boolean distinct) {
        this.distinct = distinct;
    }

    public boolean isDistinct() {
        return distinct;
    }

    public List<Criteria> getOredCriteria() {
        return oredCriteria;
    }

    public void or(Criteria criteria) {
        oredCriteria.add(criteria);
    }

    public Criteria or() {
        Criteria criteria = createCriteriaInternal();
        oredCriteria.add(criteria);
        return criteria;
    }

    public Criteria createCriteria() {
        Criteria criteria = createCriteriaInternal();
        if (oredCriteria.size() == 0) {
            oredCriteria.add(criteria);
        }
        return criteria;
    }

    protected Criteria createCriteriaInternal() {
        Criteria criteria = new Criteria();
        return criteria;
    }

    public void clear() {
        oredCriteria.clear();
        orderByClause = null;
        distinct = false;
    }

    protected abstract static class GeneratedCriteria {
        protected List<Criterion> criteria;

        protected GeneratedCriteria() {
            super();
            criteria = new ArrayList<Criterion>();
        }

        public boolean isValid() {
            return criteria.size() > 0;
        }

        public List<Criterion> getAllCriteria() {
            return criteria;
        }

        public List<Criterion> getCriteria() {
            return criteria;
        }

        protected void addCriterion(String condition) {
            if (condition == null) {
                throw new RuntimeException("Value for condition cannot be null");
            }
            criteria.add(new Criterion(condition));
        }

        protected void addCriterion(String condition, Object value, String property) {
            if (value == null) {
                throw new RuntimeException("Value for " + property + " cannot be null");
            }
            criteria.add(new Criterion(condition, value));
        }

        protected void addCriterion(String condition, Object value1, Object value2, String property) {
            if (value1 == null || value2 == null) {
                throw new RuntimeException("Between values for " + property + " cannot be null");
            }
            criteria.add(new Criterion(condition, value1, value2));
        }

        public Criteria andFcmIdIsNull() {
            addCriterion("fcm_id is null");
            return (Criteria) this;
        }

        public Criteria andFcmIdIsNotNull() {
            addCriterion("fcm_id is not null");
            return (Criteria) this;
        }

        public Criteria andFcmIdEqualTo(Long value) {
            addCriterion("fcm_id =", value, "fcmId");
            return (Criteria) this;
        }

        public Criteria andFcmIdNotEqualTo(Long value) {
            addCriterion("fcm_id <>", value, "fcmId");
            return (Criteria) this;
        }

        public Criteria andFcmIdGreaterThan(Long value) {
            addCriterion("fcm_id >", value, "fcmId");
            return (Criteria) this;
        }

        public Criteria andFcmIdGreaterThanOrEqualTo(Long value) {
            addCriterion("fcm_id >=", value, "fcmId");
            return (Criteria) this;
        }

        public Criteria andFcmIdLessThan(Long value) {
            addCriterion("fcm_id <", value, "fcmId");
            return (Criteria) this;
        }

        public Criteria andFcmIdLessThanOrEqualTo(Long value) {
            addCriterion("fcm_id <=", value, "fcmId");
            return (Criteria) this;
        }

        public Criteria andFcmIdIn(List<Long> values) {
            addCriterion("fcm_id in", values, "fcmId");
            return (Criteria) this;
        }

        public Criteria andFcmIdNotIn(List<Long> values) {
            addCriterion("fcm_id not in", values, "fcmId");
            return (Criteria) this;
        }

        public Criteria andFcmIdBetween(Long value1, Long value2) {
            addCriterion("fcm_id between", value1, value2, "fcmId");
            return (Criteria) this;
        }

        public Criteria andFcmIdNotBetween(Long value1, Long value2) {
            addCriterion("fcm_id not between", value1, value2, "fcmId");
            return (Criteria) this;
        }

        public Criteria andFcmCityIdIsNull() {
            addCriterion("fcm_city_id is null");
            return (Criteria) this;
        }

        public Criteria andFcmCityIdIsNotNull() {
            addCriterion("fcm_city_id is not null");
            return (Criteria) this;
        }

        public Criteria andFcmCityIdEqualTo(Long value) {
            addCriterion("fcm_city_id =", value, "fcmCityId");
            return (Criteria) this;
        }

        public Criteria andFcmCityIdNotEqualTo(Long value) {
            addCriterion("fcm_city_id <>", value, "fcmCityId");
            return (Criteria) this;
        }

        public Criteria andFcmCityIdGreaterThan(Long value) {
            addCriterion("fcm_city_id >", value, "fcmCityId");
            return (Criteria) this;
        }

        public Criteria andFcmCityIdGreaterThanOrEqualTo(Long value) {
            addCriterion("fcm_city_id >=", value, "fcmCityId");
            return (Criteria) this;
        }

        public Criteria andFcmCityIdLessThan(Long value) {
            addCriterion("fcm_city_id <", value, "fcmCityId");
            return (Criteria) this;
        }

        public Criteria andFcmCityIdLessThanOrEqualTo(Long value) {
            addCriterion("fcm_city_id <=", value, "fcmCityId");
            return (Criteria) this;
        }

        public Criteria andFcmCityIdIn(List<Long> values) {
            addCriterion("fcm_city_id in", values, "fcmCityId");
            return (Criteria) this;
        }

        public Criteria andFcmCityIdNotIn(List<Long> values) {
            addCriterion("fcm_city_id not in", values, "fcmCityId");
            return (Criteria) this;
        }

        public Criteria andFcmCityIdBetween(Long value1, Long value2) {
            addCriterion("fcm_city_id between", value1, value2, "fcmCityId");
            return (Criteria) this;
        }

        public Criteria andFcmCityIdNotBetween(Long value1, Long value2) {
            addCriterion("fcm_city_id not between", value1, value2, "fcmCityId");
            return (Criteria) this;
        }

        public Criteria andFcmContractTypeIsNull() {
            addCriterion("fcm_contract_type is null");
            return (Criteria) this;
        }

        public Criteria andFcmContractTypeIsNotNull() {
            addCriterion("fcm_contract_type is not null");
            return (Criteria) this;
        }

        public Criteria andFcmContractTypeEqualTo(Integer value) {
            addCriterion("fcm_contract_type =", value, "fcmContractType");
            return (Criteria) this;
        }

        public Criteria andFcmContractTypeNotEqualTo(Integer value) {
            addCriterion("fcm_contract_type <>", value, "fcmContractType");
            return (Criteria) this;
        }

        public Criteria andFcmContractTypeGreaterThan(Integer value) {
            addCriterion("fcm_contract_type >", value, "fcmContractType");
            return (Criteria) this;
        }

        public Criteria andFcmContractTypeGreaterThanOrEqualTo(Integer value) {
            addCriterion("fcm_contract_type >=", value, "fcmContractType");
            return (Criteria) this;
        }

        public Criteria andFcmContractTypeLessThan(Integer value) {
            addCriterion("fcm_contract_type <", value, "fcmContractType");
            return (Criteria) this;
        }

        public Criteria andFcmContractTypeLessThanOrEqualTo(Integer value) {
            addCriterion("fcm_contract_type <=", value, "fcmContractType");
            return (Criteria) this;
        }

        public Criteria andFcmContractTypeIn(List<Integer> values) {
            addCriterion("fcm_contract_type in", values, "fcmContractType");
            return (Criteria) this;
        }

        public Criteria andFcmContractTypeNotIn(List<Integer> values) {
            addCriterion("fcm_contract_type not in", values, "fcmContractType");
            return (Criteria) this;
        }

        public Criteria andFcmContractTypeBetween(Integer value1, Integer value2) {
            addCriterion("fcm_contract_type between", value1, value2, "fcmContractType");
            return (Criteria) this;
        }

        public Criteria andFcmContractTypeNotBetween(Integer value1, Integer value2) {
            addCriterion("fcm_contract_type not between", value1, value2, "fcmContractType");
            return (Criteria) this;
        }

        public Criteria andFcmContractNoIsNull() {
            addCriterion("fcm_contract_no is null");
            return (Criteria) this;
        }

        public Criteria andFcmContractNoIsNotNull() {
            addCriterion("fcm_contract_no is not null");
            return (Criteria) this;
        }

        public Criteria andFcmContractNoEqualTo(String value) {
            addCriterion("fcm_contract_no =", value, "fcmContractNo");
            return (Criteria) this;
        }

        public Criteria andFcmContractNoNotEqualTo(String value) {
            addCriterion("fcm_contract_no <>", value, "fcmContractNo");
            return (Criteria) this;
        }

        public Criteria andFcmContractNoGreaterThan(String value) {
            addCriterion("fcm_contract_no >", value, "fcmContractNo");
            return (Criteria) this;
        }

        public Criteria andFcmContractNoGreaterThanOrEqualTo(String value) {
            addCriterion("fcm_contract_no >=", value, "fcmContractNo");
            return (Criteria) this;
        }

        public Criteria andFcmContractNoLessThan(String value) {
            addCriterion("fcm_contract_no <", value, "fcmContractNo");
            return (Criteria) this;
        }

        public Criteria andFcmContractNoLessThanOrEqualTo(String value) {
            addCriterion("fcm_contract_no <=", value, "fcmContractNo");
            return (Criteria) this;
        }

        public Criteria andFcmContractNoLike(String value) {
            addCriterion("fcm_contract_no like", value, "fcmContractNo");
            return (Criteria) this;
        }

        public Criteria andFcmContractNoNotLike(String value) {
            addCriterion("fcm_contract_no not like", value, "fcmContractNo");
            return (Criteria) this;
        }

        public Criteria andFcmContractNoIn(List<String> values) {
            addCriterion("fcm_contract_no in", values, "fcmContractNo");
            return (Criteria) this;
        }

        public Criteria andFcmContractNoNotIn(List<String> values) {
            addCriterion("fcm_contract_no not in", values, "fcmContractNo");
            return (Criteria) this;
        }

        public Criteria andFcmContractNoBetween(String value1, String value2) {
            addCriterion("fcm_contract_no between", value1, value2, "fcmContractNo");
            return (Criteria) this;
        }

        public Criteria andFcmContractNoNotBetween(String value1, String value2) {
            addCriterion("fcm_contract_no not between", value1, value2, "fcmContractNo");
            return (Criteria) this;
        }

        public Criteria andFcmPartyaTypeIsNull() {
            addCriterion("fcm_partya_type is null");
            return (Criteria) this;
        }

        public Criteria andFcmPartyaTypeIsNotNull() {
            addCriterion("fcm_partya_type is not null");
            return (Criteria) this;
        }

        public Criteria andFcmPartyaTypeEqualTo(Integer value) {
            addCriterion("fcm_partya_type =", value, "fcmPartyaType");
            return (Criteria) this;
        }

        public Criteria andFcmPartyaTypeNotEqualTo(Integer value) {
            addCriterion("fcm_partya_type <>", value, "fcmPartyaType");
            return (Criteria) this;
        }

        public Criteria andFcmPartyaTypeGreaterThan(Integer value) {
            addCriterion("fcm_partya_type >", value, "fcmPartyaType");
            return (Criteria) this;
        }

        public Criteria andFcmPartyaTypeGreaterThanOrEqualTo(Integer value) {
            addCriterion("fcm_partya_type >=", value, "fcmPartyaType");
            return (Criteria) this;
        }

        public Criteria andFcmPartyaTypeLessThan(Integer value) {
            addCriterion("fcm_partya_type <", value, "fcmPartyaType");
            return (Criteria) this;
        }

        public Criteria andFcmPartyaTypeLessThanOrEqualTo(Integer value) {
            addCriterion("fcm_partya_type <=", value, "fcmPartyaType");
            return (Criteria) this;
        }

        public Criteria andFcmPartyaTypeIn(List<Integer> values) {
            addCriterion("fcm_partya_type in", values, "fcmPartyaType");
            return (Criteria) this;
        }

        public Criteria andFcmPartyaTypeNotIn(List<Integer> values) {
            addCriterion("fcm_partya_type not in", values, "fcmPartyaType");
            return (Criteria) this;
        }

        public Criteria andFcmPartyaTypeBetween(Integer value1, Integer value2) {
            addCriterion("fcm_partya_type between", value1, value2, "fcmPartyaType");
            return (Criteria) this;
        }

        public Criteria andFcmPartyaTypeNotBetween(Integer value1, Integer value2) {
            addCriterion("fcm_partya_type not between", value1, value2, "fcmPartyaType");
            return (Criteria) this;
        }

        public Criteria andFcmPartyaIdIsNull() {
            addCriterion("fcm_partya_id is null");
            return (Criteria) this;
        }

        public Criteria andFcmPartyaIdIsNotNull() {
            addCriterion("fcm_partya_id is not null");
            return (Criteria) this;
        }

        public Criteria andFcmPartyaIdEqualTo(Long value) {
            addCriterion("fcm_partya_id =", value, "fcmPartyaId");
            return (Criteria) this;
        }

        public Criteria andFcmPartyaIdNotEqualTo(Long value) {
            addCriterion("fcm_partya_id <>", value, "fcmPartyaId");
            return (Criteria) this;
        }

        public Criteria andFcmPartyaIdGreaterThan(Long value) {
            addCriterion("fcm_partya_id >", value, "fcmPartyaId");
            return (Criteria) this;
        }

        public Criteria andFcmPartyaIdGreaterThanOrEqualTo(Long value) {
            addCriterion("fcm_partya_id >=", value, "fcmPartyaId");
            return (Criteria) this;
        }

        public Criteria andFcmPartyaIdLessThan(Long value) {
            addCriterion("fcm_partya_id <", value, "fcmPartyaId");
            return (Criteria) this;
        }

        public Criteria andFcmPartyaIdLessThanOrEqualTo(Long value) {
            addCriterion("fcm_partya_id <=", value, "fcmPartyaId");
            return (Criteria) this;
        }

        public Criteria andFcmPartyaIdIn(List<Long> values) {
            addCriterion("fcm_partya_id in", values, "fcmPartyaId");
            return (Criteria) this;
        }

        public Criteria andFcmPartyaIdNotIn(List<Long> values) {
            addCriterion("fcm_partya_id not in", values, "fcmPartyaId");
            return (Criteria) this;
        }

        public Criteria andFcmPartyaIdBetween(Long value1, Long value2) {
            addCriterion("fcm_partya_id between", value1, value2, "fcmPartyaId");
            return (Criteria) this;
        }

        public Criteria andFcmPartyaIdNotBetween(Long value1, Long value2) {
            addCriterion("fcm_partya_id not between", value1, value2, "fcmPartyaId");
            return (Criteria) this;
        }

        public Criteria andFcmPartybTypeIsNull() {
            addCriterion("fcm_partyb_type is null");
            return (Criteria) this;
        }

        public Criteria andFcmPartybTypeIsNotNull() {
            addCriterion("fcm_partyb_type is not null");
            return (Criteria) this;
        }

        public Criteria andFcmPartybTypeEqualTo(Integer value) {
            addCriterion("fcm_partyb_type =", value, "fcmPartybType");
            return (Criteria) this;
        }

        public Criteria andFcmPartybTypeNotEqualTo(Integer value) {
            addCriterion("fcm_partyb_type <>", value, "fcmPartybType");
            return (Criteria) this;
        }

        public Criteria andFcmPartybTypeGreaterThan(Integer value) {
            addCriterion("fcm_partyb_type >", value, "fcmPartybType");
            return (Criteria) this;
        }

        public Criteria andFcmPartybTypeGreaterThanOrEqualTo(Integer value) {
            addCriterion("fcm_partyb_type >=", value, "fcmPartybType");
            return (Criteria) this;
        }

        public Criteria andFcmPartybTypeLessThan(Integer value) {
            addCriterion("fcm_partyb_type <", value, "fcmPartybType");
            return (Criteria) this;
        }

        public Criteria andFcmPartybTypeLessThanOrEqualTo(Integer value) {
            addCriterion("fcm_partyb_type <=", value, "fcmPartybType");
            return (Criteria) this;
        }

        public Criteria andFcmPartybTypeIn(List<Integer> values) {
            addCriterion("fcm_partyb_type in", values, "fcmPartybType");
            return (Criteria) this;
        }

        public Criteria andFcmPartybTypeNotIn(List<Integer> values) {
            addCriterion("fcm_partyb_type not in", values, "fcmPartybType");
            return (Criteria) this;
        }

        public Criteria andFcmPartybTypeBetween(Integer value1, Integer value2) {
            addCriterion("fcm_partyb_type between", value1, value2, "fcmPartybType");
            return (Criteria) this;
        }

        public Criteria andFcmPartybTypeNotBetween(Integer value1, Integer value2) {
            addCriterion("fcm_partyb_type not between", value1, value2, "fcmPartybType");
            return (Criteria) this;
        }

        public Criteria andFcmPartybIdIsNull() {
            addCriterion("fcm_partyb_id is null");
            return (Criteria) this;
        }

        public Criteria andFcmPartybIdIsNotNull() {
            addCriterion("fcm_partyb_id is not null");
            return (Criteria) this;
        }

        public Criteria andFcmPartybIdEqualTo(Long value) {
            addCriterion("fcm_partyb_id =", value, "fcmPartybId");
            return (Criteria) this;
        }

        public Criteria andFcmPartybIdNotEqualTo(Long value) {
            addCriterion("fcm_partyb_id <>", value, "fcmPartybId");
            return (Criteria) this;
        }

        public Criteria andFcmPartybIdGreaterThan(Long value) {
            addCriterion("fcm_partyb_id >", value, "fcmPartybId");
            return (Criteria) this;
        }

        public Criteria andFcmPartybIdGreaterThanOrEqualTo(Long value) {
            addCriterion("fcm_partyb_id >=", value, "fcmPartybId");
            return (Criteria) this;
        }

        public Criteria andFcmPartybIdLessThan(Long value) {
            addCriterion("fcm_partyb_id <", value, "fcmPartybId");
            return (Criteria) this;
        }

        public Criteria andFcmPartybIdLessThanOrEqualTo(Long value) {
            addCriterion("fcm_partyb_id <=", value, "fcmPartybId");
            return (Criteria) this;
        }

        public Criteria andFcmPartybIdIn(List<Long> values) {
            addCriterion("fcm_partyb_id in", values, "fcmPartybId");
            return (Criteria) this;
        }

        public Criteria andFcmPartybIdNotIn(List<Long> values) {
            addCriterion("fcm_partyb_id not in", values, "fcmPartybId");
            return (Criteria) this;
        }

        public Criteria andFcmPartybIdBetween(Long value1, Long value2) {
            addCriterion("fcm_partyb_id between", value1, value2, "fcmPartybId");
            return (Criteria) this;
        }

        public Criteria andFcmPartybIdNotBetween(Long value1, Long value2) {
            addCriterion("fcm_partyb_id not between", value1, value2, "fcmPartybId");
            return (Criteria) this;
        }

        public Criteria andFcmCarTypeIdIsNull() {
            addCriterion("fcm_car_type_id is null");
            return (Criteria) this;
        }

        public Criteria andFcmCarTypeIdIsNotNull() {
            addCriterion("fcm_car_type_id is not null");
            return (Criteria) this;
        }

        public Criteria andFcmCarTypeIdEqualTo(Long value) {
            addCriterion("fcm_car_type_id =", value, "fcmCarTypeId");
            return (Criteria) this;
        }

        public Criteria andFcmCarTypeIdNotEqualTo(Long value) {
            addCriterion("fcm_car_type_id <>", value, "fcmCarTypeId");
            return (Criteria) this;
        }

        public Criteria andFcmCarTypeIdGreaterThan(Long value) {
            addCriterion("fcm_car_type_id >", value, "fcmCarTypeId");
            return (Criteria) this;
        }

        public Criteria andFcmCarTypeIdGreaterThanOrEqualTo(Long value) {
            addCriterion("fcm_car_type_id >=", value, "fcmCarTypeId");
            return (Criteria) this;
        }

        public Criteria andFcmCarTypeIdLessThan(Long value) {
            addCriterion("fcm_car_type_id <", value, "fcmCarTypeId");
            return (Criteria) this;
        }

        public Criteria andFcmCarTypeIdLessThanOrEqualTo(Long value) {
            addCriterion("fcm_car_type_id <=", value, "fcmCarTypeId");
            return (Criteria) this;
        }

        public Criteria andFcmCarTypeIdIn(List<Long> values) {
            addCriterion("fcm_car_type_id in", values, "fcmCarTypeId");
            return (Criteria) this;
        }

        public Criteria andFcmCarTypeIdNotIn(List<Long> values) {
            addCriterion("fcm_car_type_id not in", values, "fcmCarTypeId");
            return (Criteria) this;
        }

        public Criteria andFcmCarTypeIdBetween(Long value1, Long value2) {
            addCriterion("fcm_car_type_id between", value1, value2, "fcmCarTypeId");
            return (Criteria) this;
        }

        public Criteria andFcmCarTypeIdNotBetween(Long value1, Long value2) {
            addCriterion("fcm_car_type_id not between", value1, value2, "fcmCarTypeId");
            return (Criteria) this;
        }

        public Criteria andFcmOperatPlatformIsNull() {
            addCriterion("fcm_operat_platform is null");
            return (Criteria) this;
        }

        public Criteria andFcmOperatPlatformIsNotNull() {
            addCriterion("fcm_operat_platform is not null");
            return (Criteria) this;
        }

        public Criteria andFcmOperatPlatformEqualTo(Integer value) {
            addCriterion("fcm_operat_platform =", value, "fcmOperatPlatform");
            return (Criteria) this;
        }

        public Criteria andFcmOperatPlatformNotEqualTo(Integer value) {
            addCriterion("fcm_operat_platform <>", value, "fcmOperatPlatform");
            return (Criteria) this;
        }

        public Criteria andFcmOperatPlatformGreaterThan(Integer value) {
            addCriterion("fcm_operat_platform >", value, "fcmOperatPlatform");
            return (Criteria) this;
        }

        public Criteria andFcmOperatPlatformGreaterThanOrEqualTo(Integer value) {
            addCriterion("fcm_operat_platform >=", value, "fcmOperatPlatform");
            return (Criteria) this;
        }

        public Criteria andFcmOperatPlatformLessThan(Integer value) {
            addCriterion("fcm_operat_platform <", value, "fcmOperatPlatform");
            return (Criteria) this;
        }

        public Criteria andFcmOperatPlatformLessThanOrEqualTo(Integer value) {
            addCriterion("fcm_operat_platform <=", value, "fcmOperatPlatform");
            return (Criteria) this;
        }

        public Criteria andFcmOperatPlatformIn(List<Integer> values) {
            addCriterion("fcm_operat_platform in", values, "fcmOperatPlatform");
            return (Criteria) this;
        }

        public Criteria andFcmOperatPlatformNotIn(List<Integer> values) {
            addCriterion("fcm_operat_platform not in", values, "fcmOperatPlatform");
            return (Criteria) this;
        }

        public Criteria andFcmOperatPlatformBetween(Integer value1, Integer value2) {
            addCriterion("fcm_operat_platform between", value1, value2, "fcmOperatPlatform");
            return (Criteria) this;
        }

        public Criteria andFcmOperatPlatformNotBetween(Integer value1, Integer value2) {
            addCriterion("fcm_operat_platform not between", value1, value2, "fcmOperatPlatform");
            return (Criteria) this;
        }

        public Criteria andFcmSignedDateIsNull() {
            addCriterion("fcm_signed_date is null");
            return (Criteria) this;
        }

        public Criteria andFcmSignedDateIsNotNull() {
            addCriterion("fcm_signed_date is not null");
            return (Criteria) this;
        }

        public Criteria andFcmSignedDateEqualTo(Date value) {
            addCriterion("fcm_signed_date =", value, "fcmSignedDate");
            return (Criteria) this;
        }

        public Criteria andFcmSignedDateNotEqualTo(Date value) {
            addCriterion("fcm_signed_date <>", value, "fcmSignedDate");
            return (Criteria) this;
        }

        public Criteria andFcmSignedDateGreaterThan(Date value) {
            addCriterion("fcm_signed_date >", value, "fcmSignedDate");
            return (Criteria) this;
        }

        public Criteria andFcmSignedDateGreaterThanOrEqualTo(Date value) {
            addCriterion("fcm_signed_date >=", value, "fcmSignedDate");
            return (Criteria) this;
        }

        public Criteria andFcmSignedDateLessThan(Date value) {
            addCriterion("fcm_signed_date <", value, "fcmSignedDate");
            return (Criteria) this;
        }

        public Criteria andFcmSignedDateLessThanOrEqualTo(Date value) {
            addCriterion("fcm_signed_date <=", value, "fcmSignedDate");
            return (Criteria) this;
        }

        public Criteria andFcmSignedDateIn(List<Date> values) {
            addCriterion("fcm_signed_date in", values, "fcmSignedDate");
            return (Criteria) this;
        }

        public Criteria andFcmSignedDateNotIn(List<Date> values) {
            addCriterion("fcm_signed_date not in", values, "fcmSignedDate");
            return (Criteria) this;
        }

        public Criteria andFcmSignedDateBetween(Date value1, Date value2) {
            addCriterion("fcm_signed_date between", value1, value2, "fcmSignedDate");
            return (Criteria) this;
        }

        public Criteria andFcmSignedDateNotBetween(Date value1, Date value2) {
            addCriterion("fcm_signed_date not between", value1, value2, "fcmSignedDate");
            return (Criteria) this;
        }

        public Criteria andFcmLeaseCalculateTypeIsNull() {
            addCriterion("fcm_lease_calculate_type is null");
            return (Criteria) this;
        }

        public Criteria andFcmLeaseCalculateTypeIsNotNull() {
            addCriterion("fcm_lease_calculate_type is not null");
            return (Criteria) this;
        }

        public Criteria andFcmLeaseCalculateTypeEqualTo(Integer value) {
            addCriterion("fcm_lease_calculate_type =", value, "fcmLeaseCalculateType");
            return (Criteria) this;
        }

        public Criteria andFcmLeaseCalculateTypeNotEqualTo(Integer value) {
            addCriterion("fcm_lease_calculate_type <>", value, "fcmLeaseCalculateType");
            return (Criteria) this;
        }

        public Criteria andFcmLeaseCalculateTypeGreaterThan(Integer value) {
            addCriterion("fcm_lease_calculate_type >", value, "fcmLeaseCalculateType");
            return (Criteria) this;
        }

        public Criteria andFcmLeaseCalculateTypeGreaterThanOrEqualTo(Integer value) {
            addCriterion("fcm_lease_calculate_type >=", value, "fcmLeaseCalculateType");
            return (Criteria) this;
        }

        public Criteria andFcmLeaseCalculateTypeLessThan(Integer value) {
            addCriterion("fcm_lease_calculate_type <", value, "fcmLeaseCalculateType");
            return (Criteria) this;
        }

        public Criteria andFcmLeaseCalculateTypeLessThanOrEqualTo(Integer value) {
            addCriterion("fcm_lease_calculate_type <=", value, "fcmLeaseCalculateType");
            return (Criteria) this;
        }

        public Criteria andFcmLeaseCalculateTypeIn(List<Integer> values) {
            addCriterion("fcm_lease_calculate_type in", values, "fcmLeaseCalculateType");
            return (Criteria) this;
        }

        public Criteria andFcmLeaseCalculateTypeNotIn(List<Integer> values) {
            addCriterion("fcm_lease_calculate_type not in", values, "fcmLeaseCalculateType");
            return (Criteria) this;
        }

        public Criteria andFcmLeaseCalculateTypeBetween(Integer value1, Integer value2) {
            addCriterion("fcm_lease_calculate_type between", value1, value2, "fcmLeaseCalculateType");
            return (Criteria) this;
        }

        public Criteria andFcmLeaseCalculateTypeNotBetween(Integer value1, Integer value2) {
            addCriterion("fcm_lease_calculate_type not between", value1, value2, "fcmLeaseCalculateType");
            return (Criteria) this;
        }

        public Criteria andFcmLeaseCountIsNull() {
            addCriterion("fcm_lease_count is null");
            return (Criteria) this;
        }

        public Criteria andFcmLeaseCountIsNotNull() {
            addCriterion("fcm_lease_count is not null");
            return (Criteria) this;
        }

        public Criteria andFcmLeaseCountEqualTo(Integer value) {
            addCriterion("fcm_lease_count =", value, "fcmLeaseCount");
            return (Criteria) this;
        }

        public Criteria andFcmLeaseCountNotEqualTo(Integer value) {
            addCriterion("fcm_lease_count <>", value, "fcmLeaseCount");
            return (Criteria) this;
        }

        public Criteria andFcmLeaseCountGreaterThan(Integer value) {
            addCriterion("fcm_lease_count >", value, "fcmLeaseCount");
            return (Criteria) this;
        }

        public Criteria andFcmLeaseCountGreaterThanOrEqualTo(Integer value) {
            addCriterion("fcm_lease_count >=", value, "fcmLeaseCount");
            return (Criteria) this;
        }

        public Criteria andFcmLeaseCountLessThan(Integer value) {
            addCriterion("fcm_lease_count <", value, "fcmLeaseCount");
            return (Criteria) this;
        }

        public Criteria andFcmLeaseCountLessThanOrEqualTo(Integer value) {
            addCriterion("fcm_lease_count <=", value, "fcmLeaseCount");
            return (Criteria) this;
        }

        public Criteria andFcmLeaseCountIn(List<Integer> values) {
            addCriterion("fcm_lease_count in", values, "fcmLeaseCount");
            return (Criteria) this;
        }

        public Criteria andFcmLeaseCountNotIn(List<Integer> values) {
            addCriterion("fcm_lease_count not in", values, "fcmLeaseCount");
            return (Criteria) this;
        }

        public Criteria andFcmLeaseCountBetween(Integer value1, Integer value2) {
            addCriterion("fcm_lease_count between", value1, value2, "fcmLeaseCount");
            return (Criteria) this;
        }

        public Criteria andFcmLeaseCountNotBetween(Integer value1, Integer value2) {
            addCriterion("fcm_lease_count not between", value1, value2, "fcmLeaseCount");
            return (Criteria) this;
        }

        public Criteria andFcmLeaseStartTypeIsNull() {
            addCriterion("fcm_lease_start_type is null");
            return (Criteria) this;
        }

        public Criteria andFcmLeaseStartTypeIsNotNull() {
            addCriterion("fcm_lease_start_type is not null");
            return (Criteria) this;
        }

        public Criteria andFcmLeaseStartTypeEqualTo(Integer value) {
            addCriterion("fcm_lease_start_type =", value, "fcmLeaseStartType");
            return (Criteria) this;
        }

        public Criteria andFcmLeaseStartTypeNotEqualTo(Integer value) {
            addCriterion("fcm_lease_start_type <>", value, "fcmLeaseStartType");
            return (Criteria) this;
        }

        public Criteria andFcmLeaseStartTypeGreaterThan(Integer value) {
            addCriterion("fcm_lease_start_type >", value, "fcmLeaseStartType");
            return (Criteria) this;
        }

        public Criteria andFcmLeaseStartTypeGreaterThanOrEqualTo(Integer value) {
            addCriterion("fcm_lease_start_type >=", value, "fcmLeaseStartType");
            return (Criteria) this;
        }

        public Criteria andFcmLeaseStartTypeLessThan(Integer value) {
            addCriterion("fcm_lease_start_type <", value, "fcmLeaseStartType");
            return (Criteria) this;
        }

        public Criteria andFcmLeaseStartTypeLessThanOrEqualTo(Integer value) {
            addCriterion("fcm_lease_start_type <=", value, "fcmLeaseStartType");
            return (Criteria) this;
        }

        public Criteria andFcmLeaseStartTypeIn(List<Integer> values) {
            addCriterion("fcm_lease_start_type in", values, "fcmLeaseStartType");
            return (Criteria) this;
        }

        public Criteria andFcmLeaseStartTypeNotIn(List<Integer> values) {
            addCriterion("fcm_lease_start_type not in", values, "fcmLeaseStartType");
            return (Criteria) this;
        }

        public Criteria andFcmLeaseStartTypeBetween(Integer value1, Integer value2) {
            addCriterion("fcm_lease_start_type between", value1, value2, "fcmLeaseStartType");
            return (Criteria) this;
        }

        public Criteria andFcmLeaseStartTypeNotBetween(Integer value1, Integer value2) {
            addCriterion("fcm_lease_start_type not between", value1, value2, "fcmLeaseStartType");
            return (Criteria) this;
        }

        public Criteria andFcmLeaseStartDateIsNull() {
            addCriterion("fcm_lease_start_date is null");
            return (Criteria) this;
        }

        public Criteria andFcmLeaseStartDateIsNotNull() {
            addCriterion("fcm_lease_start_date is not null");
            return (Criteria) this;
        }

        public Criteria andFcmLeaseStartDateEqualTo(Date value) {
            addCriterion("fcm_lease_start_date =", value, "fcmLeaseStartDate");
            return (Criteria) this;
        }

        public Criteria andFcmLeaseStartDateNotEqualTo(Date value) {
            addCriterion("fcm_lease_start_date <>", value, "fcmLeaseStartDate");
            return (Criteria) this;
        }

        public Criteria andFcmLeaseStartDateGreaterThan(Date value) {
            addCriterion("fcm_lease_start_date >", value, "fcmLeaseStartDate");
            return (Criteria) this;
        }

        public Criteria andFcmLeaseStartDateGreaterThanOrEqualTo(Date value) {
            addCriterion("fcm_lease_start_date >=", value, "fcmLeaseStartDate");
            return (Criteria) this;
        }

        public Criteria andFcmLeaseStartDateLessThan(Date value) {
            addCriterion("fcm_lease_start_date <", value, "fcmLeaseStartDate");
            return (Criteria) this;
        }

        public Criteria andFcmLeaseStartDateLessThanOrEqualTo(Date value) {
            addCriterion("fcm_lease_start_date <=", value, "fcmLeaseStartDate");
            return (Criteria) this;
        }

        public Criteria andFcmLeaseStartDateIn(List<Date> values) {
            addCriterion("fcm_lease_start_date in", values, "fcmLeaseStartDate");
            return (Criteria) this;
        }

        public Criteria andFcmLeaseStartDateNotIn(List<Date> values) {
            addCriterion("fcm_lease_start_date not in", values, "fcmLeaseStartDate");
            return (Criteria) this;
        }

        public Criteria andFcmLeaseStartDateBetween(Date value1, Date value2) {
            addCriterion("fcm_lease_start_date between", value1, value2, "fcmLeaseStartDate");
            return (Criteria) this;
        }

        public Criteria andFcmLeaseStartDateNotBetween(Date value1, Date value2) {
            addCriterion("fcm_lease_start_date not between", value1, value2, "fcmLeaseStartDate");
            return (Criteria) this;
        }

        public Criteria andFcmLeaseEndDateIsNull() {
            addCriterion("fcm_lease_end_date is null");
            return (Criteria) this;
        }

        public Criteria andFcmLeaseEndDateIsNotNull() {
            addCriterion("fcm_lease_end_date is not null");
            return (Criteria) this;
        }

        public Criteria andFcmLeaseEndDateEqualTo(Date value) {
            addCriterion("fcm_lease_end_date =", value, "fcmLeaseEndDate");
            return (Criteria) this;
        }

        public Criteria andFcmLeaseEndDateNotEqualTo(Date value) {
            addCriterion("fcm_lease_end_date <>", value, "fcmLeaseEndDate");
            return (Criteria) this;
        }

        public Criteria andFcmLeaseEndDateGreaterThan(Date value) {
            addCriterion("fcm_lease_end_date >", value, "fcmLeaseEndDate");
            return (Criteria) this;
        }

        public Criteria andFcmLeaseEndDateGreaterThanOrEqualTo(Date value) {
            addCriterion("fcm_lease_end_date >=", value, "fcmLeaseEndDate");
            return (Criteria) this;
        }

        public Criteria andFcmLeaseEndDateLessThan(Date value) {
            addCriterion("fcm_lease_end_date <", value, "fcmLeaseEndDate");
            return (Criteria) this;
        }

        public Criteria andFcmLeaseEndDateLessThanOrEqualTo(Date value) {
            addCriterion("fcm_lease_end_date <=", value, "fcmLeaseEndDate");
            return (Criteria) this;
        }

        public Criteria andFcmLeaseEndDateIn(List<Date> values) {
            addCriterion("fcm_lease_end_date in", values, "fcmLeaseEndDate");
            return (Criteria) this;
        }

        public Criteria andFcmLeaseEndDateNotIn(List<Date> values) {
            addCriterion("fcm_lease_end_date not in", values, "fcmLeaseEndDate");
            return (Criteria) this;
        }

        public Criteria andFcmLeaseEndDateBetween(Date value1, Date value2) {
            addCriterion("fcm_lease_end_date between", value1, value2, "fcmLeaseEndDate");
            return (Criteria) this;
        }

        public Criteria andFcmLeaseEndDateNotBetween(Date value1, Date value2) {
            addCriterion("fcm_lease_end_date not between", value1, value2, "fcmLeaseEndDate");
            return (Criteria) this;
        }

        public Criteria andFcmLeaseTypeIsNull() {
            addCriterion("fcm_lease_type is null");
            return (Criteria) this;
        }

        public Criteria andFcmLeaseTypeIsNotNull() {
            addCriterion("fcm_lease_type is not null");
            return (Criteria) this;
        }

        public Criteria andFcmLeaseTypeEqualTo(Integer value) {
            addCriterion("fcm_lease_type =", value, "fcmLeaseType");
            return (Criteria) this;
        }

        public Criteria andFcmLeaseTypeNotEqualTo(Integer value) {
            addCriterion("fcm_lease_type <>", value, "fcmLeaseType");
            return (Criteria) this;
        }

        public Criteria andFcmLeaseTypeGreaterThan(Integer value) {
            addCriterion("fcm_lease_type >", value, "fcmLeaseType");
            return (Criteria) this;
        }

        public Criteria andFcmLeaseTypeGreaterThanOrEqualTo(Integer value) {
            addCriterion("fcm_lease_type >=", value, "fcmLeaseType");
            return (Criteria) this;
        }

        public Criteria andFcmLeaseTypeLessThan(Integer value) {
            addCriterion("fcm_lease_type <", value, "fcmLeaseType");
            return (Criteria) this;
        }

        public Criteria andFcmLeaseTypeLessThanOrEqualTo(Integer value) {
            addCriterion("fcm_lease_type <=", value, "fcmLeaseType");
            return (Criteria) this;
        }

        public Criteria andFcmLeaseTypeIn(List<Integer> values) {
            addCriterion("fcm_lease_type in", values, "fcmLeaseType");
            return (Criteria) this;
        }

        public Criteria andFcmLeaseTypeNotIn(List<Integer> values) {
            addCriterion("fcm_lease_type not in", values, "fcmLeaseType");
            return (Criteria) this;
        }

        public Criteria andFcmLeaseTypeBetween(Integer value1, Integer value2) {
            addCriterion("fcm_lease_type between", value1, value2, "fcmLeaseType");
            return (Criteria) this;
        }

        public Criteria andFcmLeaseTypeNotBetween(Integer value1, Integer value2) {
            addCriterion("fcm_lease_type not between", value1, value2, "fcmLeaseType");
            return (Criteria) this;
        }

        public Criteria andFcmLeaseAmountIsNull() {
            addCriterion("fcm_lease_amount is null");
            return (Criteria) this;
        }

        public Criteria andFcmLeaseAmountIsNotNull() {
            addCriterion("fcm_lease_amount is not null");
            return (Criteria) this;
        }

        public Criteria andFcmLeaseAmountEqualTo(Double value) {
            addCriterion("fcm_lease_amount =", value, "fcmLeaseAmount");
            return (Criteria) this;
        }

        public Criteria andFcmLeaseAmountNotEqualTo(Double value) {
            addCriterion("fcm_lease_amount <>", value, "fcmLeaseAmount");
            return (Criteria) this;
        }

        public Criteria andFcmLeaseAmountGreaterThan(Double value) {
            addCriterion("fcm_lease_amount >", value, "fcmLeaseAmount");
            return (Criteria) this;
        }

        public Criteria andFcmLeaseAmountGreaterThanOrEqualTo(Double value) {
            addCriterion("fcm_lease_amount >=", value, "fcmLeaseAmount");
            return (Criteria) this;
        }

        public Criteria andFcmLeaseAmountLessThan(Double value) {
            addCriterion("fcm_lease_amount <", value, "fcmLeaseAmount");
            return (Criteria) this;
        }

        public Criteria andFcmLeaseAmountLessThanOrEqualTo(Double value) {
            addCriterion("fcm_lease_amount <=", value, "fcmLeaseAmount");
            return (Criteria) this;
        }

        public Criteria andFcmLeaseAmountIn(List<Double> values) {
            addCriterion("fcm_lease_amount in", values, "fcmLeaseAmount");
            return (Criteria) this;
        }

        public Criteria andFcmLeaseAmountNotIn(List<Double> values) {
            addCriterion("fcm_lease_amount not in", values, "fcmLeaseAmount");
            return (Criteria) this;
        }

        public Criteria andFcmLeaseAmountBetween(Double value1, Double value2) {
            addCriterion("fcm_lease_amount between", value1, value2, "fcmLeaseAmount");
            return (Criteria) this;
        }

        public Criteria andFcmLeaseAmountNotBetween(Double value1, Double value2) {
            addCriterion("fcm_lease_amount not between", value1, value2, "fcmLeaseAmount");
            return (Criteria) this;
        }

        public Criteria andFcmRentPayTypeIsNull() {
            addCriterion("fcm_rent_pay_type is null");
            return (Criteria) this;
        }

        public Criteria andFcmRentPayTypeIsNotNull() {
            addCriterion("fcm_rent_pay_type is not null");
            return (Criteria) this;
        }

        public Criteria andFcmRentPayTypeEqualTo(Integer value) {
            addCriterion("fcm_rent_pay_type =", value, "fcmRentPayType");
            return (Criteria) this;
        }

        public Criteria andFcmRentPayTypeNotEqualTo(Integer value) {
            addCriterion("fcm_rent_pay_type <>", value, "fcmRentPayType");
            return (Criteria) this;
        }

        public Criteria andFcmRentPayTypeGreaterThan(Integer value) {
            addCriterion("fcm_rent_pay_type >", value, "fcmRentPayType");
            return (Criteria) this;
        }

        public Criteria andFcmRentPayTypeGreaterThanOrEqualTo(Integer value) {
            addCriterion("fcm_rent_pay_type >=", value, "fcmRentPayType");
            return (Criteria) this;
        }

        public Criteria andFcmRentPayTypeLessThan(Integer value) {
            addCriterion("fcm_rent_pay_type <", value, "fcmRentPayType");
            return (Criteria) this;
        }

        public Criteria andFcmRentPayTypeLessThanOrEqualTo(Integer value) {
            addCriterion("fcm_rent_pay_type <=", value, "fcmRentPayType");
            return (Criteria) this;
        }

        public Criteria andFcmRentPayTypeIn(List<Integer> values) {
            addCriterion("fcm_rent_pay_type in", values, "fcmRentPayType");
            return (Criteria) this;
        }

        public Criteria andFcmRentPayTypeNotIn(List<Integer> values) {
            addCriterion("fcm_rent_pay_type not in", values, "fcmRentPayType");
            return (Criteria) this;
        }

        public Criteria andFcmRentPayTypeBetween(Integer value1, Integer value2) {
            addCriterion("fcm_rent_pay_type between", value1, value2, "fcmRentPayType");
            return (Criteria) this;
        }

        public Criteria andFcmRentPayTypeNotBetween(Integer value1, Integer value2) {
            addCriterion("fcm_rent_pay_type not between", value1, value2, "fcmRentPayType");
            return (Criteria) this;
        }

        public Criteria andFcmRentPayCycleIsNull() {
            addCriterion("fcm_rent_pay_cycle is null");
            return (Criteria) this;
        }

        public Criteria andFcmRentPayCycleIsNotNull() {
            addCriterion("fcm_rent_pay_cycle is not null");
            return (Criteria) this;
        }

        public Criteria andFcmRentPayCycleEqualTo(Integer value) {
            addCriterion("fcm_rent_pay_cycle =", value, "fcmRentPayCycle");
            return (Criteria) this;
        }

        public Criteria andFcmRentPayCycleNotEqualTo(Integer value) {
            addCriterion("fcm_rent_pay_cycle <>", value, "fcmRentPayCycle");
            return (Criteria) this;
        }

        public Criteria andFcmRentPayCycleGreaterThan(Integer value) {
            addCriterion("fcm_rent_pay_cycle >", value, "fcmRentPayCycle");
            return (Criteria) this;
        }

        public Criteria andFcmRentPayCycleGreaterThanOrEqualTo(Integer value) {
            addCriterion("fcm_rent_pay_cycle >=", value, "fcmRentPayCycle");
            return (Criteria) this;
        }

        public Criteria andFcmRentPayCycleLessThan(Integer value) {
            addCriterion("fcm_rent_pay_cycle <", value, "fcmRentPayCycle");
            return (Criteria) this;
        }

        public Criteria andFcmRentPayCycleLessThanOrEqualTo(Integer value) {
            addCriterion("fcm_rent_pay_cycle <=", value, "fcmRentPayCycle");
            return (Criteria) this;
        }

        public Criteria andFcmRentPayCycleIn(List<Integer> values) {
            addCriterion("fcm_rent_pay_cycle in", values, "fcmRentPayCycle");
            return (Criteria) this;
        }

        public Criteria andFcmRentPayCycleNotIn(List<Integer> values) {
            addCriterion("fcm_rent_pay_cycle not in", values, "fcmRentPayCycle");
            return (Criteria) this;
        }

        public Criteria andFcmRentPayCycleBetween(Integer value1, Integer value2) {
            addCriterion("fcm_rent_pay_cycle between", value1, value2, "fcmRentPayCycle");
            return (Criteria) this;
        }

        public Criteria andFcmRentPayCycleNotBetween(Integer value1, Integer value2) {
            addCriterion("fcm_rent_pay_cycle not between", value1, value2, "fcmRentPayCycle");
            return (Criteria) this;
        }

        public Criteria andFcmGiveLeaseIsNull() {
            addCriterion("fcm_give_lease is null");
            return (Criteria) this;
        }

        public Criteria andFcmGiveLeaseIsNotNull() {
            addCriterion("fcm_give_lease is not null");
            return (Criteria) this;
        }

        public Criteria andFcmGiveLeaseEqualTo(Integer value) {
            addCriterion("fcm_give_lease =", value, "fcmGiveLease");
            return (Criteria) this;
        }

        public Criteria andFcmGiveLeaseNotEqualTo(Integer value) {
            addCriterion("fcm_give_lease <>", value, "fcmGiveLease");
            return (Criteria) this;
        }

        public Criteria andFcmGiveLeaseGreaterThan(Integer value) {
            addCriterion("fcm_give_lease >", value, "fcmGiveLease");
            return (Criteria) this;
        }

        public Criteria andFcmGiveLeaseGreaterThanOrEqualTo(Integer value) {
            addCriterion("fcm_give_lease >=", value, "fcmGiveLease");
            return (Criteria) this;
        }

        public Criteria andFcmGiveLeaseLessThan(Integer value) {
            addCriterion("fcm_give_lease <", value, "fcmGiveLease");
            return (Criteria) this;
        }

        public Criteria andFcmGiveLeaseLessThanOrEqualTo(Integer value) {
            addCriterion("fcm_give_lease <=", value, "fcmGiveLease");
            return (Criteria) this;
        }

        public Criteria andFcmGiveLeaseIn(List<Integer> values) {
            addCriterion("fcm_give_lease in", values, "fcmGiveLease");
            return (Criteria) this;
        }

        public Criteria andFcmGiveLeaseNotIn(List<Integer> values) {
            addCriterion("fcm_give_lease not in", values, "fcmGiveLease");
            return (Criteria) this;
        }

        public Criteria andFcmGiveLeaseBetween(Integer value1, Integer value2) {
            addCriterion("fcm_give_lease between", value1, value2, "fcmGiveLease");
            return (Criteria) this;
        }

        public Criteria andFcmGiveLeaseNotBetween(Integer value1, Integer value2) {
            addCriterion("fcm_give_lease not between", value1, value2, "fcmGiveLease");
            return (Criteria) this;
        }

        public Criteria andFcmGiveSequenceIsNull() {
            addCriterion("fcm_give_sequence is null");
            return (Criteria) this;
        }

        public Criteria andFcmGiveSequenceIsNotNull() {
            addCriterion("fcm_give_sequence is not null");
            return (Criteria) this;
        }

        public Criteria andFcmGiveSequenceEqualTo(Integer value) {
            addCriterion("fcm_give_sequence =", value, "fcmGiveSequence");
            return (Criteria) this;
        }

        public Criteria andFcmGiveSequenceNotEqualTo(Integer value) {
            addCriterion("fcm_give_sequence <>", value, "fcmGiveSequence");
            return (Criteria) this;
        }

        public Criteria andFcmGiveSequenceGreaterThan(Integer value) {
            addCriterion("fcm_give_sequence >", value, "fcmGiveSequence");
            return (Criteria) this;
        }

        public Criteria andFcmGiveSequenceGreaterThanOrEqualTo(Integer value) {
            addCriterion("fcm_give_sequence >=", value, "fcmGiveSequence");
            return (Criteria) this;
        }

        public Criteria andFcmGiveSequenceLessThan(Integer value) {
            addCriterion("fcm_give_sequence <", value, "fcmGiveSequence");
            return (Criteria) this;
        }

        public Criteria andFcmGiveSequenceLessThanOrEqualTo(Integer value) {
            addCriterion("fcm_give_sequence <=", value, "fcmGiveSequence");
            return (Criteria) this;
        }

        public Criteria andFcmGiveSequenceIn(List<Integer> values) {
            addCriterion("fcm_give_sequence in", values, "fcmGiveSequence");
            return (Criteria) this;
        }

        public Criteria andFcmGiveSequenceNotIn(List<Integer> values) {
            addCriterion("fcm_give_sequence not in", values, "fcmGiveSequence");
            return (Criteria) this;
        }

        public Criteria andFcmGiveSequenceBetween(Integer value1, Integer value2) {
            addCriterion("fcm_give_sequence between", value1, value2, "fcmGiveSequence");
            return (Criteria) this;
        }

        public Criteria andFcmGiveSequenceNotBetween(Integer value1, Integer value2) {
            addCriterion("fcm_give_sequence not between", value1, value2, "fcmGiveSequence");
            return (Criteria) this;
        }

        public Criteria andFcmBillGenerateTypeIsNull() {
            addCriterion("fcm_bill_generate_type is null");
            return (Criteria) this;
        }

        public Criteria andFcmBillGenerateTypeIsNotNull() {
            addCriterion("fcm_bill_generate_type is not null");
            return (Criteria) this;
        }

        public Criteria andFcmBillGenerateTypeEqualTo(Integer value) {
            addCriterion("fcm_bill_generate_type =", value, "fcmBillGenerateType");
            return (Criteria) this;
        }

        public Criteria andFcmBillGenerateTypeNotEqualTo(Integer value) {
            addCriterion("fcm_bill_generate_type <>", value, "fcmBillGenerateType");
            return (Criteria) this;
        }

        public Criteria andFcmBillGenerateTypeGreaterThan(Integer value) {
            addCriterion("fcm_bill_generate_type >", value, "fcmBillGenerateType");
            return (Criteria) this;
        }

        public Criteria andFcmBillGenerateTypeGreaterThanOrEqualTo(Integer value) {
            addCriterion("fcm_bill_generate_type >=", value, "fcmBillGenerateType");
            return (Criteria) this;
        }

        public Criteria andFcmBillGenerateTypeLessThan(Integer value) {
            addCriterion("fcm_bill_generate_type <", value, "fcmBillGenerateType");
            return (Criteria) this;
        }

        public Criteria andFcmBillGenerateTypeLessThanOrEqualTo(Integer value) {
            addCriterion("fcm_bill_generate_type <=", value, "fcmBillGenerateType");
            return (Criteria) this;
        }

        public Criteria andFcmBillGenerateTypeIn(List<Integer> values) {
            addCriterion("fcm_bill_generate_type in", values, "fcmBillGenerateType");
            return (Criteria) this;
        }

        public Criteria andFcmBillGenerateTypeNotIn(List<Integer> values) {
            addCriterion("fcm_bill_generate_type not in", values, "fcmBillGenerateType");
            return (Criteria) this;
        }

        public Criteria andFcmBillGenerateTypeBetween(Integer value1, Integer value2) {
            addCriterion("fcm_bill_generate_type between", value1, value2, "fcmBillGenerateType");
            return (Criteria) this;
        }

        public Criteria andFcmBillGenerateTypeNotBetween(Integer value1, Integer value2) {
            addCriterion("fcm_bill_generate_type not between", value1, value2, "fcmBillGenerateType");
            return (Criteria) this;
        }

        public Criteria andFcmBillGenerateIntervalIsNull() {
            addCriterion("fcm_bill_generate_interval is null");
            return (Criteria) this;
        }

        public Criteria andFcmBillGenerateIntervalIsNotNull() {
            addCriterion("fcm_bill_generate_interval is not null");
            return (Criteria) this;
        }

        public Criteria andFcmBillGenerateIntervalEqualTo(Integer value) {
            addCriterion("fcm_bill_generate_interval =", value, "fcmBillGenerateInterval");
            return (Criteria) this;
        }

        public Criteria andFcmBillGenerateIntervalNotEqualTo(Integer value) {
            addCriterion("fcm_bill_generate_interval <>", value, "fcmBillGenerateInterval");
            return (Criteria) this;
        }

        public Criteria andFcmBillGenerateIntervalGreaterThan(Integer value) {
            addCriterion("fcm_bill_generate_interval >", value, "fcmBillGenerateInterval");
            return (Criteria) this;
        }

        public Criteria andFcmBillGenerateIntervalGreaterThanOrEqualTo(Integer value) {
            addCriterion("fcm_bill_generate_interval >=", value, "fcmBillGenerateInterval");
            return (Criteria) this;
        }

        public Criteria andFcmBillGenerateIntervalLessThan(Integer value) {
            addCriterion("fcm_bill_generate_interval <", value, "fcmBillGenerateInterval");
            return (Criteria) this;
        }

        public Criteria andFcmBillGenerateIntervalLessThanOrEqualTo(Integer value) {
            addCriterion("fcm_bill_generate_interval <=", value, "fcmBillGenerateInterval");
            return (Criteria) this;
        }

        public Criteria andFcmBillGenerateIntervalIn(List<Integer> values) {
            addCriterion("fcm_bill_generate_interval in", values, "fcmBillGenerateInterval");
            return (Criteria) this;
        }

        public Criteria andFcmBillGenerateIntervalNotIn(List<Integer> values) {
            addCriterion("fcm_bill_generate_interval not in", values, "fcmBillGenerateInterval");
            return (Criteria) this;
        }

        public Criteria andFcmBillGenerateIntervalBetween(Integer value1, Integer value2) {
            addCriterion("fcm_bill_generate_interval between", value1, value2, "fcmBillGenerateInterval");
            return (Criteria) this;
        }

        public Criteria andFcmBillGenerateIntervalNotBetween(Integer value1, Integer value2) {
            addCriterion("fcm_bill_generate_interval not between", value1, value2, "fcmBillGenerateInterval");
            return (Criteria) this;
        }

        public Criteria andFcmBillCatoffTypeIsNull() {
            addCriterion("fcm_bill_catoff_type is null");
            return (Criteria) this;
        }

        public Criteria andFcmBillCatoffTypeIsNotNull() {
            addCriterion("fcm_bill_catoff_type is not null");
            return (Criteria) this;
        }

        public Criteria andFcmBillCatoffTypeEqualTo(Integer value) {
            addCriterion("fcm_bill_catoff_type =", value, "fcmBillCatoffType");
            return (Criteria) this;
        }

        public Criteria andFcmBillCatoffTypeNotEqualTo(Integer value) {
            addCriterion("fcm_bill_catoff_type <>", value, "fcmBillCatoffType");
            return (Criteria) this;
        }

        public Criteria andFcmBillCatoffTypeGreaterThan(Integer value) {
            addCriterion("fcm_bill_catoff_type >", value, "fcmBillCatoffType");
            return (Criteria) this;
        }

        public Criteria andFcmBillCatoffTypeGreaterThanOrEqualTo(Integer value) {
            addCriterion("fcm_bill_catoff_type >=", value, "fcmBillCatoffType");
            return (Criteria) this;
        }

        public Criteria andFcmBillCatoffTypeLessThan(Integer value) {
            addCriterion("fcm_bill_catoff_type <", value, "fcmBillCatoffType");
            return (Criteria) this;
        }

        public Criteria andFcmBillCatoffTypeLessThanOrEqualTo(Integer value) {
            addCriterion("fcm_bill_catoff_type <=", value, "fcmBillCatoffType");
            return (Criteria) this;
        }

        public Criteria andFcmBillCatoffTypeIn(List<Integer> values) {
            addCriterion("fcm_bill_catoff_type in", values, "fcmBillCatoffType");
            return (Criteria) this;
        }

        public Criteria andFcmBillCatoffTypeNotIn(List<Integer> values) {
            addCriterion("fcm_bill_catoff_type not in", values, "fcmBillCatoffType");
            return (Criteria) this;
        }

        public Criteria andFcmBillCatoffTypeBetween(Integer value1, Integer value2) {
            addCriterion("fcm_bill_catoff_type between", value1, value2, "fcmBillCatoffType");
            return (Criteria) this;
        }

        public Criteria andFcmBillCatoffTypeNotBetween(Integer value1, Integer value2) {
            addCriterion("fcm_bill_catoff_type not between", value1, value2, "fcmBillCatoffType");
            return (Criteria) this;
        }

        public Criteria andFcmBillCatoffIntervalIsNull() {
            addCriterion("fcm_bill_catoff_interval is null");
            return (Criteria) this;
        }

        public Criteria andFcmBillCatoffIntervalIsNotNull() {
            addCriterion("fcm_bill_catoff_interval is not null");
            return (Criteria) this;
        }

        public Criteria andFcmBillCatoffIntervalEqualTo(Integer value) {
            addCriterion("fcm_bill_catoff_interval =", value, "fcmBillCatoffInterval");
            return (Criteria) this;
        }

        public Criteria andFcmBillCatoffIntervalNotEqualTo(Integer value) {
            addCriterion("fcm_bill_catoff_interval <>", value, "fcmBillCatoffInterval");
            return (Criteria) this;
        }

        public Criteria andFcmBillCatoffIntervalGreaterThan(Integer value) {
            addCriterion("fcm_bill_catoff_interval >", value, "fcmBillCatoffInterval");
            return (Criteria) this;
        }

        public Criteria andFcmBillCatoffIntervalGreaterThanOrEqualTo(Integer value) {
            addCriterion("fcm_bill_catoff_interval >=", value, "fcmBillCatoffInterval");
            return (Criteria) this;
        }

        public Criteria andFcmBillCatoffIntervalLessThan(Integer value) {
            addCriterion("fcm_bill_catoff_interval <", value, "fcmBillCatoffInterval");
            return (Criteria) this;
        }

        public Criteria andFcmBillCatoffIntervalLessThanOrEqualTo(Integer value) {
            addCriterion("fcm_bill_catoff_interval <=", value, "fcmBillCatoffInterval");
            return (Criteria) this;
        }

        public Criteria andFcmBillCatoffIntervalIn(List<Integer> values) {
            addCriterion("fcm_bill_catoff_interval in", values, "fcmBillCatoffInterval");
            return (Criteria) this;
        }

        public Criteria andFcmBillCatoffIntervalNotIn(List<Integer> values) {
            addCriterion("fcm_bill_catoff_interval not in", values, "fcmBillCatoffInterval");
            return (Criteria) this;
        }

        public Criteria andFcmBillCatoffIntervalBetween(Integer value1, Integer value2) {
            addCriterion("fcm_bill_catoff_interval between", value1, value2, "fcmBillCatoffInterval");
            return (Criteria) this;
        }

        public Criteria andFcmBillCatoffIntervalNotBetween(Integer value1, Integer value2) {
            addCriterion("fcm_bill_catoff_interval not between", value1, value2, "fcmBillCatoffInterval");
            return (Criteria) this;
        }

        public Criteria andFcmCarnumTotalIsNull() {
            addCriterion("fcm_carnum_total is null");
            return (Criteria) this;
        }

        public Criteria andFcmCarnumTotalIsNotNull() {
            addCriterion("fcm_carnum_total is not null");
            return (Criteria) this;
        }

        public Criteria andFcmCarnumTotalEqualTo(Integer value) {
            addCriterion("fcm_carnum_total =", value, "fcmCarnumTotal");
            return (Criteria) this;
        }

        public Criteria andFcmCarnumTotalNotEqualTo(Integer value) {
            addCriterion("fcm_carnum_total <>", value, "fcmCarnumTotal");
            return (Criteria) this;
        }

        public Criteria andFcmCarnumTotalGreaterThan(Integer value) {
            addCriterion("fcm_carnum_total >", value, "fcmCarnumTotal");
            return (Criteria) this;
        }

        public Criteria andFcmCarnumTotalGreaterThanOrEqualTo(Integer value) {
            addCriterion("fcm_carnum_total >=", value, "fcmCarnumTotal");
            return (Criteria) this;
        }

        public Criteria andFcmCarnumTotalLessThan(Integer value) {
            addCriterion("fcm_carnum_total <", value, "fcmCarnumTotal");
            return (Criteria) this;
        }

        public Criteria andFcmCarnumTotalLessThanOrEqualTo(Integer value) {
            addCriterion("fcm_carnum_total <=", value, "fcmCarnumTotal");
            return (Criteria) this;
        }

        public Criteria andFcmCarnumTotalIn(List<Integer> values) {
            addCriterion("fcm_carnum_total in", values, "fcmCarnumTotal");
            return (Criteria) this;
        }

        public Criteria andFcmCarnumTotalNotIn(List<Integer> values) {
            addCriterion("fcm_carnum_total not in", values, "fcmCarnumTotal");
            return (Criteria) this;
        }

        public Criteria andFcmCarnumTotalBetween(Integer value1, Integer value2) {
            addCriterion("fcm_carnum_total between", value1, value2, "fcmCarnumTotal");
            return (Criteria) this;
        }

        public Criteria andFcmCarnumTotalNotBetween(Integer value1, Integer value2) {
            addCriterion("fcm_carnum_total not between", value1, value2, "fcmCarnumTotal");
            return (Criteria) this;
        }

        public Criteria andFcmSingleMarginIsNull() {
            addCriterion("fcm_single_margin is null");
            return (Criteria) this;
        }

        public Criteria andFcmSingleMarginIsNotNull() {
            addCriterion("fcm_single_margin is not null");
            return (Criteria) this;
        }

        public Criteria andFcmSingleMarginEqualTo(Double value) {
            addCriterion("fcm_single_margin =", value, "fcmSingleMargin");
            return (Criteria) this;
        }

        public Criteria andFcmSingleMarginNotEqualTo(Double value) {
            addCriterion("fcm_single_margin <>", value, "fcmSingleMargin");
            return (Criteria) this;
        }

        public Criteria andFcmSingleMarginGreaterThan(Double value) {
            addCriterion("fcm_single_margin >", value, "fcmSingleMargin");
            return (Criteria) this;
        }

        public Criteria andFcmSingleMarginGreaterThanOrEqualTo(Double value) {
            addCriterion("fcm_single_margin >=", value, "fcmSingleMargin");
            return (Criteria) this;
        }

        public Criteria andFcmSingleMarginLessThan(Double value) {
            addCriterion("fcm_single_margin <", value, "fcmSingleMargin");
            return (Criteria) this;
        }

        public Criteria andFcmSingleMarginLessThanOrEqualTo(Double value) {
            addCriterion("fcm_single_margin <=", value, "fcmSingleMargin");
            return (Criteria) this;
        }

        public Criteria andFcmSingleMarginIn(List<Double> values) {
            addCriterion("fcm_single_margin in", values, "fcmSingleMargin");
            return (Criteria) this;
        }

        public Criteria andFcmSingleMarginNotIn(List<Double> values) {
            addCriterion("fcm_single_margin not in", values, "fcmSingleMargin");
            return (Criteria) this;
        }

        public Criteria andFcmSingleMarginBetween(Double value1, Double value2) {
            addCriterion("fcm_single_margin between", value1, value2, "fcmSingleMargin");
            return (Criteria) this;
        }

        public Criteria andFcmSingleMarginNotBetween(Double value1, Double value2) {
            addCriterion("fcm_single_margin not between", value1, value2, "fcmSingleMargin");
            return (Criteria) this;
        }

        public Criteria andFcmMarginPayRequireIsNull() {
            addCriterion("fcm_margin_pay_require is null");
            return (Criteria) this;
        }

        public Criteria andFcmMarginPayRequireIsNotNull() {
            addCriterion("fcm_margin_pay_require is not null");
            return (Criteria) this;
        }

        public Criteria andFcmMarginPayRequireEqualTo(Integer value) {
            addCriterion("fcm_margin_pay_require =", value, "fcmMarginPayRequire");
            return (Criteria) this;
        }

        public Criteria andFcmMarginPayRequireNotEqualTo(Integer value) {
            addCriterion("fcm_margin_pay_require <>", value, "fcmMarginPayRequire");
            return (Criteria) this;
        }

        public Criteria andFcmMarginPayRequireGreaterThan(Integer value) {
            addCriterion("fcm_margin_pay_require >", value, "fcmMarginPayRequire");
            return (Criteria) this;
        }

        public Criteria andFcmMarginPayRequireGreaterThanOrEqualTo(Integer value) {
            addCriterion("fcm_margin_pay_require >=", value, "fcmMarginPayRequire");
            return (Criteria) this;
        }

        public Criteria andFcmMarginPayRequireLessThan(Integer value) {
            addCriterion("fcm_margin_pay_require <", value, "fcmMarginPayRequire");
            return (Criteria) this;
        }

        public Criteria andFcmMarginPayRequireLessThanOrEqualTo(Integer value) {
            addCriterion("fcm_margin_pay_require <=", value, "fcmMarginPayRequire");
            return (Criteria) this;
        }

        public Criteria andFcmMarginPayRequireIn(List<Integer> values) {
            addCriterion("fcm_margin_pay_require in", values, "fcmMarginPayRequire");
            return (Criteria) this;
        }

        public Criteria andFcmMarginPayRequireNotIn(List<Integer> values) {
            addCriterion("fcm_margin_pay_require not in", values, "fcmMarginPayRequire");
            return (Criteria) this;
        }

        public Criteria andFcmMarginPayRequireBetween(Integer value1, Integer value2) {
            addCriterion("fcm_margin_pay_require between", value1, value2, "fcmMarginPayRequire");
            return (Criteria) this;
        }

        public Criteria andFcmMarginPayRequireNotBetween(Integer value1, Integer value2) {
            addCriterion("fcm_margin_pay_require not between", value1, value2, "fcmMarginPayRequire");
            return (Criteria) this;
        }

        public Criteria andFcmLeaseAmountTotalIsNull() {
            addCriterion("fcm_lease_amount_total is null");
            return (Criteria) this;
        }

        public Criteria andFcmLeaseAmountTotalIsNotNull() {
            addCriterion("fcm_lease_amount_total is not null");
            return (Criteria) this;
        }

        public Criteria andFcmLeaseAmountTotalEqualTo(Double value) {
            addCriterion("fcm_lease_amount_total =", value, "fcmLeaseAmountTotal");
            return (Criteria) this;
        }

        public Criteria andFcmLeaseAmountTotalNotEqualTo(Double value) {
            addCriterion("fcm_lease_amount_total <>", value, "fcmLeaseAmountTotal");
            return (Criteria) this;
        }

        public Criteria andFcmLeaseAmountTotalGreaterThan(Double value) {
            addCriterion("fcm_lease_amount_total >", value, "fcmLeaseAmountTotal");
            return (Criteria) this;
        }

        public Criteria andFcmLeaseAmountTotalGreaterThanOrEqualTo(Double value) {
            addCriterion("fcm_lease_amount_total >=", value, "fcmLeaseAmountTotal");
            return (Criteria) this;
        }

        public Criteria andFcmLeaseAmountTotalLessThan(Double value) {
            addCriterion("fcm_lease_amount_total <", value, "fcmLeaseAmountTotal");
            return (Criteria) this;
        }

        public Criteria andFcmLeaseAmountTotalLessThanOrEqualTo(Double value) {
            addCriterion("fcm_lease_amount_total <=", value, "fcmLeaseAmountTotal");
            return (Criteria) this;
        }

        public Criteria andFcmLeaseAmountTotalIn(List<Double> values) {
            addCriterion("fcm_lease_amount_total in", values, "fcmLeaseAmountTotal");
            return (Criteria) this;
        }

        public Criteria andFcmLeaseAmountTotalNotIn(List<Double> values) {
            addCriterion("fcm_lease_amount_total not in", values, "fcmLeaseAmountTotal");
            return (Criteria) this;
        }

        public Criteria andFcmLeaseAmountTotalBetween(Double value1, Double value2) {
            addCriterion("fcm_lease_amount_total between", value1, value2, "fcmLeaseAmountTotal");
            return (Criteria) this;
        }

        public Criteria andFcmLeaseAmountTotalNotBetween(Double value1, Double value2) {
            addCriterion("fcm_lease_amount_total not between", value1, value2, "fcmLeaseAmountTotal");
            return (Criteria) this;
        }

        public Criteria andFcmMarginTypeIsNull() {
            addCriterion("fcm_margin_type is null");
            return (Criteria) this;
        }

        public Criteria andFcmMarginTypeIsNotNull() {
            addCriterion("fcm_margin_type is not null");
            return (Criteria) this;
        }

        public Criteria andFcmMarginTypeEqualTo(Integer value) {
            addCriterion("fcm_margin_type =", value, "fcmMarginType");
            return (Criteria) this;
        }

        public Criteria andFcmMarginTypeNotEqualTo(Integer value) {
            addCriterion("fcm_margin_type <>", value, "fcmMarginType");
            return (Criteria) this;
        }

        public Criteria andFcmMarginTypeGreaterThan(Integer value) {
            addCriterion("fcm_margin_type >", value, "fcmMarginType");
            return (Criteria) this;
        }

        public Criteria andFcmMarginTypeGreaterThanOrEqualTo(Integer value) {
            addCriterion("fcm_margin_type >=", value, "fcmMarginType");
            return (Criteria) this;
        }

        public Criteria andFcmMarginTypeLessThan(Integer value) {
            addCriterion("fcm_margin_type <", value, "fcmMarginType");
            return (Criteria) this;
        }

        public Criteria andFcmMarginTypeLessThanOrEqualTo(Integer value) {
            addCriterion("fcm_margin_type <=", value, "fcmMarginType");
            return (Criteria) this;
        }

        public Criteria andFcmMarginTypeIn(List<Integer> values) {
            addCriterion("fcm_margin_type in", values, "fcmMarginType");
            return (Criteria) this;
        }

        public Criteria andFcmMarginTypeNotIn(List<Integer> values) {
            addCriterion("fcm_margin_type not in", values, "fcmMarginType");
            return (Criteria) this;
        }

        public Criteria andFcmMarginTypeBetween(Integer value1, Integer value2) {
            addCriterion("fcm_margin_type between", value1, value2, "fcmMarginType");
            return (Criteria) this;
        }

        public Criteria andFcmMarginTypeNotBetween(Integer value1, Integer value2) {
            addCriterion("fcm_margin_type not between", value1, value2, "fcmMarginType");
            return (Criteria) this;
        }

        public Criteria andFcmMarginMoneyIsNull() {
            addCriterion("fcm_margin_money is null");
            return (Criteria) this;
        }

        public Criteria andFcmMarginMoneyIsNotNull() {
            addCriterion("fcm_margin_money is not null");
            return (Criteria) this;
        }

        public Criteria andFcmMarginMoneyEqualTo(Double value) {
            addCriterion("fcm_margin_money =", value, "fcmMarginMoney");
            return (Criteria) this;
        }

        public Criteria andFcmMarginMoneyNotEqualTo(Double value) {
            addCriterion("fcm_margin_money <>", value, "fcmMarginMoney");
            return (Criteria) this;
        }

        public Criteria andFcmMarginMoneyGreaterThan(Double value) {
            addCriterion("fcm_margin_money >", value, "fcmMarginMoney");
            return (Criteria) this;
        }

        public Criteria andFcmMarginMoneyGreaterThanOrEqualTo(Double value) {
            addCriterion("fcm_margin_money >=", value, "fcmMarginMoney");
            return (Criteria) this;
        }

        public Criteria andFcmMarginMoneyLessThan(Double value) {
            addCriterion("fcm_margin_money <", value, "fcmMarginMoney");
            return (Criteria) this;
        }

        public Criteria andFcmMarginMoneyLessThanOrEqualTo(Double value) {
            addCriterion("fcm_margin_money <=", value, "fcmMarginMoney");
            return (Criteria) this;
        }

        public Criteria andFcmMarginMoneyIn(List<Double> values) {
            addCriterion("fcm_margin_money in", values, "fcmMarginMoney");
            return (Criteria) this;
        }

        public Criteria andFcmMarginMoneyNotIn(List<Double> values) {
            addCriterion("fcm_margin_money not in", values, "fcmMarginMoney");
            return (Criteria) this;
        }

        public Criteria andFcmMarginMoneyBetween(Double value1, Double value2) {
            addCriterion("fcm_margin_money between", value1, value2, "fcmMarginMoney");
            return (Criteria) this;
        }

        public Criteria andFcmMarginMoneyNotBetween(Double value1, Double value2) {
            addCriterion("fcm_margin_money not between", value1, value2, "fcmMarginMoney");
            return (Criteria) this;
        }

        public Criteria andFcmMarginTotalIsNull() {
            addCriterion("fcm_margin_total is null");
            return (Criteria) this;
        }

        public Criteria andFcmMarginTotalIsNotNull() {
            addCriterion("fcm_margin_total is not null");
            return (Criteria) this;
        }

        public Criteria andFcmMarginTotalEqualTo(Double value) {
            addCriterion("fcm_margin_total =", value, "fcmMarginTotal");
            return (Criteria) this;
        }

        public Criteria andFcmMarginTotalNotEqualTo(Double value) {
            addCriterion("fcm_margin_total <>", value, "fcmMarginTotal");
            return (Criteria) this;
        }

        public Criteria andFcmMarginTotalGreaterThan(Double value) {
            addCriterion("fcm_margin_total >", value, "fcmMarginTotal");
            return (Criteria) this;
        }

        public Criteria andFcmMarginTotalGreaterThanOrEqualTo(Double value) {
            addCriterion("fcm_margin_total >=", value, "fcmMarginTotal");
            return (Criteria) this;
        }

        public Criteria andFcmMarginTotalLessThan(Double value) {
            addCriterion("fcm_margin_total <", value, "fcmMarginTotal");
            return (Criteria) this;
        }

        public Criteria andFcmMarginTotalLessThanOrEqualTo(Double value) {
            addCriterion("fcm_margin_total <=", value, "fcmMarginTotal");
            return (Criteria) this;
        }

        public Criteria andFcmMarginTotalIn(List<Double> values) {
            addCriterion("fcm_margin_total in", values, "fcmMarginTotal");
            return (Criteria) this;
        }

        public Criteria andFcmMarginTotalNotIn(List<Double> values) {
            addCriterion("fcm_margin_total not in", values, "fcmMarginTotal");
            return (Criteria) this;
        }

        public Criteria andFcmMarginTotalBetween(Double value1, Double value2) {
            addCriterion("fcm_margin_total between", value1, value2, "fcmMarginTotal");
            return (Criteria) this;
        }

        public Criteria andFcmMarginTotalNotBetween(Double value1, Double value2) {
            addCriterion("fcm_margin_total not between", value1, value2, "fcmMarginTotal");
            return (Criteria) this;
        }

        public Criteria andFcmCarPurchaseIsNull() {
            addCriterion("fcm_car_purchase is null");
            return (Criteria) this;
        }

        public Criteria andFcmCarPurchaseIsNotNull() {
            addCriterion("fcm_car_purchase is not null");
            return (Criteria) this;
        }

        public Criteria andFcmCarPurchaseEqualTo(Double value) {
            addCriterion("fcm_car_purchase =", value, "fcmCarPurchase");
            return (Criteria) this;
        }

        public Criteria andFcmCarPurchaseNotEqualTo(Double value) {
            addCriterion("fcm_car_purchase <>", value, "fcmCarPurchase");
            return (Criteria) this;
        }

        public Criteria andFcmCarPurchaseGreaterThan(Double value) {
            addCriterion("fcm_car_purchase >", value, "fcmCarPurchase");
            return (Criteria) this;
        }

        public Criteria andFcmCarPurchaseGreaterThanOrEqualTo(Double value) {
            addCriterion("fcm_car_purchase >=", value, "fcmCarPurchase");
            return (Criteria) this;
        }

        public Criteria andFcmCarPurchaseLessThan(Double value) {
            addCriterion("fcm_car_purchase <", value, "fcmCarPurchase");
            return (Criteria) this;
        }

        public Criteria andFcmCarPurchaseLessThanOrEqualTo(Double value) {
            addCriterion("fcm_car_purchase <=", value, "fcmCarPurchase");
            return (Criteria) this;
        }

        public Criteria andFcmCarPurchaseIn(List<Double> values) {
            addCriterion("fcm_car_purchase in", values, "fcmCarPurchase");
            return (Criteria) this;
        }

        public Criteria andFcmCarPurchaseNotIn(List<Double> values) {
            addCriterion("fcm_car_purchase not in", values, "fcmCarPurchase");
            return (Criteria) this;
        }

        public Criteria andFcmCarPurchaseBetween(Double value1, Double value2) {
            addCriterion("fcm_car_purchase between", value1, value2, "fcmCarPurchase");
            return (Criteria) this;
        }

        public Criteria andFcmCarPurchaseNotBetween(Double value1, Double value2) {
            addCriterion("fcm_car_purchase not between", value1, value2, "fcmCarPurchase");
            return (Criteria) this;
        }

        public Criteria andFcmBoldRentIsNull() {
            addCriterion("fcm_bold_rent is null");
            return (Criteria) this;
        }

        public Criteria andFcmBoldRentIsNotNull() {
            addCriterion("fcm_bold_rent is not null");
            return (Criteria) this;
        }

        public Criteria andFcmBoldRentEqualTo(Double value) {
            addCriterion("fcm_bold_rent =", value, "fcmBoldRent");
            return (Criteria) this;
        }

        public Criteria andFcmBoldRentNotEqualTo(Double value) {
            addCriterion("fcm_bold_rent <>", value, "fcmBoldRent");
            return (Criteria) this;
        }

        public Criteria andFcmBoldRentGreaterThan(Double value) {
            addCriterion("fcm_bold_rent >", value, "fcmBoldRent");
            return (Criteria) this;
        }

        public Criteria andFcmBoldRentGreaterThanOrEqualTo(Double value) {
            addCriterion("fcm_bold_rent >=", value, "fcmBoldRent");
            return (Criteria) this;
        }

        public Criteria andFcmBoldRentLessThan(Double value) {
            addCriterion("fcm_bold_rent <", value, "fcmBoldRent");
            return (Criteria) this;
        }

        public Criteria andFcmBoldRentLessThanOrEqualTo(Double value) {
            addCriterion("fcm_bold_rent <=", value, "fcmBoldRent");
            return (Criteria) this;
        }

        public Criteria andFcmBoldRentIn(List<Double> values) {
            addCriterion("fcm_bold_rent in", values, "fcmBoldRent");
            return (Criteria) this;
        }

        public Criteria andFcmBoldRentNotIn(List<Double> values) {
            addCriterion("fcm_bold_rent not in", values, "fcmBoldRent");
            return (Criteria) this;
        }

        public Criteria andFcmBoldRentBetween(Double value1, Double value2) {
            addCriterion("fcm_bold_rent between", value1, value2, "fcmBoldRent");
            return (Criteria) this;
        }

        public Criteria andFcmBoldRentNotBetween(Double value1, Double value2) {
            addCriterion("fcm_bold_rent not between", value1, value2, "fcmBoldRent");
            return (Criteria) this;
        }

        public Criteria andFcmCarPurchaseAdvanceIsNull() {
            addCriterion("fcm_car_purchase_advance is null");
            return (Criteria) this;
        }

        public Criteria andFcmCarPurchaseAdvanceIsNotNull() {
            addCriterion("fcm_car_purchase_advance is not null");
            return (Criteria) this;
        }

        public Criteria andFcmCarPurchaseAdvanceEqualTo(String value) {
            addCriterion("fcm_car_purchase_advance =", value, "fcmCarPurchaseAdvance");
            return (Criteria) this;
        }

        public Criteria andFcmCarPurchaseAdvanceNotEqualTo(String value) {
            addCriterion("fcm_car_purchase_advance <>", value, "fcmCarPurchaseAdvance");
            return (Criteria) this;
        }

        public Criteria andFcmCarPurchaseAdvanceGreaterThan(String value) {
            addCriterion("fcm_car_purchase_advance >", value, "fcmCarPurchaseAdvance");
            return (Criteria) this;
        }

        public Criteria andFcmCarPurchaseAdvanceGreaterThanOrEqualTo(String value) {
            addCriterion("fcm_car_purchase_advance >=", value, "fcmCarPurchaseAdvance");
            return (Criteria) this;
        }

        public Criteria andFcmCarPurchaseAdvanceLessThan(String value) {
            addCriterion("fcm_car_purchase_advance <", value, "fcmCarPurchaseAdvance");
            return (Criteria) this;
        }

        public Criteria andFcmCarPurchaseAdvanceLessThanOrEqualTo(String value) {
            addCriterion("fcm_car_purchase_advance <=", value, "fcmCarPurchaseAdvance");
            return (Criteria) this;
        }

        public Criteria andFcmCarPurchaseAdvanceLike(String value) {
            addCriterion("fcm_car_purchase_advance like", value, "fcmCarPurchaseAdvance");
            return (Criteria) this;
        }

        public Criteria andFcmCarPurchaseAdvanceNotLike(String value) {
            addCriterion("fcm_car_purchase_advance not like", value, "fcmCarPurchaseAdvance");
            return (Criteria) this;
        }

        public Criteria andFcmCarPurchaseAdvanceIn(List<String> values) {
            addCriterion("fcm_car_purchase_advance in", values, "fcmCarPurchaseAdvance");
            return (Criteria) this;
        }

        public Criteria andFcmCarPurchaseAdvanceNotIn(List<String> values) {
            addCriterion("fcm_car_purchase_advance not in", values, "fcmCarPurchaseAdvance");
            return (Criteria) this;
        }

        public Criteria andFcmCarPurchaseAdvanceBetween(String value1, String value2) {
            addCriterion("fcm_car_purchase_advance between", value1, value2, "fcmCarPurchaseAdvance");
            return (Criteria) this;
        }

        public Criteria andFcmCarPurchaseAdvanceNotBetween(String value1, String value2) {
            addCriterion("fcm_car_purchase_advance not between", value1, value2, "fcmCarPurchaseAdvance");
            return (Criteria) this;
        }

        public Criteria andFcmContractStateIsNull() {
            addCriterion("fcm_contract_state is null");
            return (Criteria) this;
        }

        public Criteria andFcmContractStateIsNotNull() {
            addCriterion("fcm_contract_state is not null");
            return (Criteria) this;
        }

        public Criteria andFcmContractStateEqualTo(Integer value) {
            addCriterion("fcm_contract_state =", value, "fcmContractState");
            return (Criteria) this;
        }

        public Criteria andFcmContractStateNotEqualTo(Integer value) {
            addCriterion("fcm_contract_state <>", value, "fcmContractState");
            return (Criteria) this;
        }

        public Criteria andFcmContractStateGreaterThan(Integer value) {
            addCriterion("fcm_contract_state >", value, "fcmContractState");
            return (Criteria) this;
        }

        public Criteria andFcmContractStateGreaterThanOrEqualTo(Integer value) {
            addCriterion("fcm_contract_state >=", value, "fcmContractState");
            return (Criteria) this;
        }

        public Criteria andFcmContractStateLessThan(Integer value) {
            addCriterion("fcm_contract_state <", value, "fcmContractState");
            return (Criteria) this;
        }

        public Criteria andFcmContractStateLessThanOrEqualTo(Integer value) {
            addCriterion("fcm_contract_state <=", value, "fcmContractState");
            return (Criteria) this;
        }

        public Criteria andFcmContractStateIn(List<Integer> values) {
            addCriterion("fcm_contract_state in", values, "fcmContractState");
            return (Criteria) this;
        }

        public Criteria andFcmContractStateNotIn(List<Integer> values) {
            addCriterion("fcm_contract_state not in", values, "fcmContractState");
            return (Criteria) this;
        }

        public Criteria andFcmContractStateBetween(Integer value1, Integer value2) {
            addCriterion("fcm_contract_state between", value1, value2, "fcmContractState");
            return (Criteria) this;
        }

        public Criteria andFcmContractStateNotBetween(Integer value1, Integer value2) {
            addCriterion("fcm_contract_state not between", value1, value2, "fcmContractState");
            return (Criteria) this;
        }

        public Criteria andFcmSettlementStateIsNull() {
            addCriterion("fcm_settlement_state is null");
            return (Criteria) this;
        }

        public Criteria andFcmSettlementStateIsNotNull() {
            addCriterion("fcm_settlement_state is not null");
            return (Criteria) this;
        }

        public Criteria andFcmSettlementStateEqualTo(Integer value) {
            addCriterion("fcm_settlement_state =", value, "fcmSettlementState");
            return (Criteria) this;
        }

        public Criteria andFcmSettlementStateNotEqualTo(Integer value) {
            addCriterion("fcm_settlement_state <>", value, "fcmSettlementState");
            return (Criteria) this;
        }

        public Criteria andFcmSettlementStateGreaterThan(Integer value) {
            addCriterion("fcm_settlement_state >", value, "fcmSettlementState");
            return (Criteria) this;
        }

        public Criteria andFcmSettlementStateGreaterThanOrEqualTo(Integer value) {
            addCriterion("fcm_settlement_state >=", value, "fcmSettlementState");
            return (Criteria) this;
        }

        public Criteria andFcmSettlementStateLessThan(Integer value) {
            addCriterion("fcm_settlement_state <", value, "fcmSettlementState");
            return (Criteria) this;
        }

        public Criteria andFcmSettlementStateLessThanOrEqualTo(Integer value) {
            addCriterion("fcm_settlement_state <=", value, "fcmSettlementState");
            return (Criteria) this;
        }

        public Criteria andFcmSettlementStateIn(List<Integer> values) {
            addCriterion("fcm_settlement_state in", values, "fcmSettlementState");
            return (Criteria) this;
        }

        public Criteria andFcmSettlementStateNotIn(List<Integer> values) {
            addCriterion("fcm_settlement_state not in", values, "fcmSettlementState");
            return (Criteria) this;
        }

        public Criteria andFcmSettlementStateBetween(Integer value1, Integer value2) {
            addCriterion("fcm_settlement_state between", value1, value2, "fcmSettlementState");
            return (Criteria) this;
        }

        public Criteria andFcmSettlementStateNotBetween(Integer value1, Integer value2) {
            addCriterion("fcm_settlement_state not between", value1, value2, "fcmSettlementState");
            return (Criteria) this;
        }

        public Criteria andFcmAssociateContractIdIsNull() {
            addCriterion("fcm_associate_contract_id is null");
            return (Criteria) this;
        }

        public Criteria andFcmAssociateContractIdIsNotNull() {
            addCriterion("fcm_associate_contract_id is not null");
            return (Criteria) this;
        }

        public Criteria andFcmAssociateContractIdEqualTo(Long value) {
            addCriterion("fcm_associate_contract_id =", value, "fcmAssociateContractId");
            return (Criteria) this;
        }

        public Criteria andFcmAssociateContractIdNotEqualTo(Long value) {
            addCriterion("fcm_associate_contract_id <>", value, "fcmAssociateContractId");
            return (Criteria) this;
        }

        public Criteria andFcmAssociateContractIdGreaterThan(Long value) {
            addCriterion("fcm_associate_contract_id >", value, "fcmAssociateContractId");
            return (Criteria) this;
        }

        public Criteria andFcmAssociateContractIdGreaterThanOrEqualTo(Long value) {
            addCriterion("fcm_associate_contract_id >=", value, "fcmAssociateContractId");
            return (Criteria) this;
        }

        public Criteria andFcmAssociateContractIdLessThan(Long value) {
            addCriterion("fcm_associate_contract_id <", value, "fcmAssociateContractId");
            return (Criteria) this;
        }

        public Criteria andFcmAssociateContractIdLessThanOrEqualTo(Long value) {
            addCriterion("fcm_associate_contract_id <=", value, "fcmAssociateContractId");
            return (Criteria) this;
        }

        public Criteria andFcmAssociateContractIdIn(List<Long> values) {
            addCriterion("fcm_associate_contract_id in", values, "fcmAssociateContractId");
            return (Criteria) this;
        }

        public Criteria andFcmAssociateContractIdNotIn(List<Long> values) {
            addCriterion("fcm_associate_contract_id not in", values, "fcmAssociateContractId");
            return (Criteria) this;
        }

        public Criteria andFcmAssociateContractIdBetween(Long value1, Long value2) {
            addCriterion("fcm_associate_contract_id between", value1, value2, "fcmAssociateContractId");
            return (Criteria) this;
        }

        public Criteria andFcmAssociateContractIdNotBetween(Long value1, Long value2) {
            addCriterion("fcm_associate_contract_id not between", value1, value2, "fcmAssociateContractId");
            return (Criteria) this;
        }

        public Criteria andFcmAssociateContractNoIsNull() {
            addCriterion("fcm_associate_contract_no is null");
            return (Criteria) this;
        }

        public Criteria andFcmAssociateContractNoIsNotNull() {
            addCriterion("fcm_associate_contract_no is not null");
            return (Criteria) this;
        }

        public Criteria andFcmAssociateContractNoEqualTo(String value) {
            addCriterion("fcm_associate_contract_no =", value, "fcmAssociateContractNo");
            return (Criteria) this;
        }

        public Criteria andFcmAssociateContractNoNotEqualTo(String value) {
            addCriterion("fcm_associate_contract_no <>", value, "fcmAssociateContractNo");
            return (Criteria) this;
        }

        public Criteria andFcmAssociateContractNoGreaterThan(String value) {
            addCriterion("fcm_associate_contract_no >", value, "fcmAssociateContractNo");
            return (Criteria) this;
        }

        public Criteria andFcmAssociateContractNoGreaterThanOrEqualTo(String value) {
            addCriterion("fcm_associate_contract_no >=", value, "fcmAssociateContractNo");
            return (Criteria) this;
        }

        public Criteria andFcmAssociateContractNoLessThan(String value) {
            addCriterion("fcm_associate_contract_no <", value, "fcmAssociateContractNo");
            return (Criteria) this;
        }

        public Criteria andFcmAssociateContractNoLessThanOrEqualTo(String value) {
            addCriterion("fcm_associate_contract_no <=", value, "fcmAssociateContractNo");
            return (Criteria) this;
        }

        public Criteria andFcmAssociateContractNoLike(String value) {
            addCriterion("fcm_associate_contract_no like", value, "fcmAssociateContractNo");
            return (Criteria) this;
        }

        public Criteria andFcmAssociateContractNoNotLike(String value) {
            addCriterion("fcm_associate_contract_no not like", value, "fcmAssociateContractNo");
            return (Criteria) this;
        }

        public Criteria andFcmAssociateContractNoIn(List<String> values) {
            addCriterion("fcm_associate_contract_no in", values, "fcmAssociateContractNo");
            return (Criteria) this;
        }

        public Criteria andFcmAssociateContractNoNotIn(List<String> values) {
            addCriterion("fcm_associate_contract_no not in", values, "fcmAssociateContractNo");
            return (Criteria) this;
        }

        public Criteria andFcmAssociateContractNoBetween(String value1, String value2) {
            addCriterion("fcm_associate_contract_no between", value1, value2, "fcmAssociateContractNo");
            return (Criteria) this;
        }

        public Criteria andFcmAssociateContractNoNotBetween(String value1, String value2) {
            addCriterion("fcm_associate_contract_no not between", value1, value2, "fcmAssociateContractNo");
            return (Criteria) this;
        }

        public Criteria andFncTurnerSingleDealIsNull() {
            addCriterion("fnc_turner_single_deal is null");
            return (Criteria) this;
        }

        public Criteria andFncTurnerSingleDealIsNotNull() {
            addCriterion("fnc_turner_single_deal is not null");
            return (Criteria) this;
        }

        public Criteria andFncTurnerSingleDealEqualTo(Integer value) {
            addCriterion("fnc_turner_single_deal =", value, "fncTurnerSingleDeal");
            return (Criteria) this;
        }

        public Criteria andFncTurnerSingleDealNotEqualTo(Integer value) {
            addCriterion("fnc_turner_single_deal <>", value, "fncTurnerSingleDeal");
            return (Criteria) this;
        }

        public Criteria andFncTurnerSingleDealGreaterThan(Integer value) {
            addCriterion("fnc_turner_single_deal >", value, "fncTurnerSingleDeal");
            return (Criteria) this;
        }

        public Criteria andFncTurnerSingleDealGreaterThanOrEqualTo(Integer value) {
            addCriterion("fnc_turner_single_deal >=", value, "fncTurnerSingleDeal");
            return (Criteria) this;
        }

        public Criteria andFncTurnerSingleDealLessThan(Integer value) {
            addCriterion("fnc_turner_single_deal <", value, "fncTurnerSingleDeal");
            return (Criteria) this;
        }

        public Criteria andFncTurnerSingleDealLessThanOrEqualTo(Integer value) {
            addCriterion("fnc_turner_single_deal <=", value, "fncTurnerSingleDeal");
            return (Criteria) this;
        }

        public Criteria andFncTurnerSingleDealIn(List<Integer> values) {
            addCriterion("fnc_turner_single_deal in", values, "fncTurnerSingleDeal");
            return (Criteria) this;
        }

        public Criteria andFncTurnerSingleDealNotIn(List<Integer> values) {
            addCriterion("fnc_turner_single_deal not in", values, "fncTurnerSingleDeal");
            return (Criteria) this;
        }

        public Criteria andFncTurnerSingleDealBetween(Integer value1, Integer value2) {
            addCriterion("fnc_turner_single_deal between", value1, value2, "fncTurnerSingleDeal");
            return (Criteria) this;
        }

        public Criteria andFncTurnerSingleDealNotBetween(Integer value1, Integer value2) {
            addCriterion("fnc_turner_single_deal not between", value1, value2, "fncTurnerSingleDeal");
            return (Criteria) this;
        }

        public Criteria andFcmCarNatureIsNull() {
            addCriterion("fcm_car_nature is null");
            return (Criteria) this;
        }

        public Criteria andFcmCarNatureIsNotNull() {
            addCriterion("fcm_car_nature is not null");
            return (Criteria) this;
        }

        public Criteria andFcmCarNatureEqualTo(String value) {
            addCriterion("fcm_car_nature =", value, "fcmCarNature");
            return (Criteria) this;
        }

        public Criteria andFcmCarNatureNotEqualTo(String value) {
            addCriterion("fcm_car_nature <>", value, "fcmCarNature");
            return (Criteria) this;
        }

        public Criteria andFcmCarNatureGreaterThan(String value) {
            addCriterion("fcm_car_nature >", value, "fcmCarNature");
            return (Criteria) this;
        }

        public Criteria andFcmCarNatureGreaterThanOrEqualTo(String value) {
            addCriterion("fcm_car_nature >=", value, "fcmCarNature");
            return (Criteria) this;
        }

        public Criteria andFcmCarNatureLessThan(String value) {
            addCriterion("fcm_car_nature <", value, "fcmCarNature");
            return (Criteria) this;
        }

        public Criteria andFcmCarNatureLessThanOrEqualTo(String value) {
            addCriterion("fcm_car_nature <=", value, "fcmCarNature");
            return (Criteria) this;
        }

        public Criteria andFcmCarNatureLike(String value) {
            addCriterion("fcm_car_nature like", value, "fcmCarNature");
            return (Criteria) this;
        }

        public Criteria andFcmCarNatureNotLike(String value) {
            addCriterion("fcm_car_nature not like", value, "fcmCarNature");
            return (Criteria) this;
        }

        public Criteria andFcmCarNatureIn(List<String> values) {
            addCriterion("fcm_car_nature in", values, "fcmCarNature");
            return (Criteria) this;
        }

        public Criteria andFcmCarNatureNotIn(List<String> values) {
            addCriterion("fcm_car_nature not in", values, "fcmCarNature");
            return (Criteria) this;
        }

        public Criteria andFcmCarNatureBetween(String value1, String value2) {
            addCriterion("fcm_car_nature between", value1, value2, "fcmCarNature");
            return (Criteria) this;
        }

        public Criteria andFcmCarNatureNotBetween(String value1, String value2) {
            addCriterion("fcm_car_nature not between", value1, value2, "fcmCarNature");
            return (Criteria) this;
        }

        public Criteria andFcmDeliverCityIsNull() {
            addCriterion("fcm_deliver_city is null");
            return (Criteria) this;
        }

        public Criteria andFcmDeliverCityIsNotNull() {
            addCriterion("fcm_deliver_city is not null");
            return (Criteria) this;
        }

        public Criteria andFcmDeliverCityEqualTo(Long value) {
            addCriterion("fcm_deliver_city =", value, "fcmDeliverCity");
            return (Criteria) this;
        }

        public Criteria andFcmDeliverCityNotEqualTo(Long value) {
            addCriterion("fcm_deliver_city <>", value, "fcmDeliverCity");
            return (Criteria) this;
        }

        public Criteria andFcmDeliverCityGreaterThan(Long value) {
            addCriterion("fcm_deliver_city >", value, "fcmDeliverCity");
            return (Criteria) this;
        }

        public Criteria andFcmDeliverCityGreaterThanOrEqualTo(Long value) {
            addCriterion("fcm_deliver_city >=", value, "fcmDeliverCity");
            return (Criteria) this;
        }

        public Criteria andFcmDeliverCityLessThan(Long value) {
            addCriterion("fcm_deliver_city <", value, "fcmDeliverCity");
            return (Criteria) this;
        }

        public Criteria andFcmDeliverCityLessThanOrEqualTo(Long value) {
            addCriterion("fcm_deliver_city <=", value, "fcmDeliverCity");
            return (Criteria) this;
        }

        public Criteria andFcmDeliverCityIn(List<Long> values) {
            addCriterion("fcm_deliver_city in", values, "fcmDeliverCity");
            return (Criteria) this;
        }

        public Criteria andFcmDeliverCityNotIn(List<Long> values) {
            addCriterion("fcm_deliver_city not in", values, "fcmDeliverCity");
            return (Criteria) this;
        }

        public Criteria andFcmDeliverCityBetween(Long value1, Long value2) {
            addCriterion("fcm_deliver_city between", value1, value2, "fcmDeliverCity");
            return (Criteria) this;
        }

        public Criteria andFcmDeliverCityNotBetween(Long value1, Long value2) {
            addCriterion("fcm_deliver_city not between", value1, value2, "fcmDeliverCity");
            return (Criteria) this;
        }

        public Criteria andFcmReturnCityIsNull() {
            addCriterion("fcm_return_city is null");
            return (Criteria) this;
        }

        public Criteria andFcmReturnCityIsNotNull() {
            addCriterion("fcm_return_city is not null");
            return (Criteria) this;
        }

        public Criteria andFcmReturnCityEqualTo(Long value) {
            addCriterion("fcm_return_city =", value, "fcmReturnCity");
            return (Criteria) this;
        }

        public Criteria andFcmReturnCityNotEqualTo(Long value) {
            addCriterion("fcm_return_city <>", value, "fcmReturnCity");
            return (Criteria) this;
        }

        public Criteria andFcmReturnCityGreaterThan(Long value) {
            addCriterion("fcm_return_city >", value, "fcmReturnCity");
            return (Criteria) this;
        }

        public Criteria andFcmReturnCityGreaterThanOrEqualTo(Long value) {
            addCriterion("fcm_return_city >=", value, "fcmReturnCity");
            return (Criteria) this;
        }

        public Criteria andFcmReturnCityLessThan(Long value) {
            addCriterion("fcm_return_city <", value, "fcmReturnCity");
            return (Criteria) this;
        }

        public Criteria andFcmReturnCityLessThanOrEqualTo(Long value) {
            addCriterion("fcm_return_city <=", value, "fcmReturnCity");
            return (Criteria) this;
        }

        public Criteria andFcmReturnCityIn(List<Long> values) {
            addCriterion("fcm_return_city in", values, "fcmReturnCity");
            return (Criteria) this;
        }

        public Criteria andFcmReturnCityNotIn(List<Long> values) {
            addCriterion("fcm_return_city not in", values, "fcmReturnCity");
            return (Criteria) this;
        }

        public Criteria andFcmReturnCityBetween(Long value1, Long value2) {
            addCriterion("fcm_return_city between", value1, value2, "fcmReturnCity");
            return (Criteria) this;
        }

        public Criteria andFcmReturnCityNotBetween(Long value1, Long value2) {
            addCriterion("fcm_return_city not between", value1, value2, "fcmReturnCity");
            return (Criteria) this;
        }

        public Criteria andFcmDeliverTypeIsNull() {
            addCriterion("fcm_deliver_type is null");
            return (Criteria) this;
        }

        public Criteria andFcmDeliverTypeIsNotNull() {
            addCriterion("fcm_deliver_type is not null");
            return (Criteria) this;
        }

        public Criteria andFcmDeliverTypeEqualTo(Integer value) {
            addCriterion("fcm_deliver_type =", value, "fcmDeliverType");
            return (Criteria) this;
        }

        public Criteria andFcmDeliverTypeNotEqualTo(Integer value) {
            addCriterion("fcm_deliver_type <>", value, "fcmDeliverType");
            return (Criteria) this;
        }

        public Criteria andFcmDeliverTypeGreaterThan(Integer value) {
            addCriterion("fcm_deliver_type >", value, "fcmDeliverType");
            return (Criteria) this;
        }

        public Criteria andFcmDeliverTypeGreaterThanOrEqualTo(Integer value) {
            addCriterion("fcm_deliver_type >=", value, "fcmDeliverType");
            return (Criteria) this;
        }

        public Criteria andFcmDeliverTypeLessThan(Integer value) {
            addCriterion("fcm_deliver_type <", value, "fcmDeliverType");
            return (Criteria) this;
        }

        public Criteria andFcmDeliverTypeLessThanOrEqualTo(Integer value) {
            addCriterion("fcm_deliver_type <=", value, "fcmDeliverType");
            return (Criteria) this;
        }

        public Criteria andFcmDeliverTypeIn(List<Integer> values) {
            addCriterion("fcm_deliver_type in", values, "fcmDeliverType");
            return (Criteria) this;
        }

        public Criteria andFcmDeliverTypeNotIn(List<Integer> values) {
            addCriterion("fcm_deliver_type not in", values, "fcmDeliverType");
            return (Criteria) this;
        }

        public Criteria andFcmDeliverTypeBetween(Integer value1, Integer value2) {
            addCriterion("fcm_deliver_type between", value1, value2, "fcmDeliverType");
            return (Criteria) this;
        }

        public Criteria andFcmDeliverTypeNotBetween(Integer value1, Integer value2) {
            addCriterion("fcm_deliver_type not between", value1, value2, "fcmDeliverType");
            return (Criteria) this;
        }

        public Criteria andFcmSubletIsNull() {
            addCriterion("fcm_sublet is null");
            return (Criteria) this;
        }

        public Criteria andFcmSubletIsNotNull() {
            addCriterion("fcm_sublet is not null");
            return (Criteria) this;
        }

        public Criteria andFcmSubletEqualTo(Integer value) {
            addCriterion("fcm_sublet =", value, "fcmSublet");
            return (Criteria) this;
        }

        public Criteria andFcmSubletNotEqualTo(Integer value) {
            addCriterion("fcm_sublet <>", value, "fcmSublet");
            return (Criteria) this;
        }

        public Criteria andFcmSubletGreaterThan(Integer value) {
            addCriterion("fcm_sublet >", value, "fcmSublet");
            return (Criteria) this;
        }

        public Criteria andFcmSubletGreaterThanOrEqualTo(Integer value) {
            addCriterion("fcm_sublet >=", value, "fcmSublet");
            return (Criteria) this;
        }

        public Criteria andFcmSubletLessThan(Integer value) {
            addCriterion("fcm_sublet <", value, "fcmSublet");
            return (Criteria) this;
        }

        public Criteria andFcmSubletLessThanOrEqualTo(Integer value) {
            addCriterion("fcm_sublet <=", value, "fcmSublet");
            return (Criteria) this;
        }

        public Criteria andFcmSubletIn(List<Integer> values) {
            addCriterion("fcm_sublet in", values, "fcmSublet");
            return (Criteria) this;
        }

        public Criteria andFcmSubletNotIn(List<Integer> values) {
            addCriterion("fcm_sublet not in", values, "fcmSublet");
            return (Criteria) this;
        }

        public Criteria andFcmSubletBetween(Integer value1, Integer value2) {
            addCriterion("fcm_sublet between", value1, value2, "fcmSublet");
            return (Criteria) this;
        }

        public Criteria andFcmSubletNotBetween(Integer value1, Integer value2) {
            addCriterion("fcm_sublet not between", value1, value2, "fcmSublet");
            return (Criteria) this;
        }

        public Criteria andFcmSignedAddrIsNull() {
            addCriterion("fcm_signed_addr is null");
            return (Criteria) this;
        }

        public Criteria andFcmSignedAddrIsNotNull() {
            addCriterion("fcm_signed_addr is not null");
            return (Criteria) this;
        }

        public Criteria andFcmSignedAddrEqualTo(Long value) {
            addCriterion("fcm_signed_addr =", value, "fcmSignedAddr");
            return (Criteria) this;
        }

        public Criteria andFcmSignedAddrNotEqualTo(Long value) {
            addCriterion("fcm_signed_addr <>", value, "fcmSignedAddr");
            return (Criteria) this;
        }

        public Criteria andFcmSignedAddrGreaterThan(Long value) {
            addCriterion("fcm_signed_addr >", value, "fcmSignedAddr");
            return (Criteria) this;
        }

        public Criteria andFcmSignedAddrGreaterThanOrEqualTo(Long value) {
            addCriterion("fcm_signed_addr >=", value, "fcmSignedAddr");
            return (Criteria) this;
        }

        public Criteria andFcmSignedAddrLessThan(Long value) {
            addCriterion("fcm_signed_addr <", value, "fcmSignedAddr");
            return (Criteria) this;
        }

        public Criteria andFcmSignedAddrLessThanOrEqualTo(Long value) {
            addCriterion("fcm_signed_addr <=", value, "fcmSignedAddr");
            return (Criteria) this;
        }

        public Criteria andFcmSignedAddrIn(List<Long> values) {
            addCriterion("fcm_signed_addr in", values, "fcmSignedAddr");
            return (Criteria) this;
        }

        public Criteria andFcmSignedAddrNotIn(List<Long> values) {
            addCriterion("fcm_signed_addr not in", values, "fcmSignedAddr");
            return (Criteria) this;
        }

        public Criteria andFcmSignedAddrBetween(Long value1, Long value2) {
            addCriterion("fcm_signed_addr between", value1, value2, "fcmSignedAddr");
            return (Criteria) this;
        }

        public Criteria andFcmSignedAddrNotBetween(Long value1, Long value2) {
            addCriterion("fcm_signed_addr not between", value1, value2, "fcmSignedAddr");
            return (Criteria) this;
        }

        public Criteria andFcmCreatePhoneIsNull() {
            addCriterion("fcm_create_phone is null");
            return (Criteria) this;
        }

        public Criteria andFcmCreatePhoneIsNotNull() {
            addCriterion("fcm_create_phone is not null");
            return (Criteria) this;
        }

        public Criteria andFcmCreatePhoneEqualTo(String value) {
            addCriterion("fcm_create_phone =", value, "fcmCreatePhone");
            return (Criteria) this;
        }

        public Criteria andFcmCreatePhoneNotEqualTo(String value) {
            addCriterion("fcm_create_phone <>", value, "fcmCreatePhone");
            return (Criteria) this;
        }

        public Criteria andFcmCreatePhoneGreaterThan(String value) {
            addCriterion("fcm_create_phone >", value, "fcmCreatePhone");
            return (Criteria) this;
        }

        public Criteria andFcmCreatePhoneGreaterThanOrEqualTo(String value) {
            addCriterion("fcm_create_phone >=", value, "fcmCreatePhone");
            return (Criteria) this;
        }

        public Criteria andFcmCreatePhoneLessThan(String value) {
            addCriterion("fcm_create_phone <", value, "fcmCreatePhone");
            return (Criteria) this;
        }

        public Criteria andFcmCreatePhoneLessThanOrEqualTo(String value) {
            addCriterion("fcm_create_phone <=", value, "fcmCreatePhone");
            return (Criteria) this;
        }

        public Criteria andFcmCreatePhoneLike(String value) {
            addCriterion("fcm_create_phone like", value, "fcmCreatePhone");
            return (Criteria) this;
        }

        public Criteria andFcmCreatePhoneNotLike(String value) {
            addCriterion("fcm_create_phone not like", value, "fcmCreatePhone");
            return (Criteria) this;
        }

        public Criteria andFcmCreatePhoneIn(List<String> values) {
            addCriterion("fcm_create_phone in", values, "fcmCreatePhone");
            return (Criteria) this;
        }

        public Criteria andFcmCreatePhoneNotIn(List<String> values) {
            addCriterion("fcm_create_phone not in", values, "fcmCreatePhone");
            return (Criteria) this;
        }

        public Criteria andFcmCreatePhoneBetween(String value1, String value2) {
            addCriterion("fcm_create_phone between", value1, value2, "fcmCreatePhone");
            return (Criteria) this;
        }

        public Criteria andFcmCreatePhoneNotBetween(String value1, String value2) {
            addCriterion("fcm_create_phone not between", value1, value2, "fcmCreatePhone");
            return (Criteria) this;
        }

        public Criteria andFcmUseIsNull() {
            addCriterion("fcm_use is null");
            return (Criteria) this;
        }

        public Criteria andFcmUseIsNotNull() {
            addCriterion("fcm_use is not null");
            return (Criteria) this;
        }

        public Criteria andFcmUseEqualTo(String value) {
            addCriterion("fcm_use =", value, "fcmUse");
            return (Criteria) this;
        }

        public Criteria andFcmUseNotEqualTo(String value) {
            addCriterion("fcm_use <>", value, "fcmUse");
            return (Criteria) this;
        }

        public Criteria andFcmUseGreaterThan(String value) {
            addCriterion("fcm_use >", value, "fcmUse");
            return (Criteria) this;
        }

        public Criteria andFcmUseGreaterThanOrEqualTo(String value) {
            addCriterion("fcm_use >=", value, "fcmUse");
            return (Criteria) this;
        }

        public Criteria andFcmUseLessThan(String value) {
            addCriterion("fcm_use <", value, "fcmUse");
            return (Criteria) this;
        }

        public Criteria andFcmUseLessThanOrEqualTo(String value) {
            addCriterion("fcm_use <=", value, "fcmUse");
            return (Criteria) this;
        }

        public Criteria andFcmUseLike(String value) {
            addCriterion("fcm_use like", value, "fcmUse");
            return (Criteria) this;
        }

        public Criteria andFcmUseNotLike(String value) {
            addCriterion("fcm_use not like", value, "fcmUse");
            return (Criteria) this;
        }

        public Criteria andFcmUseIn(List<String> values) {
            addCriterion("fcm_use in", values, "fcmUse");
            return (Criteria) this;
        }

        public Criteria andFcmUseNotIn(List<String> values) {
            addCriterion("fcm_use not in", values, "fcmUse");
            return (Criteria) this;
        }

        public Criteria andFcmUseBetween(String value1, String value2) {
            addCriterion("fcm_use between", value1, value2, "fcmUse");
            return (Criteria) this;
        }

        public Criteria andFcmUseNotBetween(String value1, String value2) {
            addCriterion("fcm_use not between", value1, value2, "fcmUse");
            return (Criteria) this;
        }

        public Criteria andRemarkIsNull() {
            addCriterion("remark is null");
            return (Criteria) this;
        }

        public Criteria andRemarkIsNotNull() {
            addCriterion("remark is not null");
            return (Criteria) this;
        }

        public Criteria andRemarkEqualTo(String value) {
            addCriterion("remark =", value, "remark");
            return (Criteria) this;
        }

        public Criteria andRemarkNotEqualTo(String value) {
            addCriterion("remark <>", value, "remark");
            return (Criteria) this;
        }

        public Criteria andRemarkGreaterThan(String value) {
            addCriterion("remark >", value, "remark");
            return (Criteria) this;
        }

        public Criteria andRemarkGreaterThanOrEqualTo(String value) {
            addCriterion("remark >=", value, "remark");
            return (Criteria) this;
        }

        public Criteria andRemarkLessThan(String value) {
            addCriterion("remark <", value, "remark");
            return (Criteria) this;
        }

        public Criteria andRemarkLessThanOrEqualTo(String value) {
            addCriterion("remark <=", value, "remark");
            return (Criteria) this;
        }

        public Criteria andRemarkLike(String value) {
            addCriterion("remark like", value, "remark");
            return (Criteria) this;
        }

        public Criteria andRemarkNotLike(String value) {
            addCriterion("remark not like", value, "remark");
            return (Criteria) this;
        }

        public Criteria andRemarkIn(List<String> values) {
            addCriterion("remark in", values, "remark");
            return (Criteria) this;
        }

        public Criteria andRemarkNotIn(List<String> values) {
            addCriterion("remark not in", values, "remark");
            return (Criteria) this;
        }

        public Criteria andRemarkBetween(String value1, String value2) {
            addCriterion("remark between", value1, value2, "remark");
            return (Criteria) this;
        }

        public Criteria andRemarkNotBetween(String value1, String value2) {
            addCriterion("remark not between", value1, value2, "remark");
            return (Criteria) this;
        }

        public Criteria andCreateuserIsNull() {
            addCriterion("createuser is null");
            return (Criteria) this;
        }

        public Criteria andCreateuserIsNotNull() {
            addCriterion("createuser is not null");
            return (Criteria) this;
        }

        public Criteria andCreateuserEqualTo(String value) {
            addCriterion("createuser =", value, "createuser");
            return (Criteria) this;
        }

        public Criteria andCreateuserNotEqualTo(String value) {
            addCriterion("createuser <>", value, "createuser");
            return (Criteria) this;
        }

        public Criteria andCreateuserGreaterThan(String value) {
            addCriterion("createuser >", value, "createuser");
            return (Criteria) this;
        }

        public Criteria andCreateuserGreaterThanOrEqualTo(String value) {
            addCriterion("createuser >=", value, "createuser");
            return (Criteria) this;
        }

        public Criteria andCreateuserLessThan(String value) {
            addCriterion("createuser <", value, "createuser");
            return (Criteria) this;
        }

        public Criteria andCreateuserLessThanOrEqualTo(String value) {
            addCriterion("createuser <=", value, "createuser");
            return (Criteria) this;
        }

        public Criteria andCreateuserLike(String value) {
            addCriterion("createuser like", value, "createuser");
            return (Criteria) this;
        }

        public Criteria andCreateuserNotLike(String value) {
            addCriterion("createuser not like", value, "createuser");
            return (Criteria) this;
        }

        public Criteria andCreateuserIn(List<String> values) {
            addCriterion("createuser in", values, "createuser");
            return (Criteria) this;
        }

        public Criteria andCreateuserNotIn(List<String> values) {
            addCriterion("createuser not in", values, "createuser");
            return (Criteria) this;
        }

        public Criteria andCreateuserBetween(String value1, String value2) {
            addCriterion("createuser between", value1, value2, "createuser");
            return (Criteria) this;
        }

        public Criteria andCreateuserNotBetween(String value1, String value2) {
            addCriterion("createuser not between", value1, value2, "createuser");
            return (Criteria) this;
        }

        public Criteria andCreatetimeIsNull() {
            addCriterion("createtime is null");
            return (Criteria) this;
        }

        public Criteria andCreatetimeIsNotNull() {
            addCriterion("createtime is not null");
            return (Criteria) this;
        }

        public Criteria andCreatetimeEqualTo(Date value) {
            addCriterion("createtime =", value, "createtime");
            return (Criteria) this;
        }

        public Criteria andCreatetimeNotEqualTo(Date value) {
            addCriterion("createtime <>", value, "createtime");
            return (Criteria) this;
        }

        public Criteria andCreatetimeGreaterThan(Date value) {
            addCriterion("createtime >", value, "createtime");
            return (Criteria) this;
        }

        public Criteria andCreatetimeGreaterThanOrEqualTo(Date value) {
            addCriterion("createtime >=", value, "createtime");
            return (Criteria) this;
        }

        public Criteria andCreatetimeLessThan(Date value) {
            addCriterion("createtime <", value, "createtime");
            return (Criteria) this;
        }

        public Criteria andCreatetimeLessThanOrEqualTo(Date value) {
            addCriterion("createtime <=", value, "createtime");
            return (Criteria) this;
        }

        public Criteria andCreatetimeIn(List<Date> values) {
            addCriterion("createtime in", values, "createtime");
            return (Criteria) this;
        }

        public Criteria andCreatetimeNotIn(List<Date> values) {
            addCriterion("createtime not in", values, "createtime");
            return (Criteria) this;
        }

        public Criteria andCreatetimeBetween(Date value1, Date value2) {
            addCriterion("createtime between", value1, value2, "createtime");
            return (Criteria) this;
        }

        public Criteria andCreatetimeNotBetween(Date value1, Date value2) {
            addCriterion("createtime not between", value1, value2, "createtime");
            return (Criteria) this;
        }

        public Criteria andUpdateuserIsNull() {
            addCriterion("updateuser is null");
            return (Criteria) this;
        }

        public Criteria andUpdateuserIsNotNull() {
            addCriterion("updateuser is not null");
            return (Criteria) this;
        }

        public Criteria andUpdateuserEqualTo(String value) {
            addCriterion("updateuser =", value, "updateuser");
            return (Criteria) this;
        }

        public Criteria andUpdateuserNotEqualTo(String value) {
            addCriterion("updateuser <>", value, "updateuser");
            return (Criteria) this;
        }

        public Criteria andUpdateuserGreaterThan(String value) {
            addCriterion("updateuser >", value, "updateuser");
            return (Criteria) this;
        }

        public Criteria andUpdateuserGreaterThanOrEqualTo(String value) {
            addCriterion("updateuser >=", value, "updateuser");
            return (Criteria) this;
        }

        public Criteria andUpdateuserLessThan(String value) {
            addCriterion("updateuser <", value, "updateuser");
            return (Criteria) this;
        }

        public Criteria andUpdateuserLessThanOrEqualTo(String value) {
            addCriterion("updateuser <=", value, "updateuser");
            return (Criteria) this;
        }

        public Criteria andUpdateuserLike(String value) {
            addCriterion("updateuser like", value, "updateuser");
            return (Criteria) this;
        }

        public Criteria andUpdateuserNotLike(String value) {
            addCriterion("updateuser not like", value, "updateuser");
            return (Criteria) this;
        }

        public Criteria andUpdateuserIn(List<String> values) {
            addCriterion("updateuser in", values, "updateuser");
            return (Criteria) this;
        }

        public Criteria andUpdateuserNotIn(List<String> values) {
            addCriterion("updateuser not in", values, "updateuser");
            return (Criteria) this;
        }

        public Criteria andUpdateuserBetween(String value1, String value2) {
            addCriterion("updateuser between", value1, value2, "updateuser");
            return (Criteria) this;
        }

        public Criteria andUpdateuserNotBetween(String value1, String value2) {
            addCriterion("updateuser not between", value1, value2, "updateuser");
            return (Criteria) this;
        }

        public Criteria andUpdatetimeIsNull() {
            addCriterion("updatetime is null");
            return (Criteria) this;
        }

        public Criteria andUpdatetimeIsNotNull() {
            addCriterion("updatetime is not null");
            return (Criteria) this;
        }

        public Criteria andUpdatetimeEqualTo(Date value) {
            addCriterion("updatetime =", value, "updatetime");
            return (Criteria) this;
        }

        public Criteria andUpdatetimeNotEqualTo(Date value) {
            addCriterion("updatetime <>", value, "updatetime");
            return (Criteria) this;
        }

        public Criteria andUpdatetimeGreaterThan(Date value) {
            addCriterion("updatetime >", value, "updatetime");
            return (Criteria) this;
        }

        public Criteria andUpdatetimeGreaterThanOrEqualTo(Date value) {
            addCriterion("updatetime >=", value, "updatetime");
            return (Criteria) this;
        }

        public Criteria andUpdatetimeLessThan(Date value) {
            addCriterion("updatetime <", value, "updatetime");
            return (Criteria) this;
        }

        public Criteria andUpdatetimeLessThanOrEqualTo(Date value) {
            addCriterion("updatetime <=", value, "updatetime");
            return (Criteria) this;
        }

        public Criteria andUpdatetimeIn(List<Date> values) {
            addCriterion("updatetime in", values, "updatetime");
            return (Criteria) this;
        }

        public Criteria andUpdatetimeNotIn(List<Date> values) {
            addCriterion("updatetime not in", values, "updatetime");
            return (Criteria) this;
        }

        public Criteria andUpdatetimeBetween(Date value1, Date value2) {
            addCriterion("updatetime between", value1, value2, "updatetime");
            return (Criteria) this;
        }

        public Criteria andUpdatetimeNotBetween(Date value1, Date value2) {
            addCriterion("updatetime not between", value1, value2, "updatetime");
            return (Criteria) this;
        }

        public Criteria andDrIsNull() {
            addCriterion("dr is null");
            return (Criteria) this;
        }

        public Criteria andDrIsNotNull() {
            addCriterion("dr is not null");
            return (Criteria) this;
        }

        public Criteria andDrEqualTo(Integer value) {
            addCriterion("dr =", value, "dr");
            return (Criteria) this;
        }

        public Criteria andDrNotEqualTo(Integer value) {
            addCriterion("dr <>", value, "dr");
            return (Criteria) this;
        }

        public Criteria andDrGreaterThan(Integer value) {
            addCriterion("dr >", value, "dr");
            return (Criteria) this;
        }

        public Criteria andDrGreaterThanOrEqualTo(Integer value) {
            addCriterion("dr >=", value, "dr");
            return (Criteria) this;
        }

        public Criteria andDrLessThan(Integer value) {
            addCriterion("dr <", value, "dr");
            return (Criteria) this;
        }

        public Criteria andDrLessThanOrEqualTo(Integer value) {
            addCriterion("dr <=", value, "dr");
            return (Criteria) this;
        }

        public Criteria andDrIn(List<Integer> values) {
            addCriterion("dr in", values, "dr");
            return (Criteria) this;
        }

        public Criteria andDrNotIn(List<Integer> values) {
            addCriterion("dr not in", values, "dr");
            return (Criteria) this;
        }

        public Criteria andDrBetween(Integer value1, Integer value2) {
            addCriterion("dr between", value1, value2, "dr");
            return (Criteria) this;
        }

        public Criteria andDrNotBetween(Integer value1, Integer value2) {
            addCriterion("dr not between", value1, value2, "dr");
            return (Criteria) this;
        }
    }

    public static class Criteria extends GeneratedCriteria {

        protected Criteria() {
            super();
        }
    }

    public static class Criterion {
        private final String condition;

        private Object value;

        private Object secondValue;

        private boolean noValue;

        private boolean singleValue;

        private boolean betweenValue;

        private boolean listValue;

        private final String typeHandler;

        public String getCondition() {
            return condition;
        }

        public Object getValue() {
            return value;
        }

        public Object getSecondValue() {
            return secondValue;
        }

        public boolean isNoValue() {
            return noValue;
        }

        public boolean isSingleValue() {
            return singleValue;
        }

        public boolean isBetweenValue() {
            return betweenValue;
        }

        public boolean isListValue() {
            return listValue;
        }

        public String getTypeHandler() {
            return typeHandler;
        }

        protected Criterion(String condition) {
            super();
            this.condition = condition;
            this.typeHandler = null;
            this.noValue = true;
        }

        protected Criterion(String condition, Object value, String typeHandler) {
            super();
            this.condition = condition;
            this.value = value;
            this.typeHandler = typeHandler;
            if (value instanceof List<?>) {
                this.listValue = true;
            } else {
                this.singleValue = true;
            }
        }

        protected Criterion(String condition, Object value) {
            this(condition, value, null);
        }

        protected Criterion(String condition, Object value, Object secondValue, String typeHandler) {
            super();
            this.condition = condition;
            this.value = value;
            this.secondValue = secondValue;
            this.typeHandler = typeHandler;
            this.betweenValue = true;
        }

        protected Criterion(String condition, Object value, Object secondValue) {
            this(condition, value, secondValue, null);
        }
    }
}
