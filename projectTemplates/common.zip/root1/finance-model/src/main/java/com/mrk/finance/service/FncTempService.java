package com.mrk.finance.service;

import com.github.pagehelper.PageInfo;
import com.mrk.finance.model.FncTemp;
import com.mrk.finance.queryvo.FncTempQueryVo;

import java.util.Date;
import java.util.List;

/**
 * @Description: FncTemp
 */
public interface FncTempService {
    /**
     * 分页查询
     *
     * @param queryVo 前端查询对象
     * @return 分页查询数据
     */
    PageInfo<FncTemp> page(FncTempQueryVo queryVo);

    /**
     * 列表查询
     * @param queryVo 前端查询对象
     * @return 分页查询数据
     */
    List<FncTemp> list(FncTempQueryVo queryVo);

    /**
     * 新增
     *
     * @param entity
     * @return 结果
     */
    int add(FncTemp entity);

    /**
     * 修改
     *
     * @param entity
     * @return 结果
     */
    int update(FncTemp entity);

    /**
     * 删除
     */
    int delete(Long id);

    /**
    * 通过ID查询
    * @param id
    */
    FncTemp getById(Long id);

    /**
     * 删除小于指定时间的数据
     * @param date 日期
     */
    void deleteByLessTime(Date date);

    /**
     * 根据操作标识删除临时表数据
     * @param operateCode
     */
  void deleteByOperateCode(String operateCode);
    /**
     * 根据操作标识获取错误数据
     * @param operateCode 操作标识
     * @return 错误的临时数据
     */
  List<FncTemp> selectErrorByOperateCode(String operateCode);
    /**
     * 根据操作标识符获取数据
     * @param operateCode 操作标识
     * @return 临时数据
     */
    List<FncTemp> selectByOperateCode(String operateCode);
}
