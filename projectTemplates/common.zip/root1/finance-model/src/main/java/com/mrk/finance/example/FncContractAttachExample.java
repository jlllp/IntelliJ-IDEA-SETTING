package com.mrk.finance.example;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

public class FncContractAttachExample {
    protected String orderByClause;

    protected boolean distinct;

    protected List<Criteria> oredCriteria;

    public FncContractAttachExample() {
        oredCriteria = new ArrayList<Criteria>();
    }

    public void setOrderByClause(String orderByClause) {
        this.orderByClause = orderByClause;
    }

    public String getOrderByClause() {
        return orderByClause;
    }

    public void setDistinct(boolean distinct) {
        this.distinct = distinct;
    }

    public boolean isDistinct() {
        return distinct;
    }

    public List<Criteria> getOredCriteria() {
        return oredCriteria;
    }

    public void or(Criteria criteria) {
        oredCriteria.add(criteria);
    }

    public Criteria or() {
        Criteria criteria = createCriteriaInternal();
        oredCriteria.add(criteria);
        return criteria;
    }

    public Criteria createCriteria() {
        Criteria criteria = createCriteriaInternal();
        if (oredCriteria.size() == 0) {
            oredCriteria.add(criteria);
        }
        return criteria;
    }

    protected Criteria createCriteriaInternal() {
        Criteria criteria = new Criteria();
        return criteria;
    }

    public void clear() {
        oredCriteria.clear();
        orderByClause = null;
        distinct = false;
    }

    protected abstract static class GeneratedCriteria {
        protected List<Criterion> criteria;

        protected GeneratedCriteria() {
            super();
            criteria = new ArrayList<Criterion>();
        }

        public boolean isValid() {
            return criteria.size() > 0;
        }

        public List<Criterion> getAllCriteria() {
            return criteria;
        }

        public List<Criterion> getCriteria() {
            return criteria;
        }

        protected void addCriterion(String condition) {
            if (condition == null) {
                throw new RuntimeException("Value for condition cannot be null");
            }
            criteria.add(new Criterion(condition));
        }

        protected void addCriterion(String condition, Object value, String property) {
            if (value == null) {
                throw new RuntimeException("Value for " + property + " cannot be null");
            }
            criteria.add(new Criterion(condition, value));
        }

        protected void addCriterion(String condition, Object value1, Object value2, String property) {
            if (value1 == null || value2 == null) {
                throw new RuntimeException("Between values for " + property + " cannot be null");
            }
            criteria.add(new Criterion(condition, value1, value2));
        }

        public Criteria andFcaIdIsNull() {
            addCriterion("fca_id is null");
            return (Criteria) this;
        }

        public Criteria andFcaIdIsNotNull() {
            addCriterion("fca_id is not null");
            return (Criteria) this;
        }

        public Criteria andFcaIdEqualTo(Long value) {
            addCriterion("fca_id =", value, "fcaId");
            return (Criteria) this;
        }

        public Criteria andFcaIdNotEqualTo(Long value) {
            addCriterion("fca_id <>", value, "fcaId");
            return (Criteria) this;
        }

        public Criteria andFcaIdGreaterThan(Long value) {
            addCriterion("fca_id >", value, "fcaId");
            return (Criteria) this;
        }

        public Criteria andFcaIdGreaterThanOrEqualTo(Long value) {
            addCriterion("fca_id >=", value, "fcaId");
            return (Criteria) this;
        }

        public Criteria andFcaIdLessThan(Long value) {
            addCriterion("fca_id <", value, "fcaId");
            return (Criteria) this;
        }

        public Criteria andFcaIdLessThanOrEqualTo(Long value) {
            addCriterion("fca_id <=", value, "fcaId");
            return (Criteria) this;
        }

        public Criteria andFcaIdIn(List<Long> values) {
            addCriterion("fca_id in", values, "fcaId");
            return (Criteria) this;
        }

        public Criteria andFcaIdNotIn(List<Long> values) {
            addCriterion("fca_id not in", values, "fcaId");
            return (Criteria) this;
        }

        public Criteria andFcaIdBetween(Long value1, Long value2) {
            addCriterion("fca_id between", value1, value2, "fcaId");
            return (Criteria) this;
        }

        public Criteria andFcaIdNotBetween(Long value1, Long value2) {
            addCriterion("fca_id not between", value1, value2, "fcaId");
            return (Criteria) this;
        }

        public Criteria andFcaContractIdIsNull() {
            addCriterion("fca_contract_id is null");
            return (Criteria) this;
        }

        public Criteria andFcaContractIdIsNotNull() {
            addCriterion("fca_contract_id is not null");
            return (Criteria) this;
        }

        public Criteria andFcaContractIdEqualTo(Long value) {
            addCriterion("fca_contract_id =", value, "fcaContractId");
            return (Criteria) this;
        }

        public Criteria andFcaContractIdNotEqualTo(Long value) {
            addCriterion("fca_contract_id <>", value, "fcaContractId");
            return (Criteria) this;
        }

        public Criteria andFcaContractIdGreaterThan(Long value) {
            addCriterion("fca_contract_id >", value, "fcaContractId");
            return (Criteria) this;
        }

        public Criteria andFcaContractIdGreaterThanOrEqualTo(Long value) {
            addCriterion("fca_contract_id >=", value, "fcaContractId");
            return (Criteria) this;
        }

        public Criteria andFcaContractIdLessThan(Long value) {
            addCriterion("fca_contract_id <", value, "fcaContractId");
            return (Criteria) this;
        }

        public Criteria andFcaContractIdLessThanOrEqualTo(Long value) {
            addCriterion("fca_contract_id <=", value, "fcaContractId");
            return (Criteria) this;
        }

        public Criteria andFcaContractIdIn(List<Long> values) {
            addCriterion("fca_contract_id in", values, "fcaContractId");
            return (Criteria) this;
        }

        public Criteria andFcaContractIdNotIn(List<Long> values) {
            addCriterion("fca_contract_id not in", values, "fcaContractId");
            return (Criteria) this;
        }

        public Criteria andFcaContractIdBetween(Long value1, Long value2) {
            addCriterion("fca_contract_id between", value1, value2, "fcaContractId");
            return (Criteria) this;
        }

        public Criteria andFcaContractIdNotBetween(Long value1, Long value2) {
            addCriterion("fca_contract_id not between", value1, value2, "fcaContractId");
            return (Criteria) this;
        }

        public Criteria andFcaLinkIsNull() {
            addCriterion("fca_link is null");
            return (Criteria) this;
        }

        public Criteria andFcaLinkIsNotNull() {
            addCriterion("fca_link is not null");
            return (Criteria) this;
        }

        public Criteria andFcaLinkEqualTo(String value) {
            addCriterion("fca_link =", value, "fcaLink");
            return (Criteria) this;
        }

        public Criteria andFcaLinkNotEqualTo(String value) {
            addCriterion("fca_link <>", value, "fcaLink");
            return (Criteria) this;
        }

        public Criteria andFcaLinkGreaterThan(String value) {
            addCriterion("fca_link >", value, "fcaLink");
            return (Criteria) this;
        }

        public Criteria andFcaLinkGreaterThanOrEqualTo(String value) {
            addCriterion("fca_link >=", value, "fcaLink");
            return (Criteria) this;
        }

        public Criteria andFcaLinkLessThan(String value) {
            addCriterion("fca_link <", value, "fcaLink");
            return (Criteria) this;
        }

        public Criteria andFcaLinkLessThanOrEqualTo(String value) {
            addCriterion("fca_link <=", value, "fcaLink");
            return (Criteria) this;
        }

        public Criteria andFcaLinkLike(String value) {
            addCriterion("fca_link like", value, "fcaLink");
            return (Criteria) this;
        }

        public Criteria andFcaLinkNotLike(String value) {
            addCriterion("fca_link not like", value, "fcaLink");
            return (Criteria) this;
        }

        public Criteria andFcaLinkIn(List<String> values) {
            addCriterion("fca_link in", values, "fcaLink");
            return (Criteria) this;
        }

        public Criteria andFcaLinkNotIn(List<String> values) {
            addCriterion("fca_link not in", values, "fcaLink");
            return (Criteria) this;
        }

        public Criteria andFcaLinkBetween(String value1, String value2) {
            addCriterion("fca_link between", value1, value2, "fcaLink");
            return (Criteria) this;
        }

        public Criteria andFcaLinkNotBetween(String value1, String value2) {
            addCriterion("fca_link not between", value1, value2, "fcaLink");
            return (Criteria) this;
        }

        public Criteria andFcaFileTypeIsNull() {
            addCriterion("fca_file_type is null");
            return (Criteria) this;
        }

        public Criteria andFcaFileTypeIsNotNull() {
            addCriterion("fca_file_type is not null");
            return (Criteria) this;
        }

        public Criteria andFcaFileTypeEqualTo(String value) {
            addCriterion("fca_file_type =", value, "fcaFileType");
            return (Criteria) this;
        }

        public Criteria andFcaFileTypeNotEqualTo(String value) {
            addCriterion("fca_file_type <>", value, "fcaFileType");
            return (Criteria) this;
        }

        public Criteria andFcaFileTypeGreaterThan(String value) {
            addCriterion("fca_file_type >", value, "fcaFileType");
            return (Criteria) this;
        }

        public Criteria andFcaFileTypeGreaterThanOrEqualTo(String value) {
            addCriterion("fca_file_type >=", value, "fcaFileType");
            return (Criteria) this;
        }

        public Criteria andFcaFileTypeLessThan(String value) {
            addCriterion("fca_file_type <", value, "fcaFileType");
            return (Criteria) this;
        }

        public Criteria andFcaFileTypeLessThanOrEqualTo(String value) {
            addCriterion("fca_file_type <=", value, "fcaFileType");
            return (Criteria) this;
        }

        public Criteria andFcaFileTypeLike(String value) {
            addCriterion("fca_file_type like", value, "fcaFileType");
            return (Criteria) this;
        }

        public Criteria andFcaFileTypeNotLike(String value) {
            addCriterion("fca_file_type not like", value, "fcaFileType");
            return (Criteria) this;
        }

        public Criteria andFcaFileTypeIn(List<String> values) {
            addCriterion("fca_file_type in", values, "fcaFileType");
            return (Criteria) this;
        }

        public Criteria andFcaFileTypeNotIn(List<String> values) {
            addCriterion("fca_file_type not in", values, "fcaFileType");
            return (Criteria) this;
        }

        public Criteria andFcaFileTypeBetween(String value1, String value2) {
            addCriterion("fca_file_type between", value1, value2, "fcaFileType");
            return (Criteria) this;
        }

        public Criteria andFcaFileTypeNotBetween(String value1, String value2) {
            addCriterion("fca_file_type not between", value1, value2, "fcaFileType");
            return (Criteria) this;
        }

        public Criteria andRemarkIsNull() {
            addCriterion("remark is null");
            return (Criteria) this;
        }

        public Criteria andRemarkIsNotNull() {
            addCriterion("remark is not null");
            return (Criteria) this;
        }

        public Criteria andRemarkEqualTo(String value) {
            addCriterion("remark =", value, "remark");
            return (Criteria) this;
        }

        public Criteria andRemarkNotEqualTo(String value) {
            addCriterion("remark <>", value, "remark");
            return (Criteria) this;
        }

        public Criteria andRemarkGreaterThan(String value) {
            addCriterion("remark >", value, "remark");
            return (Criteria) this;
        }

        public Criteria andRemarkGreaterThanOrEqualTo(String value) {
            addCriterion("remark >=", value, "remark");
            return (Criteria) this;
        }

        public Criteria andRemarkLessThan(String value) {
            addCriterion("remark <", value, "remark");
            return (Criteria) this;
        }

        public Criteria andRemarkLessThanOrEqualTo(String value) {
            addCriterion("remark <=", value, "remark");
            return (Criteria) this;
        }

        public Criteria andRemarkLike(String value) {
            addCriterion("remark like", value, "remark");
            return (Criteria) this;
        }

        public Criteria andRemarkNotLike(String value) {
            addCriterion("remark not like", value, "remark");
            return (Criteria) this;
        }

        public Criteria andRemarkIn(List<String> values) {
            addCriterion("remark in", values, "remark");
            return (Criteria) this;
        }

        public Criteria andRemarkNotIn(List<String> values) {
            addCriterion("remark not in", values, "remark");
            return (Criteria) this;
        }

        public Criteria andRemarkBetween(String value1, String value2) {
            addCriterion("remark between", value1, value2, "remark");
            return (Criteria) this;
        }

        public Criteria andRemarkNotBetween(String value1, String value2) {
            addCriterion("remark not between", value1, value2, "remark");
            return (Criteria) this;
        }

        public Criteria andCreatetimeIsNull() {
            addCriterion("createtime is null");
            return (Criteria) this;
        }

        public Criteria andCreatetimeIsNotNull() {
            addCriterion("createtime is not null");
            return (Criteria) this;
        }

        public Criteria andCreatetimeEqualTo(Date value) {
            addCriterion("createtime =", value, "createtime");
            return (Criteria) this;
        }

        public Criteria andCreatetimeNotEqualTo(Date value) {
            addCriterion("createtime <>", value, "createtime");
            return (Criteria) this;
        }

        public Criteria andCreatetimeGreaterThan(Date value) {
            addCriterion("createtime >", value, "createtime");
            return (Criteria) this;
        }

        public Criteria andCreatetimeGreaterThanOrEqualTo(Date value) {
            addCriterion("createtime >=", value, "createtime");
            return (Criteria) this;
        }

        public Criteria andCreatetimeLessThan(Date value) {
            addCriterion("createtime <", value, "createtime");
            return (Criteria) this;
        }

        public Criteria andCreatetimeLessThanOrEqualTo(Date value) {
            addCriterion("createtime <=", value, "createtime");
            return (Criteria) this;
        }

        public Criteria andCreatetimeIn(List<Date> values) {
            addCriterion("createtime in", values, "createtime");
            return (Criteria) this;
        }

        public Criteria andCreatetimeNotIn(List<Date> values) {
            addCriterion("createtime not in", values, "createtime");
            return (Criteria) this;
        }

        public Criteria andCreatetimeBetween(Date value1, Date value2) {
            addCriterion("createtime between", value1, value2, "createtime");
            return (Criteria) this;
        }

        public Criteria andCreatetimeNotBetween(Date value1, Date value2) {
            addCriterion("createtime not between", value1, value2, "createtime");
            return (Criteria) this;
        }

        public Criteria andCreateuserIsNull() {
            addCriterion("createuser is null");
            return (Criteria) this;
        }

        public Criteria andCreateuserIsNotNull() {
            addCriterion("createuser is not null");
            return (Criteria) this;
        }

        public Criteria andCreateuserEqualTo(String value) {
            addCriterion("createuser =", value, "createuser");
            return (Criteria) this;
        }

        public Criteria andCreateuserNotEqualTo(String value) {
            addCriterion("createuser <>", value, "createuser");
            return (Criteria) this;
        }

        public Criteria andCreateuserGreaterThan(String value) {
            addCriterion("createuser >", value, "createuser");
            return (Criteria) this;
        }

        public Criteria andCreateuserGreaterThanOrEqualTo(String value) {
            addCriterion("createuser >=", value, "createuser");
            return (Criteria) this;
        }

        public Criteria andCreateuserLessThan(String value) {
            addCriterion("createuser <", value, "createuser");
            return (Criteria) this;
        }

        public Criteria andCreateuserLessThanOrEqualTo(String value) {
            addCriterion("createuser <=", value, "createuser");
            return (Criteria) this;
        }

        public Criteria andCreateuserLike(String value) {
            addCriterion("createuser like", value, "createuser");
            return (Criteria) this;
        }

        public Criteria andCreateuserNotLike(String value) {
            addCriterion("createuser not like", value, "createuser");
            return (Criteria) this;
        }

        public Criteria andCreateuserIn(List<String> values) {
            addCriterion("createuser in", values, "createuser");
            return (Criteria) this;
        }

        public Criteria andCreateuserNotIn(List<String> values) {
            addCriterion("createuser not in", values, "createuser");
            return (Criteria) this;
        }

        public Criteria andCreateuserBetween(String value1, String value2) {
            addCriterion("createuser between", value1, value2, "createuser");
            return (Criteria) this;
        }

        public Criteria andCreateuserNotBetween(String value1, String value2) {
            addCriterion("createuser not between", value1, value2, "createuser");
            return (Criteria) this;
        }

        public Criteria andUpdatetimeIsNull() {
            addCriterion("updatetime is null");
            return (Criteria) this;
        }

        public Criteria andUpdatetimeIsNotNull() {
            addCriterion("updatetime is not null");
            return (Criteria) this;
        }

        public Criteria andUpdatetimeEqualTo(Date value) {
            addCriterion("updatetime =", value, "updatetime");
            return (Criteria) this;
        }

        public Criteria andUpdatetimeNotEqualTo(Date value) {
            addCriterion("updatetime <>", value, "updatetime");
            return (Criteria) this;
        }

        public Criteria andUpdatetimeGreaterThan(Date value) {
            addCriterion("updatetime >", value, "updatetime");
            return (Criteria) this;
        }

        public Criteria andUpdatetimeGreaterThanOrEqualTo(Date value) {
            addCriterion("updatetime >=", value, "updatetime");
            return (Criteria) this;
        }

        public Criteria andUpdatetimeLessThan(Date value) {
            addCriterion("updatetime <", value, "updatetime");
            return (Criteria) this;
        }

        public Criteria andUpdatetimeLessThanOrEqualTo(Date value) {
            addCriterion("updatetime <=", value, "updatetime");
            return (Criteria) this;
        }

        public Criteria andUpdatetimeIn(List<Date> values) {
            addCriterion("updatetime in", values, "updatetime");
            return (Criteria) this;
        }

        public Criteria andUpdatetimeNotIn(List<Date> values) {
            addCriterion("updatetime not in", values, "updatetime");
            return (Criteria) this;
        }

        public Criteria andUpdatetimeBetween(Date value1, Date value2) {
            addCriterion("updatetime between", value1, value2, "updatetime");
            return (Criteria) this;
        }

        public Criteria andUpdatetimeNotBetween(Date value1, Date value2) {
            addCriterion("updatetime not between", value1, value2, "updatetime");
            return (Criteria) this;
        }

        public Criteria andUpdateuserIsNull() {
            addCriterion("updateuser is null");
            return (Criteria) this;
        }

        public Criteria andUpdateuserIsNotNull() {
            addCriterion("updateuser is not null");
            return (Criteria) this;
        }

        public Criteria andUpdateuserEqualTo(String value) {
            addCriterion("updateuser =", value, "updateuser");
            return (Criteria) this;
        }

        public Criteria andUpdateuserNotEqualTo(String value) {
            addCriterion("updateuser <>", value, "updateuser");
            return (Criteria) this;
        }

        public Criteria andUpdateuserGreaterThan(String value) {
            addCriterion("updateuser >", value, "updateuser");
            return (Criteria) this;
        }

        public Criteria andUpdateuserGreaterThanOrEqualTo(String value) {
            addCriterion("updateuser >=", value, "updateuser");
            return (Criteria) this;
        }

        public Criteria andUpdateuserLessThan(String value) {
            addCriterion("updateuser <", value, "updateuser");
            return (Criteria) this;
        }

        public Criteria andUpdateuserLessThanOrEqualTo(String value) {
            addCriterion("updateuser <=", value, "updateuser");
            return (Criteria) this;
        }

        public Criteria andUpdateuserLike(String value) {
            addCriterion("updateuser like", value, "updateuser");
            return (Criteria) this;
        }

        public Criteria andUpdateuserNotLike(String value) {
            addCriterion("updateuser not like", value, "updateuser");
            return (Criteria) this;
        }

        public Criteria andUpdateuserIn(List<String> values) {
            addCriterion("updateuser in", values, "updateuser");
            return (Criteria) this;
        }

        public Criteria andUpdateuserNotIn(List<String> values) {
            addCriterion("updateuser not in", values, "updateuser");
            return (Criteria) this;
        }

        public Criteria andUpdateuserBetween(String value1, String value2) {
            addCriterion("updateuser between", value1, value2, "updateuser");
            return (Criteria) this;
        }

        public Criteria andUpdateuserNotBetween(String value1, String value2) {
            addCriterion("updateuser not between", value1, value2, "updateuser");
            return (Criteria) this;
        }

        public Criteria andDrIsNull() {
            addCriterion("dr is null");
            return (Criteria) this;
        }

        public Criteria andDrIsNotNull() {
            addCriterion("dr is not null");
            return (Criteria) this;
        }

        public Criteria andDrEqualTo(Integer value) {
            addCriterion("dr =", value, "dr");
            return (Criteria) this;
        }

        public Criteria andDrNotEqualTo(Integer value) {
            addCriterion("dr <>", value, "dr");
            return (Criteria) this;
        }

        public Criteria andDrGreaterThan(Integer value) {
            addCriterion("dr >", value, "dr");
            return (Criteria) this;
        }

        public Criteria andDrGreaterThanOrEqualTo(Integer value) {
            addCriterion("dr >=", value, "dr");
            return (Criteria) this;
        }

        public Criteria andDrLessThan(Integer value) {
            addCriterion("dr <", value, "dr");
            return (Criteria) this;
        }

        public Criteria andDrLessThanOrEqualTo(Integer value) {
            addCriterion("dr <=", value, "dr");
            return (Criteria) this;
        }

        public Criteria andDrIn(List<Integer> values) {
            addCriterion("dr in", values, "dr");
            return (Criteria) this;
        }

        public Criteria andDrNotIn(List<Integer> values) {
            addCriterion("dr not in", values, "dr");
            return (Criteria) this;
        }

        public Criteria andDrBetween(Integer value1, Integer value2) {
            addCriterion("dr between", value1, value2, "dr");
            return (Criteria) this;
        }

        public Criteria andDrNotBetween(Integer value1, Integer value2) {
            addCriterion("dr not between", value1, value2, "dr");
            return (Criteria) this;
        }
    }

    public static class Criteria extends GeneratedCriteria {

        protected Criteria() {
            super();
        }
    }

    public static class Criterion {
        private String condition;

        private Object value;

        private Object secondValue;

        private boolean noValue;

        private boolean singleValue;

        private boolean betweenValue;

        private boolean listValue;

        private String typeHandler;

        public String getCondition() {
            return condition;
        }

        public Object getValue() {
            return value;
        }

        public Object getSecondValue() {
            return secondValue;
        }

        public boolean isNoValue() {
            return noValue;
        }

        public boolean isSingleValue() {
            return singleValue;
        }

        public boolean isBetweenValue() {
            return betweenValue;
        }

        public boolean isListValue() {
            return listValue;
        }

        public String getTypeHandler() {
            return typeHandler;
        }

        protected Criterion(String condition) {
            super();
            this.condition = condition;
            this.typeHandler = null;
            this.noValue = true;
        }

        protected Criterion(String condition, Object value, String typeHandler) {
            super();
            this.condition = condition;
            this.value = value;
            this.typeHandler = typeHandler;
            if (value instanceof List<?>) {
                this.listValue = true;
            } else {
                this.singleValue = true;
            }
        }

        protected Criterion(String condition, Object value) {
            this(condition, value, null);
        }

        protected Criterion(String condition, Object value, Object secondValue, String typeHandler) {
            super();
            this.condition = condition;
            this.value = value;
            this.secondValue = secondValue;
            this.typeHandler = typeHandler;
            this.betweenValue = true;
        }

        protected Criterion(String condition, Object value, Object secondValue) {
            this(condition, value, secondValue, null);
        }
    }
}
