package com.mrk.finance.queryvo;

import com.mrk.common.base.BaseQueryVo;
import io.swagger.annotations.ApiModelProperty;
import lombok.Getter;
import lombok.Setter;
import com.fasterxml.jackson.annotation.JsonFormat;
import org.springframework.format.annotation.DateTimeFormat;

import java.util.List;

@Setter
@Getter
public class FncRentalFeesQueryVo extends BaseQueryVo {



    @ApiModelProperty(value = "主键 精确匹配")
    private Long frfIdEqualTo;

    @ApiModelProperty(value = "主键 模糊匹配")
    private Long frfIdLike;


    @ApiModelProperty(value = "租金包含费用明细 精确匹配")
    private String frfNameEqualTo;

    @ApiModelProperty(value = "租金包含费用明细 模糊匹配")
    private String frfNameLike;


    @ApiModelProperty(value = "租金包含费用标识 精确匹配")
    private String frfMarkEqualTo;

    @ApiModelProperty(value = "租金包含费用标识 模糊匹配")
    private String frfMarkLike;


    @ApiModelProperty(value = "是否可填写 精确匹配")
    private Integer frfWriteEqualTo;
    private List<Long> frfIdIn;

    @ApiModelProperty(value = "是否可填写 模糊匹配")
    private Integer frfWriteLike;
    }
