package com.mrk.finance.service.impl;

import java.util.List;
import java.util.Date;

import com.mrk.finance.example.FncContractAttachExample;
import com.mrk.finance.model.FncContractAttach;
import com.mrk.finance.dao.FncContractAttachMapper;
import com.mrk.finance.query.FncContractAttachQuery;
import com.mrk.finance.queryvo.FncContractAttachQueryVo;
import com.github.pagehelper.PageInfo;
import com.mrk.finance.service.FncContractAttachService;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import lombok.extern.slf4j.Slf4j;
import com.mrk.common.constant.BaseConstants;
import com.mrk.common.utils.page.PageUtils;
import com.mrk.common.utils.bean.BeanUtils;
import javax.annotation.Resource;


/**
 * @Description: FncContractAttachServiceImpl
 */
@Service
@Slf4j
public class FncContractAttachServiceImpl implements FncContractAttachService {
    @Resource
    private FncContractAttachMapper fncContractAttachMapper;

    @Override
    public PageInfo<FncContractAttach> page(FncContractAttachQueryVo queryVo){
        PageUtils.startPage();
        List<FncContractAttach> list = this.list(queryVo);
        return new PageInfo<>(list);
    }

    @Override
    public List<FncContractAttach> list(FncContractAttachQueryVo queryVo){
        FncContractAttachQuery query = new FncContractAttachQuery();
        BeanUtils.copyBeanProp(queryVo, query);
        return fncContractAttachMapper.selectByExample(query.getCrieria());
    }

    @Override
    @Transactional(rollbackFor = Exception.class)
    public int add(FncContractAttach entity){
        entity.setCreatetime(new Date());
        entity.setUpdatetime(new Date());
        entity.setDr(BaseConstants.DR_NO);
        return fncContractAttachMapper.insert(entity);
    }

    @Override
    @Transactional(rollbackFor = Exception.class)
    public int update(FncContractAttach entity){
        entity.setUpdatetime(new Date());
        return fncContractAttachMapper.updateByPrimaryKey(entity);
    }

    @Override
    @Transactional(rollbackFor = Exception.class)
    public int delete(Long id){
        return fncContractAttachMapper.deleteByPrimaryKey(id);
    }

    @Override
    public FncContractAttach getById(Long id){
        return fncContractAttachMapper.selectByPrimaryKey(id);
    }

    @Override
    public void insertList(List<FncContractAttach> fncContractAttaches) {
        fncContractAttachMapper.insertList(fncContractAttaches);
    }

    @Override
    public List<FncContractAttach> selectByContractIds(List<Long> contractIds) {
        FncContractAttachExample example =new FncContractAttachExample();
        example.createCriteria()
            .andFcaContractIdIn(contractIds)
            .andDrEqualTo(BaseConstants.DR_NO);
        return fncContractAttachMapper.selectByExample(example);
    }

    @Override
    public void updateByContarctId(Long fcmId) {
        FncContractAttachExample example =new FncContractAttachExample();
        example.createCriteria()
            .andFcaContractIdEqualTo(fcmId)
            .andDrEqualTo(BaseConstants.DR_NO);
        FncContractAttach fncContractAttach = new FncContractAttach();
        fncContractAttach.setDr(BaseConstants.DR_YES);
        fncContractAttachMapper.updateByExample(fncContractAttach,example);
    }
}
