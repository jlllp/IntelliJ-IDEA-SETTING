package com.mrk.finance.query;
import com.mrk.common.utils.text.CheckUtil;

/**
 * @author 自动生成工具
 * @date   2021/11/19
 */
public class FncTempQuery {
	private String updateuserNotLike;
	private java.util.List updateuserNotIn;
	private String updateuserNotEqualTo;
	private String updateuserLike;
	private String updateuserLessThanOrEqualTo;
	private String updateuserLessThan;
	private Boolean updateuserIsNull;
	private Boolean updateuserIsNotNull;
	private java.util.List updateuserIn;
	private String updateuserGreaterThanOrEqualTo;
	private String updateuserGreaterThan;
	private String updateuserEqualTo;
	private java.util.List updatetimeNotIn;
	private java.util.Date updatetimeNotEqualTo;
	private java.util.Date updatetimeLessThanOrEqualTo;
	private java.util.Date updatetimeLessThan;
	private Boolean updatetimeIsNull;
	private Boolean updatetimeIsNotNull;
	private java.util.List updatetimeIn;
	private java.util.Date updatetimeGreaterThanOrEqualTo;
	private java.util.Date updatetimeGreaterThan;
	private java.util.Date updatetimeEqualTo;
	private String remarkNotLike;
	private java.util.List remarkNotIn;
	private String remarkNotEqualTo;
	private String remarkLike;
	private String remarkLessThanOrEqualTo;
	private String remarkLessThan;
	private Boolean remarkIsNull;
	private Boolean remarkIsNotNull;
	private java.util.List remarkIn;
	private String remarkGreaterThanOrEqualTo;
	private String remarkGreaterThan;
	private String remarkEqualTo;
	private String fncVoucherNoNotLike;
	private java.util.List fncVoucherNoNotIn;
	private String fncVoucherNoNotEqualTo;
	private String fncVoucherNoLike;
	private String fncVoucherNoLessThanOrEqualTo;
	private String fncVoucherNoLessThan;
	private Boolean fncVoucherNoIsNull;
	private Boolean fncVoucherNoIsNotNull;
	private java.util.List fncVoucherNoIn;
	private String fncVoucherNoGreaterThanOrEqualTo;
	private String fncVoucherNoGreaterThan;
	private String fncVoucherNoEqualTo;
	private String fncUseNotLike;
	private java.util.List fncUseNotIn;
	private String fncUseNotEqualTo;
	private String fncUseLike;
	private String fncUseLessThanOrEqualTo;
	private String fncUseLessThan;
	private Boolean fncUseIsNull;
	private Boolean fncUseIsNotNull;
	private java.util.List fncUseIn;
	private String fncUseGreaterThanOrEqualTo;
	private String fncUseGreaterThan;
	private String fncUseEqualTo;
	private java.util.List fncTradeTimeNotIn;
	private java.util.Date fncTradeTimeNotEqualTo;
	private java.util.Date fncTradeTimeLessThanOrEqualTo;
	private java.util.Date fncTradeTimeLessThan;
	private Boolean fncTradeTimeIsNull;
	private Boolean fncTradeTimeIsNotNull;
	private java.util.List fncTradeTimeIn;
	private java.util.Date fncTradeTimeGreaterThanOrEqualTo;
	private java.util.Date fncTradeTimeGreaterThan;
	private java.util.Date fncTradeTimeEqualTo;
	private String fncTradePartyNotLike;
	private java.util.List fncTradePartyNotIn;
	private String fncTradePartyNotEqualTo;
	private String fncTradePartyLike;
	private String fncTradePartyLessThanOrEqualTo;
	private String fncTradePartyLessThan;
	private Boolean fncTradePartyIsNull;
	private Boolean fncTradePartyIsNotNull;
	private java.util.List fncTradePartyIn;
	private String fncTradePartyGreaterThanOrEqualTo;
	private String fncTradePartyGreaterThan;
	private String fncTradePartyEqualTo;
	private String fncTradeNamesNotLike;
	private java.util.List fncTradeNamesNotIn;
	private String fncTradeNamesNotEqualTo;
	private String fncTradeNamesLike;
	private String fncTradeNamesLessThanOrEqualTo;
	private String fncTradeNamesLessThan;
	private Boolean fncTradeNamesIsNull;
	private Boolean fncTradeNamesIsNotNull;
	private java.util.List fncTradeNamesIn;
	private String fncTradeNamesGreaterThanOrEqualTo;
	private String fncTradeNamesGreaterThan;
	private String fncTradeNamesEqualTo;
	private java.util.List fncTradeAmountNotIn;
	private Double fncTradeAmountNotEqualTo;
	private Double fncTradeAmountLessThanOrEqualTo;
	private Double fncTradeAmountLessThan;
	private Boolean fncTradeAmountIsNull;
	private Boolean fncTradeAmountIsNotNull;
	private java.util.List fncTradeAmountIn;
	private Double fncTradeAmountGreaterThanOrEqualTo;
	private Double fncTradeAmountGreaterThan;
	private Double fncTradeAmountEqualTo;
	private java.util.List fncRentDateNotIn;
	private java.util.Date fncRentDateNotEqualTo;
	private java.util.Date fncRentDateLessThanOrEqualTo;
	private java.util.Date fncRentDateLessThan;
	private Boolean fncRentDateIsNull;
	private Boolean fncRentDateIsNotNull;
	private java.util.List fncRentDateIn;
	private java.util.Date fncRentDateGreaterThanOrEqualTo;
	private java.util.Date fncRentDateGreaterThan;
	private java.util.Date fncRentDateEqualTo;
	private String fncOwnAccountNotLike;
	private java.util.List fncOwnAccountNotIn;
	private String fncOwnAccountNotEqualTo;
	private String fncOwnAccountLike;
	private String fncOwnAccountLessThanOrEqualTo;
	private String fncOwnAccountLessThan;
	private Boolean fncOwnAccountIsNull;
	private Boolean fncOwnAccountIsNotNull;
	private java.util.List fncOwnAccountIn;
	private String fncOwnAccountGreaterThanOrEqualTo;
	private String fncOwnAccountGreaterThan;
	private String fncOwnAccountEqualTo;
	private String fncOtherUnitNameNotLike;
	private java.util.List fncOtherUnitNameNotIn;
	private String fncOtherUnitNameNotEqualTo;
	private String fncOtherUnitNameLike;
	private String fncOtherUnitNameLessThanOrEqualTo;
	private String fncOtherUnitNameLessThan;
	private Boolean fncOtherUnitNameIsNull;
	private Boolean fncOtherUnitNameIsNotNull;
	private java.util.List fncOtherUnitNameIn;
	private String fncOtherUnitNameGreaterThanOrEqualTo;
	private String fncOtherUnitNameGreaterThan;
	private String fncOtherUnitNameEqualTo;
	private String fncOtherAccountNotLike;
	private java.util.List fncOtherAccountNotIn;
	private String fncOtherAccountNotEqualTo;
	private String fncOtherAccountLike;
	private String fncOtherAccountLessThanOrEqualTo;
	private String fncOtherAccountLessThan;
	private Boolean fncOtherAccountIsNull;
	private Boolean fncOtherAccountIsNotNull;
	private java.util.List fncOtherAccountIn;
	private String fncOtherAccountGreaterThanOrEqualTo;
	private String fncOtherAccountGreaterThan;
	private String fncOtherAccountEqualTo;
	private String fncOrderNoNotLike;
	private java.util.List fncOrderNoNotIn;
	private String fncOrderNoNotEqualTo;
	private String fncOrderNoLike;
	private String fncOrderNoLessThanOrEqualTo;
	private String fncOrderNoLessThan;
	private Boolean fncOrderNoIsNull;
	private Boolean fncOrderNoIsNotNull;
	private java.util.List fncOrderNoIn;
	private String fncOrderNoGreaterThanOrEqualTo;
	private String fncOrderNoGreaterThan;
	private String fncOrderNoEqualTo;
	private String fncOperateCodeNotLike;
	private java.util.List fncOperateCodeNotIn;
	private String fncOperateCodeNotEqualTo;
	private String fncOperateCodeLike;
	private String fncOperateCodeLessThanOrEqualTo;
	private String fncOperateCodeLessThan;
	private Boolean fncOperateCodeIsNull;
	private Boolean fncOperateCodeIsNotNull;
	private java.util.List fncOperateCodeIn;
	private String fncOperateCodeGreaterThanOrEqualTo;
	private String fncOperateCodeGreaterThan;
	private String fncOperateCodeEqualTo;
	private String fncNameNotLike;
	private java.util.List fncNameNotIn;
	private String fncNameNotEqualTo;
	private String fncNameLike;
	private String fncNameLessThanOrEqualTo;
	private String fncNameLessThan;
	private Boolean fncNameIsNull;
	private Boolean fncNameIsNotNull;
	private java.util.List fncNameIn;
	private String fncNameGreaterThanOrEqualTo;
	private String fncNameGreaterThan;
	private String fncNameEqualTo;
	private java.util.List fncMonthWithholdNotIn;
	private Double fncMonthWithholdNotEqualTo;
	private Double fncMonthWithholdLessThanOrEqualTo;
	private Double fncMonthWithholdLessThan;
	private Boolean fncMonthWithholdIsNull;
	private Boolean fncMonthWithholdIsNotNull;
	private java.util.List fncMonthWithholdIn;
	private Double fncMonthWithholdGreaterThanOrEqualTo;
	private Double fncMonthWithholdGreaterThan;
	private Double fncMonthWithholdEqualTo;
	private java.util.List fncMonthRentNotIn;
	private Double fncMonthRentNotEqualTo;
	private Double fncMonthRentLessThanOrEqualTo;
	private Double fncMonthRentLessThan;
	private Boolean fncMonthRentIsNull;
	private Boolean fncMonthRentIsNotNull;
	private java.util.List fncMonthRentIn;
	private Double fncMonthRentGreaterThanOrEqualTo;
	private Double fncMonthRentGreaterThan;
	private Double fncMonthRentEqualTo;
	private java.util.List fncMonthRentBalanceNotIn;
	private Double fncMonthRentBalanceNotEqualTo;
	private Double fncMonthRentBalanceLessThanOrEqualTo;
	private Double fncMonthRentBalanceLessThan;
	private Boolean fncMonthRentBalanceIsNull;
	private Boolean fncMonthRentBalanceIsNotNull;
	private java.util.List fncMonthRentBalanceIn;
	private Double fncMonthRentBalanceGreaterThanOrEqualTo;
	private Double fncMonthRentBalanceGreaterThan;
	private Double fncMonthRentBalanceEqualTo;
	private java.util.List fncMonthNotIn;
	private java.util.Date fncMonthNotEqualTo;
	private java.util.Date fncMonthLessThanOrEqualTo;
	private java.util.Date fncMonthLessThan;
	private Boolean fncMonthIsNull;
	private Boolean fncMonthIsNotNull;
	private java.util.List fncMonthIn;
	private java.util.Date fncMonthGreaterThanOrEqualTo;
	private java.util.Date fncMonthGreaterThan;
	private java.util.Date fncMonthEqualTo;
	private java.util.List fncMemberIdNotIn;
	private Long fncMemberIdNotEqualTo;
	private Long fncMemberIdLessThanOrEqualTo;
	private Long fncMemberIdLessThan;
	private Boolean fncMemberIdIsNull;
	private Boolean fncMemberIdIsNotNull;
	private java.util.List fncMemberIdIn;
	private Long fncMemberIdGreaterThanOrEqualTo;
	private Long fncMemberIdGreaterThan;
	private Long fncMemberIdEqualTo;
	private String fncLoanTypeNotLike;
	private java.util.List fncLoanTypeNotIn;
	private String fncLoanTypeNotEqualTo;
	private String fncLoanTypeLike;
	private String fncLoanTypeLessThanOrEqualTo;
	private String fncLoanTypeLessThan;
	private Boolean fncLoanTypeIsNull;
	private Boolean fncLoanTypeIsNotNull;
	private java.util.List fncLoanTypeIn;
	private String fncLoanTypeGreaterThanOrEqualTo;
	private String fncLoanTypeGreaterThan;
	private String fncLoanTypeEqualTo;
	private java.util.List fncLeaseCountNotIn;
	private Integer fncLeaseCountNotEqualTo;
	private Integer fncLeaseCountLessThanOrEqualTo;
	private Integer fncLeaseCountLessThan;
	private Boolean fncLeaseCountIsNull;
	private Boolean fncLeaseCountIsNotNull;
	private java.util.List fncLeaseCountIn;
	private Integer fncLeaseCountGreaterThanOrEqualTo;
	private Integer fncLeaseCountGreaterThan;
	private Integer fncLeaseCountEqualTo;
	private String fncIdnumberNotLike;
	private java.util.List fncIdnumberNotIn;
	private String fncIdnumberNotEqualTo;
	private String fncIdnumberLike;
	private String fncIdnumberLessThanOrEqualTo;
	private String fncIdnumberLessThan;
	private Boolean fncIdnumberIsNull;
	private Boolean fncIdnumberIsNotNull;
	private java.util.List fncIdnumberIn;
	private String fncIdnumberGreaterThanOrEqualTo;
	private String fncIdnumberGreaterThan;
	private String fncIdnumberEqualTo;
	private java.util.List fncIdNotIn;
	private Long fncIdNotEqualTo;
	private Long fncIdLessThanOrEqualTo;
	private Long fncIdLessThan;
	private Boolean fncIdIsNull;
	private Boolean fncIdIsNotNull;
	private java.util.List fncIdIn;
	private Long fncIdGreaterThanOrEqualTo;
	private Long fncIdGreaterThan;
	private Long fncIdEqualTo;
	private java.util.List fncErrorNotIn;
	private Integer fncErrorNotEqualTo;
	private String fncErrorMsgNotLike;
	private java.util.List fncErrorMsgNotIn;
	private String fncErrorMsgNotEqualTo;
	private String fncErrorMsgLike;
	private String fncErrorMsgLessThanOrEqualTo;
	private String fncErrorMsgLessThan;
	private Boolean fncErrorMsgIsNull;
	private Boolean fncErrorMsgIsNotNull;
	private java.util.List fncErrorMsgIn;
	private String fncErrorMsgGreaterThanOrEqualTo;
	private String fncErrorMsgGreaterThan;
	private String fncErrorMsgEqualTo;
	private Integer fncErrorLessThanOrEqualTo;
	private Integer fncErrorLessThan;
	private Boolean fncErrorIsNull;
	private Boolean fncErrorIsNotNull;
	private java.util.List fncErrorIn;
	private Integer fncErrorGreaterThanOrEqualTo;
	private Integer fncErrorGreaterThan;
	private Integer fncErrorEqualTo;
	private String fncDigestNotLike;
	private java.util.List fncDigestNotIn;
	private String fncDigestNotEqualTo;
	private String fncDigestLike;
	private String fncDigestLessThanOrEqualTo;
	private String fncDigestLessThan;
	private Boolean fncDigestIsNull;
	private Boolean fncDigestIsNotNull;
	private java.util.List fncDigestIn;
	private String fncDigestGreaterThanOrEqualTo;
	private String fncDigestGreaterThan;
	private String fncDigestEqualTo;
	private java.util.List fncDealTimeNotIn;
	private java.util.Date fncDealTimeNotEqualTo;
	private java.util.Date fncDealTimeLessThanOrEqualTo;
	private java.util.Date fncDealTimeLessThan;
	private Boolean fncDealTimeIsNull;
	private Boolean fncDealTimeIsNotNull;
	private java.util.List fncDealTimeIn;
	private java.util.Date fncDealTimeGreaterThanOrEqualTo;
	private java.util.Date fncDealTimeGreaterThan;
	private java.util.Date fncDealTimeEqualTo;
	private java.util.List fncCreditAmountNotIn;
	private Double fncCreditAmountNotEqualTo;
	private Double fncCreditAmountLessThanOrEqualTo;
	private Double fncCreditAmountLessThan;
	private Boolean fncCreditAmountIsNull;
	private Boolean fncCreditAmountIsNotNull;
	private java.util.List fncCreditAmountIn;
	private Double fncCreditAmountGreaterThanOrEqualTo;
	private Double fncCreditAmountGreaterThan;
	private Double fncCreditAmountEqualTo;
	private String fncCityNotLike;
	private java.util.List fncCityNotIn;
	private String fncCityNotEqualTo;
	private String fncCityLike;
	private String fncCityLessThanOrEqualTo;
	private String fncCityLessThan;
	private Boolean fncCityIsNull;
	private Boolean fncCityIsNotNull;
	private java.util.List fncCityIn;
	private String fncCityGreaterThanOrEqualTo;
	private String fncCityGreaterThan;
	private String fncCityEqualTo;
	private String fncCarVinNotLike;
	private java.util.List fncCarVinNotIn;
	private String fncCarVinNotEqualTo;
	private String fncCarVinLike;
	private String fncCarVinLessThanOrEqualTo;
	private String fncCarVinLessThan;
	private Boolean fncCarVinIsNull;
	private Boolean fncCarVinIsNotNull;
	private java.util.List fncCarVinIn;
	private String fncCarVinGreaterThanOrEqualTo;
	private String fncCarVinGreaterThan;
	private String fncCarVinEqualTo;
	private java.util.List fncBorrowAmountNotIn;
	private Double fncBorrowAmountNotEqualTo;
	private Double fncBorrowAmountLessThanOrEqualTo;
	private Double fncBorrowAmountLessThan;
	private Boolean fncBorrowAmountIsNull;
	private Boolean fncBorrowAmountIsNotNull;
	private java.util.List fncBorrowAmountIn;
	private Double fncBorrowAmountGreaterThanOrEqualTo;
	private Double fncBorrowAmountGreaterThan;
	private Double fncBorrowAmountEqualTo;
	private String fncAgreementNumberNotLike;
	private java.util.List fncAgreementNumberNotIn;
	private String fncAgreementNumberNotEqualTo;
	private String fncAgreementNumberLike;
	private String fncAgreementNumberLessThanOrEqualTo;
	private String fncAgreementNumberLessThan;
	private Boolean fncAgreementNumberIsNull;
	private Boolean fncAgreementNumberIsNotNull;
	private java.util.List fncAgreementNumberIn;
	private String fncAgreementNumberGreaterThanOrEqualTo;
	private String fncAgreementNumberGreaterThan;
	private String fncAgreementNumberEqualTo;
	private String fncAccountNoNotLike;
	private java.util.List fncAccountNoNotIn;
	private String fncAccountNoNotEqualTo;
	private String fncAccountNoLike;
	private String fncAccountNoLessThanOrEqualTo;
	private String fncAccountNoLessThan;
	private Boolean fncAccountNoIsNull;
	private Boolean fncAccountNoIsNotNull;
	private java.util.List fncAccountNoIn;
	private String fncAccountNoGreaterThanOrEqualTo;
	private String fncAccountNoGreaterThan;
	private String fncAccountNoEqualTo;
	private String fncAccountDealFlowNotLike;
	private java.util.List fncAccountDealFlowNotIn;
	private String fncAccountDealFlowNotEqualTo;
	private String fncAccountDealFlowLike;
	private String fncAccountDealFlowLessThanOrEqualTo;
	private String fncAccountDealFlowLessThan;
	private Boolean fncAccountDealFlowIsNull;
	private Boolean fncAccountDealFlowIsNotNull;
	private java.util.List fncAccountDealFlowIn;
	private String fncAccountDealFlowGreaterThanOrEqualTo;
	private String fncAccountDealFlowGreaterThan;
	private String fncAccountDealFlowEqualTo;
	private java.util.List drNotIn;
	private Integer drNotEqualTo;
	private Integer drLessThanOrEqualTo;
	private Integer drLessThan;
	private Boolean drIsNull;
	private Boolean drIsNotNull;
	private java.util.List drIn;
	private Integer drGreaterThanOrEqualTo;
	private Integer drGreaterThan;
	private Integer drEqualTo;
	private String createuserNotLike;
	private java.util.List createuserNotIn;
	private String createuserNotEqualTo;
	private String createuserLike;
	private String createuserLessThanOrEqualTo;
	private String createuserLessThan;
	private Boolean createuserIsNull;
	private Boolean createuserIsNotNull;
	private java.util.List createuserIn;
	private String createuserGreaterThanOrEqualTo;
	private String createuserGreaterThan;
	private String createuserEqualTo;
	private java.util.List createtimeNotIn;
	private java.util.Date createtimeNotEqualTo;
	private java.util.Date createtimeLessThanOrEqualTo;
	private java.util.Date createtimeLessThan;
	private Boolean createtimeIsNull;
	private Boolean createtimeIsNotNull;
	private java.util.List createtimeIn;
	private java.util.Date createtimeGreaterThanOrEqualTo;
	private java.util.Date createtimeGreaterThan;
	private java.util.Date createtimeEqualTo;
	private String sidx;
	private String sord;
	public String getSidx(){
		if(this.sidx == null){
			return "";
		}
		else if("updateuser".equals(this.sidx)){
			return "updateuser";
		}
		else if("updatetime".equals(this.sidx)){
			return "updatetime";
		}
		else if("remark".equals(this.sidx)){
			return "remark";
		}
		else if("fncVoucherNo".equals(this.sidx)){
			return "fnc_voucher_no";
		}
		else if("fncUse".equals(this.sidx)){
			return "fnc_use";
		}
		else if("fncTradeTime".equals(this.sidx)){
			return "fnc_trade_time";
		}
		else if("fncTradeParty".equals(this.sidx)){
			return "fnc_trade_party";
		}
		else if("fncTradeNames".equals(this.sidx)){
			return "fnc_trade_names";
		}
		else if("fncTradeAmount".equals(this.sidx)){
			return "fnc_trade_amount";
		}
		else if("fncRentDate".equals(this.sidx)){
			return "fnc_rent_date";
		}
		else if("fncOwnAccount".equals(this.sidx)){
			return "fnc_own_account";
		}
		else if("fncOtherUnitName".equals(this.sidx)){
			return "fnc_other_unit_name";
		}
		else if("fncOtherAccount".equals(this.sidx)){
			return "fnc_other_account";
		}
		else if("fncderNo".equals(this.sidx)){
			return "fncder_no";
		}
		else if("fncderNoOr".equals(this.sidx)){
			return "fncder_no_or";
		}
		else if("fncOperateCode".equals(this.sidx)){
			return "fnc_operate_code";
		}
		else if("fncName".equals(this.sidx)){
			return "fnc_name";
		}
		else if("fncMonthWithhold".equals(this.sidx)){
			return "fnc_month_withhold";
		}
		else if("fncMonthRent".equals(this.sidx)){
			return "fnc_month_rent";
		}
		else if("fncMonthRentBalance".equals(this.sidx)){
			return "fnc_month_rent_balance";
		}
		else if("fncMonth".equals(this.sidx)){
			return "fnc_month";
		}
		else if("fncMemberId".equals(this.sidx)){
			return "fnc_member_id";
		}
		else if("fncLoanType".equals(this.sidx)){
			return "fnc_loan_type";
		}
		else if("fncLeaseCount".equals(this.sidx)){
			return "fnc_lease_count";
		}
		else if("fncIdnumber".equals(this.sidx)){
			return "fnc_idnumber";
		}
		else if("fncId".equals(this.sidx)){
			return "fnc_id";
		}
		else if("fncError".equals(this.sidx)){
			return "fnc_error";
		}
		else if("fncErrorMsg".equals(this.sidx)){
			return "fnc_error_msg";
		}
		else if("fncDigest".equals(this.sidx)){
			return "fnc_digest";
		}
		else if("fncDealTime".equals(this.sidx)){
			return "fnc_deal_time";
		}
		else if("fncCreditAmount".equals(this.sidx)){
			return "fnc_credit_amount";
		}
		else if("fncCity".equals(this.sidx)){
			return "fnc_city";
		}
		else if("fncCarVin".equals(this.sidx)){
			return "fnc_car_vin";
		}
		else if("fncBorrowAmount".equals(this.sidx)){
			return "fnc_borrow_amount";
		}
		else if("fncAgreementNumber".equals(this.sidx)){
			return "fnc_agreement_number";
		}
		else if("fncAccountNo".equals(this.sidx)){
			return "fnc_account_no";
		}
		else if("fncAccountDealFlow".equals(this.sidx)){
			return "fnc_account_deal_flow";
		}
		else if("dr".equals(this.sidx)){
			return "dr";
		}
		else if("createuser".equals(this.sidx)){
			return "createuser";
		}
		else if("createtime".equals(this.sidx)){
			return "createtime";
		}
		return this.sidx;
	}

	@com.fasterxml.jackson.annotation.JsonIgnore
	public com.mrk.finance.example.FncTempExample getCrieria(){
		com.mrk.finance.example.FncTempExample q = new com.mrk.finance.example.FncTempExample();
		com.mrk.finance.example.FncTempExample.Criteria c = q.createCriteria();
		c.andDrEqualTo(0);
		if(CheckUtil.isNotEmpty(getUpdateuserNotLike())){
			c.andUpdateuserNotLike("%"+this.getUpdateuserNotLike()+"%");
		}
		if(CheckUtil.isNotEmpty(getUpdateuserNotIn())){
			c.andUpdateuserNotIn(this.getUpdateuserNotIn());
		}
		if(CheckUtil.isNotEmpty(getUpdateuserNotEqualTo())){
			c.andUpdateuserNotEqualTo(this.getUpdateuserNotEqualTo());
		}
		if(CheckUtil.isNotEmpty(getUpdateuserLike())){
			c.andUpdateuserLike("%"+this.getUpdateuserLike()+"%");
		}
		if(CheckUtil.isNotEmpty(getUpdateuserLessThanOrEqualTo())){
			c.andUpdateuserLessThanOrEqualTo(this.getUpdateuserLessThanOrEqualTo());
		}
		if(CheckUtil.isNotEmpty(getUpdateuserLessThan())){
			c.andUpdateuserLessThan(this.getUpdateuserLessThan());
		}
		if(CheckUtil.isNotEmpty(getUpdateuserIsNull()) && this.getUpdateuserIsNull()){
			c.andUpdateuserIsNull();
		}
		if(CheckUtil.isNotEmpty(getUpdateuserIsNotNull()) && this.getUpdateuserIsNotNull()){
			c.andUpdateuserIsNotNull();
		}
		if(CheckUtil.isNotEmpty(getUpdateuserIn())){
			c.andUpdateuserIn(this.getUpdateuserIn());
		}
		if(CheckUtil.isNotEmpty(getUpdateuserGreaterThanOrEqualTo())){
			c.andUpdateuserGreaterThanOrEqualTo(this.getUpdateuserGreaterThanOrEqualTo());
		}
		if(CheckUtil.isNotEmpty(getUpdateuserGreaterThan())){
			c.andUpdateuserGreaterThan(this.getUpdateuserGreaterThan());
		}
		if(CheckUtil.isNotEmpty(getUpdateuserEqualTo())){
			c.andUpdateuserEqualTo(this.getUpdateuserEqualTo());
		}
		if(CheckUtil.isNotEmpty(getUpdatetimeNotIn())){
			c.andUpdatetimeNotIn(this.getUpdatetimeNotIn());
		}
		if(CheckUtil.isNotEmpty(getUpdatetimeNotEqualTo())){
			c.andUpdatetimeNotEqualTo(this.getUpdatetimeNotEqualTo());
		}
		if(CheckUtil.isNotEmpty(getUpdatetimeLessThanOrEqualTo())){
			c.andUpdatetimeLessThanOrEqualTo(this.getUpdatetimeLessThanOrEqualTo());
		}
		if(CheckUtil.isNotEmpty(getUpdatetimeLessThan())){
			c.andUpdatetimeLessThan(this.getUpdatetimeLessThan());
		}
		if(CheckUtil.isNotEmpty(getUpdatetimeIsNull()) && this.getUpdatetimeIsNull()){
			c.andUpdatetimeIsNull();
		}
		if(CheckUtil.isNotEmpty(getUpdatetimeIsNotNull()) && this.getUpdatetimeIsNotNull()){
			c.andUpdatetimeIsNotNull();
		}
		if(CheckUtil.isNotEmpty(getUpdatetimeIn())){
			c.andUpdatetimeIn(this.getUpdatetimeIn());
		}
		if(CheckUtil.isNotEmpty(getUpdatetimeGreaterThanOrEqualTo())){
			c.andUpdatetimeGreaterThanOrEqualTo(this.getUpdatetimeGreaterThanOrEqualTo());
		}
		if(CheckUtil.isNotEmpty(getUpdatetimeGreaterThan())){
			c.andUpdatetimeGreaterThan(this.getUpdatetimeGreaterThan());
		}
		if(CheckUtil.isNotEmpty(getUpdatetimeEqualTo())){
			c.andUpdatetimeEqualTo(this.getUpdatetimeEqualTo());
		}
		if(CheckUtil.isNotEmpty(getRemarkNotLike())){
			c.andRemarkNotLike("%"+this.getRemarkNotLike()+"%");
		}
		if(CheckUtil.isNotEmpty(getRemarkNotIn())){
			c.andRemarkNotIn(this.getRemarkNotIn());
		}
		if(CheckUtil.isNotEmpty(getRemarkNotEqualTo())){
			c.andRemarkNotEqualTo(this.getRemarkNotEqualTo());
		}
		if(CheckUtil.isNotEmpty(getRemarkLike())){
			c.andRemarkLike("%"+this.getRemarkLike()+"%");
		}
		if(CheckUtil.isNotEmpty(getRemarkLessThanOrEqualTo())){
			c.andRemarkLessThanOrEqualTo(this.getRemarkLessThanOrEqualTo());
		}
		if(CheckUtil.isNotEmpty(getRemarkLessThan())){
			c.andRemarkLessThan(this.getRemarkLessThan());
		}
		if(CheckUtil.isNotEmpty(getRemarkIsNull()) && this.getRemarkIsNull()){
			c.andRemarkIsNull();
		}
		if(CheckUtil.isNotEmpty(getRemarkIsNotNull()) && this.getRemarkIsNotNull()){
			c.andRemarkIsNotNull();
		}
		if(CheckUtil.isNotEmpty(getRemarkIn())){
			c.andRemarkIn(this.getRemarkIn());
		}
		if(CheckUtil.isNotEmpty(getRemarkGreaterThanOrEqualTo())){
			c.andRemarkGreaterThanOrEqualTo(this.getRemarkGreaterThanOrEqualTo());
		}
		if(CheckUtil.isNotEmpty(getRemarkGreaterThan())){
			c.andRemarkGreaterThan(this.getRemarkGreaterThan());
		}
		if(CheckUtil.isNotEmpty(getRemarkEqualTo())){
			c.andRemarkEqualTo(this.getRemarkEqualTo());
		}
		if(CheckUtil.isNotEmpty(getFncVoucherNoNotLike())){
			c.andFncVoucherNoNotLike("%"+this.getFncVoucherNoNotLike()+"%");
		}
		if(CheckUtil.isNotEmpty(getFncVoucherNoNotIn())){
			c.andFncVoucherNoNotIn(this.getFncVoucherNoNotIn());
		}
		if(CheckUtil.isNotEmpty(getFncVoucherNoNotEqualTo())){
			c.andFncVoucherNoNotEqualTo(this.getFncVoucherNoNotEqualTo());
		}
		if(CheckUtil.isNotEmpty(getFncVoucherNoLike())){
			c.andFncVoucherNoLike("%"+this.getFncVoucherNoLike()+"%");
		}
		if(CheckUtil.isNotEmpty(getFncVoucherNoLessThanOrEqualTo())){
			c.andFncVoucherNoLessThanOrEqualTo(this.getFncVoucherNoLessThanOrEqualTo());
		}
		if(CheckUtil.isNotEmpty(getFncVoucherNoLessThan())){
			c.andFncVoucherNoLessThan(this.getFncVoucherNoLessThan());
		}
		if(CheckUtil.isNotEmpty(getFncVoucherNoIsNull()) && this.getFncVoucherNoIsNull()){
			c.andFncVoucherNoIsNull();
		}
		if(CheckUtil.isNotEmpty(getFncVoucherNoIsNotNull()) && this.getFncVoucherNoIsNotNull()){
			c.andFncVoucherNoIsNotNull();
		}
		if(CheckUtil.isNotEmpty(getFncVoucherNoIn())){
			c.andFncVoucherNoIn(this.getFncVoucherNoIn());
		}
		if(CheckUtil.isNotEmpty(getFncVoucherNoGreaterThanOrEqualTo())){
			c.andFncVoucherNoGreaterThanOrEqualTo(this.getFncVoucherNoGreaterThanOrEqualTo());
		}
		if(CheckUtil.isNotEmpty(getFncVoucherNoGreaterThan())){
			c.andFncVoucherNoGreaterThan(this.getFncVoucherNoGreaterThan());
		}
		if(CheckUtil.isNotEmpty(getFncVoucherNoEqualTo())){
			c.andFncVoucherNoEqualTo(this.getFncVoucherNoEqualTo());
		}
		if(CheckUtil.isNotEmpty(getFncUseNotLike())){
			c.andFncUseNotLike("%"+this.getFncUseNotLike()+"%");
		}
		if(CheckUtil.isNotEmpty(getFncUseNotIn())){
			c.andFncUseNotIn(this.getFncUseNotIn());
		}
		if(CheckUtil.isNotEmpty(getFncUseNotEqualTo())){
			c.andFncUseNotEqualTo(this.getFncUseNotEqualTo());
		}
		if(CheckUtil.isNotEmpty(getFncUseLike())){
			c.andFncUseLike("%"+this.getFncUseLike()+"%");
		}
		if(CheckUtil.isNotEmpty(getFncUseLessThanOrEqualTo())){
			c.andFncUseLessThanOrEqualTo(this.getFncUseLessThanOrEqualTo());
		}
		if(CheckUtil.isNotEmpty(getFncUseLessThan())){
			c.andFncUseLessThan(this.getFncUseLessThan());
		}
		if(CheckUtil.isNotEmpty(getFncUseIsNull()) && this.getFncUseIsNull()){
			c.andFncUseIsNull();
		}
		if(CheckUtil.isNotEmpty(getFncUseIsNotNull()) && this.getFncUseIsNotNull()){
			c.andFncUseIsNotNull();
		}
		if(CheckUtil.isNotEmpty(getFncUseIn())){
			c.andFncUseIn(this.getFncUseIn());
		}
		if(CheckUtil.isNotEmpty(getFncUseGreaterThanOrEqualTo())){
			c.andFncUseGreaterThanOrEqualTo(this.getFncUseGreaterThanOrEqualTo());
		}
		if(CheckUtil.isNotEmpty(getFncUseGreaterThan())){
			c.andFncUseGreaterThan(this.getFncUseGreaterThan());
		}
		if(CheckUtil.isNotEmpty(getFncUseEqualTo())){
			c.andFncUseEqualTo(this.getFncUseEqualTo());
		}
		if(CheckUtil.isNotEmpty(getFncTradeTimeNotIn())){
			c.andFncTradeTimeNotIn(this.getFncTradeTimeNotIn());
		}
		if(CheckUtil.isNotEmpty(getFncTradeTimeNotEqualTo())){
			c.andFncTradeTimeNotEqualTo(this.getFncTradeTimeNotEqualTo());
		}
		if(CheckUtil.isNotEmpty(getFncTradeTimeLessThanOrEqualTo())){
			c.andFncTradeTimeLessThanOrEqualTo(this.getFncTradeTimeLessThanOrEqualTo());
		}
		if(CheckUtil.isNotEmpty(getFncTradeTimeLessThan())){
			c.andFncTradeTimeLessThan(this.getFncTradeTimeLessThan());
		}
		if(CheckUtil.isNotEmpty(getFncTradeTimeIsNull()) && this.getFncTradeTimeIsNull()){
			c.andFncTradeTimeIsNull();
		}
		if(CheckUtil.isNotEmpty(getFncTradeTimeIsNotNull()) && this.getFncTradeTimeIsNotNull()){
			c.andFncTradeTimeIsNotNull();
		}
		if(CheckUtil.isNotEmpty(getFncTradeTimeIn())){
			c.andFncTradeTimeIn(this.getFncTradeTimeIn());
		}
		if(CheckUtil.isNotEmpty(getFncTradeTimeGreaterThanOrEqualTo())){
			c.andFncTradeTimeGreaterThanOrEqualTo(this.getFncTradeTimeGreaterThanOrEqualTo());
		}
		if(CheckUtil.isNotEmpty(getFncTradeTimeGreaterThan())){
			c.andFncTradeTimeGreaterThan(this.getFncTradeTimeGreaterThan());
		}
		if(CheckUtil.isNotEmpty(getFncTradeTimeEqualTo())){
			c.andFncTradeTimeEqualTo(this.getFncTradeTimeEqualTo());
		}
		if(CheckUtil.isNotEmpty(getFncTradePartyNotLike())){
			c.andFncTradePartyNotLike("%"+this.getFncTradePartyNotLike()+"%");
		}
		if(CheckUtil.isNotEmpty(getFncTradePartyNotIn())){
			c.andFncTradePartyNotIn(this.getFncTradePartyNotIn());
		}
		if(CheckUtil.isNotEmpty(getFncTradePartyNotEqualTo())){
			c.andFncTradePartyNotEqualTo(this.getFncTradePartyNotEqualTo());
		}
		if(CheckUtil.isNotEmpty(getFncTradePartyLike())){
			c.andFncTradePartyLike("%"+this.getFncTradePartyLike()+"%");
		}
		if(CheckUtil.isNotEmpty(getFncTradePartyLessThanOrEqualTo())){
			c.andFncTradePartyLessThanOrEqualTo(this.getFncTradePartyLessThanOrEqualTo());
		}
		if(CheckUtil.isNotEmpty(getFncTradePartyLessThan())){
			c.andFncTradePartyLessThan(this.getFncTradePartyLessThan());
		}
		if(CheckUtil.isNotEmpty(getFncTradePartyIsNull()) && this.getFncTradePartyIsNull()){
			c.andFncTradePartyIsNull();
		}
		if(CheckUtil.isNotEmpty(getFncTradePartyIsNotNull()) && this.getFncTradePartyIsNotNull()){
			c.andFncTradePartyIsNotNull();
		}
		if(CheckUtil.isNotEmpty(getFncTradePartyIn())){
			c.andFncTradePartyIn(this.getFncTradePartyIn());
		}
		if(CheckUtil.isNotEmpty(getFncTradePartyGreaterThanOrEqualTo())){
			c.andFncTradePartyGreaterThanOrEqualTo(this.getFncTradePartyGreaterThanOrEqualTo());
		}
		if(CheckUtil.isNotEmpty(getFncTradePartyGreaterThan())){
			c.andFncTradePartyGreaterThan(this.getFncTradePartyGreaterThan());
		}
		if(CheckUtil.isNotEmpty(getFncTradePartyEqualTo())){
			c.andFncTradePartyEqualTo(this.getFncTradePartyEqualTo());
		}
		if(CheckUtil.isNotEmpty(getFncTradeNamesNotLike())){
			c.andFncTradeNamesNotLike("%"+this.getFncTradeNamesNotLike()+"%");
		}
		if(CheckUtil.isNotEmpty(getFncTradeNamesNotIn())){
			c.andFncTradeNamesNotIn(this.getFncTradeNamesNotIn());
		}
		if(CheckUtil.isNotEmpty(getFncTradeNamesNotEqualTo())){
			c.andFncTradeNamesNotEqualTo(this.getFncTradeNamesNotEqualTo());
		}
		if(CheckUtil.isNotEmpty(getFncTradeNamesLike())){
			c.andFncTradeNamesLike("%"+this.getFncTradeNamesLike()+"%");
		}
		if(CheckUtil.isNotEmpty(getFncTradeNamesLessThanOrEqualTo())){
			c.andFncTradeNamesLessThanOrEqualTo(this.getFncTradeNamesLessThanOrEqualTo());
		}
		if(CheckUtil.isNotEmpty(getFncTradeNamesLessThan())){
			c.andFncTradeNamesLessThan(this.getFncTradeNamesLessThan());
		}
		if(CheckUtil.isNotEmpty(getFncTradeNamesIsNull()) && this.getFncTradeNamesIsNull()){
			c.andFncTradeNamesIsNull();
		}
		if(CheckUtil.isNotEmpty(getFncTradeNamesIsNotNull()) && this.getFncTradeNamesIsNotNull()){
			c.andFncTradeNamesIsNotNull();
		}
		if(CheckUtil.isNotEmpty(getFncTradeNamesIn())){
			c.andFncTradeNamesIn(this.getFncTradeNamesIn());
		}
		if(CheckUtil.isNotEmpty(getFncTradeNamesGreaterThanOrEqualTo())){
			c.andFncTradeNamesGreaterThanOrEqualTo(this.getFncTradeNamesGreaterThanOrEqualTo());
		}
		if(CheckUtil.isNotEmpty(getFncTradeNamesGreaterThan())){
			c.andFncTradeNamesGreaterThan(this.getFncTradeNamesGreaterThan());
		}
		if(CheckUtil.isNotEmpty(getFncTradeNamesEqualTo())){
			c.andFncTradeNamesEqualTo(this.getFncTradeNamesEqualTo());
		}
		if(CheckUtil.isNotEmpty(getFncTradeAmountNotIn())){
			c.andFncTradeAmountNotIn(this.getFncTradeAmountNotIn());
		}
		if(CheckUtil.isNotEmpty(getFncTradeAmountNotEqualTo())){
			c.andFncTradeAmountNotEqualTo(this.getFncTradeAmountNotEqualTo());
		}
		if(CheckUtil.isNotEmpty(getFncTradeAmountLessThanOrEqualTo())){
			c.andFncTradeAmountLessThanOrEqualTo(this.getFncTradeAmountLessThanOrEqualTo());
		}
		if(CheckUtil.isNotEmpty(getFncTradeAmountLessThan())){
			c.andFncTradeAmountLessThan(this.getFncTradeAmountLessThan());
		}
		if(CheckUtil.isNotEmpty(getFncTradeAmountIsNull()) && this.getFncTradeAmountIsNull()){
			c.andFncTradeAmountIsNull();
		}
		if(CheckUtil.isNotEmpty(getFncTradeAmountIsNotNull()) && this.getFncTradeAmountIsNotNull()){
			c.andFncTradeAmountIsNotNull();
		}
		if(CheckUtil.isNotEmpty(getFncTradeAmountIn())){
			c.andFncTradeAmountIn(this.getFncTradeAmountIn());
		}
		if(CheckUtil.isNotEmpty(getFncTradeAmountGreaterThanOrEqualTo())){
			c.andFncTradeAmountGreaterThanOrEqualTo(this.getFncTradeAmountGreaterThanOrEqualTo());
		}
		if(CheckUtil.isNotEmpty(getFncTradeAmountGreaterThan())){
			c.andFncTradeAmountGreaterThan(this.getFncTradeAmountGreaterThan());
		}
		if(CheckUtil.isNotEmpty(getFncTradeAmountEqualTo())){
			c.andFncTradeAmountEqualTo(this.getFncTradeAmountEqualTo());
		}
		if(CheckUtil.isNotEmpty(getFncRentDateNotIn())){
			c.andFncRentDateNotIn(this.getFncRentDateNotIn());
		}
		if(CheckUtil.isNotEmpty(getFncRentDateNotEqualTo())){
			c.andFncRentDateNotEqualTo(this.getFncRentDateNotEqualTo());
		}
		if(CheckUtil.isNotEmpty(getFncRentDateLessThanOrEqualTo())){
			c.andFncRentDateLessThanOrEqualTo(this.getFncRentDateLessThanOrEqualTo());
		}
		if(CheckUtil.isNotEmpty(getFncRentDateLessThan())){
			c.andFncRentDateLessThan(this.getFncRentDateLessThan());
		}
		if(CheckUtil.isNotEmpty(getFncRentDateIsNull()) && this.getFncRentDateIsNull()){
			c.andFncRentDateIsNull();
		}
		if(CheckUtil.isNotEmpty(getFncRentDateIsNotNull()) && this.getFncRentDateIsNotNull()){
			c.andFncRentDateIsNotNull();
		}
		if(CheckUtil.isNotEmpty(getFncRentDateIn())){
			c.andFncRentDateIn(this.getFncRentDateIn());
		}
		if(CheckUtil.isNotEmpty(getFncRentDateGreaterThanOrEqualTo())){
			c.andFncRentDateGreaterThanOrEqualTo(this.getFncRentDateGreaterThanOrEqualTo());
		}
		if(CheckUtil.isNotEmpty(getFncRentDateGreaterThan())){
			c.andFncRentDateGreaterThan(this.getFncRentDateGreaterThan());
		}
		if(CheckUtil.isNotEmpty(getFncRentDateEqualTo())){
			c.andFncRentDateEqualTo(this.getFncRentDateEqualTo());
		}
		if(CheckUtil.isNotEmpty(getFncOwnAccountNotLike())){
			c.andFncOwnAccountNotLike("%"+this.getFncOwnAccountNotLike()+"%");
		}
		if(CheckUtil.isNotEmpty(getFncOwnAccountNotIn())){
			c.andFncOwnAccountNotIn(this.getFncOwnAccountNotIn());
		}
		if(CheckUtil.isNotEmpty(getFncOwnAccountNotEqualTo())){
			c.andFncOwnAccountNotEqualTo(this.getFncOwnAccountNotEqualTo());
		}
		if(CheckUtil.isNotEmpty(getFncOwnAccountLike())){
			c.andFncOwnAccountLike("%"+this.getFncOwnAccountLike()+"%");
		}
		if(CheckUtil.isNotEmpty(getFncOwnAccountLessThanOrEqualTo())){
			c.andFncOwnAccountLessThanOrEqualTo(this.getFncOwnAccountLessThanOrEqualTo());
		}
		if(CheckUtil.isNotEmpty(getFncOwnAccountLessThan())){
			c.andFncOwnAccountLessThan(this.getFncOwnAccountLessThan());
		}
		if(CheckUtil.isNotEmpty(getFncOwnAccountIsNull()) && this.getFncOwnAccountIsNull()){
			c.andFncOwnAccountIsNull();
		}
		if(CheckUtil.isNotEmpty(getFncOwnAccountIsNotNull()) && this.getFncOwnAccountIsNotNull()){
			c.andFncOwnAccountIsNotNull();
		}
		if(CheckUtil.isNotEmpty(getFncOwnAccountIn())){
			c.andFncOwnAccountIn(this.getFncOwnAccountIn());
		}
		if(CheckUtil.isNotEmpty(getFncOwnAccountGreaterThanOrEqualTo())){
			c.andFncOwnAccountGreaterThanOrEqualTo(this.getFncOwnAccountGreaterThanOrEqualTo());
		}
		if(CheckUtil.isNotEmpty(getFncOwnAccountGreaterThan())){
			c.andFncOwnAccountGreaterThan(this.getFncOwnAccountGreaterThan());
		}
		if(CheckUtil.isNotEmpty(getFncOwnAccountEqualTo())){
			c.andFncOwnAccountEqualTo(this.getFncOwnAccountEqualTo());
		}
		if(CheckUtil.isNotEmpty(getFncOtherUnitNameNotLike())){
			c.andFncOtherUnitNameNotLike("%"+this.getFncOtherUnitNameNotLike()+"%");
		}
		if(CheckUtil.isNotEmpty(getFncOtherUnitNameNotIn())){
			c.andFncOtherUnitNameNotIn(this.getFncOtherUnitNameNotIn());
		}
		if(CheckUtil.isNotEmpty(getFncOtherUnitNameNotEqualTo())){
			c.andFncOtherUnitNameNotEqualTo(this.getFncOtherUnitNameNotEqualTo());
		}
		if(CheckUtil.isNotEmpty(getFncOtherUnitNameLike())){
			c.andFncOtherUnitNameLike("%"+this.getFncOtherUnitNameLike()+"%");
		}
		if(CheckUtil.isNotEmpty(getFncOtherUnitNameLessThanOrEqualTo())){
			c.andFncOtherUnitNameLessThanOrEqualTo(this.getFncOtherUnitNameLessThanOrEqualTo());
		}
		if(CheckUtil.isNotEmpty(getFncOtherUnitNameLessThan())){
			c.andFncOtherUnitNameLessThan(this.getFncOtherUnitNameLessThan());
		}
		if(CheckUtil.isNotEmpty(getFncOtherUnitNameIsNull()) && this.getFncOtherUnitNameIsNull()){
			c.andFncOtherUnitNameIsNull();
		}
		if(CheckUtil.isNotEmpty(getFncOtherUnitNameIsNotNull()) && this.getFncOtherUnitNameIsNotNull()){
			c.andFncOtherUnitNameIsNotNull();
		}
		if(CheckUtil.isNotEmpty(getFncOtherUnitNameIn())){
			c.andFncOtherUnitNameIn(this.getFncOtherUnitNameIn());
		}
		if(CheckUtil.isNotEmpty(getFncOtherUnitNameGreaterThanOrEqualTo())){
			c.andFncOtherUnitNameGreaterThanOrEqualTo(this.getFncOtherUnitNameGreaterThanOrEqualTo());
		}
		if(CheckUtil.isNotEmpty(getFncOtherUnitNameGreaterThan())){
			c.andFncOtherUnitNameGreaterThan(this.getFncOtherUnitNameGreaterThan());
		}
		if(CheckUtil.isNotEmpty(getFncOtherUnitNameEqualTo())){
			c.andFncOtherUnitNameEqualTo(this.getFncOtherUnitNameEqualTo());
		}
		if(CheckUtil.isNotEmpty(getFncOtherAccountNotLike())){
			c.andFncOtherAccountNotLike("%"+this.getFncOtherAccountNotLike()+"%");
		}
		if(CheckUtil.isNotEmpty(getFncOtherAccountNotIn())){
			c.andFncOtherAccountNotIn(this.getFncOtherAccountNotIn());
		}
		if(CheckUtil.isNotEmpty(getFncOtherAccountNotEqualTo())){
			c.andFncOtherAccountNotEqualTo(this.getFncOtherAccountNotEqualTo());
		}
		if(CheckUtil.isNotEmpty(getFncOtherAccountLike())){
			c.andFncOtherAccountLike("%"+this.getFncOtherAccountLike()+"%");
		}
		if(CheckUtil.isNotEmpty(getFncOtherAccountLessThanOrEqualTo())){
			c.andFncOtherAccountLessThanOrEqualTo(this.getFncOtherAccountLessThanOrEqualTo());
		}
		if(CheckUtil.isNotEmpty(getFncOtherAccountLessThan())){
			c.andFncOtherAccountLessThan(this.getFncOtherAccountLessThan());
		}
		if(CheckUtil.isNotEmpty(getFncOtherAccountIsNull()) && this.getFncOtherAccountIsNull()){
			c.andFncOtherAccountIsNull();
		}
		if(CheckUtil.isNotEmpty(getFncOtherAccountIsNotNull()) && this.getFncOtherAccountIsNotNull()){
			c.andFncOtherAccountIsNotNull();
		}
		if(CheckUtil.isNotEmpty(getFncOtherAccountIn())){
			c.andFncOtherAccountIn(this.getFncOtherAccountIn());
		}
		if(CheckUtil.isNotEmpty(getFncOtherAccountGreaterThanOrEqualTo())){
			c.andFncOtherAccountGreaterThanOrEqualTo(this.getFncOtherAccountGreaterThanOrEqualTo());
		}
		if(CheckUtil.isNotEmpty(getFncOtherAccountGreaterThan())){
			c.andFncOtherAccountGreaterThan(this.getFncOtherAccountGreaterThan());
		}
		if(CheckUtil.isNotEmpty(getFncOtherAccountEqualTo())){
			c.andFncOtherAccountEqualTo(this.getFncOtherAccountEqualTo());
		}
		if(CheckUtil.isNotEmpty(getFncOrderNoNotLike())){
			c.andFncOrderNoNotLike("%"+this.getFncOrderNoNotLike()+"%");
		}
		if(CheckUtil.isNotEmpty(getFncOrderNoNotIn())){
			c.andFncOrderNoNotIn(this.getFncOrderNoNotIn());
		}
		if(CheckUtil.isNotEmpty(getFncOrderNoNotEqualTo())){
			c.andFncOrderNoNotEqualTo(this.getFncOrderNoNotEqualTo());
		}
		if(CheckUtil.isNotEmpty(getFncOrderNoLike())){
			c.andFncOrderNoLike("%"+this.getFncOrderNoLike()+"%");
		}
		if(CheckUtil.isNotEmpty(getFncOrderNoLessThanOrEqualTo())){
			c.andFncOrderNoLessThanOrEqualTo(this.getFncOrderNoLessThanOrEqualTo());
		}
		if(CheckUtil.isNotEmpty(getFncOrderNoLessThan())){
			c.andFncOrderNoLessThan(this.getFncOrderNoLessThan());
		}
		if(CheckUtil.isNotEmpty(getFncOrderNoIsNull()) && this.getFncOrderNoIsNull()){
			c.andFncOrderNoIsNull();
		}
		if(CheckUtil.isNotEmpty(getFncOrderNoIsNotNull()) && this.getFncOrderNoIsNotNull()){
			c.andFncOrderNoIsNotNull();
		}
		if(CheckUtil.isNotEmpty(getFncOrderNoIn())){
			c.andFncOrderNoIn(this.getFncOrderNoIn());
		}
		if(CheckUtil.isNotEmpty(getFncOrderNoGreaterThanOrEqualTo())){
			c.andFncOrderNoGreaterThanOrEqualTo(this.getFncOrderNoGreaterThanOrEqualTo());
		}
		if(CheckUtil.isNotEmpty(getFncOrderNoGreaterThan())){
			c.andFncOrderNoGreaterThan(this.getFncOrderNoGreaterThan());
		}
		if(CheckUtil.isNotEmpty(getFncOrderNoEqualTo())){
			c.andFncOrderNoEqualTo(this.getFncOrderNoEqualTo());
		}
		if(CheckUtil.isNotEmpty(getFncOperateCodeNotLike())){
			c.andFncOperateCodeNotLike("%"+this.getFncOperateCodeNotLike()+"%");
		}
		if(CheckUtil.isNotEmpty(getFncOperateCodeNotIn())){
			c.andFncOperateCodeNotIn(this.getFncOperateCodeNotIn());
		}
		if(CheckUtil.isNotEmpty(getFncOperateCodeNotEqualTo())){
			c.andFncOperateCodeNotEqualTo(this.getFncOperateCodeNotEqualTo());
		}
		if(CheckUtil.isNotEmpty(getFncOperateCodeLike())){
			c.andFncOperateCodeLike("%"+this.getFncOperateCodeLike()+"%");
		}
		if(CheckUtil.isNotEmpty(getFncOperateCodeLessThanOrEqualTo())){
			c.andFncOperateCodeLessThanOrEqualTo(this.getFncOperateCodeLessThanOrEqualTo());
		}
		if(CheckUtil.isNotEmpty(getFncOperateCodeLessThan())){
			c.andFncOperateCodeLessThan(this.getFncOperateCodeLessThan());
		}
		if(CheckUtil.isNotEmpty(getFncOperateCodeIsNull()) && this.getFncOperateCodeIsNull()){
			c.andFncOperateCodeIsNull();
		}
		if(CheckUtil.isNotEmpty(getFncOperateCodeIsNotNull()) && this.getFncOperateCodeIsNotNull()){
			c.andFncOperateCodeIsNotNull();
		}
		if(CheckUtil.isNotEmpty(getFncOperateCodeIn())){
			c.andFncOperateCodeIn(this.getFncOperateCodeIn());
		}
		if(CheckUtil.isNotEmpty(getFncOperateCodeGreaterThanOrEqualTo())){
			c.andFncOperateCodeGreaterThanOrEqualTo(this.getFncOperateCodeGreaterThanOrEqualTo());
		}
		if(CheckUtil.isNotEmpty(getFncOperateCodeGreaterThan())){
			c.andFncOperateCodeGreaterThan(this.getFncOperateCodeGreaterThan());
		}
		if(CheckUtil.isNotEmpty(getFncOperateCodeEqualTo())){
			c.andFncOperateCodeEqualTo(this.getFncOperateCodeEqualTo());
		}
		if(CheckUtil.isNotEmpty(getFncNameNotLike())){
			c.andFncNameNotLike("%"+this.getFncNameNotLike()+"%");
		}
		if(CheckUtil.isNotEmpty(getFncNameNotIn())){
			c.andFncNameNotIn(this.getFncNameNotIn());
		}
		if(CheckUtil.isNotEmpty(getFncNameNotEqualTo())){
			c.andFncNameNotEqualTo(this.getFncNameNotEqualTo());
		}
		if(CheckUtil.isNotEmpty(getFncNameLike())){
			c.andFncNameLike("%"+this.getFncNameLike()+"%");
		}
		if(CheckUtil.isNotEmpty(getFncNameLessThanOrEqualTo())){
			c.andFncNameLessThanOrEqualTo(this.getFncNameLessThanOrEqualTo());
		}
		if(CheckUtil.isNotEmpty(getFncNameLessThan())){
			c.andFncNameLessThan(this.getFncNameLessThan());
		}
		if(CheckUtil.isNotEmpty(getFncNameIsNull()) && this.getFncNameIsNull()){
			c.andFncNameIsNull();
		}
		if(CheckUtil.isNotEmpty(getFncNameIsNotNull()) && this.getFncNameIsNotNull()){
			c.andFncNameIsNotNull();
		}
		if(CheckUtil.isNotEmpty(getFncNameIn())){
			c.andFncNameIn(this.getFncNameIn());
		}
		if(CheckUtil.isNotEmpty(getFncNameGreaterThanOrEqualTo())){
			c.andFncNameGreaterThanOrEqualTo(this.getFncNameGreaterThanOrEqualTo());
		}
		if(CheckUtil.isNotEmpty(getFncNameGreaterThan())){
			c.andFncNameGreaterThan(this.getFncNameGreaterThan());
		}
		if(CheckUtil.isNotEmpty(getFncNameEqualTo())){
			c.andFncNameEqualTo(this.getFncNameEqualTo());
		}
		if(CheckUtil.isNotEmpty(getFncMonthWithholdNotIn())){
			c.andFncMonthWithholdNotIn(this.getFncMonthWithholdNotIn());
		}
		if(CheckUtil.isNotEmpty(getFncMonthWithholdNotEqualTo())){
			c.andFncMonthWithholdNotEqualTo(this.getFncMonthWithholdNotEqualTo());
		}
		if(CheckUtil.isNotEmpty(getFncMonthWithholdLessThanOrEqualTo())){
			c.andFncMonthWithholdLessThanOrEqualTo(this.getFncMonthWithholdLessThanOrEqualTo());
		}
		if(CheckUtil.isNotEmpty(getFncMonthWithholdLessThan())){
			c.andFncMonthWithholdLessThan(this.getFncMonthWithholdLessThan());
		}
		if(CheckUtil.isNotEmpty(getFncMonthWithholdIsNull()) && this.getFncMonthWithholdIsNull()){
			c.andFncMonthWithholdIsNull();
		}
		if(CheckUtil.isNotEmpty(getFncMonthWithholdIsNotNull()) && this.getFncMonthWithholdIsNotNull()){
			c.andFncMonthWithholdIsNotNull();
		}
		if(CheckUtil.isNotEmpty(getFncMonthWithholdIn())){
			c.andFncMonthWithholdIn(this.getFncMonthWithholdIn());
		}
		if(CheckUtil.isNotEmpty(getFncMonthWithholdGreaterThanOrEqualTo())){
			c.andFncMonthWithholdGreaterThanOrEqualTo(this.getFncMonthWithholdGreaterThanOrEqualTo());
		}
		if(CheckUtil.isNotEmpty(getFncMonthWithholdGreaterThan())){
			c.andFncMonthWithholdGreaterThan(this.getFncMonthWithholdGreaterThan());
		}
		if(CheckUtil.isNotEmpty(getFncMonthWithholdEqualTo())){
			c.andFncMonthWithholdEqualTo(this.getFncMonthWithholdEqualTo());
		}
		if(CheckUtil.isNotEmpty(getFncMonthRentNotIn())){
			c.andFncMonthRentNotIn(this.getFncMonthRentNotIn());
		}
		if(CheckUtil.isNotEmpty(getFncMonthRentNotEqualTo())){
			c.andFncMonthRentNotEqualTo(this.getFncMonthRentNotEqualTo());
		}
		if(CheckUtil.isNotEmpty(getFncMonthRentLessThanOrEqualTo())){
			c.andFncMonthRentLessThanOrEqualTo(this.getFncMonthRentLessThanOrEqualTo());
		}
		if(CheckUtil.isNotEmpty(getFncMonthRentLessThan())){
			c.andFncMonthRentLessThan(this.getFncMonthRentLessThan());
		}
		if(CheckUtil.isNotEmpty(getFncMonthRentIsNull()) && this.getFncMonthRentIsNull()){
			c.andFncMonthRentIsNull();
		}
		if(CheckUtil.isNotEmpty(getFncMonthRentIsNotNull()) && this.getFncMonthRentIsNotNull()){
			c.andFncMonthRentIsNotNull();
		}
		if(CheckUtil.isNotEmpty(getFncMonthRentIn())){
			c.andFncMonthRentIn(this.getFncMonthRentIn());
		}
		if(CheckUtil.isNotEmpty(getFncMonthRentGreaterThanOrEqualTo())){
			c.andFncMonthRentGreaterThanOrEqualTo(this.getFncMonthRentGreaterThanOrEqualTo());
		}
		if(CheckUtil.isNotEmpty(getFncMonthRentGreaterThan())){
			c.andFncMonthRentGreaterThan(this.getFncMonthRentGreaterThan());
		}
		if(CheckUtil.isNotEmpty(getFncMonthRentEqualTo())){
			c.andFncMonthRentEqualTo(this.getFncMonthRentEqualTo());
		}
		if(CheckUtil.isNotEmpty(getFncMonthRentBalanceNotIn())){
			c.andFncMonthRentBalanceNotIn(this.getFncMonthRentBalanceNotIn());
		}
		if(CheckUtil.isNotEmpty(getFncMonthRentBalanceNotEqualTo())){
			c.andFncMonthRentBalanceNotEqualTo(this.getFncMonthRentBalanceNotEqualTo());
		}
		if(CheckUtil.isNotEmpty(getFncMonthRentBalanceLessThanOrEqualTo())){
			c.andFncMonthRentBalanceLessThanOrEqualTo(this.getFncMonthRentBalanceLessThanOrEqualTo());
		}
		if(CheckUtil.isNotEmpty(getFncMonthRentBalanceLessThan())){
			c.andFncMonthRentBalanceLessThan(this.getFncMonthRentBalanceLessThan());
		}
		if(CheckUtil.isNotEmpty(getFncMonthRentBalanceIsNull()) && this.getFncMonthRentBalanceIsNull()){
			c.andFncMonthRentBalanceIsNull();
		}
		if(CheckUtil.isNotEmpty(getFncMonthRentBalanceIsNotNull()) && this.getFncMonthRentBalanceIsNotNull()){
			c.andFncMonthRentBalanceIsNotNull();
		}
		if(CheckUtil.isNotEmpty(getFncMonthRentBalanceIn())){
			c.andFncMonthRentBalanceIn(this.getFncMonthRentBalanceIn());
		}
		if(CheckUtil.isNotEmpty(getFncMonthRentBalanceGreaterThanOrEqualTo())){
			c.andFncMonthRentBalanceGreaterThanOrEqualTo(this.getFncMonthRentBalanceGreaterThanOrEqualTo());
		}
		if(CheckUtil.isNotEmpty(getFncMonthRentBalanceGreaterThan())){
			c.andFncMonthRentBalanceGreaterThan(this.getFncMonthRentBalanceGreaterThan());
		}
		if(CheckUtil.isNotEmpty(getFncMonthRentBalanceEqualTo())){
			c.andFncMonthRentBalanceEqualTo(this.getFncMonthRentBalanceEqualTo());
		}
		if(CheckUtil.isNotEmpty(getFncMonthNotIn())){
			c.andFncMonthNotIn(this.getFncMonthNotIn());
		}
		if(CheckUtil.isNotEmpty(getFncMonthNotEqualTo())){
			c.andFncMonthNotEqualTo(this.getFncMonthNotEqualTo());
		}
		if(CheckUtil.isNotEmpty(getFncMonthLessThanOrEqualTo())){
			c.andFncMonthLessThanOrEqualTo(this.getFncMonthLessThanOrEqualTo());
		}
		if(CheckUtil.isNotEmpty(getFncMonthLessThan())){
			c.andFncMonthLessThan(this.getFncMonthLessThan());
		}
		if(CheckUtil.isNotEmpty(getFncMonthIsNull()) && this.getFncMonthIsNull()){
			c.andFncMonthIsNull();
		}
		if(CheckUtil.isNotEmpty(getFncMonthIsNotNull()) && this.getFncMonthIsNotNull()){
			c.andFncMonthIsNotNull();
		}
		if(CheckUtil.isNotEmpty(getFncMonthIn())){
			c.andFncMonthIn(this.getFncMonthIn());
		}
		if(CheckUtil.isNotEmpty(getFncMonthGreaterThanOrEqualTo())){
			c.andFncMonthGreaterThanOrEqualTo(this.getFncMonthGreaterThanOrEqualTo());
		}
		if(CheckUtil.isNotEmpty(getFncMonthGreaterThan())){
			c.andFncMonthGreaterThan(this.getFncMonthGreaterThan());
		}
		if(CheckUtil.isNotEmpty(getFncMonthEqualTo())){
			c.andFncMonthEqualTo(this.getFncMonthEqualTo());
		}
		if(CheckUtil.isNotEmpty(getFncMemberIdNotIn())){
			c.andFncMemberIdNotIn(this.getFncMemberIdNotIn());
		}
		if(CheckUtil.isNotEmpty(getFncMemberIdNotEqualTo())){
			c.andFncMemberIdNotEqualTo(this.getFncMemberIdNotEqualTo());
		}
		if(CheckUtil.isNotEmpty(getFncMemberIdLessThanOrEqualTo())){
			c.andFncMemberIdLessThanOrEqualTo(this.getFncMemberIdLessThanOrEqualTo());
		}
		if(CheckUtil.isNotEmpty(getFncMemberIdLessThan())){
			c.andFncMemberIdLessThan(this.getFncMemberIdLessThan());
		}
		if(CheckUtil.isNotEmpty(getFncMemberIdIsNull()) && this.getFncMemberIdIsNull()){
			c.andFncMemberIdIsNull();
		}
		if(CheckUtil.isNotEmpty(getFncMemberIdIsNotNull()) && this.getFncMemberIdIsNotNull()){
			c.andFncMemberIdIsNotNull();
		}
		if(CheckUtil.isNotEmpty(getFncMemberIdIn())){
			c.andFncMemberIdIn(this.getFncMemberIdIn());
		}
		if(CheckUtil.isNotEmpty(getFncMemberIdGreaterThanOrEqualTo())){
			c.andFncMemberIdGreaterThanOrEqualTo(this.getFncMemberIdGreaterThanOrEqualTo());
		}
		if(CheckUtil.isNotEmpty(getFncMemberIdGreaterThan())){
			c.andFncMemberIdGreaterThan(this.getFncMemberIdGreaterThan());
		}
		if(CheckUtil.isNotEmpty(getFncMemberIdEqualTo())){
			c.andFncMemberIdEqualTo(this.getFncMemberIdEqualTo());
		}
		if(CheckUtil.isNotEmpty(getFncLoanTypeNotLike())){
			c.andFncLoanTypeNotLike("%"+this.getFncLoanTypeNotLike()+"%");
		}
		if(CheckUtil.isNotEmpty(getFncLoanTypeNotIn())){
			c.andFncLoanTypeNotIn(this.getFncLoanTypeNotIn());
		}
		if(CheckUtil.isNotEmpty(getFncLoanTypeNotEqualTo())){
			c.andFncLoanTypeNotEqualTo(this.getFncLoanTypeNotEqualTo());
		}
		if(CheckUtil.isNotEmpty(getFncLoanTypeLike())){
			c.andFncLoanTypeLike("%"+this.getFncLoanTypeLike()+"%");
		}
		if(CheckUtil.isNotEmpty(getFncLoanTypeLessThanOrEqualTo())){
			c.andFncLoanTypeLessThanOrEqualTo(this.getFncLoanTypeLessThanOrEqualTo());
		}
		if(CheckUtil.isNotEmpty(getFncLoanTypeLessThan())){
			c.andFncLoanTypeLessThan(this.getFncLoanTypeLessThan());
		}
		if(CheckUtil.isNotEmpty(getFncLoanTypeIsNull()) && this.getFncLoanTypeIsNull()){
			c.andFncLoanTypeIsNull();
		}
		if(CheckUtil.isNotEmpty(getFncLoanTypeIsNotNull()) && this.getFncLoanTypeIsNotNull()){
			c.andFncLoanTypeIsNotNull();
		}
		if(CheckUtil.isNotEmpty(getFncLoanTypeIn())){
			c.andFncLoanTypeIn(this.getFncLoanTypeIn());
		}
		if(CheckUtil.isNotEmpty(getFncLoanTypeGreaterThanOrEqualTo())){
			c.andFncLoanTypeGreaterThanOrEqualTo(this.getFncLoanTypeGreaterThanOrEqualTo());
		}
		if(CheckUtil.isNotEmpty(getFncLoanTypeGreaterThan())){
			c.andFncLoanTypeGreaterThan(this.getFncLoanTypeGreaterThan());
		}
		if(CheckUtil.isNotEmpty(getFncLoanTypeEqualTo())){
			c.andFncLoanTypeEqualTo(this.getFncLoanTypeEqualTo());
		}
		if(CheckUtil.isNotEmpty(getFncLeaseCountNotIn())){
			c.andFncLeaseCountNotIn(this.getFncLeaseCountNotIn());
		}
		if(CheckUtil.isNotEmpty(getFncLeaseCountNotEqualTo())){
			c.andFncLeaseCountNotEqualTo(this.getFncLeaseCountNotEqualTo());
		}
		if(CheckUtil.isNotEmpty(getFncLeaseCountLessThanOrEqualTo())){
			c.andFncLeaseCountLessThanOrEqualTo(this.getFncLeaseCountLessThanOrEqualTo());
		}
		if(CheckUtil.isNotEmpty(getFncLeaseCountLessThan())){
			c.andFncLeaseCountLessThan(this.getFncLeaseCountLessThan());
		}
		if(CheckUtil.isNotEmpty(getFncLeaseCountIsNull()) && this.getFncLeaseCountIsNull()){
			c.andFncLeaseCountIsNull();
		}
		if(CheckUtil.isNotEmpty(getFncLeaseCountIsNotNull()) && this.getFncLeaseCountIsNotNull()){
			c.andFncLeaseCountIsNotNull();
		}
		if(CheckUtil.isNotEmpty(getFncLeaseCountIn())){
			c.andFncLeaseCountIn(this.getFncLeaseCountIn());
		}
		if(CheckUtil.isNotEmpty(getFncLeaseCountGreaterThanOrEqualTo())){
			c.andFncLeaseCountGreaterThanOrEqualTo(this.getFncLeaseCountGreaterThanOrEqualTo());
		}
		if(CheckUtil.isNotEmpty(getFncLeaseCountGreaterThan())){
			c.andFncLeaseCountGreaterThan(this.getFncLeaseCountGreaterThan());
		}
		if(CheckUtil.isNotEmpty(getFncLeaseCountEqualTo())){
			c.andFncLeaseCountEqualTo(this.getFncLeaseCountEqualTo());
		}
		if(CheckUtil.isNotEmpty(getFncIdnumberNotLike())){
			c.andFncIdnumberNotLike("%"+this.getFncIdnumberNotLike()+"%");
		}
		if(CheckUtil.isNotEmpty(getFncIdnumberNotIn())){
			c.andFncIdnumberNotIn(this.getFncIdnumberNotIn());
		}
		if(CheckUtil.isNotEmpty(getFncIdnumberNotEqualTo())){
			c.andFncIdnumberNotEqualTo(this.getFncIdnumberNotEqualTo());
		}
		if(CheckUtil.isNotEmpty(getFncIdnumberLike())){
			c.andFncIdnumberLike("%"+this.getFncIdnumberLike()+"%");
		}
		if(CheckUtil.isNotEmpty(getFncIdnumberLessThanOrEqualTo())){
			c.andFncIdnumberLessThanOrEqualTo(this.getFncIdnumberLessThanOrEqualTo());
		}
		if(CheckUtil.isNotEmpty(getFncIdnumberLessThan())){
			c.andFncIdnumberLessThan(this.getFncIdnumberLessThan());
		}
		if(CheckUtil.isNotEmpty(getFncIdnumberIsNull()) && this.getFncIdnumberIsNull()){
			c.andFncIdnumberIsNull();
		}
		if(CheckUtil.isNotEmpty(getFncIdnumberIsNotNull()) && this.getFncIdnumberIsNotNull()){
			c.andFncIdnumberIsNotNull();
		}
		if(CheckUtil.isNotEmpty(getFncIdnumberIn())){
			c.andFncIdnumberIn(this.getFncIdnumberIn());
		}
		if(CheckUtil.isNotEmpty(getFncIdnumberGreaterThanOrEqualTo())){
			c.andFncIdnumberGreaterThanOrEqualTo(this.getFncIdnumberGreaterThanOrEqualTo());
		}
		if(CheckUtil.isNotEmpty(getFncIdnumberGreaterThan())){
			c.andFncIdnumberGreaterThan(this.getFncIdnumberGreaterThan());
		}
		if(CheckUtil.isNotEmpty(getFncIdnumberEqualTo())){
			c.andFncIdnumberEqualTo(this.getFncIdnumberEqualTo());
		}
		if(CheckUtil.isNotEmpty(getFncIdNotIn())){
			c.andFncIdNotIn(this.getFncIdNotIn());
		}
		if(CheckUtil.isNotEmpty(getFncIdNotEqualTo())){
			c.andFncIdNotEqualTo(this.getFncIdNotEqualTo());
		}
		if(CheckUtil.isNotEmpty(getFncIdLessThanOrEqualTo())){
			c.andFncIdLessThanOrEqualTo(this.getFncIdLessThanOrEqualTo());
		}
		if(CheckUtil.isNotEmpty(getFncIdLessThan())){
			c.andFncIdLessThan(this.getFncIdLessThan());
		}
		if(CheckUtil.isNotEmpty(getFncIdIsNull()) && this.getFncIdIsNull()){
			c.andFncIdIsNull();
		}
		if(CheckUtil.isNotEmpty(getFncIdIsNotNull()) && this.getFncIdIsNotNull()){
			c.andFncIdIsNotNull();
		}
		if(CheckUtil.isNotEmpty(getFncIdIn())){
			c.andFncIdIn(this.getFncIdIn());
		}
		if(CheckUtil.isNotEmpty(getFncIdGreaterThanOrEqualTo())){
			c.andFncIdGreaterThanOrEqualTo(this.getFncIdGreaterThanOrEqualTo());
		}
		if(CheckUtil.isNotEmpty(getFncIdGreaterThan())){
			c.andFncIdGreaterThan(this.getFncIdGreaterThan());
		}
		if(CheckUtil.isNotEmpty(getFncIdEqualTo())){
			c.andFncIdEqualTo(this.getFncIdEqualTo());
		}
		if(CheckUtil.isNotEmpty(getFncErrorNotIn())){
			c.andFncErrorNotIn(this.getFncErrorNotIn());
		}
		if(CheckUtil.isNotEmpty(getFncErrorNotEqualTo())){
			c.andFncErrorNotEqualTo(this.getFncErrorNotEqualTo());
		}
		if(CheckUtil.isNotEmpty(getFncErrorMsgNotLike())){
			c.andFncErrorMsgNotLike("%"+this.getFncErrorMsgNotLike()+"%");
		}
		if(CheckUtil.isNotEmpty(getFncErrorMsgNotIn())){
			c.andFncErrorMsgNotIn(this.getFncErrorMsgNotIn());
		}
		if(CheckUtil.isNotEmpty(getFncErrorMsgNotEqualTo())){
			c.andFncErrorMsgNotEqualTo(this.getFncErrorMsgNotEqualTo());
		}
		if(CheckUtil.isNotEmpty(getFncErrorMsgLike())){
			c.andFncErrorMsgLike("%"+this.getFncErrorMsgLike()+"%");
		}
		if(CheckUtil.isNotEmpty(getFncErrorMsgLessThanOrEqualTo())){
			c.andFncErrorMsgLessThanOrEqualTo(this.getFncErrorMsgLessThanOrEqualTo());
		}
		if(CheckUtil.isNotEmpty(getFncErrorMsgLessThan())){
			c.andFncErrorMsgLessThan(this.getFncErrorMsgLessThan());
		}
		if(CheckUtil.isNotEmpty(getFncErrorMsgIsNull()) && this.getFncErrorMsgIsNull()){
			c.andFncErrorMsgIsNull();
		}
		if(CheckUtil.isNotEmpty(getFncErrorMsgIsNotNull()) && this.getFncErrorMsgIsNotNull()){
			c.andFncErrorMsgIsNotNull();
		}
		if(CheckUtil.isNotEmpty(getFncErrorMsgIn())){
			c.andFncErrorMsgIn(this.getFncErrorMsgIn());
		}
		if(CheckUtil.isNotEmpty(getFncErrorMsgGreaterThanOrEqualTo())){
			c.andFncErrorMsgGreaterThanOrEqualTo(this.getFncErrorMsgGreaterThanOrEqualTo());
		}
		if(CheckUtil.isNotEmpty(getFncErrorMsgGreaterThan())){
			c.andFncErrorMsgGreaterThan(this.getFncErrorMsgGreaterThan());
		}
		if(CheckUtil.isNotEmpty(getFncErrorMsgEqualTo())){
			c.andFncErrorMsgEqualTo(this.getFncErrorMsgEqualTo());
		}
		if(CheckUtil.isNotEmpty(getFncErrorLessThanOrEqualTo())){
			c.andFncErrorLessThanOrEqualTo(this.getFncErrorLessThanOrEqualTo());
		}
		if(CheckUtil.isNotEmpty(getFncErrorLessThan())){
			c.andFncErrorLessThan(this.getFncErrorLessThan());
		}
		if(CheckUtil.isNotEmpty(getFncErrorIsNull()) && this.getFncErrorIsNull()){
			c.andFncErrorIsNull();
		}
		if(CheckUtil.isNotEmpty(getFncErrorIsNotNull()) && this.getFncErrorIsNotNull()){
			c.andFncErrorIsNotNull();
		}
		if(CheckUtil.isNotEmpty(getFncErrorIn())){
			c.andFncErrorIn(this.getFncErrorIn());
		}
		if(CheckUtil.isNotEmpty(getFncErrorGreaterThanOrEqualTo())){
			c.andFncErrorGreaterThanOrEqualTo(this.getFncErrorGreaterThanOrEqualTo());
		}
		if(CheckUtil.isNotEmpty(getFncErrorGreaterThan())){
			c.andFncErrorGreaterThan(this.getFncErrorGreaterThan());
		}
		if(CheckUtil.isNotEmpty(getFncErrorEqualTo())){
			c.andFncErrorEqualTo(this.getFncErrorEqualTo());
		}
		if(CheckUtil.isNotEmpty(getFncDigestNotLike())){
			c.andFncDigestNotLike("%"+this.getFncDigestNotLike()+"%");
		}
		if(CheckUtil.isNotEmpty(getFncDigestNotIn())){
			c.andFncDigestNotIn(this.getFncDigestNotIn());
		}
		if(CheckUtil.isNotEmpty(getFncDigestNotEqualTo())){
			c.andFncDigestNotEqualTo(this.getFncDigestNotEqualTo());
		}
		if(CheckUtil.isNotEmpty(getFncDigestLike())){
			c.andFncDigestLike("%"+this.getFncDigestLike()+"%");
		}
		if(CheckUtil.isNotEmpty(getFncDigestLessThanOrEqualTo())){
			c.andFncDigestLessThanOrEqualTo(this.getFncDigestLessThanOrEqualTo());
		}
		if(CheckUtil.isNotEmpty(getFncDigestLessThan())){
			c.andFncDigestLessThan(this.getFncDigestLessThan());
		}
		if(CheckUtil.isNotEmpty(getFncDigestIsNull()) && this.getFncDigestIsNull()){
			c.andFncDigestIsNull();
		}
		if(CheckUtil.isNotEmpty(getFncDigestIsNotNull()) && this.getFncDigestIsNotNull()){
			c.andFncDigestIsNotNull();
		}
		if(CheckUtil.isNotEmpty(getFncDigestIn())){
			c.andFncDigestIn(this.getFncDigestIn());
		}
		if(CheckUtil.isNotEmpty(getFncDigestGreaterThanOrEqualTo())){
			c.andFncDigestGreaterThanOrEqualTo(this.getFncDigestGreaterThanOrEqualTo());
		}
		if(CheckUtil.isNotEmpty(getFncDigestGreaterThan())){
			c.andFncDigestGreaterThan(this.getFncDigestGreaterThan());
		}
		if(CheckUtil.isNotEmpty(getFncDigestEqualTo())){
			c.andFncDigestEqualTo(this.getFncDigestEqualTo());
		}
		if(CheckUtil.isNotEmpty(getFncDealTimeNotIn())){
			c.andFncDealTimeNotIn(this.getFncDealTimeNotIn());
		}
		if(CheckUtil.isNotEmpty(getFncDealTimeNotEqualTo())){
			c.andFncDealTimeNotEqualTo(this.getFncDealTimeNotEqualTo());
		}
		if(CheckUtil.isNotEmpty(getFncDealTimeLessThanOrEqualTo())){
			c.andFncDealTimeLessThanOrEqualTo(this.getFncDealTimeLessThanOrEqualTo());
		}
		if(CheckUtil.isNotEmpty(getFncDealTimeLessThan())){
			c.andFncDealTimeLessThan(this.getFncDealTimeLessThan());
		}
		if(CheckUtil.isNotEmpty(getFncDealTimeIsNull()) && this.getFncDealTimeIsNull()){
			c.andFncDealTimeIsNull();
		}
		if(CheckUtil.isNotEmpty(getFncDealTimeIsNotNull()) && this.getFncDealTimeIsNotNull()){
			c.andFncDealTimeIsNotNull();
		}
		if(CheckUtil.isNotEmpty(getFncDealTimeIn())){
			c.andFncDealTimeIn(this.getFncDealTimeIn());
		}
		if(CheckUtil.isNotEmpty(getFncDealTimeGreaterThanOrEqualTo())){
			c.andFncDealTimeGreaterThanOrEqualTo(this.getFncDealTimeGreaterThanOrEqualTo());
		}
		if(CheckUtil.isNotEmpty(getFncDealTimeGreaterThan())){
			c.andFncDealTimeGreaterThan(this.getFncDealTimeGreaterThan());
		}
		if(CheckUtil.isNotEmpty(getFncDealTimeEqualTo())){
			c.andFncDealTimeEqualTo(this.getFncDealTimeEqualTo());
		}
		if(CheckUtil.isNotEmpty(getFncCreditAmountNotIn())){
			c.andFncCreditAmountNotIn(this.getFncCreditAmountNotIn());
		}
		if(CheckUtil.isNotEmpty(getFncCreditAmountNotEqualTo())){
			c.andFncCreditAmountNotEqualTo(this.getFncCreditAmountNotEqualTo());
		}
		if(CheckUtil.isNotEmpty(getFncCreditAmountLessThanOrEqualTo())){
			c.andFncCreditAmountLessThanOrEqualTo(this.getFncCreditAmountLessThanOrEqualTo());
		}
		if(CheckUtil.isNotEmpty(getFncCreditAmountLessThan())){
			c.andFncCreditAmountLessThan(this.getFncCreditAmountLessThan());
		}
		if(CheckUtil.isNotEmpty(getFncCreditAmountIsNull()) && this.getFncCreditAmountIsNull()){
			c.andFncCreditAmountIsNull();
		}
		if(CheckUtil.isNotEmpty(getFncCreditAmountIsNotNull()) && this.getFncCreditAmountIsNotNull()){
			c.andFncCreditAmountIsNotNull();
		}
		if(CheckUtil.isNotEmpty(getFncCreditAmountIn())){
			c.andFncCreditAmountIn(this.getFncCreditAmountIn());
		}
		if(CheckUtil.isNotEmpty(getFncCreditAmountGreaterThanOrEqualTo())){
			c.andFncCreditAmountGreaterThanOrEqualTo(this.getFncCreditAmountGreaterThanOrEqualTo());
		}
		if(CheckUtil.isNotEmpty(getFncCreditAmountGreaterThan())){
			c.andFncCreditAmountGreaterThan(this.getFncCreditAmountGreaterThan());
		}
		if(CheckUtil.isNotEmpty(getFncCreditAmountEqualTo())){
			c.andFncCreditAmountEqualTo(this.getFncCreditAmountEqualTo());
		}
		if(CheckUtil.isNotEmpty(getFncCityNotLike())){
			c.andFncCityNotLike("%"+this.getFncCityNotLike()+"%");
		}
		if(CheckUtil.isNotEmpty(getFncCityNotIn())){
			c.andFncCityNotIn(this.getFncCityNotIn());
		}
		if(CheckUtil.isNotEmpty(getFncCityNotEqualTo())){
			c.andFncCityNotEqualTo(this.getFncCityNotEqualTo());
		}
		if(CheckUtil.isNotEmpty(getFncCityLike())){
			c.andFncCityLike("%"+this.getFncCityLike()+"%");
		}
		if(CheckUtil.isNotEmpty(getFncCityLessThanOrEqualTo())){
			c.andFncCityLessThanOrEqualTo(this.getFncCityLessThanOrEqualTo());
		}
		if(CheckUtil.isNotEmpty(getFncCityLessThan())){
			c.andFncCityLessThan(this.getFncCityLessThan());
		}
		if(CheckUtil.isNotEmpty(getFncCityIsNull()) && this.getFncCityIsNull()){
			c.andFncCityIsNull();
		}
		if(CheckUtil.isNotEmpty(getFncCityIsNotNull()) && this.getFncCityIsNotNull()){
			c.andFncCityIsNotNull();
		}
		if(CheckUtil.isNotEmpty(getFncCityIn())){
			c.andFncCityIn(this.getFncCityIn());
		}
		if(CheckUtil.isNotEmpty(getFncCityGreaterThanOrEqualTo())){
			c.andFncCityGreaterThanOrEqualTo(this.getFncCityGreaterThanOrEqualTo());
		}
		if(CheckUtil.isNotEmpty(getFncCityGreaterThan())){
			c.andFncCityGreaterThan(this.getFncCityGreaterThan());
		}
		if(CheckUtil.isNotEmpty(getFncCityEqualTo())){
			c.andFncCityEqualTo(this.getFncCityEqualTo());
		}
		if(CheckUtil.isNotEmpty(getFncCarVinNotLike())){
			c.andFncCarVinNotLike("%"+this.getFncCarVinNotLike()+"%");
		}
		if(CheckUtil.isNotEmpty(getFncCarVinNotIn())){
			c.andFncCarVinNotIn(this.getFncCarVinNotIn());
		}
		if(CheckUtil.isNotEmpty(getFncCarVinNotEqualTo())){
			c.andFncCarVinNotEqualTo(this.getFncCarVinNotEqualTo());
		}
		if(CheckUtil.isNotEmpty(getFncCarVinLike())){
			c.andFncCarVinLike("%"+this.getFncCarVinLike()+"%");
		}
		if(CheckUtil.isNotEmpty(getFncCarVinLessThanOrEqualTo())){
			c.andFncCarVinLessThanOrEqualTo(this.getFncCarVinLessThanOrEqualTo());
		}
		if(CheckUtil.isNotEmpty(getFncCarVinLessThan())){
			c.andFncCarVinLessThan(this.getFncCarVinLessThan());
		}
		if(CheckUtil.isNotEmpty(getFncCarVinIsNull()) && this.getFncCarVinIsNull()){
			c.andFncCarVinIsNull();
		}
		if(CheckUtil.isNotEmpty(getFncCarVinIsNotNull()) && this.getFncCarVinIsNotNull()){
			c.andFncCarVinIsNotNull();
		}
		if(CheckUtil.isNotEmpty(getFncCarVinIn())){
			c.andFncCarVinIn(this.getFncCarVinIn());
		}
		if(CheckUtil.isNotEmpty(getFncCarVinGreaterThanOrEqualTo())){
			c.andFncCarVinGreaterThanOrEqualTo(this.getFncCarVinGreaterThanOrEqualTo());
		}
		if(CheckUtil.isNotEmpty(getFncCarVinGreaterThan())){
			c.andFncCarVinGreaterThan(this.getFncCarVinGreaterThan());
		}
		if(CheckUtil.isNotEmpty(getFncCarVinEqualTo())){
			c.andFncCarVinEqualTo(this.getFncCarVinEqualTo());
		}
		if(CheckUtil.isNotEmpty(getFncBorrowAmountNotIn())){
			c.andFncBorrowAmountNotIn(this.getFncBorrowAmountNotIn());
		}
		if(CheckUtil.isNotEmpty(getFncBorrowAmountNotEqualTo())){
			c.andFncBorrowAmountNotEqualTo(this.getFncBorrowAmountNotEqualTo());
		}
		if(CheckUtil.isNotEmpty(getFncBorrowAmountLessThanOrEqualTo())){
			c.andFncBorrowAmountLessThanOrEqualTo(this.getFncBorrowAmountLessThanOrEqualTo());
		}
		if(CheckUtil.isNotEmpty(getFncBorrowAmountLessThan())){
			c.andFncBorrowAmountLessThan(this.getFncBorrowAmountLessThan());
		}
		if(CheckUtil.isNotEmpty(getFncBorrowAmountIsNull()) && this.getFncBorrowAmountIsNull()){
			c.andFncBorrowAmountIsNull();
		}
		if(CheckUtil.isNotEmpty(getFncBorrowAmountIsNotNull()) && this.getFncBorrowAmountIsNotNull()){
			c.andFncBorrowAmountIsNotNull();
		}
		if(CheckUtil.isNotEmpty(getFncBorrowAmountIn())){
			c.andFncBorrowAmountIn(this.getFncBorrowAmountIn());
		}
		if(CheckUtil.isNotEmpty(getFncBorrowAmountGreaterThanOrEqualTo())){
			c.andFncBorrowAmountGreaterThanOrEqualTo(this.getFncBorrowAmountGreaterThanOrEqualTo());
		}
		if(CheckUtil.isNotEmpty(getFncBorrowAmountGreaterThan())){
			c.andFncBorrowAmountGreaterThan(this.getFncBorrowAmountGreaterThan());
		}
		if(CheckUtil.isNotEmpty(getFncBorrowAmountEqualTo())){
			c.andFncBorrowAmountEqualTo(this.getFncBorrowAmountEqualTo());
		}
		if(CheckUtil.isNotEmpty(getFncAgreementNumberNotLike())){
			c.andFncAgreementNumberNotLike("%"+this.getFncAgreementNumberNotLike()+"%");
		}
		if(CheckUtil.isNotEmpty(getFncAgreementNumberNotIn())){
			c.andFncAgreementNumberNotIn(this.getFncAgreementNumberNotIn());
		}
		if(CheckUtil.isNotEmpty(getFncAgreementNumberNotEqualTo())){
			c.andFncAgreementNumberNotEqualTo(this.getFncAgreementNumberNotEqualTo());
		}
		if(CheckUtil.isNotEmpty(getFncAgreementNumberLike())){
			c.andFncAgreementNumberLike("%"+this.getFncAgreementNumberLike()+"%");
		}
		if(CheckUtil.isNotEmpty(getFncAgreementNumberLessThanOrEqualTo())){
			c.andFncAgreementNumberLessThanOrEqualTo(this.getFncAgreementNumberLessThanOrEqualTo());
		}
		if(CheckUtil.isNotEmpty(getFncAgreementNumberLessThan())){
			c.andFncAgreementNumberLessThan(this.getFncAgreementNumberLessThan());
		}
		if(CheckUtil.isNotEmpty(getFncAgreementNumberIsNull()) && this.getFncAgreementNumberIsNull()){
			c.andFncAgreementNumberIsNull();
		}
		if(CheckUtil.isNotEmpty(getFncAgreementNumberIsNotNull()) && this.getFncAgreementNumberIsNotNull()){
			c.andFncAgreementNumberIsNotNull();
		}
		if(CheckUtil.isNotEmpty(getFncAgreementNumberIn())){
			c.andFncAgreementNumberIn(this.getFncAgreementNumberIn());
		}
		if(CheckUtil.isNotEmpty(getFncAgreementNumberGreaterThanOrEqualTo())){
			c.andFncAgreementNumberGreaterThanOrEqualTo(this.getFncAgreementNumberGreaterThanOrEqualTo());
		}
		if(CheckUtil.isNotEmpty(getFncAgreementNumberGreaterThan())){
			c.andFncAgreementNumberGreaterThan(this.getFncAgreementNumberGreaterThan());
		}
		if(CheckUtil.isNotEmpty(getFncAgreementNumberEqualTo())){
			c.andFncAgreementNumberEqualTo(this.getFncAgreementNumberEqualTo());
		}
		if(CheckUtil.isNotEmpty(getFncAccountNoNotLike())){
			c.andFncAccountNoNotLike("%"+this.getFncAccountNoNotLike()+"%");
		}
		if(CheckUtil.isNotEmpty(getFncAccountNoNotIn())){
			c.andFncAccountNoNotIn(this.getFncAccountNoNotIn());
		}
		if(CheckUtil.isNotEmpty(getFncAccountNoNotEqualTo())){
			c.andFncAccountNoNotEqualTo(this.getFncAccountNoNotEqualTo());
		}
		if(CheckUtil.isNotEmpty(getFncAccountNoLike())){
			c.andFncAccountNoLike("%"+this.getFncAccountNoLike()+"%");
		}
		if(CheckUtil.isNotEmpty(getFncAccountNoLessThanOrEqualTo())){
			c.andFncAccountNoLessThanOrEqualTo(this.getFncAccountNoLessThanOrEqualTo());
		}
		if(CheckUtil.isNotEmpty(getFncAccountNoLessThan())){
			c.andFncAccountNoLessThan(this.getFncAccountNoLessThan());
		}
		if(CheckUtil.isNotEmpty(getFncAccountNoIsNull()) && this.getFncAccountNoIsNull()){
			c.andFncAccountNoIsNull();
		}
		if(CheckUtil.isNotEmpty(getFncAccountNoIsNotNull()) && this.getFncAccountNoIsNotNull()){
			c.andFncAccountNoIsNotNull();
		}
		if(CheckUtil.isNotEmpty(getFncAccountNoIn())){
			c.andFncAccountNoIn(this.getFncAccountNoIn());
		}
		if(CheckUtil.isNotEmpty(getFncAccountNoGreaterThanOrEqualTo())){
			c.andFncAccountNoGreaterThanOrEqualTo(this.getFncAccountNoGreaterThanOrEqualTo());
		}
		if(CheckUtil.isNotEmpty(getFncAccountNoGreaterThan())){
			c.andFncAccountNoGreaterThan(this.getFncAccountNoGreaterThan());
		}
		if(CheckUtil.isNotEmpty(getFncAccountNoEqualTo())){
			c.andFncAccountNoEqualTo(this.getFncAccountNoEqualTo());
		}
		if(CheckUtil.isNotEmpty(getFncAccountDealFlowNotLike())){
			c.andFncAccountDealFlowNotLike("%"+this.getFncAccountDealFlowNotLike()+"%");
		}
		if(CheckUtil.isNotEmpty(getFncAccountDealFlowNotIn())){
			c.andFncAccountDealFlowNotIn(this.getFncAccountDealFlowNotIn());
		}
		if(CheckUtil.isNotEmpty(getFncAccountDealFlowNotEqualTo())){
			c.andFncAccountDealFlowNotEqualTo(this.getFncAccountDealFlowNotEqualTo());
		}
		if(CheckUtil.isNotEmpty(getFncAccountDealFlowLike())){
			c.andFncAccountDealFlowLike("%"+this.getFncAccountDealFlowLike()+"%");
		}
		if(CheckUtil.isNotEmpty(getFncAccountDealFlowLessThanOrEqualTo())){
			c.andFncAccountDealFlowLessThanOrEqualTo(this.getFncAccountDealFlowLessThanOrEqualTo());
		}
		if(CheckUtil.isNotEmpty(getFncAccountDealFlowLessThan())){
			c.andFncAccountDealFlowLessThan(this.getFncAccountDealFlowLessThan());
		}
		if(CheckUtil.isNotEmpty(getFncAccountDealFlowIsNull()) && this.getFncAccountDealFlowIsNull()){
			c.andFncAccountDealFlowIsNull();
		}
		if(CheckUtil.isNotEmpty(getFncAccountDealFlowIsNotNull()) && this.getFncAccountDealFlowIsNotNull()){
			c.andFncAccountDealFlowIsNotNull();
		}
		if(CheckUtil.isNotEmpty(getFncAccountDealFlowIn())){
			c.andFncAccountDealFlowIn(this.getFncAccountDealFlowIn());
		}
		if(CheckUtil.isNotEmpty(getFncAccountDealFlowGreaterThanOrEqualTo())){
			c.andFncAccountDealFlowGreaterThanOrEqualTo(this.getFncAccountDealFlowGreaterThanOrEqualTo());
		}
		if(CheckUtil.isNotEmpty(getFncAccountDealFlowGreaterThan())){
			c.andFncAccountDealFlowGreaterThan(this.getFncAccountDealFlowGreaterThan());
		}
		if(CheckUtil.isNotEmpty(getFncAccountDealFlowEqualTo())){
			c.andFncAccountDealFlowEqualTo(this.getFncAccountDealFlowEqualTo());
		}
		if(CheckUtil.isNotEmpty(getDrNotIn())){
			c.andDrNotIn(this.getDrNotIn());
		}
		if(CheckUtil.isNotEmpty(getDrNotEqualTo())){
			c.andDrNotEqualTo(this.getDrNotEqualTo());
		}
		if(CheckUtil.isNotEmpty(getDrLessThanOrEqualTo())){
			c.andDrLessThanOrEqualTo(this.getDrLessThanOrEqualTo());
		}
		if(CheckUtil.isNotEmpty(getDrLessThan())){
			c.andDrLessThan(this.getDrLessThan());
		}
		if(CheckUtil.isNotEmpty(getDrIsNull()) && this.getDrIsNull()){
			c.andDrIsNull();
		}
		if(CheckUtil.isNotEmpty(getDrIsNotNull()) && this.getDrIsNotNull()){
			c.andDrIsNotNull();
		}
		if(CheckUtil.isNotEmpty(getDrIn())){
			c.andDrIn(this.getDrIn());
		}
		if(CheckUtil.isNotEmpty(getDrGreaterThanOrEqualTo())){
			c.andDrGreaterThanOrEqualTo(this.getDrGreaterThanOrEqualTo());
		}
		if(CheckUtil.isNotEmpty(getDrGreaterThan())){
			c.andDrGreaterThan(this.getDrGreaterThan());
		}
		if(CheckUtil.isNotEmpty(getDrEqualTo())){
			c.andDrEqualTo(this.getDrEqualTo());
		}
		if(CheckUtil.isNotEmpty(getCreateuserNotLike())){
			c.andCreateuserNotLike("%"+this.getCreateuserNotLike()+"%");
		}
		if(CheckUtil.isNotEmpty(getCreateuserNotIn())){
			c.andCreateuserNotIn(this.getCreateuserNotIn());
		}
		if(CheckUtil.isNotEmpty(getCreateuserNotEqualTo())){
			c.andCreateuserNotEqualTo(this.getCreateuserNotEqualTo());
		}
		if(CheckUtil.isNotEmpty(getCreateuserLike())){
			c.andCreateuserLike("%"+this.getCreateuserLike()+"%");
		}
		if(CheckUtil.isNotEmpty(getCreateuserLessThanOrEqualTo())){
			c.andCreateuserLessThanOrEqualTo(this.getCreateuserLessThanOrEqualTo());
		}
		if(CheckUtil.isNotEmpty(getCreateuserLessThan())){
			c.andCreateuserLessThan(this.getCreateuserLessThan());
		}
		if(CheckUtil.isNotEmpty(getCreateuserIsNull()) && this.getCreateuserIsNull()){
			c.andCreateuserIsNull();
		}
		if(CheckUtil.isNotEmpty(getCreateuserIsNotNull()) && this.getCreateuserIsNotNull()){
			c.andCreateuserIsNotNull();
		}
		if(CheckUtil.isNotEmpty(getCreateuserIn())){
			c.andCreateuserIn(this.getCreateuserIn());
		}
		if(CheckUtil.isNotEmpty(getCreateuserGreaterThanOrEqualTo())){
			c.andCreateuserGreaterThanOrEqualTo(this.getCreateuserGreaterThanOrEqualTo());
		}
		if(CheckUtil.isNotEmpty(getCreateuserGreaterThan())){
			c.andCreateuserGreaterThan(this.getCreateuserGreaterThan());
		}
		if(CheckUtil.isNotEmpty(getCreateuserEqualTo())){
			c.andCreateuserEqualTo(this.getCreateuserEqualTo());
		}
		if(CheckUtil.isNotEmpty(getCreatetimeNotIn())){
			c.andCreatetimeNotIn(this.getCreatetimeNotIn());
		}
		if(CheckUtil.isNotEmpty(getCreatetimeNotEqualTo())){
			c.andCreatetimeNotEqualTo(this.getCreatetimeNotEqualTo());
		}
		if(CheckUtil.isNotEmpty(getCreatetimeLessThanOrEqualTo())){
			c.andCreatetimeLessThanOrEqualTo(this.getCreatetimeLessThanOrEqualTo());
		}
		if(CheckUtil.isNotEmpty(getCreatetimeLessThan())){
			c.andCreatetimeLessThan(this.getCreatetimeLessThan());
		}
		if(CheckUtil.isNotEmpty(getCreatetimeIsNull()) && this.getCreatetimeIsNull()){
			c.andCreatetimeIsNull();
		}
		if(CheckUtil.isNotEmpty(getCreatetimeIsNotNull()) && this.getCreatetimeIsNotNull()){
			c.andCreatetimeIsNotNull();
		}
		if(CheckUtil.isNotEmpty(getCreatetimeIn())){
			c.andCreatetimeIn(this.getCreatetimeIn());
		}
		if(CheckUtil.isNotEmpty(getCreatetimeGreaterThanOrEqualTo())){
			c.andCreatetimeGreaterThanOrEqualTo(this.getCreatetimeGreaterThanOrEqualTo());
		}
		if(CheckUtil.isNotEmpty(getCreatetimeGreaterThan())){
			c.andCreatetimeGreaterThan(this.getCreatetimeGreaterThan());
		}
		if(CheckUtil.isNotEmpty(getCreatetimeEqualTo())){
			c.andCreatetimeEqualTo(this.getCreatetimeEqualTo());
		}
		if((this.getSidx()!=null && !this.getSidx().trim().equals("")) && this.getSord()!=null) {
			q.setOrderByClause(""+ this.getSidx()+" "+this.getSord());
		}
		return q;
	}
	public String getUpdateuserNotLike() {
		return updateuserNotLike;
	}
	public void setUpdateuserNotLike(String updateuserNotLike) {
		this.updateuserNotLike = updateuserNotLike;
	}

	public java.util.List getUpdateuserNotIn() {
		return updateuserNotIn;
	}
	public void setUpdateuserNotIn(java.util.List updateuserNotIn) {
		this.updateuserNotIn = updateuserNotIn;
	}

	public String getUpdateuserNotEqualTo() {
		return updateuserNotEqualTo;
	}
	public void setUpdateuserNotEqualTo(String updateuserNotEqualTo) {
		this.updateuserNotEqualTo = updateuserNotEqualTo;
	}

	public String getUpdateuserLike() {
		return updateuserLike;
	}
	public void setUpdateuserLike(String updateuserLike) {
		this.updateuserLike = updateuserLike;
	}

	public String getUpdateuserLessThanOrEqualTo() {
		return updateuserLessThanOrEqualTo;
	}
	public void setUpdateuserLessThanOrEqualTo(String updateuserLessThanOrEqualTo) {
		this.updateuserLessThanOrEqualTo = updateuserLessThanOrEqualTo;
	}

	public String getUpdateuserLessThan() {
		return updateuserLessThan;
	}
	public void setUpdateuserLessThan(String updateuserLessThan) {
		this.updateuserLessThan = updateuserLessThan;
	}

	public Boolean getUpdateuserIsNull() {
		return updateuserIsNull;
	}
	public void setUpdateuserIsNull(Boolean updateuserIsNull) {
		this.updateuserIsNull = updateuserIsNull;
	}

	public Boolean getUpdateuserIsNotNull() {
		return updateuserIsNotNull;
	}
	public void setUpdateuserIsNotNull(Boolean updateuserIsNotNull) {
		this.updateuserIsNotNull = updateuserIsNotNull;
	}

	public java.util.List getUpdateuserIn() {
		return updateuserIn;
	}
	public void setUpdateuserIn(java.util.List updateuserIn) {
		this.updateuserIn = updateuserIn;
	}

	public String getUpdateuserGreaterThanOrEqualTo() {
		return updateuserGreaterThanOrEqualTo;
	}
	public void setUpdateuserGreaterThanOrEqualTo(String updateuserGreaterThanOrEqualTo) {
		this.updateuserGreaterThanOrEqualTo = updateuserGreaterThanOrEqualTo;
	}

	public String getUpdateuserGreaterThan() {
		return updateuserGreaterThan;
	}
	public void setUpdateuserGreaterThan(String updateuserGreaterThan) {
		this.updateuserGreaterThan = updateuserGreaterThan;
	}

	public String getUpdateuserEqualTo() {
		return updateuserEqualTo;
	}
	public void setUpdateuserEqualTo(String updateuserEqualTo) {
		this.updateuserEqualTo = updateuserEqualTo;
	}

	public java.util.List getUpdatetimeNotIn() {
		return updatetimeNotIn;
	}
	public void setUpdatetimeNotIn(java.util.List updatetimeNotIn) {
		this.updatetimeNotIn = updatetimeNotIn;
	}

	public java.util.Date getUpdatetimeNotEqualTo() {
		return updatetimeNotEqualTo;
	}
	public void setUpdatetimeNotEqualTo(java.util.Date updatetimeNotEqualTo) {
		this.updatetimeNotEqualTo = updatetimeNotEqualTo;
	}

	public java.util.Date getUpdatetimeLessThanOrEqualTo() {
		return updatetimeLessThanOrEqualTo;
	}
	public void setUpdatetimeLessThanOrEqualTo(java.util.Date updatetimeLessThanOrEqualTo) {
		this.updatetimeLessThanOrEqualTo = updatetimeLessThanOrEqualTo;
	}

	public java.util.Date getUpdatetimeLessThan() {
		return updatetimeLessThan;
	}
	public void setUpdatetimeLessThan(java.util.Date updatetimeLessThan) {
		this.updatetimeLessThan = updatetimeLessThan;
	}

	public Boolean getUpdatetimeIsNull() {
		return updatetimeIsNull;
	}
	public void setUpdatetimeIsNull(Boolean updatetimeIsNull) {
		this.updatetimeIsNull = updatetimeIsNull;
	}

	public Boolean getUpdatetimeIsNotNull() {
		return updatetimeIsNotNull;
	}
	public void setUpdatetimeIsNotNull(Boolean updatetimeIsNotNull) {
		this.updatetimeIsNotNull = updatetimeIsNotNull;
	}

	public java.util.List getUpdatetimeIn() {
		return updatetimeIn;
	}
	public void setUpdatetimeIn(java.util.List updatetimeIn) {
		this.updatetimeIn = updatetimeIn;
	}

	public java.util.Date getUpdatetimeGreaterThanOrEqualTo() {
		return updatetimeGreaterThanOrEqualTo;
	}
	public void setUpdatetimeGreaterThanOrEqualTo(java.util.Date updatetimeGreaterThanOrEqualTo) {
		this.updatetimeGreaterThanOrEqualTo = updatetimeGreaterThanOrEqualTo;
	}

	public java.util.Date getUpdatetimeGreaterThan() {
		return updatetimeGreaterThan;
	}
	public void setUpdatetimeGreaterThan(java.util.Date updatetimeGreaterThan) {
		this.updatetimeGreaterThan = updatetimeGreaterThan;
	}

	public java.util.Date getUpdatetimeEqualTo() {
		return updatetimeEqualTo;
	}
	public void setUpdatetimeEqualTo(java.util.Date updatetimeEqualTo) {
		this.updatetimeEqualTo = updatetimeEqualTo;
	}

	public String getRemarkNotLike() {
		return remarkNotLike;
	}
	public void setRemarkNotLike(String remarkNotLike) {
		this.remarkNotLike = remarkNotLike;
	}

	public java.util.List getRemarkNotIn() {
		return remarkNotIn;
	}
	public void setRemarkNotIn(java.util.List remarkNotIn) {
		this.remarkNotIn = remarkNotIn;
	}

	public String getRemarkNotEqualTo() {
		return remarkNotEqualTo;
	}
	public void setRemarkNotEqualTo(String remarkNotEqualTo) {
		this.remarkNotEqualTo = remarkNotEqualTo;
	}

	public String getRemarkLike() {
		return remarkLike;
	}
	public void setRemarkLike(String remarkLike) {
		this.remarkLike = remarkLike;
	}

	public String getRemarkLessThanOrEqualTo() {
		return remarkLessThanOrEqualTo;
	}
	public void setRemarkLessThanOrEqualTo(String remarkLessThanOrEqualTo) {
		this.remarkLessThanOrEqualTo = remarkLessThanOrEqualTo;
	}

	public String getRemarkLessThan() {
		return remarkLessThan;
	}
	public void setRemarkLessThan(String remarkLessThan) {
		this.remarkLessThan = remarkLessThan;
	}

	public Boolean getRemarkIsNull() {
		return remarkIsNull;
	}
	public void setRemarkIsNull(Boolean remarkIsNull) {
		this.remarkIsNull = remarkIsNull;
	}

	public Boolean getRemarkIsNotNull() {
		return remarkIsNotNull;
	}
	public void setRemarkIsNotNull(Boolean remarkIsNotNull) {
		this.remarkIsNotNull = remarkIsNotNull;
	}

	public java.util.List getRemarkIn() {
		return remarkIn;
	}
	public void setRemarkIn(java.util.List remarkIn) {
		this.remarkIn = remarkIn;
	}

	public String getRemarkGreaterThanOrEqualTo() {
		return remarkGreaterThanOrEqualTo;
	}
	public void setRemarkGreaterThanOrEqualTo(String remarkGreaterThanOrEqualTo) {
		this.remarkGreaterThanOrEqualTo = remarkGreaterThanOrEqualTo;
	}

	public String getRemarkGreaterThan() {
		return remarkGreaterThan;
	}
	public void setRemarkGreaterThan(String remarkGreaterThan) {
		this.remarkGreaterThan = remarkGreaterThan;
	}

	public String getRemarkEqualTo() {
		return remarkEqualTo;
	}
	public void setRemarkEqualTo(String remarkEqualTo) {
		this.remarkEqualTo = remarkEqualTo;
	}

	public String getFncVoucherNoNotLike() {
		return fncVoucherNoNotLike;
	}
	public void setFncVoucherNoNotLike(String fncVoucherNoNotLike) {
		this.fncVoucherNoNotLike = fncVoucherNoNotLike;
	}

	public java.util.List getFncVoucherNoNotIn() {
		return fncVoucherNoNotIn;
	}
	public void setFncVoucherNoNotIn(java.util.List fncVoucherNoNotIn) {
		this.fncVoucherNoNotIn = fncVoucherNoNotIn;
	}

	public String getFncVoucherNoNotEqualTo() {
		return fncVoucherNoNotEqualTo;
	}
	public void setFncVoucherNoNotEqualTo(String fncVoucherNoNotEqualTo) {
		this.fncVoucherNoNotEqualTo = fncVoucherNoNotEqualTo;
	}

	public String getFncVoucherNoLike() {
		return fncVoucherNoLike;
	}
	public void setFncVoucherNoLike(String fncVoucherNoLike) {
		this.fncVoucherNoLike = fncVoucherNoLike;
	}

	public String getFncVoucherNoLessThanOrEqualTo() {
		return fncVoucherNoLessThanOrEqualTo;
	}
	public void setFncVoucherNoLessThanOrEqualTo(String fncVoucherNoLessThanOrEqualTo) {
		this.fncVoucherNoLessThanOrEqualTo = fncVoucherNoLessThanOrEqualTo;
	}

	public String getFncVoucherNoLessThan() {
		return fncVoucherNoLessThan;
	}
	public void setFncVoucherNoLessThan(String fncVoucherNoLessThan) {
		this.fncVoucherNoLessThan = fncVoucherNoLessThan;
	}

	public Boolean getFncVoucherNoIsNull() {
		return fncVoucherNoIsNull;
	}
	public void setFncVoucherNoIsNull(Boolean fncVoucherNoIsNull) {
		this.fncVoucherNoIsNull = fncVoucherNoIsNull;
	}

	public Boolean getFncVoucherNoIsNotNull() {
		return fncVoucherNoIsNotNull;
	}
	public void setFncVoucherNoIsNotNull(Boolean fncVoucherNoIsNotNull) {
		this.fncVoucherNoIsNotNull = fncVoucherNoIsNotNull;
	}

	public java.util.List getFncVoucherNoIn() {
		return fncVoucherNoIn;
	}
	public void setFncVoucherNoIn(java.util.List fncVoucherNoIn) {
		this.fncVoucherNoIn = fncVoucherNoIn;
	}

	public String getFncVoucherNoGreaterThanOrEqualTo() {
		return fncVoucherNoGreaterThanOrEqualTo;
	}
	public void setFncVoucherNoGreaterThanOrEqualTo(String fncVoucherNoGreaterThanOrEqualTo) {
		this.fncVoucherNoGreaterThanOrEqualTo = fncVoucherNoGreaterThanOrEqualTo;
	}

	public String getFncVoucherNoGreaterThan() {
		return fncVoucherNoGreaterThan;
	}
	public void setFncVoucherNoGreaterThan(String fncVoucherNoGreaterThan) {
		this.fncVoucherNoGreaterThan = fncVoucherNoGreaterThan;
	}

	public String getFncVoucherNoEqualTo() {
		return fncVoucherNoEqualTo;
	}
	public void setFncVoucherNoEqualTo(String fncVoucherNoEqualTo) {
		this.fncVoucherNoEqualTo = fncVoucherNoEqualTo;
	}

	public String getFncUseNotLike() {
		return fncUseNotLike;
	}
	public void setFncUseNotLike(String fncUseNotLike) {
		this.fncUseNotLike = fncUseNotLike;
	}

	public java.util.List getFncUseNotIn() {
		return fncUseNotIn;
	}
	public void setFncUseNotIn(java.util.List fncUseNotIn) {
		this.fncUseNotIn = fncUseNotIn;
	}

	public String getFncUseNotEqualTo() {
		return fncUseNotEqualTo;
	}
	public void setFncUseNotEqualTo(String fncUseNotEqualTo) {
		this.fncUseNotEqualTo = fncUseNotEqualTo;
	}

	public String getFncUseLike() {
		return fncUseLike;
	}
	public void setFncUseLike(String fncUseLike) {
		this.fncUseLike = fncUseLike;
	}

	public String getFncUseLessThanOrEqualTo() {
		return fncUseLessThanOrEqualTo;
	}
	public void setFncUseLessThanOrEqualTo(String fncUseLessThanOrEqualTo) {
		this.fncUseLessThanOrEqualTo = fncUseLessThanOrEqualTo;
	}

	public String getFncUseLessThan() {
		return fncUseLessThan;
	}
	public void setFncUseLessThan(String fncUseLessThan) {
		this.fncUseLessThan = fncUseLessThan;
	}

	public Boolean getFncUseIsNull() {
		return fncUseIsNull;
	}
	public void setFncUseIsNull(Boolean fncUseIsNull) {
		this.fncUseIsNull = fncUseIsNull;
	}

	public Boolean getFncUseIsNotNull() {
		return fncUseIsNotNull;
	}
	public void setFncUseIsNotNull(Boolean fncUseIsNotNull) {
		this.fncUseIsNotNull = fncUseIsNotNull;
	}

	public java.util.List getFncUseIn() {
		return fncUseIn;
	}
	public void setFncUseIn(java.util.List fncUseIn) {
		this.fncUseIn = fncUseIn;
	}

	public String getFncUseGreaterThanOrEqualTo() {
		return fncUseGreaterThanOrEqualTo;
	}
	public void setFncUseGreaterThanOrEqualTo(String fncUseGreaterThanOrEqualTo) {
		this.fncUseGreaterThanOrEqualTo = fncUseGreaterThanOrEqualTo;
	}

	public String getFncUseGreaterThan() {
		return fncUseGreaterThan;
	}
	public void setFncUseGreaterThan(String fncUseGreaterThan) {
		this.fncUseGreaterThan = fncUseGreaterThan;
	}

	public String getFncUseEqualTo() {
		return fncUseEqualTo;
	}
	public void setFncUseEqualTo(String fncUseEqualTo) {
		this.fncUseEqualTo = fncUseEqualTo;
	}

	public java.util.List getFncTradeTimeNotIn() {
		return fncTradeTimeNotIn;
	}
	public void setFncTradeTimeNotIn(java.util.List fncTradeTimeNotIn) {
		this.fncTradeTimeNotIn = fncTradeTimeNotIn;
	}

	public java.util.Date getFncTradeTimeNotEqualTo() {
		return fncTradeTimeNotEqualTo;
	}
	public void setFncTradeTimeNotEqualTo(java.util.Date fncTradeTimeNotEqualTo) {
		this.fncTradeTimeNotEqualTo = fncTradeTimeNotEqualTo;
	}

	public java.util.Date getFncTradeTimeLessThanOrEqualTo() {
		return fncTradeTimeLessThanOrEqualTo;
	}
	public void setFncTradeTimeLessThanOrEqualTo(java.util.Date fncTradeTimeLessThanOrEqualTo) {
		this.fncTradeTimeLessThanOrEqualTo = fncTradeTimeLessThanOrEqualTo;
	}

	public java.util.Date getFncTradeTimeLessThan() {
		return fncTradeTimeLessThan;
	}
	public void setFncTradeTimeLessThan(java.util.Date fncTradeTimeLessThan) {
		this.fncTradeTimeLessThan = fncTradeTimeLessThan;
	}

	public Boolean getFncTradeTimeIsNull() {
		return fncTradeTimeIsNull;
	}
	public void setFncTradeTimeIsNull(Boolean fncTradeTimeIsNull) {
		this.fncTradeTimeIsNull = fncTradeTimeIsNull;
	}

	public Boolean getFncTradeTimeIsNotNull() {
		return fncTradeTimeIsNotNull;
	}
	public void setFncTradeTimeIsNotNull(Boolean fncTradeTimeIsNotNull) {
		this.fncTradeTimeIsNotNull = fncTradeTimeIsNotNull;
	}

	public java.util.List getFncTradeTimeIn() {
		return fncTradeTimeIn;
	}
	public void setFncTradeTimeIn(java.util.List fncTradeTimeIn) {
		this.fncTradeTimeIn = fncTradeTimeIn;
	}

	public java.util.Date getFncTradeTimeGreaterThanOrEqualTo() {
		return fncTradeTimeGreaterThanOrEqualTo;
	}
	public void setFncTradeTimeGreaterThanOrEqualTo(java.util.Date fncTradeTimeGreaterThanOrEqualTo) {
		this.fncTradeTimeGreaterThanOrEqualTo = fncTradeTimeGreaterThanOrEqualTo;
	}

	public java.util.Date getFncTradeTimeGreaterThan() {
		return fncTradeTimeGreaterThan;
	}
	public void setFncTradeTimeGreaterThan(java.util.Date fncTradeTimeGreaterThan) {
		this.fncTradeTimeGreaterThan = fncTradeTimeGreaterThan;
	}

	public java.util.Date getFncTradeTimeEqualTo() {
		return fncTradeTimeEqualTo;
	}
	public void setFncTradeTimeEqualTo(java.util.Date fncTradeTimeEqualTo) {
		this.fncTradeTimeEqualTo = fncTradeTimeEqualTo;
	}

	public String getFncTradePartyNotLike() {
		return fncTradePartyNotLike;
	}
	public void setFncTradePartyNotLike(String fncTradePartyNotLike) {
		this.fncTradePartyNotLike = fncTradePartyNotLike;
	}

	public java.util.List getFncTradePartyNotIn() {
		return fncTradePartyNotIn;
	}
	public void setFncTradePartyNotIn(java.util.List fncTradePartyNotIn) {
		this.fncTradePartyNotIn = fncTradePartyNotIn;
	}

	public String getFncTradePartyNotEqualTo() {
		return fncTradePartyNotEqualTo;
	}
	public void setFncTradePartyNotEqualTo(String fncTradePartyNotEqualTo) {
		this.fncTradePartyNotEqualTo = fncTradePartyNotEqualTo;
	}

	public String getFncTradePartyLike() {
		return fncTradePartyLike;
	}
	public void setFncTradePartyLike(String fncTradePartyLike) {
		this.fncTradePartyLike = fncTradePartyLike;
	}

	public String getFncTradePartyLessThanOrEqualTo() {
		return fncTradePartyLessThanOrEqualTo;
	}
	public void setFncTradePartyLessThanOrEqualTo(String fncTradePartyLessThanOrEqualTo) {
		this.fncTradePartyLessThanOrEqualTo = fncTradePartyLessThanOrEqualTo;
	}

	public String getFncTradePartyLessThan() {
		return fncTradePartyLessThan;
	}
	public void setFncTradePartyLessThan(String fncTradePartyLessThan) {
		this.fncTradePartyLessThan = fncTradePartyLessThan;
	}

	public Boolean getFncTradePartyIsNull() {
		return fncTradePartyIsNull;
	}
	public void setFncTradePartyIsNull(Boolean fncTradePartyIsNull) {
		this.fncTradePartyIsNull = fncTradePartyIsNull;
	}

	public Boolean getFncTradePartyIsNotNull() {
		return fncTradePartyIsNotNull;
	}
	public void setFncTradePartyIsNotNull(Boolean fncTradePartyIsNotNull) {
		this.fncTradePartyIsNotNull = fncTradePartyIsNotNull;
	}

	public java.util.List getFncTradePartyIn() {
		return fncTradePartyIn;
	}
	public void setFncTradePartyIn(java.util.List fncTradePartyIn) {
		this.fncTradePartyIn = fncTradePartyIn;
	}

	public String getFncTradePartyGreaterThanOrEqualTo() {
		return fncTradePartyGreaterThanOrEqualTo;
	}
	public void setFncTradePartyGreaterThanOrEqualTo(String fncTradePartyGreaterThanOrEqualTo) {
		this.fncTradePartyGreaterThanOrEqualTo = fncTradePartyGreaterThanOrEqualTo;
	}

	public String getFncTradePartyGreaterThan() {
		return fncTradePartyGreaterThan;
	}
	public void setFncTradePartyGreaterThan(String fncTradePartyGreaterThan) {
		this.fncTradePartyGreaterThan = fncTradePartyGreaterThan;
	}

	public String getFncTradePartyEqualTo() {
		return fncTradePartyEqualTo;
	}
	public void setFncTradePartyEqualTo(String fncTradePartyEqualTo) {
		this.fncTradePartyEqualTo = fncTradePartyEqualTo;
	}

	public String getFncTradeNamesNotLike() {
		return fncTradeNamesNotLike;
	}
	public void setFncTradeNamesNotLike(String fncTradeNamesNotLike) {
		this.fncTradeNamesNotLike = fncTradeNamesNotLike;
	}

	public java.util.List getFncTradeNamesNotIn() {
		return fncTradeNamesNotIn;
	}
	public void setFncTradeNamesNotIn(java.util.List fncTradeNamesNotIn) {
		this.fncTradeNamesNotIn = fncTradeNamesNotIn;
	}

	public String getFncTradeNamesNotEqualTo() {
		return fncTradeNamesNotEqualTo;
	}
	public void setFncTradeNamesNotEqualTo(String fncTradeNamesNotEqualTo) {
		this.fncTradeNamesNotEqualTo = fncTradeNamesNotEqualTo;
	}

	public String getFncTradeNamesLike() {
		return fncTradeNamesLike;
	}
	public void setFncTradeNamesLike(String fncTradeNamesLike) {
		this.fncTradeNamesLike = fncTradeNamesLike;
	}

	public String getFncTradeNamesLessThanOrEqualTo() {
		return fncTradeNamesLessThanOrEqualTo;
	}
	public void setFncTradeNamesLessThanOrEqualTo(String fncTradeNamesLessThanOrEqualTo) {
		this.fncTradeNamesLessThanOrEqualTo = fncTradeNamesLessThanOrEqualTo;
	}

	public String getFncTradeNamesLessThan() {
		return fncTradeNamesLessThan;
	}
	public void setFncTradeNamesLessThan(String fncTradeNamesLessThan) {
		this.fncTradeNamesLessThan = fncTradeNamesLessThan;
	}

	public Boolean getFncTradeNamesIsNull() {
		return fncTradeNamesIsNull;
	}
	public void setFncTradeNamesIsNull(Boolean fncTradeNamesIsNull) {
		this.fncTradeNamesIsNull = fncTradeNamesIsNull;
	}

	public Boolean getFncTradeNamesIsNotNull() {
		return fncTradeNamesIsNotNull;
	}
	public void setFncTradeNamesIsNotNull(Boolean fncTradeNamesIsNotNull) {
		this.fncTradeNamesIsNotNull = fncTradeNamesIsNotNull;
	}

	public java.util.List getFncTradeNamesIn() {
		return fncTradeNamesIn;
	}
	public void setFncTradeNamesIn(java.util.List fncTradeNamesIn) {
		this.fncTradeNamesIn = fncTradeNamesIn;
	}

	public String getFncTradeNamesGreaterThanOrEqualTo() {
		return fncTradeNamesGreaterThanOrEqualTo;
	}
	public void setFncTradeNamesGreaterThanOrEqualTo(String fncTradeNamesGreaterThanOrEqualTo) {
		this.fncTradeNamesGreaterThanOrEqualTo = fncTradeNamesGreaterThanOrEqualTo;
	}

	public String getFncTradeNamesGreaterThan() {
		return fncTradeNamesGreaterThan;
	}
	public void setFncTradeNamesGreaterThan(String fncTradeNamesGreaterThan) {
		this.fncTradeNamesGreaterThan = fncTradeNamesGreaterThan;
	}

	public String getFncTradeNamesEqualTo() {
		return fncTradeNamesEqualTo;
	}
	public void setFncTradeNamesEqualTo(String fncTradeNamesEqualTo) {
		this.fncTradeNamesEqualTo = fncTradeNamesEqualTo;
	}

	public java.util.List getFncTradeAmountNotIn() {
		return fncTradeAmountNotIn;
	}
	public void setFncTradeAmountNotIn(java.util.List fncTradeAmountNotIn) {
		this.fncTradeAmountNotIn = fncTradeAmountNotIn;
	}

	public Double getFncTradeAmountNotEqualTo() {
		return fncTradeAmountNotEqualTo;
	}
	public void setFncTradeAmountNotEqualTo(Double fncTradeAmountNotEqualTo) {
		this.fncTradeAmountNotEqualTo = fncTradeAmountNotEqualTo;
	}

	public Double getFncTradeAmountLessThanOrEqualTo() {
		return fncTradeAmountLessThanOrEqualTo;
	}
	public void setFncTradeAmountLessThanOrEqualTo(Double fncTradeAmountLessThanOrEqualTo) {
		this.fncTradeAmountLessThanOrEqualTo = fncTradeAmountLessThanOrEqualTo;
	}

	public Double getFncTradeAmountLessThan() {
		return fncTradeAmountLessThan;
	}
	public void setFncTradeAmountLessThan(Double fncTradeAmountLessThan) {
		this.fncTradeAmountLessThan = fncTradeAmountLessThan;
	}

	public Boolean getFncTradeAmountIsNull() {
		return fncTradeAmountIsNull;
	}
	public void setFncTradeAmountIsNull(Boolean fncTradeAmountIsNull) {
		this.fncTradeAmountIsNull = fncTradeAmountIsNull;
	}

	public Boolean getFncTradeAmountIsNotNull() {
		return fncTradeAmountIsNotNull;
	}
	public void setFncTradeAmountIsNotNull(Boolean fncTradeAmountIsNotNull) {
		this.fncTradeAmountIsNotNull = fncTradeAmountIsNotNull;
	}

	public java.util.List getFncTradeAmountIn() {
		return fncTradeAmountIn;
	}
	public void setFncTradeAmountIn(java.util.List fncTradeAmountIn) {
		this.fncTradeAmountIn = fncTradeAmountIn;
	}

	public Double getFncTradeAmountGreaterThanOrEqualTo() {
		return fncTradeAmountGreaterThanOrEqualTo;
	}
	public void setFncTradeAmountGreaterThanOrEqualTo(Double fncTradeAmountGreaterThanOrEqualTo) {
		this.fncTradeAmountGreaterThanOrEqualTo = fncTradeAmountGreaterThanOrEqualTo;
	}

	public Double getFncTradeAmountGreaterThan() {
		return fncTradeAmountGreaterThan;
	}
	public void setFncTradeAmountGreaterThan(Double fncTradeAmountGreaterThan) {
		this.fncTradeAmountGreaterThan = fncTradeAmountGreaterThan;
	}

	public Double getFncTradeAmountEqualTo() {
		return fncTradeAmountEqualTo;
	}
	public void setFncTradeAmountEqualTo(Double fncTradeAmountEqualTo) {
		this.fncTradeAmountEqualTo = fncTradeAmountEqualTo;
	}

	public java.util.List getFncRentDateNotIn() {
		return fncRentDateNotIn;
	}
	public void setFncRentDateNotIn(java.util.List fncRentDateNotIn) {
		this.fncRentDateNotIn = fncRentDateNotIn;
	}

	public java.util.Date getFncRentDateNotEqualTo() {
		return fncRentDateNotEqualTo;
	}
	public void setFncRentDateNotEqualTo(java.util.Date fncRentDateNotEqualTo) {
		this.fncRentDateNotEqualTo = fncRentDateNotEqualTo;
	}

	public java.util.Date getFncRentDateLessThanOrEqualTo() {
		return fncRentDateLessThanOrEqualTo;
	}
	public void setFncRentDateLessThanOrEqualTo(java.util.Date fncRentDateLessThanOrEqualTo) {
		this.fncRentDateLessThanOrEqualTo = fncRentDateLessThanOrEqualTo;
	}

	public java.util.Date getFncRentDateLessThan() {
		return fncRentDateLessThan;
	}
	public void setFncRentDateLessThan(java.util.Date fncRentDateLessThan) {
		this.fncRentDateLessThan = fncRentDateLessThan;
	}

	public Boolean getFncRentDateIsNull() {
		return fncRentDateIsNull;
	}
	public void setFncRentDateIsNull(Boolean fncRentDateIsNull) {
		this.fncRentDateIsNull = fncRentDateIsNull;
	}

	public Boolean getFncRentDateIsNotNull() {
		return fncRentDateIsNotNull;
	}
	public void setFncRentDateIsNotNull(Boolean fncRentDateIsNotNull) {
		this.fncRentDateIsNotNull = fncRentDateIsNotNull;
	}

	public java.util.List getFncRentDateIn() {
		return fncRentDateIn;
	}
	public void setFncRentDateIn(java.util.List fncRentDateIn) {
		this.fncRentDateIn = fncRentDateIn;
	}

	public java.util.Date getFncRentDateGreaterThanOrEqualTo() {
		return fncRentDateGreaterThanOrEqualTo;
	}
	public void setFncRentDateGreaterThanOrEqualTo(java.util.Date fncRentDateGreaterThanOrEqualTo) {
		this.fncRentDateGreaterThanOrEqualTo = fncRentDateGreaterThanOrEqualTo;
	}

	public java.util.Date getFncRentDateGreaterThan() {
		return fncRentDateGreaterThan;
	}
	public void setFncRentDateGreaterThan(java.util.Date fncRentDateGreaterThan) {
		this.fncRentDateGreaterThan = fncRentDateGreaterThan;
	}

	public java.util.Date getFncRentDateEqualTo() {
		return fncRentDateEqualTo;
	}
	public void setFncRentDateEqualTo(java.util.Date fncRentDateEqualTo) {
		this.fncRentDateEqualTo = fncRentDateEqualTo;
	}

	public String getFncOwnAccountNotLike() {
		return fncOwnAccountNotLike;
	}
	public void setFncOwnAccountNotLike(String fncOwnAccountNotLike) {
		this.fncOwnAccountNotLike = fncOwnAccountNotLike;
	}

	public java.util.List getFncOwnAccountNotIn() {
		return fncOwnAccountNotIn;
	}
	public void setFncOwnAccountNotIn(java.util.List fncOwnAccountNotIn) {
		this.fncOwnAccountNotIn = fncOwnAccountNotIn;
	}

	public String getFncOwnAccountNotEqualTo() {
		return fncOwnAccountNotEqualTo;
	}
	public void setFncOwnAccountNotEqualTo(String fncOwnAccountNotEqualTo) {
		this.fncOwnAccountNotEqualTo = fncOwnAccountNotEqualTo;
	}

	public String getFncOwnAccountLike() {
		return fncOwnAccountLike;
	}
	public void setFncOwnAccountLike(String fncOwnAccountLike) {
		this.fncOwnAccountLike = fncOwnAccountLike;
	}

	public String getFncOwnAccountLessThanOrEqualTo() {
		return fncOwnAccountLessThanOrEqualTo;
	}
	public void setFncOwnAccountLessThanOrEqualTo(String fncOwnAccountLessThanOrEqualTo) {
		this.fncOwnAccountLessThanOrEqualTo = fncOwnAccountLessThanOrEqualTo;
	}

	public String getFncOwnAccountLessThan() {
		return fncOwnAccountLessThan;
	}
	public void setFncOwnAccountLessThan(String fncOwnAccountLessThan) {
		this.fncOwnAccountLessThan = fncOwnAccountLessThan;
	}

	public Boolean getFncOwnAccountIsNull() {
		return fncOwnAccountIsNull;
	}
	public void setFncOwnAccountIsNull(Boolean fncOwnAccountIsNull) {
		this.fncOwnAccountIsNull = fncOwnAccountIsNull;
	}

	public Boolean getFncOwnAccountIsNotNull() {
		return fncOwnAccountIsNotNull;
	}
	public void setFncOwnAccountIsNotNull(Boolean fncOwnAccountIsNotNull) {
		this.fncOwnAccountIsNotNull = fncOwnAccountIsNotNull;
	}

	public java.util.List getFncOwnAccountIn() {
		return fncOwnAccountIn;
	}
	public void setFncOwnAccountIn(java.util.List fncOwnAccountIn) {
		this.fncOwnAccountIn = fncOwnAccountIn;
	}

	public String getFncOwnAccountGreaterThanOrEqualTo() {
		return fncOwnAccountGreaterThanOrEqualTo;
	}
	public void setFncOwnAccountGreaterThanOrEqualTo(String fncOwnAccountGreaterThanOrEqualTo) {
		this.fncOwnAccountGreaterThanOrEqualTo = fncOwnAccountGreaterThanOrEqualTo;
	}

	public String getFncOwnAccountGreaterThan() {
		return fncOwnAccountGreaterThan;
	}
	public void setFncOwnAccountGreaterThan(String fncOwnAccountGreaterThan) {
		this.fncOwnAccountGreaterThan = fncOwnAccountGreaterThan;
	}

	public String getFncOwnAccountEqualTo() {
		return fncOwnAccountEqualTo;
	}
	public void setFncOwnAccountEqualTo(String fncOwnAccountEqualTo) {
		this.fncOwnAccountEqualTo = fncOwnAccountEqualTo;
	}

	public String getFncOtherUnitNameNotLike() {
		return fncOtherUnitNameNotLike;
	}
	public void setFncOtherUnitNameNotLike(String fncOtherUnitNameNotLike) {
		this.fncOtherUnitNameNotLike = fncOtherUnitNameNotLike;
	}

	public java.util.List getFncOtherUnitNameNotIn() {
		return fncOtherUnitNameNotIn;
	}
	public void setFncOtherUnitNameNotIn(java.util.List fncOtherUnitNameNotIn) {
		this.fncOtherUnitNameNotIn = fncOtherUnitNameNotIn;
	}

	public String getFncOtherUnitNameNotEqualTo() {
		return fncOtherUnitNameNotEqualTo;
	}
	public void setFncOtherUnitNameNotEqualTo(String fncOtherUnitNameNotEqualTo) {
		this.fncOtherUnitNameNotEqualTo = fncOtherUnitNameNotEqualTo;
	}

	public String getFncOtherUnitNameLike() {
		return fncOtherUnitNameLike;
	}
	public void setFncOtherUnitNameLike(String fncOtherUnitNameLike) {
		this.fncOtherUnitNameLike = fncOtherUnitNameLike;
	}

	public String getFncOtherUnitNameLessThanOrEqualTo() {
		return fncOtherUnitNameLessThanOrEqualTo;
	}
	public void setFncOtherUnitNameLessThanOrEqualTo(String fncOtherUnitNameLessThanOrEqualTo) {
		this.fncOtherUnitNameLessThanOrEqualTo = fncOtherUnitNameLessThanOrEqualTo;
	}

	public String getFncOtherUnitNameLessThan() {
		return fncOtherUnitNameLessThan;
	}
	public void setFncOtherUnitNameLessThan(String fncOtherUnitNameLessThan) {
		this.fncOtherUnitNameLessThan = fncOtherUnitNameLessThan;
	}

	public Boolean getFncOtherUnitNameIsNull() {
		return fncOtherUnitNameIsNull;
	}
	public void setFncOtherUnitNameIsNull(Boolean fncOtherUnitNameIsNull) {
		this.fncOtherUnitNameIsNull = fncOtherUnitNameIsNull;
	}

	public Boolean getFncOtherUnitNameIsNotNull() {
		return fncOtherUnitNameIsNotNull;
	}
	public void setFncOtherUnitNameIsNotNull(Boolean fncOtherUnitNameIsNotNull) {
		this.fncOtherUnitNameIsNotNull = fncOtherUnitNameIsNotNull;
	}

	public java.util.List getFncOtherUnitNameIn() {
		return fncOtherUnitNameIn;
	}
	public void setFncOtherUnitNameIn(java.util.List fncOtherUnitNameIn) {
		this.fncOtherUnitNameIn = fncOtherUnitNameIn;
	}

	public String getFncOtherUnitNameGreaterThanOrEqualTo() {
		return fncOtherUnitNameGreaterThanOrEqualTo;
	}
	public void setFncOtherUnitNameGreaterThanOrEqualTo(String fncOtherUnitNameGreaterThanOrEqualTo) {
		this.fncOtherUnitNameGreaterThanOrEqualTo = fncOtherUnitNameGreaterThanOrEqualTo;
	}

	public String getFncOtherUnitNameGreaterThan() {
		return fncOtherUnitNameGreaterThan;
	}
	public void setFncOtherUnitNameGreaterThan(String fncOtherUnitNameGreaterThan) {
		this.fncOtherUnitNameGreaterThan = fncOtherUnitNameGreaterThan;
	}

	public String getFncOtherUnitNameEqualTo() {
		return fncOtherUnitNameEqualTo;
	}
	public void setFncOtherUnitNameEqualTo(String fncOtherUnitNameEqualTo) {
		this.fncOtherUnitNameEqualTo = fncOtherUnitNameEqualTo;
	}

	public String getFncOtherAccountNotLike() {
		return fncOtherAccountNotLike;
	}
	public void setFncOtherAccountNotLike(String fncOtherAccountNotLike) {
		this.fncOtherAccountNotLike = fncOtherAccountNotLike;
	}

	public java.util.List getFncOtherAccountNotIn() {
		return fncOtherAccountNotIn;
	}
	public void setFncOtherAccountNotIn(java.util.List fncOtherAccountNotIn) {
		this.fncOtherAccountNotIn = fncOtherAccountNotIn;
	}

	public String getFncOtherAccountNotEqualTo() {
		return fncOtherAccountNotEqualTo;
	}
	public void setFncOtherAccountNotEqualTo(String fncOtherAccountNotEqualTo) {
		this.fncOtherAccountNotEqualTo = fncOtherAccountNotEqualTo;
	}

	public String getFncOtherAccountLike() {
		return fncOtherAccountLike;
	}
	public void setFncOtherAccountLike(String fncOtherAccountLike) {
		this.fncOtherAccountLike = fncOtherAccountLike;
	}

	public String getFncOtherAccountLessThanOrEqualTo() {
		return fncOtherAccountLessThanOrEqualTo;
	}
	public void setFncOtherAccountLessThanOrEqualTo(String fncOtherAccountLessThanOrEqualTo) {
		this.fncOtherAccountLessThanOrEqualTo = fncOtherAccountLessThanOrEqualTo;
	}

	public String getFncOtherAccountLessThan() {
		return fncOtherAccountLessThan;
	}
	public void setFncOtherAccountLessThan(String fncOtherAccountLessThan) {
		this.fncOtherAccountLessThan = fncOtherAccountLessThan;
	}

	public Boolean getFncOtherAccountIsNull() {
		return fncOtherAccountIsNull;
	}
	public void setFncOtherAccountIsNull(Boolean fncOtherAccountIsNull) {
		this.fncOtherAccountIsNull = fncOtherAccountIsNull;
	}

	public Boolean getFncOtherAccountIsNotNull() {
		return fncOtherAccountIsNotNull;
	}
	public void setFncOtherAccountIsNotNull(Boolean fncOtherAccountIsNotNull) {
		this.fncOtherAccountIsNotNull = fncOtherAccountIsNotNull;
	}

	public java.util.List getFncOtherAccountIn() {
		return fncOtherAccountIn;
	}
	public void setFncOtherAccountIn(java.util.List fncOtherAccountIn) {
		this.fncOtherAccountIn = fncOtherAccountIn;
	}

	public String getFncOtherAccountGreaterThanOrEqualTo() {
		return fncOtherAccountGreaterThanOrEqualTo;
	}
	public void setFncOtherAccountGreaterThanOrEqualTo(String fncOtherAccountGreaterThanOrEqualTo) {
		this.fncOtherAccountGreaterThanOrEqualTo = fncOtherAccountGreaterThanOrEqualTo;
	}

	public String getFncOtherAccountGreaterThan() {
		return fncOtherAccountGreaterThan;
	}
	public void setFncOtherAccountGreaterThan(String fncOtherAccountGreaterThan) {
		this.fncOtherAccountGreaterThan = fncOtherAccountGreaterThan;
	}

	public String getFncOtherAccountEqualTo() {
		return fncOtherAccountEqualTo;
	}
	public void setFncOtherAccountEqualTo(String fncOtherAccountEqualTo) {
		this.fncOtherAccountEqualTo = fncOtherAccountEqualTo;
	}

	public String getFncOrderNoNotLike() {
		return fncOrderNoNotLike;
	}
	public void setFncOrderNoNotLike(String fncOrderNoNotLike) {
		this.fncOrderNoNotLike = fncOrderNoNotLike;
	}

	public java.util.List getFncOrderNoNotIn() {
		return fncOrderNoNotIn;
	}
	public void setFncOrderNoNotIn(java.util.List fncOrderNoNotIn) {
		this.fncOrderNoNotIn = fncOrderNoNotIn;
	}

	public String getFncOrderNoNotEqualTo() {
		return fncOrderNoNotEqualTo;
	}
	public void setFncOrderNoNotEqualTo(String fncOrderNoNotEqualTo) {
		this.fncOrderNoNotEqualTo = fncOrderNoNotEqualTo;
	}

	public String getFncOrderNoLike() {
		return fncOrderNoLike;
	}
	public void setFncOrderNoLike(String fncOrderNoLike) {
		this.fncOrderNoLike = fncOrderNoLike;
	}

	public String getFncOrderNoLessThanOrEqualTo() {
		return fncOrderNoLessThanOrEqualTo;
	}
	public void setFncOrderNoLessThanOrEqualTo(String fncOrderNoLessThanOrEqualTo) {
		this.fncOrderNoLessThanOrEqualTo = fncOrderNoLessThanOrEqualTo;
	}

	public String getFncOrderNoLessThan() {
		return fncOrderNoLessThan;
	}
	public void setFncOrderNoLessThan(String fncOrderNoLessThan) {
		this.fncOrderNoLessThan = fncOrderNoLessThan;
	}

	public Boolean getFncOrderNoIsNull() {
		return fncOrderNoIsNull;
	}
	public void setFncOrderNoIsNull(Boolean fncOrderNoIsNull) {
		this.fncOrderNoIsNull = fncOrderNoIsNull;
	}

	public Boolean getFncOrderNoIsNotNull() {
		return fncOrderNoIsNotNull;
	}
	public void setFncOrderNoIsNotNull(Boolean fncOrderNoIsNotNull) {
		this.fncOrderNoIsNotNull = fncOrderNoIsNotNull;
	}

	public java.util.List getFncOrderNoIn() {
		return fncOrderNoIn;
	}
	public void setFncOrderNoIn(java.util.List fncOrderNoIn) {
		this.fncOrderNoIn = fncOrderNoIn;
	}

	public String getFncOrderNoGreaterThanOrEqualTo() {
		return fncOrderNoGreaterThanOrEqualTo;
	}
	public void setFncOrderNoGreaterThanOrEqualTo(String fncOrderNoGreaterThanOrEqualTo) {
		this.fncOrderNoGreaterThanOrEqualTo = fncOrderNoGreaterThanOrEqualTo;
	}

	public String getFncOrderNoGreaterThan() {
		return fncOrderNoGreaterThan;
	}
	public void setFncOrderNoGreaterThan(String fncOrderNoGreaterThan) {
		this.fncOrderNoGreaterThan = fncOrderNoGreaterThan;
	}

	public String getFncOrderNoEqualTo() {
		return fncOrderNoEqualTo;
	}
	public void setFncOrderNoEqualTo(String fncOrderNoEqualTo) {
		this.fncOrderNoEqualTo = fncOrderNoEqualTo;
	}

	public String getFncOperateCodeNotLike() {
		return fncOperateCodeNotLike;
	}
	public void setFncOperateCodeNotLike(String fncOperateCodeNotLike) {
		this.fncOperateCodeNotLike = fncOperateCodeNotLike;
	}

	public java.util.List getFncOperateCodeNotIn() {
		return fncOperateCodeNotIn;
	}
	public void setFncOperateCodeNotIn(java.util.List fncOperateCodeNotIn) {
		this.fncOperateCodeNotIn = fncOperateCodeNotIn;
	}

	public String getFncOperateCodeNotEqualTo() {
		return fncOperateCodeNotEqualTo;
	}
	public void setFncOperateCodeNotEqualTo(String fncOperateCodeNotEqualTo) {
		this.fncOperateCodeNotEqualTo = fncOperateCodeNotEqualTo;
	}

	public String getFncOperateCodeLike() {
		return fncOperateCodeLike;
	}
	public void setFncOperateCodeLike(String fncOperateCodeLike) {
		this.fncOperateCodeLike = fncOperateCodeLike;
	}

	public String getFncOperateCodeLessThanOrEqualTo() {
		return fncOperateCodeLessThanOrEqualTo;
	}
	public void setFncOperateCodeLessThanOrEqualTo(String fncOperateCodeLessThanOrEqualTo) {
		this.fncOperateCodeLessThanOrEqualTo = fncOperateCodeLessThanOrEqualTo;
	}

	public String getFncOperateCodeLessThan() {
		return fncOperateCodeLessThan;
	}
	public void setFncOperateCodeLessThan(String fncOperateCodeLessThan) {
		this.fncOperateCodeLessThan = fncOperateCodeLessThan;
	}

	public Boolean getFncOperateCodeIsNull() {
		return fncOperateCodeIsNull;
	}
	public void setFncOperateCodeIsNull(Boolean fncOperateCodeIsNull) {
		this.fncOperateCodeIsNull = fncOperateCodeIsNull;
	}

	public Boolean getFncOperateCodeIsNotNull() {
		return fncOperateCodeIsNotNull;
	}
	public void setFncOperateCodeIsNotNull(Boolean fncOperateCodeIsNotNull) {
		this.fncOperateCodeIsNotNull = fncOperateCodeIsNotNull;
	}

	public java.util.List getFncOperateCodeIn() {
		return fncOperateCodeIn;
	}
	public void setFncOperateCodeIn(java.util.List fncOperateCodeIn) {
		this.fncOperateCodeIn = fncOperateCodeIn;
	}

	public String getFncOperateCodeGreaterThanOrEqualTo() {
		return fncOperateCodeGreaterThanOrEqualTo;
	}
	public void setFncOperateCodeGreaterThanOrEqualTo(String fncOperateCodeGreaterThanOrEqualTo) {
		this.fncOperateCodeGreaterThanOrEqualTo = fncOperateCodeGreaterThanOrEqualTo;
	}

	public String getFncOperateCodeGreaterThan() {
		return fncOperateCodeGreaterThan;
	}
	public void setFncOperateCodeGreaterThan(String fncOperateCodeGreaterThan) {
		this.fncOperateCodeGreaterThan = fncOperateCodeGreaterThan;
	}

	public String getFncOperateCodeEqualTo() {
		return fncOperateCodeEqualTo;
	}
	public void setFncOperateCodeEqualTo(String fncOperateCodeEqualTo) {
		this.fncOperateCodeEqualTo = fncOperateCodeEqualTo;
	}

	public String getFncNameNotLike() {
		return fncNameNotLike;
	}
	public void setFncNameNotLike(String fncNameNotLike) {
		this.fncNameNotLike = fncNameNotLike;
	}

	public java.util.List getFncNameNotIn() {
		return fncNameNotIn;
	}
	public void setFncNameNotIn(java.util.List fncNameNotIn) {
		this.fncNameNotIn = fncNameNotIn;
	}

	public String getFncNameNotEqualTo() {
		return fncNameNotEqualTo;
	}
	public void setFncNameNotEqualTo(String fncNameNotEqualTo) {
		this.fncNameNotEqualTo = fncNameNotEqualTo;
	}

	public String getFncNameLike() {
		return fncNameLike;
	}
	public void setFncNameLike(String fncNameLike) {
		this.fncNameLike = fncNameLike;
	}

	public String getFncNameLessThanOrEqualTo() {
		return fncNameLessThanOrEqualTo;
	}
	public void setFncNameLessThanOrEqualTo(String fncNameLessThanOrEqualTo) {
		this.fncNameLessThanOrEqualTo = fncNameLessThanOrEqualTo;
	}

	public String getFncNameLessThan() {
		return fncNameLessThan;
	}
	public void setFncNameLessThan(String fncNameLessThan) {
		this.fncNameLessThan = fncNameLessThan;
	}

	public Boolean getFncNameIsNull() {
		return fncNameIsNull;
	}
	public void setFncNameIsNull(Boolean fncNameIsNull) {
		this.fncNameIsNull = fncNameIsNull;
	}

	public Boolean getFncNameIsNotNull() {
		return fncNameIsNotNull;
	}
	public void setFncNameIsNotNull(Boolean fncNameIsNotNull) {
		this.fncNameIsNotNull = fncNameIsNotNull;
	}

	public java.util.List getFncNameIn() {
		return fncNameIn;
	}
	public void setFncNameIn(java.util.List fncNameIn) {
		this.fncNameIn = fncNameIn;
	}

	public String getFncNameGreaterThanOrEqualTo() {
		return fncNameGreaterThanOrEqualTo;
	}
	public void setFncNameGreaterThanOrEqualTo(String fncNameGreaterThanOrEqualTo) {
		this.fncNameGreaterThanOrEqualTo = fncNameGreaterThanOrEqualTo;
	}

	public String getFncNameGreaterThan() {
		return fncNameGreaterThan;
	}
	public void setFncNameGreaterThan(String fncNameGreaterThan) {
		this.fncNameGreaterThan = fncNameGreaterThan;
	}

	public String getFncNameEqualTo() {
		return fncNameEqualTo;
	}
	public void setFncNameEqualTo(String fncNameEqualTo) {
		this.fncNameEqualTo = fncNameEqualTo;
	}

	public java.util.List getFncMonthWithholdNotIn() {
		return fncMonthWithholdNotIn;
	}
	public void setFncMonthWithholdNotIn(java.util.List fncMonthWithholdNotIn) {
		this.fncMonthWithholdNotIn = fncMonthWithholdNotIn;
	}

	public Double getFncMonthWithholdNotEqualTo() {
		return fncMonthWithholdNotEqualTo;
	}
	public void setFncMonthWithholdNotEqualTo(Double fncMonthWithholdNotEqualTo) {
		this.fncMonthWithholdNotEqualTo = fncMonthWithholdNotEqualTo;
	}

	public Double getFncMonthWithholdLessThanOrEqualTo() {
		return fncMonthWithholdLessThanOrEqualTo;
	}
	public void setFncMonthWithholdLessThanOrEqualTo(Double fncMonthWithholdLessThanOrEqualTo) {
		this.fncMonthWithholdLessThanOrEqualTo = fncMonthWithholdLessThanOrEqualTo;
	}

	public Double getFncMonthWithholdLessThan() {
		return fncMonthWithholdLessThan;
	}
	public void setFncMonthWithholdLessThan(Double fncMonthWithholdLessThan) {
		this.fncMonthWithholdLessThan = fncMonthWithholdLessThan;
	}

	public Boolean getFncMonthWithholdIsNull() {
		return fncMonthWithholdIsNull;
	}
	public void setFncMonthWithholdIsNull(Boolean fncMonthWithholdIsNull) {
		this.fncMonthWithholdIsNull = fncMonthWithholdIsNull;
	}

	public Boolean getFncMonthWithholdIsNotNull() {
		return fncMonthWithholdIsNotNull;
	}
	public void setFncMonthWithholdIsNotNull(Boolean fncMonthWithholdIsNotNull) {
		this.fncMonthWithholdIsNotNull = fncMonthWithholdIsNotNull;
	}

	public java.util.List getFncMonthWithholdIn() {
		return fncMonthWithholdIn;
	}
	public void setFncMonthWithholdIn(java.util.List fncMonthWithholdIn) {
		this.fncMonthWithholdIn = fncMonthWithholdIn;
	}

	public Double getFncMonthWithholdGreaterThanOrEqualTo() {
		return fncMonthWithholdGreaterThanOrEqualTo;
	}
	public void setFncMonthWithholdGreaterThanOrEqualTo(Double fncMonthWithholdGreaterThanOrEqualTo) {
		this.fncMonthWithholdGreaterThanOrEqualTo = fncMonthWithholdGreaterThanOrEqualTo;
	}

	public Double getFncMonthWithholdGreaterThan() {
		return fncMonthWithholdGreaterThan;
	}
	public void setFncMonthWithholdGreaterThan(Double fncMonthWithholdGreaterThan) {
		this.fncMonthWithholdGreaterThan = fncMonthWithholdGreaterThan;
	}

	public Double getFncMonthWithholdEqualTo() {
		return fncMonthWithholdEqualTo;
	}
	public void setFncMonthWithholdEqualTo(Double fncMonthWithholdEqualTo) {
		this.fncMonthWithholdEqualTo = fncMonthWithholdEqualTo;
	}

	public java.util.List getFncMonthRentNotIn() {
		return fncMonthRentNotIn;
	}
	public void setFncMonthRentNotIn(java.util.List fncMonthRentNotIn) {
		this.fncMonthRentNotIn = fncMonthRentNotIn;
	}

	public Double getFncMonthRentNotEqualTo() {
		return fncMonthRentNotEqualTo;
	}
	public void setFncMonthRentNotEqualTo(Double fncMonthRentNotEqualTo) {
		this.fncMonthRentNotEqualTo = fncMonthRentNotEqualTo;
	}

	public Double getFncMonthRentLessThanOrEqualTo() {
		return fncMonthRentLessThanOrEqualTo;
	}
	public void setFncMonthRentLessThanOrEqualTo(Double fncMonthRentLessThanOrEqualTo) {
		this.fncMonthRentLessThanOrEqualTo = fncMonthRentLessThanOrEqualTo;
	}

	public Double getFncMonthRentLessThan() {
		return fncMonthRentLessThan;
	}
	public void setFncMonthRentLessThan(Double fncMonthRentLessThan) {
		this.fncMonthRentLessThan = fncMonthRentLessThan;
	}

	public Boolean getFncMonthRentIsNull() {
		return fncMonthRentIsNull;
	}
	public void setFncMonthRentIsNull(Boolean fncMonthRentIsNull) {
		this.fncMonthRentIsNull = fncMonthRentIsNull;
	}

	public Boolean getFncMonthRentIsNotNull() {
		return fncMonthRentIsNotNull;
	}
	public void setFncMonthRentIsNotNull(Boolean fncMonthRentIsNotNull) {
		this.fncMonthRentIsNotNull = fncMonthRentIsNotNull;
	}

	public java.util.List getFncMonthRentIn() {
		return fncMonthRentIn;
	}
	public void setFncMonthRentIn(java.util.List fncMonthRentIn) {
		this.fncMonthRentIn = fncMonthRentIn;
	}

	public Double getFncMonthRentGreaterThanOrEqualTo() {
		return fncMonthRentGreaterThanOrEqualTo;
	}
	public void setFncMonthRentGreaterThanOrEqualTo(Double fncMonthRentGreaterThanOrEqualTo) {
		this.fncMonthRentGreaterThanOrEqualTo = fncMonthRentGreaterThanOrEqualTo;
	}

	public Double getFncMonthRentGreaterThan() {
		return fncMonthRentGreaterThan;
	}
	public void setFncMonthRentGreaterThan(Double fncMonthRentGreaterThan) {
		this.fncMonthRentGreaterThan = fncMonthRentGreaterThan;
	}

	public Double getFncMonthRentEqualTo() {
		return fncMonthRentEqualTo;
	}
	public void setFncMonthRentEqualTo(Double fncMonthRentEqualTo) {
		this.fncMonthRentEqualTo = fncMonthRentEqualTo;
	}

	public java.util.List getFncMonthRentBalanceNotIn() {
		return fncMonthRentBalanceNotIn;
	}
	public void setFncMonthRentBalanceNotIn(java.util.List fncMonthRentBalanceNotIn) {
		this.fncMonthRentBalanceNotIn = fncMonthRentBalanceNotIn;
	}

	public Double getFncMonthRentBalanceNotEqualTo() {
		return fncMonthRentBalanceNotEqualTo;
	}
	public void setFncMonthRentBalanceNotEqualTo(Double fncMonthRentBalanceNotEqualTo) {
		this.fncMonthRentBalanceNotEqualTo = fncMonthRentBalanceNotEqualTo;
	}

	public Double getFncMonthRentBalanceLessThanOrEqualTo() {
		return fncMonthRentBalanceLessThanOrEqualTo;
	}
	public void setFncMonthRentBalanceLessThanOrEqualTo(Double fncMonthRentBalanceLessThanOrEqualTo) {
		this.fncMonthRentBalanceLessThanOrEqualTo = fncMonthRentBalanceLessThanOrEqualTo;
	}

	public Double getFncMonthRentBalanceLessThan() {
		return fncMonthRentBalanceLessThan;
	}
	public void setFncMonthRentBalanceLessThan(Double fncMonthRentBalanceLessThan) {
		this.fncMonthRentBalanceLessThan = fncMonthRentBalanceLessThan;
	}

	public Boolean getFncMonthRentBalanceIsNull() {
		return fncMonthRentBalanceIsNull;
	}
	public void setFncMonthRentBalanceIsNull(Boolean fncMonthRentBalanceIsNull) {
		this.fncMonthRentBalanceIsNull = fncMonthRentBalanceIsNull;
	}

	public Boolean getFncMonthRentBalanceIsNotNull() {
		return fncMonthRentBalanceIsNotNull;
	}
	public void setFncMonthRentBalanceIsNotNull(Boolean fncMonthRentBalanceIsNotNull) {
		this.fncMonthRentBalanceIsNotNull = fncMonthRentBalanceIsNotNull;
	}

	public java.util.List getFncMonthRentBalanceIn() {
		return fncMonthRentBalanceIn;
	}
	public void setFncMonthRentBalanceIn(java.util.List fncMonthRentBalanceIn) {
		this.fncMonthRentBalanceIn = fncMonthRentBalanceIn;
	}

	public Double getFncMonthRentBalanceGreaterThanOrEqualTo() {
		return fncMonthRentBalanceGreaterThanOrEqualTo;
	}
	public void setFncMonthRentBalanceGreaterThanOrEqualTo(Double fncMonthRentBalanceGreaterThanOrEqualTo) {
		this.fncMonthRentBalanceGreaterThanOrEqualTo = fncMonthRentBalanceGreaterThanOrEqualTo;
	}

	public Double getFncMonthRentBalanceGreaterThan() {
		return fncMonthRentBalanceGreaterThan;
	}
	public void setFncMonthRentBalanceGreaterThan(Double fncMonthRentBalanceGreaterThan) {
		this.fncMonthRentBalanceGreaterThan = fncMonthRentBalanceGreaterThan;
	}

	public Double getFncMonthRentBalanceEqualTo() {
		return fncMonthRentBalanceEqualTo;
	}
	public void setFncMonthRentBalanceEqualTo(Double fncMonthRentBalanceEqualTo) {
		this.fncMonthRentBalanceEqualTo = fncMonthRentBalanceEqualTo;
	}

	public java.util.List getFncMonthNotIn() {
		return fncMonthNotIn;
	}
	public void setFncMonthNotIn(java.util.List fncMonthNotIn) {
		this.fncMonthNotIn = fncMonthNotIn;
	}

	public java.util.Date getFncMonthNotEqualTo() {
		return fncMonthNotEqualTo;
	}
	public void setFncMonthNotEqualTo(java.util.Date fncMonthNotEqualTo) {
		this.fncMonthNotEqualTo = fncMonthNotEqualTo;
	}

	public java.util.Date getFncMonthLessThanOrEqualTo() {
		return fncMonthLessThanOrEqualTo;
	}
	public void setFncMonthLessThanOrEqualTo(java.util.Date fncMonthLessThanOrEqualTo) {
		this.fncMonthLessThanOrEqualTo = fncMonthLessThanOrEqualTo;
	}

	public java.util.Date getFncMonthLessThan() {
		return fncMonthLessThan;
	}
	public void setFncMonthLessThan(java.util.Date fncMonthLessThan) {
		this.fncMonthLessThan = fncMonthLessThan;
	}

	public Boolean getFncMonthIsNull() {
		return fncMonthIsNull;
	}
	public void setFncMonthIsNull(Boolean fncMonthIsNull) {
		this.fncMonthIsNull = fncMonthIsNull;
	}

	public Boolean getFncMonthIsNotNull() {
		return fncMonthIsNotNull;
	}
	public void setFncMonthIsNotNull(Boolean fncMonthIsNotNull) {
		this.fncMonthIsNotNull = fncMonthIsNotNull;
	}

	public java.util.List getFncMonthIn() {
		return fncMonthIn;
	}
	public void setFncMonthIn(java.util.List fncMonthIn) {
		this.fncMonthIn = fncMonthIn;
	}

	public java.util.Date getFncMonthGreaterThanOrEqualTo() {
		return fncMonthGreaterThanOrEqualTo;
	}
	public void setFncMonthGreaterThanOrEqualTo(java.util.Date fncMonthGreaterThanOrEqualTo) {
		this.fncMonthGreaterThanOrEqualTo = fncMonthGreaterThanOrEqualTo;
	}

	public java.util.Date getFncMonthGreaterThan() {
		return fncMonthGreaterThan;
	}
	public void setFncMonthGreaterThan(java.util.Date fncMonthGreaterThan) {
		this.fncMonthGreaterThan = fncMonthGreaterThan;
	}

	public java.util.Date getFncMonthEqualTo() {
		return fncMonthEqualTo;
	}
	public void setFncMonthEqualTo(java.util.Date fncMonthEqualTo) {
		this.fncMonthEqualTo = fncMonthEqualTo;
	}

	public java.util.List getFncMemberIdNotIn() {
		return fncMemberIdNotIn;
	}
	public void setFncMemberIdNotIn(java.util.List fncMemberIdNotIn) {
		this.fncMemberIdNotIn = fncMemberIdNotIn;
	}

	public Long getFncMemberIdNotEqualTo() {
		return fncMemberIdNotEqualTo;
	}
	public void setFncMemberIdNotEqualTo(Long fncMemberIdNotEqualTo) {
		this.fncMemberIdNotEqualTo = fncMemberIdNotEqualTo;
	}

	public Long getFncMemberIdLessThanOrEqualTo() {
		return fncMemberIdLessThanOrEqualTo;
	}
	public void setFncMemberIdLessThanOrEqualTo(Long fncMemberIdLessThanOrEqualTo) {
		this.fncMemberIdLessThanOrEqualTo = fncMemberIdLessThanOrEqualTo;
	}

	public Long getFncMemberIdLessThan() {
		return fncMemberIdLessThan;
	}
	public void setFncMemberIdLessThan(Long fncMemberIdLessThan) {
		this.fncMemberIdLessThan = fncMemberIdLessThan;
	}

	public Boolean getFncMemberIdIsNull() {
		return fncMemberIdIsNull;
	}
	public void setFncMemberIdIsNull(Boolean fncMemberIdIsNull) {
		this.fncMemberIdIsNull = fncMemberIdIsNull;
	}

	public Boolean getFncMemberIdIsNotNull() {
		return fncMemberIdIsNotNull;
	}
	public void setFncMemberIdIsNotNull(Boolean fncMemberIdIsNotNull) {
		this.fncMemberIdIsNotNull = fncMemberIdIsNotNull;
	}

	public java.util.List getFncMemberIdIn() {
		return fncMemberIdIn;
	}
	public void setFncMemberIdIn(java.util.List fncMemberIdIn) {
		this.fncMemberIdIn = fncMemberIdIn;
	}

	public Long getFncMemberIdGreaterThanOrEqualTo() {
		return fncMemberIdGreaterThanOrEqualTo;
	}
	public void setFncMemberIdGreaterThanOrEqualTo(Long fncMemberIdGreaterThanOrEqualTo) {
		this.fncMemberIdGreaterThanOrEqualTo = fncMemberIdGreaterThanOrEqualTo;
	}

	public Long getFncMemberIdGreaterThan() {
		return fncMemberIdGreaterThan;
	}
	public void setFncMemberIdGreaterThan(Long fncMemberIdGreaterThan) {
		this.fncMemberIdGreaterThan = fncMemberIdGreaterThan;
	}

	public Long getFncMemberIdEqualTo() {
		return fncMemberIdEqualTo;
	}
	public void setFncMemberIdEqualTo(Long fncMemberIdEqualTo) {
		this.fncMemberIdEqualTo = fncMemberIdEqualTo;
	}

	public String getFncLoanTypeNotLike() {
		return fncLoanTypeNotLike;
	}
	public void setFncLoanTypeNotLike(String fncLoanTypeNotLike) {
		this.fncLoanTypeNotLike = fncLoanTypeNotLike;
	}

	public java.util.List getFncLoanTypeNotIn() {
		return fncLoanTypeNotIn;
	}
	public void setFncLoanTypeNotIn(java.util.List fncLoanTypeNotIn) {
		this.fncLoanTypeNotIn = fncLoanTypeNotIn;
	}

	public String getFncLoanTypeNotEqualTo() {
		return fncLoanTypeNotEqualTo;
	}
	public void setFncLoanTypeNotEqualTo(String fncLoanTypeNotEqualTo) {
		this.fncLoanTypeNotEqualTo = fncLoanTypeNotEqualTo;
	}

	public String getFncLoanTypeLike() {
		return fncLoanTypeLike;
	}
	public void setFncLoanTypeLike(String fncLoanTypeLike) {
		this.fncLoanTypeLike = fncLoanTypeLike;
	}

	public String getFncLoanTypeLessThanOrEqualTo() {
		return fncLoanTypeLessThanOrEqualTo;
	}
	public void setFncLoanTypeLessThanOrEqualTo(String fncLoanTypeLessThanOrEqualTo) {
		this.fncLoanTypeLessThanOrEqualTo = fncLoanTypeLessThanOrEqualTo;
	}

	public String getFncLoanTypeLessThan() {
		return fncLoanTypeLessThan;
	}
	public void setFncLoanTypeLessThan(String fncLoanTypeLessThan) {
		this.fncLoanTypeLessThan = fncLoanTypeLessThan;
	}

	public Boolean getFncLoanTypeIsNull() {
		return fncLoanTypeIsNull;
	}
	public void setFncLoanTypeIsNull(Boolean fncLoanTypeIsNull) {
		this.fncLoanTypeIsNull = fncLoanTypeIsNull;
	}

	public Boolean getFncLoanTypeIsNotNull() {
		return fncLoanTypeIsNotNull;
	}
	public void setFncLoanTypeIsNotNull(Boolean fncLoanTypeIsNotNull) {
		this.fncLoanTypeIsNotNull = fncLoanTypeIsNotNull;
	}

	public java.util.List getFncLoanTypeIn() {
		return fncLoanTypeIn;
	}
	public void setFncLoanTypeIn(java.util.List fncLoanTypeIn) {
		this.fncLoanTypeIn = fncLoanTypeIn;
	}

	public String getFncLoanTypeGreaterThanOrEqualTo() {
		return fncLoanTypeGreaterThanOrEqualTo;
	}
	public void setFncLoanTypeGreaterThanOrEqualTo(String fncLoanTypeGreaterThanOrEqualTo) {
		this.fncLoanTypeGreaterThanOrEqualTo = fncLoanTypeGreaterThanOrEqualTo;
	}

	public String getFncLoanTypeGreaterThan() {
		return fncLoanTypeGreaterThan;
	}
	public void setFncLoanTypeGreaterThan(String fncLoanTypeGreaterThan) {
		this.fncLoanTypeGreaterThan = fncLoanTypeGreaterThan;
	}

	public String getFncLoanTypeEqualTo() {
		return fncLoanTypeEqualTo;
	}
	public void setFncLoanTypeEqualTo(String fncLoanTypeEqualTo) {
		this.fncLoanTypeEqualTo = fncLoanTypeEqualTo;
	}

	public java.util.List getFncLeaseCountNotIn() {
		return fncLeaseCountNotIn;
	}
	public void setFncLeaseCountNotIn(java.util.List fncLeaseCountNotIn) {
		this.fncLeaseCountNotIn = fncLeaseCountNotIn;
	}

	public Integer getFncLeaseCountNotEqualTo() {
		return fncLeaseCountNotEqualTo;
	}
	public void setFncLeaseCountNotEqualTo(Integer fncLeaseCountNotEqualTo) {
		this.fncLeaseCountNotEqualTo = fncLeaseCountNotEqualTo;
	}

	public Integer getFncLeaseCountLessThanOrEqualTo() {
		return fncLeaseCountLessThanOrEqualTo;
	}
	public void setFncLeaseCountLessThanOrEqualTo(Integer fncLeaseCountLessThanOrEqualTo) {
		this.fncLeaseCountLessThanOrEqualTo = fncLeaseCountLessThanOrEqualTo;
	}

	public Integer getFncLeaseCountLessThan() {
		return fncLeaseCountLessThan;
	}
	public void setFncLeaseCountLessThan(Integer fncLeaseCountLessThan) {
		this.fncLeaseCountLessThan = fncLeaseCountLessThan;
	}

	public Boolean getFncLeaseCountIsNull() {
		return fncLeaseCountIsNull;
	}
	public void setFncLeaseCountIsNull(Boolean fncLeaseCountIsNull) {
		this.fncLeaseCountIsNull = fncLeaseCountIsNull;
	}

	public Boolean getFncLeaseCountIsNotNull() {
		return fncLeaseCountIsNotNull;
	}
	public void setFncLeaseCountIsNotNull(Boolean fncLeaseCountIsNotNull) {
		this.fncLeaseCountIsNotNull = fncLeaseCountIsNotNull;
	}

	public java.util.List getFncLeaseCountIn() {
		return fncLeaseCountIn;
	}
	public void setFncLeaseCountIn(java.util.List fncLeaseCountIn) {
		this.fncLeaseCountIn = fncLeaseCountIn;
	}

	public Integer getFncLeaseCountGreaterThanOrEqualTo() {
		return fncLeaseCountGreaterThanOrEqualTo;
	}
	public void setFncLeaseCountGreaterThanOrEqualTo(Integer fncLeaseCountGreaterThanOrEqualTo) {
		this.fncLeaseCountGreaterThanOrEqualTo = fncLeaseCountGreaterThanOrEqualTo;
	}

	public Integer getFncLeaseCountGreaterThan() {
		return fncLeaseCountGreaterThan;
	}
	public void setFncLeaseCountGreaterThan(Integer fncLeaseCountGreaterThan) {
		this.fncLeaseCountGreaterThan = fncLeaseCountGreaterThan;
	}

	public Integer getFncLeaseCountEqualTo() {
		return fncLeaseCountEqualTo;
	}
	public void setFncLeaseCountEqualTo(Integer fncLeaseCountEqualTo) {
		this.fncLeaseCountEqualTo = fncLeaseCountEqualTo;
	}

	public String getFncIdnumberNotLike() {
		return fncIdnumberNotLike;
	}
	public void setFncIdnumberNotLike(String fncIdnumberNotLike) {
		this.fncIdnumberNotLike = fncIdnumberNotLike;
	}

	public java.util.List getFncIdnumberNotIn() {
		return fncIdnumberNotIn;
	}
	public void setFncIdnumberNotIn(java.util.List fncIdnumberNotIn) {
		this.fncIdnumberNotIn = fncIdnumberNotIn;
	}

	public String getFncIdnumberNotEqualTo() {
		return fncIdnumberNotEqualTo;
	}
	public void setFncIdnumberNotEqualTo(String fncIdnumberNotEqualTo) {
		this.fncIdnumberNotEqualTo = fncIdnumberNotEqualTo;
	}

	public String getFncIdnumberLike() {
		return fncIdnumberLike;
	}
	public void setFncIdnumberLike(String fncIdnumberLike) {
		this.fncIdnumberLike = fncIdnumberLike;
	}

	public String getFncIdnumberLessThanOrEqualTo() {
		return fncIdnumberLessThanOrEqualTo;
	}
	public void setFncIdnumberLessThanOrEqualTo(String fncIdnumberLessThanOrEqualTo) {
		this.fncIdnumberLessThanOrEqualTo = fncIdnumberLessThanOrEqualTo;
	}

	public String getFncIdnumberLessThan() {
		return fncIdnumberLessThan;
	}
	public void setFncIdnumberLessThan(String fncIdnumberLessThan) {
		this.fncIdnumberLessThan = fncIdnumberLessThan;
	}

	public Boolean getFncIdnumberIsNull() {
		return fncIdnumberIsNull;
	}
	public void setFncIdnumberIsNull(Boolean fncIdnumberIsNull) {
		this.fncIdnumberIsNull = fncIdnumberIsNull;
	}

	public Boolean getFncIdnumberIsNotNull() {
		return fncIdnumberIsNotNull;
	}
	public void setFncIdnumberIsNotNull(Boolean fncIdnumberIsNotNull) {
		this.fncIdnumberIsNotNull = fncIdnumberIsNotNull;
	}

	public java.util.List getFncIdnumberIn() {
		return fncIdnumberIn;
	}
	public void setFncIdnumberIn(java.util.List fncIdnumberIn) {
		this.fncIdnumberIn = fncIdnumberIn;
	}

	public String getFncIdnumberGreaterThanOrEqualTo() {
		return fncIdnumberGreaterThanOrEqualTo;
	}
	public void setFncIdnumberGreaterThanOrEqualTo(String fncIdnumberGreaterThanOrEqualTo) {
		this.fncIdnumberGreaterThanOrEqualTo = fncIdnumberGreaterThanOrEqualTo;
	}

	public String getFncIdnumberGreaterThan() {
		return fncIdnumberGreaterThan;
	}
	public void setFncIdnumberGreaterThan(String fncIdnumberGreaterThan) {
		this.fncIdnumberGreaterThan = fncIdnumberGreaterThan;
	}

	public String getFncIdnumberEqualTo() {
		return fncIdnumberEqualTo;
	}
	public void setFncIdnumberEqualTo(String fncIdnumberEqualTo) {
		this.fncIdnumberEqualTo = fncIdnumberEqualTo;
	}

	public java.util.List getFncIdNotIn() {
		return fncIdNotIn;
	}
	public void setFncIdNotIn(java.util.List fncIdNotIn) {
		this.fncIdNotIn = fncIdNotIn;
	}

	public Long getFncIdNotEqualTo() {
		return fncIdNotEqualTo;
	}
	public void setFncIdNotEqualTo(Long fncIdNotEqualTo) {
		this.fncIdNotEqualTo = fncIdNotEqualTo;
	}

	public Long getFncIdLessThanOrEqualTo() {
		return fncIdLessThanOrEqualTo;
	}
	public void setFncIdLessThanOrEqualTo(Long fncIdLessThanOrEqualTo) {
		this.fncIdLessThanOrEqualTo = fncIdLessThanOrEqualTo;
	}

	public Long getFncIdLessThan() {
		return fncIdLessThan;
	}
	public void setFncIdLessThan(Long fncIdLessThan) {
		this.fncIdLessThan = fncIdLessThan;
	}

	public Boolean getFncIdIsNull() {
		return fncIdIsNull;
	}
	public void setFncIdIsNull(Boolean fncIdIsNull) {
		this.fncIdIsNull = fncIdIsNull;
	}

	public Boolean getFncIdIsNotNull() {
		return fncIdIsNotNull;
	}
	public void setFncIdIsNotNull(Boolean fncIdIsNotNull) {
		this.fncIdIsNotNull = fncIdIsNotNull;
	}

	public java.util.List getFncIdIn() {
		return fncIdIn;
	}
	public void setFncIdIn(java.util.List fncIdIn) {
		this.fncIdIn = fncIdIn;
	}

	public Long getFncIdGreaterThanOrEqualTo() {
		return fncIdGreaterThanOrEqualTo;
	}
	public void setFncIdGreaterThanOrEqualTo(Long fncIdGreaterThanOrEqualTo) {
		this.fncIdGreaterThanOrEqualTo = fncIdGreaterThanOrEqualTo;
	}

	public Long getFncIdGreaterThan() {
		return fncIdGreaterThan;
	}
	public void setFncIdGreaterThan(Long fncIdGreaterThan) {
		this.fncIdGreaterThan = fncIdGreaterThan;
	}

	public Long getFncIdEqualTo() {
		return fncIdEqualTo;
	}
	public void setFncIdEqualTo(Long fncIdEqualTo) {
		this.fncIdEqualTo = fncIdEqualTo;
	}

	public java.util.List getFncErrorNotIn() {
		return fncErrorNotIn;
	}
	public void setFncErrorNotIn(java.util.List fncErrorNotIn) {
		this.fncErrorNotIn = fncErrorNotIn;
	}

	public Integer getFncErrorNotEqualTo() {
		return fncErrorNotEqualTo;
	}
	public void setFncErrorNotEqualTo(Integer fncErrorNotEqualTo) {
		this.fncErrorNotEqualTo = fncErrorNotEqualTo;
	}

	public String getFncErrorMsgNotLike() {
		return fncErrorMsgNotLike;
	}
	public void setFncErrorMsgNotLike(String fncErrorMsgNotLike) {
		this.fncErrorMsgNotLike = fncErrorMsgNotLike;
	}

	public java.util.List getFncErrorMsgNotIn() {
		return fncErrorMsgNotIn;
	}
	public void setFncErrorMsgNotIn(java.util.List fncErrorMsgNotIn) {
		this.fncErrorMsgNotIn = fncErrorMsgNotIn;
	}

	public String getFncErrorMsgNotEqualTo() {
		return fncErrorMsgNotEqualTo;
	}
	public void setFncErrorMsgNotEqualTo(String fncErrorMsgNotEqualTo) {
		this.fncErrorMsgNotEqualTo = fncErrorMsgNotEqualTo;
	}

	public String getFncErrorMsgLike() {
		return fncErrorMsgLike;
	}
	public void setFncErrorMsgLike(String fncErrorMsgLike) {
		this.fncErrorMsgLike = fncErrorMsgLike;
	}

	public String getFncErrorMsgLessThanOrEqualTo() {
		return fncErrorMsgLessThanOrEqualTo;
	}
	public void setFncErrorMsgLessThanOrEqualTo(String fncErrorMsgLessThanOrEqualTo) {
		this.fncErrorMsgLessThanOrEqualTo = fncErrorMsgLessThanOrEqualTo;
	}

	public String getFncErrorMsgLessThan() {
		return fncErrorMsgLessThan;
	}
	public void setFncErrorMsgLessThan(String fncErrorMsgLessThan) {
		this.fncErrorMsgLessThan = fncErrorMsgLessThan;
	}

	public Boolean getFncErrorMsgIsNull() {
		return fncErrorMsgIsNull;
	}
	public void setFncErrorMsgIsNull(Boolean fncErrorMsgIsNull) {
		this.fncErrorMsgIsNull = fncErrorMsgIsNull;
	}

	public Boolean getFncErrorMsgIsNotNull() {
		return fncErrorMsgIsNotNull;
	}
	public void setFncErrorMsgIsNotNull(Boolean fncErrorMsgIsNotNull) {
		this.fncErrorMsgIsNotNull = fncErrorMsgIsNotNull;
	}

	public java.util.List getFncErrorMsgIn() {
		return fncErrorMsgIn;
	}
	public void setFncErrorMsgIn(java.util.List fncErrorMsgIn) {
		this.fncErrorMsgIn = fncErrorMsgIn;
	}

	public String getFncErrorMsgGreaterThanOrEqualTo() {
		return fncErrorMsgGreaterThanOrEqualTo;
	}
	public void setFncErrorMsgGreaterThanOrEqualTo(String fncErrorMsgGreaterThanOrEqualTo) {
		this.fncErrorMsgGreaterThanOrEqualTo = fncErrorMsgGreaterThanOrEqualTo;
	}

	public String getFncErrorMsgGreaterThan() {
		return fncErrorMsgGreaterThan;
	}
	public void setFncErrorMsgGreaterThan(String fncErrorMsgGreaterThan) {
		this.fncErrorMsgGreaterThan = fncErrorMsgGreaterThan;
	}

	public String getFncErrorMsgEqualTo() {
		return fncErrorMsgEqualTo;
	}
	public void setFncErrorMsgEqualTo(String fncErrorMsgEqualTo) {
		this.fncErrorMsgEqualTo = fncErrorMsgEqualTo;
	}

	public Integer getFncErrorLessThanOrEqualTo() {
		return fncErrorLessThanOrEqualTo;
	}
	public void setFncErrorLessThanOrEqualTo(Integer fncErrorLessThanOrEqualTo) {
		this.fncErrorLessThanOrEqualTo = fncErrorLessThanOrEqualTo;
	}

	public Integer getFncErrorLessThan() {
		return fncErrorLessThan;
	}
	public void setFncErrorLessThan(Integer fncErrorLessThan) {
		this.fncErrorLessThan = fncErrorLessThan;
	}

	public Boolean getFncErrorIsNull() {
		return fncErrorIsNull;
	}
	public void setFncErrorIsNull(Boolean fncErrorIsNull) {
		this.fncErrorIsNull = fncErrorIsNull;
	}

	public Boolean getFncErrorIsNotNull() {
		return fncErrorIsNotNull;
	}
	public void setFncErrorIsNotNull(Boolean fncErrorIsNotNull) {
		this.fncErrorIsNotNull = fncErrorIsNotNull;
	}

	public java.util.List getFncErrorIn() {
		return fncErrorIn;
	}
	public void setFncErrorIn(java.util.List fncErrorIn) {
		this.fncErrorIn = fncErrorIn;
	}

	public Integer getFncErrorGreaterThanOrEqualTo() {
		return fncErrorGreaterThanOrEqualTo;
	}
	public void setFncErrorGreaterThanOrEqualTo(Integer fncErrorGreaterThanOrEqualTo) {
		this.fncErrorGreaterThanOrEqualTo = fncErrorGreaterThanOrEqualTo;
	}

	public Integer getFncErrorGreaterThan() {
		return fncErrorGreaterThan;
	}
	public void setFncErrorGreaterThan(Integer fncErrorGreaterThan) {
		this.fncErrorGreaterThan = fncErrorGreaterThan;
	}

	public Integer getFncErrorEqualTo() {
		return fncErrorEqualTo;
	}
	public void setFncErrorEqualTo(Integer fncErrorEqualTo) {
		this.fncErrorEqualTo = fncErrorEqualTo;
	}

	public String getFncDigestNotLike() {
		return fncDigestNotLike;
	}
	public void setFncDigestNotLike(String fncDigestNotLike) {
		this.fncDigestNotLike = fncDigestNotLike;
	}

	public java.util.List getFncDigestNotIn() {
		return fncDigestNotIn;
	}
	public void setFncDigestNotIn(java.util.List fncDigestNotIn) {
		this.fncDigestNotIn = fncDigestNotIn;
	}

	public String getFncDigestNotEqualTo() {
		return fncDigestNotEqualTo;
	}
	public void setFncDigestNotEqualTo(String fncDigestNotEqualTo) {
		this.fncDigestNotEqualTo = fncDigestNotEqualTo;
	}

	public String getFncDigestLike() {
		return fncDigestLike;
	}
	public void setFncDigestLike(String fncDigestLike) {
		this.fncDigestLike = fncDigestLike;
	}

	public String getFncDigestLessThanOrEqualTo() {
		return fncDigestLessThanOrEqualTo;
	}
	public void setFncDigestLessThanOrEqualTo(String fncDigestLessThanOrEqualTo) {
		this.fncDigestLessThanOrEqualTo = fncDigestLessThanOrEqualTo;
	}

	public String getFncDigestLessThan() {
		return fncDigestLessThan;
	}
	public void setFncDigestLessThan(String fncDigestLessThan) {
		this.fncDigestLessThan = fncDigestLessThan;
	}

	public Boolean getFncDigestIsNull() {
		return fncDigestIsNull;
	}
	public void setFncDigestIsNull(Boolean fncDigestIsNull) {
		this.fncDigestIsNull = fncDigestIsNull;
	}

	public Boolean getFncDigestIsNotNull() {
		return fncDigestIsNotNull;
	}
	public void setFncDigestIsNotNull(Boolean fncDigestIsNotNull) {
		this.fncDigestIsNotNull = fncDigestIsNotNull;
	}

	public java.util.List getFncDigestIn() {
		return fncDigestIn;
	}
	public void setFncDigestIn(java.util.List fncDigestIn) {
		this.fncDigestIn = fncDigestIn;
	}

	public String getFncDigestGreaterThanOrEqualTo() {
		return fncDigestGreaterThanOrEqualTo;
	}
	public void setFncDigestGreaterThanOrEqualTo(String fncDigestGreaterThanOrEqualTo) {
		this.fncDigestGreaterThanOrEqualTo = fncDigestGreaterThanOrEqualTo;
	}

	public String getFncDigestGreaterThan() {
		return fncDigestGreaterThan;
	}
	public void setFncDigestGreaterThan(String fncDigestGreaterThan) {
		this.fncDigestGreaterThan = fncDigestGreaterThan;
	}

	public String getFncDigestEqualTo() {
		return fncDigestEqualTo;
	}
	public void setFncDigestEqualTo(String fncDigestEqualTo) {
		this.fncDigestEqualTo = fncDigestEqualTo;
	}

	public java.util.List getFncDealTimeNotIn() {
		return fncDealTimeNotIn;
	}
	public void setFncDealTimeNotIn(java.util.List fncDealTimeNotIn) {
		this.fncDealTimeNotIn = fncDealTimeNotIn;
	}

	public java.util.Date getFncDealTimeNotEqualTo() {
		return fncDealTimeNotEqualTo;
	}
	public void setFncDealTimeNotEqualTo(java.util.Date fncDealTimeNotEqualTo) {
		this.fncDealTimeNotEqualTo = fncDealTimeNotEqualTo;
	}

	public java.util.Date getFncDealTimeLessThanOrEqualTo() {
		return fncDealTimeLessThanOrEqualTo;
	}
	public void setFncDealTimeLessThanOrEqualTo(java.util.Date fncDealTimeLessThanOrEqualTo) {
		this.fncDealTimeLessThanOrEqualTo = fncDealTimeLessThanOrEqualTo;
	}

	public java.util.Date getFncDealTimeLessThan() {
		return fncDealTimeLessThan;
	}
	public void setFncDealTimeLessThan(java.util.Date fncDealTimeLessThan) {
		this.fncDealTimeLessThan = fncDealTimeLessThan;
	}

	public Boolean getFncDealTimeIsNull() {
		return fncDealTimeIsNull;
	}
	public void setFncDealTimeIsNull(Boolean fncDealTimeIsNull) {
		this.fncDealTimeIsNull = fncDealTimeIsNull;
	}

	public Boolean getFncDealTimeIsNotNull() {
		return fncDealTimeIsNotNull;
	}
	public void setFncDealTimeIsNotNull(Boolean fncDealTimeIsNotNull) {
		this.fncDealTimeIsNotNull = fncDealTimeIsNotNull;
	}

	public java.util.List getFncDealTimeIn() {
		return fncDealTimeIn;
	}
	public void setFncDealTimeIn(java.util.List fncDealTimeIn) {
		this.fncDealTimeIn = fncDealTimeIn;
	}

	public java.util.Date getFncDealTimeGreaterThanOrEqualTo() {
		return fncDealTimeGreaterThanOrEqualTo;
	}
	public void setFncDealTimeGreaterThanOrEqualTo(java.util.Date fncDealTimeGreaterThanOrEqualTo) {
		this.fncDealTimeGreaterThanOrEqualTo = fncDealTimeGreaterThanOrEqualTo;
	}

	public java.util.Date getFncDealTimeGreaterThan() {
		return fncDealTimeGreaterThan;
	}
	public void setFncDealTimeGreaterThan(java.util.Date fncDealTimeGreaterThan) {
		this.fncDealTimeGreaterThan = fncDealTimeGreaterThan;
	}

	public java.util.Date getFncDealTimeEqualTo() {
		return fncDealTimeEqualTo;
	}
	public void setFncDealTimeEqualTo(java.util.Date fncDealTimeEqualTo) {
		this.fncDealTimeEqualTo = fncDealTimeEqualTo;
	}

	public java.util.List getFncCreditAmountNotIn() {
		return fncCreditAmountNotIn;
	}
	public void setFncCreditAmountNotIn(java.util.List fncCreditAmountNotIn) {
		this.fncCreditAmountNotIn = fncCreditAmountNotIn;
	}

	public Double getFncCreditAmountNotEqualTo() {
		return fncCreditAmountNotEqualTo;
	}
	public void setFncCreditAmountNotEqualTo(Double fncCreditAmountNotEqualTo) {
		this.fncCreditAmountNotEqualTo = fncCreditAmountNotEqualTo;
	}

	public Double getFncCreditAmountLessThanOrEqualTo() {
		return fncCreditAmountLessThanOrEqualTo;
	}
	public void setFncCreditAmountLessThanOrEqualTo(Double fncCreditAmountLessThanOrEqualTo) {
		this.fncCreditAmountLessThanOrEqualTo = fncCreditAmountLessThanOrEqualTo;
	}

	public Double getFncCreditAmountLessThan() {
		return fncCreditAmountLessThan;
	}
	public void setFncCreditAmountLessThan(Double fncCreditAmountLessThan) {
		this.fncCreditAmountLessThan = fncCreditAmountLessThan;
	}

	public Boolean getFncCreditAmountIsNull() {
		return fncCreditAmountIsNull;
	}
	public void setFncCreditAmountIsNull(Boolean fncCreditAmountIsNull) {
		this.fncCreditAmountIsNull = fncCreditAmountIsNull;
	}

	public Boolean getFncCreditAmountIsNotNull() {
		return fncCreditAmountIsNotNull;
	}
	public void setFncCreditAmountIsNotNull(Boolean fncCreditAmountIsNotNull) {
		this.fncCreditAmountIsNotNull = fncCreditAmountIsNotNull;
	}

	public java.util.List getFncCreditAmountIn() {
		return fncCreditAmountIn;
	}
	public void setFncCreditAmountIn(java.util.List fncCreditAmountIn) {
		this.fncCreditAmountIn = fncCreditAmountIn;
	}

	public Double getFncCreditAmountGreaterThanOrEqualTo() {
		return fncCreditAmountGreaterThanOrEqualTo;
	}
	public void setFncCreditAmountGreaterThanOrEqualTo(Double fncCreditAmountGreaterThanOrEqualTo) {
		this.fncCreditAmountGreaterThanOrEqualTo = fncCreditAmountGreaterThanOrEqualTo;
	}

	public Double getFncCreditAmountGreaterThan() {
		return fncCreditAmountGreaterThan;
	}
	public void setFncCreditAmountGreaterThan(Double fncCreditAmountGreaterThan) {
		this.fncCreditAmountGreaterThan = fncCreditAmountGreaterThan;
	}

	public Double getFncCreditAmountEqualTo() {
		return fncCreditAmountEqualTo;
	}
	public void setFncCreditAmountEqualTo(Double fncCreditAmountEqualTo) {
		this.fncCreditAmountEqualTo = fncCreditAmountEqualTo;
	}

	public String getFncCityNotLike() {
		return fncCityNotLike;
	}
	public void setFncCityNotLike(String fncCityNotLike) {
		this.fncCityNotLike = fncCityNotLike;
	}

	public java.util.List getFncCityNotIn() {
		return fncCityNotIn;
	}
	public void setFncCityNotIn(java.util.List fncCityNotIn) {
		this.fncCityNotIn = fncCityNotIn;
	}

	public String getFncCityNotEqualTo() {
		return fncCityNotEqualTo;
	}
	public void setFncCityNotEqualTo(String fncCityNotEqualTo) {
		this.fncCityNotEqualTo = fncCityNotEqualTo;
	}

	public String getFncCityLike() {
		return fncCityLike;
	}
	public void setFncCityLike(String fncCityLike) {
		this.fncCityLike = fncCityLike;
	}

	public String getFncCityLessThanOrEqualTo() {
		return fncCityLessThanOrEqualTo;
	}
	public void setFncCityLessThanOrEqualTo(String fncCityLessThanOrEqualTo) {
		this.fncCityLessThanOrEqualTo = fncCityLessThanOrEqualTo;
	}

	public String getFncCityLessThan() {
		return fncCityLessThan;
	}
	public void setFncCityLessThan(String fncCityLessThan) {
		this.fncCityLessThan = fncCityLessThan;
	}

	public Boolean getFncCityIsNull() {
		return fncCityIsNull;
	}
	public void setFncCityIsNull(Boolean fncCityIsNull) {
		this.fncCityIsNull = fncCityIsNull;
	}

	public Boolean getFncCityIsNotNull() {
		return fncCityIsNotNull;
	}
	public void setFncCityIsNotNull(Boolean fncCityIsNotNull) {
		this.fncCityIsNotNull = fncCityIsNotNull;
	}

	public java.util.List getFncCityIn() {
		return fncCityIn;
	}
	public void setFncCityIn(java.util.List fncCityIn) {
		this.fncCityIn = fncCityIn;
	}

	public String getFncCityGreaterThanOrEqualTo() {
		return fncCityGreaterThanOrEqualTo;
	}
	public void setFncCityGreaterThanOrEqualTo(String fncCityGreaterThanOrEqualTo) {
		this.fncCityGreaterThanOrEqualTo = fncCityGreaterThanOrEqualTo;
	}

	public String getFncCityGreaterThan() {
		return fncCityGreaterThan;
	}
	public void setFncCityGreaterThan(String fncCityGreaterThan) {
		this.fncCityGreaterThan = fncCityGreaterThan;
	}

	public String getFncCityEqualTo() {
		return fncCityEqualTo;
	}
	public void setFncCityEqualTo(String fncCityEqualTo) {
		this.fncCityEqualTo = fncCityEqualTo;
	}

	public String getFncCarVinNotLike() {
		return fncCarVinNotLike;
	}
	public void setFncCarVinNotLike(String fncCarVinNotLike) {
		this.fncCarVinNotLike = fncCarVinNotLike;
	}

	public java.util.List getFncCarVinNotIn() {
		return fncCarVinNotIn;
	}
	public void setFncCarVinNotIn(java.util.List fncCarVinNotIn) {
		this.fncCarVinNotIn = fncCarVinNotIn;
	}

	public String getFncCarVinNotEqualTo() {
		return fncCarVinNotEqualTo;
	}
	public void setFncCarVinNotEqualTo(String fncCarVinNotEqualTo) {
		this.fncCarVinNotEqualTo = fncCarVinNotEqualTo;
	}

	public String getFncCarVinLike() {
		return fncCarVinLike;
	}
	public void setFncCarVinLike(String fncCarVinLike) {
		this.fncCarVinLike = fncCarVinLike;
	}

	public String getFncCarVinLessThanOrEqualTo() {
		return fncCarVinLessThanOrEqualTo;
	}
	public void setFncCarVinLessThanOrEqualTo(String fncCarVinLessThanOrEqualTo) {
		this.fncCarVinLessThanOrEqualTo = fncCarVinLessThanOrEqualTo;
	}

	public String getFncCarVinLessThan() {
		return fncCarVinLessThan;
	}
	public void setFncCarVinLessThan(String fncCarVinLessThan) {
		this.fncCarVinLessThan = fncCarVinLessThan;
	}

	public Boolean getFncCarVinIsNull() {
		return fncCarVinIsNull;
	}
	public void setFncCarVinIsNull(Boolean fncCarVinIsNull) {
		this.fncCarVinIsNull = fncCarVinIsNull;
	}

	public Boolean getFncCarVinIsNotNull() {
		return fncCarVinIsNotNull;
	}
	public void setFncCarVinIsNotNull(Boolean fncCarVinIsNotNull) {
		this.fncCarVinIsNotNull = fncCarVinIsNotNull;
	}

	public java.util.List getFncCarVinIn() {
		return fncCarVinIn;
	}
	public void setFncCarVinIn(java.util.List fncCarVinIn) {
		this.fncCarVinIn = fncCarVinIn;
	}

	public String getFncCarVinGreaterThanOrEqualTo() {
		return fncCarVinGreaterThanOrEqualTo;
	}
	public void setFncCarVinGreaterThanOrEqualTo(String fncCarVinGreaterThanOrEqualTo) {
		this.fncCarVinGreaterThanOrEqualTo = fncCarVinGreaterThanOrEqualTo;
	}

	public String getFncCarVinGreaterThan() {
		return fncCarVinGreaterThan;
	}
	public void setFncCarVinGreaterThan(String fncCarVinGreaterThan) {
		this.fncCarVinGreaterThan = fncCarVinGreaterThan;
	}

	public String getFncCarVinEqualTo() {
		return fncCarVinEqualTo;
	}
	public void setFncCarVinEqualTo(String fncCarVinEqualTo) {
		this.fncCarVinEqualTo = fncCarVinEqualTo;
	}

	public java.util.List getFncBorrowAmountNotIn() {
		return fncBorrowAmountNotIn;
	}
	public void setFncBorrowAmountNotIn(java.util.List fncBorrowAmountNotIn) {
		this.fncBorrowAmountNotIn = fncBorrowAmountNotIn;
	}

	public Double getFncBorrowAmountNotEqualTo() {
		return fncBorrowAmountNotEqualTo;
	}
	public void setFncBorrowAmountNotEqualTo(Double fncBorrowAmountNotEqualTo) {
		this.fncBorrowAmountNotEqualTo = fncBorrowAmountNotEqualTo;
	}

	public Double getFncBorrowAmountLessThanOrEqualTo() {
		return fncBorrowAmountLessThanOrEqualTo;
	}
	public void setFncBorrowAmountLessThanOrEqualTo(Double fncBorrowAmountLessThanOrEqualTo) {
		this.fncBorrowAmountLessThanOrEqualTo = fncBorrowAmountLessThanOrEqualTo;
	}

	public Double getFncBorrowAmountLessThan() {
		return fncBorrowAmountLessThan;
	}
	public void setFncBorrowAmountLessThan(Double fncBorrowAmountLessThan) {
		this.fncBorrowAmountLessThan = fncBorrowAmountLessThan;
	}

	public Boolean getFncBorrowAmountIsNull() {
		return fncBorrowAmountIsNull;
	}
	public void setFncBorrowAmountIsNull(Boolean fncBorrowAmountIsNull) {
		this.fncBorrowAmountIsNull = fncBorrowAmountIsNull;
	}

	public Boolean getFncBorrowAmountIsNotNull() {
		return fncBorrowAmountIsNotNull;
	}
	public void setFncBorrowAmountIsNotNull(Boolean fncBorrowAmountIsNotNull) {
		this.fncBorrowAmountIsNotNull = fncBorrowAmountIsNotNull;
	}

	public java.util.List getFncBorrowAmountIn() {
		return fncBorrowAmountIn;
	}
	public void setFncBorrowAmountIn(java.util.List fncBorrowAmountIn) {
		this.fncBorrowAmountIn = fncBorrowAmountIn;
	}

	public Double getFncBorrowAmountGreaterThanOrEqualTo() {
		return fncBorrowAmountGreaterThanOrEqualTo;
	}
	public void setFncBorrowAmountGreaterThanOrEqualTo(Double fncBorrowAmountGreaterThanOrEqualTo) {
		this.fncBorrowAmountGreaterThanOrEqualTo = fncBorrowAmountGreaterThanOrEqualTo;
	}

	public Double getFncBorrowAmountGreaterThan() {
		return fncBorrowAmountGreaterThan;
	}
	public void setFncBorrowAmountGreaterThan(Double fncBorrowAmountGreaterThan) {
		this.fncBorrowAmountGreaterThan = fncBorrowAmountGreaterThan;
	}

	public Double getFncBorrowAmountEqualTo() {
		return fncBorrowAmountEqualTo;
	}
	public void setFncBorrowAmountEqualTo(Double fncBorrowAmountEqualTo) {
		this.fncBorrowAmountEqualTo = fncBorrowAmountEqualTo;
	}

	public String getFncAgreementNumberNotLike() {
		return fncAgreementNumberNotLike;
	}
	public void setFncAgreementNumberNotLike(String fncAgreementNumberNotLike) {
		this.fncAgreementNumberNotLike = fncAgreementNumberNotLike;
	}

	public java.util.List getFncAgreementNumberNotIn() {
		return fncAgreementNumberNotIn;
	}
	public void setFncAgreementNumberNotIn(java.util.List fncAgreementNumberNotIn) {
		this.fncAgreementNumberNotIn = fncAgreementNumberNotIn;
	}

	public String getFncAgreementNumberNotEqualTo() {
		return fncAgreementNumberNotEqualTo;
	}
	public void setFncAgreementNumberNotEqualTo(String fncAgreementNumberNotEqualTo) {
		this.fncAgreementNumberNotEqualTo = fncAgreementNumberNotEqualTo;
	}

	public String getFncAgreementNumberLike() {
		return fncAgreementNumberLike;
	}
	public void setFncAgreementNumberLike(String fncAgreementNumberLike) {
		this.fncAgreementNumberLike = fncAgreementNumberLike;
	}

	public String getFncAgreementNumberLessThanOrEqualTo() {
		return fncAgreementNumberLessThanOrEqualTo;
	}
	public void setFncAgreementNumberLessThanOrEqualTo(String fncAgreementNumberLessThanOrEqualTo) {
		this.fncAgreementNumberLessThanOrEqualTo = fncAgreementNumberLessThanOrEqualTo;
	}

	public String getFncAgreementNumberLessThan() {
		return fncAgreementNumberLessThan;
	}
	public void setFncAgreementNumberLessThan(String fncAgreementNumberLessThan) {
		this.fncAgreementNumberLessThan = fncAgreementNumberLessThan;
	}

	public Boolean getFncAgreementNumberIsNull() {
		return fncAgreementNumberIsNull;
	}
	public void setFncAgreementNumberIsNull(Boolean fncAgreementNumberIsNull) {
		this.fncAgreementNumberIsNull = fncAgreementNumberIsNull;
	}

	public Boolean getFncAgreementNumberIsNotNull() {
		return fncAgreementNumberIsNotNull;
	}
	public void setFncAgreementNumberIsNotNull(Boolean fncAgreementNumberIsNotNull) {
		this.fncAgreementNumberIsNotNull = fncAgreementNumberIsNotNull;
	}

	public java.util.List getFncAgreementNumberIn() {
		return fncAgreementNumberIn;
	}
	public void setFncAgreementNumberIn(java.util.List fncAgreementNumberIn) {
		this.fncAgreementNumberIn = fncAgreementNumberIn;
	}

	public String getFncAgreementNumberGreaterThanOrEqualTo() {
		return fncAgreementNumberGreaterThanOrEqualTo;
	}
	public void setFncAgreementNumberGreaterThanOrEqualTo(String fncAgreementNumberGreaterThanOrEqualTo) {
		this.fncAgreementNumberGreaterThanOrEqualTo = fncAgreementNumberGreaterThanOrEqualTo;
	}

	public String getFncAgreementNumberGreaterThan() {
		return fncAgreementNumberGreaterThan;
	}
	public void setFncAgreementNumberGreaterThan(String fncAgreementNumberGreaterThan) {
		this.fncAgreementNumberGreaterThan = fncAgreementNumberGreaterThan;
	}

	public String getFncAgreementNumberEqualTo() {
		return fncAgreementNumberEqualTo;
	}
	public void setFncAgreementNumberEqualTo(String fncAgreementNumberEqualTo) {
		this.fncAgreementNumberEqualTo = fncAgreementNumberEqualTo;
	}

	public String getFncAccountNoNotLike() {
		return fncAccountNoNotLike;
	}
	public void setFncAccountNoNotLike(String fncAccountNoNotLike) {
		this.fncAccountNoNotLike = fncAccountNoNotLike;
	}

	public java.util.List getFncAccountNoNotIn() {
		return fncAccountNoNotIn;
	}
	public void setFncAccountNoNotIn(java.util.List fncAccountNoNotIn) {
		this.fncAccountNoNotIn = fncAccountNoNotIn;
	}

	public String getFncAccountNoNotEqualTo() {
		return fncAccountNoNotEqualTo;
	}
	public void setFncAccountNoNotEqualTo(String fncAccountNoNotEqualTo) {
		this.fncAccountNoNotEqualTo = fncAccountNoNotEqualTo;
	}

	public String getFncAccountNoLike() {
		return fncAccountNoLike;
	}
	public void setFncAccountNoLike(String fncAccountNoLike) {
		this.fncAccountNoLike = fncAccountNoLike;
	}

	public String getFncAccountNoLessThanOrEqualTo() {
		return fncAccountNoLessThanOrEqualTo;
	}
	public void setFncAccountNoLessThanOrEqualTo(String fncAccountNoLessThanOrEqualTo) {
		this.fncAccountNoLessThanOrEqualTo = fncAccountNoLessThanOrEqualTo;
	}

	public String getFncAccountNoLessThan() {
		return fncAccountNoLessThan;
	}
	public void setFncAccountNoLessThan(String fncAccountNoLessThan) {
		this.fncAccountNoLessThan = fncAccountNoLessThan;
	}

	public Boolean getFncAccountNoIsNull() {
		return fncAccountNoIsNull;
	}
	public void setFncAccountNoIsNull(Boolean fncAccountNoIsNull) {
		this.fncAccountNoIsNull = fncAccountNoIsNull;
	}

	public Boolean getFncAccountNoIsNotNull() {
		return fncAccountNoIsNotNull;
	}
	public void setFncAccountNoIsNotNull(Boolean fncAccountNoIsNotNull) {
		this.fncAccountNoIsNotNull = fncAccountNoIsNotNull;
	}

	public java.util.List getFncAccountNoIn() {
		return fncAccountNoIn;
	}
	public void setFncAccountNoIn(java.util.List fncAccountNoIn) {
		this.fncAccountNoIn = fncAccountNoIn;
	}

	public String getFncAccountNoGreaterThanOrEqualTo() {
		return fncAccountNoGreaterThanOrEqualTo;
	}
	public void setFncAccountNoGreaterThanOrEqualTo(String fncAccountNoGreaterThanOrEqualTo) {
		this.fncAccountNoGreaterThanOrEqualTo = fncAccountNoGreaterThanOrEqualTo;
	}

	public String getFncAccountNoGreaterThan() {
		return fncAccountNoGreaterThan;
	}
	public void setFncAccountNoGreaterThan(String fncAccountNoGreaterThan) {
		this.fncAccountNoGreaterThan = fncAccountNoGreaterThan;
	}

	public String getFncAccountNoEqualTo() {
		return fncAccountNoEqualTo;
	}
	public void setFncAccountNoEqualTo(String fncAccountNoEqualTo) {
		this.fncAccountNoEqualTo = fncAccountNoEqualTo;
	}

	public String getFncAccountDealFlowNotLike() {
		return fncAccountDealFlowNotLike;
	}
	public void setFncAccountDealFlowNotLike(String fncAccountDealFlowNotLike) {
		this.fncAccountDealFlowNotLike = fncAccountDealFlowNotLike;
	}

	public java.util.List getFncAccountDealFlowNotIn() {
		return fncAccountDealFlowNotIn;
	}
	public void setFncAccountDealFlowNotIn(java.util.List fncAccountDealFlowNotIn) {
		this.fncAccountDealFlowNotIn = fncAccountDealFlowNotIn;
	}

	public String getFncAccountDealFlowNotEqualTo() {
		return fncAccountDealFlowNotEqualTo;
	}
	public void setFncAccountDealFlowNotEqualTo(String fncAccountDealFlowNotEqualTo) {
		this.fncAccountDealFlowNotEqualTo = fncAccountDealFlowNotEqualTo;
	}

	public String getFncAccountDealFlowLike() {
		return fncAccountDealFlowLike;
	}
	public void setFncAccountDealFlowLike(String fncAccountDealFlowLike) {
		this.fncAccountDealFlowLike = fncAccountDealFlowLike;
	}

	public String getFncAccountDealFlowLessThanOrEqualTo() {
		return fncAccountDealFlowLessThanOrEqualTo;
	}
	public void setFncAccountDealFlowLessThanOrEqualTo(String fncAccountDealFlowLessThanOrEqualTo) {
		this.fncAccountDealFlowLessThanOrEqualTo = fncAccountDealFlowLessThanOrEqualTo;
	}

	public String getFncAccountDealFlowLessThan() {
		return fncAccountDealFlowLessThan;
	}
	public void setFncAccountDealFlowLessThan(String fncAccountDealFlowLessThan) {
		this.fncAccountDealFlowLessThan = fncAccountDealFlowLessThan;
	}

	public Boolean getFncAccountDealFlowIsNull() {
		return fncAccountDealFlowIsNull;
	}
	public void setFncAccountDealFlowIsNull(Boolean fncAccountDealFlowIsNull) {
		this.fncAccountDealFlowIsNull = fncAccountDealFlowIsNull;
	}

	public Boolean getFncAccountDealFlowIsNotNull() {
		return fncAccountDealFlowIsNotNull;
	}
	public void setFncAccountDealFlowIsNotNull(Boolean fncAccountDealFlowIsNotNull) {
		this.fncAccountDealFlowIsNotNull = fncAccountDealFlowIsNotNull;
	}

	public java.util.List getFncAccountDealFlowIn() {
		return fncAccountDealFlowIn;
	}
	public void setFncAccountDealFlowIn(java.util.List fncAccountDealFlowIn) {
		this.fncAccountDealFlowIn = fncAccountDealFlowIn;
	}

	public String getFncAccountDealFlowGreaterThanOrEqualTo() {
		return fncAccountDealFlowGreaterThanOrEqualTo;
	}
	public void setFncAccountDealFlowGreaterThanOrEqualTo(String fncAccountDealFlowGreaterThanOrEqualTo) {
		this.fncAccountDealFlowGreaterThanOrEqualTo = fncAccountDealFlowGreaterThanOrEqualTo;
	}

	public String getFncAccountDealFlowGreaterThan() {
		return fncAccountDealFlowGreaterThan;
	}
	public void setFncAccountDealFlowGreaterThan(String fncAccountDealFlowGreaterThan) {
		this.fncAccountDealFlowGreaterThan = fncAccountDealFlowGreaterThan;
	}

	public String getFncAccountDealFlowEqualTo() {
		return fncAccountDealFlowEqualTo;
	}
	public void setFncAccountDealFlowEqualTo(String fncAccountDealFlowEqualTo) {
		this.fncAccountDealFlowEqualTo = fncAccountDealFlowEqualTo;
	}

	public java.util.List getDrNotIn() {
		return drNotIn;
	}
	public void setDrNotIn(java.util.List drNotIn) {
		this.drNotIn = drNotIn;
	}

	public Integer getDrNotEqualTo() {
		return drNotEqualTo;
	}
	public void setDrNotEqualTo(Integer drNotEqualTo) {
		this.drNotEqualTo = drNotEqualTo;
	}

	public Integer getDrLessThanOrEqualTo() {
		return drLessThanOrEqualTo;
	}
	public void setDrLessThanOrEqualTo(Integer drLessThanOrEqualTo) {
		this.drLessThanOrEqualTo = drLessThanOrEqualTo;
	}

	public Integer getDrLessThan() {
		return drLessThan;
	}
	public void setDrLessThan(Integer drLessThan) {
		this.drLessThan = drLessThan;
	}

	public Boolean getDrIsNull() {
		return drIsNull;
	}
	public void setDrIsNull(Boolean drIsNull) {
		this.drIsNull = drIsNull;
	}

	public Boolean getDrIsNotNull() {
		return drIsNotNull;
	}
	public void setDrIsNotNull(Boolean drIsNotNull) {
		this.drIsNotNull = drIsNotNull;
	}

	public java.util.List getDrIn() {
		return drIn;
	}
	public void setDrIn(java.util.List drIn) {
		this.drIn = drIn;
	}

	public Integer getDrGreaterThanOrEqualTo() {
		return drGreaterThanOrEqualTo;
	}
	public void setDrGreaterThanOrEqualTo(Integer drGreaterThanOrEqualTo) {
		this.drGreaterThanOrEqualTo = drGreaterThanOrEqualTo;
	}

	public Integer getDrGreaterThan() {
		return drGreaterThan;
	}
	public void setDrGreaterThan(Integer drGreaterThan) {
		this.drGreaterThan = drGreaterThan;
	}

	public Integer getDrEqualTo() {
		return drEqualTo;
	}
	public void setDrEqualTo(Integer drEqualTo) {
		this.drEqualTo = drEqualTo;
	}

	public String getCreateuserNotLike() {
		return createuserNotLike;
	}
	public void setCreateuserNotLike(String createuserNotLike) {
		this.createuserNotLike = createuserNotLike;
	}

	public java.util.List getCreateuserNotIn() {
		return createuserNotIn;
	}
	public void setCreateuserNotIn(java.util.List createuserNotIn) {
		this.createuserNotIn = createuserNotIn;
	}

	public String getCreateuserNotEqualTo() {
		return createuserNotEqualTo;
	}
	public void setCreateuserNotEqualTo(String createuserNotEqualTo) {
		this.createuserNotEqualTo = createuserNotEqualTo;
	}

	public String getCreateuserLike() {
		return createuserLike;
	}
	public void setCreateuserLike(String createuserLike) {
		this.createuserLike = createuserLike;
	}

	public String getCreateuserLessThanOrEqualTo() {
		return createuserLessThanOrEqualTo;
	}
	public void setCreateuserLessThanOrEqualTo(String createuserLessThanOrEqualTo) {
		this.createuserLessThanOrEqualTo = createuserLessThanOrEqualTo;
	}

	public String getCreateuserLessThan() {
		return createuserLessThan;
	}
	public void setCreateuserLessThan(String createuserLessThan) {
		this.createuserLessThan = createuserLessThan;
	}

	public Boolean getCreateuserIsNull() {
		return createuserIsNull;
	}
	public void setCreateuserIsNull(Boolean createuserIsNull) {
		this.createuserIsNull = createuserIsNull;
	}

	public Boolean getCreateuserIsNotNull() {
		return createuserIsNotNull;
	}
	public void setCreateuserIsNotNull(Boolean createuserIsNotNull) {
		this.createuserIsNotNull = createuserIsNotNull;
	}

	public java.util.List getCreateuserIn() {
		return createuserIn;
	}
	public void setCreateuserIn(java.util.List createuserIn) {
		this.createuserIn = createuserIn;
	}

	public String getCreateuserGreaterThanOrEqualTo() {
		return createuserGreaterThanOrEqualTo;
	}
	public void setCreateuserGreaterThanOrEqualTo(String createuserGreaterThanOrEqualTo) {
		this.createuserGreaterThanOrEqualTo = createuserGreaterThanOrEqualTo;
	}

	public String getCreateuserGreaterThan() {
		return createuserGreaterThan;
	}
	public void setCreateuserGreaterThan(String createuserGreaterThan) {
		this.createuserGreaterThan = createuserGreaterThan;
	}

	public String getCreateuserEqualTo() {
		return createuserEqualTo;
	}
	public void setCreateuserEqualTo(String createuserEqualTo) {
		this.createuserEqualTo = createuserEqualTo;
	}

	public java.util.List getCreatetimeNotIn() {
		return createtimeNotIn;
	}
	public void setCreatetimeNotIn(java.util.List createtimeNotIn) {
		this.createtimeNotIn = createtimeNotIn;
	}

	public java.util.Date getCreatetimeNotEqualTo() {
		return createtimeNotEqualTo;
	}
	public void setCreatetimeNotEqualTo(java.util.Date createtimeNotEqualTo) {
		this.createtimeNotEqualTo = createtimeNotEqualTo;
	}

	public java.util.Date getCreatetimeLessThanOrEqualTo() {
		return createtimeLessThanOrEqualTo;
	}
	public void setCreatetimeLessThanOrEqualTo(java.util.Date createtimeLessThanOrEqualTo) {
		this.createtimeLessThanOrEqualTo = createtimeLessThanOrEqualTo;
	}

	public java.util.Date getCreatetimeLessThan() {
		return createtimeLessThan;
	}
	public void setCreatetimeLessThan(java.util.Date createtimeLessThan) {
		this.createtimeLessThan = createtimeLessThan;
	}

	public Boolean getCreatetimeIsNull() {
		return createtimeIsNull;
	}
	public void setCreatetimeIsNull(Boolean createtimeIsNull) {
		this.createtimeIsNull = createtimeIsNull;
	}

	public Boolean getCreatetimeIsNotNull() {
		return createtimeIsNotNull;
	}
	public void setCreatetimeIsNotNull(Boolean createtimeIsNotNull) {
		this.createtimeIsNotNull = createtimeIsNotNull;
	}

	public java.util.List getCreatetimeIn() {
		return createtimeIn;
	}
	public void setCreatetimeIn(java.util.List createtimeIn) {
		this.createtimeIn = createtimeIn;
	}

	public java.util.Date getCreatetimeGreaterThanOrEqualTo() {
		return createtimeGreaterThanOrEqualTo;
	}
	public void setCreatetimeGreaterThanOrEqualTo(java.util.Date createtimeGreaterThanOrEqualTo) {
		this.createtimeGreaterThanOrEqualTo = createtimeGreaterThanOrEqualTo;
	}

	public java.util.Date getCreatetimeGreaterThan() {
		return createtimeGreaterThan;
	}
	public void setCreatetimeGreaterThan(java.util.Date createtimeGreaterThan) {
		this.createtimeGreaterThan = createtimeGreaterThan;
	}

	public java.util.Date getCreatetimeEqualTo() {
		return createtimeEqualTo;
	}
	public void setCreatetimeEqualTo(java.util.Date createtimeEqualTo) {
		this.createtimeEqualTo = createtimeEqualTo;
	}

	public void setSidx(String sidx) {
		this.sidx = sidx;
	}
	public String getSord() {
		return sord;
	}
	public void setSord(String sord) {
		 this.sord = sord;
	}
}
