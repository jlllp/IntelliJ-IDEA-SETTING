package com.mrk.finance.dao;

import com.mrk.common.base.BaseMapper;
import com.mrk.finance.model.FncDdWithhold;

/**
 * Mapper接口
 * @author 自动工具
 */
public interface FncDdWithholdMapper extends BaseMapper<FncDdWithhold> {

}
