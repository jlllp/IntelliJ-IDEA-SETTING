package com.mrk.finance.service.impl;

import com.github.pagehelper.PageInfo;
import com.mrk.common.constant.BaseConstants;
import com.mrk.common.utils.bean.BeanUtils;
import com.mrk.common.utils.page.PageUtils;
import com.mrk.common.utils.text.StringUtils;
import com.mrk.finance.dao.FncTtWithholdMapper;
import com.mrk.finance.example.FncTtWithholdExample;
import com.mrk.finance.model.FncTtWithhold;
import com.mrk.finance.query.FncTtWithholdQuery;
import com.mrk.finance.queryvo.FncTtWithholdQueryVo;
import com.mrk.finance.service.FncTtWithholdService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import javax.annotation.Resource;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;


/**
 * @Description: FncTtWithholdServiceImpl
 */
@Service
@Slf4j
public class FncTtWithholdServiceImpl implements FncTtWithholdService {
    @Resource
    private FncTtWithholdMapper fncTtWithholdMapper;

    @Override
    public PageInfo<FncTtWithhold> page(FncTtWithholdQueryVo queryVo){
        PageUtils.startPage();
        List<FncTtWithhold> list = this.list(queryVo);
        return new PageInfo<>(list);
    }

    @Override
    public List<FncTtWithhold> list(FncTtWithholdQueryVo queryVo){
        FncTtWithholdQuery query = new FncTtWithholdQuery();
        BeanUtils.copyBeanProp(queryVo, query);
        query.setSidx(StringUtils.camelToUnderlineAndFilterText(query.getSidx()));
        return fncTtWithholdMapper.selectByExample(query.getCrieria());
    }

    @Override
    @Transactional(rollbackFor = Exception.class)
    public int add(FncTtWithhold entity){
        entity.setCreatetime(new Date());
        entity.setUpdatetime(new Date());
        entity.setDr(BaseConstants.DR_NO);
        return fncTtWithholdMapper.insert(entity);
    }

    @Override
    @Transactional(rollbackFor = Exception.class)
    public int update(FncTtWithhold entity){
        entity.setUpdatetime(new Date());
        return fncTtWithholdMapper.updateByPrimaryKey(entity);
    }

    @Override
    @Transactional(rollbackFor = Exception.class)
    public int delete(Long id){
        return fncTtWithholdMapper.deleteByPrimaryKey(id);
    }

    @Override
    public FncTtWithhold getById(Long id){
        return fncTtWithholdMapper.selectByPrimaryKey(id);
    }

    @Override
    public List<FncTtWithhold> getByIds(List<Long> ids) {
        if (ids == null || ids.isEmpty()) {
            return new ArrayList<>();
        }

        FncTtWithholdExample example = new FncTtWithholdExample();
        example.createCriteria()
                .andDrEqualTo(BaseConstants.DR_NO)
                .andFtwIdIn(ids);

        return fncTtWithholdMapper.selectByExample(example);
    }

    @Override
    public int insertList(List<FncTtWithhold> fncTtWithholdList) {
        return fncTtWithholdMapper.insertList(fncTtWithholdList);
    }
}
