package com.mrk.finance.query;
import com.mrk.common.utils.text.CheckUtil;

/**
 * @author 自动生成工具
 * @date   2022/06/16 
 */
public class FncBillMatchRecordQuery {
	private String updateuserNotLike;
	private java.util.List updateuserNotIn;
	private String updateuserNotEqualTo;
	private String updateuserLike;
	private String updateuserLessThanOrEqualTo;
	private String updateuserLessThan;
	private Boolean updateuserIsNull;
	private Boolean updateuserIsNotNull;
	private java.util.List updateuserIn;
	private String updateuserGreaterThanOrEqualTo;
	private String updateuserGreaterThan;
	private String updateuserEqualTo;
	private java.util.List updatetimeNotIn;
	private java.util.Date updatetimeNotEqualTo;
	private java.util.Date updatetimeLessThanOrEqualTo;
	private java.util.Date updatetimeLessThan;
	private Boolean updatetimeIsNull;
	private Boolean updatetimeIsNotNull;
	private java.util.List updatetimeIn;
	private java.util.Date updatetimeGreaterThanOrEqualTo;
	private java.util.Date updatetimeGreaterThan;
	private java.util.Date updatetimeEqualTo;
	private String remarkNotLike;
	private java.util.List remarkNotIn;
	private String remarkNotEqualTo;
	private String remarkLike;
	private String remarkLessThanOrEqualTo;
	private String remarkLessThan;
	private Boolean remarkIsNull;
	private Boolean remarkIsNotNull;
	private java.util.List remarkIn;
	private String remarkGreaterThanOrEqualTo;
	private String remarkGreaterThan;
	private String remarkEqualTo;
	private java.util.List fbmrWaterTypeNotIn;
	private Integer fbmrWaterTypeNotEqualTo;
	private Integer fbmrWaterTypeLessThanOrEqualTo;
	private Integer fbmrWaterTypeLessThan;
	private Boolean fbmrWaterTypeIsNull;
	private Boolean fbmrWaterTypeIsNotNull;
	private java.util.List fbmrWaterTypeIn;
	private Integer fbmrWaterTypeGreaterThanOrEqualTo;
	private Integer fbmrWaterTypeGreaterThan;
	private Integer fbmrWaterTypeEqualTo;
	private java.util.List fbmrWaterIdNotIn;
	private Long fbmrWaterIdNotEqualTo;
	private Long fbmrWaterIdLessThanOrEqualTo;
	private Long fbmrWaterIdLessThan;
	private Boolean fbmrWaterIdIsNull;
	private Boolean fbmrWaterIdIsNotNull;
	private java.util.List fbmrWaterIdIn;
	private Long fbmrWaterIdGreaterThanOrEqualTo;
	private Long fbmrWaterIdGreaterThan;
	private Long fbmrWaterIdEqualTo;
	private java.util.List fbmrMatchMoneyNotIn;
	private Double fbmrMatchMoneyNotEqualTo;
	private Double fbmrMatchMoneyLessThanOrEqualTo;
	private Double fbmrMatchMoneyLessThan;
	private Boolean fbmrMatchMoneyIsNull;
	private Boolean fbmrMatchMoneyIsNotNull;
	private java.util.List fbmrMatchMoneyIn;
	private Double fbmrMatchMoneyGreaterThanOrEqualTo;
	private Double fbmrMatchMoneyGreaterThan;
	private Double fbmrMatchMoneyEqualTo;
	private java.util.List fbmrIdNotIn;
	private Long fbmrIdNotEqualTo;
	private Long fbmrIdLessThanOrEqualTo;
	private Long fbmrIdLessThan;
	private Boolean fbmrIdIsNull;
	private Boolean fbmrIdIsNotNull;
	private java.util.List fbmrIdIn;
	private Long fbmrIdGreaterThanOrEqualTo;
	private Long fbmrIdGreaterThan;
	private Long fbmrIdEqualTo;
	private java.util.List fbmrBillIdNotIn;
	private Long fbmrBillIdNotEqualTo;
	private Long fbmrBillIdLessThanOrEqualTo;
	private Long fbmrBillIdLessThan;
	private Boolean fbmrBillIdIsNull;
	private Boolean fbmrBillIdIsNotNull;
	private java.util.List fbmrBillIdIn;
	private Long fbmrBillIdGreaterThanOrEqualTo;
	private Long fbmrBillIdGreaterThan;
	private Long fbmrBillIdEqualTo;
	private java.util.List drNotIn;
	private Integer drNotEqualTo;
	private Integer drLessThanOrEqualTo;
	private Integer drLessThan;
	private Boolean drIsNull;
	private Boolean drIsNotNull;
	private java.util.List drIn;
	private Integer drGreaterThanOrEqualTo;
	private Integer drGreaterThan;
	private Integer drEqualTo;
	private String createuserNotLike;
	private java.util.List createuserNotIn;
	private String createuserNotEqualTo;
	private String createuserLike;
	private String createuserLessThanOrEqualTo;
	private String createuserLessThan;
	private Boolean createuserIsNull;
	private Boolean createuserIsNotNull;
	private java.util.List createuserIn;
	private String createuserGreaterThanOrEqualTo;
	private String createuserGreaterThan;
	private String createuserEqualTo;
	private java.util.List createtimeNotIn;
	private java.util.Date createtimeNotEqualTo;
	private java.util.Date createtimeLessThanOrEqualTo;
	private java.util.Date createtimeLessThan;
	private Boolean createtimeIsNull;
	private Boolean createtimeIsNotNull;
	private java.util.List createtimeIn;
	private java.util.Date createtimeGreaterThanOrEqualTo;
	private java.util.Date createtimeGreaterThan;
	private java.util.Date createtimeEqualTo;
	private String sidx;
	private String sord;
	public String getSidx(){
		if(this.sidx == null){
			return "";
		}
		else if("updateuser".equals(this.sidx)){
			return "updateuser";
		}
		else if("updatetime".equals(this.sidx)){
			return "updatetime";
		}
		else if("remark".equals(this.sidx)){
			return "remark";
		}
		else if("fbmrWaterType".equals(this.sidx)){
			return "fbmr_water_type";
		}
		else if("fbmrWaterId".equals(this.sidx)){
			return "fbmr_water_id";
		}
		else if("fbmrMatchMoney".equals(this.sidx)){
			return "fbmr_match_money";
		}
		else if("fbmrId".equals(this.sidx)){
			return "fbmr_id";
		}
		else if("fbmrBillId".equals(this.sidx)){
			return "fbmr_bill_id";
		}
		else if("dr".equals(this.sidx)){
			return "dr";
		}
		else if("createuser".equals(this.sidx)){
			return "createuser";
		}
		else if("createtime".equals(this.sidx)){
			return "createtime";
		}
		return this.sidx;
	}

	@com.fasterxml.jackson.annotation.JsonIgnore
	public com.mrk.finance.example.FncBillMatchRecordExample getCrieria(){
		com.mrk.finance.example.FncBillMatchRecordExample q = new com.mrk.finance.example.FncBillMatchRecordExample();
		com.mrk.finance.example.FncBillMatchRecordExample.Criteria c = q.createCriteria();
		c.andDrEqualTo(0);
		if(CheckUtil.isNotEmpty(getUpdateuserNotLike())){
			c.andUpdateuserNotLike("%"+this.getUpdateuserNotLike()+"%");
		}
		if(CheckUtil.isNotEmpty(getUpdateuserNotIn())){
			c.andUpdateuserNotIn(this.getUpdateuserNotIn());
		}
		if(CheckUtil.isNotEmpty(getUpdateuserNotEqualTo())){
			c.andUpdateuserNotEqualTo(this.getUpdateuserNotEqualTo());
		}
		if(CheckUtil.isNotEmpty(getUpdateuserLike())){
			c.andUpdateuserLike("%"+this.getUpdateuserLike()+"%");
		}
		if(CheckUtil.isNotEmpty(getUpdateuserLessThanOrEqualTo())){
			c.andUpdateuserLessThanOrEqualTo(this.getUpdateuserLessThanOrEqualTo());
		}
		if(CheckUtil.isNotEmpty(getUpdateuserLessThan())){
			c.andUpdateuserLessThan(this.getUpdateuserLessThan());
		}
		if(CheckUtil.isNotEmpty(getUpdateuserIsNull()) && this.getUpdateuserIsNull()){
			c.andUpdateuserIsNull();
		}
		if(CheckUtil.isNotEmpty(getUpdateuserIsNotNull()) && this.getUpdateuserIsNotNull()){
			c.andUpdateuserIsNotNull();
		}
		if(CheckUtil.isNotEmpty(getUpdateuserIn())){
			c.andUpdateuserIn(this.getUpdateuserIn());
		}
		if(CheckUtil.isNotEmpty(getUpdateuserGreaterThanOrEqualTo())){
			c.andUpdateuserGreaterThanOrEqualTo(this.getUpdateuserGreaterThanOrEqualTo());
		}
		if(CheckUtil.isNotEmpty(getUpdateuserGreaterThan())){
			c.andUpdateuserGreaterThan(this.getUpdateuserGreaterThan());
		}
		if(CheckUtil.isNotEmpty(getUpdateuserEqualTo())){
			c.andUpdateuserEqualTo(this.getUpdateuserEqualTo());
		}
		if(CheckUtil.isNotEmpty(getUpdatetimeNotIn())){
			c.andUpdatetimeNotIn(this.getUpdatetimeNotIn());
		}
		if(CheckUtil.isNotEmpty(getUpdatetimeNotEqualTo())){
			c.andUpdatetimeNotEqualTo(this.getUpdatetimeNotEqualTo());
		}
		if(CheckUtil.isNotEmpty(getUpdatetimeLessThanOrEqualTo())){
			c.andUpdatetimeLessThanOrEqualTo(this.getUpdatetimeLessThanOrEqualTo());
		}
		if(CheckUtil.isNotEmpty(getUpdatetimeLessThan())){
			c.andUpdatetimeLessThan(this.getUpdatetimeLessThan());
		}
		if(CheckUtil.isNotEmpty(getUpdatetimeIsNull()) && this.getUpdatetimeIsNull()){
			c.andUpdatetimeIsNull();
		}
		if(CheckUtil.isNotEmpty(getUpdatetimeIsNotNull()) && this.getUpdatetimeIsNotNull()){
			c.andUpdatetimeIsNotNull();
		}
		if(CheckUtil.isNotEmpty(getUpdatetimeIn())){
			c.andUpdatetimeIn(this.getUpdatetimeIn());
		}
		if(CheckUtil.isNotEmpty(getUpdatetimeGreaterThanOrEqualTo())){
			c.andUpdatetimeGreaterThanOrEqualTo(this.getUpdatetimeGreaterThanOrEqualTo());
		}
		if(CheckUtil.isNotEmpty(getUpdatetimeGreaterThan())){
			c.andUpdatetimeGreaterThan(this.getUpdatetimeGreaterThan());
		}
		if(CheckUtil.isNotEmpty(getUpdatetimeEqualTo())){
			c.andUpdatetimeEqualTo(this.getUpdatetimeEqualTo());
		}
		if(CheckUtil.isNotEmpty(getRemarkNotLike())){
			c.andRemarkNotLike("%"+this.getRemarkNotLike()+"%");
		}
		if(CheckUtil.isNotEmpty(getRemarkNotIn())){
			c.andRemarkNotIn(this.getRemarkNotIn());
		}
		if(CheckUtil.isNotEmpty(getRemarkNotEqualTo())){
			c.andRemarkNotEqualTo(this.getRemarkNotEqualTo());
		}
		if(CheckUtil.isNotEmpty(getRemarkLike())){
			c.andRemarkLike("%"+this.getRemarkLike()+"%");
		}
		if(CheckUtil.isNotEmpty(getRemarkLessThanOrEqualTo())){
			c.andRemarkLessThanOrEqualTo(this.getRemarkLessThanOrEqualTo());
		}
		if(CheckUtil.isNotEmpty(getRemarkLessThan())){
			c.andRemarkLessThan(this.getRemarkLessThan());
		}
		if(CheckUtil.isNotEmpty(getRemarkIsNull()) && this.getRemarkIsNull()){
			c.andRemarkIsNull();
		}
		if(CheckUtil.isNotEmpty(getRemarkIsNotNull()) && this.getRemarkIsNotNull()){
			c.andRemarkIsNotNull();
		}
		if(CheckUtil.isNotEmpty(getRemarkIn())){
			c.andRemarkIn(this.getRemarkIn());
		}
		if(CheckUtil.isNotEmpty(getRemarkGreaterThanOrEqualTo())){
			c.andRemarkGreaterThanOrEqualTo(this.getRemarkGreaterThanOrEqualTo());
		}
		if(CheckUtil.isNotEmpty(getRemarkGreaterThan())){
			c.andRemarkGreaterThan(this.getRemarkGreaterThan());
		}
		if(CheckUtil.isNotEmpty(getRemarkEqualTo())){
			c.andRemarkEqualTo(this.getRemarkEqualTo());
		}
		if(CheckUtil.isNotEmpty(getFbmrWaterTypeNotIn())){
			c.andFbmrWaterTypeNotIn(this.getFbmrWaterTypeNotIn());
		}
		if(CheckUtil.isNotEmpty(getFbmrWaterTypeNotEqualTo())){
			c.andFbmrWaterTypeNotEqualTo(this.getFbmrWaterTypeNotEqualTo());
		}
		if(CheckUtil.isNotEmpty(getFbmrWaterTypeLessThanOrEqualTo())){
			c.andFbmrWaterTypeLessThanOrEqualTo(this.getFbmrWaterTypeLessThanOrEqualTo());
		}
		if(CheckUtil.isNotEmpty(getFbmrWaterTypeLessThan())){
			c.andFbmrWaterTypeLessThan(this.getFbmrWaterTypeLessThan());
		}
		if(CheckUtil.isNotEmpty(getFbmrWaterTypeIsNull()) && this.getFbmrWaterTypeIsNull()){
			c.andFbmrWaterTypeIsNull();
		}
		if(CheckUtil.isNotEmpty(getFbmrWaterTypeIsNotNull()) && this.getFbmrWaterTypeIsNotNull()){
			c.andFbmrWaterTypeIsNotNull();
		}
		if(CheckUtil.isNotEmpty(getFbmrWaterTypeIn())){
			c.andFbmrWaterTypeIn(this.getFbmrWaterTypeIn());
		}
		if(CheckUtil.isNotEmpty(getFbmrWaterTypeGreaterThanOrEqualTo())){
			c.andFbmrWaterTypeGreaterThanOrEqualTo(this.getFbmrWaterTypeGreaterThanOrEqualTo());
		}
		if(CheckUtil.isNotEmpty(getFbmrWaterTypeGreaterThan())){
			c.andFbmrWaterTypeGreaterThan(this.getFbmrWaterTypeGreaterThan());
		}
		if(CheckUtil.isNotEmpty(getFbmrWaterTypeEqualTo())){
			c.andFbmrWaterTypeEqualTo(this.getFbmrWaterTypeEqualTo());
		}
		if(CheckUtil.isNotEmpty(getFbmrWaterIdNotIn())){
			c.andFbmrWaterIdNotIn(this.getFbmrWaterIdNotIn());
		}
		if(CheckUtil.isNotEmpty(getFbmrWaterIdNotEqualTo())){
			c.andFbmrWaterIdNotEqualTo(this.getFbmrWaterIdNotEqualTo());
		}
		if(CheckUtil.isNotEmpty(getFbmrWaterIdLessThanOrEqualTo())){
			c.andFbmrWaterIdLessThanOrEqualTo(this.getFbmrWaterIdLessThanOrEqualTo());
		}
		if(CheckUtil.isNotEmpty(getFbmrWaterIdLessThan())){
			c.andFbmrWaterIdLessThan(this.getFbmrWaterIdLessThan());
		}
		if(CheckUtil.isNotEmpty(getFbmrWaterIdIsNull()) && this.getFbmrWaterIdIsNull()){
			c.andFbmrWaterIdIsNull();
		}
		if(CheckUtil.isNotEmpty(getFbmrWaterIdIsNotNull()) && this.getFbmrWaterIdIsNotNull()){
			c.andFbmrWaterIdIsNotNull();
		}
		if(CheckUtil.isNotEmpty(getFbmrWaterIdIn())){
			c.andFbmrWaterIdIn(this.getFbmrWaterIdIn());
		}
		if(CheckUtil.isNotEmpty(getFbmrWaterIdGreaterThanOrEqualTo())){
			c.andFbmrWaterIdGreaterThanOrEqualTo(this.getFbmrWaterIdGreaterThanOrEqualTo());
		}
		if(CheckUtil.isNotEmpty(getFbmrWaterIdGreaterThan())){
			c.andFbmrWaterIdGreaterThan(this.getFbmrWaterIdGreaterThan());
		}
		if(CheckUtil.isNotEmpty(getFbmrWaterIdEqualTo())){
			c.andFbmrWaterIdEqualTo(this.getFbmrWaterIdEqualTo());
		}
		if(CheckUtil.isNotEmpty(getFbmrMatchMoneyNotIn())){
			c.andFbmrMatchMoneyNotIn(this.getFbmrMatchMoneyNotIn());
		}
		if(CheckUtil.isNotEmpty(getFbmrMatchMoneyNotEqualTo())){
			c.andFbmrMatchMoneyNotEqualTo(this.getFbmrMatchMoneyNotEqualTo());
		}
		if(CheckUtil.isNotEmpty(getFbmrMatchMoneyLessThanOrEqualTo())){
			c.andFbmrMatchMoneyLessThanOrEqualTo(this.getFbmrMatchMoneyLessThanOrEqualTo());
		}
		if(CheckUtil.isNotEmpty(getFbmrMatchMoneyLessThan())){
			c.andFbmrMatchMoneyLessThan(this.getFbmrMatchMoneyLessThan());
		}
		if(CheckUtil.isNotEmpty(getFbmrMatchMoneyIsNull()) && this.getFbmrMatchMoneyIsNull()){
			c.andFbmrMatchMoneyIsNull();
		}
		if(CheckUtil.isNotEmpty(getFbmrMatchMoneyIsNotNull()) && this.getFbmrMatchMoneyIsNotNull()){
			c.andFbmrMatchMoneyIsNotNull();
		}
		if(CheckUtil.isNotEmpty(getFbmrMatchMoneyIn())){
			c.andFbmrMatchMoneyIn(this.getFbmrMatchMoneyIn());
		}
		if(CheckUtil.isNotEmpty(getFbmrMatchMoneyGreaterThanOrEqualTo())){
			c.andFbmrMatchMoneyGreaterThanOrEqualTo(this.getFbmrMatchMoneyGreaterThanOrEqualTo());
		}
		if(CheckUtil.isNotEmpty(getFbmrMatchMoneyGreaterThan())){
			c.andFbmrMatchMoneyGreaterThan(this.getFbmrMatchMoneyGreaterThan());
		}
		if(CheckUtil.isNotEmpty(getFbmrMatchMoneyEqualTo())){
			c.andFbmrMatchMoneyEqualTo(this.getFbmrMatchMoneyEqualTo());
		}
		if(CheckUtil.isNotEmpty(getFbmrIdNotIn())){
			c.andFbmrIdNotIn(this.getFbmrIdNotIn());
		}
		if(CheckUtil.isNotEmpty(getFbmrIdNotEqualTo())){
			c.andFbmrIdNotEqualTo(this.getFbmrIdNotEqualTo());
		}
		if(CheckUtil.isNotEmpty(getFbmrIdLessThanOrEqualTo())){
			c.andFbmrIdLessThanOrEqualTo(this.getFbmrIdLessThanOrEqualTo());
		}
		if(CheckUtil.isNotEmpty(getFbmrIdLessThan())){
			c.andFbmrIdLessThan(this.getFbmrIdLessThan());
		}
		if(CheckUtil.isNotEmpty(getFbmrIdIsNull()) && this.getFbmrIdIsNull()){
			c.andFbmrIdIsNull();
		}
		if(CheckUtil.isNotEmpty(getFbmrIdIsNotNull()) && this.getFbmrIdIsNotNull()){
			c.andFbmrIdIsNotNull();
		}
		if(CheckUtil.isNotEmpty(getFbmrIdIn())){
			c.andFbmrIdIn(this.getFbmrIdIn());
		}
		if(CheckUtil.isNotEmpty(getFbmrIdGreaterThanOrEqualTo())){
			c.andFbmrIdGreaterThanOrEqualTo(this.getFbmrIdGreaterThanOrEqualTo());
		}
		if(CheckUtil.isNotEmpty(getFbmrIdGreaterThan())){
			c.andFbmrIdGreaterThan(this.getFbmrIdGreaterThan());
		}
		if(CheckUtil.isNotEmpty(getFbmrIdEqualTo())){
			c.andFbmrIdEqualTo(this.getFbmrIdEqualTo());
		}
		if(CheckUtil.isNotEmpty(getFbmrBillIdNotIn())){
			c.andFbmrBillIdNotIn(this.getFbmrBillIdNotIn());
		}
		if(CheckUtil.isNotEmpty(getFbmrBillIdNotEqualTo())){
			c.andFbmrBillIdNotEqualTo(this.getFbmrBillIdNotEqualTo());
		}
		if(CheckUtil.isNotEmpty(getFbmrBillIdLessThanOrEqualTo())){
			c.andFbmrBillIdLessThanOrEqualTo(this.getFbmrBillIdLessThanOrEqualTo());
		}
		if(CheckUtil.isNotEmpty(getFbmrBillIdLessThan())){
			c.andFbmrBillIdLessThan(this.getFbmrBillIdLessThan());
		}
		if(CheckUtil.isNotEmpty(getFbmrBillIdIsNull()) && this.getFbmrBillIdIsNull()){
			c.andFbmrBillIdIsNull();
		}
		if(CheckUtil.isNotEmpty(getFbmrBillIdIsNotNull()) && this.getFbmrBillIdIsNotNull()){
			c.andFbmrBillIdIsNotNull();
		}
		if(CheckUtil.isNotEmpty(getFbmrBillIdIn())){
			c.andFbmrBillIdIn(this.getFbmrBillIdIn());
		}
		if(CheckUtil.isNotEmpty(getFbmrBillIdGreaterThanOrEqualTo())){
			c.andFbmrBillIdGreaterThanOrEqualTo(this.getFbmrBillIdGreaterThanOrEqualTo());
		}
		if(CheckUtil.isNotEmpty(getFbmrBillIdGreaterThan())){
			c.andFbmrBillIdGreaterThan(this.getFbmrBillIdGreaterThan());
		}
		if(CheckUtil.isNotEmpty(getFbmrBillIdEqualTo())){
			c.andFbmrBillIdEqualTo(this.getFbmrBillIdEqualTo());
		}
		if(CheckUtil.isNotEmpty(getDrNotIn())){
			c.andDrNotIn(this.getDrNotIn());
		}
		if(CheckUtil.isNotEmpty(getDrNotEqualTo())){
			c.andDrNotEqualTo(this.getDrNotEqualTo());
		}
		if(CheckUtil.isNotEmpty(getDrLessThanOrEqualTo())){
			c.andDrLessThanOrEqualTo(this.getDrLessThanOrEqualTo());
		}
		if(CheckUtil.isNotEmpty(getDrLessThan())){
			c.andDrLessThan(this.getDrLessThan());
		}
		if(CheckUtil.isNotEmpty(getDrIsNull()) && this.getDrIsNull()){
			c.andDrIsNull();
		}
		if(CheckUtil.isNotEmpty(getDrIsNotNull()) && this.getDrIsNotNull()){
			c.andDrIsNotNull();
		}
		if(CheckUtil.isNotEmpty(getDrIn())){
			c.andDrIn(this.getDrIn());
		}
		if(CheckUtil.isNotEmpty(getDrGreaterThanOrEqualTo())){
			c.andDrGreaterThanOrEqualTo(this.getDrGreaterThanOrEqualTo());
		}
		if(CheckUtil.isNotEmpty(getDrGreaterThan())){
			c.andDrGreaterThan(this.getDrGreaterThan());
		}
		if(CheckUtil.isNotEmpty(getDrEqualTo())){
			c.andDrEqualTo(this.getDrEqualTo());
		}
		if(CheckUtil.isNotEmpty(getCreateuserNotLike())){
			c.andCreateuserNotLike("%"+this.getCreateuserNotLike()+"%");
		}
		if(CheckUtil.isNotEmpty(getCreateuserNotIn())){
			c.andCreateuserNotIn(this.getCreateuserNotIn());
		}
		if(CheckUtil.isNotEmpty(getCreateuserNotEqualTo())){
			c.andCreateuserNotEqualTo(this.getCreateuserNotEqualTo());
		}
		if(CheckUtil.isNotEmpty(getCreateuserLike())){
			c.andCreateuserLike("%"+this.getCreateuserLike()+"%");
		}
		if(CheckUtil.isNotEmpty(getCreateuserLessThanOrEqualTo())){
			c.andCreateuserLessThanOrEqualTo(this.getCreateuserLessThanOrEqualTo());
		}
		if(CheckUtil.isNotEmpty(getCreateuserLessThan())){
			c.andCreateuserLessThan(this.getCreateuserLessThan());
		}
		if(CheckUtil.isNotEmpty(getCreateuserIsNull()) && this.getCreateuserIsNull()){
			c.andCreateuserIsNull();
		}
		if(CheckUtil.isNotEmpty(getCreateuserIsNotNull()) && this.getCreateuserIsNotNull()){
			c.andCreateuserIsNotNull();
		}
		if(CheckUtil.isNotEmpty(getCreateuserIn())){
			c.andCreateuserIn(this.getCreateuserIn());
		}
		if(CheckUtil.isNotEmpty(getCreateuserGreaterThanOrEqualTo())){
			c.andCreateuserGreaterThanOrEqualTo(this.getCreateuserGreaterThanOrEqualTo());
		}
		if(CheckUtil.isNotEmpty(getCreateuserGreaterThan())){
			c.andCreateuserGreaterThan(this.getCreateuserGreaterThan());
		}
		if(CheckUtil.isNotEmpty(getCreateuserEqualTo())){
			c.andCreateuserEqualTo(this.getCreateuserEqualTo());
		}
		if(CheckUtil.isNotEmpty(getCreatetimeNotIn())){
			c.andCreatetimeNotIn(this.getCreatetimeNotIn());
		}
		if(CheckUtil.isNotEmpty(getCreatetimeNotEqualTo())){
			c.andCreatetimeNotEqualTo(this.getCreatetimeNotEqualTo());
		}
		if(CheckUtil.isNotEmpty(getCreatetimeLessThanOrEqualTo())){
			c.andCreatetimeLessThanOrEqualTo(this.getCreatetimeLessThanOrEqualTo());
		}
		if(CheckUtil.isNotEmpty(getCreatetimeLessThan())){
			c.andCreatetimeLessThan(this.getCreatetimeLessThan());
		}
		if(CheckUtil.isNotEmpty(getCreatetimeIsNull()) && this.getCreatetimeIsNull()){
			c.andCreatetimeIsNull();
		}
		if(CheckUtil.isNotEmpty(getCreatetimeIsNotNull()) && this.getCreatetimeIsNotNull()){
			c.andCreatetimeIsNotNull();
		}
		if(CheckUtil.isNotEmpty(getCreatetimeIn())){
			c.andCreatetimeIn(this.getCreatetimeIn());
		}
		if(CheckUtil.isNotEmpty(getCreatetimeGreaterThanOrEqualTo())){
			c.andCreatetimeGreaterThanOrEqualTo(this.getCreatetimeGreaterThanOrEqualTo());
		}
		if(CheckUtil.isNotEmpty(getCreatetimeGreaterThan())){
			c.andCreatetimeGreaterThan(this.getCreatetimeGreaterThan());
		}
		if(CheckUtil.isNotEmpty(getCreatetimeEqualTo())){
			c.andCreatetimeEqualTo(this.getCreatetimeEqualTo());
		}
		if((this.getSidx()!=null && !this.getSidx().trim().equals("")) && this.getSord()!=null) {
			q.setOrderByClause(""+ this.getSidx()+" "+this.getSord());
		}
		return q;
	}
	public String getUpdateuserNotLike() {
		return updateuserNotLike;
	}
	public void setUpdateuserNotLike(String updateuserNotLike) {
		this.updateuserNotLike = updateuserNotLike;
	}

	public java.util.List getUpdateuserNotIn() {
		return updateuserNotIn;
	}
	public void setUpdateuserNotIn(java.util.List updateuserNotIn) {
		this.updateuserNotIn = updateuserNotIn;
	}

	public String getUpdateuserNotEqualTo() {
		return updateuserNotEqualTo;
	}
	public void setUpdateuserNotEqualTo(String updateuserNotEqualTo) {
		this.updateuserNotEqualTo = updateuserNotEqualTo;
	}

	public String getUpdateuserLike() {
		return updateuserLike;
	}
	public void setUpdateuserLike(String updateuserLike) {
		this.updateuserLike = updateuserLike;
	}

	public String getUpdateuserLessThanOrEqualTo() {
		return updateuserLessThanOrEqualTo;
	}
	public void setUpdateuserLessThanOrEqualTo(String updateuserLessThanOrEqualTo) {
		this.updateuserLessThanOrEqualTo = updateuserLessThanOrEqualTo;
	}

	public String getUpdateuserLessThan() {
		return updateuserLessThan;
	}
	public void setUpdateuserLessThan(String updateuserLessThan) {
		this.updateuserLessThan = updateuserLessThan;
	}

	public Boolean getUpdateuserIsNull() {
		return updateuserIsNull;
	}
	public void setUpdateuserIsNull(Boolean updateuserIsNull) {
		this.updateuserIsNull = updateuserIsNull;
	}

	public Boolean getUpdateuserIsNotNull() {
		return updateuserIsNotNull;
	}
	public void setUpdateuserIsNotNull(Boolean updateuserIsNotNull) {
		this.updateuserIsNotNull = updateuserIsNotNull;
	}

	public java.util.List getUpdateuserIn() {
		return updateuserIn;
	}
	public void setUpdateuserIn(java.util.List updateuserIn) {
		this.updateuserIn = updateuserIn;
	}

	public String getUpdateuserGreaterThanOrEqualTo() {
		return updateuserGreaterThanOrEqualTo;
	}
	public void setUpdateuserGreaterThanOrEqualTo(String updateuserGreaterThanOrEqualTo) {
		this.updateuserGreaterThanOrEqualTo = updateuserGreaterThanOrEqualTo;
	}

	public String getUpdateuserGreaterThan() {
		return updateuserGreaterThan;
	}
	public void setUpdateuserGreaterThan(String updateuserGreaterThan) {
		this.updateuserGreaterThan = updateuserGreaterThan;
	}

	public String getUpdateuserEqualTo() {
		return updateuserEqualTo;
	}
	public void setUpdateuserEqualTo(String updateuserEqualTo) {
		this.updateuserEqualTo = updateuserEqualTo;
	}

	public java.util.List getUpdatetimeNotIn() {
		return updatetimeNotIn;
	}
	public void setUpdatetimeNotIn(java.util.List updatetimeNotIn) {
		this.updatetimeNotIn = updatetimeNotIn;
	}

	public java.util.Date getUpdatetimeNotEqualTo() {
		return updatetimeNotEqualTo;
	}
	public void setUpdatetimeNotEqualTo(java.util.Date updatetimeNotEqualTo) {
		this.updatetimeNotEqualTo = updatetimeNotEqualTo;
	}

	public java.util.Date getUpdatetimeLessThanOrEqualTo() {
		return updatetimeLessThanOrEqualTo;
	}
	public void setUpdatetimeLessThanOrEqualTo(java.util.Date updatetimeLessThanOrEqualTo) {
		this.updatetimeLessThanOrEqualTo = updatetimeLessThanOrEqualTo;
	}

	public java.util.Date getUpdatetimeLessThan() {
		return updatetimeLessThan;
	}
	public void setUpdatetimeLessThan(java.util.Date updatetimeLessThan) {
		this.updatetimeLessThan = updatetimeLessThan;
	}

	public Boolean getUpdatetimeIsNull() {
		return updatetimeIsNull;
	}
	public void setUpdatetimeIsNull(Boolean updatetimeIsNull) {
		this.updatetimeIsNull = updatetimeIsNull;
	}

	public Boolean getUpdatetimeIsNotNull() {
		return updatetimeIsNotNull;
	}
	public void setUpdatetimeIsNotNull(Boolean updatetimeIsNotNull) {
		this.updatetimeIsNotNull = updatetimeIsNotNull;
	}

	public java.util.List getUpdatetimeIn() {
		return updatetimeIn;
	}
	public void setUpdatetimeIn(java.util.List updatetimeIn) {
		this.updatetimeIn = updatetimeIn;
	}

	public java.util.Date getUpdatetimeGreaterThanOrEqualTo() {
		return updatetimeGreaterThanOrEqualTo;
	}
	public void setUpdatetimeGreaterThanOrEqualTo(java.util.Date updatetimeGreaterThanOrEqualTo) {
		this.updatetimeGreaterThanOrEqualTo = updatetimeGreaterThanOrEqualTo;
	}

	public java.util.Date getUpdatetimeGreaterThan() {
		return updatetimeGreaterThan;
	}
	public void setUpdatetimeGreaterThan(java.util.Date updatetimeGreaterThan) {
		this.updatetimeGreaterThan = updatetimeGreaterThan;
	}

	public java.util.Date getUpdatetimeEqualTo() {
		return updatetimeEqualTo;
	}
	public void setUpdatetimeEqualTo(java.util.Date updatetimeEqualTo) {
		this.updatetimeEqualTo = updatetimeEqualTo;
	}

	public String getRemarkNotLike() {
		return remarkNotLike;
	}
	public void setRemarkNotLike(String remarkNotLike) {
		this.remarkNotLike = remarkNotLike;
	}

	public java.util.List getRemarkNotIn() {
		return remarkNotIn;
	}
	public void setRemarkNotIn(java.util.List remarkNotIn) {
		this.remarkNotIn = remarkNotIn;
	}

	public String getRemarkNotEqualTo() {
		return remarkNotEqualTo;
	}
	public void setRemarkNotEqualTo(String remarkNotEqualTo) {
		this.remarkNotEqualTo = remarkNotEqualTo;
	}

	public String getRemarkLike() {
		return remarkLike;
	}
	public void setRemarkLike(String remarkLike) {
		this.remarkLike = remarkLike;
	}

	public String getRemarkLessThanOrEqualTo() {
		return remarkLessThanOrEqualTo;
	}
	public void setRemarkLessThanOrEqualTo(String remarkLessThanOrEqualTo) {
		this.remarkLessThanOrEqualTo = remarkLessThanOrEqualTo;
	}

	public String getRemarkLessThan() {
		return remarkLessThan;
	}
	public void setRemarkLessThan(String remarkLessThan) {
		this.remarkLessThan = remarkLessThan;
	}

	public Boolean getRemarkIsNull() {
		return remarkIsNull;
	}
	public void setRemarkIsNull(Boolean remarkIsNull) {
		this.remarkIsNull = remarkIsNull;
	}

	public Boolean getRemarkIsNotNull() {
		return remarkIsNotNull;
	}
	public void setRemarkIsNotNull(Boolean remarkIsNotNull) {
		this.remarkIsNotNull = remarkIsNotNull;
	}

	public java.util.List getRemarkIn() {
		return remarkIn;
	}
	public void setRemarkIn(java.util.List remarkIn) {
		this.remarkIn = remarkIn;
	}

	public String getRemarkGreaterThanOrEqualTo() {
		return remarkGreaterThanOrEqualTo;
	}
	public void setRemarkGreaterThanOrEqualTo(String remarkGreaterThanOrEqualTo) {
		this.remarkGreaterThanOrEqualTo = remarkGreaterThanOrEqualTo;
	}

	public String getRemarkGreaterThan() {
		return remarkGreaterThan;
	}
	public void setRemarkGreaterThan(String remarkGreaterThan) {
		this.remarkGreaterThan = remarkGreaterThan;
	}

	public String getRemarkEqualTo() {
		return remarkEqualTo;
	}
	public void setRemarkEqualTo(String remarkEqualTo) {
		this.remarkEqualTo = remarkEqualTo;
	}

	public java.util.List getFbmrWaterTypeNotIn() {
		return fbmrWaterTypeNotIn;
	}
	public void setFbmrWaterTypeNotIn(java.util.List fbmrWaterTypeNotIn) {
		this.fbmrWaterTypeNotIn = fbmrWaterTypeNotIn;
	}

	public Integer getFbmrWaterTypeNotEqualTo() {
		return fbmrWaterTypeNotEqualTo;
	}
	public void setFbmrWaterTypeNotEqualTo(Integer fbmrWaterTypeNotEqualTo) {
		this.fbmrWaterTypeNotEqualTo = fbmrWaterTypeNotEqualTo;
	}

	public Integer getFbmrWaterTypeLessThanOrEqualTo() {
		return fbmrWaterTypeLessThanOrEqualTo;
	}
	public void setFbmrWaterTypeLessThanOrEqualTo(Integer fbmrWaterTypeLessThanOrEqualTo) {
		this.fbmrWaterTypeLessThanOrEqualTo = fbmrWaterTypeLessThanOrEqualTo;
	}

	public Integer getFbmrWaterTypeLessThan() {
		return fbmrWaterTypeLessThan;
	}
	public void setFbmrWaterTypeLessThan(Integer fbmrWaterTypeLessThan) {
		this.fbmrWaterTypeLessThan = fbmrWaterTypeLessThan;
	}

	public Boolean getFbmrWaterTypeIsNull() {
		return fbmrWaterTypeIsNull;
	}
	public void setFbmrWaterTypeIsNull(Boolean fbmrWaterTypeIsNull) {
		this.fbmrWaterTypeIsNull = fbmrWaterTypeIsNull;
	}

	public Boolean getFbmrWaterTypeIsNotNull() {
		return fbmrWaterTypeIsNotNull;
	}
	public void setFbmrWaterTypeIsNotNull(Boolean fbmrWaterTypeIsNotNull) {
		this.fbmrWaterTypeIsNotNull = fbmrWaterTypeIsNotNull;
	}

	public java.util.List getFbmrWaterTypeIn() {
		return fbmrWaterTypeIn;
	}
	public void setFbmrWaterTypeIn(java.util.List fbmrWaterTypeIn) {
		this.fbmrWaterTypeIn = fbmrWaterTypeIn;
	}

	public Integer getFbmrWaterTypeGreaterThanOrEqualTo() {
		return fbmrWaterTypeGreaterThanOrEqualTo;
	}
	public void setFbmrWaterTypeGreaterThanOrEqualTo(Integer fbmrWaterTypeGreaterThanOrEqualTo) {
		this.fbmrWaterTypeGreaterThanOrEqualTo = fbmrWaterTypeGreaterThanOrEqualTo;
	}

	public Integer getFbmrWaterTypeGreaterThan() {
		return fbmrWaterTypeGreaterThan;
	}
	public void setFbmrWaterTypeGreaterThan(Integer fbmrWaterTypeGreaterThan) {
		this.fbmrWaterTypeGreaterThan = fbmrWaterTypeGreaterThan;
	}

	public Integer getFbmrWaterTypeEqualTo() {
		return fbmrWaterTypeEqualTo;
	}
	public void setFbmrWaterTypeEqualTo(Integer fbmrWaterTypeEqualTo) {
		this.fbmrWaterTypeEqualTo = fbmrWaterTypeEqualTo;
	}

	public java.util.List getFbmrWaterIdNotIn() {
		return fbmrWaterIdNotIn;
	}
	public void setFbmrWaterIdNotIn(java.util.List fbmrWaterIdNotIn) {
		this.fbmrWaterIdNotIn = fbmrWaterIdNotIn;
	}

	public Long getFbmrWaterIdNotEqualTo() {
		return fbmrWaterIdNotEqualTo;
	}
	public void setFbmrWaterIdNotEqualTo(Long fbmrWaterIdNotEqualTo) {
		this.fbmrWaterIdNotEqualTo = fbmrWaterIdNotEqualTo;
	}

	public Long getFbmrWaterIdLessThanOrEqualTo() {
		return fbmrWaterIdLessThanOrEqualTo;
	}
	public void setFbmrWaterIdLessThanOrEqualTo(Long fbmrWaterIdLessThanOrEqualTo) {
		this.fbmrWaterIdLessThanOrEqualTo = fbmrWaterIdLessThanOrEqualTo;
	}

	public Long getFbmrWaterIdLessThan() {
		return fbmrWaterIdLessThan;
	}
	public void setFbmrWaterIdLessThan(Long fbmrWaterIdLessThan) {
		this.fbmrWaterIdLessThan = fbmrWaterIdLessThan;
	}

	public Boolean getFbmrWaterIdIsNull() {
		return fbmrWaterIdIsNull;
	}
	public void setFbmrWaterIdIsNull(Boolean fbmrWaterIdIsNull) {
		this.fbmrWaterIdIsNull = fbmrWaterIdIsNull;
	}

	public Boolean getFbmrWaterIdIsNotNull() {
		return fbmrWaterIdIsNotNull;
	}
	public void setFbmrWaterIdIsNotNull(Boolean fbmrWaterIdIsNotNull) {
		this.fbmrWaterIdIsNotNull = fbmrWaterIdIsNotNull;
	}

	public java.util.List getFbmrWaterIdIn() {
		return fbmrWaterIdIn;
	}
	public void setFbmrWaterIdIn(java.util.List fbmrWaterIdIn) {
		this.fbmrWaterIdIn = fbmrWaterIdIn;
	}

	public Long getFbmrWaterIdGreaterThanOrEqualTo() {
		return fbmrWaterIdGreaterThanOrEqualTo;
	}
	public void setFbmrWaterIdGreaterThanOrEqualTo(Long fbmrWaterIdGreaterThanOrEqualTo) {
		this.fbmrWaterIdGreaterThanOrEqualTo = fbmrWaterIdGreaterThanOrEqualTo;
	}

	public Long getFbmrWaterIdGreaterThan() {
		return fbmrWaterIdGreaterThan;
	}
	public void setFbmrWaterIdGreaterThan(Long fbmrWaterIdGreaterThan) {
		this.fbmrWaterIdGreaterThan = fbmrWaterIdGreaterThan;
	}

	public Long getFbmrWaterIdEqualTo() {
		return fbmrWaterIdEqualTo;
	}
	public void setFbmrWaterIdEqualTo(Long fbmrWaterIdEqualTo) {
		this.fbmrWaterIdEqualTo = fbmrWaterIdEqualTo;
	}

	public java.util.List getFbmrMatchMoneyNotIn() {
		return fbmrMatchMoneyNotIn;
	}
	public void setFbmrMatchMoneyNotIn(java.util.List fbmrMatchMoneyNotIn) {
		this.fbmrMatchMoneyNotIn = fbmrMatchMoneyNotIn;
	}

	public Double getFbmrMatchMoneyNotEqualTo() {
		return fbmrMatchMoneyNotEqualTo;
	}
	public void setFbmrMatchMoneyNotEqualTo(Double fbmrMatchMoneyNotEqualTo) {
		this.fbmrMatchMoneyNotEqualTo = fbmrMatchMoneyNotEqualTo;
	}

	public Double getFbmrMatchMoneyLessThanOrEqualTo() {
		return fbmrMatchMoneyLessThanOrEqualTo;
	}
	public void setFbmrMatchMoneyLessThanOrEqualTo(Double fbmrMatchMoneyLessThanOrEqualTo) {
		this.fbmrMatchMoneyLessThanOrEqualTo = fbmrMatchMoneyLessThanOrEqualTo;
	}

	public Double getFbmrMatchMoneyLessThan() {
		return fbmrMatchMoneyLessThan;
	}
	public void setFbmrMatchMoneyLessThan(Double fbmrMatchMoneyLessThan) {
		this.fbmrMatchMoneyLessThan = fbmrMatchMoneyLessThan;
	}

	public Boolean getFbmrMatchMoneyIsNull() {
		return fbmrMatchMoneyIsNull;
	}
	public void setFbmrMatchMoneyIsNull(Boolean fbmrMatchMoneyIsNull) {
		this.fbmrMatchMoneyIsNull = fbmrMatchMoneyIsNull;
	}

	public Boolean getFbmrMatchMoneyIsNotNull() {
		return fbmrMatchMoneyIsNotNull;
	}
	public void setFbmrMatchMoneyIsNotNull(Boolean fbmrMatchMoneyIsNotNull) {
		this.fbmrMatchMoneyIsNotNull = fbmrMatchMoneyIsNotNull;
	}

	public java.util.List getFbmrMatchMoneyIn() {
		return fbmrMatchMoneyIn;
	}
	public void setFbmrMatchMoneyIn(java.util.List fbmrMatchMoneyIn) {
		this.fbmrMatchMoneyIn = fbmrMatchMoneyIn;
	}

	public Double getFbmrMatchMoneyGreaterThanOrEqualTo() {
		return fbmrMatchMoneyGreaterThanOrEqualTo;
	}
	public void setFbmrMatchMoneyGreaterThanOrEqualTo(Double fbmrMatchMoneyGreaterThanOrEqualTo) {
		this.fbmrMatchMoneyGreaterThanOrEqualTo = fbmrMatchMoneyGreaterThanOrEqualTo;
	}

	public Double getFbmrMatchMoneyGreaterThan() {
		return fbmrMatchMoneyGreaterThan;
	}
	public void setFbmrMatchMoneyGreaterThan(Double fbmrMatchMoneyGreaterThan) {
		this.fbmrMatchMoneyGreaterThan = fbmrMatchMoneyGreaterThan;
	}

	public Double getFbmrMatchMoneyEqualTo() {
		return fbmrMatchMoneyEqualTo;
	}
	public void setFbmrMatchMoneyEqualTo(Double fbmrMatchMoneyEqualTo) {
		this.fbmrMatchMoneyEqualTo = fbmrMatchMoneyEqualTo;
	}

	public java.util.List getFbmrIdNotIn() {
		return fbmrIdNotIn;
	}
	public void setFbmrIdNotIn(java.util.List fbmrIdNotIn) {
		this.fbmrIdNotIn = fbmrIdNotIn;
	}

	public Long getFbmrIdNotEqualTo() {
		return fbmrIdNotEqualTo;
	}
	public void setFbmrIdNotEqualTo(Long fbmrIdNotEqualTo) {
		this.fbmrIdNotEqualTo = fbmrIdNotEqualTo;
	}

	public Long getFbmrIdLessThanOrEqualTo() {
		return fbmrIdLessThanOrEqualTo;
	}
	public void setFbmrIdLessThanOrEqualTo(Long fbmrIdLessThanOrEqualTo) {
		this.fbmrIdLessThanOrEqualTo = fbmrIdLessThanOrEqualTo;
	}

	public Long getFbmrIdLessThan() {
		return fbmrIdLessThan;
	}
	public void setFbmrIdLessThan(Long fbmrIdLessThan) {
		this.fbmrIdLessThan = fbmrIdLessThan;
	}

	public Boolean getFbmrIdIsNull() {
		return fbmrIdIsNull;
	}
	public void setFbmrIdIsNull(Boolean fbmrIdIsNull) {
		this.fbmrIdIsNull = fbmrIdIsNull;
	}

	public Boolean getFbmrIdIsNotNull() {
		return fbmrIdIsNotNull;
	}
	public void setFbmrIdIsNotNull(Boolean fbmrIdIsNotNull) {
		this.fbmrIdIsNotNull = fbmrIdIsNotNull;
	}

	public java.util.List getFbmrIdIn() {
		return fbmrIdIn;
	}
	public void setFbmrIdIn(java.util.List fbmrIdIn) {
		this.fbmrIdIn = fbmrIdIn;
	}

	public Long getFbmrIdGreaterThanOrEqualTo() {
		return fbmrIdGreaterThanOrEqualTo;
	}
	public void setFbmrIdGreaterThanOrEqualTo(Long fbmrIdGreaterThanOrEqualTo) {
		this.fbmrIdGreaterThanOrEqualTo = fbmrIdGreaterThanOrEqualTo;
	}

	public Long getFbmrIdGreaterThan() {
		return fbmrIdGreaterThan;
	}
	public void setFbmrIdGreaterThan(Long fbmrIdGreaterThan) {
		this.fbmrIdGreaterThan = fbmrIdGreaterThan;
	}

	public Long getFbmrIdEqualTo() {
		return fbmrIdEqualTo;
	}
	public void setFbmrIdEqualTo(Long fbmrIdEqualTo) {
		this.fbmrIdEqualTo = fbmrIdEqualTo;
	}

	public java.util.List getFbmrBillIdNotIn() {
		return fbmrBillIdNotIn;
	}
	public void setFbmrBillIdNotIn(java.util.List fbmrBillIdNotIn) {
		this.fbmrBillIdNotIn = fbmrBillIdNotIn;
	}

	public Long getFbmrBillIdNotEqualTo() {
		return fbmrBillIdNotEqualTo;
	}
	public void setFbmrBillIdNotEqualTo(Long fbmrBillIdNotEqualTo) {
		this.fbmrBillIdNotEqualTo = fbmrBillIdNotEqualTo;
	}

	public Long getFbmrBillIdLessThanOrEqualTo() {
		return fbmrBillIdLessThanOrEqualTo;
	}
	public void setFbmrBillIdLessThanOrEqualTo(Long fbmrBillIdLessThanOrEqualTo) {
		this.fbmrBillIdLessThanOrEqualTo = fbmrBillIdLessThanOrEqualTo;
	}

	public Long getFbmrBillIdLessThan() {
		return fbmrBillIdLessThan;
	}
	public void setFbmrBillIdLessThan(Long fbmrBillIdLessThan) {
		this.fbmrBillIdLessThan = fbmrBillIdLessThan;
	}

	public Boolean getFbmrBillIdIsNull() {
		return fbmrBillIdIsNull;
	}
	public void setFbmrBillIdIsNull(Boolean fbmrBillIdIsNull) {
		this.fbmrBillIdIsNull = fbmrBillIdIsNull;
	}

	public Boolean getFbmrBillIdIsNotNull() {
		return fbmrBillIdIsNotNull;
	}
	public void setFbmrBillIdIsNotNull(Boolean fbmrBillIdIsNotNull) {
		this.fbmrBillIdIsNotNull = fbmrBillIdIsNotNull;
	}

	public java.util.List getFbmrBillIdIn() {
		return fbmrBillIdIn;
	}
	public void setFbmrBillIdIn(java.util.List fbmrBillIdIn) {
		this.fbmrBillIdIn = fbmrBillIdIn;
	}

	public Long getFbmrBillIdGreaterThanOrEqualTo() {
		return fbmrBillIdGreaterThanOrEqualTo;
	}
	public void setFbmrBillIdGreaterThanOrEqualTo(Long fbmrBillIdGreaterThanOrEqualTo) {
		this.fbmrBillIdGreaterThanOrEqualTo = fbmrBillIdGreaterThanOrEqualTo;
	}

	public Long getFbmrBillIdGreaterThan() {
		return fbmrBillIdGreaterThan;
	}
	public void setFbmrBillIdGreaterThan(Long fbmrBillIdGreaterThan) {
		this.fbmrBillIdGreaterThan = fbmrBillIdGreaterThan;
	}

	public Long getFbmrBillIdEqualTo() {
		return fbmrBillIdEqualTo;
	}
	public void setFbmrBillIdEqualTo(Long fbmrBillIdEqualTo) {
		this.fbmrBillIdEqualTo = fbmrBillIdEqualTo;
	}

	public java.util.List getDrNotIn() {
		return drNotIn;
	}
	public void setDrNotIn(java.util.List drNotIn) {
		this.drNotIn = drNotIn;
	}

	public Integer getDrNotEqualTo() {
		return drNotEqualTo;
	}
	public void setDrNotEqualTo(Integer drNotEqualTo) {
		this.drNotEqualTo = drNotEqualTo;
	}

	public Integer getDrLessThanOrEqualTo() {
		return drLessThanOrEqualTo;
	}
	public void setDrLessThanOrEqualTo(Integer drLessThanOrEqualTo) {
		this.drLessThanOrEqualTo = drLessThanOrEqualTo;
	}

	public Integer getDrLessThan() {
		return drLessThan;
	}
	public void setDrLessThan(Integer drLessThan) {
		this.drLessThan = drLessThan;
	}

	public Boolean getDrIsNull() {
		return drIsNull;
	}
	public void setDrIsNull(Boolean drIsNull) {
		this.drIsNull = drIsNull;
	}

	public Boolean getDrIsNotNull() {
		return drIsNotNull;
	}
	public void setDrIsNotNull(Boolean drIsNotNull) {
		this.drIsNotNull = drIsNotNull;
	}

	public java.util.List getDrIn() {
		return drIn;
	}
	public void setDrIn(java.util.List drIn) {
		this.drIn = drIn;
	}

	public Integer getDrGreaterThanOrEqualTo() {
		return drGreaterThanOrEqualTo;
	}
	public void setDrGreaterThanOrEqualTo(Integer drGreaterThanOrEqualTo) {
		this.drGreaterThanOrEqualTo = drGreaterThanOrEqualTo;
	}

	public Integer getDrGreaterThan() {
		return drGreaterThan;
	}
	public void setDrGreaterThan(Integer drGreaterThan) {
		this.drGreaterThan = drGreaterThan;
	}

	public Integer getDrEqualTo() {
		return drEqualTo;
	}
	public void setDrEqualTo(Integer drEqualTo) {
		this.drEqualTo = drEqualTo;
	}

	public String getCreateuserNotLike() {
		return createuserNotLike;
	}
	public void setCreateuserNotLike(String createuserNotLike) {
		this.createuserNotLike = createuserNotLike;
	}

	public java.util.List getCreateuserNotIn() {
		return createuserNotIn;
	}
	public void setCreateuserNotIn(java.util.List createuserNotIn) {
		this.createuserNotIn = createuserNotIn;
	}

	public String getCreateuserNotEqualTo() {
		return createuserNotEqualTo;
	}
	public void setCreateuserNotEqualTo(String createuserNotEqualTo) {
		this.createuserNotEqualTo = createuserNotEqualTo;
	}

	public String getCreateuserLike() {
		return createuserLike;
	}
	public void setCreateuserLike(String createuserLike) {
		this.createuserLike = createuserLike;
	}

	public String getCreateuserLessThanOrEqualTo() {
		return createuserLessThanOrEqualTo;
	}
	public void setCreateuserLessThanOrEqualTo(String createuserLessThanOrEqualTo) {
		this.createuserLessThanOrEqualTo = createuserLessThanOrEqualTo;
	}

	public String getCreateuserLessThan() {
		return createuserLessThan;
	}
	public void setCreateuserLessThan(String createuserLessThan) {
		this.createuserLessThan = createuserLessThan;
	}

	public Boolean getCreateuserIsNull() {
		return createuserIsNull;
	}
	public void setCreateuserIsNull(Boolean createuserIsNull) {
		this.createuserIsNull = createuserIsNull;
	}

	public Boolean getCreateuserIsNotNull() {
		return createuserIsNotNull;
	}
	public void setCreateuserIsNotNull(Boolean createuserIsNotNull) {
		this.createuserIsNotNull = createuserIsNotNull;
	}

	public java.util.List getCreateuserIn() {
		return createuserIn;
	}
	public void setCreateuserIn(java.util.List createuserIn) {
		this.createuserIn = createuserIn;
	}

	public String getCreateuserGreaterThanOrEqualTo() {
		return createuserGreaterThanOrEqualTo;
	}
	public void setCreateuserGreaterThanOrEqualTo(String createuserGreaterThanOrEqualTo) {
		this.createuserGreaterThanOrEqualTo = createuserGreaterThanOrEqualTo;
	}

	public String getCreateuserGreaterThan() {
		return createuserGreaterThan;
	}
	public void setCreateuserGreaterThan(String createuserGreaterThan) {
		this.createuserGreaterThan = createuserGreaterThan;
	}

	public String getCreateuserEqualTo() {
		return createuserEqualTo;
	}
	public void setCreateuserEqualTo(String createuserEqualTo) {
		this.createuserEqualTo = createuserEqualTo;
	}

	public java.util.List getCreatetimeNotIn() {
		return createtimeNotIn;
	}
	public void setCreatetimeNotIn(java.util.List createtimeNotIn) {
		this.createtimeNotIn = createtimeNotIn;
	}

	public java.util.Date getCreatetimeNotEqualTo() {
		return createtimeNotEqualTo;
	}
	public void setCreatetimeNotEqualTo(java.util.Date createtimeNotEqualTo) {
		this.createtimeNotEqualTo = createtimeNotEqualTo;
	}

	public java.util.Date getCreatetimeLessThanOrEqualTo() {
		return createtimeLessThanOrEqualTo;
	}
	public void setCreatetimeLessThanOrEqualTo(java.util.Date createtimeLessThanOrEqualTo) {
		this.createtimeLessThanOrEqualTo = createtimeLessThanOrEqualTo;
	}

	public java.util.Date getCreatetimeLessThan() {
		return createtimeLessThan;
	}
	public void setCreatetimeLessThan(java.util.Date createtimeLessThan) {
		this.createtimeLessThan = createtimeLessThan;
	}

	public Boolean getCreatetimeIsNull() {
		return createtimeIsNull;
	}
	public void setCreatetimeIsNull(Boolean createtimeIsNull) {
		this.createtimeIsNull = createtimeIsNull;
	}

	public Boolean getCreatetimeIsNotNull() {
		return createtimeIsNotNull;
	}
	public void setCreatetimeIsNotNull(Boolean createtimeIsNotNull) {
		this.createtimeIsNotNull = createtimeIsNotNull;
	}

	public java.util.List getCreatetimeIn() {
		return createtimeIn;
	}
	public void setCreatetimeIn(java.util.List createtimeIn) {
		this.createtimeIn = createtimeIn;
	}

	public java.util.Date getCreatetimeGreaterThanOrEqualTo() {
		return createtimeGreaterThanOrEqualTo;
	}
	public void setCreatetimeGreaterThanOrEqualTo(java.util.Date createtimeGreaterThanOrEqualTo) {
		this.createtimeGreaterThanOrEqualTo = createtimeGreaterThanOrEqualTo;
	}

	public java.util.Date getCreatetimeGreaterThan() {
		return createtimeGreaterThan;
	}
	public void setCreatetimeGreaterThan(java.util.Date createtimeGreaterThan) {
		this.createtimeGreaterThan = createtimeGreaterThan;
	}

	public java.util.Date getCreatetimeEqualTo() {
		return createtimeEqualTo;
	}
	public void setCreatetimeEqualTo(java.util.Date createtimeEqualTo) {
		this.createtimeEqualTo = createtimeEqualTo;
	}

	public void setSidx(String sidx) {
		this.sidx = sidx;
	}
	public String getSord() {
		return sord;
	}
	public void setSord(String sord) {
		 this.sord = sord;
	}
}
