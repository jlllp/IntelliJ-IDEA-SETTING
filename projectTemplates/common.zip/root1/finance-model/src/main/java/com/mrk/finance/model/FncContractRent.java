package com.mrk.finance.model;

import com.mrk.common.base.BaseEntity;
import io.swagger.annotations.ApiModelProperty;
import lombok.Getter;
import lombok.Setter;

import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import java.io.Serializable;

@Setter
@Getter
public class FncContractRent extends BaseEntity implements Serializable {
private static final long serialVersionUID=1L;


    /**id */
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @ApiModelProperty(value = "id")
    private Long fccId;

    /**合同id */
    @ApiModelProperty(value = "合同id")
    private Long fccContractId;

    /**开始月份 */
    @ApiModelProperty(value = "开始月份")
    private Integer fccStartMonth;

    /**结束月份 */
    @ApiModelProperty(value = "结束月份")
    private Integer fccEndMonth;

    /**租金金额 */
    @ApiModelProperty(value = "租金金额")
    private Double fccRentAmount;
    }
