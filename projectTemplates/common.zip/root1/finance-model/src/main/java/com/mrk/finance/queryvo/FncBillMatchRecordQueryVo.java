package com.mrk.finance.queryvo;

import com.mrk.common.base.BaseQueryVo;
import io.swagger.annotations.ApiModelProperty;
import lombok.Getter;
import lombok.Setter;

@Setter
@Getter
public class FncBillMatchRecordQueryVo extends BaseQueryVo {


    @ApiModelProperty(value = "主键 精确匹配")
    private Long fbmrIdEqualTo;

    @ApiModelProperty(value = "主键 模糊匹配")
    private Long fbmrIdLike;


    @ApiModelProperty(value = "账单id 精确匹配")
    private Long fbmrBillIdEqualTo;

    @ApiModelProperty(value = "账单id 模糊匹配")
    private Long fbmrBillIdLike;


    @ApiModelProperty(value = "匹配金额 精确匹配")
    private Double fbmrMatchMoneyEqualTo;

    @ApiModelProperty(value = "匹配金额 模糊匹配")
    private Double fbmrMatchMoneyLike;


    @ApiModelProperty(value = "流水id 精确匹配")
    private Long fbmrWaterIdEqualTo;

    @ApiModelProperty(value = "流水id 模糊匹配")
    private Long fbmrWaterIdLike;


    @ApiModelProperty(value = "流水类型 0无 1银行流水 2T3 3滴滴 精确匹配")
    private Integer fbmrWaterTypeEqualTo;

    @ApiModelProperty(value = "流水类型 0无 1银行流水 2T3 3滴滴 模糊匹配")
    private Integer fbmrWaterTypeLike;
}
