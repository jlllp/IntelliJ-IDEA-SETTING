package com.mrk.finance.queryvo;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.mrk.common.base.BaseQueryVo;
import io.swagger.annotations.ApiModelProperty;
import lombok.Getter;
import lombok.Setter;
import org.springframework.format.annotation.DateTimeFormat;

@Setter
@Getter
public class FncTempQueryVo extends BaseQueryVo {



    @ApiModelProperty(value = "主键 精确匹配")
    private Long fncIdEqualTo;

    @ApiModelProperty(value = "主键 模糊匹配")
    private Long fncIdLike;


    @ApiModelProperty(value = "城市 精确匹配")
    private String fncCityEqualTo;

    @ApiModelProperty(value = "城市 模糊匹配")
    private String fncCityLike;


    @ApiModelProperty(value = "司机id 精确匹配")
    private Long fncMemberIdEqualTo;

    @ApiModelProperty(value = "司机id 模糊匹配")
    private Long fncMemberIdLike;


    @ApiModelProperty(value = "姓名 精确匹配")
    private String fncNameEqualTo;

    @ApiModelProperty(value = "姓名 模糊匹配")
    private String fncNameLike;


    @ApiModelProperty(value = "身份证号 精确匹配")
    private String fncIdnumberEqualTo;

    @ApiModelProperty(value = "身份证号 模糊匹配")
    private String fncIdnumberLike;


    @ApiModelProperty(value = "车架号 精确匹配")
    private String fncCarVinEqualTo;

    @ApiModelProperty(value = "车架号 模糊匹配")
    private String fncCarVinLike;


    @ApiModelProperty(value = "协议编号 精确匹配")
    private String fncAgreementNumberEqualTo;

    @ApiModelProperty(value = "协议编号 模糊匹配")
    private String fncAgreementNumberLike;


    @ApiModelProperty(value = "起租日期 大于或等于")
    @DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss", timezone = "GMT+8")
    private java.util.Date fncRentDateGreaterThanOrEqualTo;

    @DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss", timezone = "GMT+8")
    @ApiModelProperty(value = "起租日期 小于或等于")
    private java.util.Date fncRentDateLessThanOrEqualTo;
    @ApiModelProperty(value = "起租日期 精确匹配")
    private java.util.Date fncRentDateEqualTo;

    @ApiModelProperty(value = "起租日期 模糊匹配")
    private java.util.Date fncRentDateLike;


    @ApiModelProperty(value = "租期 精确匹配")
    private Integer fncLeaseCountEqualTo;

    @ApiModelProperty(value = "租期 模糊匹配")
    private Integer fncLeaseCountLike;


    @ApiModelProperty(value = "代扣月份 大于或等于")
    @DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss", timezone = "GMT+8")
    private java.util.Date fncMonthGreaterThanOrEqualTo;

    @DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss", timezone = "GMT+8")
    @ApiModelProperty(value = "代扣月份 小于或等于")
    private java.util.Date fncMonthLessThanOrEqualTo;
    @ApiModelProperty(value = "代扣月份 精确匹配")
    private java.util.Date fncMonthEqualTo;

    @ApiModelProperty(value = "代扣月份 模糊匹配")
    private java.util.Date fncMonthLike;


    @ApiModelProperty(value = "月租金 精确匹配")
    private Double fncMonthRentEqualTo;

    @ApiModelProperty(value = "月租金 模糊匹配")
    private Double fncMonthRentLike;

    @ApiModelProperty(value = "月租金 小于或等于")
    private Double fncMonthRentLessThanOrEqualTo;

    @ApiModelProperty(value = "月租金 大于或等于")
    private Double fncMonthRentGreaterThanOrEqualTo;


    @ApiModelProperty(value = "月扣款总额 精确匹配")
    private Double fncMonthWithholdEqualTo;

    @ApiModelProperty(value = "月扣款总额 模糊匹配")
    private Double fncMonthWithholdLike;


    @ApiModelProperty(value = "月扣款总额 小于或等于")
    private Double fncMonthWithholdLessThanOrEqualTo;

    @ApiModelProperty(value = "月扣款总额 大于或等于")
    private Double fncMonthWithholdGreaterThanOrEqualTo;


    @ApiModelProperty(value = "错误信息 精确匹配")
    private String fncErrorMsgEqualTo;

    @ApiModelProperty(value = "错误信息 模糊匹配")
    private String fncErrorMsgLike;


    @ApiModelProperty(value = "是否错误（0否，1是） 精确匹配")
    private Integer fncErrorEqualTo;

    @ApiModelProperty(value = "是否错误（0否，1是） 模糊匹配")
    private Integer fncErrorLike;


    @ApiModelProperty(value = "账单号（滴滴） 精确匹配")
    private String fncAccountNoEqualTo;

    @ApiModelProperty(value = "账单号（滴滴） 模糊匹配")
    private String fncAccountNoLike;


    @ApiModelProperty(value = "操作标识 精确匹配")
    private String fncOperateCodeEqualTo;

    @ApiModelProperty(value = "操作标识 模糊匹配")
    private String fncOperateCodeLike;


    @ApiModelProperty(value = "交易时间 大于或等于")
    @DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss", timezone = "GMT+8")
    private java.util.Date fncTradeTimeGreaterThanOrEqualTo;

    @DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss", timezone = "GMT+8")
    @ApiModelProperty(value = "交易时间 小于或等于")
    private java.util.Date fncTradeTimeLessThanOrEqualTo;
    @ApiModelProperty(value = "交易时间 精确匹配")
    private java.util.Date fncTradeTimeEqualTo;

    @ApiModelProperty(value = "交易时间 模糊匹配")
    private java.util.Date fncTradeTimeLike;


    @ApiModelProperty(value = "交易金额 精确匹配")
    private Double fncTradeAmountEqualTo;

    @ApiModelProperty(value = "交易金额 模糊匹配")
    private Double fncTradeAmountLike;
    @ApiModelProperty(value = "交易金额 小于或等于")
    private Double fncTradeAmountLessThanOrEqualTo;
    @ApiModelProperty(value = "交易金额 大于或等于")
    private Double fncTradeAmountGreaterThanOrEqualTo;


    @ApiModelProperty(value = "交易账目 精确匹配")
    private String fncTradeNamesEqualTo;

    @ApiModelProperty(value = "交易账目 模糊匹配")
    private String fncTradeNamesLike;


    @ApiModelProperty(value = "交易流水号 精确匹配")
    private String fncAccountDealFlowEqualTo;

    @ApiModelProperty(value = "交易流水号 模糊匹配")
    private String fncAccountDealFlowLike;


    @ApiModelProperty(value = "交易方 精确匹配")
    private String fncTradePartyEqualTo;

    @ApiModelProperty(value = "交易方 模糊匹配")
    private String fncTradePartyLike;


    @ApiModelProperty(value = "订单号 精确匹配")
    private String fncOrderNoEqualTo;

    @ApiModelProperty(value = "订单号 模糊匹配")
    private String fncOrderNoLike;


    @ApiModelProperty(value = "银行流水-凭证号 精确匹配")
    private String fncVoucherNoEqualTo;

    @ApiModelProperty(value = "银行流水-凭证号 模糊匹配")
    private String fncVoucherNoLike;


    @ApiModelProperty(value = "银行流水-本方账号 精确匹配")
    private String  fncOwnAccountEqualTo;

    @ApiModelProperty(value = "银行流水-本方账号 模糊匹配")
    private String  fncOwnAccountLike;


    @ApiModelProperty(value = "月租金余量 精确匹配")
    private Double fncMonthRentBalanceEqualTo;

    @ApiModelProperty(value = "月租金余量 模糊匹配")
    private Double fncMonthRentBalanceLike;
    @ApiModelProperty(value = "月租金余量 小于或等于")
    private Double fncMonthRentBalanceLessThanOrEqualTo;
    @ApiModelProperty(value = "月租金余量  大于或等于")
    private Double fncMonthRentBalanceGreaterThanOrEqualTo;


    @ApiModelProperty(value = "银行流水-摘要 精确匹配")
    private String fncDigestEqualTo;

    @ApiModelProperty(value = "银行流水-摘要 模糊匹配")
    private String fncDigestLike;


    @ApiModelProperty(value = "银行流水-对方账号 精确匹配")
    private String fncOtherAccountEqualTo;

    @ApiModelProperty(value = "银行流水-对方账号 模糊匹配")
    private String fncOtherAccountLike;


    @ApiModelProperty(value = "对方单位名称 精确匹配")
    private String fncOtherUnitNameEqualTo;

    @ApiModelProperty(value = "对方单位名称 模糊匹配")
    private String fncOtherUnitNameLike;


    @ApiModelProperty(value = "银行流水-借/贷 精确匹配")
    private String fncLoanTypeEqualTo;

    @ApiModelProperty(value = "银行流水-借/贷 模糊匹配")
    private String fncLoanTypeLike;



    @ApiModelProperty(value = "银行流水-交易时间 大于或等于")
    @DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss", timezone = "GMT+8")
    private java.util.Date fncDealTimeGreaterThanOrEqualTo;

    @DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss", timezone = "GMT+8")
    @ApiModelProperty(value = "银行流水-交易时间 小于或等于")
    private java.util.Date fncDealTimeLessThanOrEqualTo;
    @ApiModelProperty(value = "银行流水-交易时间 精确匹配")
    private java.util.Date fncDealTimeEqualTo;

    @ApiModelProperty(value = "银行流水-交易时间 模糊匹配")
    private java.util.Date fncDealTimeLike;


    @ApiModelProperty(value = "银行流水-借方发生额度 精确匹配")
    private Double fncBorrowAmountEqualTo;

    @ApiModelProperty(value = "银行流水-借方发生额度 模糊匹配")
    private Double fncBorrowAmountLike;


    @ApiModelProperty(value = "银行流水-贷方发生额度 精确匹配")
    private Double fncCreditAmountEqualTo;

    @ApiModelProperty(value = "银行流水-贷方发生额度 模糊匹配")
    private Double fncCreditAmountLike;


    @ApiModelProperty(value = "银行流水-用途 精确匹配")
    private String fncUseEqualTo;

    @ApiModelProperty(value = "银行流水-用途 模糊匹配")
    private String fncUseLike;


    @ApiModelProperty(value = "创建人 精确匹配")
    private String fncCreateuserEqualTo;

    @ApiModelProperty(value = "创建人 模糊匹配")
    private String fncCreateuserLike;


    @ApiModelProperty(value = "创建时间 大于或等于")
    @DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss", timezone = "GMT+8")
    private java.util.Date fncCreatetimeGreaterThanOrEqualTo;

    @DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss", timezone = "GMT+8")
    @ApiModelProperty(value = "创建时间 小于或等于")
    private java.util.Date fncCreatetimeLessThanOrEqualTo;
    @ApiModelProperty(value = "创建时间 精确匹配")
    private java.util.Date fncCreatetimeEqualTo;

    @ApiModelProperty(value = "创建时间 模糊匹配")
    private java.util.Date fncCreatetimeLike;


    @ApiModelProperty(value = "更新人 精确匹配")
    private String fncUpdateuserEqualTo;

    @ApiModelProperty(value = "更新人 模糊匹配")
    private String fncUpdateuserLike;


    @ApiModelProperty(value = "更新时间 大于或等于")
    @DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss", timezone = "GMT+8")
    private java.util.Date fncUpdatetimeGreaterThanOrEqualTo;

    @DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss", timezone = "GMT+8")
    @ApiModelProperty(value = "更新时间 小于或等于")
    private java.util.Date fncUpdatetimeLessThanOrEqualTo;
    @ApiModelProperty(value = "更新时间 精确匹配")
    private java.util.Date fncUpdatetimeEqualTo;

    @ApiModelProperty(value = "更新时间 模糊匹配")
    private java.util.Date fncUpdatetimeLike;


    @ApiModelProperty(value = "备注 精确匹配")
    private String fncRemarkEqualTo;

    @ApiModelProperty(value = "备注 模糊匹配")
    private String fncRemarkLike;
    }
