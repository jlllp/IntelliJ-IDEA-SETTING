package com.mrk.finance.model;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.mrk.common.base.BaseEntity;
import io.swagger.annotations.ApiModelProperty;
import lombok.Getter;
import lombok.Setter;
import org.springframework.format.annotation.DateTimeFormat;

import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import java.io.Serializable;

@Setter
@Getter
public class FncConfirmIncome extends BaseEntity implements Serializable {
private static final long serialVersionUID=1L;


    /**主键 */
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @ApiModelProperty(value = "主键")
    private Long fciId;

    /**资产所有者 */
    @ApiModelProperty(value = "资产所有者")
    private Long fciDeptId;

    /**收入时间 */
    @DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss", timezone = "GMT+8")
    @ApiModelProperty(value = "收入时间")
    private java.util.Date fciIncomeMonth;

    /**租金收入 */
    @ApiModelProperty(value = "租金收入")
    private Double fciRentIncome;

    /**违约金收入 */
    @ApiModelProperty(value = "违约金收入")
    private Double fciPenaltyIncome;

    /**购车尾款收入 */
    @ApiModelProperty(value = "购车尾款收入")
    private Double fciCarPurchaseIncome;

    /**合计收入 */
    @ApiModelProperty(value = "合计收入")
    private Double fciTotalIncome;
    }
