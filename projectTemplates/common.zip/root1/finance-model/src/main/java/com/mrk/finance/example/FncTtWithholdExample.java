package com.mrk.finance.example;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

public class FncTtWithholdExample {
    protected String orderByClause;

    protected boolean distinct;

    protected List<Criteria> oredCriteria;

    public FncTtWithholdExample() {
        oredCriteria = new ArrayList<Criteria>();
    }

    public void setOrderByClause(String orderByClause) {
        this.orderByClause = orderByClause;
    }

    public String getOrderByClause() {
        return orderByClause;
    }

    public void setDistinct(boolean distinct) {
        this.distinct = distinct;
    }

    public boolean isDistinct() {
        return distinct;
    }

    public List<Criteria> getOredCriteria() {
        return oredCriteria;
    }

    public void or(Criteria criteria) {
        oredCriteria.add(criteria);
    }

    public Criteria or() {
        Criteria criteria = createCriteriaInternal();
        oredCriteria.add(criteria);
        return criteria;
    }

    public Criteria createCriteria() {
        Criteria criteria = createCriteriaInternal();
        if (oredCriteria.size() == 0) {
            oredCriteria.add(criteria);
        }
        return criteria;
    }

    protected Criteria createCriteriaInternal() {
        Criteria criteria = new Criteria();
        return criteria;
    }

    public void clear() {
        oredCriteria.clear();
        orderByClause = null;
        distinct = false;
    }

    protected abstract static class GeneratedCriteria {
        protected List<Criterion> criteria;

        protected GeneratedCriteria() {
            super();
            criteria = new ArrayList<Criterion>();
        }

        public boolean isValid() {
            return criteria.size() > 0;
        }

        public List<Criterion> getAllCriteria() {
            return criteria;
        }

        public List<Criterion> getCriteria() {
            return criteria;
        }

        protected void addCriterion(String condition) {
            if (condition == null) {
                throw new RuntimeException("Value for condition cannot be null");
            }
            criteria.add(new Criterion(condition));
        }

        protected void addCriterion(String condition, Object value, String property) {
            if (value == null) {
                throw new RuntimeException("Value for " + property + " cannot be null");
            }
            criteria.add(new Criterion(condition, value));
        }

        protected void addCriterion(String condition, Object value1, Object value2, String property) {
            if (value1 == null || value2 == null) {
                throw new RuntimeException("Between values for " + property + " cannot be null");
            }
            criteria.add(new Criterion(condition, value1, value2));
        }

        public Criteria andFtwIdIsNull() {
            addCriterion("ftw_id is null");
            return (Criteria) this;
        }

        public Criteria andFtwIdIsNotNull() {
            addCriterion("ftw_id is not null");
            return (Criteria) this;
        }

        public Criteria andFtwIdEqualTo(Long value) {
            addCriterion("ftw_id =", value, "ftwId");
            return (Criteria) this;
        }

        public Criteria andFtwIdNotEqualTo(Long value) {
            addCriterion("ftw_id <>", value, "ftwId");
            return (Criteria) this;
        }

        public Criteria andFtwIdGreaterThan(Long value) {
            addCriterion("ftw_id >", value, "ftwId");
            return (Criteria) this;
        }

        public Criteria andFtwIdGreaterThanOrEqualTo(Long value) {
            addCriterion("ftw_id >=", value, "ftwId");
            return (Criteria) this;
        }

        public Criteria andFtwIdLessThan(Long value) {
            addCriterion("ftw_id <", value, "ftwId");
            return (Criteria) this;
        }

        public Criteria andFtwIdLessThanOrEqualTo(Long value) {
            addCriterion("ftw_id <=", value, "ftwId");
            return (Criteria) this;
        }

        public Criteria andFtwIdIn(List<Long> values) {
            addCriterion("ftw_id in", values, "ftwId");
            return (Criteria) this;
        }

        public Criteria andFtwIdNotIn(List<Long> values) {
            addCriterion("ftw_id not in", values, "ftwId");
            return (Criteria) this;
        }

        public Criteria andFtwIdBetween(Long value1, Long value2) {
            addCriterion("ftw_id between", value1, value2, "ftwId");
            return (Criteria) this;
        }

        public Criteria andFtwIdNotBetween(Long value1, Long value2) {
            addCriterion("ftw_id not between", value1, value2, "ftwId");
            return (Criteria) this;
        }

        public Criteria andFtwCityIdIsNull() {
            addCriterion("ftw_city_id is null");
            return (Criteria) this;
        }

        public Criteria andFtwCityIdIsNotNull() {
            addCriterion("ftw_city_id is not null");
            return (Criteria) this;
        }

        public Criteria andFtwCityIdEqualTo(Long value) {
            addCriterion("ftw_city_id =", value, "ftwCityId");
            return (Criteria) this;
        }

        public Criteria andFtwCityIdNotEqualTo(Long value) {
            addCriterion("ftw_city_id <>", value, "ftwCityId");
            return (Criteria) this;
        }

        public Criteria andFtwCityIdGreaterThan(Long value) {
            addCriterion("ftw_city_id >", value, "ftwCityId");
            return (Criteria) this;
        }

        public Criteria andFtwCityIdGreaterThanOrEqualTo(Long value) {
            addCriterion("ftw_city_id >=", value, "ftwCityId");
            return (Criteria) this;
        }

        public Criteria andFtwCityIdLessThan(Long value) {
            addCriterion("ftw_city_id <", value, "ftwCityId");
            return (Criteria) this;
        }

        public Criteria andFtwCityIdLessThanOrEqualTo(Long value) {
            addCriterion("ftw_city_id <=", value, "ftwCityId");
            return (Criteria) this;
        }

        public Criteria andFtwCityIdIn(List<Long> values) {
            addCriterion("ftw_city_id in", values, "ftwCityId");
            return (Criteria) this;
        }

        public Criteria andFtwCityIdNotIn(List<Long> values) {
            addCriterion("ftw_city_id not in", values, "ftwCityId");
            return (Criteria) this;
        }

        public Criteria andFtwCityIdBetween(Long value1, Long value2) {
            addCriterion("ftw_city_id between", value1, value2, "ftwCityId");
            return (Criteria) this;
        }

        public Criteria andFtwCityIdNotBetween(Long value1, Long value2) {
            addCriterion("ftw_city_id not between", value1, value2, "ftwCityId");
            return (Criteria) this;
        }

        public Criteria andFtwNameIsNull() {
            addCriterion("ftw_name is null");
            return (Criteria) this;
        }

        public Criteria andFtwNameIsNotNull() {
            addCriterion("ftw_name is not null");
            return (Criteria) this;
        }

        public Criteria andFtwNameEqualTo(String value) {
            addCriterion("ftw_name =", value, "ftwName");
            return (Criteria) this;
        }

        public Criteria andFtwNameNotEqualTo(String value) {
            addCriterion("ftw_name <>", value, "ftwName");
            return (Criteria) this;
        }

        public Criteria andFtwNameGreaterThan(String value) {
            addCriterion("ftw_name >", value, "ftwName");
            return (Criteria) this;
        }

        public Criteria andFtwNameGreaterThanOrEqualTo(String value) {
            addCriterion("ftw_name >=", value, "ftwName");
            return (Criteria) this;
        }

        public Criteria andFtwNameLessThan(String value) {
            addCriterion("ftw_name <", value, "ftwName");
            return (Criteria) this;
        }

        public Criteria andFtwNameLessThanOrEqualTo(String value) {
            addCriterion("ftw_name <=", value, "ftwName");
            return (Criteria) this;
        }

        public Criteria andFtwNameLike(String value) {
            addCriterion("ftw_name like", value, "ftwName");
            return (Criteria) this;
        }

        public Criteria andFtwNameNotLike(String value) {
            addCriterion("ftw_name not like", value, "ftwName");
            return (Criteria) this;
        }

        public Criteria andFtwNameIn(List<String> values) {
            addCriterion("ftw_name in", values, "ftwName");
            return (Criteria) this;
        }

        public Criteria andFtwNameNotIn(List<String> values) {
            addCriterion("ftw_name not in", values, "ftwName");
            return (Criteria) this;
        }

        public Criteria andFtwNameBetween(String value1, String value2) {
            addCriterion("ftw_name between", value1, value2, "ftwName");
            return (Criteria) this;
        }

        public Criteria andFtwNameNotBetween(String value1, String value2) {
            addCriterion("ftw_name not between", value1, value2, "ftwName");
            return (Criteria) this;
        }

        public Criteria andFtwIdnumberIsNull() {
            addCriterion("ftw_idnumber is null");
            return (Criteria) this;
        }

        public Criteria andFtwIdnumberIsNotNull() {
            addCriterion("ftw_idnumber is not null");
            return (Criteria) this;
        }

        public Criteria andFtwIdnumberEqualTo(String value) {
            addCriterion("ftw_idnumber =", value, "ftwIdnumber");
            return (Criteria) this;
        }

        public Criteria andFtwIdnumberNotEqualTo(String value) {
            addCriterion("ftw_idnumber <>", value, "ftwIdnumber");
            return (Criteria) this;
        }

        public Criteria andFtwIdnumberGreaterThan(String value) {
            addCriterion("ftw_idnumber >", value, "ftwIdnumber");
            return (Criteria) this;
        }

        public Criteria andFtwIdnumberGreaterThanOrEqualTo(String value) {
            addCriterion("ftw_idnumber >=", value, "ftwIdnumber");
            return (Criteria) this;
        }

        public Criteria andFtwIdnumberLessThan(String value) {
            addCriterion("ftw_idnumber <", value, "ftwIdnumber");
            return (Criteria) this;
        }

        public Criteria andFtwIdnumberLessThanOrEqualTo(String value) {
            addCriterion("ftw_idnumber <=", value, "ftwIdnumber");
            return (Criteria) this;
        }

        public Criteria andFtwIdnumberLike(String value) {
            addCriterion("ftw_idnumber like", value, "ftwIdnumber");
            return (Criteria) this;
        }

        public Criteria andFtwIdnumberNotLike(String value) {
            addCriterion("ftw_idnumber not like", value, "ftwIdnumber");
            return (Criteria) this;
        }

        public Criteria andFtwIdnumberIn(List<String> values) {
            addCriterion("ftw_idnumber in", values, "ftwIdnumber");
            return (Criteria) this;
        }

        public Criteria andFtwIdnumberNotIn(List<String> values) {
            addCriterion("ftw_idnumber not in", values, "ftwIdnumber");
            return (Criteria) this;
        }

        public Criteria andFtwIdnumberBetween(String value1, String value2) {
            addCriterion("ftw_idnumber between", value1, value2, "ftwIdnumber");
            return (Criteria) this;
        }

        public Criteria andFtwIdnumberNotBetween(String value1, String value2) {
            addCriterion("ftw_idnumber not between", value1, value2, "ftwIdnumber");
            return (Criteria) this;
        }

        public Criteria andFtwMemberIdIsNull() {
            addCriterion("ftw_member_id is null");
            return (Criteria) this;
        }

        public Criteria andFtwMemberIdIsNotNull() {
            addCriterion("ftw_member_id is not null");
            return (Criteria) this;
        }

        public Criteria andFtwMemberIdEqualTo(Long value) {
            addCriterion("ftw_member_id =", value, "ftwMemberId");
            return (Criteria) this;
        }

        public Criteria andFtwMemberIdNotEqualTo(Long value) {
            addCriterion("ftw_member_id <>", value, "ftwMemberId");
            return (Criteria) this;
        }

        public Criteria andFtwMemberIdGreaterThan(Long value) {
            addCriterion("ftw_member_id >", value, "ftwMemberId");
            return (Criteria) this;
        }

        public Criteria andFtwMemberIdGreaterThanOrEqualTo(Long value) {
            addCriterion("ftw_member_id >=", value, "ftwMemberId");
            return (Criteria) this;
        }

        public Criteria andFtwMemberIdLessThan(Long value) {
            addCriterion("ftw_member_id <", value, "ftwMemberId");
            return (Criteria) this;
        }

        public Criteria andFtwMemberIdLessThanOrEqualTo(Long value) {
            addCriterion("ftw_member_id <=", value, "ftwMemberId");
            return (Criteria) this;
        }

        public Criteria andFtwMemberIdIn(List<Long> values) {
            addCriterion("ftw_member_id in", values, "ftwMemberId");
            return (Criteria) this;
        }

        public Criteria andFtwMemberIdNotIn(List<Long> values) {
            addCriterion("ftw_member_id not in", values, "ftwMemberId");
            return (Criteria) this;
        }

        public Criteria andFtwMemberIdBetween(Long value1, Long value2) {
            addCriterion("ftw_member_id between", value1, value2, "ftwMemberId");
            return (Criteria) this;
        }

        public Criteria andFtwMemberIdNotBetween(Long value1, Long value2) {
            addCriterion("ftw_member_id not between", value1, value2, "ftwMemberId");
            return (Criteria) this;
        }

        public Criteria andFtwAgreementNumberIsNull() {
            addCriterion("ftw_agreement_number is null");
            return (Criteria) this;
        }

        public Criteria andFtwAgreementNumberIsNotNull() {
            addCriterion("ftw_agreement_number is not null");
            return (Criteria) this;
        }

        public Criteria andFtwAgreementNumberEqualTo(String value) {
            addCriterion("ftw_agreement_number =", value, "ftwAgreementNumber");
            return (Criteria) this;
        }

        public Criteria andFtwAgreementNumberNotEqualTo(String value) {
            addCriterion("ftw_agreement_number <>", value, "ftwAgreementNumber");
            return (Criteria) this;
        }

        public Criteria andFtwAgreementNumberGreaterThan(String value) {
            addCriterion("ftw_agreement_number >", value, "ftwAgreementNumber");
            return (Criteria) this;
        }

        public Criteria andFtwAgreementNumberGreaterThanOrEqualTo(String value) {
            addCriterion("ftw_agreement_number >=", value, "ftwAgreementNumber");
            return (Criteria) this;
        }

        public Criteria andFtwAgreementNumberLessThan(String value) {
            addCriterion("ftw_agreement_number <", value, "ftwAgreementNumber");
            return (Criteria) this;
        }

        public Criteria andFtwAgreementNumberLessThanOrEqualTo(String value) {
            addCriterion("ftw_agreement_number <=", value, "ftwAgreementNumber");
            return (Criteria) this;
        }

        public Criteria andFtwAgreementNumberLike(String value) {
            addCriterion("ftw_agreement_number like", value, "ftwAgreementNumber");
            return (Criteria) this;
        }

        public Criteria andFtwAgreementNumberNotLike(String value) {
            addCriterion("ftw_agreement_number not like", value, "ftwAgreementNumber");
            return (Criteria) this;
        }

        public Criteria andFtwAgreementNumberIn(List<String> values) {
            addCriterion("ftw_agreement_number in", values, "ftwAgreementNumber");
            return (Criteria) this;
        }

        public Criteria andFtwAgreementNumberNotIn(List<String> values) {
            addCriterion("ftw_agreement_number not in", values, "ftwAgreementNumber");
            return (Criteria) this;
        }

        public Criteria andFtwAgreementNumberBetween(String value1, String value2) {
            addCriterion("ftw_agreement_number between", value1, value2, "ftwAgreementNumber");
            return (Criteria) this;
        }

        public Criteria andFtwAgreementNumberNotBetween(String value1, String value2) {
            addCriterion("ftw_agreement_number not between", value1, value2, "ftwAgreementNumber");
            return (Criteria) this;
        }

        public Criteria andFtwRentDateIsNull() {
            addCriterion("ftw_rent_date is null");
            return (Criteria) this;
        }

        public Criteria andFtwRentDateIsNotNull() {
            addCriterion("ftw_rent_date is not null");
            return (Criteria) this;
        }

        public Criteria andFtwRentDateEqualTo(Date value) {
            addCriterion("ftw_rent_date =", value, "ftwRentDate");
            return (Criteria) this;
        }

        public Criteria andFtwRentDateNotEqualTo(Date value) {
            addCriterion("ftw_rent_date <>", value, "ftwRentDate");
            return (Criteria) this;
        }

        public Criteria andFtwRentDateGreaterThan(Date value) {
            addCriterion("ftw_rent_date >", value, "ftwRentDate");
            return (Criteria) this;
        }

        public Criteria andFtwRentDateGreaterThanOrEqualTo(Date value) {
            addCriterion("ftw_rent_date >=", value, "ftwRentDate");
            return (Criteria) this;
        }

        public Criteria andFtwRentDateLessThan(Date value) {
            addCriterion("ftw_rent_date <", value, "ftwRentDate");
            return (Criteria) this;
        }

        public Criteria andFtwRentDateLessThanOrEqualTo(Date value) {
            addCriterion("ftw_rent_date <=", value, "ftwRentDate");
            return (Criteria) this;
        }

        public Criteria andFtwRentDateIn(List<Date> values) {
            addCriterion("ftw_rent_date in", values, "ftwRentDate");
            return (Criteria) this;
        }

        public Criteria andFtwRentDateNotIn(List<Date> values) {
            addCriterion("ftw_rent_date not in", values, "ftwRentDate");
            return (Criteria) this;
        }

        public Criteria andFtwRentDateBetween(Date value1, Date value2) {
            addCriterion("ftw_rent_date between", value1, value2, "ftwRentDate");
            return (Criteria) this;
        }

        public Criteria andFtwRentDateNotBetween(Date value1, Date value2) {
            addCriterion("ftw_rent_date not between", value1, value2, "ftwRentDate");
            return (Criteria) this;
        }

        public Criteria andFtwLeaseCountIsNull() {
            addCriterion("ftw_lease_count is null");
            return (Criteria) this;
        }

        public Criteria andFtwLeaseCountIsNotNull() {
            addCriterion("ftw_lease_count is not null");
            return (Criteria) this;
        }

        public Criteria andFtwLeaseCountEqualTo(Integer value) {
            addCriterion("ftw_lease_count =", value, "ftwLeaseCount");
            return (Criteria) this;
        }

        public Criteria andFtwLeaseCountNotEqualTo(Integer value) {
            addCriterion("ftw_lease_count <>", value, "ftwLeaseCount");
            return (Criteria) this;
        }

        public Criteria andFtwLeaseCountGreaterThan(Integer value) {
            addCriterion("ftw_lease_count >", value, "ftwLeaseCount");
            return (Criteria) this;
        }

        public Criteria andFtwLeaseCountGreaterThanOrEqualTo(Integer value) {
            addCriterion("ftw_lease_count >=", value, "ftwLeaseCount");
            return (Criteria) this;
        }

        public Criteria andFtwLeaseCountLessThan(Integer value) {
            addCriterion("ftw_lease_count <", value, "ftwLeaseCount");
            return (Criteria) this;
        }

        public Criteria andFtwLeaseCountLessThanOrEqualTo(Integer value) {
            addCriterion("ftw_lease_count <=", value, "ftwLeaseCount");
            return (Criteria) this;
        }

        public Criteria andFtwLeaseCountIn(List<Integer> values) {
            addCriterion("ftw_lease_count in", values, "ftwLeaseCount");
            return (Criteria) this;
        }

        public Criteria andFtwLeaseCountNotIn(List<Integer> values) {
            addCriterion("ftw_lease_count not in", values, "ftwLeaseCount");
            return (Criteria) this;
        }

        public Criteria andFtwLeaseCountBetween(Integer value1, Integer value2) {
            addCriterion("ftw_lease_count between", value1, value2, "ftwLeaseCount");
            return (Criteria) this;
        }

        public Criteria andFtwLeaseCountNotBetween(Integer value1, Integer value2) {
            addCriterion("ftw_lease_count not between", value1, value2, "ftwLeaseCount");
            return (Criteria) this;
        }

        public Criteria andFtwCarModelIsNull() {
            addCriterion("ftw_car_model is null");
            return (Criteria) this;
        }

        public Criteria andFtwCarModelIsNotNull() {
            addCriterion("ftw_car_model is not null");
            return (Criteria) this;
        }

        public Criteria andFtwCarModelEqualTo(Long value) {
            addCriterion("ftw_car_model =", value, "ftwCarModel");
            return (Criteria) this;
        }

        public Criteria andFtwCarModelNotEqualTo(Long value) {
            addCriterion("ftw_car_model <>", value, "ftwCarModel");
            return (Criteria) this;
        }

        public Criteria andFtwCarModelGreaterThan(Long value) {
            addCriterion("ftw_car_model >", value, "ftwCarModel");
            return (Criteria) this;
        }

        public Criteria andFtwCarModelGreaterThanOrEqualTo(Long value) {
            addCriterion("ftw_car_model >=", value, "ftwCarModel");
            return (Criteria) this;
        }

        public Criteria andFtwCarModelLessThan(Long value) {
            addCriterion("ftw_car_model <", value, "ftwCarModel");
            return (Criteria) this;
        }

        public Criteria andFtwCarModelLessThanOrEqualTo(Long value) {
            addCriterion("ftw_car_model <=", value, "ftwCarModel");
            return (Criteria) this;
        }

        public Criteria andFtwCarModelIn(List<Long> values) {
            addCriterion("ftw_car_model in", values, "ftwCarModel");
            return (Criteria) this;
        }

        public Criteria andFtwCarModelNotIn(List<Long> values) {
            addCriterion("ftw_car_model not in", values, "ftwCarModel");
            return (Criteria) this;
        }

        public Criteria andFtwCarModelBetween(Long value1, Long value2) {
            addCriterion("ftw_car_model between", value1, value2, "ftwCarModel");
            return (Criteria) this;
        }

        public Criteria andFtwCarModelNotBetween(Long value1, Long value2) {
            addCriterion("ftw_car_model not between", value1, value2, "ftwCarModel");
            return (Criteria) this;
        }

        public Criteria andFtwCarVinIsNull() {
            addCriterion("ftw_car_vin is null");
            return (Criteria) this;
        }

        public Criteria andFtwCarVinIsNotNull() {
            addCriterion("ftw_car_vin is not null");
            return (Criteria) this;
        }

        public Criteria andFtwCarVinEqualTo(String value) {
            addCriterion("ftw_car_vin =", value, "ftwCarVin");
            return (Criteria) this;
        }

        public Criteria andFtwCarVinNotEqualTo(String value) {
            addCriterion("ftw_car_vin <>", value, "ftwCarVin");
            return (Criteria) this;
        }

        public Criteria andFtwCarVinGreaterThan(String value) {
            addCriterion("ftw_car_vin >", value, "ftwCarVin");
            return (Criteria) this;
        }

        public Criteria andFtwCarVinGreaterThanOrEqualTo(String value) {
            addCriterion("ftw_car_vin >=", value, "ftwCarVin");
            return (Criteria) this;
        }

        public Criteria andFtwCarVinLessThan(String value) {
            addCriterion("ftw_car_vin <", value, "ftwCarVin");
            return (Criteria) this;
        }

        public Criteria andFtwCarVinLessThanOrEqualTo(String value) {
            addCriterion("ftw_car_vin <=", value, "ftwCarVin");
            return (Criteria) this;
        }

        public Criteria andFtwCarVinLike(String value) {
            addCriterion("ftw_car_vin like", value, "ftwCarVin");
            return (Criteria) this;
        }

        public Criteria andFtwCarVinNotLike(String value) {
            addCriterion("ftw_car_vin not like", value, "ftwCarVin");
            return (Criteria) this;
        }

        public Criteria andFtwCarVinIn(List<String> values) {
            addCriterion("ftw_car_vin in", values, "ftwCarVin");
            return (Criteria) this;
        }

        public Criteria andFtwCarVinNotIn(List<String> values) {
            addCriterion("ftw_car_vin not in", values, "ftwCarVin");
            return (Criteria) this;
        }

        public Criteria andFtwCarVinBetween(String value1, String value2) {
            addCriterion("ftw_car_vin between", value1, value2, "ftwCarVin");
            return (Criteria) this;
        }

        public Criteria andFtwCarVinNotBetween(String value1, String value2) {
            addCriterion("ftw_car_vin not between", value1, value2, "ftwCarVin");
            return (Criteria) this;
        }

        public Criteria andFtwMonthRentIsNull() {
            addCriterion("ftw_month_rent is null");
            return (Criteria) this;
        }

        public Criteria andFtwMonthRentIsNotNull() {
            addCriterion("ftw_month_rent is not null");
            return (Criteria) this;
        }

        public Criteria andFtwMonthRentEqualTo(Double value) {
            addCriterion("ftw_month_rent =", value, "ftwMonthRent");
            return (Criteria) this;
        }

        public Criteria andFtwMonthRentNotEqualTo(Double value) {
            addCriterion("ftw_month_rent <>", value, "ftwMonthRent");
            return (Criteria) this;
        }

        public Criteria andFtwMonthRentGreaterThan(Double value) {
            addCriterion("ftw_month_rent >", value, "ftwMonthRent");
            return (Criteria) this;
        }

        public Criteria andFtwMonthRentGreaterThanOrEqualTo(Double value) {
            addCriterion("ftw_month_rent >=", value, "ftwMonthRent");
            return (Criteria) this;
        }

        public Criteria andFtwMonthRentLessThan(Double value) {
            addCriterion("ftw_month_rent <", value, "ftwMonthRent");
            return (Criteria) this;
        }

        public Criteria andFtwMonthRentLessThanOrEqualTo(Double value) {
            addCriterion("ftw_month_rent <=", value, "ftwMonthRent");
            return (Criteria) this;
        }

        public Criteria andFtwMonthRentIn(List<Double> values) {
            addCriterion("ftw_month_rent in", values, "ftwMonthRent");
            return (Criteria) this;
        }

        public Criteria andFtwMonthRentNotIn(List<Double> values) {
            addCriterion("ftw_month_rent not in", values, "ftwMonthRent");
            return (Criteria) this;
        }

        public Criteria andFtwMonthRentBetween(Double value1, Double value2) {
            addCriterion("ftw_month_rent between", value1, value2, "ftwMonthRent");
            return (Criteria) this;
        }

        public Criteria andFtwMonthRentNotBetween(Double value1, Double value2) {
            addCriterion("ftw_month_rent not between", value1, value2, "ftwMonthRent");
            return (Criteria) this;
        }

        public Criteria andFtwMonthWithholdIsNull() {
            addCriterion("ftw_month_withhold is null");
            return (Criteria) this;
        }

        public Criteria andFtwMonthWithholdIsNotNull() {
            addCriterion("ftw_month_withhold is not null");
            return (Criteria) this;
        }

        public Criteria andFtwMonthWithholdEqualTo(Double value) {
            addCriterion("ftw_month_withhold =", value, "ftwMonthWithhold");
            return (Criteria) this;
        }

        public Criteria andFtwMonthWithholdNotEqualTo(Double value) {
            addCriterion("ftw_month_withhold <>", value, "ftwMonthWithhold");
            return (Criteria) this;
        }

        public Criteria andFtwMonthWithholdGreaterThan(Double value) {
            addCriterion("ftw_month_withhold >", value, "ftwMonthWithhold");
            return (Criteria) this;
        }

        public Criteria andFtwMonthWithholdGreaterThanOrEqualTo(Double value) {
            addCriterion("ftw_month_withhold >=", value, "ftwMonthWithhold");
            return (Criteria) this;
        }

        public Criteria andFtwMonthWithholdLessThan(Double value) {
            addCriterion("ftw_month_withhold <", value, "ftwMonthWithhold");
            return (Criteria) this;
        }

        public Criteria andFtwMonthWithholdLessThanOrEqualTo(Double value) {
            addCriterion("ftw_month_withhold <=", value, "ftwMonthWithhold");
            return (Criteria) this;
        }

        public Criteria andFtwMonthWithholdIn(List<Double> values) {
            addCriterion("ftw_month_withhold in", values, "ftwMonthWithhold");
            return (Criteria) this;
        }

        public Criteria andFtwMonthWithholdNotIn(List<Double> values) {
            addCriterion("ftw_month_withhold not in", values, "ftwMonthWithhold");
            return (Criteria) this;
        }

        public Criteria andFtwMonthWithholdBetween(Double value1, Double value2) {
            addCriterion("ftw_month_withhold between", value1, value2, "ftwMonthWithhold");
            return (Criteria) this;
        }

        public Criteria andFtwMonthWithholdNotBetween(Double value1, Double value2) {
            addCriterion("ftw_month_withhold not between", value1, value2, "ftwMonthWithhold");
            return (Criteria) this;
        }

        public Criteria andFtwMonthRentBalanceIsNull() {
            addCriterion("ftw_month_rent_balance is null");
            return (Criteria) this;
        }

        public Criteria andFtwMonthRentBalanceIsNotNull() {
            addCriterion("ftw_month_rent_balance is not null");
            return (Criteria) this;
        }

        public Criteria andFtwMonthRentBalanceEqualTo(Double value) {
            addCriterion("ftw_month_rent_balance =", value, "ftwMonthRentBalance");
            return (Criteria) this;
        }

        public Criteria andFtwMonthRentBalanceNotEqualTo(Double value) {
            addCriterion("ftw_month_rent_balance <>", value, "ftwMonthRentBalance");
            return (Criteria) this;
        }

        public Criteria andFtwMonthRentBalanceGreaterThan(Double value) {
            addCriterion("ftw_month_rent_balance >", value, "ftwMonthRentBalance");
            return (Criteria) this;
        }

        public Criteria andFtwMonthRentBalanceGreaterThanOrEqualTo(Double value) {
            addCriterion("ftw_month_rent_balance >=", value, "ftwMonthRentBalance");
            return (Criteria) this;
        }

        public Criteria andFtwMonthRentBalanceLessThan(Double value) {
            addCriterion("ftw_month_rent_balance <", value, "ftwMonthRentBalance");
            return (Criteria) this;
        }

        public Criteria andFtwMonthRentBalanceLessThanOrEqualTo(Double value) {
            addCriterion("ftw_month_rent_balance <=", value, "ftwMonthRentBalance");
            return (Criteria) this;
        }

        public Criteria andFtwMonthRentBalanceIn(List<Double> values) {
            addCriterion("ftw_month_rent_balance in", values, "ftwMonthRentBalance");
            return (Criteria) this;
        }

        public Criteria andFtwMonthRentBalanceNotIn(List<Double> values) {
            addCriterion("ftw_month_rent_balance not in", values, "ftwMonthRentBalance");
            return (Criteria) this;
        }

        public Criteria andFtwMonthRentBalanceBetween(Double value1, Double value2) {
            addCriterion("ftw_month_rent_balance between", value1, value2, "ftwMonthRentBalance");
            return (Criteria) this;
        }

        public Criteria andFtwMonthRentBalanceNotBetween(Double value1, Double value2) {
            addCriterion("ftw_month_rent_balance not between", value1, value2, "ftwMonthRentBalance");
            return (Criteria) this;
        }

        public Criteria andFtwMatchStateIsNull() {
            addCriterion("ftw_match_state is null");
            return (Criteria) this;
        }

        public Criteria andFtwMatchStateIsNotNull() {
            addCriterion("ftw_match_state is not null");
            return (Criteria) this;
        }

        public Criteria andFtwMatchStateEqualTo(Integer value) {
            addCriterion("ftw_match_state =", value, "ftwMatchState");
            return (Criteria) this;
        }

        public Criteria andFtwMatchStateNotEqualTo(Integer value) {
            addCriterion("ftw_match_state <>", value, "ftwMatchState");
            return (Criteria) this;
        }

        public Criteria andFtwMatchStateGreaterThan(Integer value) {
            addCriterion("ftw_match_state >", value, "ftwMatchState");
            return (Criteria) this;
        }

        public Criteria andFtwMatchStateGreaterThanOrEqualTo(Integer value) {
            addCriterion("ftw_match_state >=", value, "ftwMatchState");
            return (Criteria) this;
        }

        public Criteria andFtwMatchStateLessThan(Integer value) {
            addCriterion("ftw_match_state <", value, "ftwMatchState");
            return (Criteria) this;
        }

        public Criteria andFtwMatchStateLessThanOrEqualTo(Integer value) {
            addCriterion("ftw_match_state <=", value, "ftwMatchState");
            return (Criteria) this;
        }

        public Criteria andFtwMatchStateIn(List<Integer> values) {
            addCriterion("ftw_match_state in", values, "ftwMatchState");
            return (Criteria) this;
        }

        public Criteria andFtwMatchStateNotIn(List<Integer> values) {
            addCriterion("ftw_match_state not in", values, "ftwMatchState");
            return (Criteria) this;
        }

        public Criteria andFtwMatchStateBetween(Integer value1, Integer value2) {
            addCriterion("ftw_match_state between", value1, value2, "ftwMatchState");
            return (Criteria) this;
        }

        public Criteria andFtwMatchStateNotBetween(Integer value1, Integer value2) {
            addCriterion("ftw_match_state not between", value1, value2, "ftwMatchState");
            return (Criteria) this;
        }

        public Criteria andFtwMatchBillIsNull() {
            addCriterion("ftw_match_bill is null");
            return (Criteria) this;
        }

        public Criteria andFtwMatchBillIsNotNull() {
            addCriterion("ftw_match_bill is not null");
            return (Criteria) this;
        }

        public Criteria andFtwMatchBillEqualTo(String value) {
            addCriterion("ftw_match_bill =", value, "ftwMatchBill");
            return (Criteria) this;
        }

        public Criteria andFtwMatchBillNotEqualTo(String value) {
            addCriterion("ftw_match_bill <>", value, "ftwMatchBill");
            return (Criteria) this;
        }

        public Criteria andFtwMatchBillGreaterThan(String value) {
            addCriterion("ftw_match_bill >", value, "ftwMatchBill");
            return (Criteria) this;
        }

        public Criteria andFtwMatchBillGreaterThanOrEqualTo(String value) {
            addCriterion("ftw_match_bill >=", value, "ftwMatchBill");
            return (Criteria) this;
        }

        public Criteria andFtwMatchBillLessThan(String value) {
            addCriterion("ftw_match_bill <", value, "ftwMatchBill");
            return (Criteria) this;
        }

        public Criteria andFtwMatchBillLessThanOrEqualTo(String value) {
            addCriterion("ftw_match_bill <=", value, "ftwMatchBill");
            return (Criteria) this;
        }

        public Criteria andFtwMatchBillLike(String value) {
            addCriterion("ftw_match_bill like", value, "ftwMatchBill");
            return (Criteria) this;
        }

        public Criteria andFtwMatchBillNotLike(String value) {
            addCriterion("ftw_match_bill not like", value, "ftwMatchBill");
            return (Criteria) this;
        }

        public Criteria andFtwMatchBillIn(List<String> values) {
            addCriterion("ftw_match_bill in", values, "ftwMatchBill");
            return (Criteria) this;
        }

        public Criteria andFtwMatchBillNotIn(List<String> values) {
            addCriterion("ftw_match_bill not in", values, "ftwMatchBill");
            return (Criteria) this;
        }

        public Criteria andFtwMatchBillBetween(String value1, String value2) {
            addCriterion("ftw_match_bill between", value1, value2, "ftwMatchBill");
            return (Criteria) this;
        }

        public Criteria andFtwMatchBillNotBetween(String value1, String value2) {
            addCriterion("ftw_match_bill not between", value1, value2, "ftwMatchBill");
            return (Criteria) this;
        }

        public Criteria andFtwMatchWayIsNull() {
            addCriterion("ftw_match_way is null");
            return (Criteria) this;
        }

        public Criteria andFtwMatchWayIsNotNull() {
            addCriterion("ftw_match_way is not null");
            return (Criteria) this;
        }

        public Criteria andFtwMatchWayEqualTo(Integer value) {
            addCriterion("ftw_match_way =", value, "ftwMatchWay");
            return (Criteria) this;
        }

        public Criteria andFtwMatchWayNotEqualTo(Integer value) {
            addCriterion("ftw_match_way <>", value, "ftwMatchWay");
            return (Criteria) this;
        }

        public Criteria andFtwMatchWayGreaterThan(Integer value) {
            addCriterion("ftw_match_way >", value, "ftwMatchWay");
            return (Criteria) this;
        }

        public Criteria andFtwMatchWayGreaterThanOrEqualTo(Integer value) {
            addCriterion("ftw_match_way >=", value, "ftwMatchWay");
            return (Criteria) this;
        }

        public Criteria andFtwMatchWayLessThan(Integer value) {
            addCriterion("ftw_match_way <", value, "ftwMatchWay");
            return (Criteria) this;
        }

        public Criteria andFtwMatchWayLessThanOrEqualTo(Integer value) {
            addCriterion("ftw_match_way <=", value, "ftwMatchWay");
            return (Criteria) this;
        }

        public Criteria andFtwMatchWayIn(List<Integer> values) {
            addCriterion("ftw_match_way in", values, "ftwMatchWay");
            return (Criteria) this;
        }

        public Criteria andFtwMatchWayNotIn(List<Integer> values) {
            addCriterion("ftw_match_way not in", values, "ftwMatchWay");
            return (Criteria) this;
        }

        public Criteria andFtwMatchWayBetween(Integer value1, Integer value2) {
            addCriterion("ftw_match_way between", value1, value2, "ftwMatchWay");
            return (Criteria) this;
        }

        public Criteria andFtwMatchWayNotBetween(Integer value1, Integer value2) {
            addCriterion("ftw_match_way not between", value1, value2, "ftwMatchWay");
            return (Criteria) this;
        }

        public Criteria andFtwMatchedAmountIsNull() {
            addCriterion("ftw_matched_amount is null");
            return (Criteria) this;
        }

        public Criteria andFtwMatchedAmountIsNotNull() {
            addCriterion("ftw_matched_amount is not null");
            return (Criteria) this;
        }

        public Criteria andFtwMatchedAmountEqualTo(Double value) {
            addCriterion("ftw_matched_amount =", value, "ftwMatchedAmount");
            return (Criteria) this;
        }

        public Criteria andFtwMatchedAmountNotEqualTo(Double value) {
            addCriterion("ftw_matched_amount <>", value, "ftwMatchedAmount");
            return (Criteria) this;
        }

        public Criteria andFtwMatchedAmountGreaterThan(Double value) {
            addCriterion("ftw_matched_amount >", value, "ftwMatchedAmount");
            return (Criteria) this;
        }

        public Criteria andFtwMatchedAmountGreaterThanOrEqualTo(Double value) {
            addCriterion("ftw_matched_amount >=", value, "ftwMatchedAmount");
            return (Criteria) this;
        }

        public Criteria andFtwMatchedAmountLessThan(Double value) {
            addCriterion("ftw_matched_amount <", value, "ftwMatchedAmount");
            return (Criteria) this;
        }

        public Criteria andFtwMatchedAmountLessThanOrEqualTo(Double value) {
            addCriterion("ftw_matched_amount <=", value, "ftwMatchedAmount");
            return (Criteria) this;
        }

        public Criteria andFtwMatchedAmountIn(List<Double> values) {
            addCriterion("ftw_matched_amount in", values, "ftwMatchedAmount");
            return (Criteria) this;
        }

        public Criteria andFtwMatchedAmountNotIn(List<Double> values) {
            addCriterion("ftw_matched_amount not in", values, "ftwMatchedAmount");
            return (Criteria) this;
        }

        public Criteria andFtwMatchedAmountBetween(Double value1, Double value2) {
            addCriterion("ftw_matched_amount between", value1, value2, "ftwMatchedAmount");
            return (Criteria) this;
        }

        public Criteria andFtwMatchedAmountNotBetween(Double value1, Double value2) {
            addCriterion("ftw_matched_amount not between", value1, value2, "ftwMatchedAmount");
            return (Criteria) this;
        }

        public Criteria andFtwNotMatchAmountIsNull() {
            addCriterion("ftw_not_match_amount is null");
            return (Criteria) this;
        }

        public Criteria andFtwNotMatchAmountIsNotNull() {
            addCriterion("ftw_not_match_amount is not null");
            return (Criteria) this;
        }

        public Criteria andFtwNotMatchAmountEqualTo(Double value) {
            addCriterion("ftw_not_match_amount =", value, "ftwNotMatchAmount");
            return (Criteria) this;
        }

        public Criteria andFtwNotMatchAmountNotEqualTo(Double value) {
            addCriterion("ftw_not_match_amount <>", value, "ftwNotMatchAmount");
            return (Criteria) this;
        }

        public Criteria andFtwNotMatchAmountGreaterThan(Double value) {
            addCriterion("ftw_not_match_amount >", value, "ftwNotMatchAmount");
            return (Criteria) this;
        }

        public Criteria andFtwNotMatchAmountGreaterThanOrEqualTo(Double value) {
            addCriterion("ftw_not_match_amount >=", value, "ftwNotMatchAmount");
            return (Criteria) this;
        }

        public Criteria andFtwNotMatchAmountLessThan(Double value) {
            addCriterion("ftw_not_match_amount <", value, "ftwNotMatchAmount");
            return (Criteria) this;
        }

        public Criteria andFtwNotMatchAmountLessThanOrEqualTo(Double value) {
            addCriterion("ftw_not_match_amount <=", value, "ftwNotMatchAmount");
            return (Criteria) this;
        }

        public Criteria andFtwNotMatchAmountIn(List<Double> values) {
            addCriterion("ftw_not_match_amount in", values, "ftwNotMatchAmount");
            return (Criteria) this;
        }

        public Criteria andFtwNotMatchAmountNotIn(List<Double> values) {
            addCriterion("ftw_not_match_amount not in", values, "ftwNotMatchAmount");
            return (Criteria) this;
        }

        public Criteria andFtwNotMatchAmountBetween(Double value1, Double value2) {
            addCriterion("ftw_not_match_amount between", value1, value2, "ftwNotMatchAmount");
            return (Criteria) this;
        }

        public Criteria andFtwNotMatchAmountNotBetween(Double value1, Double value2) {
            addCriterion("ftw_not_match_amount not between", value1, value2, "ftwNotMatchAmount");
            return (Criteria) this;
        }

        public Criteria andRemarkIsNull() {
            addCriterion("remark is null");
            return (Criteria) this;
        }

        public Criteria andRemarkIsNotNull() {
            addCriterion("remark is not null");
            return (Criteria) this;
        }

        public Criteria andRemarkEqualTo(String value) {
            addCriterion("remark =", value, "remark");
            return (Criteria) this;
        }

        public Criteria andRemarkNotEqualTo(String value) {
            addCriterion("remark <>", value, "remark");
            return (Criteria) this;
        }

        public Criteria andRemarkGreaterThan(String value) {
            addCriterion("remark >", value, "remark");
            return (Criteria) this;
        }

        public Criteria andRemarkGreaterThanOrEqualTo(String value) {
            addCriterion("remark >=", value, "remark");
            return (Criteria) this;
        }

        public Criteria andRemarkLessThan(String value) {
            addCriterion("remark <", value, "remark");
            return (Criteria) this;
        }

        public Criteria andRemarkLessThanOrEqualTo(String value) {
            addCriterion("remark <=", value, "remark");
            return (Criteria) this;
        }

        public Criteria andRemarkLike(String value) {
            addCriterion("remark like", value, "remark");
            return (Criteria) this;
        }

        public Criteria andRemarkNotLike(String value) {
            addCriterion("remark not like", value, "remark");
            return (Criteria) this;
        }

        public Criteria andRemarkIn(List<String> values) {
            addCriterion("remark in", values, "remark");
            return (Criteria) this;
        }

        public Criteria andRemarkNotIn(List<String> values) {
            addCriterion("remark not in", values, "remark");
            return (Criteria) this;
        }

        public Criteria andRemarkBetween(String value1, String value2) {
            addCriterion("remark between", value1, value2, "remark");
            return (Criteria) this;
        }

        public Criteria andRemarkNotBetween(String value1, String value2) {
            addCriterion("remark not between", value1, value2, "remark");
            return (Criteria) this;
        }

        public Criteria andCreateuserIsNull() {
            addCriterion("createuser is null");
            return (Criteria) this;
        }

        public Criteria andCreateuserIsNotNull() {
            addCriterion("createuser is not null");
            return (Criteria) this;
        }

        public Criteria andCreateuserEqualTo(String value) {
            addCriterion("createuser =", value, "createuser");
            return (Criteria) this;
        }

        public Criteria andCreateuserNotEqualTo(String value) {
            addCriterion("createuser <>", value, "createuser");
            return (Criteria) this;
        }

        public Criteria andCreateuserGreaterThan(String value) {
            addCriterion("createuser >", value, "createuser");
            return (Criteria) this;
        }

        public Criteria andCreateuserGreaterThanOrEqualTo(String value) {
            addCriterion("createuser >=", value, "createuser");
            return (Criteria) this;
        }

        public Criteria andCreateuserLessThan(String value) {
            addCriterion("createuser <", value, "createuser");
            return (Criteria) this;
        }

        public Criteria andCreateuserLessThanOrEqualTo(String value) {
            addCriterion("createuser <=", value, "createuser");
            return (Criteria) this;
        }

        public Criteria andCreateuserLike(String value) {
            addCriterion("createuser like", value, "createuser");
            return (Criteria) this;
        }

        public Criteria andCreateuserNotLike(String value) {
            addCriterion("createuser not like", value, "createuser");
            return (Criteria) this;
        }

        public Criteria andCreateuserIn(List<String> values) {
            addCriterion("createuser in", values, "createuser");
            return (Criteria) this;
        }

        public Criteria andCreateuserNotIn(List<String> values) {
            addCriterion("createuser not in", values, "createuser");
            return (Criteria) this;
        }

        public Criteria andCreateuserBetween(String value1, String value2) {
            addCriterion("createuser between", value1, value2, "createuser");
            return (Criteria) this;
        }

        public Criteria andCreateuserNotBetween(String value1, String value2) {
            addCriterion("createuser not between", value1, value2, "createuser");
            return (Criteria) this;
        }

        public Criteria andCreatetimeIsNull() {
            addCriterion("createtime is null");
            return (Criteria) this;
        }

        public Criteria andCreatetimeIsNotNull() {
            addCriterion("createtime is not null");
            return (Criteria) this;
        }

        public Criteria andCreatetimeEqualTo(Date value) {
            addCriterion("createtime =", value, "createtime");
            return (Criteria) this;
        }

        public Criteria andCreatetimeNotEqualTo(Date value) {
            addCriterion("createtime <>", value, "createtime");
            return (Criteria) this;
        }

        public Criteria andCreatetimeGreaterThan(Date value) {
            addCriterion("createtime >", value, "createtime");
            return (Criteria) this;
        }

        public Criteria andCreatetimeGreaterThanOrEqualTo(Date value) {
            addCriterion("createtime >=", value, "createtime");
            return (Criteria) this;
        }

        public Criteria andCreatetimeLessThan(Date value) {
            addCriterion("createtime <", value, "createtime");
            return (Criteria) this;
        }

        public Criteria andCreatetimeLessThanOrEqualTo(Date value) {
            addCriterion("createtime <=", value, "createtime");
            return (Criteria) this;
        }

        public Criteria andCreatetimeIn(List<Date> values) {
            addCriterion("createtime in", values, "createtime");
            return (Criteria) this;
        }

        public Criteria andCreatetimeNotIn(List<Date> values) {
            addCriterion("createtime not in", values, "createtime");
            return (Criteria) this;
        }

        public Criteria andCreatetimeBetween(Date value1, Date value2) {
            addCriterion("createtime between", value1, value2, "createtime");
            return (Criteria) this;
        }

        public Criteria andCreatetimeNotBetween(Date value1, Date value2) {
            addCriterion("createtime not between", value1, value2, "createtime");
            return (Criteria) this;
        }

        public Criteria andUpdateuserIsNull() {
            addCriterion("updateuser is null");
            return (Criteria) this;
        }

        public Criteria andUpdateuserIsNotNull() {
            addCriterion("updateuser is not null");
            return (Criteria) this;
        }

        public Criteria andUpdateuserEqualTo(String value) {
            addCriterion("updateuser =", value, "updateuser");
            return (Criteria) this;
        }

        public Criteria andUpdateuserNotEqualTo(String value) {
            addCriterion("updateuser <>", value, "updateuser");
            return (Criteria) this;
        }

        public Criteria andUpdateuserGreaterThan(String value) {
            addCriterion("updateuser >", value, "updateuser");
            return (Criteria) this;
        }

        public Criteria andUpdateuserGreaterThanOrEqualTo(String value) {
            addCriterion("updateuser >=", value, "updateuser");
            return (Criteria) this;
        }

        public Criteria andUpdateuserLessThan(String value) {
            addCriterion("updateuser <", value, "updateuser");
            return (Criteria) this;
        }

        public Criteria andUpdateuserLessThanOrEqualTo(String value) {
            addCriterion("updateuser <=", value, "updateuser");
            return (Criteria) this;
        }

        public Criteria andUpdateuserLike(String value) {
            addCriterion("updateuser like", value, "updateuser");
            return (Criteria) this;
        }

        public Criteria andUpdateuserNotLike(String value) {
            addCriterion("updateuser not like", value, "updateuser");
            return (Criteria) this;
        }

        public Criteria andUpdateuserIn(List<String> values) {
            addCriterion("updateuser in", values, "updateuser");
            return (Criteria) this;
        }

        public Criteria andUpdateuserNotIn(List<String> values) {
            addCriterion("updateuser not in", values, "updateuser");
            return (Criteria) this;
        }

        public Criteria andUpdateuserBetween(String value1, String value2) {
            addCriterion("updateuser between", value1, value2, "updateuser");
            return (Criteria) this;
        }

        public Criteria andUpdateuserNotBetween(String value1, String value2) {
            addCriterion("updateuser not between", value1, value2, "updateuser");
            return (Criteria) this;
        }

        public Criteria andUpdatetimeIsNull() {
            addCriterion("updatetime is null");
            return (Criteria) this;
        }

        public Criteria andUpdatetimeIsNotNull() {
            addCriterion("updatetime is not null");
            return (Criteria) this;
        }

        public Criteria andUpdatetimeEqualTo(Date value) {
            addCriterion("updatetime =", value, "updatetime");
            return (Criteria) this;
        }

        public Criteria andUpdatetimeNotEqualTo(Date value) {
            addCriterion("updatetime <>", value, "updatetime");
            return (Criteria) this;
        }

        public Criteria andUpdatetimeGreaterThan(Date value) {
            addCriterion("updatetime >", value, "updatetime");
            return (Criteria) this;
        }

        public Criteria andUpdatetimeGreaterThanOrEqualTo(Date value) {
            addCriterion("updatetime >=", value, "updatetime");
            return (Criteria) this;
        }

        public Criteria andUpdatetimeLessThan(Date value) {
            addCriterion("updatetime <", value, "updatetime");
            return (Criteria) this;
        }

        public Criteria andUpdatetimeLessThanOrEqualTo(Date value) {
            addCriterion("updatetime <=", value, "updatetime");
            return (Criteria) this;
        }

        public Criteria andUpdatetimeIn(List<Date> values) {
            addCriterion("updatetime in", values, "updatetime");
            return (Criteria) this;
        }

        public Criteria andUpdatetimeNotIn(List<Date> values) {
            addCriterion("updatetime not in", values, "updatetime");
            return (Criteria) this;
        }

        public Criteria andUpdatetimeBetween(Date value1, Date value2) {
            addCriterion("updatetime between", value1, value2, "updatetime");
            return (Criteria) this;
        }

        public Criteria andUpdatetimeNotBetween(Date value1, Date value2) {
            addCriterion("updatetime not between", value1, value2, "updatetime");
            return (Criteria) this;
        }

        public Criteria andDrIsNull() {
            addCriterion("dr is null");
            return (Criteria) this;
        }

        public Criteria andDrIsNotNull() {
            addCriterion("dr is not null");
            return (Criteria) this;
        }

        public Criteria andDrEqualTo(Integer value) {
            addCriterion("dr =", value, "dr");
            return (Criteria) this;
        }

        public Criteria andDrNotEqualTo(Integer value) {
            addCriterion("dr <>", value, "dr");
            return (Criteria) this;
        }

        public Criteria andDrGreaterThan(Integer value) {
            addCriterion("dr >", value, "dr");
            return (Criteria) this;
        }

        public Criteria andDrGreaterThanOrEqualTo(Integer value) {
            addCriterion("dr >=", value, "dr");
            return (Criteria) this;
        }

        public Criteria andDrLessThan(Integer value) {
            addCriterion("dr <", value, "dr");
            return (Criteria) this;
        }

        public Criteria andDrLessThanOrEqualTo(Integer value) {
            addCriterion("dr <=", value, "dr");
            return (Criteria) this;
        }

        public Criteria andDrIn(List<Integer> values) {
            addCriterion("dr in", values, "dr");
            return (Criteria) this;
        }

        public Criteria andDrNotIn(List<Integer> values) {
            addCriterion("dr not in", values, "dr");
            return (Criteria) this;
        }

        public Criteria andDrBetween(Integer value1, Integer value2) {
            addCriterion("dr between", value1, value2, "dr");
            return (Criteria) this;
        }

        public Criteria andDrNotBetween(Integer value1, Integer value2) {
            addCriterion("dr not between", value1, value2, "dr");
            return (Criteria) this;
        }
    }

    public static class Criteria extends GeneratedCriteria {

        protected Criteria() {
            super();
        }
    }

    public static class Criterion {
        private String condition;

        private Object value;

        private Object secondValue;

        private boolean noValue;

        private boolean singleValue;

        private boolean betweenValue;

        private boolean listValue;

        private String typeHandler;

        public String getCondition() {
            return condition;
        }

        public Object getValue() {
            return value;
        }

        public Object getSecondValue() {
            return secondValue;
        }

        public boolean isNoValue() {
            return noValue;
        }

        public boolean isSingleValue() {
            return singleValue;
        }

        public boolean isBetweenValue() {
            return betweenValue;
        }

        public boolean isListValue() {
            return listValue;
        }

        public String getTypeHandler() {
            return typeHandler;
        }

        protected Criterion(String condition) {
            super();
            this.condition = condition;
            this.typeHandler = null;
            this.noValue = true;
        }

        protected Criterion(String condition, Object value, String typeHandler) {
            super();
            this.condition = condition;
            this.value = value;
            this.typeHandler = typeHandler;
            if (value instanceof List<?>) {
                this.listValue = true;
            } else {
                this.singleValue = true;
            }
        }

        protected Criterion(String condition, Object value) {
            this(condition, value, null);
        }

        protected Criterion(String condition, Object value, Object secondValue, String typeHandler) {
            super();
            this.condition = condition;
            this.value = value;
            this.secondValue = secondValue;
            this.typeHandler = typeHandler;
            this.betweenValue = true;
        }

        protected Criterion(String condition, Object value, Object secondValue) {
            this(condition, value, secondValue, null);
        }
    }
}
