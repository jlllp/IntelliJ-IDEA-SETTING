package com.mrk.finance.query;
import com.mrk.common.utils.text.CheckUtil;

/**
 * @author 自动生成工具
 * @date   2021/11/10
 */
public class FncContractRentQuery {
	private String updateuserNotLike;
	private java.util.List updateuserNotIn;
	private String updateuserNotEqualTo;
	private String updateuserLike;
	private String updateuserLessThanOrEqualTo;
	private String updateuserLessThan;
	private Boolean updateuserIsNull;
	private Boolean updateuserIsNotNull;
	private java.util.List updateuserIn;
	private String updateuserGreaterThanOrEqualTo;
	private String updateuserGreaterThan;
	private String updateuserEqualTo;
	private java.util.List updatetimeNotIn;
	private java.util.Date updatetimeNotEqualTo;
	private java.util.Date updatetimeLessThanOrEqualTo;
	private java.util.Date updatetimeLessThan;
	private Boolean updatetimeIsNull;
	private Boolean updatetimeIsNotNull;
	private java.util.List updatetimeIn;
	private java.util.Date updatetimeGreaterThanOrEqualTo;
	private java.util.Date updatetimeGreaterThan;
	private java.util.Date updatetimeEqualTo;
	private String remarkNotLike;
	private java.util.List remarkNotIn;
	private String remarkNotEqualTo;
	private String remarkLike;
	private String remarkLessThanOrEqualTo;
	private String remarkLessThan;
	private Boolean remarkIsNull;
	private Boolean remarkIsNotNull;
	private java.util.List remarkIn;
	private String remarkGreaterThanOrEqualTo;
	private String remarkGreaterThan;
	private String remarkEqualTo;
	private java.util.List fccStartMonthNotIn;
	private Integer fccStartMonthNotEqualTo;
	private Integer fccStartMonthLessThanOrEqualTo;
	private Integer fccStartMonthLessThan;
	private Boolean fccStartMonthIsNull;
	private Boolean fccStartMonthIsNotNull;
	private java.util.List fccStartMonthIn;
	private Integer fccStartMonthGreaterThanOrEqualTo;
	private Integer fccStartMonthGreaterThan;
	private Integer fccStartMonthEqualTo;
	private java.util.List fccRentAmountNotIn;
	private Double fccRentAmountNotEqualTo;
	private Double fccRentAmountLessThanOrEqualTo;
	private Double fccRentAmountLessThan;
	private Boolean fccRentAmountIsNull;
	private Boolean fccRentAmountIsNotNull;
	private java.util.List fccRentAmountIn;
	private Double fccRentAmountGreaterThanOrEqualTo;
	private Double fccRentAmountGreaterThan;
	private Double fccRentAmountEqualTo;
	private java.util.List fccIdNotIn;
	private Long fccIdNotEqualTo;
	private Long fccIdLessThanOrEqualTo;
	private Long fccIdLessThan;
	private Boolean fccIdIsNull;
	private Boolean fccIdIsNotNull;
	private java.util.List fccIdIn;
	private Long fccIdGreaterThanOrEqualTo;
	private Long fccIdGreaterThan;
	private Long fccIdEqualTo;
	private java.util.List fccEndMonthNotIn;
	private Integer fccEndMonthNotEqualTo;
	private Integer fccEndMonthLessThanOrEqualTo;
	private Integer fccEndMonthLessThan;
	private Boolean fccEndMonthIsNull;
	private Boolean fccEndMonthIsNotNull;
	private java.util.List fccEndMonthIn;
	private Integer fccEndMonthGreaterThanOrEqualTo;
	private Integer fccEndMonthGreaterThan;
	private Integer fccEndMonthEqualTo;
	private java.util.List fccContractIdNotIn;
	private Long fccContractIdNotEqualTo;
	private Long fccContractIdLessThanOrEqualTo;
	private Long fccContractIdLessThan;
	private Boolean fccContractIdIsNull;
	private Boolean fccContractIdIsNotNull;
	private java.util.List fccContractIdIn;
	private Long fccContractIdGreaterThanOrEqualTo;
	private Long fccContractIdGreaterThan;
	private Long fccContractIdEqualTo;
	private java.util.List drNotIn;
	private Integer drNotEqualTo;
	private Integer drLessThanOrEqualTo;
	private Integer drLessThan;
	private Boolean drIsNull;
	private Boolean drIsNotNull;
	private java.util.List drIn;
	private Integer drGreaterThanOrEqualTo;
	private Integer drGreaterThan;
	private Integer drEqualTo;
	private String createuserNotLike;
	private java.util.List createuserNotIn;
	private String createuserNotEqualTo;
	private String createuserLike;
	private String createuserLessThanOrEqualTo;
	private String createuserLessThan;
	private Boolean createuserIsNull;
	private Boolean createuserIsNotNull;
	private java.util.List createuserIn;
	private String createuserGreaterThanOrEqualTo;
	private String createuserGreaterThan;
	private String createuserEqualTo;
	private java.util.List createtimeNotIn;
	private java.util.Date createtimeNotEqualTo;
	private java.util.Date createtimeLessThanOrEqualTo;
	private java.util.Date createtimeLessThan;
	private Boolean createtimeIsNull;
	private Boolean createtimeIsNotNull;
	private java.util.List createtimeIn;
	private java.util.Date createtimeGreaterThanOrEqualTo;
	private java.util.Date createtimeGreaterThan;
	private java.util.Date createtimeEqualTo;
	private String sidx;
	private String sord;
	public String getSidx(){
		if(this.sidx == null){
			return "";
		}
		else if("updateuser".equals(this.sidx)){
			return "updateuser";
		}
		else if("updatetime".equals(this.sidx)){
			return "updatetime";
		}
		else if("remark".equals(this.sidx)){
			return "remark";
		}
		else if("fccMonth".equals(this.sidx)){
			return "fcc_month";
		}
		else if("fccRentAmount".equals(this.sidx)){
			return "fcc_rent_amount";
		}
		else if("fccId".equals(this.sidx)){
			return "fcc_id";
		}
		else if("fccContractId".equals(this.sidx)){
			return "fcc_contract_id";
		}
		else if("dr".equals(this.sidx)){
			return "dr";
		}
		else if("createuser".equals(this.sidx)){
			return "createuser";
		}
		else if("createtime".equals(this.sidx)){
			return "createtime";
		}
		return this.sidx;
	}

	@com.fasterxml.jackson.annotation.JsonIgnore
	public com.mrk.finance.example.FncContractRentExample getCrieria(){
		com.mrk.finance.example.FncContractRentExample q = new com.mrk.finance.example.FncContractRentExample();
		com.mrk.finance.example.FncContractRentExample.Criteria c = q.createCriteria();
		c.andDrEqualTo(0);
		if(CheckUtil.isNotEmpty(getUpdateuserNotLike())){
			c.andUpdateuserNotLike("%"+this.getUpdateuserNotLike()+"%");
		}
		if(CheckUtil.isNotEmpty(getUpdateuserNotIn())){
			c.andUpdateuserNotIn(this.getUpdateuserNotIn());
		}
		if(CheckUtil.isNotEmpty(getUpdateuserNotEqualTo())){
			c.andUpdateuserNotEqualTo(this.getUpdateuserNotEqualTo());
		}
		if(CheckUtil.isNotEmpty(getUpdateuserLike())){
			c.andUpdateuserLike("%"+this.getUpdateuserLike()+"%");
		}
		if(CheckUtil.isNotEmpty(getUpdateuserLessThanOrEqualTo())){
			c.andUpdateuserLessThanOrEqualTo(this.getUpdateuserLessThanOrEqualTo());
		}
		if(CheckUtil.isNotEmpty(getUpdateuserLessThan())){
			c.andUpdateuserLessThan(this.getUpdateuserLessThan());
		}
		if(CheckUtil.isNotEmpty(getUpdateuserIsNull()) && this.getUpdateuserIsNull()){
			c.andUpdateuserIsNull();
		}
		if(CheckUtil.isNotEmpty(getUpdateuserIsNotNull()) && this.getUpdateuserIsNotNull()){
			c.andUpdateuserIsNotNull();
		}
		if(CheckUtil.isNotEmpty(getUpdateuserIn())){
			c.andUpdateuserIn(this.getUpdateuserIn());
		}
		if(CheckUtil.isNotEmpty(getUpdateuserGreaterThanOrEqualTo())){
			c.andUpdateuserGreaterThanOrEqualTo(this.getUpdateuserGreaterThanOrEqualTo());
		}
		if(CheckUtil.isNotEmpty(getUpdateuserGreaterThan())){
			c.andUpdateuserGreaterThan(this.getUpdateuserGreaterThan());
		}
		if(CheckUtil.isNotEmpty(getUpdateuserEqualTo())){
			c.andUpdateuserEqualTo(this.getUpdateuserEqualTo());
		}
		if(CheckUtil.isNotEmpty(getUpdatetimeNotIn())){
			c.andUpdatetimeNotIn(this.getUpdatetimeNotIn());
		}
		if(CheckUtil.isNotEmpty(getUpdatetimeNotEqualTo())){
			c.andUpdatetimeNotEqualTo(this.getUpdatetimeNotEqualTo());
		}
		if(CheckUtil.isNotEmpty(getUpdatetimeLessThanOrEqualTo())){
			c.andUpdatetimeLessThanOrEqualTo(this.getUpdatetimeLessThanOrEqualTo());
		}
		if(CheckUtil.isNotEmpty(getUpdatetimeLessThan())){
			c.andUpdatetimeLessThan(this.getUpdatetimeLessThan());
		}
		if(CheckUtil.isNotEmpty(getUpdatetimeIsNull()) && this.getUpdatetimeIsNull()){
			c.andUpdatetimeIsNull();
		}
		if(CheckUtil.isNotEmpty(getUpdatetimeIsNotNull()) && this.getUpdatetimeIsNotNull()){
			c.andUpdatetimeIsNotNull();
		}
		if(CheckUtil.isNotEmpty(getUpdatetimeIn())){
			c.andUpdatetimeIn(this.getUpdatetimeIn());
		}
		if(CheckUtil.isNotEmpty(getUpdatetimeGreaterThanOrEqualTo())){
			c.andUpdatetimeGreaterThanOrEqualTo(this.getUpdatetimeGreaterThanOrEqualTo());
		}
		if(CheckUtil.isNotEmpty(getUpdatetimeGreaterThan())){
			c.andUpdatetimeGreaterThan(this.getUpdatetimeGreaterThan());
		}
		if(CheckUtil.isNotEmpty(getUpdatetimeEqualTo())){
			c.andUpdatetimeEqualTo(this.getUpdatetimeEqualTo());
		}
		if(CheckUtil.isNotEmpty(getRemarkNotLike())){
			c.andRemarkNotLike("%"+this.getRemarkNotLike()+"%");
		}
		if(CheckUtil.isNotEmpty(getRemarkNotIn())){
			c.andRemarkNotIn(this.getRemarkNotIn());
		}
		if(CheckUtil.isNotEmpty(getRemarkNotEqualTo())){
			c.andRemarkNotEqualTo(this.getRemarkNotEqualTo());
		}
		if(CheckUtil.isNotEmpty(getRemarkLike())){
			c.andRemarkLike("%"+this.getRemarkLike()+"%");
		}
		if(CheckUtil.isNotEmpty(getRemarkLessThanOrEqualTo())){
			c.andRemarkLessThanOrEqualTo(this.getRemarkLessThanOrEqualTo());
		}
		if(CheckUtil.isNotEmpty(getRemarkLessThan())){
			c.andRemarkLessThan(this.getRemarkLessThan());
		}
		if(CheckUtil.isNotEmpty(getRemarkIsNull()) && this.getRemarkIsNull()){
			c.andRemarkIsNull();
		}
		if(CheckUtil.isNotEmpty(getRemarkIsNotNull()) && this.getRemarkIsNotNull()){
			c.andRemarkIsNotNull();
		}
		if(CheckUtil.isNotEmpty(getRemarkIn())){
			c.andRemarkIn(this.getRemarkIn());
		}
		if(CheckUtil.isNotEmpty(getRemarkGreaterThanOrEqualTo())){
			c.andRemarkGreaterThanOrEqualTo(this.getRemarkGreaterThanOrEqualTo());
		}
		if(CheckUtil.isNotEmpty(getRemarkGreaterThan())){
			c.andRemarkGreaterThan(this.getRemarkGreaterThan());
		}
		if(CheckUtil.isNotEmpty(getRemarkEqualTo())){
			c.andRemarkEqualTo(this.getRemarkEqualTo());
		}
		if(CheckUtil.isNotEmpty(getFccStartMonthNotIn())){
			c.andFccStartMonthNotIn(this.getFccStartMonthNotIn());
		}
		if(CheckUtil.isNotEmpty(getFccStartMonthNotEqualTo())){
			c.andFccStartMonthNotEqualTo(this.getFccStartMonthNotEqualTo());
		}
		if(CheckUtil.isNotEmpty(getFccStartMonthLessThanOrEqualTo())){
			c.andFccStartMonthLessThanOrEqualTo(this.getFccStartMonthLessThanOrEqualTo());
		}
		if(CheckUtil.isNotEmpty(getFccStartMonthLessThan())){
			c.andFccStartMonthLessThan(this.getFccStartMonthLessThan());
		}
		if(CheckUtil.isNotEmpty(getFccStartMonthIsNull()) && this.getFccStartMonthIsNull()){
			c.andFccStartMonthIsNull();
		}
		if(CheckUtil.isNotEmpty(getFccStartMonthIsNotNull()) && this.getFccStartMonthIsNotNull()){
			c.andFccStartMonthIsNotNull();
		}
		if(CheckUtil.isNotEmpty(getFccStartMonthIn())){
			c.andFccStartMonthIn(this.getFccStartMonthIn());
		}
		if(CheckUtil.isNotEmpty(getFccStartMonthGreaterThanOrEqualTo())){
			c.andFccStartMonthGreaterThanOrEqualTo(this.getFccStartMonthGreaterThanOrEqualTo());
		}
		if(CheckUtil.isNotEmpty(getFccStartMonthGreaterThan())){
			c.andFccStartMonthGreaterThan(this.getFccStartMonthGreaterThan());
		}
		if(CheckUtil.isNotEmpty(getFccStartMonthEqualTo())){
			c.andFccStartMonthEqualTo(this.getFccStartMonthEqualTo());
		}
		if(CheckUtil.isNotEmpty(getFccRentAmountNotIn())){
			c.andFccRentAmountNotIn(this.getFccRentAmountNotIn());
		}
		if(CheckUtil.isNotEmpty(getFccRentAmountNotEqualTo())){
			c.andFccRentAmountNotEqualTo(this.getFccRentAmountNotEqualTo());
		}
		if(CheckUtil.isNotEmpty(getFccRentAmountLessThanOrEqualTo())){
			c.andFccRentAmountLessThanOrEqualTo(this.getFccRentAmountLessThanOrEqualTo());
		}
		if(CheckUtil.isNotEmpty(getFccRentAmountLessThan())){
			c.andFccRentAmountLessThan(this.getFccRentAmountLessThan());
		}
		if(CheckUtil.isNotEmpty(getFccRentAmountIsNull()) && this.getFccRentAmountIsNull()){
			c.andFccRentAmountIsNull();
		}
		if(CheckUtil.isNotEmpty(getFccRentAmountIsNotNull()) && this.getFccRentAmountIsNotNull()){
			c.andFccRentAmountIsNotNull();
		}
		if(CheckUtil.isNotEmpty(getFccRentAmountIn())){
			c.andFccRentAmountIn(this.getFccRentAmountIn());
		}
		if(CheckUtil.isNotEmpty(getFccRentAmountGreaterThanOrEqualTo())){
			c.andFccRentAmountGreaterThanOrEqualTo(this.getFccRentAmountGreaterThanOrEqualTo());
		}
		if(CheckUtil.isNotEmpty(getFccRentAmountGreaterThan())){
			c.andFccRentAmountGreaterThan(this.getFccRentAmountGreaterThan());
		}
		if(CheckUtil.isNotEmpty(getFccRentAmountEqualTo())){
			c.andFccRentAmountEqualTo(this.getFccRentAmountEqualTo());
		}
		if(CheckUtil.isNotEmpty(getFccIdNotIn())){
			c.andFccIdNotIn(this.getFccIdNotIn());
		}
		if(CheckUtil.isNotEmpty(getFccIdNotEqualTo())){
			c.andFccIdNotEqualTo(this.getFccIdNotEqualTo());
		}
		if(CheckUtil.isNotEmpty(getFccIdLessThanOrEqualTo())){
			c.andFccIdLessThanOrEqualTo(this.getFccIdLessThanOrEqualTo());
		}
		if(CheckUtil.isNotEmpty(getFccIdLessThan())){
			c.andFccIdLessThan(this.getFccIdLessThan());
		}
		if(CheckUtil.isNotEmpty(getFccIdIsNull()) && this.getFccIdIsNull()){
			c.andFccIdIsNull();
		}
		if(CheckUtil.isNotEmpty(getFccIdIsNotNull()) && this.getFccIdIsNotNull()){
			c.andFccIdIsNotNull();
		}
		if(CheckUtil.isNotEmpty(getFccIdIn())){
			c.andFccIdIn(this.getFccIdIn());
		}
		if(CheckUtil.isNotEmpty(getFccIdGreaterThanOrEqualTo())){
			c.andFccIdGreaterThanOrEqualTo(this.getFccIdGreaterThanOrEqualTo());
		}
		if(CheckUtil.isNotEmpty(getFccIdGreaterThan())){
			c.andFccIdGreaterThan(this.getFccIdGreaterThan());
		}
		if(CheckUtil.isNotEmpty(getFccIdEqualTo())){
			c.andFccIdEqualTo(this.getFccIdEqualTo());
		}
		if(CheckUtil.isNotEmpty(getFccEndMonthNotIn())){
			c.andFccEndMonthNotIn(this.getFccEndMonthNotIn());
		}
		if(CheckUtil.isNotEmpty(getFccEndMonthNotEqualTo())){
			c.andFccEndMonthNotEqualTo(this.getFccEndMonthNotEqualTo());
		}
		if(CheckUtil.isNotEmpty(getFccEndMonthLessThanOrEqualTo())){
			c.andFccEndMonthLessThanOrEqualTo(this.getFccEndMonthLessThanOrEqualTo());
		}
		if(CheckUtil.isNotEmpty(getFccEndMonthLessThan())){
			c.andFccEndMonthLessThan(this.getFccEndMonthLessThan());
		}
		if(CheckUtil.isNotEmpty(getFccEndMonthIsNull()) && this.getFccEndMonthIsNull()){
			c.andFccEndMonthIsNull();
		}
		if(CheckUtil.isNotEmpty(getFccEndMonthIsNotNull()) && this.getFccEndMonthIsNotNull()){
			c.andFccEndMonthIsNotNull();
		}
		if(CheckUtil.isNotEmpty(getFccEndMonthIn())){
			c.andFccEndMonthIn(this.getFccEndMonthIn());
		}
		if(CheckUtil.isNotEmpty(getFccEndMonthGreaterThanOrEqualTo())){
			c.andFccEndMonthGreaterThanOrEqualTo(this.getFccEndMonthGreaterThanOrEqualTo());
		}
		if(CheckUtil.isNotEmpty(getFccEndMonthGreaterThan())){
			c.andFccEndMonthGreaterThan(this.getFccEndMonthGreaterThan());
		}
		if(CheckUtil.isNotEmpty(getFccEndMonthEqualTo())){
			c.andFccEndMonthEqualTo(this.getFccEndMonthEqualTo());
		}
		if(CheckUtil.isNotEmpty(getFccContractIdNotIn())){
			c.andFccContractIdNotIn(this.getFccContractIdNotIn());
		}
		if(CheckUtil.isNotEmpty(getFccContractIdNotEqualTo())){
			c.andFccContractIdNotEqualTo(this.getFccContractIdNotEqualTo());
		}
		if(CheckUtil.isNotEmpty(getFccContractIdLessThanOrEqualTo())){
			c.andFccContractIdLessThanOrEqualTo(this.getFccContractIdLessThanOrEqualTo());
		}
		if(CheckUtil.isNotEmpty(getFccContractIdLessThan())){
			c.andFccContractIdLessThan(this.getFccContractIdLessThan());
		}
		if(CheckUtil.isNotEmpty(getFccContractIdIsNull()) && this.getFccContractIdIsNull()){
			c.andFccContractIdIsNull();
		}
		if(CheckUtil.isNotEmpty(getFccContractIdIsNotNull()) && this.getFccContractIdIsNotNull()){
			c.andFccContractIdIsNotNull();
		}
		if(CheckUtil.isNotEmpty(getFccContractIdIn())){
			c.andFccContractIdIn(this.getFccContractIdIn());
		}
		if(CheckUtil.isNotEmpty(getFccContractIdGreaterThanOrEqualTo())){
			c.andFccContractIdGreaterThanOrEqualTo(this.getFccContractIdGreaterThanOrEqualTo());
		}
		if(CheckUtil.isNotEmpty(getFccContractIdGreaterThan())){
			c.andFccContractIdGreaterThan(this.getFccContractIdGreaterThan());
		}
		if(CheckUtil.isNotEmpty(getFccContractIdEqualTo())){
			c.andFccContractIdEqualTo(this.getFccContractIdEqualTo());
		}
		if(CheckUtil.isNotEmpty(getDrNotIn())){
			c.andDrNotIn(this.getDrNotIn());
		}
		if(CheckUtil.isNotEmpty(getDrNotEqualTo())){
			c.andDrNotEqualTo(this.getDrNotEqualTo());
		}
		if(CheckUtil.isNotEmpty(getDrLessThanOrEqualTo())){
			c.andDrLessThanOrEqualTo(this.getDrLessThanOrEqualTo());
		}
		if(CheckUtil.isNotEmpty(getDrLessThan())){
			c.andDrLessThan(this.getDrLessThan());
		}
		if(CheckUtil.isNotEmpty(getDrIsNull()) && this.getDrIsNull()){
			c.andDrIsNull();
		}
		if(CheckUtil.isNotEmpty(getDrIsNotNull()) && this.getDrIsNotNull()){
			c.andDrIsNotNull();
		}
		if(CheckUtil.isNotEmpty(getDrIn())){
			c.andDrIn(this.getDrIn());
		}
		if(CheckUtil.isNotEmpty(getDrGreaterThanOrEqualTo())){
			c.andDrGreaterThanOrEqualTo(this.getDrGreaterThanOrEqualTo());
		}
		if(CheckUtil.isNotEmpty(getDrGreaterThan())){
			c.andDrGreaterThan(this.getDrGreaterThan());
		}
		if(CheckUtil.isNotEmpty(getDrEqualTo())){
			c.andDrEqualTo(this.getDrEqualTo());
		}
		if(CheckUtil.isNotEmpty(getCreateuserNotLike())){
			c.andCreateuserNotLike("%"+this.getCreateuserNotLike()+"%");
		}
		if(CheckUtil.isNotEmpty(getCreateuserNotIn())){
			c.andCreateuserNotIn(this.getCreateuserNotIn());
		}
		if(CheckUtil.isNotEmpty(getCreateuserNotEqualTo())){
			c.andCreateuserNotEqualTo(this.getCreateuserNotEqualTo());
		}
		if(CheckUtil.isNotEmpty(getCreateuserLike())){
			c.andCreateuserLike("%"+this.getCreateuserLike()+"%");
		}
		if(CheckUtil.isNotEmpty(getCreateuserLessThanOrEqualTo())){
			c.andCreateuserLessThanOrEqualTo(this.getCreateuserLessThanOrEqualTo());
		}
		if(CheckUtil.isNotEmpty(getCreateuserLessThan())){
			c.andCreateuserLessThan(this.getCreateuserLessThan());
		}
		if(CheckUtil.isNotEmpty(getCreateuserIsNull()) && this.getCreateuserIsNull()){
			c.andCreateuserIsNull();
		}
		if(CheckUtil.isNotEmpty(getCreateuserIsNotNull()) && this.getCreateuserIsNotNull()){
			c.andCreateuserIsNotNull();
		}
		if(CheckUtil.isNotEmpty(getCreateuserIn())){
			c.andCreateuserIn(this.getCreateuserIn());
		}
		if(CheckUtil.isNotEmpty(getCreateuserGreaterThanOrEqualTo())){
			c.andCreateuserGreaterThanOrEqualTo(this.getCreateuserGreaterThanOrEqualTo());
		}
		if(CheckUtil.isNotEmpty(getCreateuserGreaterThan())){
			c.andCreateuserGreaterThan(this.getCreateuserGreaterThan());
		}
		if(CheckUtil.isNotEmpty(getCreateuserEqualTo())){
			c.andCreateuserEqualTo(this.getCreateuserEqualTo());
		}
		if(CheckUtil.isNotEmpty(getCreatetimeNotIn())){
			c.andCreatetimeNotIn(this.getCreatetimeNotIn());
		}
		if(CheckUtil.isNotEmpty(getCreatetimeNotEqualTo())){
			c.andCreatetimeNotEqualTo(this.getCreatetimeNotEqualTo());
		}
		if(CheckUtil.isNotEmpty(getCreatetimeLessThanOrEqualTo())){
			c.andCreatetimeLessThanOrEqualTo(this.getCreatetimeLessThanOrEqualTo());
		}
		if(CheckUtil.isNotEmpty(getCreatetimeLessThan())){
			c.andCreatetimeLessThan(this.getCreatetimeLessThan());
		}
		if(CheckUtil.isNotEmpty(getCreatetimeIsNull()) && this.getCreatetimeIsNull()){
			c.andCreatetimeIsNull();
		}
		if(CheckUtil.isNotEmpty(getCreatetimeIsNotNull()) && this.getCreatetimeIsNotNull()){
			c.andCreatetimeIsNotNull();
		}
		if(CheckUtil.isNotEmpty(getCreatetimeIn())){
			c.andCreatetimeIn(this.getCreatetimeIn());
		}
		if(CheckUtil.isNotEmpty(getCreatetimeGreaterThanOrEqualTo())){
			c.andCreatetimeGreaterThanOrEqualTo(this.getCreatetimeGreaterThanOrEqualTo());
		}
		if(CheckUtil.isNotEmpty(getCreatetimeGreaterThan())){
			c.andCreatetimeGreaterThan(this.getCreatetimeGreaterThan());
		}
		if(CheckUtil.isNotEmpty(getCreatetimeEqualTo())){
			c.andCreatetimeEqualTo(this.getCreatetimeEqualTo());
		}
		if((this.getSidx()!=null && !this.getSidx().trim().equals("")) && this.getSord()!=null) {
			q.setOrderByClause(""+ this.getSidx()+" "+this.getSord());
		}
		return q;
	}
	public String getUpdateuserNotLike() {
		return updateuserNotLike;
	}
	public void setUpdateuserNotLike(String updateuserNotLike) {
		this.updateuserNotLike = updateuserNotLike;
	}

	public java.util.List getUpdateuserNotIn() {
		return updateuserNotIn;
	}
	public void setUpdateuserNotIn(java.util.List updateuserNotIn) {
		this.updateuserNotIn = updateuserNotIn;
	}

	public String getUpdateuserNotEqualTo() {
		return updateuserNotEqualTo;
	}
	public void setUpdateuserNotEqualTo(String updateuserNotEqualTo) {
		this.updateuserNotEqualTo = updateuserNotEqualTo;
	}

	public String getUpdateuserLike() {
		return updateuserLike;
	}
	public void setUpdateuserLike(String updateuserLike) {
		this.updateuserLike = updateuserLike;
	}

	public String getUpdateuserLessThanOrEqualTo() {
		return updateuserLessThanOrEqualTo;
	}
	public void setUpdateuserLessThanOrEqualTo(String updateuserLessThanOrEqualTo) {
		this.updateuserLessThanOrEqualTo = updateuserLessThanOrEqualTo;
	}

	public String getUpdateuserLessThan() {
		return updateuserLessThan;
	}
	public void setUpdateuserLessThan(String updateuserLessThan) {
		this.updateuserLessThan = updateuserLessThan;
	}

	public Boolean getUpdateuserIsNull() {
		return updateuserIsNull;
	}
	public void setUpdateuserIsNull(Boolean updateuserIsNull) {
		this.updateuserIsNull = updateuserIsNull;
	}

	public Boolean getUpdateuserIsNotNull() {
		return updateuserIsNotNull;
	}
	public void setUpdateuserIsNotNull(Boolean updateuserIsNotNull) {
		this.updateuserIsNotNull = updateuserIsNotNull;
	}

	public java.util.List getUpdateuserIn() {
		return updateuserIn;
	}
	public void setUpdateuserIn(java.util.List updateuserIn) {
		this.updateuserIn = updateuserIn;
	}

	public String getUpdateuserGreaterThanOrEqualTo() {
		return updateuserGreaterThanOrEqualTo;
	}
	public void setUpdateuserGreaterThanOrEqualTo(String updateuserGreaterThanOrEqualTo) {
		this.updateuserGreaterThanOrEqualTo = updateuserGreaterThanOrEqualTo;
	}

	public String getUpdateuserGreaterThan() {
		return updateuserGreaterThan;
	}
	public void setUpdateuserGreaterThan(String updateuserGreaterThan) {
		this.updateuserGreaterThan = updateuserGreaterThan;
	}

	public String getUpdateuserEqualTo() {
		return updateuserEqualTo;
	}
	public void setUpdateuserEqualTo(String updateuserEqualTo) {
		this.updateuserEqualTo = updateuserEqualTo;
	}

	public java.util.List getUpdatetimeNotIn() {
		return updatetimeNotIn;
	}
	public void setUpdatetimeNotIn(java.util.List updatetimeNotIn) {
		this.updatetimeNotIn = updatetimeNotIn;
	}

	public java.util.Date getUpdatetimeNotEqualTo() {
		return updatetimeNotEqualTo;
	}
	public void setUpdatetimeNotEqualTo(java.util.Date updatetimeNotEqualTo) {
		this.updatetimeNotEqualTo = updatetimeNotEqualTo;
	}

	public java.util.Date getUpdatetimeLessThanOrEqualTo() {
		return updatetimeLessThanOrEqualTo;
	}
	public void setUpdatetimeLessThanOrEqualTo(java.util.Date updatetimeLessThanOrEqualTo) {
		this.updatetimeLessThanOrEqualTo = updatetimeLessThanOrEqualTo;
	}

	public java.util.Date getUpdatetimeLessThan() {
		return updatetimeLessThan;
	}
	public void setUpdatetimeLessThan(java.util.Date updatetimeLessThan) {
		this.updatetimeLessThan = updatetimeLessThan;
	}

	public Boolean getUpdatetimeIsNull() {
		return updatetimeIsNull;
	}
	public void setUpdatetimeIsNull(Boolean updatetimeIsNull) {
		this.updatetimeIsNull = updatetimeIsNull;
	}

	public Boolean getUpdatetimeIsNotNull() {
		return updatetimeIsNotNull;
	}
	public void setUpdatetimeIsNotNull(Boolean updatetimeIsNotNull) {
		this.updatetimeIsNotNull = updatetimeIsNotNull;
	}

	public java.util.List getUpdatetimeIn() {
		return updatetimeIn;
	}
	public void setUpdatetimeIn(java.util.List updatetimeIn) {
		this.updatetimeIn = updatetimeIn;
	}

	public java.util.Date getUpdatetimeGreaterThanOrEqualTo() {
		return updatetimeGreaterThanOrEqualTo;
	}
	public void setUpdatetimeGreaterThanOrEqualTo(java.util.Date updatetimeGreaterThanOrEqualTo) {
		this.updatetimeGreaterThanOrEqualTo = updatetimeGreaterThanOrEqualTo;
	}

	public java.util.Date getUpdatetimeGreaterThan() {
		return updatetimeGreaterThan;
	}
	public void setUpdatetimeGreaterThan(java.util.Date updatetimeGreaterThan) {
		this.updatetimeGreaterThan = updatetimeGreaterThan;
	}

	public java.util.Date getUpdatetimeEqualTo() {
		return updatetimeEqualTo;
	}
	public void setUpdatetimeEqualTo(java.util.Date updatetimeEqualTo) {
		this.updatetimeEqualTo = updatetimeEqualTo;
	}

	public String getRemarkNotLike() {
		return remarkNotLike;
	}
	public void setRemarkNotLike(String remarkNotLike) {
		this.remarkNotLike = remarkNotLike;
	}

	public java.util.List getRemarkNotIn() {
		return remarkNotIn;
	}
	public void setRemarkNotIn(java.util.List remarkNotIn) {
		this.remarkNotIn = remarkNotIn;
	}

	public String getRemarkNotEqualTo() {
		return remarkNotEqualTo;
	}
	public void setRemarkNotEqualTo(String remarkNotEqualTo) {
		this.remarkNotEqualTo = remarkNotEqualTo;
	}

	public String getRemarkLike() {
		return remarkLike;
	}
	public void setRemarkLike(String remarkLike) {
		this.remarkLike = remarkLike;
	}

	public String getRemarkLessThanOrEqualTo() {
		return remarkLessThanOrEqualTo;
	}
	public void setRemarkLessThanOrEqualTo(String remarkLessThanOrEqualTo) {
		this.remarkLessThanOrEqualTo = remarkLessThanOrEqualTo;
	}

	public String getRemarkLessThan() {
		return remarkLessThan;
	}
	public void setRemarkLessThan(String remarkLessThan) {
		this.remarkLessThan = remarkLessThan;
	}

	public Boolean getRemarkIsNull() {
		return remarkIsNull;
	}
	public void setRemarkIsNull(Boolean remarkIsNull) {
		this.remarkIsNull = remarkIsNull;
	}

	public Boolean getRemarkIsNotNull() {
		return remarkIsNotNull;
	}
	public void setRemarkIsNotNull(Boolean remarkIsNotNull) {
		this.remarkIsNotNull = remarkIsNotNull;
	}

	public java.util.List getRemarkIn() {
		return remarkIn;
	}
	public void setRemarkIn(java.util.List remarkIn) {
		this.remarkIn = remarkIn;
	}

	public String getRemarkGreaterThanOrEqualTo() {
		return remarkGreaterThanOrEqualTo;
	}
	public void setRemarkGreaterThanOrEqualTo(String remarkGreaterThanOrEqualTo) {
		this.remarkGreaterThanOrEqualTo = remarkGreaterThanOrEqualTo;
	}

	public String getRemarkGreaterThan() {
		return remarkGreaterThan;
	}
	public void setRemarkGreaterThan(String remarkGreaterThan) {
		this.remarkGreaterThan = remarkGreaterThan;
	}

	public String getRemarkEqualTo() {
		return remarkEqualTo;
	}
	public void setRemarkEqualTo(String remarkEqualTo) {
		this.remarkEqualTo = remarkEqualTo;
	}

	public java.util.List getFccStartMonthNotIn() {
		return fccStartMonthNotIn;
	}
	public void setFccStartMonthNotIn(java.util.List fccStartMonthNotIn) {
		this.fccStartMonthNotIn = fccStartMonthNotIn;
	}

	public Integer getFccStartMonthNotEqualTo() {
		return fccStartMonthNotEqualTo;
	}
	public void setFccStartMonthNotEqualTo(Integer fccStartMonthNotEqualTo) {
		this.fccStartMonthNotEqualTo = fccStartMonthNotEqualTo;
	}

	public Integer getFccStartMonthLessThanOrEqualTo() {
		return fccStartMonthLessThanOrEqualTo;
	}
	public void setFccStartMonthLessThanOrEqualTo(Integer fccStartMonthLessThanOrEqualTo) {
		this.fccStartMonthLessThanOrEqualTo = fccStartMonthLessThanOrEqualTo;
	}

	public Integer getFccStartMonthLessThan() {
		return fccStartMonthLessThan;
	}
	public void setFccStartMonthLessThan(Integer fccStartMonthLessThan) {
		this.fccStartMonthLessThan = fccStartMonthLessThan;
	}

	public Boolean getFccStartMonthIsNull() {
		return fccStartMonthIsNull;
	}
	public void setFccStartMonthIsNull(Boolean fccStartMonthIsNull) {
		this.fccStartMonthIsNull = fccStartMonthIsNull;
	}

	public Boolean getFccStartMonthIsNotNull() {
		return fccStartMonthIsNotNull;
	}
	public void setFccStartMonthIsNotNull(Boolean fccStartMonthIsNotNull) {
		this.fccStartMonthIsNotNull = fccStartMonthIsNotNull;
	}

	public java.util.List getFccStartMonthIn() {
		return fccStartMonthIn;
	}
	public void setFccStartMonthIn(java.util.List fccStartMonthIn) {
		this.fccStartMonthIn = fccStartMonthIn;
	}

	public Integer getFccStartMonthGreaterThanOrEqualTo() {
		return fccStartMonthGreaterThanOrEqualTo;
	}
	public void setFccStartMonthGreaterThanOrEqualTo(Integer fccStartMonthGreaterThanOrEqualTo) {
		this.fccStartMonthGreaterThanOrEqualTo = fccStartMonthGreaterThanOrEqualTo;
	}

	public Integer getFccStartMonthGreaterThan() {
		return fccStartMonthGreaterThan;
	}
	public void setFccStartMonthGreaterThan(Integer fccStartMonthGreaterThan) {
		this.fccStartMonthGreaterThan = fccStartMonthGreaterThan;
	}

	public Integer getFccStartMonthEqualTo() {
		return fccStartMonthEqualTo;
	}
	public void setFccStartMonthEqualTo(Integer fccStartMonthEqualTo) {
		this.fccStartMonthEqualTo = fccStartMonthEqualTo;
	}

	public java.util.List getFccRentAmountNotIn() {
		return fccRentAmountNotIn;
	}
	public void setFccRentAmountNotIn(java.util.List fccRentAmountNotIn) {
		this.fccRentAmountNotIn = fccRentAmountNotIn;
	}

	public Double getFccRentAmountNotEqualTo() {
		return fccRentAmountNotEqualTo;
	}
	public void setFccRentAmountNotEqualTo(Double fccRentAmountNotEqualTo) {
		this.fccRentAmountNotEqualTo = fccRentAmountNotEqualTo;
	}

	public Double getFccRentAmountLessThanOrEqualTo() {
		return fccRentAmountLessThanOrEqualTo;
	}
	public void setFccRentAmountLessThanOrEqualTo(Double fccRentAmountLessThanOrEqualTo) {
		this.fccRentAmountLessThanOrEqualTo = fccRentAmountLessThanOrEqualTo;
	}

	public Double getFccRentAmountLessThan() {
		return fccRentAmountLessThan;
	}
	public void setFccRentAmountLessThan(Double fccRentAmountLessThan) {
		this.fccRentAmountLessThan = fccRentAmountLessThan;
	}

	public Boolean getFccRentAmountIsNull() {
		return fccRentAmountIsNull;
	}
	public void setFccRentAmountIsNull(Boolean fccRentAmountIsNull) {
		this.fccRentAmountIsNull = fccRentAmountIsNull;
	}

	public Boolean getFccRentAmountIsNotNull() {
		return fccRentAmountIsNotNull;
	}
	public void setFccRentAmountIsNotNull(Boolean fccRentAmountIsNotNull) {
		this.fccRentAmountIsNotNull = fccRentAmountIsNotNull;
	}

	public java.util.List getFccRentAmountIn() {
		return fccRentAmountIn;
	}
	public void setFccRentAmountIn(java.util.List fccRentAmountIn) {
		this.fccRentAmountIn = fccRentAmountIn;
	}

	public Double getFccRentAmountGreaterThanOrEqualTo() {
		return fccRentAmountGreaterThanOrEqualTo;
	}
	public void setFccRentAmountGreaterThanOrEqualTo(Double fccRentAmountGreaterThanOrEqualTo) {
		this.fccRentAmountGreaterThanOrEqualTo = fccRentAmountGreaterThanOrEqualTo;
	}

	public Double getFccRentAmountGreaterThan() {
		return fccRentAmountGreaterThan;
	}
	public void setFccRentAmountGreaterThan(Double fccRentAmountGreaterThan) {
		this.fccRentAmountGreaterThan = fccRentAmountGreaterThan;
	}

	public Double getFccRentAmountEqualTo() {
		return fccRentAmountEqualTo;
	}
	public void setFccRentAmountEqualTo(Double fccRentAmountEqualTo) {
		this.fccRentAmountEqualTo = fccRentAmountEqualTo;
	}

	public java.util.List getFccIdNotIn() {
		return fccIdNotIn;
	}
	public void setFccIdNotIn(java.util.List fccIdNotIn) {
		this.fccIdNotIn = fccIdNotIn;
	}

	public Long getFccIdNotEqualTo() {
		return fccIdNotEqualTo;
	}
	public void setFccIdNotEqualTo(Long fccIdNotEqualTo) {
		this.fccIdNotEqualTo = fccIdNotEqualTo;
	}

	public Long getFccIdLessThanOrEqualTo() {
		return fccIdLessThanOrEqualTo;
	}
	public void setFccIdLessThanOrEqualTo(Long fccIdLessThanOrEqualTo) {
		this.fccIdLessThanOrEqualTo = fccIdLessThanOrEqualTo;
	}

	public Long getFccIdLessThan() {
		return fccIdLessThan;
	}
	public void setFccIdLessThan(Long fccIdLessThan) {
		this.fccIdLessThan = fccIdLessThan;
	}

	public Boolean getFccIdIsNull() {
		return fccIdIsNull;
	}
	public void setFccIdIsNull(Boolean fccIdIsNull) {
		this.fccIdIsNull = fccIdIsNull;
	}

	public Boolean getFccIdIsNotNull() {
		return fccIdIsNotNull;
	}
	public void setFccIdIsNotNull(Boolean fccIdIsNotNull) {
		this.fccIdIsNotNull = fccIdIsNotNull;
	}

	public java.util.List getFccIdIn() {
		return fccIdIn;
	}
	public void setFccIdIn(java.util.List fccIdIn) {
		this.fccIdIn = fccIdIn;
	}

	public Long getFccIdGreaterThanOrEqualTo() {
		return fccIdGreaterThanOrEqualTo;
	}
	public void setFccIdGreaterThanOrEqualTo(Long fccIdGreaterThanOrEqualTo) {
		this.fccIdGreaterThanOrEqualTo = fccIdGreaterThanOrEqualTo;
	}

	public Long getFccIdGreaterThan() {
		return fccIdGreaterThan;
	}
	public void setFccIdGreaterThan(Long fccIdGreaterThan) {
		this.fccIdGreaterThan = fccIdGreaterThan;
	}

	public Long getFccIdEqualTo() {
		return fccIdEqualTo;
	}
	public void setFccIdEqualTo(Long fccIdEqualTo) {
		this.fccIdEqualTo = fccIdEqualTo;
	}

	public java.util.List getFccEndMonthNotIn() {
		return fccEndMonthNotIn;
	}
	public void setFccEndMonthNotIn(java.util.List fccEndMonthNotIn) {
		this.fccEndMonthNotIn = fccEndMonthNotIn;
	}

	public Integer getFccEndMonthNotEqualTo() {
		return fccEndMonthNotEqualTo;
	}
	public void setFccEndMonthNotEqualTo(Integer fccEndMonthNotEqualTo) {
		this.fccEndMonthNotEqualTo = fccEndMonthNotEqualTo;
	}

	public Integer getFccEndMonthLessThanOrEqualTo() {
		return fccEndMonthLessThanOrEqualTo;
	}
	public void setFccEndMonthLessThanOrEqualTo(Integer fccEndMonthLessThanOrEqualTo) {
		this.fccEndMonthLessThanOrEqualTo = fccEndMonthLessThanOrEqualTo;
	}

	public Integer getFccEndMonthLessThan() {
		return fccEndMonthLessThan;
	}
	public void setFccEndMonthLessThan(Integer fccEndMonthLessThan) {
		this.fccEndMonthLessThan = fccEndMonthLessThan;
	}

	public Boolean getFccEndMonthIsNull() {
		return fccEndMonthIsNull;
	}
	public void setFccEndMonthIsNull(Boolean fccEndMonthIsNull) {
		this.fccEndMonthIsNull = fccEndMonthIsNull;
	}

	public Boolean getFccEndMonthIsNotNull() {
		return fccEndMonthIsNotNull;
	}
	public void setFccEndMonthIsNotNull(Boolean fccEndMonthIsNotNull) {
		this.fccEndMonthIsNotNull = fccEndMonthIsNotNull;
	}

	public java.util.List getFccEndMonthIn() {
		return fccEndMonthIn;
	}
	public void setFccEndMonthIn(java.util.List fccEndMonthIn) {
		this.fccEndMonthIn = fccEndMonthIn;
	}

	public Integer getFccEndMonthGreaterThanOrEqualTo() {
		return fccEndMonthGreaterThanOrEqualTo;
	}
	public void setFccEndMonthGreaterThanOrEqualTo(Integer fccEndMonthGreaterThanOrEqualTo) {
		this.fccEndMonthGreaterThanOrEqualTo = fccEndMonthGreaterThanOrEqualTo;
	}

	public Integer getFccEndMonthGreaterThan() {
		return fccEndMonthGreaterThan;
	}
	public void setFccEndMonthGreaterThan(Integer fccEndMonthGreaterThan) {
		this.fccEndMonthGreaterThan = fccEndMonthGreaterThan;
	}

	public Integer getFccEndMonthEqualTo() {
		return fccEndMonthEqualTo;
	}
	public void setFccEndMonthEqualTo(Integer fccEndMonthEqualTo) {
		this.fccEndMonthEqualTo = fccEndMonthEqualTo;
	}

	public java.util.List getFccContractIdNotIn() {
		return fccContractIdNotIn;
	}
	public void setFccContractIdNotIn(java.util.List fccContractIdNotIn) {
		this.fccContractIdNotIn = fccContractIdNotIn;
	}

	public Long getFccContractIdNotEqualTo() {
		return fccContractIdNotEqualTo;
	}
	public void setFccContractIdNotEqualTo(Long fccContractIdNotEqualTo) {
		this.fccContractIdNotEqualTo = fccContractIdNotEqualTo;
	}

	public Long getFccContractIdLessThanOrEqualTo() {
		return fccContractIdLessThanOrEqualTo;
	}
	public void setFccContractIdLessThanOrEqualTo(Long fccContractIdLessThanOrEqualTo) {
		this.fccContractIdLessThanOrEqualTo = fccContractIdLessThanOrEqualTo;
	}

	public Long getFccContractIdLessThan() {
		return fccContractIdLessThan;
	}
	public void setFccContractIdLessThan(Long fccContractIdLessThan) {
		this.fccContractIdLessThan = fccContractIdLessThan;
	}

	public Boolean getFccContractIdIsNull() {
		return fccContractIdIsNull;
	}
	public void setFccContractIdIsNull(Boolean fccContractIdIsNull) {
		this.fccContractIdIsNull = fccContractIdIsNull;
	}

	public Boolean getFccContractIdIsNotNull() {
		return fccContractIdIsNotNull;
	}
	public void setFccContractIdIsNotNull(Boolean fccContractIdIsNotNull) {
		this.fccContractIdIsNotNull = fccContractIdIsNotNull;
	}

	public java.util.List getFccContractIdIn() {
		return fccContractIdIn;
	}
	public void setFccContractIdIn(java.util.List fccContractIdIn) {
		this.fccContractIdIn = fccContractIdIn;
	}

	public Long getFccContractIdGreaterThanOrEqualTo() {
		return fccContractIdGreaterThanOrEqualTo;
	}
	public void setFccContractIdGreaterThanOrEqualTo(Long fccContractIdGreaterThanOrEqualTo) {
		this.fccContractIdGreaterThanOrEqualTo = fccContractIdGreaterThanOrEqualTo;
	}

	public Long getFccContractIdGreaterThan() {
		return fccContractIdGreaterThan;
	}
	public void setFccContractIdGreaterThan(Long fccContractIdGreaterThan) {
		this.fccContractIdGreaterThan = fccContractIdGreaterThan;
	}

	public Long getFccContractIdEqualTo() {
		return fccContractIdEqualTo;
	}
	public void setFccContractIdEqualTo(Long fccContractIdEqualTo) {
		this.fccContractIdEqualTo = fccContractIdEqualTo;
	}

	public java.util.List getDrNotIn() {
		return drNotIn;
	}
	public void setDrNotIn(java.util.List drNotIn) {
		this.drNotIn = drNotIn;
	}

	public Integer getDrNotEqualTo() {
		return drNotEqualTo;
	}
	public void setDrNotEqualTo(Integer drNotEqualTo) {
		this.drNotEqualTo = drNotEqualTo;
	}

	public Integer getDrLessThanOrEqualTo() {
		return drLessThanOrEqualTo;
	}
	public void setDrLessThanOrEqualTo(Integer drLessThanOrEqualTo) {
		this.drLessThanOrEqualTo = drLessThanOrEqualTo;
	}

	public Integer getDrLessThan() {
		return drLessThan;
	}
	public void setDrLessThan(Integer drLessThan) {
		this.drLessThan = drLessThan;
	}

	public Boolean getDrIsNull() {
		return drIsNull;
	}
	public void setDrIsNull(Boolean drIsNull) {
		this.drIsNull = drIsNull;
	}

	public Boolean getDrIsNotNull() {
		return drIsNotNull;
	}
	public void setDrIsNotNull(Boolean drIsNotNull) {
		this.drIsNotNull = drIsNotNull;
	}

	public java.util.List getDrIn() {
		return drIn;
	}
	public void setDrIn(java.util.List drIn) {
		this.drIn = drIn;
	}

	public Integer getDrGreaterThanOrEqualTo() {
		return drGreaterThanOrEqualTo;
	}
	public void setDrGreaterThanOrEqualTo(Integer drGreaterThanOrEqualTo) {
		this.drGreaterThanOrEqualTo = drGreaterThanOrEqualTo;
	}

	public Integer getDrGreaterThan() {
		return drGreaterThan;
	}
	public void setDrGreaterThan(Integer drGreaterThan) {
		this.drGreaterThan = drGreaterThan;
	}

	public Integer getDrEqualTo() {
		return drEqualTo;
	}
	public void setDrEqualTo(Integer drEqualTo) {
		this.drEqualTo = drEqualTo;
	}

	public String getCreateuserNotLike() {
		return createuserNotLike;
	}
	public void setCreateuserNotLike(String createuserNotLike) {
		this.createuserNotLike = createuserNotLike;
	}

	public java.util.List getCreateuserNotIn() {
		return createuserNotIn;
	}
	public void setCreateuserNotIn(java.util.List createuserNotIn) {
		this.createuserNotIn = createuserNotIn;
	}

	public String getCreateuserNotEqualTo() {
		return createuserNotEqualTo;
	}
	public void setCreateuserNotEqualTo(String createuserNotEqualTo) {
		this.createuserNotEqualTo = createuserNotEqualTo;
	}

	public String getCreateuserLike() {
		return createuserLike;
	}
	public void setCreateuserLike(String createuserLike) {
		this.createuserLike = createuserLike;
	}

	public String getCreateuserLessThanOrEqualTo() {
		return createuserLessThanOrEqualTo;
	}
	public void setCreateuserLessThanOrEqualTo(String createuserLessThanOrEqualTo) {
		this.createuserLessThanOrEqualTo = createuserLessThanOrEqualTo;
	}

	public String getCreateuserLessThan() {
		return createuserLessThan;
	}
	public void setCreateuserLessThan(String createuserLessThan) {
		this.createuserLessThan = createuserLessThan;
	}

	public Boolean getCreateuserIsNull() {
		return createuserIsNull;
	}
	public void setCreateuserIsNull(Boolean createuserIsNull) {
		this.createuserIsNull = createuserIsNull;
	}

	public Boolean getCreateuserIsNotNull() {
		return createuserIsNotNull;
	}
	public void setCreateuserIsNotNull(Boolean createuserIsNotNull) {
		this.createuserIsNotNull = createuserIsNotNull;
	}

	public java.util.List getCreateuserIn() {
		return createuserIn;
	}
	public void setCreateuserIn(java.util.List createuserIn) {
		this.createuserIn = createuserIn;
	}

	public String getCreateuserGreaterThanOrEqualTo() {
		return createuserGreaterThanOrEqualTo;
	}
	public void setCreateuserGreaterThanOrEqualTo(String createuserGreaterThanOrEqualTo) {
		this.createuserGreaterThanOrEqualTo = createuserGreaterThanOrEqualTo;
	}

	public String getCreateuserGreaterThan() {
		return createuserGreaterThan;
	}
	public void setCreateuserGreaterThan(String createuserGreaterThan) {
		this.createuserGreaterThan = createuserGreaterThan;
	}

	public String getCreateuserEqualTo() {
		return createuserEqualTo;
	}
	public void setCreateuserEqualTo(String createuserEqualTo) {
		this.createuserEqualTo = createuserEqualTo;
	}

	public java.util.List getCreatetimeNotIn() {
		return createtimeNotIn;
	}
	public void setCreatetimeNotIn(java.util.List createtimeNotIn) {
		this.createtimeNotIn = createtimeNotIn;
	}

	public java.util.Date getCreatetimeNotEqualTo() {
		return createtimeNotEqualTo;
	}
	public void setCreatetimeNotEqualTo(java.util.Date createtimeNotEqualTo) {
		this.createtimeNotEqualTo = createtimeNotEqualTo;
	}

	public java.util.Date getCreatetimeLessThanOrEqualTo() {
		return createtimeLessThanOrEqualTo;
	}
	public void setCreatetimeLessThanOrEqualTo(java.util.Date createtimeLessThanOrEqualTo) {
		this.createtimeLessThanOrEqualTo = createtimeLessThanOrEqualTo;
	}

	public java.util.Date getCreatetimeLessThan() {
		return createtimeLessThan;
	}
	public void setCreatetimeLessThan(java.util.Date createtimeLessThan) {
		this.createtimeLessThan = createtimeLessThan;
	}

	public Boolean getCreatetimeIsNull() {
		return createtimeIsNull;
	}
	public void setCreatetimeIsNull(Boolean createtimeIsNull) {
		this.createtimeIsNull = createtimeIsNull;
	}

	public Boolean getCreatetimeIsNotNull() {
		return createtimeIsNotNull;
	}
	public void setCreatetimeIsNotNull(Boolean createtimeIsNotNull) {
		this.createtimeIsNotNull = createtimeIsNotNull;
	}

	public java.util.List getCreatetimeIn() {
		return createtimeIn;
	}
	public void setCreatetimeIn(java.util.List createtimeIn) {
		this.createtimeIn = createtimeIn;
	}

	public java.util.Date getCreatetimeGreaterThanOrEqualTo() {
		return createtimeGreaterThanOrEqualTo;
	}
	public void setCreatetimeGreaterThanOrEqualTo(java.util.Date createtimeGreaterThanOrEqualTo) {
		this.createtimeGreaterThanOrEqualTo = createtimeGreaterThanOrEqualTo;
	}

	public java.util.Date getCreatetimeGreaterThan() {
		return createtimeGreaterThan;
	}
	public void setCreatetimeGreaterThan(java.util.Date createtimeGreaterThan) {
		this.createtimeGreaterThan = createtimeGreaterThan;
	}

	public java.util.Date getCreatetimeEqualTo() {
		return createtimeEqualTo;
	}
	public void setCreatetimeEqualTo(java.util.Date createtimeEqualTo) {
		this.createtimeEqualTo = createtimeEqualTo;
	}

	public void setSidx(String sidx) {
		this.sidx = sidx;
	}
	public String getSord() {
		return sord;
	}
	public void setSord(String sord) {
		 this.sord = sord;
	}
}
