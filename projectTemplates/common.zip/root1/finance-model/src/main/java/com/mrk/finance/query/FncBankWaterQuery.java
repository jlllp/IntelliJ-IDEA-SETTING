package com.mrk.finance.query;
import com.mrk.common.utils.text.CheckUtil;

/**
 * @author 自动生成工具
 * @date   2021/11/10
 */
public class FncBankWaterQuery {
	private String updateuserNotLike;
	private java.util.List updateuserNotIn;
	private String updateuserNotEqualTo;
	private String updateuserLike;
	private String updateuserLessThanOrEqualTo;
	private String updateuserLessThan;
	private Boolean updateuserIsNull;
	private Boolean updateuserIsNotNull;
	private java.util.List updateuserIn;
	private String updateuserGreaterThanOrEqualTo;
	private String updateuserGreaterThan;
	private String updateuserEqualTo;
	private java.util.List updatetimeNotIn;
	private java.util.Date updatetimeNotEqualTo;
	private java.util.Date updatetimeLessThanOrEqualTo;
	private java.util.Date updatetimeLessThan;
	private Boolean updatetimeIsNull;
	private Boolean updatetimeIsNotNull;
	private java.util.List updatetimeIn;
	private java.util.Date updatetimeGreaterThanOrEqualTo;
	private java.util.Date updatetimeGreaterThan;
	private java.util.Date updatetimeEqualTo;
	private String remarkNotLike;
	private java.util.List remarkNotIn;
	private String remarkNotEqualTo;
	private String remarkLike;
	private String remarkLessThanOrEqualTo;
	private String remarkLessThan;
	private Boolean remarkIsNull;
	private Boolean remarkIsNotNull;
	private java.util.List remarkIn;
	private String remarkGreaterThanOrEqualTo;
	private String remarkGreaterThan;
	private String remarkEqualTo;
	private String fbwVoucherNoNotLike;
	private java.util.List fbwVoucherNoNotIn;
	private String fbwVoucherNoNotEqualTo;
	private String fbwVoucherNoLike;
	private String fbwVoucherNoLessThanOrEqualTo;
	private String fbwVoucherNoLessThan;
	private Boolean fbwVoucherNoIsNull;
	private Boolean fbwVoucherNoIsNotNull;
	private java.util.List fbwVoucherNoIn;
	private String fbwVoucherNoGreaterThanOrEqualTo;
	private String fbwVoucherNoGreaterThan;
	private String fbwVoucherNoEqualTo;
	private String fbwUseNotLike;
	private java.util.List fbwUseNotIn;
	private String fbwUseNotEqualTo;
	private String fbwUseLike;
	private String fbwUseLessThanOrEqualTo;
	private String fbwUseLessThan;
	private Boolean fbwUseIsNull;
	private Boolean fbwUseIsNotNull;
	private java.util.List fbwUseIn;
	private String fbwUseGreaterThanOrEqualTo;
	private String fbwUseGreaterThan;
	private String fbwUseEqualTo;
	private String fbwPersonalizedInformationNotLike;
	private java.util.List fbwPersonalizedInformationNotIn;
	private String fbwPersonalizedInformationNotEqualTo;
	private String fbwPersonalizedInformationLike;
	private String fbwPersonalizedInformationLessThanOrEqualTo;
	private String fbwPersonalizedInformationLessThan;
	private Boolean fbwPersonalizedInformationIsNull;
	private Boolean fbwPersonalizedInformationIsNotNull;
	private java.util.List fbwPersonalizedInformationIn;
	private String fbwPersonalizedInformationGreaterThanOrEqualTo;
	private String fbwPersonalizedInformationGreaterThan;
	private String fbwPersonalizedInformationEqualTo;
	private String fbwOwnAccountNotLike;
	private java.util.List fbwOwnAccountNotIn;
	private String fbwOwnAccountNotEqualTo;
	private String fbwOwnAccountLike;
	private String fbwOwnAccountLessThanOrEqualTo;
	private String fbwOwnAccountLessThan;
	private Boolean fbwOwnAccountIsNull;
	private Boolean fbwOwnAccountIsNotNull;
	private java.util.List fbwOwnAccountIn;
	private String fbwOwnAccountGreaterThanOrEqualTo;
	private String fbwOwnAccountGreaterThan;
	private String fbwOwnAccountEqualTo;
	private String fbwOtherUnitNameNotLike;
	private java.util.List fbwOtherUnitNameNotIn;
	private String fbwOtherUnitNameNotEqualTo;
	private String fbwOtherUnitNameLike;
	private String fbwOtherUnitNameLessThanOrEqualTo;
	private String fbwOtherUnitNameLessThan;
	private Boolean fbwOtherUnitNameIsNull;
	private Boolean fbwOtherUnitNameIsNotNull;
	private java.util.List fbwOtherUnitNameIn;
	private String fbwOtherUnitNameGreaterThanOrEqualTo;
	private String fbwOtherUnitNameGreaterThan;
	private String fbwOtherUnitNameEqualTo;
	private String fbwOtherAccountNotLike;
	private java.util.List fbwOtherAccountNotIn;
	private String fbwOtherAccountNotEqualTo;
	private String fbwOtherAccountLike;
	private String fbwOtherAccountLessThanOrEqualTo;
	private String fbwOtherAccountLessThan;
	private Boolean fbwOtherAccountIsNull;
	private Boolean fbwOtherAccountIsNotNull;
	private java.util.List fbwOtherAccountIn;
	private String fbwOtherAccountGreaterThanOrEqualTo;
	private String fbwOtherAccountGreaterThan;
	private String fbwOtherAccountEqualTo;
	private java.util.List fbwNotMatchAmountNotIn;
	private Double fbwNotMatchAmountNotEqualTo;
	private Double fbwNotMatchAmountLessThanOrEqualTo;
	private Double fbwNotMatchAmountLessThan;
	private Boolean fbwNotMatchAmountIsNull;
	private Boolean fbwNotMatchAmountIsNotNull;
	private java.util.List fbwNotMatchAmountIn;
	private Double fbwNotMatchAmountGreaterThanOrEqualTo;
	private Double fbwNotMatchAmountGreaterThan;
	private Double fbwNotMatchAmountEqualTo;
	private java.util.List fbwMatchedAmountNotIn;
	private Double fbwMatchedAmountNotEqualTo;
	private Double fbwMatchedAmountLessThanOrEqualTo;
	private Double fbwMatchedAmountLessThan;
	private Boolean fbwMatchedAmountIsNull;
	private Boolean fbwMatchedAmountIsNotNull;
	private java.util.List fbwMatchedAmountIn;
	private Double fbwMatchedAmountGreaterThanOrEqualTo;
	private Double fbwMatchedAmountGreaterThan;
	private Double fbwMatchedAmountEqualTo;
	private java.util.List fbwMatchTypeNotIn;
	private Integer fbwMatchTypeNotEqualTo;
	private Integer fbwMatchTypeLessThanOrEqualTo;
	private Integer fbwMatchTypeLessThan;
	private Boolean fbwMatchTypeIsNull;
	private Boolean fbwMatchTypeIsNotNull;
	private java.util.List fbwMatchTypeIn;
	private Integer fbwMatchTypeGreaterThanOrEqualTo;
	private Integer fbwMatchTypeGreaterThan;
	private Integer fbwMatchTypeEqualTo;
	private java.util.List fbwMatchStateNotIn;
	private Integer fbwMatchStateNotEqualTo;
	private Integer fbwMatchStateLessThanOrEqualTo;
	private Integer fbwMatchStateLessThan;
	private Boolean fbwMatchStateIsNull;
	private Boolean fbwMatchStateIsNotNull;
	private java.util.List fbwMatchStateIn;
	private Integer fbwMatchStateGreaterThanOrEqualTo;
	private Integer fbwMatchStateGreaterThan;
	private Integer fbwMatchStateEqualTo;
	private String fbwMatchBillNotLike;
	private java.util.List fbwMatchBillNotIn;
	private String fbwMatchBillNotEqualTo;
	private String fbwMatchBillLike;
	private String fbwMatchBillLessThanOrEqualTo;
	private String fbwMatchBillLessThan;
	private Boolean fbwMatchBillIsNull;
	private Boolean fbwMatchBillIsNotNull;
	private java.util.List fbwMatchBillIn;
	private String fbwMatchBillGreaterThanOrEqualTo;
	private String fbwMatchBillGreaterThan;
	private String fbwMatchBillEqualTo;
	private java.util.List fbwLoanTypeNotIn;
	private Integer fbwLoanTypeNotEqualTo;
	private Integer fbwLoanTypeLessThanOrEqualTo;
	private Integer fbwLoanTypeLessThan;
	private Boolean fbwLoanTypeIsNull;
	private Boolean fbwLoanTypeIsNotNull;
	private java.util.List fbwLoanTypeIn;
	private Integer fbwLoanTypeGreaterThanOrEqualTo;
	private Integer fbwLoanTypeGreaterThan;
	private Integer fbwLoanTypeEqualTo;
	private java.util.List fbwIdNotIn;
	private Long fbwIdNotEqualTo;
	private Long fbwIdLessThanOrEqualTo;
	private Long fbwIdLessThan;
	private Boolean fbwIdIsNull;
	private Boolean fbwIdIsNotNull;
	private java.util.List fbwIdIn;
	private Long fbwIdGreaterThanOrEqualTo;
	private Long fbwIdGreaterThan;
	private Long fbwIdEqualTo;
	private String fbwDigestNotLike;
	private java.util.List fbwDigestNotIn;
	private String fbwDigestNotEqualTo;
	private String fbwDigestLike;
	private String fbwDigestLessThanOrEqualTo;
	private String fbwDigestLessThan;
	private Boolean fbwDigestIsNull;
	private Boolean fbwDigestIsNotNull;
	private java.util.List fbwDigestIn;
	private String fbwDigestGreaterThanOrEqualTo;
	private String fbwDigestGreaterThan;
	private String fbwDigestEqualTo;
	private java.util.List fbwDealTimeNotIn;
	private java.util.Date fbwDealTimeNotEqualTo;
	private java.util.Date fbwDealTimeLessThanOrEqualTo;
	private java.util.Date fbwDealTimeLessThan;
	private Boolean fbwDealTimeIsNull;
	private Boolean fbwDealTimeIsNotNull;
	private java.util.List fbwDealTimeIn;
	private java.util.Date fbwDealTimeGreaterThanOrEqualTo;
	private java.util.Date fbwDealTimeGreaterThan;
	private java.util.Date fbwDealTimeEqualTo;
	private java.util.List fbwCreditAmountNotIn;
	private Double fbwCreditAmountNotEqualTo;
	private Double fbwCreditAmountLessThanOrEqualTo;
	private Double fbwCreditAmountLessThan;
	private Boolean fbwCreditAmountIsNull;
	private Boolean fbwCreditAmountIsNotNull;
	private java.util.List fbwCreditAmountIn;
	private Double fbwCreditAmountGreaterThanOrEqualTo;
	private Double fbwCreditAmountGreaterThan;
	private Double fbwCreditAmountEqualTo;
	private java.util.List fbwBorrowAmountNotIn;
	private Double fbwBorrowAmountNotEqualTo;
	private Double fbwBorrowAmountLessThanOrEqualTo;
	private Double fbwBorrowAmountLessThan;
	private Boolean fbwBorrowAmountIsNull;
	private Boolean fbwBorrowAmountIsNotNull;
	private java.util.List fbwBorrowAmountIn;
	private Double fbwBorrowAmountGreaterThanOrEqualTo;
	private Double fbwBorrowAmountGreaterThan;
	private Double fbwBorrowAmountEqualTo;
	private java.util.List drNotIn;
	private Integer drNotEqualTo;
	private Integer drLessThanOrEqualTo;
	private Integer drLessThan;
	private Boolean drIsNull;
	private Boolean drIsNotNull;
	private java.util.List drIn;
	private Integer drGreaterThanOrEqualTo;
	private Integer drGreaterThan;
	private Integer drEqualTo;
	private String createuserNotLike;
	private java.util.List createuserNotIn;
	private String createuserNotEqualTo;
	private String createuserLike;
	private String createuserLessThanOrEqualTo;
	private String createuserLessThan;
	private Boolean createuserIsNull;
	private Boolean createuserIsNotNull;
	private java.util.List createuserIn;
	private String createuserGreaterThanOrEqualTo;
	private String createuserGreaterThan;
	private String createuserEqualTo;
	private java.util.List createtimeNotIn;
	private java.util.Date createtimeNotEqualTo;
	private java.util.Date createtimeLessThanOrEqualTo;
	private java.util.Date createtimeLessThan;
	private Boolean createtimeIsNull;
	private Boolean createtimeIsNotNull;
	private java.util.List createtimeIn;
	private java.util.Date createtimeGreaterThanOrEqualTo;
	private java.util.Date createtimeGreaterThan;
	private java.util.Date createtimeEqualTo;
	private String sidx;
	private String sord;
	public String getSidx(){
		if(this.sidx == null){
			return "";
		}
		else if("updateuser".equals(this.sidx)){
			return "updateuser";
		}
		else if("updatetime".equals(this.sidx)){
			return "updatetime";
		}
		else if("remark".equals(this.sidx)){
			return "remark";
		}
		else if("fbwVoucherNo".equals(this.sidx)){
			return "fbw_voucher_no";
		}
		else if("fbwUse".equals(this.sidx)){
			return "fbw_use";
		}
		else if("fbwPersonalizedformation".equals(this.sidx)){
			return "fbw_personalizedformation";
		}
		else if("fbwPersonalizedformationIn".equals(this.sidx)){
			return "fbw_personalizedformation_in";
		}
		else if("fbwOwnAccount".equals(this.sidx)){
			return "fbw_own_account";
		}
		else if("fbwOtherUnitName".equals(this.sidx)){
			return "fbw_other_unit_name";
		}
		else if("fbwOtherAccount".equals(this.sidx)){
			return "fbw_other_account";
		}
		else if("fbwMatchAmountNot".equals(this.sidx)){
			return "fbw_match_amount_not";
		}
		else if("fbwMatchAmount".equals(this.sidx)){
			return "fbw_match_amount";
		}
		else if("fbwMatchedAmount".equals(this.sidx)){
			return "fbw_matched_amount";
		}
		else if("fbwMatchType".equals(this.sidx)){
			return "fbw_match_type";
		}
		else if("fbwMatchState".equals(this.sidx)){
			return "fbw_match_state";
		}
		else if("fbwMatchBill".equals(this.sidx)){
			return "fbw_match_bill";
		}
		else if("fbwLoanType".equals(this.sidx)){
			return "fbw_loan_type";
		}
		else if("fbwId".equals(this.sidx)){
			return "fbw_id";
		}
		else if("fbwDigest".equals(this.sidx)){
			return "fbw_digest";
		}
		else if("fbwDealTime".equals(this.sidx)){
			return "fbw_deal_time";
		}
		else if("fbwCreditAmount".equals(this.sidx)){
			return "fbw_credit_amount";
		}
		else if("fbwBorrowAmount".equals(this.sidx)){
			return "fbw_borrow_amount";
		}
		else if("dr".equals(this.sidx)){
			return "dr";
		}
		else if("createuser".equals(this.sidx)){
			return "createuser";
		}
		else if("createtime".equals(this.sidx)){
			return "createtime";
		}
		return this.sidx;
	}

	@com.fasterxml.jackson.annotation.JsonIgnore
	public com.mrk.finance.example.FncBankWaterExample getCrieria(){
		com.mrk.finance.example.FncBankWaterExample q = new com.mrk.finance.example.FncBankWaterExample();
		com.mrk.finance.example.FncBankWaterExample.Criteria c = q.createCriteria();
		c.andDrEqualTo(0);
		if(CheckUtil.isNotEmpty(getUpdateuserNotLike())){
			c.andUpdateuserNotLike("%"+this.getUpdateuserNotLike()+"%");
		}
		if(CheckUtil.isNotEmpty(getUpdateuserNotIn())){
			c.andUpdateuserNotIn(this.getUpdateuserNotIn());
		}
		if(CheckUtil.isNotEmpty(getUpdateuserNotEqualTo())){
			c.andUpdateuserNotEqualTo(this.getUpdateuserNotEqualTo());
		}
		if(CheckUtil.isNotEmpty(getUpdateuserLike())){
			c.andUpdateuserLike("%"+this.getUpdateuserLike()+"%");
		}
		if(CheckUtil.isNotEmpty(getUpdateuserLessThanOrEqualTo())){
			c.andUpdateuserLessThanOrEqualTo(this.getUpdateuserLessThanOrEqualTo());
		}
		if(CheckUtil.isNotEmpty(getUpdateuserLessThan())){
			c.andUpdateuserLessThan(this.getUpdateuserLessThan());
		}
		if(CheckUtil.isNotEmpty(getUpdateuserIsNull()) && this.getUpdateuserIsNull()){
			c.andUpdateuserIsNull();
		}
		if(CheckUtil.isNotEmpty(getUpdateuserIsNotNull()) && this.getUpdateuserIsNotNull()){
			c.andUpdateuserIsNotNull();
		}
		if(CheckUtil.isNotEmpty(getUpdateuserIn())){
			c.andUpdateuserIn(this.getUpdateuserIn());
		}
		if(CheckUtil.isNotEmpty(getUpdateuserGreaterThanOrEqualTo())){
			c.andUpdateuserGreaterThanOrEqualTo(this.getUpdateuserGreaterThanOrEqualTo());
		}
		if(CheckUtil.isNotEmpty(getUpdateuserGreaterThan())){
			c.andUpdateuserGreaterThan(this.getUpdateuserGreaterThan());
		}
		if(CheckUtil.isNotEmpty(getUpdateuserEqualTo())){
			c.andUpdateuserEqualTo(this.getUpdateuserEqualTo());
		}
		if(CheckUtil.isNotEmpty(getUpdatetimeNotIn())){
			c.andUpdatetimeNotIn(this.getUpdatetimeNotIn());
		}
		if(CheckUtil.isNotEmpty(getUpdatetimeNotEqualTo())){
			c.andUpdatetimeNotEqualTo(this.getUpdatetimeNotEqualTo());
		}
		if(CheckUtil.isNotEmpty(getUpdatetimeLessThanOrEqualTo())){
			c.andUpdatetimeLessThanOrEqualTo(this.getUpdatetimeLessThanOrEqualTo());
		}
		if(CheckUtil.isNotEmpty(getUpdatetimeLessThan())){
			c.andUpdatetimeLessThan(this.getUpdatetimeLessThan());
		}
		if(CheckUtil.isNotEmpty(getUpdatetimeIsNull()) && this.getUpdatetimeIsNull()){
			c.andUpdatetimeIsNull();
		}
		if(CheckUtil.isNotEmpty(getUpdatetimeIsNotNull()) && this.getUpdatetimeIsNotNull()){
			c.andUpdatetimeIsNotNull();
		}
		if(CheckUtil.isNotEmpty(getUpdatetimeIn())){
			c.andUpdatetimeIn(this.getUpdatetimeIn());
		}
		if(CheckUtil.isNotEmpty(getUpdatetimeGreaterThanOrEqualTo())){
			c.andUpdatetimeGreaterThanOrEqualTo(this.getUpdatetimeGreaterThanOrEqualTo());
		}
		if(CheckUtil.isNotEmpty(getUpdatetimeGreaterThan())){
			c.andUpdatetimeGreaterThan(this.getUpdatetimeGreaterThan());
		}
		if(CheckUtil.isNotEmpty(getUpdatetimeEqualTo())){
			c.andUpdatetimeEqualTo(this.getUpdatetimeEqualTo());
		}
		if(CheckUtil.isNotEmpty(getRemarkNotLike())){
			c.andRemarkNotLike("%"+this.getRemarkNotLike()+"%");
		}
		if(CheckUtil.isNotEmpty(getRemarkNotIn())){
			c.andRemarkNotIn(this.getRemarkNotIn());
		}
		if(CheckUtil.isNotEmpty(getRemarkNotEqualTo())){
			c.andRemarkNotEqualTo(this.getRemarkNotEqualTo());
		}
		if(CheckUtil.isNotEmpty(getRemarkLike())){
			c.andRemarkLike("%"+this.getRemarkLike()+"%");
		}
		if(CheckUtil.isNotEmpty(getRemarkLessThanOrEqualTo())){
			c.andRemarkLessThanOrEqualTo(this.getRemarkLessThanOrEqualTo());
		}
		if(CheckUtil.isNotEmpty(getRemarkLessThan())){
			c.andRemarkLessThan(this.getRemarkLessThan());
		}
		if(CheckUtil.isNotEmpty(getRemarkIsNull()) && this.getRemarkIsNull()){
			c.andRemarkIsNull();
		}
		if(CheckUtil.isNotEmpty(getRemarkIsNotNull()) && this.getRemarkIsNotNull()){
			c.andRemarkIsNotNull();
		}
		if(CheckUtil.isNotEmpty(getRemarkIn())){
			c.andRemarkIn(this.getRemarkIn());
		}
		if(CheckUtil.isNotEmpty(getRemarkGreaterThanOrEqualTo())){
			c.andRemarkGreaterThanOrEqualTo(this.getRemarkGreaterThanOrEqualTo());
		}
		if(CheckUtil.isNotEmpty(getRemarkGreaterThan())){
			c.andRemarkGreaterThan(this.getRemarkGreaterThan());
		}
		if(CheckUtil.isNotEmpty(getRemarkEqualTo())){
			c.andRemarkEqualTo(this.getRemarkEqualTo());
		}
		if(CheckUtil.isNotEmpty(getFbwVoucherNoNotLike())){
			c.andFbwVoucherNoNotLike("%"+this.getFbwVoucherNoNotLike()+"%");
		}
		if(CheckUtil.isNotEmpty(getFbwVoucherNoNotIn())){
			c.andFbwVoucherNoNotIn(this.getFbwVoucherNoNotIn());
		}
		if(CheckUtil.isNotEmpty(getFbwVoucherNoNotEqualTo())){
			c.andFbwVoucherNoNotEqualTo(this.getFbwVoucherNoNotEqualTo());
		}
		if(CheckUtil.isNotEmpty(getFbwVoucherNoLike())){
			c.andFbwVoucherNoLike("%"+this.getFbwVoucherNoLike()+"%");
		}
		if(CheckUtil.isNotEmpty(getFbwVoucherNoLessThanOrEqualTo())){
			c.andFbwVoucherNoLessThanOrEqualTo(this.getFbwVoucherNoLessThanOrEqualTo());
		}
		if(CheckUtil.isNotEmpty(getFbwVoucherNoLessThan())){
			c.andFbwVoucherNoLessThan(this.getFbwVoucherNoLessThan());
		}
		if(CheckUtil.isNotEmpty(getFbwVoucherNoIsNull()) && this.getFbwVoucherNoIsNull()){
			c.andFbwVoucherNoIsNull();
		}
		if(CheckUtil.isNotEmpty(getFbwVoucherNoIsNotNull()) && this.getFbwVoucherNoIsNotNull()){
			c.andFbwVoucherNoIsNotNull();
		}
		if(CheckUtil.isNotEmpty(getFbwVoucherNoIn())){
			c.andFbwVoucherNoIn(this.getFbwVoucherNoIn());
		}
		if(CheckUtil.isNotEmpty(getFbwVoucherNoGreaterThanOrEqualTo())){
			c.andFbwVoucherNoGreaterThanOrEqualTo(this.getFbwVoucherNoGreaterThanOrEqualTo());
		}
		if(CheckUtil.isNotEmpty(getFbwVoucherNoGreaterThan())){
			c.andFbwVoucherNoGreaterThan(this.getFbwVoucherNoGreaterThan());
		}
		if(CheckUtil.isNotEmpty(getFbwVoucherNoEqualTo())){
			c.andFbwVoucherNoEqualTo(this.getFbwVoucherNoEqualTo());
		}
		if(CheckUtil.isNotEmpty(getFbwUseNotLike())){
			c.andFbwUseNotLike("%"+this.getFbwUseNotLike()+"%");
		}
		if(CheckUtil.isNotEmpty(getFbwUseNotIn())){
			c.andFbwUseNotIn(this.getFbwUseNotIn());
		}
		if(CheckUtil.isNotEmpty(getFbwUseNotEqualTo())){
			c.andFbwUseNotEqualTo(this.getFbwUseNotEqualTo());
		}
		if(CheckUtil.isNotEmpty(getFbwUseLike())){
			c.andFbwUseLike("%"+this.getFbwUseLike()+"%");
		}
		if(CheckUtil.isNotEmpty(getFbwUseLessThanOrEqualTo())){
			c.andFbwUseLessThanOrEqualTo(this.getFbwUseLessThanOrEqualTo());
		}
		if(CheckUtil.isNotEmpty(getFbwUseLessThan())){
			c.andFbwUseLessThan(this.getFbwUseLessThan());
		}
		if(CheckUtil.isNotEmpty(getFbwUseIsNull()) && this.getFbwUseIsNull()){
			c.andFbwUseIsNull();
		}
		if(CheckUtil.isNotEmpty(getFbwUseIsNotNull()) && this.getFbwUseIsNotNull()){
			c.andFbwUseIsNotNull();
		}
		if(CheckUtil.isNotEmpty(getFbwUseIn())){
			c.andFbwUseIn(this.getFbwUseIn());
		}
		if(CheckUtil.isNotEmpty(getFbwUseGreaterThanOrEqualTo())){
			c.andFbwUseGreaterThanOrEqualTo(this.getFbwUseGreaterThanOrEqualTo());
		}
		if(CheckUtil.isNotEmpty(getFbwUseGreaterThan())){
			c.andFbwUseGreaterThan(this.getFbwUseGreaterThan());
		}
		if(CheckUtil.isNotEmpty(getFbwUseEqualTo())){
			c.andFbwUseEqualTo(this.getFbwUseEqualTo());
		}
		if(CheckUtil.isNotEmpty(getFbwPersonalizedInformationNotLike())){
			c.andFbwPersonalizedInformationNotLike("%"+this.getFbwPersonalizedInformationNotLike()+"%");
		}
		if(CheckUtil.isNotEmpty(getFbwPersonalizedInformationNotIn())){
			c.andFbwPersonalizedInformationNotIn(this.getFbwPersonalizedInformationNotIn());
		}
		if(CheckUtil.isNotEmpty(getFbwPersonalizedInformationNotEqualTo())){
			c.andFbwPersonalizedInformationNotEqualTo(this.getFbwPersonalizedInformationNotEqualTo());
		}
		if(CheckUtil.isNotEmpty(getFbwPersonalizedInformationLike())){
			c.andFbwPersonalizedInformationLike("%"+this.getFbwPersonalizedInformationLike()+"%");
		}
		if(CheckUtil.isNotEmpty(getFbwPersonalizedInformationLessThanOrEqualTo())){
			c.andFbwPersonalizedInformationLessThanOrEqualTo(this.getFbwPersonalizedInformationLessThanOrEqualTo());
		}
		if(CheckUtil.isNotEmpty(getFbwPersonalizedInformationLessThan())){
			c.andFbwPersonalizedInformationLessThan(this.getFbwPersonalizedInformationLessThan());
		}
		if(CheckUtil.isNotEmpty(getFbwPersonalizedInformationIsNull()) && this.getFbwPersonalizedInformationIsNull()){
			c.andFbwPersonalizedInformationIsNull();
		}
		if(CheckUtil.isNotEmpty(getFbwPersonalizedInformationIsNotNull()) && this.getFbwPersonalizedInformationIsNotNull()){
			c.andFbwPersonalizedInformationIsNotNull();
		}
		if(CheckUtil.isNotEmpty(getFbwPersonalizedInformationIn())){
			c.andFbwPersonalizedInformationIn(this.getFbwPersonalizedInformationIn());
		}
		if(CheckUtil.isNotEmpty(getFbwPersonalizedInformationGreaterThanOrEqualTo())){
			c.andFbwPersonalizedInformationGreaterThanOrEqualTo(this.getFbwPersonalizedInformationGreaterThanOrEqualTo());
		}
		if(CheckUtil.isNotEmpty(getFbwPersonalizedInformationGreaterThan())){
			c.andFbwPersonalizedInformationGreaterThan(this.getFbwPersonalizedInformationGreaterThan());
		}
		if(CheckUtil.isNotEmpty(getFbwPersonalizedInformationEqualTo())){
			c.andFbwPersonalizedInformationEqualTo(this.getFbwPersonalizedInformationEqualTo());
		}
		if(CheckUtil.isNotEmpty(getFbwOwnAccountNotLike())){
			c.andFbwOwnAccountNotLike("%"+this.getFbwOwnAccountNotLike()+"%");
		}
		if(CheckUtil.isNotEmpty(getFbwOwnAccountNotIn())){
			c.andFbwOwnAccountNotIn(this.getFbwOwnAccountNotIn());
		}
		if(CheckUtil.isNotEmpty(getFbwOwnAccountNotEqualTo())){
			c.andFbwOwnAccountNotEqualTo(this.getFbwOwnAccountNotEqualTo());
		}
		if(CheckUtil.isNotEmpty(getFbwOwnAccountLike())){
			c.andFbwOwnAccountLike("%"+this.getFbwOwnAccountLike()+"%");
		}
		if(CheckUtil.isNotEmpty(getFbwOwnAccountLessThanOrEqualTo())){
			c.andFbwOwnAccountLessThanOrEqualTo(this.getFbwOwnAccountLessThanOrEqualTo());
		}
		if(CheckUtil.isNotEmpty(getFbwOwnAccountLessThan())){
			c.andFbwOwnAccountLessThan(this.getFbwOwnAccountLessThan());
		}
		if(CheckUtil.isNotEmpty(getFbwOwnAccountIsNull()) && this.getFbwOwnAccountIsNull()){
			c.andFbwOwnAccountIsNull();
		}
		if(CheckUtil.isNotEmpty(getFbwOwnAccountIsNotNull()) && this.getFbwOwnAccountIsNotNull()){
			c.andFbwOwnAccountIsNotNull();
		}
		if(CheckUtil.isNotEmpty(getFbwOwnAccountIn())){
			c.andFbwOwnAccountIn(this.getFbwOwnAccountIn());
		}
		if(CheckUtil.isNotEmpty(getFbwOwnAccountGreaterThanOrEqualTo())){
			c.andFbwOwnAccountGreaterThanOrEqualTo(this.getFbwOwnAccountGreaterThanOrEqualTo());
		}
		if(CheckUtil.isNotEmpty(getFbwOwnAccountGreaterThan())){
			c.andFbwOwnAccountGreaterThan(this.getFbwOwnAccountGreaterThan());
		}
		if(CheckUtil.isNotEmpty(getFbwOwnAccountEqualTo())){
			c.andFbwOwnAccountEqualTo(this.getFbwOwnAccountEqualTo());
		}
		if(CheckUtil.isNotEmpty(getFbwOtherUnitNameNotLike())){
			c.andFbwOtherUnitNameNotLike("%"+this.getFbwOtherUnitNameNotLike()+"%");
		}
		if(CheckUtil.isNotEmpty(getFbwOtherUnitNameNotIn())){
			c.andFbwOtherUnitNameNotIn(this.getFbwOtherUnitNameNotIn());
		}
		if(CheckUtil.isNotEmpty(getFbwOtherUnitNameNotEqualTo())){
			c.andFbwOtherUnitNameNotEqualTo(this.getFbwOtherUnitNameNotEqualTo());
		}
		if(CheckUtil.isNotEmpty(getFbwOtherUnitNameLike())){
			c.andFbwOtherUnitNameLike("%"+this.getFbwOtherUnitNameLike()+"%");
		}
		if(CheckUtil.isNotEmpty(getFbwOtherUnitNameLessThanOrEqualTo())){
			c.andFbwOtherUnitNameLessThanOrEqualTo(this.getFbwOtherUnitNameLessThanOrEqualTo());
		}
		if(CheckUtil.isNotEmpty(getFbwOtherUnitNameLessThan())){
			c.andFbwOtherUnitNameLessThan(this.getFbwOtherUnitNameLessThan());
		}
		if(CheckUtil.isNotEmpty(getFbwOtherUnitNameIsNull()) && this.getFbwOtherUnitNameIsNull()){
			c.andFbwOtherUnitNameIsNull();
		}
		if(CheckUtil.isNotEmpty(getFbwOtherUnitNameIsNotNull()) && this.getFbwOtherUnitNameIsNotNull()){
			c.andFbwOtherUnitNameIsNotNull();
		}
		if(CheckUtil.isNotEmpty(getFbwOtherUnitNameIn())){
			c.andFbwOtherUnitNameIn(this.getFbwOtherUnitNameIn());
		}
		if(CheckUtil.isNotEmpty(getFbwOtherUnitNameGreaterThanOrEqualTo())){
			c.andFbwOtherUnitNameGreaterThanOrEqualTo(this.getFbwOtherUnitNameGreaterThanOrEqualTo());
		}
		if(CheckUtil.isNotEmpty(getFbwOtherUnitNameGreaterThan())){
			c.andFbwOtherUnitNameGreaterThan(this.getFbwOtherUnitNameGreaterThan());
		}
		if(CheckUtil.isNotEmpty(getFbwOtherUnitNameEqualTo())){
			c.andFbwOtherUnitNameEqualTo(this.getFbwOtherUnitNameEqualTo());
		}
		if(CheckUtil.isNotEmpty(getFbwOtherAccountNotLike())){
			c.andFbwOtherAccountNotLike("%"+this.getFbwOtherAccountNotLike()+"%");
		}
		if(CheckUtil.isNotEmpty(getFbwOtherAccountNotIn())){
			c.andFbwOtherAccountNotIn(this.getFbwOtherAccountNotIn());
		}
		if(CheckUtil.isNotEmpty(getFbwOtherAccountNotEqualTo())){
			c.andFbwOtherAccountNotEqualTo(this.getFbwOtherAccountNotEqualTo());
		}
		if(CheckUtil.isNotEmpty(getFbwOtherAccountLike())){
			c.andFbwOtherAccountLike("%"+this.getFbwOtherAccountLike()+"%");
		}
		if(CheckUtil.isNotEmpty(getFbwOtherAccountLessThanOrEqualTo())){
			c.andFbwOtherAccountLessThanOrEqualTo(this.getFbwOtherAccountLessThanOrEqualTo());
		}
		if(CheckUtil.isNotEmpty(getFbwOtherAccountLessThan())){
			c.andFbwOtherAccountLessThan(this.getFbwOtherAccountLessThan());
		}
		if(CheckUtil.isNotEmpty(getFbwOtherAccountIsNull()) && this.getFbwOtherAccountIsNull()){
			c.andFbwOtherAccountIsNull();
		}
		if(CheckUtil.isNotEmpty(getFbwOtherAccountIsNotNull()) && this.getFbwOtherAccountIsNotNull()){
			c.andFbwOtherAccountIsNotNull();
		}
		if(CheckUtil.isNotEmpty(getFbwOtherAccountIn())){
			c.andFbwOtherAccountIn(this.getFbwOtherAccountIn());
		}
		if(CheckUtil.isNotEmpty(getFbwOtherAccountGreaterThanOrEqualTo())){
			c.andFbwOtherAccountGreaterThanOrEqualTo(this.getFbwOtherAccountGreaterThanOrEqualTo());
		}
		if(CheckUtil.isNotEmpty(getFbwOtherAccountGreaterThan())){
			c.andFbwOtherAccountGreaterThan(this.getFbwOtherAccountGreaterThan());
		}
		if(CheckUtil.isNotEmpty(getFbwOtherAccountEqualTo())){
			c.andFbwOtherAccountEqualTo(this.getFbwOtherAccountEqualTo());
		}
		if(CheckUtil.isNotEmpty(getFbwNotMatchAmountNotIn())){
			c.andFbwNotMatchAmountNotIn(this.getFbwNotMatchAmountNotIn());
		}
		if(CheckUtil.isNotEmpty(getFbwNotMatchAmountNotEqualTo())){
			c.andFbwNotMatchAmountNotEqualTo(this.getFbwNotMatchAmountNotEqualTo());
		}
		if(CheckUtil.isNotEmpty(getFbwNotMatchAmountLessThanOrEqualTo())){
			c.andFbwNotMatchAmountLessThanOrEqualTo(this.getFbwNotMatchAmountLessThanOrEqualTo());
		}
		if(CheckUtil.isNotEmpty(getFbwNotMatchAmountLessThan())){
			c.andFbwNotMatchAmountLessThan(this.getFbwNotMatchAmountLessThan());
		}
		if(CheckUtil.isNotEmpty(getFbwNotMatchAmountIsNull()) && this.getFbwNotMatchAmountIsNull()){
			c.andFbwNotMatchAmountIsNull();
		}
		if(CheckUtil.isNotEmpty(getFbwNotMatchAmountIsNotNull()) && this.getFbwNotMatchAmountIsNotNull()){
			c.andFbwNotMatchAmountIsNotNull();
		}
		if(CheckUtil.isNotEmpty(getFbwNotMatchAmountIn())){
			c.andFbwNotMatchAmountIn(this.getFbwNotMatchAmountIn());
		}
		if(CheckUtil.isNotEmpty(getFbwNotMatchAmountGreaterThanOrEqualTo())){
			c.andFbwNotMatchAmountGreaterThanOrEqualTo(this.getFbwNotMatchAmountGreaterThanOrEqualTo());
		}
		if(CheckUtil.isNotEmpty(getFbwNotMatchAmountGreaterThan())){
			c.andFbwNotMatchAmountGreaterThan(this.getFbwNotMatchAmountGreaterThan());
		}
		if(CheckUtil.isNotEmpty(getFbwNotMatchAmountEqualTo())){
			c.andFbwNotMatchAmountEqualTo(this.getFbwNotMatchAmountEqualTo());
		}
		if(CheckUtil.isNotEmpty(getFbwMatchedAmountNotIn())){
			c.andFbwMatchedAmountNotIn(this.getFbwMatchedAmountNotIn());
		}
		if(CheckUtil.isNotEmpty(getFbwMatchedAmountNotEqualTo())){
			c.andFbwMatchedAmountNotEqualTo(this.getFbwMatchedAmountNotEqualTo());
		}
		if(CheckUtil.isNotEmpty(getFbwMatchedAmountLessThanOrEqualTo())){
			c.andFbwMatchedAmountLessThanOrEqualTo(this.getFbwMatchedAmountLessThanOrEqualTo());
		}
		if(CheckUtil.isNotEmpty(getFbwMatchedAmountLessThan())){
			c.andFbwMatchedAmountLessThan(this.getFbwMatchedAmountLessThan());
		}
		if(CheckUtil.isNotEmpty(getFbwMatchedAmountIsNull()) && this.getFbwMatchedAmountIsNull()){
			c.andFbwMatchedAmountIsNull();
		}
		if(CheckUtil.isNotEmpty(getFbwMatchedAmountIsNotNull()) && this.getFbwMatchedAmountIsNotNull()){
			c.andFbwMatchedAmountIsNotNull();
		}
		if(CheckUtil.isNotEmpty(getFbwMatchedAmountIn())){
			c.andFbwMatchedAmountIn(this.getFbwMatchedAmountIn());
		}
		if(CheckUtil.isNotEmpty(getFbwMatchedAmountGreaterThanOrEqualTo())){
			c.andFbwMatchedAmountGreaterThanOrEqualTo(this.getFbwMatchedAmountGreaterThanOrEqualTo());
		}
		if(CheckUtil.isNotEmpty(getFbwMatchedAmountGreaterThan())){
			c.andFbwMatchedAmountGreaterThan(this.getFbwMatchedAmountGreaterThan());
		}
		if(CheckUtil.isNotEmpty(getFbwMatchedAmountEqualTo())){
			c.andFbwMatchedAmountEqualTo(this.getFbwMatchedAmountEqualTo());
		}
		if(CheckUtil.isNotEmpty(getFbwMatchTypeNotIn())){
			c.andFbwMatchTypeNotIn(this.getFbwMatchTypeNotIn());
		}
		if(CheckUtil.isNotEmpty(getFbwMatchTypeNotEqualTo())){
			c.andFbwMatchTypeNotEqualTo(this.getFbwMatchTypeNotEqualTo());
		}
		if(CheckUtil.isNotEmpty(getFbwMatchTypeLessThanOrEqualTo())){
			c.andFbwMatchTypeLessThanOrEqualTo(this.getFbwMatchTypeLessThanOrEqualTo());
		}
		if(CheckUtil.isNotEmpty(getFbwMatchTypeLessThan())){
			c.andFbwMatchTypeLessThan(this.getFbwMatchTypeLessThan());
		}
		if(CheckUtil.isNotEmpty(getFbwMatchTypeIsNull()) && this.getFbwMatchTypeIsNull()){
			c.andFbwMatchTypeIsNull();
		}
		if(CheckUtil.isNotEmpty(getFbwMatchTypeIsNotNull()) && this.getFbwMatchTypeIsNotNull()){
			c.andFbwMatchTypeIsNotNull();
		}
		if(CheckUtil.isNotEmpty(getFbwMatchTypeIn())){
			c.andFbwMatchTypeIn(this.getFbwMatchTypeIn());
		}
		if(CheckUtil.isNotEmpty(getFbwMatchTypeGreaterThanOrEqualTo())){
			c.andFbwMatchTypeGreaterThanOrEqualTo(this.getFbwMatchTypeGreaterThanOrEqualTo());
		}
		if(CheckUtil.isNotEmpty(getFbwMatchTypeGreaterThan())){
			c.andFbwMatchTypeGreaterThan(this.getFbwMatchTypeGreaterThan());
		}
		if(CheckUtil.isNotEmpty(getFbwMatchTypeEqualTo())){
			c.andFbwMatchTypeEqualTo(this.getFbwMatchTypeEqualTo());
		}
		if(CheckUtil.isNotEmpty(getFbwMatchStateNotIn())){
			c.andFbwMatchStateNotIn(this.getFbwMatchStateNotIn());
		}
		if(CheckUtil.isNotEmpty(getFbwMatchStateNotEqualTo())){
			c.andFbwMatchStateNotEqualTo(this.getFbwMatchStateNotEqualTo());
		}
		if(CheckUtil.isNotEmpty(getFbwMatchStateLessThanOrEqualTo())){
			c.andFbwMatchStateLessThanOrEqualTo(this.getFbwMatchStateLessThanOrEqualTo());
		}
		if(CheckUtil.isNotEmpty(getFbwMatchStateLessThan())){
			c.andFbwMatchStateLessThan(this.getFbwMatchStateLessThan());
		}
		if(CheckUtil.isNotEmpty(getFbwMatchStateIsNull()) && this.getFbwMatchStateIsNull()){
			c.andFbwMatchStateIsNull();
		}
		if(CheckUtil.isNotEmpty(getFbwMatchStateIsNotNull()) && this.getFbwMatchStateIsNotNull()){
			c.andFbwMatchStateIsNotNull();
		}
		if(CheckUtil.isNotEmpty(getFbwMatchStateIn())){
			c.andFbwMatchStateIn(this.getFbwMatchStateIn());
		}
		if(CheckUtil.isNotEmpty(getFbwMatchStateGreaterThanOrEqualTo())){
			c.andFbwMatchStateGreaterThanOrEqualTo(this.getFbwMatchStateGreaterThanOrEqualTo());
		}
		if(CheckUtil.isNotEmpty(getFbwMatchStateGreaterThan())){
			c.andFbwMatchStateGreaterThan(this.getFbwMatchStateGreaterThan());
		}
		if(CheckUtil.isNotEmpty(getFbwMatchStateEqualTo())){
			c.andFbwMatchStateEqualTo(this.getFbwMatchStateEqualTo());
		}
		if(CheckUtil.isNotEmpty(getFbwMatchBillNotLike())){
			c.andFbwMatchBillNotLike("%"+this.getFbwMatchBillNotLike()+"%");
		}
		if(CheckUtil.isNotEmpty(getFbwMatchBillNotIn())){
			c.andFbwMatchBillNotIn(this.getFbwMatchBillNotIn());
		}
		if(CheckUtil.isNotEmpty(getFbwMatchBillNotEqualTo())){
			c.andFbwMatchBillNotEqualTo(this.getFbwMatchBillNotEqualTo());
		}
		if(CheckUtil.isNotEmpty(getFbwMatchBillLike())){
			c.andFbwMatchBillLike("%"+this.getFbwMatchBillLike()+"%");
		}
		if(CheckUtil.isNotEmpty(getFbwMatchBillLessThanOrEqualTo())){
			c.andFbwMatchBillLessThanOrEqualTo(this.getFbwMatchBillLessThanOrEqualTo());
		}
		if(CheckUtil.isNotEmpty(getFbwMatchBillLessThan())){
			c.andFbwMatchBillLessThan(this.getFbwMatchBillLessThan());
		}
		if(CheckUtil.isNotEmpty(getFbwMatchBillIsNull()) && this.getFbwMatchBillIsNull()){
			c.andFbwMatchBillIsNull();
		}
		if(CheckUtil.isNotEmpty(getFbwMatchBillIsNotNull()) && this.getFbwMatchBillIsNotNull()){
			c.andFbwMatchBillIsNotNull();
		}
		if(CheckUtil.isNotEmpty(getFbwMatchBillIn())){
			c.andFbwMatchBillIn(this.getFbwMatchBillIn());
		}
		if(CheckUtil.isNotEmpty(getFbwMatchBillGreaterThanOrEqualTo())){
			c.andFbwMatchBillGreaterThanOrEqualTo(this.getFbwMatchBillGreaterThanOrEqualTo());
		}
		if(CheckUtil.isNotEmpty(getFbwMatchBillGreaterThan())){
			c.andFbwMatchBillGreaterThan(this.getFbwMatchBillGreaterThan());
		}
		if(CheckUtil.isNotEmpty(getFbwMatchBillEqualTo())){
			c.andFbwMatchBillEqualTo(this.getFbwMatchBillEqualTo());
		}
		if(CheckUtil.isNotEmpty(getFbwLoanTypeNotIn())){
			c.andFbwLoanTypeNotIn(this.getFbwLoanTypeNotIn());
		}
		if(CheckUtil.isNotEmpty(getFbwLoanTypeNotEqualTo())){
			c.andFbwLoanTypeNotEqualTo(this.getFbwLoanTypeNotEqualTo());
		}
		if(CheckUtil.isNotEmpty(getFbwLoanTypeLessThanOrEqualTo())){
			c.andFbwLoanTypeLessThanOrEqualTo(this.getFbwLoanTypeLessThanOrEqualTo());
		}
		if(CheckUtil.isNotEmpty(getFbwLoanTypeLessThan())){
			c.andFbwLoanTypeLessThan(this.getFbwLoanTypeLessThan());
		}
		if(CheckUtil.isNotEmpty(getFbwLoanTypeIsNull()) && this.getFbwLoanTypeIsNull()){
			c.andFbwLoanTypeIsNull();
		}
		if(CheckUtil.isNotEmpty(getFbwLoanTypeIsNotNull()) && this.getFbwLoanTypeIsNotNull()){
			c.andFbwLoanTypeIsNotNull();
		}
		if(CheckUtil.isNotEmpty(getFbwLoanTypeIn())){
			c.andFbwLoanTypeIn(this.getFbwLoanTypeIn());
		}
		if(CheckUtil.isNotEmpty(getFbwLoanTypeGreaterThanOrEqualTo())){
			c.andFbwLoanTypeGreaterThanOrEqualTo(this.getFbwLoanTypeGreaterThanOrEqualTo());
		}
		if(CheckUtil.isNotEmpty(getFbwLoanTypeGreaterThan())){
			c.andFbwLoanTypeGreaterThan(this.getFbwLoanTypeGreaterThan());
		}
		if(CheckUtil.isNotEmpty(getFbwLoanTypeEqualTo())){
			c.andFbwLoanTypeEqualTo(this.getFbwLoanTypeEqualTo());
		}
		if(CheckUtil.isNotEmpty(getFbwIdNotIn())){
			c.andFbwIdNotIn(this.getFbwIdNotIn());
		}
		if(CheckUtil.isNotEmpty(getFbwIdNotEqualTo())){
			c.andFbwIdNotEqualTo(this.getFbwIdNotEqualTo());
		}
		if(CheckUtil.isNotEmpty(getFbwIdLessThanOrEqualTo())){
			c.andFbwIdLessThanOrEqualTo(this.getFbwIdLessThanOrEqualTo());
		}
		if(CheckUtil.isNotEmpty(getFbwIdLessThan())){
			c.andFbwIdLessThan(this.getFbwIdLessThan());
		}
		if(CheckUtil.isNotEmpty(getFbwIdIsNull()) && this.getFbwIdIsNull()){
			c.andFbwIdIsNull();
		}
		if(CheckUtil.isNotEmpty(getFbwIdIsNotNull()) && this.getFbwIdIsNotNull()){
			c.andFbwIdIsNotNull();
		}
		if(CheckUtil.isNotEmpty(getFbwIdIn())){
			c.andFbwIdIn(this.getFbwIdIn());
		}
		if(CheckUtil.isNotEmpty(getFbwIdGreaterThanOrEqualTo())){
			c.andFbwIdGreaterThanOrEqualTo(this.getFbwIdGreaterThanOrEqualTo());
		}
		if(CheckUtil.isNotEmpty(getFbwIdGreaterThan())){
			c.andFbwIdGreaterThan(this.getFbwIdGreaterThan());
		}
		if(CheckUtil.isNotEmpty(getFbwIdEqualTo())){
			c.andFbwIdEqualTo(this.getFbwIdEqualTo());
		}
		if(CheckUtil.isNotEmpty(getFbwDigestNotLike())){
			c.andFbwDigestNotLike("%"+this.getFbwDigestNotLike()+"%");
		}
		if(CheckUtil.isNotEmpty(getFbwDigestNotIn())){
			c.andFbwDigestNotIn(this.getFbwDigestNotIn());
		}
		if(CheckUtil.isNotEmpty(getFbwDigestNotEqualTo())){
			c.andFbwDigestNotEqualTo(this.getFbwDigestNotEqualTo());
		}
		if(CheckUtil.isNotEmpty(getFbwDigestLike())){
			c.andFbwDigestLike("%"+this.getFbwDigestLike()+"%");
		}
		if(CheckUtil.isNotEmpty(getFbwDigestLessThanOrEqualTo())){
			c.andFbwDigestLessThanOrEqualTo(this.getFbwDigestLessThanOrEqualTo());
		}
		if(CheckUtil.isNotEmpty(getFbwDigestLessThan())){
			c.andFbwDigestLessThan(this.getFbwDigestLessThan());
		}
		if(CheckUtil.isNotEmpty(getFbwDigestIsNull()) && this.getFbwDigestIsNull()){
			c.andFbwDigestIsNull();
		}
		if(CheckUtil.isNotEmpty(getFbwDigestIsNotNull()) && this.getFbwDigestIsNotNull()){
			c.andFbwDigestIsNotNull();
		}
		if(CheckUtil.isNotEmpty(getFbwDigestIn())){
			c.andFbwDigestIn(this.getFbwDigestIn());
		}
		if(CheckUtil.isNotEmpty(getFbwDigestGreaterThanOrEqualTo())){
			c.andFbwDigestGreaterThanOrEqualTo(this.getFbwDigestGreaterThanOrEqualTo());
		}
		if(CheckUtil.isNotEmpty(getFbwDigestGreaterThan())){
			c.andFbwDigestGreaterThan(this.getFbwDigestGreaterThan());
		}
		if(CheckUtil.isNotEmpty(getFbwDigestEqualTo())){
			c.andFbwDigestEqualTo(this.getFbwDigestEqualTo());
		}
		if(CheckUtil.isNotEmpty(getFbwDealTimeNotIn())){
			c.andFbwDealTimeNotIn(this.getFbwDealTimeNotIn());
		}
		if(CheckUtil.isNotEmpty(getFbwDealTimeNotEqualTo())){
			c.andFbwDealTimeNotEqualTo(this.getFbwDealTimeNotEqualTo());
		}
		if(CheckUtil.isNotEmpty(getFbwDealTimeLessThanOrEqualTo())){
			c.andFbwDealTimeLessThanOrEqualTo(this.getFbwDealTimeLessThanOrEqualTo());
		}
		if(CheckUtil.isNotEmpty(getFbwDealTimeLessThan())){
			c.andFbwDealTimeLessThan(this.getFbwDealTimeLessThan());
		}
		if(CheckUtil.isNotEmpty(getFbwDealTimeIsNull()) && this.getFbwDealTimeIsNull()){
			c.andFbwDealTimeIsNull();
		}
		if(CheckUtil.isNotEmpty(getFbwDealTimeIsNotNull()) && this.getFbwDealTimeIsNotNull()){
			c.andFbwDealTimeIsNotNull();
		}
		if(CheckUtil.isNotEmpty(getFbwDealTimeIn())){
			c.andFbwDealTimeIn(this.getFbwDealTimeIn());
		}
		if(CheckUtil.isNotEmpty(getFbwDealTimeGreaterThanOrEqualTo())){
			c.andFbwDealTimeGreaterThanOrEqualTo(this.getFbwDealTimeGreaterThanOrEqualTo());
		}
		if(CheckUtil.isNotEmpty(getFbwDealTimeGreaterThan())){
			c.andFbwDealTimeGreaterThan(this.getFbwDealTimeGreaterThan());
		}
		if(CheckUtil.isNotEmpty(getFbwDealTimeEqualTo())){
			c.andFbwDealTimeEqualTo(this.getFbwDealTimeEqualTo());
		}
		if(CheckUtil.isNotEmpty(getFbwCreditAmountNotIn())){
			c.andFbwCreditAmountNotIn(this.getFbwCreditAmountNotIn());
		}
		if(CheckUtil.isNotEmpty(getFbwCreditAmountNotEqualTo())){
			c.andFbwCreditAmountNotEqualTo(this.getFbwCreditAmountNotEqualTo());
		}
		if(CheckUtil.isNotEmpty(getFbwCreditAmountLessThanOrEqualTo())){
			c.andFbwCreditAmountLessThanOrEqualTo(this.getFbwCreditAmountLessThanOrEqualTo());
		}
		if(CheckUtil.isNotEmpty(getFbwCreditAmountLessThan())){
			c.andFbwCreditAmountLessThan(this.getFbwCreditAmountLessThan());
		}
		if(CheckUtil.isNotEmpty(getFbwCreditAmountIsNull()) && this.getFbwCreditAmountIsNull()){
			c.andFbwCreditAmountIsNull();
		}
		if(CheckUtil.isNotEmpty(getFbwCreditAmountIsNotNull()) && this.getFbwCreditAmountIsNotNull()){
			c.andFbwCreditAmountIsNotNull();
		}
		if(CheckUtil.isNotEmpty(getFbwCreditAmountIn())){
			c.andFbwCreditAmountIn(this.getFbwCreditAmountIn());
		}
		if(CheckUtil.isNotEmpty(getFbwCreditAmountGreaterThanOrEqualTo())){
			c.andFbwCreditAmountGreaterThanOrEqualTo(this.getFbwCreditAmountGreaterThanOrEqualTo());
		}
		if(CheckUtil.isNotEmpty(getFbwCreditAmountGreaterThan())){
			c.andFbwCreditAmountGreaterThan(this.getFbwCreditAmountGreaterThan());
		}
		if(CheckUtil.isNotEmpty(getFbwCreditAmountEqualTo())){
			c.andFbwCreditAmountEqualTo(this.getFbwCreditAmountEqualTo());
		}
		if(CheckUtil.isNotEmpty(getFbwBorrowAmountNotIn())){
			c.andFbwBorrowAmountNotIn(this.getFbwBorrowAmountNotIn());
		}
		if(CheckUtil.isNotEmpty(getFbwBorrowAmountNotEqualTo())){
			c.andFbwBorrowAmountNotEqualTo(this.getFbwBorrowAmountNotEqualTo());
		}
		if(CheckUtil.isNotEmpty(getFbwBorrowAmountLessThanOrEqualTo())){
			c.andFbwBorrowAmountLessThanOrEqualTo(this.getFbwBorrowAmountLessThanOrEqualTo());
		}
		if(CheckUtil.isNotEmpty(getFbwBorrowAmountLessThan())){
			c.andFbwBorrowAmountLessThan(this.getFbwBorrowAmountLessThan());
		}
		if(CheckUtil.isNotEmpty(getFbwBorrowAmountIsNull()) && this.getFbwBorrowAmountIsNull()){
			c.andFbwBorrowAmountIsNull();
		}
		if(CheckUtil.isNotEmpty(getFbwBorrowAmountIsNotNull()) && this.getFbwBorrowAmountIsNotNull()){
			c.andFbwBorrowAmountIsNotNull();
		}
		if(CheckUtil.isNotEmpty(getFbwBorrowAmountIn())){
			c.andFbwBorrowAmountIn(this.getFbwBorrowAmountIn());
		}
		if(CheckUtil.isNotEmpty(getFbwBorrowAmountGreaterThanOrEqualTo())){
			c.andFbwBorrowAmountGreaterThanOrEqualTo(this.getFbwBorrowAmountGreaterThanOrEqualTo());
		}
		if(CheckUtil.isNotEmpty(getFbwBorrowAmountGreaterThan())){
			c.andFbwBorrowAmountGreaterThan(this.getFbwBorrowAmountGreaterThan());
		}
		if(CheckUtil.isNotEmpty(getFbwBorrowAmountEqualTo())){
			c.andFbwBorrowAmountEqualTo(this.getFbwBorrowAmountEqualTo());
		}
		if(CheckUtil.isNotEmpty(getDrNotIn())){
			c.andDrNotIn(this.getDrNotIn());
		}
		if(CheckUtil.isNotEmpty(getDrNotEqualTo())){
			c.andDrNotEqualTo(this.getDrNotEqualTo());
		}
		if(CheckUtil.isNotEmpty(getDrLessThanOrEqualTo())){
			c.andDrLessThanOrEqualTo(this.getDrLessThanOrEqualTo());
		}
		if(CheckUtil.isNotEmpty(getDrLessThan())){
			c.andDrLessThan(this.getDrLessThan());
		}
		if(CheckUtil.isNotEmpty(getDrIsNull()) && this.getDrIsNull()){
			c.andDrIsNull();
		}
		if(CheckUtil.isNotEmpty(getDrIsNotNull()) && this.getDrIsNotNull()){
			c.andDrIsNotNull();
		}
		if(CheckUtil.isNotEmpty(getDrIn())){
			c.andDrIn(this.getDrIn());
		}
		if(CheckUtil.isNotEmpty(getDrGreaterThanOrEqualTo())){
			c.andDrGreaterThanOrEqualTo(this.getDrGreaterThanOrEqualTo());
		}
		if(CheckUtil.isNotEmpty(getDrGreaterThan())){
			c.andDrGreaterThan(this.getDrGreaterThan());
		}
		if(CheckUtil.isNotEmpty(getDrEqualTo())){
			c.andDrEqualTo(this.getDrEqualTo());
		}
		if(CheckUtil.isNotEmpty(getCreateuserNotLike())){
			c.andCreateuserNotLike("%"+this.getCreateuserNotLike()+"%");
		}
		if(CheckUtil.isNotEmpty(getCreateuserNotIn())){
			c.andCreateuserNotIn(this.getCreateuserNotIn());
		}
		if(CheckUtil.isNotEmpty(getCreateuserNotEqualTo())){
			c.andCreateuserNotEqualTo(this.getCreateuserNotEqualTo());
		}
		if(CheckUtil.isNotEmpty(getCreateuserLike())){
			c.andCreateuserLike("%"+this.getCreateuserLike()+"%");
		}
		if(CheckUtil.isNotEmpty(getCreateuserLessThanOrEqualTo())){
			c.andCreateuserLessThanOrEqualTo(this.getCreateuserLessThanOrEqualTo());
		}
		if(CheckUtil.isNotEmpty(getCreateuserLessThan())){
			c.andCreateuserLessThan(this.getCreateuserLessThan());
		}
		if(CheckUtil.isNotEmpty(getCreateuserIsNull()) && this.getCreateuserIsNull()){
			c.andCreateuserIsNull();
		}
		if(CheckUtil.isNotEmpty(getCreateuserIsNotNull()) && this.getCreateuserIsNotNull()){
			c.andCreateuserIsNotNull();
		}
		if(CheckUtil.isNotEmpty(getCreateuserIn())){
			c.andCreateuserIn(this.getCreateuserIn());
		}
		if(CheckUtil.isNotEmpty(getCreateuserGreaterThanOrEqualTo())){
			c.andCreateuserGreaterThanOrEqualTo(this.getCreateuserGreaterThanOrEqualTo());
		}
		if(CheckUtil.isNotEmpty(getCreateuserGreaterThan())){
			c.andCreateuserGreaterThan(this.getCreateuserGreaterThan());
		}
		if(CheckUtil.isNotEmpty(getCreateuserEqualTo())){
			c.andCreateuserEqualTo(this.getCreateuserEqualTo());
		}
		if(CheckUtil.isNotEmpty(getCreatetimeNotIn())){
			c.andCreatetimeNotIn(this.getCreatetimeNotIn());
		}
		if(CheckUtil.isNotEmpty(getCreatetimeNotEqualTo())){
			c.andCreatetimeNotEqualTo(this.getCreatetimeNotEqualTo());
		}
		if(CheckUtil.isNotEmpty(getCreatetimeLessThanOrEqualTo())){
			c.andCreatetimeLessThanOrEqualTo(this.getCreatetimeLessThanOrEqualTo());
		}
		if(CheckUtil.isNotEmpty(getCreatetimeLessThan())){
			c.andCreatetimeLessThan(this.getCreatetimeLessThan());
		}
		if(CheckUtil.isNotEmpty(getCreatetimeIsNull()) && this.getCreatetimeIsNull()){
			c.andCreatetimeIsNull();
		}
		if(CheckUtil.isNotEmpty(getCreatetimeIsNotNull()) && this.getCreatetimeIsNotNull()){
			c.andCreatetimeIsNotNull();
		}
		if(CheckUtil.isNotEmpty(getCreatetimeIn())){
			c.andCreatetimeIn(this.getCreatetimeIn());
		}
		if(CheckUtil.isNotEmpty(getCreatetimeGreaterThanOrEqualTo())){
			c.andCreatetimeGreaterThanOrEqualTo(this.getCreatetimeGreaterThanOrEqualTo());
		}
		if(CheckUtil.isNotEmpty(getCreatetimeGreaterThan())){
			c.andCreatetimeGreaterThan(this.getCreatetimeGreaterThan());
		}
		if(CheckUtil.isNotEmpty(getCreatetimeEqualTo())){
			c.andCreatetimeEqualTo(this.getCreatetimeEqualTo());
		}
		if((this.getSidx()!=null && !this.getSidx().trim().equals("")) && this.getSord()!=null) {
			q.setOrderByClause(""+ this.getSidx()+" "+this.getSord());
		}
		return q;
	}
	public String getUpdateuserNotLike() {
		return updateuserNotLike;
	}
	public void setUpdateuserNotLike(String updateuserNotLike) {
		this.updateuserNotLike = updateuserNotLike;
	}

	public java.util.List getUpdateuserNotIn() {
		return updateuserNotIn;
	}
	public void setUpdateuserNotIn(java.util.List updateuserNotIn) {
		this.updateuserNotIn = updateuserNotIn;
	}

	public String getUpdateuserNotEqualTo() {
		return updateuserNotEqualTo;
	}
	public void setUpdateuserNotEqualTo(String updateuserNotEqualTo) {
		this.updateuserNotEqualTo = updateuserNotEqualTo;
	}

	public String getUpdateuserLike() {
		return updateuserLike;
	}
	public void setUpdateuserLike(String updateuserLike) {
		this.updateuserLike = updateuserLike;
	}

	public String getUpdateuserLessThanOrEqualTo() {
		return updateuserLessThanOrEqualTo;
	}
	public void setUpdateuserLessThanOrEqualTo(String updateuserLessThanOrEqualTo) {
		this.updateuserLessThanOrEqualTo = updateuserLessThanOrEqualTo;
	}

	public String getUpdateuserLessThan() {
		return updateuserLessThan;
	}
	public void setUpdateuserLessThan(String updateuserLessThan) {
		this.updateuserLessThan = updateuserLessThan;
	}

	public Boolean getUpdateuserIsNull() {
		return updateuserIsNull;
	}
	public void setUpdateuserIsNull(Boolean updateuserIsNull) {
		this.updateuserIsNull = updateuserIsNull;
	}

	public Boolean getUpdateuserIsNotNull() {
		return updateuserIsNotNull;
	}
	public void setUpdateuserIsNotNull(Boolean updateuserIsNotNull) {
		this.updateuserIsNotNull = updateuserIsNotNull;
	}

	public java.util.List getUpdateuserIn() {
		return updateuserIn;
	}
	public void setUpdateuserIn(java.util.List updateuserIn) {
		this.updateuserIn = updateuserIn;
	}

	public String getUpdateuserGreaterThanOrEqualTo() {
		return updateuserGreaterThanOrEqualTo;
	}
	public void setUpdateuserGreaterThanOrEqualTo(String updateuserGreaterThanOrEqualTo) {
		this.updateuserGreaterThanOrEqualTo = updateuserGreaterThanOrEqualTo;
	}

	public String getUpdateuserGreaterThan() {
		return updateuserGreaterThan;
	}
	public void setUpdateuserGreaterThan(String updateuserGreaterThan) {
		this.updateuserGreaterThan = updateuserGreaterThan;
	}

	public String getUpdateuserEqualTo() {
		return updateuserEqualTo;
	}
	public void setUpdateuserEqualTo(String updateuserEqualTo) {
		this.updateuserEqualTo = updateuserEqualTo;
	}

	public java.util.List getUpdatetimeNotIn() {
		return updatetimeNotIn;
	}
	public void setUpdatetimeNotIn(java.util.List updatetimeNotIn) {
		this.updatetimeNotIn = updatetimeNotIn;
	}

	public java.util.Date getUpdatetimeNotEqualTo() {
		return updatetimeNotEqualTo;
	}
	public void setUpdatetimeNotEqualTo(java.util.Date updatetimeNotEqualTo) {
		this.updatetimeNotEqualTo = updatetimeNotEqualTo;
	}

	public java.util.Date getUpdatetimeLessThanOrEqualTo() {
		return updatetimeLessThanOrEqualTo;
	}
	public void setUpdatetimeLessThanOrEqualTo(java.util.Date updatetimeLessThanOrEqualTo) {
		this.updatetimeLessThanOrEqualTo = updatetimeLessThanOrEqualTo;
	}

	public java.util.Date getUpdatetimeLessThan() {
		return updatetimeLessThan;
	}
	public void setUpdatetimeLessThan(java.util.Date updatetimeLessThan) {
		this.updatetimeLessThan = updatetimeLessThan;
	}

	public Boolean getUpdatetimeIsNull() {
		return updatetimeIsNull;
	}
	public void setUpdatetimeIsNull(Boolean updatetimeIsNull) {
		this.updatetimeIsNull = updatetimeIsNull;
	}

	public Boolean getUpdatetimeIsNotNull() {
		return updatetimeIsNotNull;
	}
	public void setUpdatetimeIsNotNull(Boolean updatetimeIsNotNull) {
		this.updatetimeIsNotNull = updatetimeIsNotNull;
	}

	public java.util.List getUpdatetimeIn() {
		return updatetimeIn;
	}
	public void setUpdatetimeIn(java.util.List updatetimeIn) {
		this.updatetimeIn = updatetimeIn;
	}

	public java.util.Date getUpdatetimeGreaterThanOrEqualTo() {
		return updatetimeGreaterThanOrEqualTo;
	}
	public void setUpdatetimeGreaterThanOrEqualTo(java.util.Date updatetimeGreaterThanOrEqualTo) {
		this.updatetimeGreaterThanOrEqualTo = updatetimeGreaterThanOrEqualTo;
	}

	public java.util.Date getUpdatetimeGreaterThan() {
		return updatetimeGreaterThan;
	}
	public void setUpdatetimeGreaterThan(java.util.Date updatetimeGreaterThan) {
		this.updatetimeGreaterThan = updatetimeGreaterThan;
	}

	public java.util.Date getUpdatetimeEqualTo() {
		return updatetimeEqualTo;
	}
	public void setUpdatetimeEqualTo(java.util.Date updatetimeEqualTo) {
		this.updatetimeEqualTo = updatetimeEqualTo;
	}

	public String getRemarkNotLike() {
		return remarkNotLike;
	}
	public void setRemarkNotLike(String remarkNotLike) {
		this.remarkNotLike = remarkNotLike;
	}

	public java.util.List getRemarkNotIn() {
		return remarkNotIn;
	}
	public void setRemarkNotIn(java.util.List remarkNotIn) {
		this.remarkNotIn = remarkNotIn;
	}

	public String getRemarkNotEqualTo() {
		return remarkNotEqualTo;
	}
	public void setRemarkNotEqualTo(String remarkNotEqualTo) {
		this.remarkNotEqualTo = remarkNotEqualTo;
	}

	public String getRemarkLike() {
		return remarkLike;
	}
	public void setRemarkLike(String remarkLike) {
		this.remarkLike = remarkLike;
	}

	public String getRemarkLessThanOrEqualTo() {
		return remarkLessThanOrEqualTo;
	}
	public void setRemarkLessThanOrEqualTo(String remarkLessThanOrEqualTo) {
		this.remarkLessThanOrEqualTo = remarkLessThanOrEqualTo;
	}

	public String getRemarkLessThan() {
		return remarkLessThan;
	}
	public void setRemarkLessThan(String remarkLessThan) {
		this.remarkLessThan = remarkLessThan;
	}

	public Boolean getRemarkIsNull() {
		return remarkIsNull;
	}
	public void setRemarkIsNull(Boolean remarkIsNull) {
		this.remarkIsNull = remarkIsNull;
	}

	public Boolean getRemarkIsNotNull() {
		return remarkIsNotNull;
	}
	public void setRemarkIsNotNull(Boolean remarkIsNotNull) {
		this.remarkIsNotNull = remarkIsNotNull;
	}

	public java.util.List getRemarkIn() {
		return remarkIn;
	}
	public void setRemarkIn(java.util.List remarkIn) {
		this.remarkIn = remarkIn;
	}

	public String getRemarkGreaterThanOrEqualTo() {
		return remarkGreaterThanOrEqualTo;
	}
	public void setRemarkGreaterThanOrEqualTo(String remarkGreaterThanOrEqualTo) {
		this.remarkGreaterThanOrEqualTo = remarkGreaterThanOrEqualTo;
	}

	public String getRemarkGreaterThan() {
		return remarkGreaterThan;
	}
	public void setRemarkGreaterThan(String remarkGreaterThan) {
		this.remarkGreaterThan = remarkGreaterThan;
	}

	public String getRemarkEqualTo() {
		return remarkEqualTo;
	}
	public void setRemarkEqualTo(String remarkEqualTo) {
		this.remarkEqualTo = remarkEqualTo;
	}

	public String getFbwVoucherNoNotLike() {
		return fbwVoucherNoNotLike;
	}
	public void setFbwVoucherNoNotLike(String fbwVoucherNoNotLike) {
		this.fbwVoucherNoNotLike = fbwVoucherNoNotLike;
	}

	public java.util.List getFbwVoucherNoNotIn() {
		return fbwVoucherNoNotIn;
	}
	public void setFbwVoucherNoNotIn(java.util.List fbwVoucherNoNotIn) {
		this.fbwVoucherNoNotIn = fbwVoucherNoNotIn;
	}

	public String getFbwVoucherNoNotEqualTo() {
		return fbwVoucherNoNotEqualTo;
	}
	public void setFbwVoucherNoNotEqualTo(String fbwVoucherNoNotEqualTo) {
		this.fbwVoucherNoNotEqualTo = fbwVoucherNoNotEqualTo;
	}

	public String getFbwVoucherNoLike() {
		return fbwVoucherNoLike;
	}
	public void setFbwVoucherNoLike(String fbwVoucherNoLike) {
		this.fbwVoucherNoLike = fbwVoucherNoLike;
	}

	public String getFbwVoucherNoLessThanOrEqualTo() {
		return fbwVoucherNoLessThanOrEqualTo;
	}
	public void setFbwVoucherNoLessThanOrEqualTo(String fbwVoucherNoLessThanOrEqualTo) {
		this.fbwVoucherNoLessThanOrEqualTo = fbwVoucherNoLessThanOrEqualTo;
	}

	public String getFbwVoucherNoLessThan() {
		return fbwVoucherNoLessThan;
	}
	public void setFbwVoucherNoLessThan(String fbwVoucherNoLessThan) {
		this.fbwVoucherNoLessThan = fbwVoucherNoLessThan;
	}

	public Boolean getFbwVoucherNoIsNull() {
		return fbwVoucherNoIsNull;
	}
	public void setFbwVoucherNoIsNull(Boolean fbwVoucherNoIsNull) {
		this.fbwVoucherNoIsNull = fbwVoucherNoIsNull;
	}

	public Boolean getFbwVoucherNoIsNotNull() {
		return fbwVoucherNoIsNotNull;
	}
	public void setFbwVoucherNoIsNotNull(Boolean fbwVoucherNoIsNotNull) {
		this.fbwVoucherNoIsNotNull = fbwVoucherNoIsNotNull;
	}

	public java.util.List getFbwVoucherNoIn() {
		return fbwVoucherNoIn;
	}
	public void setFbwVoucherNoIn(java.util.List fbwVoucherNoIn) {
		this.fbwVoucherNoIn = fbwVoucherNoIn;
	}

	public String getFbwVoucherNoGreaterThanOrEqualTo() {
		return fbwVoucherNoGreaterThanOrEqualTo;
	}
	public void setFbwVoucherNoGreaterThanOrEqualTo(String fbwVoucherNoGreaterThanOrEqualTo) {
		this.fbwVoucherNoGreaterThanOrEqualTo = fbwVoucherNoGreaterThanOrEqualTo;
	}

	public String getFbwVoucherNoGreaterThan() {
		return fbwVoucherNoGreaterThan;
	}
	public void setFbwVoucherNoGreaterThan(String fbwVoucherNoGreaterThan) {
		this.fbwVoucherNoGreaterThan = fbwVoucherNoGreaterThan;
	}

	public String getFbwVoucherNoEqualTo() {
		return fbwVoucherNoEqualTo;
	}
	public void setFbwVoucherNoEqualTo(String fbwVoucherNoEqualTo) {
		this.fbwVoucherNoEqualTo = fbwVoucherNoEqualTo;
	}

	public String getFbwUseNotLike() {
		return fbwUseNotLike;
	}
	public void setFbwUseNotLike(String fbwUseNotLike) {
		this.fbwUseNotLike = fbwUseNotLike;
	}

	public java.util.List getFbwUseNotIn() {
		return fbwUseNotIn;
	}
	public void setFbwUseNotIn(java.util.List fbwUseNotIn) {
		this.fbwUseNotIn = fbwUseNotIn;
	}

	public String getFbwUseNotEqualTo() {
		return fbwUseNotEqualTo;
	}
	public void setFbwUseNotEqualTo(String fbwUseNotEqualTo) {
		this.fbwUseNotEqualTo = fbwUseNotEqualTo;
	}

	public String getFbwUseLike() {
		return fbwUseLike;
	}
	public void setFbwUseLike(String fbwUseLike) {
		this.fbwUseLike = fbwUseLike;
	}

	public String getFbwUseLessThanOrEqualTo() {
		return fbwUseLessThanOrEqualTo;
	}
	public void setFbwUseLessThanOrEqualTo(String fbwUseLessThanOrEqualTo) {
		this.fbwUseLessThanOrEqualTo = fbwUseLessThanOrEqualTo;
	}

	public String getFbwUseLessThan() {
		return fbwUseLessThan;
	}
	public void setFbwUseLessThan(String fbwUseLessThan) {
		this.fbwUseLessThan = fbwUseLessThan;
	}

	public Boolean getFbwUseIsNull() {
		return fbwUseIsNull;
	}
	public void setFbwUseIsNull(Boolean fbwUseIsNull) {
		this.fbwUseIsNull = fbwUseIsNull;
	}

	public Boolean getFbwUseIsNotNull() {
		return fbwUseIsNotNull;
	}
	public void setFbwUseIsNotNull(Boolean fbwUseIsNotNull) {
		this.fbwUseIsNotNull = fbwUseIsNotNull;
	}

	public java.util.List getFbwUseIn() {
		return fbwUseIn;
	}
	public void setFbwUseIn(java.util.List fbwUseIn) {
		this.fbwUseIn = fbwUseIn;
	}

	public String getFbwUseGreaterThanOrEqualTo() {
		return fbwUseGreaterThanOrEqualTo;
	}
	public void setFbwUseGreaterThanOrEqualTo(String fbwUseGreaterThanOrEqualTo) {
		this.fbwUseGreaterThanOrEqualTo = fbwUseGreaterThanOrEqualTo;
	}

	public String getFbwUseGreaterThan() {
		return fbwUseGreaterThan;
	}
	public void setFbwUseGreaterThan(String fbwUseGreaterThan) {
		this.fbwUseGreaterThan = fbwUseGreaterThan;
	}

	public String getFbwUseEqualTo() {
		return fbwUseEqualTo;
	}
	public void setFbwUseEqualTo(String fbwUseEqualTo) {
		this.fbwUseEqualTo = fbwUseEqualTo;
	}

	public String getFbwPersonalizedInformationNotLike() {
		return fbwPersonalizedInformationNotLike;
	}
	public void setFbwPersonalizedInformationNotLike(String fbwPersonalizedInformationNotLike) {
		this.fbwPersonalizedInformationNotLike = fbwPersonalizedInformationNotLike;
	}

	public java.util.List getFbwPersonalizedInformationNotIn() {
		return fbwPersonalizedInformationNotIn;
	}
	public void setFbwPersonalizedInformationNotIn(java.util.List fbwPersonalizedInformationNotIn) {
		this.fbwPersonalizedInformationNotIn = fbwPersonalizedInformationNotIn;
	}

	public String getFbwPersonalizedInformationNotEqualTo() {
		return fbwPersonalizedInformationNotEqualTo;
	}
	public void setFbwPersonalizedInformationNotEqualTo(String fbwPersonalizedInformationNotEqualTo) {
		this.fbwPersonalizedInformationNotEqualTo = fbwPersonalizedInformationNotEqualTo;
	}

	public String getFbwPersonalizedInformationLike() {
		return fbwPersonalizedInformationLike;
	}
	public void setFbwPersonalizedInformationLike(String fbwPersonalizedInformationLike) {
		this.fbwPersonalizedInformationLike = fbwPersonalizedInformationLike;
	}

	public String getFbwPersonalizedInformationLessThanOrEqualTo() {
		return fbwPersonalizedInformationLessThanOrEqualTo;
	}
	public void setFbwPersonalizedInformationLessThanOrEqualTo(String fbwPersonalizedInformationLessThanOrEqualTo) {
		this.fbwPersonalizedInformationLessThanOrEqualTo = fbwPersonalizedInformationLessThanOrEqualTo;
	}

	public String getFbwPersonalizedInformationLessThan() {
		return fbwPersonalizedInformationLessThan;
	}
	public void setFbwPersonalizedInformationLessThan(String fbwPersonalizedInformationLessThan) {
		this.fbwPersonalizedInformationLessThan = fbwPersonalizedInformationLessThan;
	}

	public Boolean getFbwPersonalizedInformationIsNull() {
		return fbwPersonalizedInformationIsNull;
	}
	public void setFbwPersonalizedInformationIsNull(Boolean fbwPersonalizedInformationIsNull) {
		this.fbwPersonalizedInformationIsNull = fbwPersonalizedInformationIsNull;
	}

	public Boolean getFbwPersonalizedInformationIsNotNull() {
		return fbwPersonalizedInformationIsNotNull;
	}
	public void setFbwPersonalizedInformationIsNotNull(Boolean fbwPersonalizedInformationIsNotNull) {
		this.fbwPersonalizedInformationIsNotNull = fbwPersonalizedInformationIsNotNull;
	}

	public java.util.List getFbwPersonalizedInformationIn() {
		return fbwPersonalizedInformationIn;
	}
	public void setFbwPersonalizedInformationIn(java.util.List fbwPersonalizedInformationIn) {
		this.fbwPersonalizedInformationIn = fbwPersonalizedInformationIn;
	}

	public String getFbwPersonalizedInformationGreaterThanOrEqualTo() {
		return fbwPersonalizedInformationGreaterThanOrEqualTo;
	}
	public void setFbwPersonalizedInformationGreaterThanOrEqualTo(String fbwPersonalizedInformationGreaterThanOrEqualTo) {
		this.fbwPersonalizedInformationGreaterThanOrEqualTo = fbwPersonalizedInformationGreaterThanOrEqualTo;
	}

	public String getFbwPersonalizedInformationGreaterThan() {
		return fbwPersonalizedInformationGreaterThan;
	}
	public void setFbwPersonalizedInformationGreaterThan(String fbwPersonalizedInformationGreaterThan) {
		this.fbwPersonalizedInformationGreaterThan = fbwPersonalizedInformationGreaterThan;
	}

	public String getFbwPersonalizedInformationEqualTo() {
		return fbwPersonalizedInformationEqualTo;
	}
	public void setFbwPersonalizedInformationEqualTo(String fbwPersonalizedInformationEqualTo) {
		this.fbwPersonalizedInformationEqualTo = fbwPersonalizedInformationEqualTo;
	}

	public String getFbwOwnAccountNotLike() {
		return fbwOwnAccountNotLike;
	}
	public void setFbwOwnAccountNotLike(String fbwOwnAccountNotLike) {
		this.fbwOwnAccountNotLike = fbwOwnAccountNotLike;
	}

	public java.util.List getFbwOwnAccountNotIn() {
		return fbwOwnAccountNotIn;
	}
	public void setFbwOwnAccountNotIn(java.util.List fbwOwnAccountNotIn) {
		this.fbwOwnAccountNotIn = fbwOwnAccountNotIn;
	}

	public String getFbwOwnAccountNotEqualTo() {
		return fbwOwnAccountNotEqualTo;
	}
	public void setFbwOwnAccountNotEqualTo(String fbwOwnAccountNotEqualTo) {
		this.fbwOwnAccountNotEqualTo = fbwOwnAccountNotEqualTo;
	}

	public String getFbwOwnAccountLike() {
		return fbwOwnAccountLike;
	}
	public void setFbwOwnAccountLike(String fbwOwnAccountLike) {
		this.fbwOwnAccountLike = fbwOwnAccountLike;
	}

	public String getFbwOwnAccountLessThanOrEqualTo() {
		return fbwOwnAccountLessThanOrEqualTo;
	}
	public void setFbwOwnAccountLessThanOrEqualTo(String fbwOwnAccountLessThanOrEqualTo) {
		this.fbwOwnAccountLessThanOrEqualTo = fbwOwnAccountLessThanOrEqualTo;
	}

	public String getFbwOwnAccountLessThan() {
		return fbwOwnAccountLessThan;
	}
	public void setFbwOwnAccountLessThan(String fbwOwnAccountLessThan) {
		this.fbwOwnAccountLessThan = fbwOwnAccountLessThan;
	}

	public Boolean getFbwOwnAccountIsNull() {
		return fbwOwnAccountIsNull;
	}
	public void setFbwOwnAccountIsNull(Boolean fbwOwnAccountIsNull) {
		this.fbwOwnAccountIsNull = fbwOwnAccountIsNull;
	}

	public Boolean getFbwOwnAccountIsNotNull() {
		return fbwOwnAccountIsNotNull;
	}
	public void setFbwOwnAccountIsNotNull(Boolean fbwOwnAccountIsNotNull) {
		this.fbwOwnAccountIsNotNull = fbwOwnAccountIsNotNull;
	}

	public java.util.List getFbwOwnAccountIn() {
		return fbwOwnAccountIn;
	}
	public void setFbwOwnAccountIn(java.util.List fbwOwnAccountIn) {
		this.fbwOwnAccountIn = fbwOwnAccountIn;
	}

	public String getFbwOwnAccountGreaterThanOrEqualTo() {
		return fbwOwnAccountGreaterThanOrEqualTo;
	}
	public void setFbwOwnAccountGreaterThanOrEqualTo(String fbwOwnAccountGreaterThanOrEqualTo) {
		this.fbwOwnAccountGreaterThanOrEqualTo = fbwOwnAccountGreaterThanOrEqualTo;
	}

	public String getFbwOwnAccountGreaterThan() {
		return fbwOwnAccountGreaterThan;
	}
	public void setFbwOwnAccountGreaterThan(String fbwOwnAccountGreaterThan) {
		this.fbwOwnAccountGreaterThan = fbwOwnAccountGreaterThan;
	}

	public String getFbwOwnAccountEqualTo() {
		return fbwOwnAccountEqualTo;
	}
	public void setFbwOwnAccountEqualTo(String fbwOwnAccountEqualTo) {
		this.fbwOwnAccountEqualTo = fbwOwnAccountEqualTo;
	}

	public String getFbwOtherUnitNameNotLike() {
		return fbwOtherUnitNameNotLike;
	}
	public void setFbwOtherUnitNameNotLike(String fbwOtherUnitNameNotLike) {
		this.fbwOtherUnitNameNotLike = fbwOtherUnitNameNotLike;
	}

	public java.util.List getFbwOtherUnitNameNotIn() {
		return fbwOtherUnitNameNotIn;
	}
	public void setFbwOtherUnitNameNotIn(java.util.List fbwOtherUnitNameNotIn) {
		this.fbwOtherUnitNameNotIn = fbwOtherUnitNameNotIn;
	}

	public String getFbwOtherUnitNameNotEqualTo() {
		return fbwOtherUnitNameNotEqualTo;
	}
	public void setFbwOtherUnitNameNotEqualTo(String fbwOtherUnitNameNotEqualTo) {
		this.fbwOtherUnitNameNotEqualTo = fbwOtherUnitNameNotEqualTo;
	}

	public String getFbwOtherUnitNameLike() {
		return fbwOtherUnitNameLike;
	}
	public void setFbwOtherUnitNameLike(String fbwOtherUnitNameLike) {
		this.fbwOtherUnitNameLike = fbwOtherUnitNameLike;
	}

	public String getFbwOtherUnitNameLessThanOrEqualTo() {
		return fbwOtherUnitNameLessThanOrEqualTo;
	}
	public void setFbwOtherUnitNameLessThanOrEqualTo(String fbwOtherUnitNameLessThanOrEqualTo) {
		this.fbwOtherUnitNameLessThanOrEqualTo = fbwOtherUnitNameLessThanOrEqualTo;
	}

	public String getFbwOtherUnitNameLessThan() {
		return fbwOtherUnitNameLessThan;
	}
	public void setFbwOtherUnitNameLessThan(String fbwOtherUnitNameLessThan) {
		this.fbwOtherUnitNameLessThan = fbwOtherUnitNameLessThan;
	}

	public Boolean getFbwOtherUnitNameIsNull() {
		return fbwOtherUnitNameIsNull;
	}
	public void setFbwOtherUnitNameIsNull(Boolean fbwOtherUnitNameIsNull) {
		this.fbwOtherUnitNameIsNull = fbwOtherUnitNameIsNull;
	}

	public Boolean getFbwOtherUnitNameIsNotNull() {
		return fbwOtherUnitNameIsNotNull;
	}
	public void setFbwOtherUnitNameIsNotNull(Boolean fbwOtherUnitNameIsNotNull) {
		this.fbwOtherUnitNameIsNotNull = fbwOtherUnitNameIsNotNull;
	}

	public java.util.List getFbwOtherUnitNameIn() {
		return fbwOtherUnitNameIn;
	}
	public void setFbwOtherUnitNameIn(java.util.List fbwOtherUnitNameIn) {
		this.fbwOtherUnitNameIn = fbwOtherUnitNameIn;
	}

	public String getFbwOtherUnitNameGreaterThanOrEqualTo() {
		return fbwOtherUnitNameGreaterThanOrEqualTo;
	}
	public void setFbwOtherUnitNameGreaterThanOrEqualTo(String fbwOtherUnitNameGreaterThanOrEqualTo) {
		this.fbwOtherUnitNameGreaterThanOrEqualTo = fbwOtherUnitNameGreaterThanOrEqualTo;
	}

	public String getFbwOtherUnitNameGreaterThan() {
		return fbwOtherUnitNameGreaterThan;
	}
	public void setFbwOtherUnitNameGreaterThan(String fbwOtherUnitNameGreaterThan) {
		this.fbwOtherUnitNameGreaterThan = fbwOtherUnitNameGreaterThan;
	}

	public String getFbwOtherUnitNameEqualTo() {
		return fbwOtherUnitNameEqualTo;
	}
	public void setFbwOtherUnitNameEqualTo(String fbwOtherUnitNameEqualTo) {
		this.fbwOtherUnitNameEqualTo = fbwOtherUnitNameEqualTo;
	}

	public String getFbwOtherAccountNotLike() {
		return fbwOtherAccountNotLike;
	}
	public void setFbwOtherAccountNotLike(String fbwOtherAccountNotLike) {
		this.fbwOtherAccountNotLike = fbwOtherAccountNotLike;
	}

	public java.util.List getFbwOtherAccountNotIn() {
		return fbwOtherAccountNotIn;
	}
	public void setFbwOtherAccountNotIn(java.util.List fbwOtherAccountNotIn) {
		this.fbwOtherAccountNotIn = fbwOtherAccountNotIn;
	}

	public String getFbwOtherAccountNotEqualTo() {
		return fbwOtherAccountNotEqualTo;
	}
	public void setFbwOtherAccountNotEqualTo(String fbwOtherAccountNotEqualTo) {
		this.fbwOtherAccountNotEqualTo = fbwOtherAccountNotEqualTo;
	}

	public String getFbwOtherAccountLike() {
		return fbwOtherAccountLike;
	}
	public void setFbwOtherAccountLike(String fbwOtherAccountLike) {
		this.fbwOtherAccountLike = fbwOtherAccountLike;
	}

	public String getFbwOtherAccountLessThanOrEqualTo() {
		return fbwOtherAccountLessThanOrEqualTo;
	}
	public void setFbwOtherAccountLessThanOrEqualTo(String fbwOtherAccountLessThanOrEqualTo) {
		this.fbwOtherAccountLessThanOrEqualTo = fbwOtherAccountLessThanOrEqualTo;
	}

	public String getFbwOtherAccountLessThan() {
		return fbwOtherAccountLessThan;
	}
	public void setFbwOtherAccountLessThan(String fbwOtherAccountLessThan) {
		this.fbwOtherAccountLessThan = fbwOtherAccountLessThan;
	}

	public Boolean getFbwOtherAccountIsNull() {
		return fbwOtherAccountIsNull;
	}
	public void setFbwOtherAccountIsNull(Boolean fbwOtherAccountIsNull) {
		this.fbwOtherAccountIsNull = fbwOtherAccountIsNull;
	}

	public Boolean getFbwOtherAccountIsNotNull() {
		return fbwOtherAccountIsNotNull;
	}
	public void setFbwOtherAccountIsNotNull(Boolean fbwOtherAccountIsNotNull) {
		this.fbwOtherAccountIsNotNull = fbwOtherAccountIsNotNull;
	}

	public java.util.List getFbwOtherAccountIn() {
		return fbwOtherAccountIn;
	}
	public void setFbwOtherAccountIn(java.util.List fbwOtherAccountIn) {
		this.fbwOtherAccountIn = fbwOtherAccountIn;
	}

	public String getFbwOtherAccountGreaterThanOrEqualTo() {
		return fbwOtherAccountGreaterThanOrEqualTo;
	}
	public void setFbwOtherAccountGreaterThanOrEqualTo(String fbwOtherAccountGreaterThanOrEqualTo) {
		this.fbwOtherAccountGreaterThanOrEqualTo = fbwOtherAccountGreaterThanOrEqualTo;
	}

	public String getFbwOtherAccountGreaterThan() {
		return fbwOtherAccountGreaterThan;
	}
	public void setFbwOtherAccountGreaterThan(String fbwOtherAccountGreaterThan) {
		this.fbwOtherAccountGreaterThan = fbwOtherAccountGreaterThan;
	}

	public String getFbwOtherAccountEqualTo() {
		return fbwOtherAccountEqualTo;
	}
	public void setFbwOtherAccountEqualTo(String fbwOtherAccountEqualTo) {
		this.fbwOtherAccountEqualTo = fbwOtherAccountEqualTo;
	}

	public java.util.List getFbwNotMatchAmountNotIn() {
		return fbwNotMatchAmountNotIn;
	}
	public void setFbwNotMatchAmountNotIn(java.util.List fbwNotMatchAmountNotIn) {
		this.fbwNotMatchAmountNotIn = fbwNotMatchAmountNotIn;
	}

	public Double getFbwNotMatchAmountNotEqualTo() {
		return fbwNotMatchAmountNotEqualTo;
	}
	public void setFbwNotMatchAmountNotEqualTo(Double fbwNotMatchAmountNotEqualTo) {
		this.fbwNotMatchAmountNotEqualTo = fbwNotMatchAmountNotEqualTo;
	}

	public Double getFbwNotMatchAmountLessThanOrEqualTo() {
		return fbwNotMatchAmountLessThanOrEqualTo;
	}
	public void setFbwNotMatchAmountLessThanOrEqualTo(Double fbwNotMatchAmountLessThanOrEqualTo) {
		this.fbwNotMatchAmountLessThanOrEqualTo = fbwNotMatchAmountLessThanOrEqualTo;
	}

	public Double getFbwNotMatchAmountLessThan() {
		return fbwNotMatchAmountLessThan;
	}
	public void setFbwNotMatchAmountLessThan(Double fbwNotMatchAmountLessThan) {
		this.fbwNotMatchAmountLessThan = fbwNotMatchAmountLessThan;
	}

	public Boolean getFbwNotMatchAmountIsNull() {
		return fbwNotMatchAmountIsNull;
	}
	public void setFbwNotMatchAmountIsNull(Boolean fbwNotMatchAmountIsNull) {
		this.fbwNotMatchAmountIsNull = fbwNotMatchAmountIsNull;
	}

	public Boolean getFbwNotMatchAmountIsNotNull() {
		return fbwNotMatchAmountIsNotNull;
	}
	public void setFbwNotMatchAmountIsNotNull(Boolean fbwNotMatchAmountIsNotNull) {
		this.fbwNotMatchAmountIsNotNull = fbwNotMatchAmountIsNotNull;
	}

	public java.util.List getFbwNotMatchAmountIn() {
		return fbwNotMatchAmountIn;
	}
	public void setFbwNotMatchAmountIn(java.util.List fbwNotMatchAmountIn) {
		this.fbwNotMatchAmountIn = fbwNotMatchAmountIn;
	}

	public Double getFbwNotMatchAmountGreaterThanOrEqualTo() {
		return fbwNotMatchAmountGreaterThanOrEqualTo;
	}
	public void setFbwNotMatchAmountGreaterThanOrEqualTo(Double fbwNotMatchAmountGreaterThanOrEqualTo) {
		this.fbwNotMatchAmountGreaterThanOrEqualTo = fbwNotMatchAmountGreaterThanOrEqualTo;
	}

	public Double getFbwNotMatchAmountGreaterThan() {
		return fbwNotMatchAmountGreaterThan;
	}
	public void setFbwNotMatchAmountGreaterThan(Double fbwNotMatchAmountGreaterThan) {
		this.fbwNotMatchAmountGreaterThan = fbwNotMatchAmountGreaterThan;
	}

	public Double getFbwNotMatchAmountEqualTo() {
		return fbwNotMatchAmountEqualTo;
	}
	public void setFbwNotMatchAmountEqualTo(Double fbwNotMatchAmountEqualTo) {
		this.fbwNotMatchAmountEqualTo = fbwNotMatchAmountEqualTo;
	}

	public java.util.List getFbwMatchedAmountNotIn() {
		return fbwMatchedAmountNotIn;
	}
	public void setFbwMatchedAmountNotIn(java.util.List fbwMatchedAmountNotIn) {
		this.fbwMatchedAmountNotIn = fbwMatchedAmountNotIn;
	}

	public Double getFbwMatchedAmountNotEqualTo() {
		return fbwMatchedAmountNotEqualTo;
	}
	public void setFbwMatchedAmountNotEqualTo(Double fbwMatchedAmountNotEqualTo) {
		this.fbwMatchedAmountNotEqualTo = fbwMatchedAmountNotEqualTo;
	}

	public Double getFbwMatchedAmountLessThanOrEqualTo() {
		return fbwMatchedAmountLessThanOrEqualTo;
	}
	public void setFbwMatchedAmountLessThanOrEqualTo(Double fbwMatchedAmountLessThanOrEqualTo) {
		this.fbwMatchedAmountLessThanOrEqualTo = fbwMatchedAmountLessThanOrEqualTo;
	}

	public Double getFbwMatchedAmountLessThan() {
		return fbwMatchedAmountLessThan;
	}
	public void setFbwMatchedAmountLessThan(Double fbwMatchedAmountLessThan) {
		this.fbwMatchedAmountLessThan = fbwMatchedAmountLessThan;
	}

	public Boolean getFbwMatchedAmountIsNull() {
		return fbwMatchedAmountIsNull;
	}
	public void setFbwMatchedAmountIsNull(Boolean fbwMatchedAmountIsNull) {
		this.fbwMatchedAmountIsNull = fbwMatchedAmountIsNull;
	}

	public Boolean getFbwMatchedAmountIsNotNull() {
		return fbwMatchedAmountIsNotNull;
	}
	public void setFbwMatchedAmountIsNotNull(Boolean fbwMatchedAmountIsNotNull) {
		this.fbwMatchedAmountIsNotNull = fbwMatchedAmountIsNotNull;
	}

	public java.util.List getFbwMatchedAmountIn() {
		return fbwMatchedAmountIn;
	}
	public void setFbwMatchedAmountIn(java.util.List fbwMatchedAmountIn) {
		this.fbwMatchedAmountIn = fbwMatchedAmountIn;
	}

	public Double getFbwMatchedAmountGreaterThanOrEqualTo() {
		return fbwMatchedAmountGreaterThanOrEqualTo;
	}
	public void setFbwMatchedAmountGreaterThanOrEqualTo(Double fbwMatchedAmountGreaterThanOrEqualTo) {
		this.fbwMatchedAmountGreaterThanOrEqualTo = fbwMatchedAmountGreaterThanOrEqualTo;
	}

	public Double getFbwMatchedAmountGreaterThan() {
		return fbwMatchedAmountGreaterThan;
	}
	public void setFbwMatchedAmountGreaterThan(Double fbwMatchedAmountGreaterThan) {
		this.fbwMatchedAmountGreaterThan = fbwMatchedAmountGreaterThan;
	}

	public Double getFbwMatchedAmountEqualTo() {
		return fbwMatchedAmountEqualTo;
	}
	public void setFbwMatchedAmountEqualTo(Double fbwMatchedAmountEqualTo) {
		this.fbwMatchedAmountEqualTo = fbwMatchedAmountEqualTo;
	}

	public java.util.List getFbwMatchTypeNotIn() {
		return fbwMatchTypeNotIn;
	}
	public void setFbwMatchTypeNotIn(java.util.List fbwMatchTypeNotIn) {
		this.fbwMatchTypeNotIn = fbwMatchTypeNotIn;
	}

	public Integer getFbwMatchTypeNotEqualTo() {
		return fbwMatchTypeNotEqualTo;
	}
	public void setFbwMatchTypeNotEqualTo(Integer fbwMatchTypeNotEqualTo) {
		this.fbwMatchTypeNotEqualTo = fbwMatchTypeNotEqualTo;
	}

	public Integer getFbwMatchTypeLessThanOrEqualTo() {
		return fbwMatchTypeLessThanOrEqualTo;
	}
	public void setFbwMatchTypeLessThanOrEqualTo(Integer fbwMatchTypeLessThanOrEqualTo) {
		this.fbwMatchTypeLessThanOrEqualTo = fbwMatchTypeLessThanOrEqualTo;
	}

	public Integer getFbwMatchTypeLessThan() {
		return fbwMatchTypeLessThan;
	}
	public void setFbwMatchTypeLessThan(Integer fbwMatchTypeLessThan) {
		this.fbwMatchTypeLessThan = fbwMatchTypeLessThan;
	}

	public Boolean getFbwMatchTypeIsNull() {
		return fbwMatchTypeIsNull;
	}
	public void setFbwMatchTypeIsNull(Boolean fbwMatchTypeIsNull) {
		this.fbwMatchTypeIsNull = fbwMatchTypeIsNull;
	}

	public Boolean getFbwMatchTypeIsNotNull() {
		return fbwMatchTypeIsNotNull;
	}
	public void setFbwMatchTypeIsNotNull(Boolean fbwMatchTypeIsNotNull) {
		this.fbwMatchTypeIsNotNull = fbwMatchTypeIsNotNull;
	}

	public java.util.List getFbwMatchTypeIn() {
		return fbwMatchTypeIn;
	}
	public void setFbwMatchTypeIn(java.util.List fbwMatchTypeIn) {
		this.fbwMatchTypeIn = fbwMatchTypeIn;
	}

	public Integer getFbwMatchTypeGreaterThanOrEqualTo() {
		return fbwMatchTypeGreaterThanOrEqualTo;
	}
	public void setFbwMatchTypeGreaterThanOrEqualTo(Integer fbwMatchTypeGreaterThanOrEqualTo) {
		this.fbwMatchTypeGreaterThanOrEqualTo = fbwMatchTypeGreaterThanOrEqualTo;
	}

	public Integer getFbwMatchTypeGreaterThan() {
		return fbwMatchTypeGreaterThan;
	}
	public void setFbwMatchTypeGreaterThan(Integer fbwMatchTypeGreaterThan) {
		this.fbwMatchTypeGreaterThan = fbwMatchTypeGreaterThan;
	}

	public Integer getFbwMatchTypeEqualTo() {
		return fbwMatchTypeEqualTo;
	}
	public void setFbwMatchTypeEqualTo(Integer fbwMatchTypeEqualTo) {
		this.fbwMatchTypeEqualTo = fbwMatchTypeEqualTo;
	}

	public java.util.List getFbwMatchStateNotIn() {
		return fbwMatchStateNotIn;
	}
	public void setFbwMatchStateNotIn(java.util.List fbwMatchStateNotIn) {
		this.fbwMatchStateNotIn = fbwMatchStateNotIn;
	}

	public Integer getFbwMatchStateNotEqualTo() {
		return fbwMatchStateNotEqualTo;
	}
	public void setFbwMatchStateNotEqualTo(Integer fbwMatchStateNotEqualTo) {
		this.fbwMatchStateNotEqualTo = fbwMatchStateNotEqualTo;
	}

	public Integer getFbwMatchStateLessThanOrEqualTo() {
		return fbwMatchStateLessThanOrEqualTo;
	}
	public void setFbwMatchStateLessThanOrEqualTo(Integer fbwMatchStateLessThanOrEqualTo) {
		this.fbwMatchStateLessThanOrEqualTo = fbwMatchStateLessThanOrEqualTo;
	}

	public Integer getFbwMatchStateLessThan() {
		return fbwMatchStateLessThan;
	}
	public void setFbwMatchStateLessThan(Integer fbwMatchStateLessThan) {
		this.fbwMatchStateLessThan = fbwMatchStateLessThan;
	}

	public Boolean getFbwMatchStateIsNull() {
		return fbwMatchStateIsNull;
	}
	public void setFbwMatchStateIsNull(Boolean fbwMatchStateIsNull) {
		this.fbwMatchStateIsNull = fbwMatchStateIsNull;
	}

	public Boolean getFbwMatchStateIsNotNull() {
		return fbwMatchStateIsNotNull;
	}
	public void setFbwMatchStateIsNotNull(Boolean fbwMatchStateIsNotNull) {
		this.fbwMatchStateIsNotNull = fbwMatchStateIsNotNull;
	}

	public java.util.List getFbwMatchStateIn() {
		return fbwMatchStateIn;
	}
	public void setFbwMatchStateIn(java.util.List fbwMatchStateIn) {
		this.fbwMatchStateIn = fbwMatchStateIn;
	}

	public Integer getFbwMatchStateGreaterThanOrEqualTo() {
		return fbwMatchStateGreaterThanOrEqualTo;
	}
	public void setFbwMatchStateGreaterThanOrEqualTo(Integer fbwMatchStateGreaterThanOrEqualTo) {
		this.fbwMatchStateGreaterThanOrEqualTo = fbwMatchStateGreaterThanOrEqualTo;
	}

	public Integer getFbwMatchStateGreaterThan() {
		return fbwMatchStateGreaterThan;
	}
	public void setFbwMatchStateGreaterThan(Integer fbwMatchStateGreaterThan) {
		this.fbwMatchStateGreaterThan = fbwMatchStateGreaterThan;
	}

	public Integer getFbwMatchStateEqualTo() {
		return fbwMatchStateEqualTo;
	}
	public void setFbwMatchStateEqualTo(Integer fbwMatchStateEqualTo) {
		this.fbwMatchStateEqualTo = fbwMatchStateEqualTo;
	}

	public String getFbwMatchBillNotLike() {
		return fbwMatchBillNotLike;
	}
	public void setFbwMatchBillNotLike(String fbwMatchBillNotLike) {
		this.fbwMatchBillNotLike = fbwMatchBillNotLike;
	}

	public java.util.List getFbwMatchBillNotIn() {
		return fbwMatchBillNotIn;
	}
	public void setFbwMatchBillNotIn(java.util.List fbwMatchBillNotIn) {
		this.fbwMatchBillNotIn = fbwMatchBillNotIn;
	}

	public String getFbwMatchBillNotEqualTo() {
		return fbwMatchBillNotEqualTo;
	}
	public void setFbwMatchBillNotEqualTo(String fbwMatchBillNotEqualTo) {
		this.fbwMatchBillNotEqualTo = fbwMatchBillNotEqualTo;
	}

	public String getFbwMatchBillLike() {
		return fbwMatchBillLike;
	}
	public void setFbwMatchBillLike(String fbwMatchBillLike) {
		this.fbwMatchBillLike = fbwMatchBillLike;
	}

	public String getFbwMatchBillLessThanOrEqualTo() {
		return fbwMatchBillLessThanOrEqualTo;
	}
	public void setFbwMatchBillLessThanOrEqualTo(String fbwMatchBillLessThanOrEqualTo) {
		this.fbwMatchBillLessThanOrEqualTo = fbwMatchBillLessThanOrEqualTo;
	}

	public String getFbwMatchBillLessThan() {
		return fbwMatchBillLessThan;
	}
	public void setFbwMatchBillLessThan(String fbwMatchBillLessThan) {
		this.fbwMatchBillLessThan = fbwMatchBillLessThan;
	}

	public Boolean getFbwMatchBillIsNull() {
		return fbwMatchBillIsNull;
	}
	public void setFbwMatchBillIsNull(Boolean fbwMatchBillIsNull) {
		this.fbwMatchBillIsNull = fbwMatchBillIsNull;
	}

	public Boolean getFbwMatchBillIsNotNull() {
		return fbwMatchBillIsNotNull;
	}
	public void setFbwMatchBillIsNotNull(Boolean fbwMatchBillIsNotNull) {
		this.fbwMatchBillIsNotNull = fbwMatchBillIsNotNull;
	}

	public java.util.List getFbwMatchBillIn() {
		return fbwMatchBillIn;
	}
	public void setFbwMatchBillIn(java.util.List fbwMatchBillIn) {
		this.fbwMatchBillIn = fbwMatchBillIn;
	}

	public String getFbwMatchBillGreaterThanOrEqualTo() {
		return fbwMatchBillGreaterThanOrEqualTo;
	}
	public void setFbwMatchBillGreaterThanOrEqualTo(String fbwMatchBillGreaterThanOrEqualTo) {
		this.fbwMatchBillGreaterThanOrEqualTo = fbwMatchBillGreaterThanOrEqualTo;
	}

	public String getFbwMatchBillGreaterThan() {
		return fbwMatchBillGreaterThan;
	}
	public void setFbwMatchBillGreaterThan(String fbwMatchBillGreaterThan) {
		this.fbwMatchBillGreaterThan = fbwMatchBillGreaterThan;
	}

	public String getFbwMatchBillEqualTo() {
		return fbwMatchBillEqualTo;
	}
	public void setFbwMatchBillEqualTo(String fbwMatchBillEqualTo) {
		this.fbwMatchBillEqualTo = fbwMatchBillEqualTo;
	}

	public java.util.List getFbwLoanTypeNotIn() {
		return fbwLoanTypeNotIn;
	}
	public void setFbwLoanTypeNotIn(java.util.List fbwLoanTypeNotIn) {
		this.fbwLoanTypeNotIn = fbwLoanTypeNotIn;
	}

	public Integer getFbwLoanTypeNotEqualTo() {
		return fbwLoanTypeNotEqualTo;
	}
	public void setFbwLoanTypeNotEqualTo(Integer fbwLoanTypeNotEqualTo) {
		this.fbwLoanTypeNotEqualTo = fbwLoanTypeNotEqualTo;
	}

	public Integer getFbwLoanTypeLessThanOrEqualTo() {
		return fbwLoanTypeLessThanOrEqualTo;
	}
	public void setFbwLoanTypeLessThanOrEqualTo(Integer fbwLoanTypeLessThanOrEqualTo) {
		this.fbwLoanTypeLessThanOrEqualTo = fbwLoanTypeLessThanOrEqualTo;
	}

	public Integer getFbwLoanTypeLessThan() {
		return fbwLoanTypeLessThan;
	}
	public void setFbwLoanTypeLessThan(Integer fbwLoanTypeLessThan) {
		this.fbwLoanTypeLessThan = fbwLoanTypeLessThan;
	}

	public Boolean getFbwLoanTypeIsNull() {
		return fbwLoanTypeIsNull;
	}
	public void setFbwLoanTypeIsNull(Boolean fbwLoanTypeIsNull) {
		this.fbwLoanTypeIsNull = fbwLoanTypeIsNull;
	}

	public Boolean getFbwLoanTypeIsNotNull() {
		return fbwLoanTypeIsNotNull;
	}
	public void setFbwLoanTypeIsNotNull(Boolean fbwLoanTypeIsNotNull) {
		this.fbwLoanTypeIsNotNull = fbwLoanTypeIsNotNull;
	}

	public java.util.List getFbwLoanTypeIn() {
		return fbwLoanTypeIn;
	}
	public void setFbwLoanTypeIn(java.util.List fbwLoanTypeIn) {
		this.fbwLoanTypeIn = fbwLoanTypeIn;
	}

	public Integer getFbwLoanTypeGreaterThanOrEqualTo() {
		return fbwLoanTypeGreaterThanOrEqualTo;
	}
	public void setFbwLoanTypeGreaterThanOrEqualTo(Integer fbwLoanTypeGreaterThanOrEqualTo) {
		this.fbwLoanTypeGreaterThanOrEqualTo = fbwLoanTypeGreaterThanOrEqualTo;
	}

	public Integer getFbwLoanTypeGreaterThan() {
		return fbwLoanTypeGreaterThan;
	}
	public void setFbwLoanTypeGreaterThan(Integer fbwLoanTypeGreaterThan) {
		this.fbwLoanTypeGreaterThan = fbwLoanTypeGreaterThan;
	}

	public Integer getFbwLoanTypeEqualTo() {
		return fbwLoanTypeEqualTo;
	}
	public void setFbwLoanTypeEqualTo(Integer fbwLoanTypeEqualTo) {
		this.fbwLoanTypeEqualTo = fbwLoanTypeEqualTo;
	}

	public java.util.List getFbwIdNotIn() {
		return fbwIdNotIn;
	}
	public void setFbwIdNotIn(java.util.List fbwIdNotIn) {
		this.fbwIdNotIn = fbwIdNotIn;
	}

	public Long getFbwIdNotEqualTo() {
		return fbwIdNotEqualTo;
	}
	public void setFbwIdNotEqualTo(Long fbwIdNotEqualTo) {
		this.fbwIdNotEqualTo = fbwIdNotEqualTo;
	}

	public Long getFbwIdLessThanOrEqualTo() {
		return fbwIdLessThanOrEqualTo;
	}
	public void setFbwIdLessThanOrEqualTo(Long fbwIdLessThanOrEqualTo) {
		this.fbwIdLessThanOrEqualTo = fbwIdLessThanOrEqualTo;
	}

	public Long getFbwIdLessThan() {
		return fbwIdLessThan;
	}
	public void setFbwIdLessThan(Long fbwIdLessThan) {
		this.fbwIdLessThan = fbwIdLessThan;
	}

	public Boolean getFbwIdIsNull() {
		return fbwIdIsNull;
	}
	public void setFbwIdIsNull(Boolean fbwIdIsNull) {
		this.fbwIdIsNull = fbwIdIsNull;
	}

	public Boolean getFbwIdIsNotNull() {
		return fbwIdIsNotNull;
	}
	public void setFbwIdIsNotNull(Boolean fbwIdIsNotNull) {
		this.fbwIdIsNotNull = fbwIdIsNotNull;
	}

	public java.util.List getFbwIdIn() {
		return fbwIdIn;
	}
	public void setFbwIdIn(java.util.List fbwIdIn) {
		this.fbwIdIn = fbwIdIn;
	}

	public Long getFbwIdGreaterThanOrEqualTo() {
		return fbwIdGreaterThanOrEqualTo;
	}
	public void setFbwIdGreaterThanOrEqualTo(Long fbwIdGreaterThanOrEqualTo) {
		this.fbwIdGreaterThanOrEqualTo = fbwIdGreaterThanOrEqualTo;
	}

	public Long getFbwIdGreaterThan() {
		return fbwIdGreaterThan;
	}
	public void setFbwIdGreaterThan(Long fbwIdGreaterThan) {
		this.fbwIdGreaterThan = fbwIdGreaterThan;
	}

	public Long getFbwIdEqualTo() {
		return fbwIdEqualTo;
	}
	public void setFbwIdEqualTo(Long fbwIdEqualTo) {
		this.fbwIdEqualTo = fbwIdEqualTo;
	}

	public String getFbwDigestNotLike() {
		return fbwDigestNotLike;
	}
	public void setFbwDigestNotLike(String fbwDigestNotLike) {
		this.fbwDigestNotLike = fbwDigestNotLike;
	}

	public java.util.List getFbwDigestNotIn() {
		return fbwDigestNotIn;
	}
	public void setFbwDigestNotIn(java.util.List fbwDigestNotIn) {
		this.fbwDigestNotIn = fbwDigestNotIn;
	}

	public String getFbwDigestNotEqualTo() {
		return fbwDigestNotEqualTo;
	}
	public void setFbwDigestNotEqualTo(String fbwDigestNotEqualTo) {
		this.fbwDigestNotEqualTo = fbwDigestNotEqualTo;
	}

	public String getFbwDigestLike() {
		return fbwDigestLike;
	}
	public void setFbwDigestLike(String fbwDigestLike) {
		this.fbwDigestLike = fbwDigestLike;
	}

	public String getFbwDigestLessThanOrEqualTo() {
		return fbwDigestLessThanOrEqualTo;
	}
	public void setFbwDigestLessThanOrEqualTo(String fbwDigestLessThanOrEqualTo) {
		this.fbwDigestLessThanOrEqualTo = fbwDigestLessThanOrEqualTo;
	}

	public String getFbwDigestLessThan() {
		return fbwDigestLessThan;
	}
	public void setFbwDigestLessThan(String fbwDigestLessThan) {
		this.fbwDigestLessThan = fbwDigestLessThan;
	}

	public Boolean getFbwDigestIsNull() {
		return fbwDigestIsNull;
	}
	public void setFbwDigestIsNull(Boolean fbwDigestIsNull) {
		this.fbwDigestIsNull = fbwDigestIsNull;
	}

	public Boolean getFbwDigestIsNotNull() {
		return fbwDigestIsNotNull;
	}
	public void setFbwDigestIsNotNull(Boolean fbwDigestIsNotNull) {
		this.fbwDigestIsNotNull = fbwDigestIsNotNull;
	}

	public java.util.List getFbwDigestIn() {
		return fbwDigestIn;
	}
	public void setFbwDigestIn(java.util.List fbwDigestIn) {
		this.fbwDigestIn = fbwDigestIn;
	}

	public String getFbwDigestGreaterThanOrEqualTo() {
		return fbwDigestGreaterThanOrEqualTo;
	}
	public void setFbwDigestGreaterThanOrEqualTo(String fbwDigestGreaterThanOrEqualTo) {
		this.fbwDigestGreaterThanOrEqualTo = fbwDigestGreaterThanOrEqualTo;
	}

	public String getFbwDigestGreaterThan() {
		return fbwDigestGreaterThan;
	}
	public void setFbwDigestGreaterThan(String fbwDigestGreaterThan) {
		this.fbwDigestGreaterThan = fbwDigestGreaterThan;
	}

	public String getFbwDigestEqualTo() {
		return fbwDigestEqualTo;
	}
	public void setFbwDigestEqualTo(String fbwDigestEqualTo) {
		this.fbwDigestEqualTo = fbwDigestEqualTo;
	}

	public java.util.List getFbwDealTimeNotIn() {
		return fbwDealTimeNotIn;
	}
	public void setFbwDealTimeNotIn(java.util.List fbwDealTimeNotIn) {
		this.fbwDealTimeNotIn = fbwDealTimeNotIn;
	}

	public java.util.Date getFbwDealTimeNotEqualTo() {
		return fbwDealTimeNotEqualTo;
	}
	public void setFbwDealTimeNotEqualTo(java.util.Date fbwDealTimeNotEqualTo) {
		this.fbwDealTimeNotEqualTo = fbwDealTimeNotEqualTo;
	}

	public java.util.Date getFbwDealTimeLessThanOrEqualTo() {
		return fbwDealTimeLessThanOrEqualTo;
	}
	public void setFbwDealTimeLessThanOrEqualTo(java.util.Date fbwDealTimeLessThanOrEqualTo) {
		this.fbwDealTimeLessThanOrEqualTo = fbwDealTimeLessThanOrEqualTo;
	}

	public java.util.Date getFbwDealTimeLessThan() {
		return fbwDealTimeLessThan;
	}
	public void setFbwDealTimeLessThan(java.util.Date fbwDealTimeLessThan) {
		this.fbwDealTimeLessThan = fbwDealTimeLessThan;
	}

	public Boolean getFbwDealTimeIsNull() {
		return fbwDealTimeIsNull;
	}
	public void setFbwDealTimeIsNull(Boolean fbwDealTimeIsNull) {
		this.fbwDealTimeIsNull = fbwDealTimeIsNull;
	}

	public Boolean getFbwDealTimeIsNotNull() {
		return fbwDealTimeIsNotNull;
	}
	public void setFbwDealTimeIsNotNull(Boolean fbwDealTimeIsNotNull) {
		this.fbwDealTimeIsNotNull = fbwDealTimeIsNotNull;
	}

	public java.util.List getFbwDealTimeIn() {
		return fbwDealTimeIn;
	}
	public void setFbwDealTimeIn(java.util.List fbwDealTimeIn) {
		this.fbwDealTimeIn = fbwDealTimeIn;
	}

	public java.util.Date getFbwDealTimeGreaterThanOrEqualTo() {
		return fbwDealTimeGreaterThanOrEqualTo;
	}
	public void setFbwDealTimeGreaterThanOrEqualTo(java.util.Date fbwDealTimeGreaterThanOrEqualTo) {
		this.fbwDealTimeGreaterThanOrEqualTo = fbwDealTimeGreaterThanOrEqualTo;
	}

	public java.util.Date getFbwDealTimeGreaterThan() {
		return fbwDealTimeGreaterThan;
	}
	public void setFbwDealTimeGreaterThan(java.util.Date fbwDealTimeGreaterThan) {
		this.fbwDealTimeGreaterThan = fbwDealTimeGreaterThan;
	}

	public java.util.Date getFbwDealTimeEqualTo() {
		return fbwDealTimeEqualTo;
	}
	public void setFbwDealTimeEqualTo(java.util.Date fbwDealTimeEqualTo) {
		this.fbwDealTimeEqualTo = fbwDealTimeEqualTo;
	}

	public java.util.List getFbwCreditAmountNotIn() {
		return fbwCreditAmountNotIn;
	}
	public void setFbwCreditAmountNotIn(java.util.List fbwCreditAmountNotIn) {
		this.fbwCreditAmountNotIn = fbwCreditAmountNotIn;
	}

	public Double getFbwCreditAmountNotEqualTo() {
		return fbwCreditAmountNotEqualTo;
	}
	public void setFbwCreditAmountNotEqualTo(Double fbwCreditAmountNotEqualTo) {
		this.fbwCreditAmountNotEqualTo = fbwCreditAmountNotEqualTo;
	}

	public Double getFbwCreditAmountLessThanOrEqualTo() {
		return fbwCreditAmountLessThanOrEqualTo;
	}
	public void setFbwCreditAmountLessThanOrEqualTo(Double fbwCreditAmountLessThanOrEqualTo) {
		this.fbwCreditAmountLessThanOrEqualTo = fbwCreditAmountLessThanOrEqualTo;
	}

	public Double getFbwCreditAmountLessThan() {
		return fbwCreditAmountLessThan;
	}
	public void setFbwCreditAmountLessThan(Double fbwCreditAmountLessThan) {
		this.fbwCreditAmountLessThan = fbwCreditAmountLessThan;
	}

	public Boolean getFbwCreditAmountIsNull() {
		return fbwCreditAmountIsNull;
	}
	public void setFbwCreditAmountIsNull(Boolean fbwCreditAmountIsNull) {
		this.fbwCreditAmountIsNull = fbwCreditAmountIsNull;
	}

	public Boolean getFbwCreditAmountIsNotNull() {
		return fbwCreditAmountIsNotNull;
	}
	public void setFbwCreditAmountIsNotNull(Boolean fbwCreditAmountIsNotNull) {
		this.fbwCreditAmountIsNotNull = fbwCreditAmountIsNotNull;
	}

	public java.util.List getFbwCreditAmountIn() {
		return fbwCreditAmountIn;
	}
	public void setFbwCreditAmountIn(java.util.List fbwCreditAmountIn) {
		this.fbwCreditAmountIn = fbwCreditAmountIn;
	}

	public Double getFbwCreditAmountGreaterThanOrEqualTo() {
		return fbwCreditAmountGreaterThanOrEqualTo;
	}
	public void setFbwCreditAmountGreaterThanOrEqualTo(Double fbwCreditAmountGreaterThanOrEqualTo) {
		this.fbwCreditAmountGreaterThanOrEqualTo = fbwCreditAmountGreaterThanOrEqualTo;
	}

	public Double getFbwCreditAmountGreaterThan() {
		return fbwCreditAmountGreaterThan;
	}
	public void setFbwCreditAmountGreaterThan(Double fbwCreditAmountGreaterThan) {
		this.fbwCreditAmountGreaterThan = fbwCreditAmountGreaterThan;
	}

	public Double getFbwCreditAmountEqualTo() {
		return fbwCreditAmountEqualTo;
	}
	public void setFbwCreditAmountEqualTo(Double fbwCreditAmountEqualTo) {
		this.fbwCreditAmountEqualTo = fbwCreditAmountEqualTo;
	}

	public java.util.List getFbwBorrowAmountNotIn() {
		return fbwBorrowAmountNotIn;
	}
	public void setFbwBorrowAmountNotIn(java.util.List fbwBorrowAmountNotIn) {
		this.fbwBorrowAmountNotIn = fbwBorrowAmountNotIn;
	}

	public Double getFbwBorrowAmountNotEqualTo() {
		return fbwBorrowAmountNotEqualTo;
	}
	public void setFbwBorrowAmountNotEqualTo(Double fbwBorrowAmountNotEqualTo) {
		this.fbwBorrowAmountNotEqualTo = fbwBorrowAmountNotEqualTo;
	}

	public Double getFbwBorrowAmountLessThanOrEqualTo() {
		return fbwBorrowAmountLessThanOrEqualTo;
	}
	public void setFbwBorrowAmountLessThanOrEqualTo(Double fbwBorrowAmountLessThanOrEqualTo) {
		this.fbwBorrowAmountLessThanOrEqualTo = fbwBorrowAmountLessThanOrEqualTo;
	}

	public Double getFbwBorrowAmountLessThan() {
		return fbwBorrowAmountLessThan;
	}
	public void setFbwBorrowAmountLessThan(Double fbwBorrowAmountLessThan) {
		this.fbwBorrowAmountLessThan = fbwBorrowAmountLessThan;
	}

	public Boolean getFbwBorrowAmountIsNull() {
		return fbwBorrowAmountIsNull;
	}
	public void setFbwBorrowAmountIsNull(Boolean fbwBorrowAmountIsNull) {
		this.fbwBorrowAmountIsNull = fbwBorrowAmountIsNull;
	}

	public Boolean getFbwBorrowAmountIsNotNull() {
		return fbwBorrowAmountIsNotNull;
	}
	public void setFbwBorrowAmountIsNotNull(Boolean fbwBorrowAmountIsNotNull) {
		this.fbwBorrowAmountIsNotNull = fbwBorrowAmountIsNotNull;
	}

	public java.util.List getFbwBorrowAmountIn() {
		return fbwBorrowAmountIn;
	}
	public void setFbwBorrowAmountIn(java.util.List fbwBorrowAmountIn) {
		this.fbwBorrowAmountIn = fbwBorrowAmountIn;
	}

	public Double getFbwBorrowAmountGreaterThanOrEqualTo() {
		return fbwBorrowAmountGreaterThanOrEqualTo;
	}
	public void setFbwBorrowAmountGreaterThanOrEqualTo(Double fbwBorrowAmountGreaterThanOrEqualTo) {
		this.fbwBorrowAmountGreaterThanOrEqualTo = fbwBorrowAmountGreaterThanOrEqualTo;
	}

	public Double getFbwBorrowAmountGreaterThan() {
		return fbwBorrowAmountGreaterThan;
	}
	public void setFbwBorrowAmountGreaterThan(Double fbwBorrowAmountGreaterThan) {
		this.fbwBorrowAmountGreaterThan = fbwBorrowAmountGreaterThan;
	}

	public Double getFbwBorrowAmountEqualTo() {
		return fbwBorrowAmountEqualTo;
	}
	public void setFbwBorrowAmountEqualTo(Double fbwBorrowAmountEqualTo) {
		this.fbwBorrowAmountEqualTo = fbwBorrowAmountEqualTo;
	}

	public java.util.List getDrNotIn() {
		return drNotIn;
	}
	public void setDrNotIn(java.util.List drNotIn) {
		this.drNotIn = drNotIn;
	}

	public Integer getDrNotEqualTo() {
		return drNotEqualTo;
	}
	public void setDrNotEqualTo(Integer drNotEqualTo) {
		this.drNotEqualTo = drNotEqualTo;
	}

	public Integer getDrLessThanOrEqualTo() {
		return drLessThanOrEqualTo;
	}
	public void setDrLessThanOrEqualTo(Integer drLessThanOrEqualTo) {
		this.drLessThanOrEqualTo = drLessThanOrEqualTo;
	}

	public Integer getDrLessThan() {
		return drLessThan;
	}
	public void setDrLessThan(Integer drLessThan) {
		this.drLessThan = drLessThan;
	}

	public Boolean getDrIsNull() {
		return drIsNull;
	}
	public void setDrIsNull(Boolean drIsNull) {
		this.drIsNull = drIsNull;
	}

	public Boolean getDrIsNotNull() {
		return drIsNotNull;
	}
	public void setDrIsNotNull(Boolean drIsNotNull) {
		this.drIsNotNull = drIsNotNull;
	}

	public java.util.List getDrIn() {
		return drIn;
	}
	public void setDrIn(java.util.List drIn) {
		this.drIn = drIn;
	}

	public Integer getDrGreaterThanOrEqualTo() {
		return drGreaterThanOrEqualTo;
	}
	public void setDrGreaterThanOrEqualTo(Integer drGreaterThanOrEqualTo) {
		this.drGreaterThanOrEqualTo = drGreaterThanOrEqualTo;
	}

	public Integer getDrGreaterThan() {
		return drGreaterThan;
	}
	public void setDrGreaterThan(Integer drGreaterThan) {
		this.drGreaterThan = drGreaterThan;
	}

	public Integer getDrEqualTo() {
		return drEqualTo;
	}
	public void setDrEqualTo(Integer drEqualTo) {
		this.drEqualTo = drEqualTo;
	}

	public String getCreateuserNotLike() {
		return createuserNotLike;
	}
	public void setCreateuserNotLike(String createuserNotLike) {
		this.createuserNotLike = createuserNotLike;
	}

	public java.util.List getCreateuserNotIn() {
		return createuserNotIn;
	}
	public void setCreateuserNotIn(java.util.List createuserNotIn) {
		this.createuserNotIn = createuserNotIn;
	}

	public String getCreateuserNotEqualTo() {
		return createuserNotEqualTo;
	}
	public void setCreateuserNotEqualTo(String createuserNotEqualTo) {
		this.createuserNotEqualTo = createuserNotEqualTo;
	}

	public String getCreateuserLike() {
		return createuserLike;
	}
	public void setCreateuserLike(String createuserLike) {
		this.createuserLike = createuserLike;
	}

	public String getCreateuserLessThanOrEqualTo() {
		return createuserLessThanOrEqualTo;
	}
	public void setCreateuserLessThanOrEqualTo(String createuserLessThanOrEqualTo) {
		this.createuserLessThanOrEqualTo = createuserLessThanOrEqualTo;
	}

	public String getCreateuserLessThan() {
		return createuserLessThan;
	}
	public void setCreateuserLessThan(String createuserLessThan) {
		this.createuserLessThan = createuserLessThan;
	}

	public Boolean getCreateuserIsNull() {
		return createuserIsNull;
	}
	public void setCreateuserIsNull(Boolean createuserIsNull) {
		this.createuserIsNull = createuserIsNull;
	}

	public Boolean getCreateuserIsNotNull() {
		return createuserIsNotNull;
	}
	public void setCreateuserIsNotNull(Boolean createuserIsNotNull) {
		this.createuserIsNotNull = createuserIsNotNull;
	}

	public java.util.List getCreateuserIn() {
		return createuserIn;
	}
	public void setCreateuserIn(java.util.List createuserIn) {
		this.createuserIn = createuserIn;
	}

	public String getCreateuserGreaterThanOrEqualTo() {
		return createuserGreaterThanOrEqualTo;
	}
	public void setCreateuserGreaterThanOrEqualTo(String createuserGreaterThanOrEqualTo) {
		this.createuserGreaterThanOrEqualTo = createuserGreaterThanOrEqualTo;
	}

	public String getCreateuserGreaterThan() {
		return createuserGreaterThan;
	}
	public void setCreateuserGreaterThan(String createuserGreaterThan) {
		this.createuserGreaterThan = createuserGreaterThan;
	}

	public String getCreateuserEqualTo() {
		return createuserEqualTo;
	}
	public void setCreateuserEqualTo(String createuserEqualTo) {
		this.createuserEqualTo = createuserEqualTo;
	}

	public java.util.List getCreatetimeNotIn() {
		return createtimeNotIn;
	}
	public void setCreatetimeNotIn(java.util.List createtimeNotIn) {
		this.createtimeNotIn = createtimeNotIn;
	}

	public java.util.Date getCreatetimeNotEqualTo() {
		return createtimeNotEqualTo;
	}
	public void setCreatetimeNotEqualTo(java.util.Date createtimeNotEqualTo) {
		this.createtimeNotEqualTo = createtimeNotEqualTo;
	}

	public java.util.Date getCreatetimeLessThanOrEqualTo() {
		return createtimeLessThanOrEqualTo;
	}
	public void setCreatetimeLessThanOrEqualTo(java.util.Date createtimeLessThanOrEqualTo) {
		this.createtimeLessThanOrEqualTo = createtimeLessThanOrEqualTo;
	}

	public java.util.Date getCreatetimeLessThan() {
		return createtimeLessThan;
	}
	public void setCreatetimeLessThan(java.util.Date createtimeLessThan) {
		this.createtimeLessThan = createtimeLessThan;
	}

	public Boolean getCreatetimeIsNull() {
		return createtimeIsNull;
	}
	public void setCreatetimeIsNull(Boolean createtimeIsNull) {
		this.createtimeIsNull = createtimeIsNull;
	}

	public Boolean getCreatetimeIsNotNull() {
		return createtimeIsNotNull;
	}
	public void setCreatetimeIsNotNull(Boolean createtimeIsNotNull) {
		this.createtimeIsNotNull = createtimeIsNotNull;
	}

	public java.util.List getCreatetimeIn() {
		return createtimeIn;
	}
	public void setCreatetimeIn(java.util.List createtimeIn) {
		this.createtimeIn = createtimeIn;
	}

	public java.util.Date getCreatetimeGreaterThanOrEqualTo() {
		return createtimeGreaterThanOrEqualTo;
	}
	public void setCreatetimeGreaterThanOrEqualTo(java.util.Date createtimeGreaterThanOrEqualTo) {
		this.createtimeGreaterThanOrEqualTo = createtimeGreaterThanOrEqualTo;
	}

	public java.util.Date getCreatetimeGreaterThan() {
		return createtimeGreaterThan;
	}
	public void setCreatetimeGreaterThan(java.util.Date createtimeGreaterThan) {
		this.createtimeGreaterThan = createtimeGreaterThan;
	}

	public java.util.Date getCreatetimeEqualTo() {
		return createtimeEqualTo;
	}
	public void setCreatetimeEqualTo(java.util.Date createtimeEqualTo) {
		this.createtimeEqualTo = createtimeEqualTo;
	}

	public void setSidx(String sidx) {
		this.sidx = sidx;
	}
	public String getSord() {
		return sord;
	}
	public void setSord(String sord) {
		 this.sord = sord;
	}
}
