package com.mrk.finance.service;

import com.github.pagehelper.PageInfo;
import com.mrk.finance.model.FncRentalFees;
import com.mrk.finance.queryvo.FncRentalFeesQueryVo;

import java.util.List;

/**
 * @Description: FncRentalFees
 */
public interface FncRentalFeesService {
    /**
     * 分页查询
     *
     * @param queryVo 前端查询对象
     * @return 分页查询数据
     */
    PageInfo<FncRentalFees> page(FncRentalFeesQueryVo queryVo);

    /**
     * 列表查询
     *
     * @param queryVo 前端查询对象
     * @return 分页查询数据
     */
    List<FncRentalFees> list(FncRentalFeesQueryVo queryVo);

    /**
     * 根据名称查询(名称唯一)
     *
     * @return *
     * @author Frank.Tang
     */
    List<FncRentalFees> selectByName(String name);

    /**
     * 新增
     *
     * @param entity
     * @return 结果
     */
    int add(FncRentalFees entity);

    /**
     * 批量新增
     *
     * @return *
     * @author Frank.Tang
     */
    int addList(List<FncRentalFees> rents);

    /**
     * 修改
     *
     * @param entity
     * @return 结果
     */
    int update(FncRentalFees entity);

    /**
     * 根据id选择性修改
     *
     * @return *
     * @author Frank.Tang
     */
    int updateSelective(FncRentalFees entity);


    /**
     * 删除
     */
    int delete(Long id);

    /**
     * 根据id逻辑删除
     *
     * @return *
     * @author Frank.Tang
     */
    int deleteLogically(Long id);

    /**
     * 通过ID查询
     *
     * @param id
     */
    FncRentalFees getById(Long id);

    /**
     * 获取所有的租金包含费用
     *
     * @return 租金包含费用
     */
    List<FncRentalFees> getAll();

}
