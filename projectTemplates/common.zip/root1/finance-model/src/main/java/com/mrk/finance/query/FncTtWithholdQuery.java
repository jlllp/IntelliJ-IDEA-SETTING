package com.mrk.finance.query;
import com.mrk.common.utils.text.CheckUtil;

/**
 * @author 自动生成工具
 * @date   2021/11/10
 */
public class FncTtWithholdQuery {
	private String updateuserNotLike;
	private java.util.List updateuserNotIn;
	private String updateuserNotEqualTo;
	private String updateuserLike;
	private String updateuserLessThanOrEqualTo;
	private String updateuserLessThan;
	private Boolean updateuserIsNull;
	private Boolean updateuserIsNotNull;
	private java.util.List updateuserIn;
	private String updateuserGreaterThanOrEqualTo;
	private String updateuserGreaterThan;
	private String updateuserEqualTo;
	private java.util.List updatetimeNotIn;
	private java.util.Date updatetimeNotEqualTo;
	private java.util.Date updatetimeLessThanOrEqualTo;
	private java.util.Date updatetimeLessThan;
	private Boolean updatetimeIsNull;
	private Boolean updatetimeIsNotNull;
	private java.util.List updatetimeIn;
	private java.util.Date updatetimeGreaterThanOrEqualTo;
	private java.util.Date updatetimeGreaterThan;
	private java.util.Date updatetimeEqualTo;
	private String remarkNotLike;
	private java.util.List remarkNotIn;
	private String remarkNotEqualTo;
	private String remarkLike;
	private String remarkLessThanOrEqualTo;
	private String remarkLessThan;
	private Boolean remarkIsNull;
	private Boolean remarkIsNotNull;
	private java.util.List remarkIn;
	private String remarkGreaterThanOrEqualTo;
	private String remarkGreaterThan;
	private String remarkEqualTo;
	private java.util.List ftwRentDateNotIn;
	private java.util.Date ftwRentDateNotEqualTo;
	private java.util.Date ftwRentDateLessThanOrEqualTo;
	private java.util.Date ftwRentDateLessThan;
	private Boolean ftwRentDateIsNull;
	private Boolean ftwRentDateIsNotNull;
	private java.util.List ftwRentDateIn;
	private java.util.Date ftwRentDateGreaterThanOrEqualTo;
	private java.util.Date ftwRentDateGreaterThan;
	private java.util.Date ftwRentDateEqualTo;
	private java.util.List ftwNotMatchAmountNotIn;
	private Double ftwNotMatchAmountNotEqualTo;
	private Double ftwNotMatchAmountLessThanOrEqualTo;
	private Double ftwNotMatchAmountLessThan;
	private Boolean ftwNotMatchAmountIsNull;
	private Boolean ftwNotMatchAmountIsNotNull;
	private java.util.List ftwNotMatchAmountIn;
	private Double ftwNotMatchAmountGreaterThanOrEqualTo;
	private Double ftwNotMatchAmountGreaterThan;
	private Double ftwNotMatchAmountEqualTo;
	private String ftwNameNotLike;
	private java.util.List ftwNameNotIn;
	private String ftwNameNotEqualTo;
	private String ftwNameLike;
	private String ftwNameLessThanOrEqualTo;
	private String ftwNameLessThan;
	private Boolean ftwNameIsNull;
	private Boolean ftwNameIsNotNull;
	private java.util.List ftwNameIn;
	private String ftwNameGreaterThanOrEqualTo;
	private String ftwNameGreaterThan;
	private String ftwNameEqualTo;
	private java.util.List ftwMonthWithholdNotIn;
	private Double ftwMonthWithholdNotEqualTo;
	private Double ftwMonthWithholdLessThanOrEqualTo;
	private Double ftwMonthWithholdLessThan;
	private Boolean ftwMonthWithholdIsNull;
	private Boolean ftwMonthWithholdIsNotNull;
	private java.util.List ftwMonthWithholdIn;
	private Double ftwMonthWithholdGreaterThanOrEqualTo;
	private Double ftwMonthWithholdGreaterThan;
	private Double ftwMonthWithholdEqualTo;
	private java.util.List ftwMonthRentNotIn;
	private Double ftwMonthRentNotEqualTo;
	private Double ftwMonthRentLessThanOrEqualTo;
	private Double ftwMonthRentLessThan;
	private Boolean ftwMonthRentIsNull;
	private Boolean ftwMonthRentIsNotNull;
	private java.util.List ftwMonthRentIn;
	private Double ftwMonthRentGreaterThanOrEqualTo;
	private Double ftwMonthRentGreaterThan;
	private Double ftwMonthRentEqualTo;
	private java.util.List ftwMonthRentBalanceNotIn;
	private Double ftwMonthRentBalanceNotEqualTo;
	private Double ftwMonthRentBalanceLessThanOrEqualTo;
	private Double ftwMonthRentBalanceLessThan;
	private Boolean ftwMonthRentBalanceIsNull;
	private Boolean ftwMonthRentBalanceIsNotNull;
	private java.util.List ftwMonthRentBalanceIn;
	private Double ftwMonthRentBalanceGreaterThanOrEqualTo;
	private Double ftwMonthRentBalanceGreaterThan;
	private Double ftwMonthRentBalanceEqualTo;
	private java.util.List ftwMemberIdNotIn;
	private Long ftwMemberIdNotEqualTo;
	private Long ftwMemberIdLessThanOrEqualTo;
	private Long ftwMemberIdLessThan;
	private Boolean ftwMemberIdIsNull;
	private Boolean ftwMemberIdIsNotNull;
	private java.util.List ftwMemberIdIn;
	private Long ftwMemberIdGreaterThanOrEqualTo;
	private Long ftwMemberIdGreaterThan;
	private Long ftwMemberIdEqualTo;
	private java.util.List ftwMatchedAmountNotIn;
	private Double ftwMatchedAmountNotEqualTo;
	private Double ftwMatchedAmountLessThanOrEqualTo;
	private Double ftwMatchedAmountLessThan;
	private Boolean ftwMatchedAmountIsNull;
	private Boolean ftwMatchedAmountIsNotNull;
	private java.util.List ftwMatchedAmountIn;
	private Double ftwMatchedAmountGreaterThanOrEqualTo;
	private Double ftwMatchedAmountGreaterThan;
	private Double ftwMatchedAmountEqualTo;
	private java.util.List ftwMatchWayNotIn;
	private Integer ftwMatchWayNotEqualTo;
	private Integer ftwMatchWayLessThanOrEqualTo;
	private Integer ftwMatchWayLessThan;
	private Boolean ftwMatchWayIsNull;
	private Boolean ftwMatchWayIsNotNull;
	private java.util.List ftwMatchWayIn;
	private Integer ftwMatchWayGreaterThanOrEqualTo;
	private Integer ftwMatchWayGreaterThan;
	private Integer ftwMatchWayEqualTo;
	private java.util.List ftwMatchStateNotIn;
	private Integer ftwMatchStateNotEqualTo;
	private Integer ftwMatchStateLessThanOrEqualTo;
	private Integer ftwMatchStateLessThan;
	private Boolean ftwMatchStateIsNull;
	private Boolean ftwMatchStateIsNotNull;
	private java.util.List ftwMatchStateIn;
	private Integer ftwMatchStateGreaterThanOrEqualTo;
	private Integer ftwMatchStateGreaterThan;
	private Integer ftwMatchStateEqualTo;
	private String ftwMatchBillNotLike;
	private java.util.List ftwMatchBillNotIn;
	private String ftwMatchBillNotEqualTo;
	private String ftwMatchBillLike;
	private String ftwMatchBillLessThanOrEqualTo;
	private String ftwMatchBillLessThan;
	private Boolean ftwMatchBillIsNull;
	private Boolean ftwMatchBillIsNotNull;
	private java.util.List ftwMatchBillIn;
	private String ftwMatchBillGreaterThanOrEqualTo;
	private String ftwMatchBillGreaterThan;
	private String ftwMatchBillEqualTo;
	private java.util.List ftwLeaseCountNotIn;
	private Integer ftwLeaseCountNotEqualTo;
	private Integer ftwLeaseCountLessThanOrEqualTo;
	private Integer ftwLeaseCountLessThan;
	private Boolean ftwLeaseCountIsNull;
	private Boolean ftwLeaseCountIsNotNull;
	private java.util.List ftwLeaseCountIn;
	private Integer ftwLeaseCountGreaterThanOrEqualTo;
	private Integer ftwLeaseCountGreaterThan;
	private Integer ftwLeaseCountEqualTo;
	private String ftwIdnumberNotLike;
	private java.util.List ftwIdnumberNotIn;
	private String ftwIdnumberNotEqualTo;
	private String ftwIdnumberLike;
	private String ftwIdnumberLessThanOrEqualTo;
	private String ftwIdnumberLessThan;
	private Boolean ftwIdnumberIsNull;
	private Boolean ftwIdnumberIsNotNull;
	private java.util.List ftwIdnumberIn;
	private String ftwIdnumberGreaterThanOrEqualTo;
	private String ftwIdnumberGreaterThan;
	private String ftwIdnumberEqualTo;
	private java.util.List ftwIdNotIn;
	private Long ftwIdNotEqualTo;
	private Long ftwIdLessThanOrEqualTo;
	private Long ftwIdLessThan;
	private Boolean ftwIdIsNull;
	private Boolean ftwIdIsNotNull;
	private java.util.List ftwIdIn;
	private Long ftwIdGreaterThanOrEqualTo;
	private Long ftwIdGreaterThan;
	private Long ftwIdEqualTo;
	private java.util.List ftwCityIdNotIn;
	private Long ftwCityIdNotEqualTo;
	private Long ftwCityIdLessThanOrEqualTo;
	private Long ftwCityIdLessThan;
	private Boolean ftwCityIdIsNull;
	private Boolean ftwCityIdIsNotNull;
	private java.util.List ftwCityIdIn;
	private Long ftwCityIdGreaterThanOrEqualTo;
	private Long ftwCityIdGreaterThan;
	private Long ftwCityIdEqualTo;
	private String ftwCarVinNotLike;
	private java.util.List ftwCarVinNotIn;
	private String ftwCarVinNotEqualTo;
	private String ftwCarVinLike;
	private String ftwCarVinLessThanOrEqualTo;
	private String ftwCarVinLessThan;
	private Boolean ftwCarVinIsNull;
	private Boolean ftwCarVinIsNotNull;
	private java.util.List ftwCarVinIn;
	private String ftwCarVinGreaterThanOrEqualTo;
	private String ftwCarVinGreaterThan;
	private String ftwCarVinEqualTo;
	private java.util.List ftwCarModelNotIn;
	private Long ftwCarModelNotEqualTo;
	private Long ftwCarModelLessThanOrEqualTo;
	private Long ftwCarModelLessThan;
	private Boolean ftwCarModelIsNull;
	private Boolean ftwCarModelIsNotNull;
	private java.util.List ftwCarModelIn;
	private Long ftwCarModelGreaterThanOrEqualTo;
	private Long ftwCarModelGreaterThan;
	private Long ftwCarModelEqualTo;
	private String ftwAgreementNumberNotLike;
	private java.util.List ftwAgreementNumberNotIn;
	private String ftwAgreementNumberNotEqualTo;
	private String ftwAgreementNumberLike;
	private String ftwAgreementNumberLessThanOrEqualTo;
	private String ftwAgreementNumberLessThan;
	private Boolean ftwAgreementNumberIsNull;
	private Boolean ftwAgreementNumberIsNotNull;
	private java.util.List ftwAgreementNumberIn;
	private String ftwAgreementNumberGreaterThanOrEqualTo;
	private String ftwAgreementNumberGreaterThan;
	private String ftwAgreementNumberEqualTo;
	private java.util.List drNotIn;
	private Integer drNotEqualTo;
	private Integer drLessThanOrEqualTo;
	private Integer drLessThan;
	private Boolean drIsNull;
	private Boolean drIsNotNull;
	private java.util.List drIn;
	private Integer drGreaterThanOrEqualTo;
	private Integer drGreaterThan;
	private Integer drEqualTo;
	private String createuserNotLike;
	private java.util.List createuserNotIn;
	private String createuserNotEqualTo;
	private String createuserLike;
	private String createuserLessThanOrEqualTo;
	private String createuserLessThan;
	private Boolean createuserIsNull;
	private Boolean createuserIsNotNull;
	private java.util.List createuserIn;
	private String createuserGreaterThanOrEqualTo;
	private String createuserGreaterThan;
	private String createuserEqualTo;
	private java.util.List createtimeNotIn;
	private java.util.Date createtimeNotEqualTo;
	private java.util.Date createtimeLessThanOrEqualTo;
	private java.util.Date createtimeLessThan;
	private Boolean createtimeIsNull;
	private Boolean createtimeIsNotNull;
	private java.util.List createtimeIn;
	private java.util.Date createtimeGreaterThanOrEqualTo;
	private java.util.Date createtimeGreaterThan;
	private java.util.Date createtimeEqualTo;
	private String sidx;
	private String sord;
	public String getSidx(){
		if(this.sidx == null){
			return "";
		}
		else if("updateuser".equals(this.sidx)){
			return "updateuser";
		}
		else if("updatetime".equals(this.sidx)){
			return "updatetime";
		}
		else if("remark".equals(this.sidx)){
			return "remark";
		}
		else if("ftwRentDate".equals(this.sidx)){
			return "ftw_rent_date";
		}
		else if("ftwMatchAmountNot".equals(this.sidx)){
			return "ftw_match_amount_not";
		}
		else if("ftwMatchAmount".equals(this.sidx)){
			return "ftw_match_amount";
		}
		else if("ftwName".equals(this.sidx)){
			return "ftw_name";
		}
		else if("ftwMonthWithhold".equals(this.sidx)){
			return "ftw_month_withhold";
		}
		else if("ftwMonthRent".equals(this.sidx)){
			return "ftw_month_rent";
		}
		else if("ftwMonthRentBalance".equals(this.sidx)){
			return "ftw_month_rent_balance";
		}
		else if("ftwMemberId".equals(this.sidx)){
			return "ftw_member_id";
		}
		else if("ftwMatchedAmount".equals(this.sidx)){
			return "ftw_matched_amount";
		}
		else if("ftwMatchWay".equals(this.sidx)){
			return "ftw_match_way";
		}
		else if("ftwMatchState".equals(this.sidx)){
			return "ftw_match_state";
		}
		else if("ftwMatchBill".equals(this.sidx)){
			return "ftw_match_bill";
		}
		else if("ftwLeaseCount".equals(this.sidx)){
			return "ftw_lease_count";
		}
		else if("ftwIdnumber".equals(this.sidx)){
			return "ftw_idnumber";
		}
		else if("ftwId".equals(this.sidx)){
			return "ftw_id";
		}
		else if("ftwCityId".equals(this.sidx)){
			return "ftw_city_id";
		}
		else if("ftwCarVin".equals(this.sidx)){
			return "ftw_car_vin";
		}
		else if("ftwCarModel".equals(this.sidx)){
			return "ftw_car_model";
		}
		else if("ftwAgreementNumber".equals(this.sidx)){
			return "ftw_agreement_number";
		}
		else if("dr".equals(this.sidx)){
			return "dr";
		}
		else if("createuser".equals(this.sidx)){
			return "createuser";
		}
		else if("createtime".equals(this.sidx)){
			return "createtime";
		}
		return this.sidx;
	}

	@com.fasterxml.jackson.annotation.JsonIgnore
	public com.mrk.finance.example.FncTtWithholdExample getCrieria(){
		com.mrk.finance.example.FncTtWithholdExample q = new com.mrk.finance.example.FncTtWithholdExample();
		com.mrk.finance.example.FncTtWithholdExample.Criteria c = q.createCriteria();
		c.andDrEqualTo(0);
		if(CheckUtil.isNotEmpty(getUpdateuserNotLike())){
			c.andUpdateuserNotLike("%"+this.getUpdateuserNotLike()+"%");
		}
		if(CheckUtil.isNotEmpty(getUpdateuserNotIn())){
			c.andUpdateuserNotIn(this.getUpdateuserNotIn());
		}
		if(CheckUtil.isNotEmpty(getUpdateuserNotEqualTo())){
			c.andUpdateuserNotEqualTo(this.getUpdateuserNotEqualTo());
		}
		if(CheckUtil.isNotEmpty(getUpdateuserLike())){
			c.andUpdateuserLike("%"+this.getUpdateuserLike()+"%");
		}
		if(CheckUtil.isNotEmpty(getUpdateuserLessThanOrEqualTo())){
			c.andUpdateuserLessThanOrEqualTo(this.getUpdateuserLessThanOrEqualTo());
		}
		if(CheckUtil.isNotEmpty(getUpdateuserLessThan())){
			c.andUpdateuserLessThan(this.getUpdateuserLessThan());
		}
		if(CheckUtil.isNotEmpty(getUpdateuserIsNull()) && this.getUpdateuserIsNull()){
			c.andUpdateuserIsNull();
		}
		if(CheckUtil.isNotEmpty(getUpdateuserIsNotNull()) && this.getUpdateuserIsNotNull()){
			c.andUpdateuserIsNotNull();
		}
		if(CheckUtil.isNotEmpty(getUpdateuserIn())){
			c.andUpdateuserIn(this.getUpdateuserIn());
		}
		if(CheckUtil.isNotEmpty(getUpdateuserGreaterThanOrEqualTo())){
			c.andUpdateuserGreaterThanOrEqualTo(this.getUpdateuserGreaterThanOrEqualTo());
		}
		if(CheckUtil.isNotEmpty(getUpdateuserGreaterThan())){
			c.andUpdateuserGreaterThan(this.getUpdateuserGreaterThan());
		}
		if(CheckUtil.isNotEmpty(getUpdateuserEqualTo())){
			c.andUpdateuserEqualTo(this.getUpdateuserEqualTo());
		}
		if(CheckUtil.isNotEmpty(getUpdatetimeNotIn())){
			c.andUpdatetimeNotIn(this.getUpdatetimeNotIn());
		}
		if(CheckUtil.isNotEmpty(getUpdatetimeNotEqualTo())){
			c.andUpdatetimeNotEqualTo(this.getUpdatetimeNotEqualTo());
		}
		if(CheckUtil.isNotEmpty(getUpdatetimeLessThanOrEqualTo())){
			c.andUpdatetimeLessThanOrEqualTo(this.getUpdatetimeLessThanOrEqualTo());
		}
		if(CheckUtil.isNotEmpty(getUpdatetimeLessThan())){
			c.andUpdatetimeLessThan(this.getUpdatetimeLessThan());
		}
		if(CheckUtil.isNotEmpty(getUpdatetimeIsNull()) && this.getUpdatetimeIsNull()){
			c.andUpdatetimeIsNull();
		}
		if(CheckUtil.isNotEmpty(getUpdatetimeIsNotNull()) && this.getUpdatetimeIsNotNull()){
			c.andUpdatetimeIsNotNull();
		}
		if(CheckUtil.isNotEmpty(getUpdatetimeIn())){
			c.andUpdatetimeIn(this.getUpdatetimeIn());
		}
		if(CheckUtil.isNotEmpty(getUpdatetimeGreaterThanOrEqualTo())){
			c.andUpdatetimeGreaterThanOrEqualTo(this.getUpdatetimeGreaterThanOrEqualTo());
		}
		if(CheckUtil.isNotEmpty(getUpdatetimeGreaterThan())){
			c.andUpdatetimeGreaterThan(this.getUpdatetimeGreaterThan());
		}
		if(CheckUtil.isNotEmpty(getUpdatetimeEqualTo())){
			c.andUpdatetimeEqualTo(this.getUpdatetimeEqualTo());
		}
		if(CheckUtil.isNotEmpty(getRemarkNotLike())){
			c.andRemarkNotLike("%"+this.getRemarkNotLike()+"%");
		}
		if(CheckUtil.isNotEmpty(getRemarkNotIn())){
			c.andRemarkNotIn(this.getRemarkNotIn());
		}
		if(CheckUtil.isNotEmpty(getRemarkNotEqualTo())){
			c.andRemarkNotEqualTo(this.getRemarkNotEqualTo());
		}
		if(CheckUtil.isNotEmpty(getRemarkLike())){
			c.andRemarkLike("%"+this.getRemarkLike()+"%");
		}
		if(CheckUtil.isNotEmpty(getRemarkLessThanOrEqualTo())){
			c.andRemarkLessThanOrEqualTo(this.getRemarkLessThanOrEqualTo());
		}
		if(CheckUtil.isNotEmpty(getRemarkLessThan())){
			c.andRemarkLessThan(this.getRemarkLessThan());
		}
		if(CheckUtil.isNotEmpty(getRemarkIsNull()) && this.getRemarkIsNull()){
			c.andRemarkIsNull();
		}
		if(CheckUtil.isNotEmpty(getRemarkIsNotNull()) && this.getRemarkIsNotNull()){
			c.andRemarkIsNotNull();
		}
		if(CheckUtil.isNotEmpty(getRemarkIn())){
			c.andRemarkIn(this.getRemarkIn());
		}
		if(CheckUtil.isNotEmpty(getRemarkGreaterThanOrEqualTo())){
			c.andRemarkGreaterThanOrEqualTo(this.getRemarkGreaterThanOrEqualTo());
		}
		if(CheckUtil.isNotEmpty(getRemarkGreaterThan())){
			c.andRemarkGreaterThan(this.getRemarkGreaterThan());
		}
		if(CheckUtil.isNotEmpty(getRemarkEqualTo())){
			c.andRemarkEqualTo(this.getRemarkEqualTo());
		}
		if(CheckUtil.isNotEmpty(getFtwRentDateNotIn())){
			c.andFtwRentDateNotIn(this.getFtwRentDateNotIn());
		}
		if(CheckUtil.isNotEmpty(getFtwRentDateNotEqualTo())){
			c.andFtwRentDateNotEqualTo(this.getFtwRentDateNotEqualTo());
		}
		if(CheckUtil.isNotEmpty(getFtwRentDateLessThanOrEqualTo())){
			c.andFtwRentDateLessThanOrEqualTo(this.getFtwRentDateLessThanOrEqualTo());
		}
		if(CheckUtil.isNotEmpty(getFtwRentDateLessThan())){
			c.andFtwRentDateLessThan(this.getFtwRentDateLessThan());
		}
		if(CheckUtil.isNotEmpty(getFtwRentDateIsNull()) && this.getFtwRentDateIsNull()){
			c.andFtwRentDateIsNull();
		}
		if(CheckUtil.isNotEmpty(getFtwRentDateIsNotNull()) && this.getFtwRentDateIsNotNull()){
			c.andFtwRentDateIsNotNull();
		}
		if(CheckUtil.isNotEmpty(getFtwRentDateIn())){
			c.andFtwRentDateIn(this.getFtwRentDateIn());
		}
		if(CheckUtil.isNotEmpty(getFtwRentDateGreaterThanOrEqualTo())){
			c.andFtwRentDateGreaterThanOrEqualTo(this.getFtwRentDateGreaterThanOrEqualTo());
		}
		if(CheckUtil.isNotEmpty(getFtwRentDateGreaterThan())){
			c.andFtwRentDateGreaterThan(this.getFtwRentDateGreaterThan());
		}
		if(CheckUtil.isNotEmpty(getFtwRentDateEqualTo())){
			c.andFtwRentDateEqualTo(this.getFtwRentDateEqualTo());
		}
		if(CheckUtil.isNotEmpty(getFtwNotMatchAmountNotIn())){
			c.andFtwNotMatchAmountNotIn(this.getFtwNotMatchAmountNotIn());
		}
		if(CheckUtil.isNotEmpty(getFtwNotMatchAmountNotEqualTo())){
			c.andFtwNotMatchAmountNotEqualTo(this.getFtwNotMatchAmountNotEqualTo());
		}
		if(CheckUtil.isNotEmpty(getFtwNotMatchAmountLessThanOrEqualTo())){
			c.andFtwNotMatchAmountLessThanOrEqualTo(this.getFtwNotMatchAmountLessThanOrEqualTo());
		}
		if(CheckUtil.isNotEmpty(getFtwNotMatchAmountLessThan())){
			c.andFtwNotMatchAmountLessThan(this.getFtwNotMatchAmountLessThan());
		}
		if(CheckUtil.isNotEmpty(getFtwNotMatchAmountIsNull()) && this.getFtwNotMatchAmountIsNull()){
			c.andFtwNotMatchAmountIsNull();
		}
		if(CheckUtil.isNotEmpty(getFtwNotMatchAmountIsNotNull()) && this.getFtwNotMatchAmountIsNotNull()){
			c.andFtwNotMatchAmountIsNotNull();
		}
		if(CheckUtil.isNotEmpty(getFtwNotMatchAmountIn())){
			c.andFtwNotMatchAmountIn(this.getFtwNotMatchAmountIn());
		}
		if(CheckUtil.isNotEmpty(getFtwNotMatchAmountGreaterThanOrEqualTo())){
			c.andFtwNotMatchAmountGreaterThanOrEqualTo(this.getFtwNotMatchAmountGreaterThanOrEqualTo());
		}
		if(CheckUtil.isNotEmpty(getFtwNotMatchAmountGreaterThan())){
			c.andFtwNotMatchAmountGreaterThan(this.getFtwNotMatchAmountGreaterThan());
		}
		if(CheckUtil.isNotEmpty(getFtwNotMatchAmountEqualTo())){
			c.andFtwNotMatchAmountEqualTo(this.getFtwNotMatchAmountEqualTo());
		}
		if(CheckUtil.isNotEmpty(getFtwNameNotLike())){
			c.andFtwNameNotLike("%"+this.getFtwNameNotLike()+"%");
		}
		if(CheckUtil.isNotEmpty(getFtwNameNotIn())){
			c.andFtwNameNotIn(this.getFtwNameNotIn());
		}
		if(CheckUtil.isNotEmpty(getFtwNameNotEqualTo())){
			c.andFtwNameNotEqualTo(this.getFtwNameNotEqualTo());
		}
		if(CheckUtil.isNotEmpty(getFtwNameLike())){
			c.andFtwNameLike("%"+this.getFtwNameLike()+"%");
		}
		if(CheckUtil.isNotEmpty(getFtwNameLessThanOrEqualTo())){
			c.andFtwNameLessThanOrEqualTo(this.getFtwNameLessThanOrEqualTo());
		}
		if(CheckUtil.isNotEmpty(getFtwNameLessThan())){
			c.andFtwNameLessThan(this.getFtwNameLessThan());
		}
		if(CheckUtil.isNotEmpty(getFtwNameIsNull()) && this.getFtwNameIsNull()){
			c.andFtwNameIsNull();
		}
		if(CheckUtil.isNotEmpty(getFtwNameIsNotNull()) && this.getFtwNameIsNotNull()){
			c.andFtwNameIsNotNull();
		}
		if(CheckUtil.isNotEmpty(getFtwNameIn())){
			c.andFtwNameIn(this.getFtwNameIn());
		}
		if(CheckUtil.isNotEmpty(getFtwNameGreaterThanOrEqualTo())){
			c.andFtwNameGreaterThanOrEqualTo(this.getFtwNameGreaterThanOrEqualTo());
		}
		if(CheckUtil.isNotEmpty(getFtwNameGreaterThan())){
			c.andFtwNameGreaterThan(this.getFtwNameGreaterThan());
		}
		if(CheckUtil.isNotEmpty(getFtwNameEqualTo())){
			c.andFtwNameEqualTo(this.getFtwNameEqualTo());
		}
		if(CheckUtil.isNotEmpty(getFtwMonthWithholdNotIn())){
			c.andFtwMonthWithholdNotIn(this.getFtwMonthWithholdNotIn());
		}
		if(CheckUtil.isNotEmpty(getFtwMonthWithholdNotEqualTo())){
			c.andFtwMonthWithholdNotEqualTo(this.getFtwMonthWithholdNotEqualTo());
		}
		if(CheckUtil.isNotEmpty(getFtwMonthWithholdLessThanOrEqualTo())){
			c.andFtwMonthWithholdLessThanOrEqualTo(this.getFtwMonthWithholdLessThanOrEqualTo());
		}
		if(CheckUtil.isNotEmpty(getFtwMonthWithholdLessThan())){
			c.andFtwMonthWithholdLessThan(this.getFtwMonthWithholdLessThan());
		}
		if(CheckUtil.isNotEmpty(getFtwMonthWithholdIsNull()) && this.getFtwMonthWithholdIsNull()){
			c.andFtwMonthWithholdIsNull();
		}
		if(CheckUtil.isNotEmpty(getFtwMonthWithholdIsNotNull()) && this.getFtwMonthWithholdIsNotNull()){
			c.andFtwMonthWithholdIsNotNull();
		}
		if(CheckUtil.isNotEmpty(getFtwMonthWithholdIn())){
			c.andFtwMonthWithholdIn(this.getFtwMonthWithholdIn());
		}
		if(CheckUtil.isNotEmpty(getFtwMonthWithholdGreaterThanOrEqualTo())){
			c.andFtwMonthWithholdGreaterThanOrEqualTo(this.getFtwMonthWithholdGreaterThanOrEqualTo());
		}
		if(CheckUtil.isNotEmpty(getFtwMonthWithholdGreaterThan())){
			c.andFtwMonthWithholdGreaterThan(this.getFtwMonthWithholdGreaterThan());
		}
		if(CheckUtil.isNotEmpty(getFtwMonthWithholdEqualTo())){
			c.andFtwMonthWithholdEqualTo(this.getFtwMonthWithholdEqualTo());
		}
		if(CheckUtil.isNotEmpty(getFtwMonthRentNotIn())){
			c.andFtwMonthRentNotIn(this.getFtwMonthRentNotIn());
		}
		if(CheckUtil.isNotEmpty(getFtwMonthRentNotEqualTo())){
			c.andFtwMonthRentNotEqualTo(this.getFtwMonthRentNotEqualTo());
		}
		if(CheckUtil.isNotEmpty(getFtwMonthRentLessThanOrEqualTo())){
			c.andFtwMonthRentLessThanOrEqualTo(this.getFtwMonthRentLessThanOrEqualTo());
		}
		if(CheckUtil.isNotEmpty(getFtwMonthRentLessThan())){
			c.andFtwMonthRentLessThan(this.getFtwMonthRentLessThan());
		}
		if(CheckUtil.isNotEmpty(getFtwMonthRentIsNull()) && this.getFtwMonthRentIsNull()){
			c.andFtwMonthRentIsNull();
		}
		if(CheckUtil.isNotEmpty(getFtwMonthRentIsNotNull()) && this.getFtwMonthRentIsNotNull()){
			c.andFtwMonthRentIsNotNull();
		}
		if(CheckUtil.isNotEmpty(getFtwMonthRentIn())){
			c.andFtwMonthRentIn(this.getFtwMonthRentIn());
		}
		if(CheckUtil.isNotEmpty(getFtwMonthRentGreaterThanOrEqualTo())){
			c.andFtwMonthRentGreaterThanOrEqualTo(this.getFtwMonthRentGreaterThanOrEqualTo());
		}
		if(CheckUtil.isNotEmpty(getFtwMonthRentGreaterThan())){
			c.andFtwMonthRentGreaterThan(this.getFtwMonthRentGreaterThan());
		}
		if(CheckUtil.isNotEmpty(getFtwMonthRentEqualTo())){
			c.andFtwMonthRentEqualTo(this.getFtwMonthRentEqualTo());
		}
		if(CheckUtil.isNotEmpty(getFtwMonthRentBalanceNotIn())){
			c.andFtwMonthRentBalanceNotIn(this.getFtwMonthRentBalanceNotIn());
		}
		if(CheckUtil.isNotEmpty(getFtwMonthRentBalanceNotEqualTo())){
			c.andFtwMonthRentBalanceNotEqualTo(this.getFtwMonthRentBalanceNotEqualTo());
		}
		if(CheckUtil.isNotEmpty(getFtwMonthRentBalanceLessThanOrEqualTo())){
			c.andFtwMonthRentBalanceLessThanOrEqualTo(this.getFtwMonthRentBalanceLessThanOrEqualTo());
		}
		if(CheckUtil.isNotEmpty(getFtwMonthRentBalanceLessThan())){
			c.andFtwMonthRentBalanceLessThan(this.getFtwMonthRentBalanceLessThan());
		}
		if(CheckUtil.isNotEmpty(getFtwMonthRentBalanceIsNull()) && this.getFtwMonthRentBalanceIsNull()){
			c.andFtwMonthRentBalanceIsNull();
		}
		if(CheckUtil.isNotEmpty(getFtwMonthRentBalanceIsNotNull()) && this.getFtwMonthRentBalanceIsNotNull()){
			c.andFtwMonthRentBalanceIsNotNull();
		}
		if(CheckUtil.isNotEmpty(getFtwMonthRentBalanceIn())){
			c.andFtwMonthRentBalanceIn(this.getFtwMonthRentBalanceIn());
		}
		if(CheckUtil.isNotEmpty(getFtwMonthRentBalanceGreaterThanOrEqualTo())){
			c.andFtwMonthRentBalanceGreaterThanOrEqualTo(this.getFtwMonthRentBalanceGreaterThanOrEqualTo());
		}
		if(CheckUtil.isNotEmpty(getFtwMonthRentBalanceGreaterThan())){
			c.andFtwMonthRentBalanceGreaterThan(this.getFtwMonthRentBalanceGreaterThan());
		}
		if(CheckUtil.isNotEmpty(getFtwMonthRentBalanceEqualTo())){
			c.andFtwMonthRentBalanceEqualTo(this.getFtwMonthRentBalanceEqualTo());
		}
		if(CheckUtil.isNotEmpty(getFtwMemberIdNotIn())){
			c.andFtwMemberIdNotIn(this.getFtwMemberIdNotIn());
		}
		if(CheckUtil.isNotEmpty(getFtwMemberIdNotEqualTo())){
			c.andFtwMemberIdNotEqualTo(this.getFtwMemberIdNotEqualTo());
		}
		if(CheckUtil.isNotEmpty(getFtwMemberIdLessThanOrEqualTo())){
			c.andFtwMemberIdLessThanOrEqualTo(this.getFtwMemberIdLessThanOrEqualTo());
		}
		if(CheckUtil.isNotEmpty(getFtwMemberIdLessThan())){
			c.andFtwMemberIdLessThan(this.getFtwMemberIdLessThan());
		}
		if(CheckUtil.isNotEmpty(getFtwMemberIdIsNull()) && this.getFtwMemberIdIsNull()){
			c.andFtwMemberIdIsNull();
		}
		if(CheckUtil.isNotEmpty(getFtwMemberIdIsNotNull()) && this.getFtwMemberIdIsNotNull()){
			c.andFtwMemberIdIsNotNull();
		}
		if(CheckUtil.isNotEmpty(getFtwMemberIdIn())){
			c.andFtwMemberIdIn(this.getFtwMemberIdIn());
		}
		if(CheckUtil.isNotEmpty(getFtwMemberIdGreaterThanOrEqualTo())){
			c.andFtwMemberIdGreaterThanOrEqualTo(this.getFtwMemberIdGreaterThanOrEqualTo());
		}
		if(CheckUtil.isNotEmpty(getFtwMemberIdGreaterThan())){
			c.andFtwMemberIdGreaterThan(this.getFtwMemberIdGreaterThan());
		}
		if(CheckUtil.isNotEmpty(getFtwMemberIdEqualTo())){
			c.andFtwMemberIdEqualTo(this.getFtwMemberIdEqualTo());
		}
		if(CheckUtil.isNotEmpty(getFtwMatchedAmountNotIn())){
			c.andFtwMatchedAmountNotIn(this.getFtwMatchedAmountNotIn());
		}
		if(CheckUtil.isNotEmpty(getFtwMatchedAmountNotEqualTo())){
			c.andFtwMatchedAmountNotEqualTo(this.getFtwMatchedAmountNotEqualTo());
		}
		if(CheckUtil.isNotEmpty(getFtwMatchedAmountLessThanOrEqualTo())){
			c.andFtwMatchedAmountLessThanOrEqualTo(this.getFtwMatchedAmountLessThanOrEqualTo());
		}
		if(CheckUtil.isNotEmpty(getFtwMatchedAmountLessThan())){
			c.andFtwMatchedAmountLessThan(this.getFtwMatchedAmountLessThan());
		}
		if(CheckUtil.isNotEmpty(getFtwMatchedAmountIsNull()) && this.getFtwMatchedAmountIsNull()){
			c.andFtwMatchedAmountIsNull();
		}
		if(CheckUtil.isNotEmpty(getFtwMatchedAmountIsNotNull()) && this.getFtwMatchedAmountIsNotNull()){
			c.andFtwMatchedAmountIsNotNull();
		}
		if(CheckUtil.isNotEmpty(getFtwMatchedAmountIn())){
			c.andFtwMatchedAmountIn(this.getFtwMatchedAmountIn());
		}
		if(CheckUtil.isNotEmpty(getFtwMatchedAmountGreaterThanOrEqualTo())){
			c.andFtwMatchedAmountGreaterThanOrEqualTo(this.getFtwMatchedAmountGreaterThanOrEqualTo());
		}
		if(CheckUtil.isNotEmpty(getFtwMatchedAmountGreaterThan())){
			c.andFtwMatchedAmountGreaterThan(this.getFtwMatchedAmountGreaterThan());
		}
		if(CheckUtil.isNotEmpty(getFtwMatchedAmountEqualTo())){
			c.andFtwMatchedAmountEqualTo(this.getFtwMatchedAmountEqualTo());
		}
		if(CheckUtil.isNotEmpty(getFtwMatchWayNotIn())){
			c.andFtwMatchWayNotIn(this.getFtwMatchWayNotIn());
		}
		if(CheckUtil.isNotEmpty(getFtwMatchWayNotEqualTo())){
			c.andFtwMatchWayNotEqualTo(this.getFtwMatchWayNotEqualTo());
		}
		if(CheckUtil.isNotEmpty(getFtwMatchWayLessThanOrEqualTo())){
			c.andFtwMatchWayLessThanOrEqualTo(this.getFtwMatchWayLessThanOrEqualTo());
		}
		if(CheckUtil.isNotEmpty(getFtwMatchWayLessThan())){
			c.andFtwMatchWayLessThan(this.getFtwMatchWayLessThan());
		}
		if(CheckUtil.isNotEmpty(getFtwMatchWayIsNull()) && this.getFtwMatchWayIsNull()){
			c.andFtwMatchWayIsNull();
		}
		if(CheckUtil.isNotEmpty(getFtwMatchWayIsNotNull()) && this.getFtwMatchWayIsNotNull()){
			c.andFtwMatchWayIsNotNull();
		}
		if(CheckUtil.isNotEmpty(getFtwMatchWayIn())){
			c.andFtwMatchWayIn(this.getFtwMatchWayIn());
		}
		if(CheckUtil.isNotEmpty(getFtwMatchWayGreaterThanOrEqualTo())){
			c.andFtwMatchWayGreaterThanOrEqualTo(this.getFtwMatchWayGreaterThanOrEqualTo());
		}
		if(CheckUtil.isNotEmpty(getFtwMatchWayGreaterThan())){
			c.andFtwMatchWayGreaterThan(this.getFtwMatchWayGreaterThan());
		}
		if(CheckUtil.isNotEmpty(getFtwMatchWayEqualTo())){
			c.andFtwMatchWayEqualTo(this.getFtwMatchWayEqualTo());
		}
		if(CheckUtil.isNotEmpty(getFtwMatchStateNotIn())){
			c.andFtwMatchStateNotIn(this.getFtwMatchStateNotIn());
		}
		if(CheckUtil.isNotEmpty(getFtwMatchStateNotEqualTo())){
			c.andFtwMatchStateNotEqualTo(this.getFtwMatchStateNotEqualTo());
		}
		if(CheckUtil.isNotEmpty(getFtwMatchStateLessThanOrEqualTo())){
			c.andFtwMatchStateLessThanOrEqualTo(this.getFtwMatchStateLessThanOrEqualTo());
		}
		if(CheckUtil.isNotEmpty(getFtwMatchStateLessThan())){
			c.andFtwMatchStateLessThan(this.getFtwMatchStateLessThan());
		}
		if(CheckUtil.isNotEmpty(getFtwMatchStateIsNull()) && this.getFtwMatchStateIsNull()){
			c.andFtwMatchStateIsNull();
		}
		if(CheckUtil.isNotEmpty(getFtwMatchStateIsNotNull()) && this.getFtwMatchStateIsNotNull()){
			c.andFtwMatchStateIsNotNull();
		}
		if(CheckUtil.isNotEmpty(getFtwMatchStateIn())){
			c.andFtwMatchStateIn(this.getFtwMatchStateIn());
		}
		if(CheckUtil.isNotEmpty(getFtwMatchStateGreaterThanOrEqualTo())){
			c.andFtwMatchStateGreaterThanOrEqualTo(this.getFtwMatchStateGreaterThanOrEqualTo());
		}
		if(CheckUtil.isNotEmpty(getFtwMatchStateGreaterThan())){
			c.andFtwMatchStateGreaterThan(this.getFtwMatchStateGreaterThan());
		}
		if(CheckUtil.isNotEmpty(getFtwMatchStateEqualTo())){
			c.andFtwMatchStateEqualTo(this.getFtwMatchStateEqualTo());
		}
		if(CheckUtil.isNotEmpty(getFtwMatchBillNotLike())){
			c.andFtwMatchBillNotLike("%"+this.getFtwMatchBillNotLike()+"%");
		}
		if(CheckUtil.isNotEmpty(getFtwMatchBillNotIn())){
			c.andFtwMatchBillNotIn(this.getFtwMatchBillNotIn());
		}
		if(CheckUtil.isNotEmpty(getFtwMatchBillNotEqualTo())){
			c.andFtwMatchBillNotEqualTo(this.getFtwMatchBillNotEqualTo());
		}
		if(CheckUtil.isNotEmpty(getFtwMatchBillLike())){
			c.andFtwMatchBillLike("%"+this.getFtwMatchBillLike()+"%");
		}
		if(CheckUtil.isNotEmpty(getFtwMatchBillLessThanOrEqualTo())){
			c.andFtwMatchBillLessThanOrEqualTo(this.getFtwMatchBillLessThanOrEqualTo());
		}
		if(CheckUtil.isNotEmpty(getFtwMatchBillLessThan())){
			c.andFtwMatchBillLessThan(this.getFtwMatchBillLessThan());
		}
		if(CheckUtil.isNotEmpty(getFtwMatchBillIsNull()) && this.getFtwMatchBillIsNull()){
			c.andFtwMatchBillIsNull();
		}
		if(CheckUtil.isNotEmpty(getFtwMatchBillIsNotNull()) && this.getFtwMatchBillIsNotNull()){
			c.andFtwMatchBillIsNotNull();
		}
		if(CheckUtil.isNotEmpty(getFtwMatchBillIn())){
			c.andFtwMatchBillIn(this.getFtwMatchBillIn());
		}
		if(CheckUtil.isNotEmpty(getFtwMatchBillGreaterThanOrEqualTo())){
			c.andFtwMatchBillGreaterThanOrEqualTo(this.getFtwMatchBillGreaterThanOrEqualTo());
		}
		if(CheckUtil.isNotEmpty(getFtwMatchBillGreaterThan())){
			c.andFtwMatchBillGreaterThan(this.getFtwMatchBillGreaterThan());
		}
		if(CheckUtil.isNotEmpty(getFtwMatchBillEqualTo())){
			c.andFtwMatchBillEqualTo(this.getFtwMatchBillEqualTo());
		}
		if(CheckUtil.isNotEmpty(getFtwLeaseCountNotIn())){
			c.andFtwLeaseCountNotIn(this.getFtwLeaseCountNotIn());
		}
		if(CheckUtil.isNotEmpty(getFtwLeaseCountNotEqualTo())){
			c.andFtwLeaseCountNotEqualTo(this.getFtwLeaseCountNotEqualTo());
		}
		if(CheckUtil.isNotEmpty(getFtwLeaseCountLessThanOrEqualTo())){
			c.andFtwLeaseCountLessThanOrEqualTo(this.getFtwLeaseCountLessThanOrEqualTo());
		}
		if(CheckUtil.isNotEmpty(getFtwLeaseCountLessThan())){
			c.andFtwLeaseCountLessThan(this.getFtwLeaseCountLessThan());
		}
		if(CheckUtil.isNotEmpty(getFtwLeaseCountIsNull()) && this.getFtwLeaseCountIsNull()){
			c.andFtwLeaseCountIsNull();
		}
		if(CheckUtil.isNotEmpty(getFtwLeaseCountIsNotNull()) && this.getFtwLeaseCountIsNotNull()){
			c.andFtwLeaseCountIsNotNull();
		}
		if(CheckUtil.isNotEmpty(getFtwLeaseCountIn())){
			c.andFtwLeaseCountIn(this.getFtwLeaseCountIn());
		}
		if(CheckUtil.isNotEmpty(getFtwLeaseCountGreaterThanOrEqualTo())){
			c.andFtwLeaseCountGreaterThanOrEqualTo(this.getFtwLeaseCountGreaterThanOrEqualTo());
		}
		if(CheckUtil.isNotEmpty(getFtwLeaseCountGreaterThan())){
			c.andFtwLeaseCountGreaterThan(this.getFtwLeaseCountGreaterThan());
		}
		if(CheckUtil.isNotEmpty(getFtwLeaseCountEqualTo())){
			c.andFtwLeaseCountEqualTo(this.getFtwLeaseCountEqualTo());
		}
		if(CheckUtil.isNotEmpty(getFtwIdnumberNotLike())){
			c.andFtwIdnumberNotLike("%"+this.getFtwIdnumberNotLike()+"%");
		}
		if(CheckUtil.isNotEmpty(getFtwIdnumberNotIn())){
			c.andFtwIdnumberNotIn(this.getFtwIdnumberNotIn());
		}
		if(CheckUtil.isNotEmpty(getFtwIdnumberNotEqualTo())){
			c.andFtwIdnumberNotEqualTo(this.getFtwIdnumberNotEqualTo());
		}
		if(CheckUtil.isNotEmpty(getFtwIdnumberLike())){
			c.andFtwIdnumberLike("%"+this.getFtwIdnumberLike()+"%");
		}
		if(CheckUtil.isNotEmpty(getFtwIdnumberLessThanOrEqualTo())){
			c.andFtwIdnumberLessThanOrEqualTo(this.getFtwIdnumberLessThanOrEqualTo());
		}
		if(CheckUtil.isNotEmpty(getFtwIdnumberLessThan())){
			c.andFtwIdnumberLessThan(this.getFtwIdnumberLessThan());
		}
		if(CheckUtil.isNotEmpty(getFtwIdnumberIsNull()) && this.getFtwIdnumberIsNull()){
			c.andFtwIdnumberIsNull();
		}
		if(CheckUtil.isNotEmpty(getFtwIdnumberIsNotNull()) && this.getFtwIdnumberIsNotNull()){
			c.andFtwIdnumberIsNotNull();
		}
		if(CheckUtil.isNotEmpty(getFtwIdnumberIn())){
			c.andFtwIdnumberIn(this.getFtwIdnumberIn());
		}
		if(CheckUtil.isNotEmpty(getFtwIdnumberGreaterThanOrEqualTo())){
			c.andFtwIdnumberGreaterThanOrEqualTo(this.getFtwIdnumberGreaterThanOrEqualTo());
		}
		if(CheckUtil.isNotEmpty(getFtwIdnumberGreaterThan())){
			c.andFtwIdnumberGreaterThan(this.getFtwIdnumberGreaterThan());
		}
		if(CheckUtil.isNotEmpty(getFtwIdnumberEqualTo())){
			c.andFtwIdnumberEqualTo(this.getFtwIdnumberEqualTo());
		}
		if(CheckUtil.isNotEmpty(getFtwIdNotIn())){
			c.andFtwIdNotIn(this.getFtwIdNotIn());
		}
		if(CheckUtil.isNotEmpty(getFtwIdNotEqualTo())){
			c.andFtwIdNotEqualTo(this.getFtwIdNotEqualTo());
		}
		if(CheckUtil.isNotEmpty(getFtwIdLessThanOrEqualTo())){
			c.andFtwIdLessThanOrEqualTo(this.getFtwIdLessThanOrEqualTo());
		}
		if(CheckUtil.isNotEmpty(getFtwIdLessThan())){
			c.andFtwIdLessThan(this.getFtwIdLessThan());
		}
		if(CheckUtil.isNotEmpty(getFtwIdIsNull()) && this.getFtwIdIsNull()){
			c.andFtwIdIsNull();
		}
		if(CheckUtil.isNotEmpty(getFtwIdIsNotNull()) && this.getFtwIdIsNotNull()){
			c.andFtwIdIsNotNull();
		}
		if(CheckUtil.isNotEmpty(getFtwIdIn())){
			c.andFtwIdIn(this.getFtwIdIn());
		}
		if(CheckUtil.isNotEmpty(getFtwIdGreaterThanOrEqualTo())){
			c.andFtwIdGreaterThanOrEqualTo(this.getFtwIdGreaterThanOrEqualTo());
		}
		if(CheckUtil.isNotEmpty(getFtwIdGreaterThan())){
			c.andFtwIdGreaterThan(this.getFtwIdGreaterThan());
		}
		if(CheckUtil.isNotEmpty(getFtwIdEqualTo())){
			c.andFtwIdEqualTo(this.getFtwIdEqualTo());
		}
		if(CheckUtil.isNotEmpty(getFtwCityIdNotIn())){
			c.andFtwCityIdNotIn(this.getFtwCityIdNotIn());
		}
		if(CheckUtil.isNotEmpty(getFtwCityIdNotEqualTo())){
			c.andFtwCityIdNotEqualTo(this.getFtwCityIdNotEqualTo());
		}
		if(CheckUtil.isNotEmpty(getFtwCityIdLessThanOrEqualTo())){
			c.andFtwCityIdLessThanOrEqualTo(this.getFtwCityIdLessThanOrEqualTo());
		}
		if(CheckUtil.isNotEmpty(getFtwCityIdLessThan())){
			c.andFtwCityIdLessThan(this.getFtwCityIdLessThan());
		}
		if(CheckUtil.isNotEmpty(getFtwCityIdIsNull()) && this.getFtwCityIdIsNull()){
			c.andFtwCityIdIsNull();
		}
		if(CheckUtil.isNotEmpty(getFtwCityIdIsNotNull()) && this.getFtwCityIdIsNotNull()){
			c.andFtwCityIdIsNotNull();
		}
		if(CheckUtil.isNotEmpty(getFtwCityIdIn())){
			c.andFtwCityIdIn(this.getFtwCityIdIn());
		}
		if(CheckUtil.isNotEmpty(getFtwCityIdGreaterThanOrEqualTo())){
			c.andFtwCityIdGreaterThanOrEqualTo(this.getFtwCityIdGreaterThanOrEqualTo());
		}
		if(CheckUtil.isNotEmpty(getFtwCityIdGreaterThan())){
			c.andFtwCityIdGreaterThan(this.getFtwCityIdGreaterThan());
		}
		if(CheckUtil.isNotEmpty(getFtwCityIdEqualTo())){
			c.andFtwCityIdEqualTo(this.getFtwCityIdEqualTo());
		}
		if(CheckUtil.isNotEmpty(getFtwCarVinNotLike())){
			c.andFtwCarVinNotLike("%"+this.getFtwCarVinNotLike()+"%");
		}
		if(CheckUtil.isNotEmpty(getFtwCarVinNotIn())){
			c.andFtwCarVinNotIn(this.getFtwCarVinNotIn());
		}
		if(CheckUtil.isNotEmpty(getFtwCarVinNotEqualTo())){
			c.andFtwCarVinNotEqualTo(this.getFtwCarVinNotEqualTo());
		}
		if(CheckUtil.isNotEmpty(getFtwCarVinLike())){
			c.andFtwCarVinLike("%"+this.getFtwCarVinLike()+"%");
		}
		if(CheckUtil.isNotEmpty(getFtwCarVinLessThanOrEqualTo())){
			c.andFtwCarVinLessThanOrEqualTo(this.getFtwCarVinLessThanOrEqualTo());
		}
		if(CheckUtil.isNotEmpty(getFtwCarVinLessThan())){
			c.andFtwCarVinLessThan(this.getFtwCarVinLessThan());
		}
		if(CheckUtil.isNotEmpty(getFtwCarVinIsNull()) && this.getFtwCarVinIsNull()){
			c.andFtwCarVinIsNull();
		}
		if(CheckUtil.isNotEmpty(getFtwCarVinIsNotNull()) && this.getFtwCarVinIsNotNull()){
			c.andFtwCarVinIsNotNull();
		}
		if(CheckUtil.isNotEmpty(getFtwCarVinIn())){
			c.andFtwCarVinIn(this.getFtwCarVinIn());
		}
		if(CheckUtil.isNotEmpty(getFtwCarVinGreaterThanOrEqualTo())){
			c.andFtwCarVinGreaterThanOrEqualTo(this.getFtwCarVinGreaterThanOrEqualTo());
		}
		if(CheckUtil.isNotEmpty(getFtwCarVinGreaterThan())){
			c.andFtwCarVinGreaterThan(this.getFtwCarVinGreaterThan());
		}
		if(CheckUtil.isNotEmpty(getFtwCarVinEqualTo())){
			c.andFtwCarVinEqualTo(this.getFtwCarVinEqualTo());
		}
		if(CheckUtil.isNotEmpty(getFtwCarModelNotIn())){
			c.andFtwCarModelNotIn(this.getFtwCarModelNotIn());
		}
		if(CheckUtil.isNotEmpty(getFtwCarModelNotEqualTo())){
			c.andFtwCarModelNotEqualTo(this.getFtwCarModelNotEqualTo());
		}
		if(CheckUtil.isNotEmpty(getFtwCarModelLessThanOrEqualTo())){
			c.andFtwCarModelLessThanOrEqualTo(this.getFtwCarModelLessThanOrEqualTo());
		}
		if(CheckUtil.isNotEmpty(getFtwCarModelLessThan())){
			c.andFtwCarModelLessThan(this.getFtwCarModelLessThan());
		}
		if(CheckUtil.isNotEmpty(getFtwCarModelIsNull()) && this.getFtwCarModelIsNull()){
			c.andFtwCarModelIsNull();
		}
		if(CheckUtil.isNotEmpty(getFtwCarModelIsNotNull()) && this.getFtwCarModelIsNotNull()){
			c.andFtwCarModelIsNotNull();
		}
		if(CheckUtil.isNotEmpty(getFtwCarModelIn())){
			c.andFtwCarModelIn(this.getFtwCarModelIn());
		}
		if(CheckUtil.isNotEmpty(getFtwCarModelGreaterThanOrEqualTo())){
			c.andFtwCarModelGreaterThanOrEqualTo(this.getFtwCarModelGreaterThanOrEqualTo());
		}
		if(CheckUtil.isNotEmpty(getFtwCarModelGreaterThan())){
			c.andFtwCarModelGreaterThan(this.getFtwCarModelGreaterThan());
		}
		if(CheckUtil.isNotEmpty(getFtwCarModelEqualTo())){
			c.andFtwCarModelEqualTo(this.getFtwCarModelEqualTo());
		}
		if(CheckUtil.isNotEmpty(getFtwAgreementNumberNotLike())){
			c.andFtwAgreementNumberNotLike("%"+this.getFtwAgreementNumberNotLike()+"%");
		}
		if(CheckUtil.isNotEmpty(getFtwAgreementNumberNotIn())){
			c.andFtwAgreementNumberNotIn(this.getFtwAgreementNumberNotIn());
		}
		if(CheckUtil.isNotEmpty(getFtwAgreementNumberNotEqualTo())){
			c.andFtwAgreementNumberNotEqualTo(this.getFtwAgreementNumberNotEqualTo());
		}
		if(CheckUtil.isNotEmpty(getFtwAgreementNumberLike())){
			c.andFtwAgreementNumberLike("%"+this.getFtwAgreementNumberLike()+"%");
		}
		if(CheckUtil.isNotEmpty(getFtwAgreementNumberLessThanOrEqualTo())){
			c.andFtwAgreementNumberLessThanOrEqualTo(this.getFtwAgreementNumberLessThanOrEqualTo());
		}
		if(CheckUtil.isNotEmpty(getFtwAgreementNumberLessThan())){
			c.andFtwAgreementNumberLessThan(this.getFtwAgreementNumberLessThan());
		}
		if(CheckUtil.isNotEmpty(getFtwAgreementNumberIsNull()) && this.getFtwAgreementNumberIsNull()){
			c.andFtwAgreementNumberIsNull();
		}
		if(CheckUtil.isNotEmpty(getFtwAgreementNumberIsNotNull()) && this.getFtwAgreementNumberIsNotNull()){
			c.andFtwAgreementNumberIsNotNull();
		}
		if(CheckUtil.isNotEmpty(getFtwAgreementNumberIn())){
			c.andFtwAgreementNumberIn(this.getFtwAgreementNumberIn());
		}
		if(CheckUtil.isNotEmpty(getFtwAgreementNumberGreaterThanOrEqualTo())){
			c.andFtwAgreementNumberGreaterThanOrEqualTo(this.getFtwAgreementNumberGreaterThanOrEqualTo());
		}
		if(CheckUtil.isNotEmpty(getFtwAgreementNumberGreaterThan())){
			c.andFtwAgreementNumberGreaterThan(this.getFtwAgreementNumberGreaterThan());
		}
		if(CheckUtil.isNotEmpty(getFtwAgreementNumberEqualTo())){
			c.andFtwAgreementNumberEqualTo(this.getFtwAgreementNumberEqualTo());
		}
		if(CheckUtil.isNotEmpty(getDrNotIn())){
			c.andDrNotIn(this.getDrNotIn());
		}
		if(CheckUtil.isNotEmpty(getDrNotEqualTo())){
			c.andDrNotEqualTo(this.getDrNotEqualTo());
		}
		if(CheckUtil.isNotEmpty(getDrLessThanOrEqualTo())){
			c.andDrLessThanOrEqualTo(this.getDrLessThanOrEqualTo());
		}
		if(CheckUtil.isNotEmpty(getDrLessThan())){
			c.andDrLessThan(this.getDrLessThan());
		}
		if(CheckUtil.isNotEmpty(getDrIsNull()) && this.getDrIsNull()){
			c.andDrIsNull();
		}
		if(CheckUtil.isNotEmpty(getDrIsNotNull()) && this.getDrIsNotNull()){
			c.andDrIsNotNull();
		}
		if(CheckUtil.isNotEmpty(getDrIn())){
			c.andDrIn(this.getDrIn());
		}
		if(CheckUtil.isNotEmpty(getDrGreaterThanOrEqualTo())){
			c.andDrGreaterThanOrEqualTo(this.getDrGreaterThanOrEqualTo());
		}
		if(CheckUtil.isNotEmpty(getDrGreaterThan())){
			c.andDrGreaterThan(this.getDrGreaterThan());
		}
		if(CheckUtil.isNotEmpty(getDrEqualTo())){
			c.andDrEqualTo(this.getDrEqualTo());
		}
		if(CheckUtil.isNotEmpty(getCreateuserNotLike())){
			c.andCreateuserNotLike("%"+this.getCreateuserNotLike()+"%");
		}
		if(CheckUtil.isNotEmpty(getCreateuserNotIn())){
			c.andCreateuserNotIn(this.getCreateuserNotIn());
		}
		if(CheckUtil.isNotEmpty(getCreateuserNotEqualTo())){
			c.andCreateuserNotEqualTo(this.getCreateuserNotEqualTo());
		}
		if(CheckUtil.isNotEmpty(getCreateuserLike())){
			c.andCreateuserLike("%"+this.getCreateuserLike()+"%");
		}
		if(CheckUtil.isNotEmpty(getCreateuserLessThanOrEqualTo())){
			c.andCreateuserLessThanOrEqualTo(this.getCreateuserLessThanOrEqualTo());
		}
		if(CheckUtil.isNotEmpty(getCreateuserLessThan())){
			c.andCreateuserLessThan(this.getCreateuserLessThan());
		}
		if(CheckUtil.isNotEmpty(getCreateuserIsNull()) && this.getCreateuserIsNull()){
			c.andCreateuserIsNull();
		}
		if(CheckUtil.isNotEmpty(getCreateuserIsNotNull()) && this.getCreateuserIsNotNull()){
			c.andCreateuserIsNotNull();
		}
		if(CheckUtil.isNotEmpty(getCreateuserIn())){
			c.andCreateuserIn(this.getCreateuserIn());
		}
		if(CheckUtil.isNotEmpty(getCreateuserGreaterThanOrEqualTo())){
			c.andCreateuserGreaterThanOrEqualTo(this.getCreateuserGreaterThanOrEqualTo());
		}
		if(CheckUtil.isNotEmpty(getCreateuserGreaterThan())){
			c.andCreateuserGreaterThan(this.getCreateuserGreaterThan());
		}
		if(CheckUtil.isNotEmpty(getCreateuserEqualTo())){
			c.andCreateuserEqualTo(this.getCreateuserEqualTo());
		}
		if(CheckUtil.isNotEmpty(getCreatetimeNotIn())){
			c.andCreatetimeNotIn(this.getCreatetimeNotIn());
		}
		if(CheckUtil.isNotEmpty(getCreatetimeNotEqualTo())){
			c.andCreatetimeNotEqualTo(this.getCreatetimeNotEqualTo());
		}
		if(CheckUtil.isNotEmpty(getCreatetimeLessThanOrEqualTo())){
			c.andCreatetimeLessThanOrEqualTo(this.getCreatetimeLessThanOrEqualTo());
		}
		if(CheckUtil.isNotEmpty(getCreatetimeLessThan())){
			c.andCreatetimeLessThan(this.getCreatetimeLessThan());
		}
		if(CheckUtil.isNotEmpty(getCreatetimeIsNull()) && this.getCreatetimeIsNull()){
			c.andCreatetimeIsNull();
		}
		if(CheckUtil.isNotEmpty(getCreatetimeIsNotNull()) && this.getCreatetimeIsNotNull()){
			c.andCreatetimeIsNotNull();
		}
		if(CheckUtil.isNotEmpty(getCreatetimeIn())){
			c.andCreatetimeIn(this.getCreatetimeIn());
		}
		if(CheckUtil.isNotEmpty(getCreatetimeGreaterThanOrEqualTo())){
			c.andCreatetimeGreaterThanOrEqualTo(this.getCreatetimeGreaterThanOrEqualTo());
		}
		if(CheckUtil.isNotEmpty(getCreatetimeGreaterThan())){
			c.andCreatetimeGreaterThan(this.getCreatetimeGreaterThan());
		}
		if(CheckUtil.isNotEmpty(getCreatetimeEqualTo())){
			c.andCreatetimeEqualTo(this.getCreatetimeEqualTo());
		}
		if((this.getSidx()!=null && !this.getSidx().trim().equals("")) && this.getSord()!=null) {
			q.setOrderByClause(""+ this.getSidx()+" "+this.getSord());
		}
		return q;
	}
	public String getUpdateuserNotLike() {
		return updateuserNotLike;
	}
	public void setUpdateuserNotLike(String updateuserNotLike) {
		this.updateuserNotLike = updateuserNotLike;
	}

	public java.util.List getUpdateuserNotIn() {
		return updateuserNotIn;
	}
	public void setUpdateuserNotIn(java.util.List updateuserNotIn) {
		this.updateuserNotIn = updateuserNotIn;
	}

	public String getUpdateuserNotEqualTo() {
		return updateuserNotEqualTo;
	}
	public void setUpdateuserNotEqualTo(String updateuserNotEqualTo) {
		this.updateuserNotEqualTo = updateuserNotEqualTo;
	}

	public String getUpdateuserLike() {
		return updateuserLike;
	}
	public void setUpdateuserLike(String updateuserLike) {
		this.updateuserLike = updateuserLike;
	}

	public String getUpdateuserLessThanOrEqualTo() {
		return updateuserLessThanOrEqualTo;
	}
	public void setUpdateuserLessThanOrEqualTo(String updateuserLessThanOrEqualTo) {
		this.updateuserLessThanOrEqualTo = updateuserLessThanOrEqualTo;
	}

	public String getUpdateuserLessThan() {
		return updateuserLessThan;
	}
	public void setUpdateuserLessThan(String updateuserLessThan) {
		this.updateuserLessThan = updateuserLessThan;
	}

	public Boolean getUpdateuserIsNull() {
		return updateuserIsNull;
	}
	public void setUpdateuserIsNull(Boolean updateuserIsNull) {
		this.updateuserIsNull = updateuserIsNull;
	}

	public Boolean getUpdateuserIsNotNull() {
		return updateuserIsNotNull;
	}
	public void setUpdateuserIsNotNull(Boolean updateuserIsNotNull) {
		this.updateuserIsNotNull = updateuserIsNotNull;
	}

	public java.util.List getUpdateuserIn() {
		return updateuserIn;
	}
	public void setUpdateuserIn(java.util.List updateuserIn) {
		this.updateuserIn = updateuserIn;
	}

	public String getUpdateuserGreaterThanOrEqualTo() {
		return updateuserGreaterThanOrEqualTo;
	}
	public void setUpdateuserGreaterThanOrEqualTo(String updateuserGreaterThanOrEqualTo) {
		this.updateuserGreaterThanOrEqualTo = updateuserGreaterThanOrEqualTo;
	}

	public String getUpdateuserGreaterThan() {
		return updateuserGreaterThan;
	}
	public void setUpdateuserGreaterThan(String updateuserGreaterThan) {
		this.updateuserGreaterThan = updateuserGreaterThan;
	}

	public String getUpdateuserEqualTo() {
		return updateuserEqualTo;
	}
	public void setUpdateuserEqualTo(String updateuserEqualTo) {
		this.updateuserEqualTo = updateuserEqualTo;
	}

	public java.util.List getUpdatetimeNotIn() {
		return updatetimeNotIn;
	}
	public void setUpdatetimeNotIn(java.util.List updatetimeNotIn) {
		this.updatetimeNotIn = updatetimeNotIn;
	}

	public java.util.Date getUpdatetimeNotEqualTo() {
		return updatetimeNotEqualTo;
	}
	public void setUpdatetimeNotEqualTo(java.util.Date updatetimeNotEqualTo) {
		this.updatetimeNotEqualTo = updatetimeNotEqualTo;
	}

	public java.util.Date getUpdatetimeLessThanOrEqualTo() {
		return updatetimeLessThanOrEqualTo;
	}
	public void setUpdatetimeLessThanOrEqualTo(java.util.Date updatetimeLessThanOrEqualTo) {
		this.updatetimeLessThanOrEqualTo = updatetimeLessThanOrEqualTo;
	}

	public java.util.Date getUpdatetimeLessThan() {
		return updatetimeLessThan;
	}
	public void setUpdatetimeLessThan(java.util.Date updatetimeLessThan) {
		this.updatetimeLessThan = updatetimeLessThan;
	}

	public Boolean getUpdatetimeIsNull() {
		return updatetimeIsNull;
	}
	public void setUpdatetimeIsNull(Boolean updatetimeIsNull) {
		this.updatetimeIsNull = updatetimeIsNull;
	}

	public Boolean getUpdatetimeIsNotNull() {
		return updatetimeIsNotNull;
	}
	public void setUpdatetimeIsNotNull(Boolean updatetimeIsNotNull) {
		this.updatetimeIsNotNull = updatetimeIsNotNull;
	}

	public java.util.List getUpdatetimeIn() {
		return updatetimeIn;
	}
	public void setUpdatetimeIn(java.util.List updatetimeIn) {
		this.updatetimeIn = updatetimeIn;
	}

	public java.util.Date getUpdatetimeGreaterThanOrEqualTo() {
		return updatetimeGreaterThanOrEqualTo;
	}
	public void setUpdatetimeGreaterThanOrEqualTo(java.util.Date updatetimeGreaterThanOrEqualTo) {
		this.updatetimeGreaterThanOrEqualTo = updatetimeGreaterThanOrEqualTo;
	}

	public java.util.Date getUpdatetimeGreaterThan() {
		return updatetimeGreaterThan;
	}
	public void setUpdatetimeGreaterThan(java.util.Date updatetimeGreaterThan) {
		this.updatetimeGreaterThan = updatetimeGreaterThan;
	}

	public java.util.Date getUpdatetimeEqualTo() {
		return updatetimeEqualTo;
	}
	public void setUpdatetimeEqualTo(java.util.Date updatetimeEqualTo) {
		this.updatetimeEqualTo = updatetimeEqualTo;
	}

	public String getRemarkNotLike() {
		return remarkNotLike;
	}
	public void setRemarkNotLike(String remarkNotLike) {
		this.remarkNotLike = remarkNotLike;
	}

	public java.util.List getRemarkNotIn() {
		return remarkNotIn;
	}
	public void setRemarkNotIn(java.util.List remarkNotIn) {
		this.remarkNotIn = remarkNotIn;
	}

	public String getRemarkNotEqualTo() {
		return remarkNotEqualTo;
	}
	public void setRemarkNotEqualTo(String remarkNotEqualTo) {
		this.remarkNotEqualTo = remarkNotEqualTo;
	}

	public String getRemarkLike() {
		return remarkLike;
	}
	public void setRemarkLike(String remarkLike) {
		this.remarkLike = remarkLike;
	}

	public String getRemarkLessThanOrEqualTo() {
		return remarkLessThanOrEqualTo;
	}
	public void setRemarkLessThanOrEqualTo(String remarkLessThanOrEqualTo) {
		this.remarkLessThanOrEqualTo = remarkLessThanOrEqualTo;
	}

	public String getRemarkLessThan() {
		return remarkLessThan;
	}
	public void setRemarkLessThan(String remarkLessThan) {
		this.remarkLessThan = remarkLessThan;
	}

	public Boolean getRemarkIsNull() {
		return remarkIsNull;
	}
	public void setRemarkIsNull(Boolean remarkIsNull) {
		this.remarkIsNull = remarkIsNull;
	}

	public Boolean getRemarkIsNotNull() {
		return remarkIsNotNull;
	}
	public void setRemarkIsNotNull(Boolean remarkIsNotNull) {
		this.remarkIsNotNull = remarkIsNotNull;
	}

	public java.util.List getRemarkIn() {
		return remarkIn;
	}
	public void setRemarkIn(java.util.List remarkIn) {
		this.remarkIn = remarkIn;
	}

	public String getRemarkGreaterThanOrEqualTo() {
		return remarkGreaterThanOrEqualTo;
	}
	public void setRemarkGreaterThanOrEqualTo(String remarkGreaterThanOrEqualTo) {
		this.remarkGreaterThanOrEqualTo = remarkGreaterThanOrEqualTo;
	}

	public String getRemarkGreaterThan() {
		return remarkGreaterThan;
	}
	public void setRemarkGreaterThan(String remarkGreaterThan) {
		this.remarkGreaterThan = remarkGreaterThan;
	}

	public String getRemarkEqualTo() {
		return remarkEqualTo;
	}
	public void setRemarkEqualTo(String remarkEqualTo) {
		this.remarkEqualTo = remarkEqualTo;
	}

	public java.util.List getFtwRentDateNotIn() {
		return ftwRentDateNotIn;
	}
	public void setFtwRentDateNotIn(java.util.List ftwRentDateNotIn) {
		this.ftwRentDateNotIn = ftwRentDateNotIn;
	}

	public java.util.Date getFtwRentDateNotEqualTo() {
		return ftwRentDateNotEqualTo;
	}
	public void setFtwRentDateNotEqualTo(java.util.Date ftwRentDateNotEqualTo) {
		this.ftwRentDateNotEqualTo = ftwRentDateNotEqualTo;
	}

	public java.util.Date getFtwRentDateLessThanOrEqualTo() {
		return ftwRentDateLessThanOrEqualTo;
	}
	public void setFtwRentDateLessThanOrEqualTo(java.util.Date ftwRentDateLessThanOrEqualTo) {
		this.ftwRentDateLessThanOrEqualTo = ftwRentDateLessThanOrEqualTo;
	}

	public java.util.Date getFtwRentDateLessThan() {
		return ftwRentDateLessThan;
	}
	public void setFtwRentDateLessThan(java.util.Date ftwRentDateLessThan) {
		this.ftwRentDateLessThan = ftwRentDateLessThan;
	}

	public Boolean getFtwRentDateIsNull() {
		return ftwRentDateIsNull;
	}
	public void setFtwRentDateIsNull(Boolean ftwRentDateIsNull) {
		this.ftwRentDateIsNull = ftwRentDateIsNull;
	}

	public Boolean getFtwRentDateIsNotNull() {
		return ftwRentDateIsNotNull;
	}
	public void setFtwRentDateIsNotNull(Boolean ftwRentDateIsNotNull) {
		this.ftwRentDateIsNotNull = ftwRentDateIsNotNull;
	}

	public java.util.List getFtwRentDateIn() {
		return ftwRentDateIn;
	}
	public void setFtwRentDateIn(java.util.List ftwRentDateIn) {
		this.ftwRentDateIn = ftwRentDateIn;
	}

	public java.util.Date getFtwRentDateGreaterThanOrEqualTo() {
		return ftwRentDateGreaterThanOrEqualTo;
	}
	public void setFtwRentDateGreaterThanOrEqualTo(java.util.Date ftwRentDateGreaterThanOrEqualTo) {
		this.ftwRentDateGreaterThanOrEqualTo = ftwRentDateGreaterThanOrEqualTo;
	}

	public java.util.Date getFtwRentDateGreaterThan() {
		return ftwRentDateGreaterThan;
	}
	public void setFtwRentDateGreaterThan(java.util.Date ftwRentDateGreaterThan) {
		this.ftwRentDateGreaterThan = ftwRentDateGreaterThan;
	}

	public java.util.Date getFtwRentDateEqualTo() {
		return ftwRentDateEqualTo;
	}
	public void setFtwRentDateEqualTo(java.util.Date ftwRentDateEqualTo) {
		this.ftwRentDateEqualTo = ftwRentDateEqualTo;
	}

	public java.util.List getFtwNotMatchAmountNotIn() {
		return ftwNotMatchAmountNotIn;
	}
	public void setFtwNotMatchAmountNotIn(java.util.List ftwNotMatchAmountNotIn) {
		this.ftwNotMatchAmountNotIn = ftwNotMatchAmountNotIn;
	}

	public Double getFtwNotMatchAmountNotEqualTo() {
		return ftwNotMatchAmountNotEqualTo;
	}
	public void setFtwNotMatchAmountNotEqualTo(Double ftwNotMatchAmountNotEqualTo) {
		this.ftwNotMatchAmountNotEqualTo = ftwNotMatchAmountNotEqualTo;
	}

	public Double getFtwNotMatchAmountLessThanOrEqualTo() {
		return ftwNotMatchAmountLessThanOrEqualTo;
	}
	public void setFtwNotMatchAmountLessThanOrEqualTo(Double ftwNotMatchAmountLessThanOrEqualTo) {
		this.ftwNotMatchAmountLessThanOrEqualTo = ftwNotMatchAmountLessThanOrEqualTo;
	}

	public Double getFtwNotMatchAmountLessThan() {
		return ftwNotMatchAmountLessThan;
	}
	public void setFtwNotMatchAmountLessThan(Double ftwNotMatchAmountLessThan) {
		this.ftwNotMatchAmountLessThan = ftwNotMatchAmountLessThan;
	}

	public Boolean getFtwNotMatchAmountIsNull() {
		return ftwNotMatchAmountIsNull;
	}
	public void setFtwNotMatchAmountIsNull(Boolean ftwNotMatchAmountIsNull) {
		this.ftwNotMatchAmountIsNull = ftwNotMatchAmountIsNull;
	}

	public Boolean getFtwNotMatchAmountIsNotNull() {
		return ftwNotMatchAmountIsNotNull;
	}
	public void setFtwNotMatchAmountIsNotNull(Boolean ftwNotMatchAmountIsNotNull) {
		this.ftwNotMatchAmountIsNotNull = ftwNotMatchAmountIsNotNull;
	}

	public java.util.List getFtwNotMatchAmountIn() {
		return ftwNotMatchAmountIn;
	}
	public void setFtwNotMatchAmountIn(java.util.List ftwNotMatchAmountIn) {
		this.ftwNotMatchAmountIn = ftwNotMatchAmountIn;
	}

	public Double getFtwNotMatchAmountGreaterThanOrEqualTo() {
		return ftwNotMatchAmountGreaterThanOrEqualTo;
	}
	public void setFtwNotMatchAmountGreaterThanOrEqualTo(Double ftwNotMatchAmountGreaterThanOrEqualTo) {
		this.ftwNotMatchAmountGreaterThanOrEqualTo = ftwNotMatchAmountGreaterThanOrEqualTo;
	}

	public Double getFtwNotMatchAmountGreaterThan() {
		return ftwNotMatchAmountGreaterThan;
	}
	public void setFtwNotMatchAmountGreaterThan(Double ftwNotMatchAmountGreaterThan) {
		this.ftwNotMatchAmountGreaterThan = ftwNotMatchAmountGreaterThan;
	}

	public Double getFtwNotMatchAmountEqualTo() {
		return ftwNotMatchAmountEqualTo;
	}
	public void setFtwNotMatchAmountEqualTo(Double ftwNotMatchAmountEqualTo) {
		this.ftwNotMatchAmountEqualTo = ftwNotMatchAmountEqualTo;
	}

	public String getFtwNameNotLike() {
		return ftwNameNotLike;
	}
	public void setFtwNameNotLike(String ftwNameNotLike) {
		this.ftwNameNotLike = ftwNameNotLike;
	}

	public java.util.List getFtwNameNotIn() {
		return ftwNameNotIn;
	}
	public void setFtwNameNotIn(java.util.List ftwNameNotIn) {
		this.ftwNameNotIn = ftwNameNotIn;
	}

	public String getFtwNameNotEqualTo() {
		return ftwNameNotEqualTo;
	}
	public void setFtwNameNotEqualTo(String ftwNameNotEqualTo) {
		this.ftwNameNotEqualTo = ftwNameNotEqualTo;
	}

	public String getFtwNameLike() {
		return ftwNameLike;
	}
	public void setFtwNameLike(String ftwNameLike) {
		this.ftwNameLike = ftwNameLike;
	}

	public String getFtwNameLessThanOrEqualTo() {
		return ftwNameLessThanOrEqualTo;
	}
	public void setFtwNameLessThanOrEqualTo(String ftwNameLessThanOrEqualTo) {
		this.ftwNameLessThanOrEqualTo = ftwNameLessThanOrEqualTo;
	}

	public String getFtwNameLessThan() {
		return ftwNameLessThan;
	}
	public void setFtwNameLessThan(String ftwNameLessThan) {
		this.ftwNameLessThan = ftwNameLessThan;
	}

	public Boolean getFtwNameIsNull() {
		return ftwNameIsNull;
	}
	public void setFtwNameIsNull(Boolean ftwNameIsNull) {
		this.ftwNameIsNull = ftwNameIsNull;
	}

	public Boolean getFtwNameIsNotNull() {
		return ftwNameIsNotNull;
	}
	public void setFtwNameIsNotNull(Boolean ftwNameIsNotNull) {
		this.ftwNameIsNotNull = ftwNameIsNotNull;
	}

	public java.util.List getFtwNameIn() {
		return ftwNameIn;
	}
	public void setFtwNameIn(java.util.List ftwNameIn) {
		this.ftwNameIn = ftwNameIn;
	}

	public String getFtwNameGreaterThanOrEqualTo() {
		return ftwNameGreaterThanOrEqualTo;
	}
	public void setFtwNameGreaterThanOrEqualTo(String ftwNameGreaterThanOrEqualTo) {
		this.ftwNameGreaterThanOrEqualTo = ftwNameGreaterThanOrEqualTo;
	}

	public String getFtwNameGreaterThan() {
		return ftwNameGreaterThan;
	}
	public void setFtwNameGreaterThan(String ftwNameGreaterThan) {
		this.ftwNameGreaterThan = ftwNameGreaterThan;
	}

	public String getFtwNameEqualTo() {
		return ftwNameEqualTo;
	}
	public void setFtwNameEqualTo(String ftwNameEqualTo) {
		this.ftwNameEqualTo = ftwNameEqualTo;
	}

	public java.util.List getFtwMonthWithholdNotIn() {
		return ftwMonthWithholdNotIn;
	}
	public void setFtwMonthWithholdNotIn(java.util.List ftwMonthWithholdNotIn) {
		this.ftwMonthWithholdNotIn = ftwMonthWithholdNotIn;
	}

	public Double getFtwMonthWithholdNotEqualTo() {
		return ftwMonthWithholdNotEqualTo;
	}
	public void setFtwMonthWithholdNotEqualTo(Double ftwMonthWithholdNotEqualTo) {
		this.ftwMonthWithholdNotEqualTo = ftwMonthWithholdNotEqualTo;
	}

	public Double getFtwMonthWithholdLessThanOrEqualTo() {
		return ftwMonthWithholdLessThanOrEqualTo;
	}
	public void setFtwMonthWithholdLessThanOrEqualTo(Double ftwMonthWithholdLessThanOrEqualTo) {
		this.ftwMonthWithholdLessThanOrEqualTo = ftwMonthWithholdLessThanOrEqualTo;
	}

	public Double getFtwMonthWithholdLessThan() {
		return ftwMonthWithholdLessThan;
	}
	public void setFtwMonthWithholdLessThan(Double ftwMonthWithholdLessThan) {
		this.ftwMonthWithholdLessThan = ftwMonthWithholdLessThan;
	}

	public Boolean getFtwMonthWithholdIsNull() {
		return ftwMonthWithholdIsNull;
	}
	public void setFtwMonthWithholdIsNull(Boolean ftwMonthWithholdIsNull) {
		this.ftwMonthWithholdIsNull = ftwMonthWithholdIsNull;
	}

	public Boolean getFtwMonthWithholdIsNotNull() {
		return ftwMonthWithholdIsNotNull;
	}
	public void setFtwMonthWithholdIsNotNull(Boolean ftwMonthWithholdIsNotNull) {
		this.ftwMonthWithholdIsNotNull = ftwMonthWithholdIsNotNull;
	}

	public java.util.List getFtwMonthWithholdIn() {
		return ftwMonthWithholdIn;
	}
	public void setFtwMonthWithholdIn(java.util.List ftwMonthWithholdIn) {
		this.ftwMonthWithholdIn = ftwMonthWithholdIn;
	}

	public Double getFtwMonthWithholdGreaterThanOrEqualTo() {
		return ftwMonthWithholdGreaterThanOrEqualTo;
	}
	public void setFtwMonthWithholdGreaterThanOrEqualTo(Double ftwMonthWithholdGreaterThanOrEqualTo) {
		this.ftwMonthWithholdGreaterThanOrEqualTo = ftwMonthWithholdGreaterThanOrEqualTo;
	}

	public Double getFtwMonthWithholdGreaterThan() {
		return ftwMonthWithholdGreaterThan;
	}
	public void setFtwMonthWithholdGreaterThan(Double ftwMonthWithholdGreaterThan) {
		this.ftwMonthWithholdGreaterThan = ftwMonthWithholdGreaterThan;
	}

	public Double getFtwMonthWithholdEqualTo() {
		return ftwMonthWithholdEqualTo;
	}
	public void setFtwMonthWithholdEqualTo(Double ftwMonthWithholdEqualTo) {
		this.ftwMonthWithholdEqualTo = ftwMonthWithholdEqualTo;
	}

	public java.util.List getFtwMonthRentNotIn() {
		return ftwMonthRentNotIn;
	}
	public void setFtwMonthRentNotIn(java.util.List ftwMonthRentNotIn) {
		this.ftwMonthRentNotIn = ftwMonthRentNotIn;
	}

	public Double getFtwMonthRentNotEqualTo() {
		return ftwMonthRentNotEqualTo;
	}
	public void setFtwMonthRentNotEqualTo(Double ftwMonthRentNotEqualTo) {
		this.ftwMonthRentNotEqualTo = ftwMonthRentNotEqualTo;
	}

	public Double getFtwMonthRentLessThanOrEqualTo() {
		return ftwMonthRentLessThanOrEqualTo;
	}
	public void setFtwMonthRentLessThanOrEqualTo(Double ftwMonthRentLessThanOrEqualTo) {
		this.ftwMonthRentLessThanOrEqualTo = ftwMonthRentLessThanOrEqualTo;
	}

	public Double getFtwMonthRentLessThan() {
		return ftwMonthRentLessThan;
	}
	public void setFtwMonthRentLessThan(Double ftwMonthRentLessThan) {
		this.ftwMonthRentLessThan = ftwMonthRentLessThan;
	}

	public Boolean getFtwMonthRentIsNull() {
		return ftwMonthRentIsNull;
	}
	public void setFtwMonthRentIsNull(Boolean ftwMonthRentIsNull) {
		this.ftwMonthRentIsNull = ftwMonthRentIsNull;
	}

	public Boolean getFtwMonthRentIsNotNull() {
		return ftwMonthRentIsNotNull;
	}
	public void setFtwMonthRentIsNotNull(Boolean ftwMonthRentIsNotNull) {
		this.ftwMonthRentIsNotNull = ftwMonthRentIsNotNull;
	}

	public java.util.List getFtwMonthRentIn() {
		return ftwMonthRentIn;
	}
	public void setFtwMonthRentIn(java.util.List ftwMonthRentIn) {
		this.ftwMonthRentIn = ftwMonthRentIn;
	}

	public Double getFtwMonthRentGreaterThanOrEqualTo() {
		return ftwMonthRentGreaterThanOrEqualTo;
	}
	public void setFtwMonthRentGreaterThanOrEqualTo(Double ftwMonthRentGreaterThanOrEqualTo) {
		this.ftwMonthRentGreaterThanOrEqualTo = ftwMonthRentGreaterThanOrEqualTo;
	}

	public Double getFtwMonthRentGreaterThan() {
		return ftwMonthRentGreaterThan;
	}
	public void setFtwMonthRentGreaterThan(Double ftwMonthRentGreaterThan) {
		this.ftwMonthRentGreaterThan = ftwMonthRentGreaterThan;
	}

	public Double getFtwMonthRentEqualTo() {
		return ftwMonthRentEqualTo;
	}
	public void setFtwMonthRentEqualTo(Double ftwMonthRentEqualTo) {
		this.ftwMonthRentEqualTo = ftwMonthRentEqualTo;
	}

	public java.util.List getFtwMonthRentBalanceNotIn() {
		return ftwMonthRentBalanceNotIn;
	}
	public void setFtwMonthRentBalanceNotIn(java.util.List ftwMonthRentBalanceNotIn) {
		this.ftwMonthRentBalanceNotIn = ftwMonthRentBalanceNotIn;
	}

	public Double getFtwMonthRentBalanceNotEqualTo() {
		return ftwMonthRentBalanceNotEqualTo;
	}
	public void setFtwMonthRentBalanceNotEqualTo(Double ftwMonthRentBalanceNotEqualTo) {
		this.ftwMonthRentBalanceNotEqualTo = ftwMonthRentBalanceNotEqualTo;
	}

	public Double getFtwMonthRentBalanceLessThanOrEqualTo() {
		return ftwMonthRentBalanceLessThanOrEqualTo;
	}
	public void setFtwMonthRentBalanceLessThanOrEqualTo(Double ftwMonthRentBalanceLessThanOrEqualTo) {
		this.ftwMonthRentBalanceLessThanOrEqualTo = ftwMonthRentBalanceLessThanOrEqualTo;
	}

	public Double getFtwMonthRentBalanceLessThan() {
		return ftwMonthRentBalanceLessThan;
	}
	public void setFtwMonthRentBalanceLessThan(Double ftwMonthRentBalanceLessThan) {
		this.ftwMonthRentBalanceLessThan = ftwMonthRentBalanceLessThan;
	}

	public Boolean getFtwMonthRentBalanceIsNull() {
		return ftwMonthRentBalanceIsNull;
	}
	public void setFtwMonthRentBalanceIsNull(Boolean ftwMonthRentBalanceIsNull) {
		this.ftwMonthRentBalanceIsNull = ftwMonthRentBalanceIsNull;
	}

	public Boolean getFtwMonthRentBalanceIsNotNull() {
		return ftwMonthRentBalanceIsNotNull;
	}
	public void setFtwMonthRentBalanceIsNotNull(Boolean ftwMonthRentBalanceIsNotNull) {
		this.ftwMonthRentBalanceIsNotNull = ftwMonthRentBalanceIsNotNull;
	}

	public java.util.List getFtwMonthRentBalanceIn() {
		return ftwMonthRentBalanceIn;
	}
	public void setFtwMonthRentBalanceIn(java.util.List ftwMonthRentBalanceIn) {
		this.ftwMonthRentBalanceIn = ftwMonthRentBalanceIn;
	}

	public Double getFtwMonthRentBalanceGreaterThanOrEqualTo() {
		return ftwMonthRentBalanceGreaterThanOrEqualTo;
	}
	public void setFtwMonthRentBalanceGreaterThanOrEqualTo(Double ftwMonthRentBalanceGreaterThanOrEqualTo) {
		this.ftwMonthRentBalanceGreaterThanOrEqualTo = ftwMonthRentBalanceGreaterThanOrEqualTo;
	}

	public Double getFtwMonthRentBalanceGreaterThan() {
		return ftwMonthRentBalanceGreaterThan;
	}
	public void setFtwMonthRentBalanceGreaterThan(Double ftwMonthRentBalanceGreaterThan) {
		this.ftwMonthRentBalanceGreaterThan = ftwMonthRentBalanceGreaterThan;
	}

	public Double getFtwMonthRentBalanceEqualTo() {
		return ftwMonthRentBalanceEqualTo;
	}
	public void setFtwMonthRentBalanceEqualTo(Double ftwMonthRentBalanceEqualTo) {
		this.ftwMonthRentBalanceEqualTo = ftwMonthRentBalanceEqualTo;
	}

	public java.util.List getFtwMemberIdNotIn() {
		return ftwMemberIdNotIn;
	}
	public void setFtwMemberIdNotIn(java.util.List ftwMemberIdNotIn) {
		this.ftwMemberIdNotIn = ftwMemberIdNotIn;
	}

	public Long getFtwMemberIdNotEqualTo() {
		return ftwMemberIdNotEqualTo;
	}
	public void setFtwMemberIdNotEqualTo(Long ftwMemberIdNotEqualTo) {
		this.ftwMemberIdNotEqualTo = ftwMemberIdNotEqualTo;
	}

	public Long getFtwMemberIdLessThanOrEqualTo() {
		return ftwMemberIdLessThanOrEqualTo;
	}
	public void setFtwMemberIdLessThanOrEqualTo(Long ftwMemberIdLessThanOrEqualTo) {
		this.ftwMemberIdLessThanOrEqualTo = ftwMemberIdLessThanOrEqualTo;
	}

	public Long getFtwMemberIdLessThan() {
		return ftwMemberIdLessThan;
	}
	public void setFtwMemberIdLessThan(Long ftwMemberIdLessThan) {
		this.ftwMemberIdLessThan = ftwMemberIdLessThan;
	}

	public Boolean getFtwMemberIdIsNull() {
		return ftwMemberIdIsNull;
	}
	public void setFtwMemberIdIsNull(Boolean ftwMemberIdIsNull) {
		this.ftwMemberIdIsNull = ftwMemberIdIsNull;
	}

	public Boolean getFtwMemberIdIsNotNull() {
		return ftwMemberIdIsNotNull;
	}
	public void setFtwMemberIdIsNotNull(Boolean ftwMemberIdIsNotNull) {
		this.ftwMemberIdIsNotNull = ftwMemberIdIsNotNull;
	}

	public java.util.List getFtwMemberIdIn() {
		return ftwMemberIdIn;
	}
	public void setFtwMemberIdIn(java.util.List ftwMemberIdIn) {
		this.ftwMemberIdIn = ftwMemberIdIn;
	}

	public Long getFtwMemberIdGreaterThanOrEqualTo() {
		return ftwMemberIdGreaterThanOrEqualTo;
	}
	public void setFtwMemberIdGreaterThanOrEqualTo(Long ftwMemberIdGreaterThanOrEqualTo) {
		this.ftwMemberIdGreaterThanOrEqualTo = ftwMemberIdGreaterThanOrEqualTo;
	}

	public Long getFtwMemberIdGreaterThan() {
		return ftwMemberIdGreaterThan;
	}
	public void setFtwMemberIdGreaterThan(Long ftwMemberIdGreaterThan) {
		this.ftwMemberIdGreaterThan = ftwMemberIdGreaterThan;
	}

	public Long getFtwMemberIdEqualTo() {
		return ftwMemberIdEqualTo;
	}
	public void setFtwMemberIdEqualTo(Long ftwMemberIdEqualTo) {
		this.ftwMemberIdEqualTo = ftwMemberIdEqualTo;
	}

	public java.util.List getFtwMatchedAmountNotIn() {
		return ftwMatchedAmountNotIn;
	}
	public void setFtwMatchedAmountNotIn(java.util.List ftwMatchedAmountNotIn) {
		this.ftwMatchedAmountNotIn = ftwMatchedAmountNotIn;
	}

	public Double getFtwMatchedAmountNotEqualTo() {
		return ftwMatchedAmountNotEqualTo;
	}
	public void setFtwMatchedAmountNotEqualTo(Double ftwMatchedAmountNotEqualTo) {
		this.ftwMatchedAmountNotEqualTo = ftwMatchedAmountNotEqualTo;
	}

	public Double getFtwMatchedAmountLessThanOrEqualTo() {
		return ftwMatchedAmountLessThanOrEqualTo;
	}
	public void setFtwMatchedAmountLessThanOrEqualTo(Double ftwMatchedAmountLessThanOrEqualTo) {
		this.ftwMatchedAmountLessThanOrEqualTo = ftwMatchedAmountLessThanOrEqualTo;
	}

	public Double getFtwMatchedAmountLessThan() {
		return ftwMatchedAmountLessThan;
	}
	public void setFtwMatchedAmountLessThan(Double ftwMatchedAmountLessThan) {
		this.ftwMatchedAmountLessThan = ftwMatchedAmountLessThan;
	}

	public Boolean getFtwMatchedAmountIsNull() {
		return ftwMatchedAmountIsNull;
	}
	public void setFtwMatchedAmountIsNull(Boolean ftwMatchedAmountIsNull) {
		this.ftwMatchedAmountIsNull = ftwMatchedAmountIsNull;
	}

	public Boolean getFtwMatchedAmountIsNotNull() {
		return ftwMatchedAmountIsNotNull;
	}
	public void setFtwMatchedAmountIsNotNull(Boolean ftwMatchedAmountIsNotNull) {
		this.ftwMatchedAmountIsNotNull = ftwMatchedAmountIsNotNull;
	}

	public java.util.List getFtwMatchedAmountIn() {
		return ftwMatchedAmountIn;
	}
	public void setFtwMatchedAmountIn(java.util.List ftwMatchedAmountIn) {
		this.ftwMatchedAmountIn = ftwMatchedAmountIn;
	}

	public Double getFtwMatchedAmountGreaterThanOrEqualTo() {
		return ftwMatchedAmountGreaterThanOrEqualTo;
	}
	public void setFtwMatchedAmountGreaterThanOrEqualTo(Double ftwMatchedAmountGreaterThanOrEqualTo) {
		this.ftwMatchedAmountGreaterThanOrEqualTo = ftwMatchedAmountGreaterThanOrEqualTo;
	}

	public Double getFtwMatchedAmountGreaterThan() {
		return ftwMatchedAmountGreaterThan;
	}
	public void setFtwMatchedAmountGreaterThan(Double ftwMatchedAmountGreaterThan) {
		this.ftwMatchedAmountGreaterThan = ftwMatchedAmountGreaterThan;
	}

	public Double getFtwMatchedAmountEqualTo() {
		return ftwMatchedAmountEqualTo;
	}
	public void setFtwMatchedAmountEqualTo(Double ftwMatchedAmountEqualTo) {
		this.ftwMatchedAmountEqualTo = ftwMatchedAmountEqualTo;
	}

	public java.util.List getFtwMatchWayNotIn() {
		return ftwMatchWayNotIn;
	}
	public void setFtwMatchWayNotIn(java.util.List ftwMatchWayNotIn) {
		this.ftwMatchWayNotIn = ftwMatchWayNotIn;
	}

	public Integer getFtwMatchWayNotEqualTo() {
		return ftwMatchWayNotEqualTo;
	}
	public void setFtwMatchWayNotEqualTo(Integer ftwMatchWayNotEqualTo) {
		this.ftwMatchWayNotEqualTo = ftwMatchWayNotEqualTo;
	}

	public Integer getFtwMatchWayLessThanOrEqualTo() {
		return ftwMatchWayLessThanOrEqualTo;
	}
	public void setFtwMatchWayLessThanOrEqualTo(Integer ftwMatchWayLessThanOrEqualTo) {
		this.ftwMatchWayLessThanOrEqualTo = ftwMatchWayLessThanOrEqualTo;
	}

	public Integer getFtwMatchWayLessThan() {
		return ftwMatchWayLessThan;
	}
	public void setFtwMatchWayLessThan(Integer ftwMatchWayLessThan) {
		this.ftwMatchWayLessThan = ftwMatchWayLessThan;
	}

	public Boolean getFtwMatchWayIsNull() {
		return ftwMatchWayIsNull;
	}
	public void setFtwMatchWayIsNull(Boolean ftwMatchWayIsNull) {
		this.ftwMatchWayIsNull = ftwMatchWayIsNull;
	}

	public Boolean getFtwMatchWayIsNotNull() {
		return ftwMatchWayIsNotNull;
	}
	public void setFtwMatchWayIsNotNull(Boolean ftwMatchWayIsNotNull) {
		this.ftwMatchWayIsNotNull = ftwMatchWayIsNotNull;
	}

	public java.util.List getFtwMatchWayIn() {
		return ftwMatchWayIn;
	}
	public void setFtwMatchWayIn(java.util.List ftwMatchWayIn) {
		this.ftwMatchWayIn = ftwMatchWayIn;
	}

	public Integer getFtwMatchWayGreaterThanOrEqualTo() {
		return ftwMatchWayGreaterThanOrEqualTo;
	}
	public void setFtwMatchWayGreaterThanOrEqualTo(Integer ftwMatchWayGreaterThanOrEqualTo) {
		this.ftwMatchWayGreaterThanOrEqualTo = ftwMatchWayGreaterThanOrEqualTo;
	}

	public Integer getFtwMatchWayGreaterThan() {
		return ftwMatchWayGreaterThan;
	}
	public void setFtwMatchWayGreaterThan(Integer ftwMatchWayGreaterThan) {
		this.ftwMatchWayGreaterThan = ftwMatchWayGreaterThan;
	}

	public Integer getFtwMatchWayEqualTo() {
		return ftwMatchWayEqualTo;
	}
	public void setFtwMatchWayEqualTo(Integer ftwMatchWayEqualTo) {
		this.ftwMatchWayEqualTo = ftwMatchWayEqualTo;
	}

	public java.util.List getFtwMatchStateNotIn() {
		return ftwMatchStateNotIn;
	}
	public void setFtwMatchStateNotIn(java.util.List ftwMatchStateNotIn) {
		this.ftwMatchStateNotIn = ftwMatchStateNotIn;
	}

	public Integer getFtwMatchStateNotEqualTo() {
		return ftwMatchStateNotEqualTo;
	}
	public void setFtwMatchStateNotEqualTo(Integer ftwMatchStateNotEqualTo) {
		this.ftwMatchStateNotEqualTo = ftwMatchStateNotEqualTo;
	}

	public Integer getFtwMatchStateLessThanOrEqualTo() {
		return ftwMatchStateLessThanOrEqualTo;
	}
	public void setFtwMatchStateLessThanOrEqualTo(Integer ftwMatchStateLessThanOrEqualTo) {
		this.ftwMatchStateLessThanOrEqualTo = ftwMatchStateLessThanOrEqualTo;
	}

	public Integer getFtwMatchStateLessThan() {
		return ftwMatchStateLessThan;
	}
	public void setFtwMatchStateLessThan(Integer ftwMatchStateLessThan) {
		this.ftwMatchStateLessThan = ftwMatchStateLessThan;
	}

	public Boolean getFtwMatchStateIsNull() {
		return ftwMatchStateIsNull;
	}
	public void setFtwMatchStateIsNull(Boolean ftwMatchStateIsNull) {
		this.ftwMatchStateIsNull = ftwMatchStateIsNull;
	}

	public Boolean getFtwMatchStateIsNotNull() {
		return ftwMatchStateIsNotNull;
	}
	public void setFtwMatchStateIsNotNull(Boolean ftwMatchStateIsNotNull) {
		this.ftwMatchStateIsNotNull = ftwMatchStateIsNotNull;
	}

	public java.util.List getFtwMatchStateIn() {
		return ftwMatchStateIn;
	}
	public void setFtwMatchStateIn(java.util.List ftwMatchStateIn) {
		this.ftwMatchStateIn = ftwMatchStateIn;
	}

	public Integer getFtwMatchStateGreaterThanOrEqualTo() {
		return ftwMatchStateGreaterThanOrEqualTo;
	}
	public void setFtwMatchStateGreaterThanOrEqualTo(Integer ftwMatchStateGreaterThanOrEqualTo) {
		this.ftwMatchStateGreaterThanOrEqualTo = ftwMatchStateGreaterThanOrEqualTo;
	}

	public Integer getFtwMatchStateGreaterThan() {
		return ftwMatchStateGreaterThan;
	}
	public void setFtwMatchStateGreaterThan(Integer ftwMatchStateGreaterThan) {
		this.ftwMatchStateGreaterThan = ftwMatchStateGreaterThan;
	}

	public Integer getFtwMatchStateEqualTo() {
		return ftwMatchStateEqualTo;
	}
	public void setFtwMatchStateEqualTo(Integer ftwMatchStateEqualTo) {
		this.ftwMatchStateEqualTo = ftwMatchStateEqualTo;
	}

	public String getFtwMatchBillNotLike() {
		return ftwMatchBillNotLike;
	}
	public void setFtwMatchBillNotLike(String ftwMatchBillNotLike) {
		this.ftwMatchBillNotLike = ftwMatchBillNotLike;
	}

	public java.util.List getFtwMatchBillNotIn() {
		return ftwMatchBillNotIn;
	}
	public void setFtwMatchBillNotIn(java.util.List ftwMatchBillNotIn) {
		this.ftwMatchBillNotIn = ftwMatchBillNotIn;
	}

	public String getFtwMatchBillNotEqualTo() {
		return ftwMatchBillNotEqualTo;
	}
	public void setFtwMatchBillNotEqualTo(String ftwMatchBillNotEqualTo) {
		this.ftwMatchBillNotEqualTo = ftwMatchBillNotEqualTo;
	}

	public String getFtwMatchBillLike() {
		return ftwMatchBillLike;
	}
	public void setFtwMatchBillLike(String ftwMatchBillLike) {
		this.ftwMatchBillLike = ftwMatchBillLike;
	}

	public String getFtwMatchBillLessThanOrEqualTo() {
		return ftwMatchBillLessThanOrEqualTo;
	}
	public void setFtwMatchBillLessThanOrEqualTo(String ftwMatchBillLessThanOrEqualTo) {
		this.ftwMatchBillLessThanOrEqualTo = ftwMatchBillLessThanOrEqualTo;
	}

	public String getFtwMatchBillLessThan() {
		return ftwMatchBillLessThan;
	}
	public void setFtwMatchBillLessThan(String ftwMatchBillLessThan) {
		this.ftwMatchBillLessThan = ftwMatchBillLessThan;
	}

	public Boolean getFtwMatchBillIsNull() {
		return ftwMatchBillIsNull;
	}
	public void setFtwMatchBillIsNull(Boolean ftwMatchBillIsNull) {
		this.ftwMatchBillIsNull = ftwMatchBillIsNull;
	}

	public Boolean getFtwMatchBillIsNotNull() {
		return ftwMatchBillIsNotNull;
	}
	public void setFtwMatchBillIsNotNull(Boolean ftwMatchBillIsNotNull) {
		this.ftwMatchBillIsNotNull = ftwMatchBillIsNotNull;
	}

	public java.util.List getFtwMatchBillIn() {
		return ftwMatchBillIn;
	}
	public void setFtwMatchBillIn(java.util.List ftwMatchBillIn) {
		this.ftwMatchBillIn = ftwMatchBillIn;
	}

	public String getFtwMatchBillGreaterThanOrEqualTo() {
		return ftwMatchBillGreaterThanOrEqualTo;
	}
	public void setFtwMatchBillGreaterThanOrEqualTo(String ftwMatchBillGreaterThanOrEqualTo) {
		this.ftwMatchBillGreaterThanOrEqualTo = ftwMatchBillGreaterThanOrEqualTo;
	}

	public String getFtwMatchBillGreaterThan() {
		return ftwMatchBillGreaterThan;
	}
	public void setFtwMatchBillGreaterThan(String ftwMatchBillGreaterThan) {
		this.ftwMatchBillGreaterThan = ftwMatchBillGreaterThan;
	}

	public String getFtwMatchBillEqualTo() {
		return ftwMatchBillEqualTo;
	}
	public void setFtwMatchBillEqualTo(String ftwMatchBillEqualTo) {
		this.ftwMatchBillEqualTo = ftwMatchBillEqualTo;
	}

	public java.util.List getFtwLeaseCountNotIn() {
		return ftwLeaseCountNotIn;
	}
	public void setFtwLeaseCountNotIn(java.util.List ftwLeaseCountNotIn) {
		this.ftwLeaseCountNotIn = ftwLeaseCountNotIn;
	}

	public Integer getFtwLeaseCountNotEqualTo() {
		return ftwLeaseCountNotEqualTo;
	}
	public void setFtwLeaseCountNotEqualTo(Integer ftwLeaseCountNotEqualTo) {
		this.ftwLeaseCountNotEqualTo = ftwLeaseCountNotEqualTo;
	}

	public Integer getFtwLeaseCountLessThanOrEqualTo() {
		return ftwLeaseCountLessThanOrEqualTo;
	}
	public void setFtwLeaseCountLessThanOrEqualTo(Integer ftwLeaseCountLessThanOrEqualTo) {
		this.ftwLeaseCountLessThanOrEqualTo = ftwLeaseCountLessThanOrEqualTo;
	}

	public Integer getFtwLeaseCountLessThan() {
		return ftwLeaseCountLessThan;
	}
	public void setFtwLeaseCountLessThan(Integer ftwLeaseCountLessThan) {
		this.ftwLeaseCountLessThan = ftwLeaseCountLessThan;
	}

	public Boolean getFtwLeaseCountIsNull() {
		return ftwLeaseCountIsNull;
	}
	public void setFtwLeaseCountIsNull(Boolean ftwLeaseCountIsNull) {
		this.ftwLeaseCountIsNull = ftwLeaseCountIsNull;
	}

	public Boolean getFtwLeaseCountIsNotNull() {
		return ftwLeaseCountIsNotNull;
	}
	public void setFtwLeaseCountIsNotNull(Boolean ftwLeaseCountIsNotNull) {
		this.ftwLeaseCountIsNotNull = ftwLeaseCountIsNotNull;
	}

	public java.util.List getFtwLeaseCountIn() {
		return ftwLeaseCountIn;
	}
	public void setFtwLeaseCountIn(java.util.List ftwLeaseCountIn) {
		this.ftwLeaseCountIn = ftwLeaseCountIn;
	}

	public Integer getFtwLeaseCountGreaterThanOrEqualTo() {
		return ftwLeaseCountGreaterThanOrEqualTo;
	}
	public void setFtwLeaseCountGreaterThanOrEqualTo(Integer ftwLeaseCountGreaterThanOrEqualTo) {
		this.ftwLeaseCountGreaterThanOrEqualTo = ftwLeaseCountGreaterThanOrEqualTo;
	}

	public Integer getFtwLeaseCountGreaterThan() {
		return ftwLeaseCountGreaterThan;
	}
	public void setFtwLeaseCountGreaterThan(Integer ftwLeaseCountGreaterThan) {
		this.ftwLeaseCountGreaterThan = ftwLeaseCountGreaterThan;
	}

	public Integer getFtwLeaseCountEqualTo() {
		return ftwLeaseCountEqualTo;
	}
	public void setFtwLeaseCountEqualTo(Integer ftwLeaseCountEqualTo) {
		this.ftwLeaseCountEqualTo = ftwLeaseCountEqualTo;
	}

	public String getFtwIdnumberNotLike() {
		return ftwIdnumberNotLike;
	}
	public void setFtwIdnumberNotLike(String ftwIdnumberNotLike) {
		this.ftwIdnumberNotLike = ftwIdnumberNotLike;
	}

	public java.util.List getFtwIdnumberNotIn() {
		return ftwIdnumberNotIn;
	}
	public void setFtwIdnumberNotIn(java.util.List ftwIdnumberNotIn) {
		this.ftwIdnumberNotIn = ftwIdnumberNotIn;
	}

	public String getFtwIdnumberNotEqualTo() {
		return ftwIdnumberNotEqualTo;
	}
	public void setFtwIdnumberNotEqualTo(String ftwIdnumberNotEqualTo) {
		this.ftwIdnumberNotEqualTo = ftwIdnumberNotEqualTo;
	}

	public String getFtwIdnumberLike() {
		return ftwIdnumberLike;
	}
	public void setFtwIdnumberLike(String ftwIdnumberLike) {
		this.ftwIdnumberLike = ftwIdnumberLike;
	}

	public String getFtwIdnumberLessThanOrEqualTo() {
		return ftwIdnumberLessThanOrEqualTo;
	}
	public void setFtwIdnumberLessThanOrEqualTo(String ftwIdnumberLessThanOrEqualTo) {
		this.ftwIdnumberLessThanOrEqualTo = ftwIdnumberLessThanOrEqualTo;
	}

	public String getFtwIdnumberLessThan() {
		return ftwIdnumberLessThan;
	}
	public void setFtwIdnumberLessThan(String ftwIdnumberLessThan) {
		this.ftwIdnumberLessThan = ftwIdnumberLessThan;
	}

	public Boolean getFtwIdnumberIsNull() {
		return ftwIdnumberIsNull;
	}
	public void setFtwIdnumberIsNull(Boolean ftwIdnumberIsNull) {
		this.ftwIdnumberIsNull = ftwIdnumberIsNull;
	}

	public Boolean getFtwIdnumberIsNotNull() {
		return ftwIdnumberIsNotNull;
	}
	public void setFtwIdnumberIsNotNull(Boolean ftwIdnumberIsNotNull) {
		this.ftwIdnumberIsNotNull = ftwIdnumberIsNotNull;
	}

	public java.util.List getFtwIdnumberIn() {
		return ftwIdnumberIn;
	}
	public void setFtwIdnumberIn(java.util.List ftwIdnumberIn) {
		this.ftwIdnumberIn = ftwIdnumberIn;
	}

	public String getFtwIdnumberGreaterThanOrEqualTo() {
		return ftwIdnumberGreaterThanOrEqualTo;
	}
	public void setFtwIdnumberGreaterThanOrEqualTo(String ftwIdnumberGreaterThanOrEqualTo) {
		this.ftwIdnumberGreaterThanOrEqualTo = ftwIdnumberGreaterThanOrEqualTo;
	}

	public String getFtwIdnumberGreaterThan() {
		return ftwIdnumberGreaterThan;
	}
	public void setFtwIdnumberGreaterThan(String ftwIdnumberGreaterThan) {
		this.ftwIdnumberGreaterThan = ftwIdnumberGreaterThan;
	}

	public String getFtwIdnumberEqualTo() {
		return ftwIdnumberEqualTo;
	}
	public void setFtwIdnumberEqualTo(String ftwIdnumberEqualTo) {
		this.ftwIdnumberEqualTo = ftwIdnumberEqualTo;
	}

	public java.util.List getFtwIdNotIn() {
		return ftwIdNotIn;
	}
	public void setFtwIdNotIn(java.util.List ftwIdNotIn) {
		this.ftwIdNotIn = ftwIdNotIn;
	}

	public Long getFtwIdNotEqualTo() {
		return ftwIdNotEqualTo;
	}
	public void setFtwIdNotEqualTo(Long ftwIdNotEqualTo) {
		this.ftwIdNotEqualTo = ftwIdNotEqualTo;
	}

	public Long getFtwIdLessThanOrEqualTo() {
		return ftwIdLessThanOrEqualTo;
	}
	public void setFtwIdLessThanOrEqualTo(Long ftwIdLessThanOrEqualTo) {
		this.ftwIdLessThanOrEqualTo = ftwIdLessThanOrEqualTo;
	}

	public Long getFtwIdLessThan() {
		return ftwIdLessThan;
	}
	public void setFtwIdLessThan(Long ftwIdLessThan) {
		this.ftwIdLessThan = ftwIdLessThan;
	}

	public Boolean getFtwIdIsNull() {
		return ftwIdIsNull;
	}
	public void setFtwIdIsNull(Boolean ftwIdIsNull) {
		this.ftwIdIsNull = ftwIdIsNull;
	}

	public Boolean getFtwIdIsNotNull() {
		return ftwIdIsNotNull;
	}
	public void setFtwIdIsNotNull(Boolean ftwIdIsNotNull) {
		this.ftwIdIsNotNull = ftwIdIsNotNull;
	}

	public java.util.List getFtwIdIn() {
		return ftwIdIn;
	}
	public void setFtwIdIn(java.util.List ftwIdIn) {
		this.ftwIdIn = ftwIdIn;
	}

	public Long getFtwIdGreaterThanOrEqualTo() {
		return ftwIdGreaterThanOrEqualTo;
	}
	public void setFtwIdGreaterThanOrEqualTo(Long ftwIdGreaterThanOrEqualTo) {
		this.ftwIdGreaterThanOrEqualTo = ftwIdGreaterThanOrEqualTo;
	}

	public Long getFtwIdGreaterThan() {
		return ftwIdGreaterThan;
	}
	public void setFtwIdGreaterThan(Long ftwIdGreaterThan) {
		this.ftwIdGreaterThan = ftwIdGreaterThan;
	}

	public Long getFtwIdEqualTo() {
		return ftwIdEqualTo;
	}
	public void setFtwIdEqualTo(Long ftwIdEqualTo) {
		this.ftwIdEqualTo = ftwIdEqualTo;
	}

	public java.util.List getFtwCityIdNotIn() {
		return ftwCityIdNotIn;
	}
	public void setFtwCityIdNotIn(java.util.List ftwCityIdNotIn) {
		this.ftwCityIdNotIn = ftwCityIdNotIn;
	}

	public Long getFtwCityIdNotEqualTo() {
		return ftwCityIdNotEqualTo;
	}
	public void setFtwCityIdNotEqualTo(Long ftwCityIdNotEqualTo) {
		this.ftwCityIdNotEqualTo = ftwCityIdNotEqualTo;
	}

	public Long getFtwCityIdLessThanOrEqualTo() {
		return ftwCityIdLessThanOrEqualTo;
	}
	public void setFtwCityIdLessThanOrEqualTo(Long ftwCityIdLessThanOrEqualTo) {
		this.ftwCityIdLessThanOrEqualTo = ftwCityIdLessThanOrEqualTo;
	}

	public Long getFtwCityIdLessThan() {
		return ftwCityIdLessThan;
	}
	public void setFtwCityIdLessThan(Long ftwCityIdLessThan) {
		this.ftwCityIdLessThan = ftwCityIdLessThan;
	}

	public Boolean getFtwCityIdIsNull() {
		return ftwCityIdIsNull;
	}
	public void setFtwCityIdIsNull(Boolean ftwCityIdIsNull) {
		this.ftwCityIdIsNull = ftwCityIdIsNull;
	}

	public Boolean getFtwCityIdIsNotNull() {
		return ftwCityIdIsNotNull;
	}
	public void setFtwCityIdIsNotNull(Boolean ftwCityIdIsNotNull) {
		this.ftwCityIdIsNotNull = ftwCityIdIsNotNull;
	}

	public java.util.List getFtwCityIdIn() {
		return ftwCityIdIn;
	}
	public void setFtwCityIdIn(java.util.List ftwCityIdIn) {
		this.ftwCityIdIn = ftwCityIdIn;
	}

	public Long getFtwCityIdGreaterThanOrEqualTo() {
		return ftwCityIdGreaterThanOrEqualTo;
	}
	public void setFtwCityIdGreaterThanOrEqualTo(Long ftwCityIdGreaterThanOrEqualTo) {
		this.ftwCityIdGreaterThanOrEqualTo = ftwCityIdGreaterThanOrEqualTo;
	}

	public Long getFtwCityIdGreaterThan() {
		return ftwCityIdGreaterThan;
	}
	public void setFtwCityIdGreaterThan(Long ftwCityIdGreaterThan) {
		this.ftwCityIdGreaterThan = ftwCityIdGreaterThan;
	}

	public Long getFtwCityIdEqualTo() {
		return ftwCityIdEqualTo;
	}
	public void setFtwCityIdEqualTo(Long ftwCityIdEqualTo) {
		this.ftwCityIdEqualTo = ftwCityIdEqualTo;
	}

	public String getFtwCarVinNotLike() {
		return ftwCarVinNotLike;
	}
	public void setFtwCarVinNotLike(String ftwCarVinNotLike) {
		this.ftwCarVinNotLike = ftwCarVinNotLike;
	}

	public java.util.List getFtwCarVinNotIn() {
		return ftwCarVinNotIn;
	}
	public void setFtwCarVinNotIn(java.util.List ftwCarVinNotIn) {
		this.ftwCarVinNotIn = ftwCarVinNotIn;
	}

	public String getFtwCarVinNotEqualTo() {
		return ftwCarVinNotEqualTo;
	}
	public void setFtwCarVinNotEqualTo(String ftwCarVinNotEqualTo) {
		this.ftwCarVinNotEqualTo = ftwCarVinNotEqualTo;
	}

	public String getFtwCarVinLike() {
		return ftwCarVinLike;
	}
	public void setFtwCarVinLike(String ftwCarVinLike) {
		this.ftwCarVinLike = ftwCarVinLike;
	}

	public String getFtwCarVinLessThanOrEqualTo() {
		return ftwCarVinLessThanOrEqualTo;
	}
	public void setFtwCarVinLessThanOrEqualTo(String ftwCarVinLessThanOrEqualTo) {
		this.ftwCarVinLessThanOrEqualTo = ftwCarVinLessThanOrEqualTo;
	}

	public String getFtwCarVinLessThan() {
		return ftwCarVinLessThan;
	}
	public void setFtwCarVinLessThan(String ftwCarVinLessThan) {
		this.ftwCarVinLessThan = ftwCarVinLessThan;
	}

	public Boolean getFtwCarVinIsNull() {
		return ftwCarVinIsNull;
	}
	public void setFtwCarVinIsNull(Boolean ftwCarVinIsNull) {
		this.ftwCarVinIsNull = ftwCarVinIsNull;
	}

	public Boolean getFtwCarVinIsNotNull() {
		return ftwCarVinIsNotNull;
	}
	public void setFtwCarVinIsNotNull(Boolean ftwCarVinIsNotNull) {
		this.ftwCarVinIsNotNull = ftwCarVinIsNotNull;
	}

	public java.util.List getFtwCarVinIn() {
		return ftwCarVinIn;
	}
	public void setFtwCarVinIn(java.util.List ftwCarVinIn) {
		this.ftwCarVinIn = ftwCarVinIn;
	}

	public String getFtwCarVinGreaterThanOrEqualTo() {
		return ftwCarVinGreaterThanOrEqualTo;
	}
	public void setFtwCarVinGreaterThanOrEqualTo(String ftwCarVinGreaterThanOrEqualTo) {
		this.ftwCarVinGreaterThanOrEqualTo = ftwCarVinGreaterThanOrEqualTo;
	}

	public String getFtwCarVinGreaterThan() {
		return ftwCarVinGreaterThan;
	}
	public void setFtwCarVinGreaterThan(String ftwCarVinGreaterThan) {
		this.ftwCarVinGreaterThan = ftwCarVinGreaterThan;
	}

	public String getFtwCarVinEqualTo() {
		return ftwCarVinEqualTo;
	}
	public void setFtwCarVinEqualTo(String ftwCarVinEqualTo) {
		this.ftwCarVinEqualTo = ftwCarVinEqualTo;
	}

	public java.util.List getFtwCarModelNotIn() {
		return ftwCarModelNotIn;
	}
	public void setFtwCarModelNotIn(java.util.List ftwCarModelNotIn) {
		this.ftwCarModelNotIn = ftwCarModelNotIn;
	}

	public Long getFtwCarModelNotEqualTo() {
		return ftwCarModelNotEqualTo;
	}
	public void setFtwCarModelNotEqualTo(Long ftwCarModelNotEqualTo) {
		this.ftwCarModelNotEqualTo = ftwCarModelNotEqualTo;
	}

	public Long getFtwCarModelLessThanOrEqualTo() {
		return ftwCarModelLessThanOrEqualTo;
	}
	public void setFtwCarModelLessThanOrEqualTo(Long ftwCarModelLessThanOrEqualTo) {
		this.ftwCarModelLessThanOrEqualTo = ftwCarModelLessThanOrEqualTo;
	}

	public Long getFtwCarModelLessThan() {
		return ftwCarModelLessThan;
	}
	public void setFtwCarModelLessThan(Long ftwCarModelLessThan) {
		this.ftwCarModelLessThan = ftwCarModelLessThan;
	}

	public Boolean getFtwCarModelIsNull() {
		return ftwCarModelIsNull;
	}
	public void setFtwCarModelIsNull(Boolean ftwCarModelIsNull) {
		this.ftwCarModelIsNull = ftwCarModelIsNull;
	}

	public Boolean getFtwCarModelIsNotNull() {
		return ftwCarModelIsNotNull;
	}
	public void setFtwCarModelIsNotNull(Boolean ftwCarModelIsNotNull) {
		this.ftwCarModelIsNotNull = ftwCarModelIsNotNull;
	}

	public java.util.List getFtwCarModelIn() {
		return ftwCarModelIn;
	}
	public void setFtwCarModelIn(java.util.List ftwCarModelIn) {
		this.ftwCarModelIn = ftwCarModelIn;
	}

	public Long getFtwCarModelGreaterThanOrEqualTo() {
		return ftwCarModelGreaterThanOrEqualTo;
	}
	public void setFtwCarModelGreaterThanOrEqualTo(Long ftwCarModelGreaterThanOrEqualTo) {
		this.ftwCarModelGreaterThanOrEqualTo = ftwCarModelGreaterThanOrEqualTo;
	}

	public Long getFtwCarModelGreaterThan() {
		return ftwCarModelGreaterThan;
	}
	public void setFtwCarModelGreaterThan(Long ftwCarModelGreaterThan) {
		this.ftwCarModelGreaterThan = ftwCarModelGreaterThan;
	}

	public Long getFtwCarModelEqualTo() {
		return ftwCarModelEqualTo;
	}
	public void setFtwCarModelEqualTo(Long ftwCarModelEqualTo) {
		this.ftwCarModelEqualTo = ftwCarModelEqualTo;
	}

	public String getFtwAgreementNumberNotLike() {
		return ftwAgreementNumberNotLike;
	}
	public void setFtwAgreementNumberNotLike(String ftwAgreementNumberNotLike) {
		this.ftwAgreementNumberNotLike = ftwAgreementNumberNotLike;
	}

	public java.util.List getFtwAgreementNumberNotIn() {
		return ftwAgreementNumberNotIn;
	}
	public void setFtwAgreementNumberNotIn(java.util.List ftwAgreementNumberNotIn) {
		this.ftwAgreementNumberNotIn = ftwAgreementNumberNotIn;
	}

	public String getFtwAgreementNumberNotEqualTo() {
		return ftwAgreementNumberNotEqualTo;
	}
	public void setFtwAgreementNumberNotEqualTo(String ftwAgreementNumberNotEqualTo) {
		this.ftwAgreementNumberNotEqualTo = ftwAgreementNumberNotEqualTo;
	}

	public String getFtwAgreementNumberLike() {
		return ftwAgreementNumberLike;
	}
	public void setFtwAgreementNumberLike(String ftwAgreementNumberLike) {
		this.ftwAgreementNumberLike = ftwAgreementNumberLike;
	}

	public String getFtwAgreementNumberLessThanOrEqualTo() {
		return ftwAgreementNumberLessThanOrEqualTo;
	}
	public void setFtwAgreementNumberLessThanOrEqualTo(String ftwAgreementNumberLessThanOrEqualTo) {
		this.ftwAgreementNumberLessThanOrEqualTo = ftwAgreementNumberLessThanOrEqualTo;
	}

	public String getFtwAgreementNumberLessThan() {
		return ftwAgreementNumberLessThan;
	}
	public void setFtwAgreementNumberLessThan(String ftwAgreementNumberLessThan) {
		this.ftwAgreementNumberLessThan = ftwAgreementNumberLessThan;
	}

	public Boolean getFtwAgreementNumberIsNull() {
		return ftwAgreementNumberIsNull;
	}
	public void setFtwAgreementNumberIsNull(Boolean ftwAgreementNumberIsNull) {
		this.ftwAgreementNumberIsNull = ftwAgreementNumberIsNull;
	}

	public Boolean getFtwAgreementNumberIsNotNull() {
		return ftwAgreementNumberIsNotNull;
	}
	public void setFtwAgreementNumberIsNotNull(Boolean ftwAgreementNumberIsNotNull) {
		this.ftwAgreementNumberIsNotNull = ftwAgreementNumberIsNotNull;
	}

	public java.util.List getFtwAgreementNumberIn() {
		return ftwAgreementNumberIn;
	}
	public void setFtwAgreementNumberIn(java.util.List ftwAgreementNumberIn) {
		this.ftwAgreementNumberIn = ftwAgreementNumberIn;
	}

	public String getFtwAgreementNumberGreaterThanOrEqualTo() {
		return ftwAgreementNumberGreaterThanOrEqualTo;
	}
	public void setFtwAgreementNumberGreaterThanOrEqualTo(String ftwAgreementNumberGreaterThanOrEqualTo) {
		this.ftwAgreementNumberGreaterThanOrEqualTo = ftwAgreementNumberGreaterThanOrEqualTo;
	}

	public String getFtwAgreementNumberGreaterThan() {
		return ftwAgreementNumberGreaterThan;
	}
	public void setFtwAgreementNumberGreaterThan(String ftwAgreementNumberGreaterThan) {
		this.ftwAgreementNumberGreaterThan = ftwAgreementNumberGreaterThan;
	}

	public String getFtwAgreementNumberEqualTo() {
		return ftwAgreementNumberEqualTo;
	}
	public void setFtwAgreementNumberEqualTo(String ftwAgreementNumberEqualTo) {
		this.ftwAgreementNumberEqualTo = ftwAgreementNumberEqualTo;
	}

	public java.util.List getDrNotIn() {
		return drNotIn;
	}
	public void setDrNotIn(java.util.List drNotIn) {
		this.drNotIn = drNotIn;
	}

	public Integer getDrNotEqualTo() {
		return drNotEqualTo;
	}
	public void setDrNotEqualTo(Integer drNotEqualTo) {
		this.drNotEqualTo = drNotEqualTo;
	}

	public Integer getDrLessThanOrEqualTo() {
		return drLessThanOrEqualTo;
	}
	public void setDrLessThanOrEqualTo(Integer drLessThanOrEqualTo) {
		this.drLessThanOrEqualTo = drLessThanOrEqualTo;
	}

	public Integer getDrLessThan() {
		return drLessThan;
	}
	public void setDrLessThan(Integer drLessThan) {
		this.drLessThan = drLessThan;
	}

	public Boolean getDrIsNull() {
		return drIsNull;
	}
	public void setDrIsNull(Boolean drIsNull) {
		this.drIsNull = drIsNull;
	}

	public Boolean getDrIsNotNull() {
		return drIsNotNull;
	}
	public void setDrIsNotNull(Boolean drIsNotNull) {
		this.drIsNotNull = drIsNotNull;
	}

	public java.util.List getDrIn() {
		return drIn;
	}
	public void setDrIn(java.util.List drIn) {
		this.drIn = drIn;
	}

	public Integer getDrGreaterThanOrEqualTo() {
		return drGreaterThanOrEqualTo;
	}
	public void setDrGreaterThanOrEqualTo(Integer drGreaterThanOrEqualTo) {
		this.drGreaterThanOrEqualTo = drGreaterThanOrEqualTo;
	}

	public Integer getDrGreaterThan() {
		return drGreaterThan;
	}
	public void setDrGreaterThan(Integer drGreaterThan) {
		this.drGreaterThan = drGreaterThan;
	}

	public Integer getDrEqualTo() {
		return drEqualTo;
	}
	public void setDrEqualTo(Integer drEqualTo) {
		this.drEqualTo = drEqualTo;
	}

	public String getCreateuserNotLike() {
		return createuserNotLike;
	}
	public void setCreateuserNotLike(String createuserNotLike) {
		this.createuserNotLike = createuserNotLike;
	}

	public java.util.List getCreateuserNotIn() {
		return createuserNotIn;
	}
	public void setCreateuserNotIn(java.util.List createuserNotIn) {
		this.createuserNotIn = createuserNotIn;
	}

	public String getCreateuserNotEqualTo() {
		return createuserNotEqualTo;
	}
	public void setCreateuserNotEqualTo(String createuserNotEqualTo) {
		this.createuserNotEqualTo = createuserNotEqualTo;
	}

	public String getCreateuserLike() {
		return createuserLike;
	}
	public void setCreateuserLike(String createuserLike) {
		this.createuserLike = createuserLike;
	}

	public String getCreateuserLessThanOrEqualTo() {
		return createuserLessThanOrEqualTo;
	}
	public void setCreateuserLessThanOrEqualTo(String createuserLessThanOrEqualTo) {
		this.createuserLessThanOrEqualTo = createuserLessThanOrEqualTo;
	}

	public String getCreateuserLessThan() {
		return createuserLessThan;
	}
	public void setCreateuserLessThan(String createuserLessThan) {
		this.createuserLessThan = createuserLessThan;
	}

	public Boolean getCreateuserIsNull() {
		return createuserIsNull;
	}
	public void setCreateuserIsNull(Boolean createuserIsNull) {
		this.createuserIsNull = createuserIsNull;
	}

	public Boolean getCreateuserIsNotNull() {
		return createuserIsNotNull;
	}
	public void setCreateuserIsNotNull(Boolean createuserIsNotNull) {
		this.createuserIsNotNull = createuserIsNotNull;
	}

	public java.util.List getCreateuserIn() {
		return createuserIn;
	}
	public void setCreateuserIn(java.util.List createuserIn) {
		this.createuserIn = createuserIn;
	}

	public String getCreateuserGreaterThanOrEqualTo() {
		return createuserGreaterThanOrEqualTo;
	}
	public void setCreateuserGreaterThanOrEqualTo(String createuserGreaterThanOrEqualTo) {
		this.createuserGreaterThanOrEqualTo = createuserGreaterThanOrEqualTo;
	}

	public String getCreateuserGreaterThan() {
		return createuserGreaterThan;
	}
	public void setCreateuserGreaterThan(String createuserGreaterThan) {
		this.createuserGreaterThan = createuserGreaterThan;
	}

	public String getCreateuserEqualTo() {
		return createuserEqualTo;
	}
	public void setCreateuserEqualTo(String createuserEqualTo) {
		this.createuserEqualTo = createuserEqualTo;
	}

	public java.util.List getCreatetimeNotIn() {
		return createtimeNotIn;
	}
	public void setCreatetimeNotIn(java.util.List createtimeNotIn) {
		this.createtimeNotIn = createtimeNotIn;
	}

	public java.util.Date getCreatetimeNotEqualTo() {
		return createtimeNotEqualTo;
	}
	public void setCreatetimeNotEqualTo(java.util.Date createtimeNotEqualTo) {
		this.createtimeNotEqualTo = createtimeNotEqualTo;
	}

	public java.util.Date getCreatetimeLessThanOrEqualTo() {
		return createtimeLessThanOrEqualTo;
	}
	public void setCreatetimeLessThanOrEqualTo(java.util.Date createtimeLessThanOrEqualTo) {
		this.createtimeLessThanOrEqualTo = createtimeLessThanOrEqualTo;
	}

	public java.util.Date getCreatetimeLessThan() {
		return createtimeLessThan;
	}
	public void setCreatetimeLessThan(java.util.Date createtimeLessThan) {
		this.createtimeLessThan = createtimeLessThan;
	}

	public Boolean getCreatetimeIsNull() {
		return createtimeIsNull;
	}
	public void setCreatetimeIsNull(Boolean createtimeIsNull) {
		this.createtimeIsNull = createtimeIsNull;
	}

	public Boolean getCreatetimeIsNotNull() {
		return createtimeIsNotNull;
	}
	public void setCreatetimeIsNotNull(Boolean createtimeIsNotNull) {
		this.createtimeIsNotNull = createtimeIsNotNull;
	}

	public java.util.List getCreatetimeIn() {
		return createtimeIn;
	}
	public void setCreatetimeIn(java.util.List createtimeIn) {
		this.createtimeIn = createtimeIn;
	}

	public java.util.Date getCreatetimeGreaterThanOrEqualTo() {
		return createtimeGreaterThanOrEqualTo;
	}
	public void setCreatetimeGreaterThanOrEqualTo(java.util.Date createtimeGreaterThanOrEqualTo) {
		this.createtimeGreaterThanOrEqualTo = createtimeGreaterThanOrEqualTo;
	}

	public java.util.Date getCreatetimeGreaterThan() {
		return createtimeGreaterThan;
	}
	public void setCreatetimeGreaterThan(java.util.Date createtimeGreaterThan) {
		this.createtimeGreaterThan = createtimeGreaterThan;
	}

	public java.util.Date getCreatetimeEqualTo() {
		return createtimeEqualTo;
	}
	public void setCreatetimeEqualTo(java.util.Date createtimeEqualTo) {
		this.createtimeEqualTo = createtimeEqualTo;
	}

	public void setSidx(String sidx) {
		this.sidx = sidx;
	}
	public String getSord() {
		return sord;
	}
	public void setSord(String sord) {
		 this.sord = sord;
	}
}
