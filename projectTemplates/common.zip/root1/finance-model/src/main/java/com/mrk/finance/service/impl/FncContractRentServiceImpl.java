package com.mrk.finance.service.impl;

import com.github.pagehelper.PageInfo;
import com.mrk.common.constant.BaseConstants;
import com.mrk.common.utils.bean.BeanUtils;
import com.mrk.common.utils.jwt.JWTUtil;
import com.mrk.common.utils.page.PageUtils;
import com.mrk.common.utils.text.StringUtils;
import com.mrk.finance.dao.FncContractRentMapper;
import com.mrk.finance.example.FncContractRentExample;
import com.mrk.finance.model.FncContractRent;
import com.mrk.finance.query.FncContractRentQuery;
import com.mrk.finance.queryvo.FncContractRentQueryVo;
import com.mrk.finance.service.FncContractRentService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import javax.annotation.Resource;
import java.util.Date;
import java.util.List;


/**
 * @Description: FncContractRentServiceImpl
 */
@Service
@Slf4j
public class FncContractRentServiceImpl implements FncContractRentService {
    @Resource
    private FncContractRentMapper fncContractRentMapper;

    @Override
    public PageInfo<FncContractRent> page(FncContractRentQueryVo queryVo){
        PageUtils.startPage();
        List<FncContractRent> list = this.list(queryVo);
        return new PageInfo<>(list);
    }

    @Override
    public List<FncContractRent> list(FncContractRentQueryVo queryVo){
        FncContractRentQuery query = new FncContractRentQuery();
        BeanUtils.copyBeanProp(queryVo, query);
        query.setSidx(StringUtils.camelToUnderlineAndFilterText(query.getSidx()));
        return fncContractRentMapper.selectByExample(query.getCrieria());
    }

    @Override
    @Transactional(rollbackFor = Exception.class)
    public int add(FncContractRent entity){
        entity.setCreatetime(new Date());
        entity.setUpdatetime(new Date());
        entity.setDr(BaseConstants.DR_NO);
        return fncContractRentMapper.insert(entity);
    }

    @Override
    public int addList(List<FncContractRent> rents) {
        if (rents == null || rents.isEmpty()) {
            return 0;
        }
        Date date = new Date();
        String name = JWTUtil.getNikeName();
        for (FncContractRent rent : rents) {
            rent.setDr(BaseConstants.DR_NO);
            rent.setCreatetime(date);
            rent.setCreateuser(name);
        }
        return fncContractRentMapper.insertList(rents);
    }

    @Override
    @Transactional(rollbackFor = Exception.class)
    public int update(FncContractRent entity){
        entity.setUpdatetime(new Date());
        return fncContractRentMapper.updateByPrimaryKey(entity);
    }

    @Override
    public int updateByExampleSelective(FncContractRent entity, FncContractRentExample example) {
        return fncContractRentMapper.updateByExampleSelective(entity, example);
    }

    @Override
    @Transactional(rollbackFor = Exception.class)
    public int delete(Long id){
        return fncContractRentMapper.deleteByPrimaryKey(id);
    }

    @Override
    public FncContractRent getById(Long id){
        return fncContractRentMapper.selectByPrimaryKey(id);
    }

    /**
     * @param contractId 合同Id
     * @return 合同对应的租金
     * @author Bob
     * @date 2021/11/22
     * @description 通过合同id获取合同租金
     */
    @Override
    public List<FncContractRent> getByContractId(Long contractId) {
        FncContractRentExample example = new FncContractRentExample();
        example.createCriteria()
                .andDrEqualTo(BaseConstants.NO)
                .andFccContractIdEqualTo(contractId);
        return fncContractRentMapper.selectByExample(example);
    }
}
