import com.base.BaseApplication;
import com.mrk.generator.MybatisGenerator;
import com.mrk.generator.service.GenTableService;
import lombok.extern.slf4j.Slf4j;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mybatis.generator.config.Configuration;
import org.mybatis.generator.config.Context;
import org.mybatis.generator.config.TableConfiguration;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

import java.util.List;

/**
 * @program: pp-partent
 * @Description:
 * @Author: Shen.Sun  suntion@yeah.net
 * @create: 2020-12-17 12:07
 **/
@RunWith(SpringRunner.class)
@SpringBootTest(classes = BaseApplication.class)
@Slf4j
public class GeneratorTest {

    @Autowired
    private GenTableService genTableService;

    /**
     * 先运行 生成 example
     * @throws Exception
     */
    public static void main(String[] args) throws Exception {
        MybatisGenerator.generate();
        MybatisGenerator.moveExample();
        MybatisGenerator.delFile();
    }


    /**
     * 生成service controller model
     * @throws Exception
     */
    @Test
    public void generatorCodes() throws Exception {
        /**
         * 根据 example  生成Query
         */
        MybatisGenerator.generateQuery();

        Configuration config = MybatisGenerator.getConfiguration();
        Context context = config.getContext("testTables");
        String targetPackage = context.getJavaModelGeneratorConfiguration().getTargetPackage();
        String packageName = targetPackage.substring(0, targetPackage.lastIndexOf("."));

        List<TableConfiguration> tableConfigurationList = context.getTableConfigurations();
        for (TableConfiguration tableConfiguration : tableConfigurationList) {
            log.info(tableConfiguration.getTableName() + "-" + tableConfiguration.getDomainObjectName());
            //生成controller
            genTableService.generatorController(packageName, "mrk_finance", tableConfiguration.getTableName());
            //生成service
            genTableService.generatorService(packageName, "mrk_finance", tableConfiguration.getTableName());
            //生成Model
            genTableService.generatorMoel(packageName, "mrk_finance", tableConfiguration.getTableName());
        }
    }
}
