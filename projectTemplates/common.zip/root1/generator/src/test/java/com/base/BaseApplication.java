package com.base;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.ComponentScan;
import tk.mybatis.spring.annotation.MapperScan;

/**
 * @program: pp-partent
 * @Description:
 * @Author: Shen.Sun  suntion@yeah.net
 * @create: 2020-12-17 12:07
 **/
@SpringBootApplication
@ComponentScan(basePackages = {"com.mrk"})
@MapperScan(basePackages = {"com.mrk.**.dao"})
public class BaseApplication {
    public static void main(String[] args) {
        SpringApplication.run(com.base.BaseApplication.class, args);
    }
}
